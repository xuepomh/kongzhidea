package com.kk.code.handle;

import java.util.List;
import java.util.Random;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.kk.code.model.ImgByteArray;
import com.kk.code.model.TemplateInfo;
import com.kk.code.util.HttpUtil;

public class TemplateHandler {
	private static final Log logger = LogFactory.getLog(TemplateHandler.class);

	private List<TemplateInfo> templateList;

	public int getVLTemplateCount() {
		return templateList.size();
	}

	public List<TemplateInfo> getVLTemplates(int offset, int count) {
		int toIndex = offset + count;

		// 防止越界
		if (toIndex > templateList.size()) {
			toIndex = templateList.size();
		}
		return templateList.subList(offset, toIndex);
	}

	public boolean validate(int animId) {
		for (TemplateInfo template : templateList) {
			if (template.getAnimId() == animId) {
				return true;
			}
		}
		return false;
	}

	public TemplateInfo getTemplateRandom() {

		Random rand = new Random();
		return templateList.get(rand.nextInt(templateList.size()));
	}

	/**
	 * @param templateList
	 *            the templateList to set
	 */
	public void setTemplateList(List<TemplateInfo> templateList) {
		this.templateList = templateList;
	}

	// 动态二维码地址，使用其他公司提供的服务
	private static final String URL_FM = "http://121.199.46.38/visualead-beta/api/get_anim?anim_id=%d&api_key=51ebf5aa-c8dc-4a47-b4ee-526379c72e26&content=%s";

	/**
	 * 生成动态二维码
	 * 
	 * @param animId
	 * @param content
	 * @return
	 */
	public ImgByteArray getQRCode(int animId, String content) {

		ImgByteArray byteArray = new ImgByteArray();

		String urlstr = getURL(animId, content);
		byte[] bt = HttpUtil.getContent(urlstr);
		byteArray.setBytes(bt);

		byteArray.setImgFmt(QRCodeMeta.IMAGE_GIF);
		byteArray.setOriginalFilename(System.currentTimeMillis() + "."
				+ QRCodeMeta.IMAGE_GIF);

		return byteArray;
	}

	public String getURL(int animId, String content) {
		String url = String.format(URL_FM, animId, content);
		return url;
	}

}

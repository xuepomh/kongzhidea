/*      */ package org.apache.hadoop.ipc;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.FilterInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.net.ConnectException;
/*      */ import java.net.InetAddress;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.Socket;
/*      */ import java.net.SocketTimeoutException;
/*      */ import java.net.UnknownHostException;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ import javax.net.SocketFactory;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.apache.hadoop.conf.Configuration;
/*      */ import org.apache.hadoop.io.DataOutputBuffer;
/*      */ import org.apache.hadoop.io.IOUtils;
/*      */ import org.apache.hadoop.io.Writable;
/*      */ import org.apache.hadoop.io.WritableUtils;
/*      */ import org.apache.hadoop.io.retry.RetryPolicies;
/*      */ import org.apache.hadoop.io.retry.RetryPolicy;
/*      */ import org.apache.hadoop.net.NetUtils;
/*      */ import org.apache.hadoop.security.KerberosInfo;
/*      */ import org.apache.hadoop.security.SaslRpcClient;
/*      */ import org.apache.hadoop.security.SaslRpcServer.AuthMethod;
/*      */ import org.apache.hadoop.security.SecurityUtil;
/*      */ import org.apache.hadoop.security.UserGroupInformation;
/*      */ import org.apache.hadoop.security.token.Token;
/*      */ import org.apache.hadoop.security.token.TokenIdentifier;
/*      */ import org.apache.hadoop.security.token.TokenInfo;
/*      */ import org.apache.hadoop.security.token.TokenSelector;
/*      */ import org.apache.hadoop.util.ReflectionUtils;
/*      */ 
/*      */ public class Client
/*      */ {
/*      */   public static final String IPC_CLIENT_CONNECT_MAX_RETRIES_KEY = "ipc.client.connect.max.retries";
/*      */   public static final int IPC_CLIENT_CONNECT_MAX_RETRIES_DEFAULT = 10;
/*   79 */   public static final Log LOG = LogFactory.getLog(Client.class);
/*      */ 
/*   81 */   private Hashtable<ConnectionId, Connection> connections = new Hashtable();
/*      */   private Class<? extends Writable> valueClass;
/*      */   private int counter;
/*   86 */   private AtomicBoolean running = new AtomicBoolean(true);
/*      */   private final Configuration conf;
/*      */   private SocketFactory socketFactory;
/*   90 */   private int refCount = 1;
/*      */   private final boolean fallbackAllowed;
/*      */   private static final String PING_INTERVAL_NAME = "ipc.ping.interval";
/*      */   static final int DEFAULT_PING_INTERVAL = 60000;
/*      */   static final int PING_CALL_ID = -1;
/*      */ 
/*      */   public static final void setPingInterval(Configuration conf, int pingInterval)
/*      */   {
/*  105 */     conf.setInt("ipc.ping.interval", pingInterval);
/*      */   }
/*      */ 
/*      */   static final int getPingInterval(Configuration conf)
/*      */   {
/*  116 */     return conf.getInt("ipc.ping.interval", 60000);
/*      */   }
/*      */ 
/*      */   public static final int getTimeout(Configuration conf)
/*      */   {
/*  128 */     if (!conf.getBoolean("ipc.client.ping", true)) {
/*  129 */       return getPingInterval(conf);
/*      */     }
/*  131 */     return -1;
/*      */   }
/*      */ 
/*      */   synchronized void incCount()
/*      */   {
/*  139 */     this.refCount += 1;
/*      */   }
/*      */ 
/*      */   synchronized void decCount()
/*      */   {
/*  147 */     this.refCount -= 1;
/*      */   }
/*      */ 
/*      */   synchronized boolean isZeroReference()
/*      */   {
/*  156 */     return this.refCount == 0;
/*      */   }
/*      */ 
/*      */   public Client(Class<? extends Writable> valueClass, Configuration conf, SocketFactory factory)
/*      */   {
/*  975 */     this.valueClass = valueClass;
/*  976 */     this.conf = conf;
/*  977 */     this.socketFactory = factory;
/*  978 */     this.fallbackAllowed = conf.getBoolean("ipc.client.fallback-to-simple-auth-allowed", false);
/*      */   }
/*      */ 
/*      */   public Client(Class<? extends Writable> valueClass, Configuration conf)
/*      */   {
/*  988 */     this(valueClass, conf, NetUtils.getDefaultSocketFactory(conf));
/*      */   }
/*      */ 
/*      */   SocketFactory getSocketFactory()
/*      */   {
/*  996 */     return this.socketFactory;
/*      */   }
/*      */ 
/*      */   public void stop()
/*      */   {
/* 1002 */     if (LOG.isDebugEnabled()) {
/* 1003 */       LOG.debug("Stopping client");
/*      */     }
/*      */ 
/* 1006 */     if (!this.running.compareAndSet(true, false)) {
/* 1007 */       return;
/*      */     }
/*      */ 
/* 1011 */     synchronized (this.connections) {
/* 1012 */       for (Connection conn : this.connections.values()) {
/* 1013 */         conn.interrupt();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1018 */     while (!this.connections.isEmpty())
/*      */       try {
/* 1020 */         Thread.sleep(100L);
/*      */       }
/*      */       catch (InterruptedException e)
/*      */       {
/*      */       }
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public Writable call(Writable param, InetSocketAddress address)
/*      */     throws InterruptedException, IOException
/*      */   {
/* 1034 */     return call(param, address, null);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public Writable call(Writable param, InetSocketAddress addr, UserGroupInformation ticket)
/*      */     throws InterruptedException, IOException
/*      */   {
/* 1048 */     ConnectionId remoteId = ConnectionId.getConnectionId(addr, null, ticket, 0, this.conf);
/*      */ 
/* 1050 */     return call(param, remoteId);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public Writable call(Writable param, InetSocketAddress addr, Class<?> protocol, UserGroupInformation ticket, int rpcTimeout)
/*      */     throws InterruptedException, IOException
/*      */   {
/* 1066 */     ConnectionId remoteId = ConnectionId.getConnectionId(addr, protocol, ticket, rpcTimeout, this.conf);
/*      */ 
/* 1068 */     return call(param, remoteId);
/*      */   }
/*      */ 
/*      */   public Writable call(Writable param, InetSocketAddress addr, Class<?> protocol, UserGroupInformation ticket, int rpcTimeout, Configuration conf)
/*      */     throws InterruptedException, IOException
/*      */   {
/* 1081 */     ConnectionId remoteId = ConnectionId.getConnectionId(addr, protocol, ticket, rpcTimeout, conf);
/*      */ 
/* 1083 */     return call(param, remoteId);
/*      */   }
/*      */ 
/*      */   public Writable call(Writable param, ConnectionId remoteId)
/*      */     throws InterruptedException, IOException
/*      */   {
/* 1092 */     Call call = new Call(param);
/* 1093 */     Connection connection = getConnection(remoteId, call);
/* 1094 */     connection.sendParam(call);
/* 1095 */     boolean interrupted = false;
/* 1096 */     synchronized (call) {
/* 1097 */       while (!call.done) {
/*      */         try {
/* 1099 */           call.wait();
/*      */         }
/*      */         catch (InterruptedException ie) {
/* 1102 */           interrupted = true;
/*      */         }
/*      */       }
/*      */ 
/* 1106 */       if (interrupted)
/*      */       {
/* 1108 */         Thread.currentThread().interrupt();
/*      */       }
/*      */ 
/* 1111 */       if (call.error != null) {
/* 1112 */         if ((call.error instanceof RemoteException)) {
/* 1113 */           call.error.fillInStackTrace();
/* 1114 */           throw call.error;
/*      */         }
/*      */ 
/* 1118 */         throw wrapException(connection.getRemoteAddress(), call.error);
/*      */       }
/*      */ 
/* 1121 */       return call.value;
/*      */     }
/*      */   }
/*      */ 
/*      */   private IOException wrapException(InetSocketAddress addr, IOException exception)
/*      */   {
/* 1140 */     if ((exception instanceof ConnectException))
/*      */     {
/* 1142 */       return (ConnectException)new ConnectException("Call to " + addr + " failed on connection exception: " + exception).initCause(exception);
/*      */     }
/*      */ 
/* 1145 */     if ((exception instanceof SocketTimeoutException)) {
/* 1146 */       return (SocketTimeoutException)new SocketTimeoutException("Call to " + addr + " failed on socket timeout exception: " + exception).initCause(exception);
/*      */     }
/*      */ 
/* 1150 */     return (IOException)new IOException("Call to " + addr + " failed on local exception: " + exception).initCause(exception);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public Writable[] call(Writable[] params, InetSocketAddress[] addresses)
/*      */     throws IOException, InterruptedException
/*      */   {
/* 1164 */     return call(params, addresses, null, null, this.conf);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public Writable[] call(Writable[] params, InetSocketAddress[] addresses, Class<?> protocol, UserGroupInformation ticket)
/*      */     throws IOException, InterruptedException
/*      */   {
/* 1175 */     return call(params, addresses, protocol, ticket, this.conf);
/*      */   }
/*      */ 
/*      */   public Writable[] call(Writable[] params, InetSocketAddress[] addresses, Class<?> protocol, UserGroupInformation ticket, Configuration conf)
/*      */     throws IOException, InterruptedException
/*      */   {
/* 1186 */     if (addresses.length == 0) return new Writable[0];
/*      */ 
/* 1188 */     ParallelResults results = new ParallelResults(params.length);
/* 1189 */     synchronized (results) {
/* 1190 */       for (int i = 0; i < params.length; i++) {
/* 1191 */         ParallelCall call = new ParallelCall(params[i], results, i);
/*      */         try {
/* 1193 */           ConnectionId remoteId = ConnectionId.getConnectionId(addresses[i], protocol, ticket, 0, conf);
/*      */ 
/* 1195 */           Connection connection = getConnection(remoteId, call);
/* 1196 */           connection.sendParam(call);
/*      */         }
/*      */         catch (IOException e) {
/* 1199 */           LOG.info("Calling " + addresses[i] + " caught: " + e.getMessage(), e);
/*      */ 
/* 1201 */           ParallelResults.access$1810(results);
/*      */         }
/*      */       }
/* 1204 */       while (results.count != results.size)
/*      */         try {
/* 1206 */           results.wait();
/*      */         }
/*      */         catch (InterruptedException e) {
/*      */         }
/* 1210 */       return results.values;
/*      */     }
/*      */   }
/*      */ 
/*      */   Set<ConnectionId> getConnectionIds()
/*      */   {
/* 1216 */     synchronized (this.connections) {
/* 1217 */       return this.connections.keySet();
/*      */     }
/*      */   }
/*      */ 
/*      */   private Connection getConnection(ConnectionId remoteId, Call call)
/*      */     throws IOException, InterruptedException
/*      */   {
/* 1226 */     if (!this.running.get())
/*      */     {
/* 1228 */       throw new IOException("The client is stopped");
/*      */     }
/*      */ 
/*      */     Connection connection;
/*      */     do
/*      */     {
/* 1236 */       synchronized (this.connections) {
/* 1237 */         connection = (Connection)this.connections.get(remoteId);
/* 1238 */         if (connection == null) {
/* 1239 */           connection = new Connection(remoteId);
/* 1240 */           this.connections.put(remoteId, connection);
/*      */         }
/*      */       }
/*      */     }
/* 1243 */     while (!connection.addCall(call));
/*      */ 
/* 1249 */     connection.setupIOstreams();
/* 1250 */     return connection;
/*      */   }
/*      */ 
/*      */   static class ConnectionId
/*      */   {
/*      */     InetSocketAddress address;
/*      */     UserGroupInformation ticket;
/*      */     Class<?> protocol;
/*      */     private static final int PRIME = 16777619;
/*      */     private int rpcTimeout;
/*      */     private String serverPrincipal;
/*      */     private int maxIdleTime;
/*      */     private final RetryPolicy connectionRetryPolicy;
/*      */     private boolean tcpNoDelay;
/*      */     private int pingInterval;
/*      */ 
/*      */     ConnectionId(InetSocketAddress address, Class<?> protocol, UserGroupInformation ticket, int rpcTimeout, String serverPrincipal, int maxIdleTime, RetryPolicy connectionRetryPolicy, boolean tcpNoDelay, int pingInterval) {
/* 1276 */       this.protocol = protocol;
/* 1277 */       this.address = address;
/* 1278 */       this.ticket = ticket;
/* 1279 */       this.rpcTimeout = rpcTimeout;
/* 1280 */       this.serverPrincipal = serverPrincipal;
/* 1281 */       this.maxIdleTime = maxIdleTime;
/* 1282 */       this.connectionRetryPolicy = connectionRetryPolicy;
/* 1283 */       this.tcpNoDelay = tcpNoDelay;
/* 1284 */       this.pingInterval = pingInterval;
/*      */     }
/*      */ 
/*      */     InetSocketAddress getAddress() {
/* 1288 */       return this.address;
/*      */     }
/*      */ 
/*      */     Class<?> getProtocol() {
/* 1292 */       return this.protocol;
/*      */     }
/*      */ 
/*      */     UserGroupInformation getTicket() {
/* 1296 */       return this.ticket;
/*      */     }
/*      */ 
/*      */     private int getRpcTimeout() {
/* 1300 */       return this.rpcTimeout;
/*      */     }
/*      */ 
/*      */     String getServerPrincipal() {
/* 1304 */       return this.serverPrincipal;
/*      */     }
/*      */ 
/*      */     int getMaxIdleTime() {
/* 1308 */       return this.maxIdleTime;
/*      */     }
/*      */ 
/*      */     boolean getTcpNoDelay() {
/* 1312 */       return this.tcpNoDelay;
/*      */     }
/*      */ 
/*      */     int getPingInterval() {
/* 1316 */       return this.pingInterval;
/*      */     }
/*      */ 
/*      */     static ConnectionId getConnectionId(InetSocketAddress addr, Class<?> protocol, UserGroupInformation ticket, Configuration conf)
/*      */       throws IOException
/*      */     {
/* 1322 */       return getConnectionId(addr, protocol, ticket, 0, conf);
/*      */     }
/*      */ 
/*      */     static ConnectionId getConnectionId(InetSocketAddress addr, Class<?> protocol, UserGroupInformation ticket, int rpcTimeout, Configuration conf)
/*      */       throws IOException
/*      */     {
/* 1328 */       return getConnectionId(addr, protocol, ticket, rpcTimeout, null, conf);
/*      */     }
/*      */ 
/*      */     static ConnectionId getConnectionId(InetSocketAddress addr, Class<?> protocol, UserGroupInformation ticket, int rpcTimeout, RetryPolicy connectionRetryPolicy, Configuration conf)
/*      */       throws IOException
/*      */     {
/* 1335 */       if (connectionRetryPolicy == null) {
/* 1336 */         int max = conf.getInt("ipc.client.connect.max.retries", 10);
/*      */ 
/* 1339 */         connectionRetryPolicy = RetryPolicies.retryUpToMaximumCountWithFixedSleep(max, 1L, TimeUnit.SECONDS);
/*      */       }
/*      */ 
/* 1343 */       String remotePrincipal = getRemotePrincipal(conf, addr, protocol);
/* 1344 */       return new ConnectionId(addr, protocol, ticket, rpcTimeout, remotePrincipal, conf.getInt("ipc.client.connection.maxidletime", 10000), connectionRetryPolicy, conf.getBoolean("ipc.client.tcpnodelay", false), Client.getPingInterval(conf));
/*      */     }
/*      */ 
/*      */     private static String getRemotePrincipal(Configuration conf, InetSocketAddress address, Class<?> protocol)
/*      */       throws IOException
/*      */     {
/* 1354 */       if ((!UserGroupInformation.isSecurityEnabled()) || (protocol == null)) {
/* 1355 */         return null;
/*      */       }
/* 1357 */       KerberosInfo krbInfo = (KerberosInfo)protocol.getAnnotation(KerberosInfo.class);
/* 1358 */       if (krbInfo != null) {
/* 1359 */         String serverKey = krbInfo.serverPrincipal();
/* 1360 */         if (serverKey == null) {
/* 1361 */           throw new IOException("Can't obtain server Kerberos config key from protocol=" + protocol.getCanonicalName());
/*      */         }
/*      */ 
/* 1365 */         return SecurityUtil.getServerPrincipal(conf.get(serverKey), address.getAddress());
/*      */       }
/*      */ 
/* 1368 */       return null;
/*      */     }
/*      */ 
/*      */     static boolean isEqual(Object a, Object b) {
/* 1372 */       return a == null ? false : b == null ? true : a.equals(b);
/*      */     }
/*      */ 
/*      */     public boolean equals(Object obj)
/*      */     {
/* 1377 */       if (obj == this) {
/* 1378 */         return true;
/*      */       }
/* 1380 */       if ((obj instanceof ConnectionId)) {
/* 1381 */         ConnectionId that = (ConnectionId)obj;
/* 1382 */         return (isEqual(this.address, that.address)) && (this.maxIdleTime == that.maxIdleTime) && (isEqual(this.connectionRetryPolicy, that.connectionRetryPolicy)) && (this.pingInterval == that.pingInterval) && (isEqual(this.protocol, that.protocol)) && (this.rpcTimeout == that.rpcTimeout) && (isEqual(this.serverPrincipal, that.serverPrincipal)) && (this.tcpNoDelay == that.tcpNoDelay) && (isEqual(this.ticket, that.ticket));
/*      */       }
/*      */ 
/* 1392 */       return false;
/*      */     }
/*      */ 
/*      */     public int hashCode()
/*      */     {
/* 1397 */       int result = this.connectionRetryPolicy.hashCode();
/* 1398 */       result = 16777619 * result + (this.address == null ? 0 : this.address.hashCode());
/* 1399 */       result = 16777619 * result + this.maxIdleTime;
/* 1400 */       result = 16777619 * result + this.pingInterval;
/* 1401 */       result = 16777619 * result + (this.protocol == null ? 0 : this.protocol.hashCode());
/* 1402 */       result = 16777619 * this.rpcTimeout;
/* 1403 */       result = 16777619 * result + (this.serverPrincipal == null ? 0 : this.serverPrincipal.hashCode());
/*      */ 
/* 1405 */       result = 16777619 * result + (this.tcpNoDelay ? 1231 : 1237);
/* 1406 */       result = 16777619 * result + (this.ticket == null ? 0 : this.ticket.hashCode());
/* 1407 */       return result;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class ParallelResults
/*      */   {
/*      */     private Writable[] values;
/*      */     private int size;
/*      */     private int count;
/*      */ 
/*      */     public ParallelResults(int size)
/*      */     {
/*  958 */       this.values = new Writable[size];
/*  959 */       this.size = size;
/*      */     }
/*      */ 
/*      */     public synchronized void callComplete(Client.ParallelCall call)
/*      */     {
/*  964 */       this.values[Client.ParallelCall.access$1700(call)] = call.value;
/*  965 */       this.count += 1;
/*  966 */       if (this.count == this.size)
/*  967 */         notify();
/*      */     }
/*      */   }
/*      */ 
/*      */   private class ParallelCall extends Client.Call
/*      */   {
/*      */     private Client.ParallelResults results;
/*      */     private int index;
/*      */ 
/*      */     public ParallelCall(Writable param, Client.ParallelResults results, int index)
/*      */     {
/*  940 */       super(param);
/*  941 */       this.results = results;
/*  942 */       this.index = index;
/*      */     }
/*      */ 
/*      */     protected void callComplete()
/*      */     {
/*  947 */       this.results.callComplete(this);
/*      */     }
/*      */   }
/*      */ 
/*      */   private class Connection extends Thread
/*      */   {
/*      */     private InetSocketAddress server;
/*      */     private String serverPrincipal;
/*      */     private ConnectionHeader header;
/*      */     private final Client.ConnectionId remoteId;
/*      */     private SaslRpcServer.AuthMethod authMethod;
/*      */     private boolean useSasl;
/*      */     private Token<? extends TokenIdentifier> token;
/*      */     private SaslRpcClient saslRpcClient;
/*  215 */     private Socket socket = null;
/*      */     private DataInputStream in;
/*      */     private DataOutputStream out;
/*      */     private int rpcTimeout;
/*      */     private int maxIdleTime;
/*      */     private final RetryPolicy connectionRetryPolicy;
/*      */     private boolean tcpNoDelay;
/*      */     private int pingInterval;
/*  227 */     private Hashtable<Integer, Client.Call> calls = new Hashtable();
/*  228 */     private AtomicLong lastActivity = new AtomicLong();
/*  229 */     private AtomicBoolean shouldCloseConnection = new AtomicBoolean();
/*      */     private IOException closeException;
/*      */ 
/*      */     public Connection(Client.ConnectionId remoteId)
/*      */       throws IOException
/*      */     {
/*  233 */       this.remoteId = remoteId;
/*  234 */       this.server = remoteId.getAddress();
/*  235 */       if (this.server.isUnresolved()) {
/*  236 */         throw new UnknownHostException(new StringBuilder().append("unknown host: ").append(remoteId.getAddress().getHostName()).toString());
/*      */       }
/*      */ 
/*  239 */       this.maxIdleTime = remoteId.getMaxIdleTime();
/*  240 */       this.connectionRetryPolicy = remoteId.connectionRetryPolicy;
/*  241 */       this.tcpNoDelay = remoteId.getTcpNoDelay();
/*  242 */       this.pingInterval = remoteId.getPingInterval();
/*  243 */       if (Client.LOG.isDebugEnabled()) {
/*  244 */         Client.LOG.debug(new StringBuilder().append("The ping interval is").append(this.pingInterval).append("ms.").toString());
/*      */       }
/*  246 */       this.rpcTimeout = remoteId.getRpcTimeout();
/*  247 */       UserGroupInformation ticket = remoteId.getTicket();
/*  248 */       Class protocol = remoteId.getProtocol();
/*  249 */       this.useSasl = UserGroupInformation.isSecurityEnabled();
/*  250 */       if ((this.useSasl) && (protocol != null)) {
/*  251 */         TokenInfo tokenInfo = (TokenInfo)protocol.getAnnotation(TokenInfo.class);
/*  252 */         if (tokenInfo != null) {
/*  253 */           TokenSelector tokenSelector = null;
/*      */           try {
/*  255 */             tokenSelector = (TokenSelector)tokenInfo.value().newInstance();
/*      */           } catch (InstantiationException e) {
/*  257 */             throw new IOException(e.toString());
/*      */           } catch (IllegalAccessException e) {
/*  259 */             throw new IOException(e.toString());
/*      */           }
/*  261 */           InetSocketAddress addr = remoteId.getAddress();
/*  262 */           this.token = tokenSelector.selectToken(SecurityUtil.buildTokenService(addr), ticket.getTokens());
/*      */         }
/*      */ 
/*  265 */         KerberosInfo krbInfo = (KerberosInfo)protocol.getAnnotation(KerberosInfo.class);
/*  266 */         if (krbInfo != null) {
/*  267 */           this.serverPrincipal = remoteId.getServerPrincipal();
/*  268 */           if (Client.LOG.isDebugEnabled()) {
/*  269 */             Client.LOG.debug(new StringBuilder().append("RPC Server's Kerberos principal name for protocol=").append(protocol.getCanonicalName()).append(" is ").append(this.serverPrincipal).toString());
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  275 */       if (!this.useSasl)
/*  276 */         this.authMethod = SaslRpcServer.AuthMethod.SIMPLE;
/*  277 */       else if (this.token != null)
/*  278 */         this.authMethod = SaslRpcServer.AuthMethod.DIGEST;
/*      */       else {
/*  280 */         this.authMethod = SaslRpcServer.AuthMethod.KERBEROS;
/*      */       }
/*      */ 
/*  283 */       this.header = new ConnectionHeader(protocol == null ? null : protocol.getName(), ticket, this.authMethod);
/*      */ 
/*  286 */       if (Client.LOG.isDebugEnabled()) {
/*  287 */         Client.LOG.debug(new StringBuilder().append("Use ").append(this.authMethod).append(" authentication for protocol ").append(protocol.getSimpleName()).toString());
/*      */       }
/*      */ 
/*  290 */       setName(new StringBuilder().append("IPC Client (").append(Client.this.socketFactory.hashCode()).append(") connection to ").append(remoteId.getAddress().toString()).append(" from ").append(ticket == null ? "an unknown user" : ticket.getUserName()).toString());
/*      */ 
/*  293 */       setDaemon(true);
/*      */     }
/*      */ 
/*      */     private void touch()
/*      */     {
/*  298 */       this.lastActivity.set(System.currentTimeMillis());
/*      */     }
/*      */ 
/*      */     private synchronized boolean addCall(Client.Call call)
/*      */     {
/*  309 */       if (this.shouldCloseConnection.get())
/*  310 */         return false;
/*  311 */       this.calls.put(Integer.valueOf(call.id), call);
/*  312 */       notify();
/*  313 */       return true;
/*      */     }
/*      */ 
/*      */     private synchronized void disposeSasl()
/*      */     {
/*  373 */       if (this.saslRpcClient != null)
/*      */         try {
/*  375 */           this.saslRpcClient.dispose();
/*      */         }
/*      */         catch (IOException ignored) {
/*      */         }
/*      */     }
/*      */ 
/*      */     private synchronized boolean shouldAuthenticateOverKrb() throws IOException {
/*  382 */       UserGroupInformation loginUser = UserGroupInformation.getLoginUser();
/*  383 */       UserGroupInformation currentUser = UserGroupInformation.getCurrentUser();
/*      */ 
/*  385 */       UserGroupInformation realUser = currentUser.getRealUser();
/*  386 */       if ((this.authMethod == SaslRpcServer.AuthMethod.KERBEROS) && (loginUser != null) && (loginUser.hasKerberosCredentials()) && ((loginUser.equals(currentUser)) || (loginUser.equals(realUser))))
/*      */       {
/*  394 */         return true;
/*      */       }
/*  396 */       return false;
/*      */     }
/*      */ 
/*      */     private synchronized boolean setupSaslConnection(InputStream in2, OutputStream out2)
/*      */       throws IOException
/*      */     {
/*  402 */       this.saslRpcClient = new SaslRpcClient(this.authMethod, this.token, this.serverPrincipal, Client.this.fallbackAllowed);
/*      */ 
/*  404 */       return this.saslRpcClient.saslConnect(in2, out2);
/*      */     }
/*      */ 
/*      */     private synchronized boolean updateAddress()
/*      */       throws IOException
/*      */     {
/*  416 */       InetSocketAddress currentAddr = NetUtils.makeSocketAddr(this.server.getHostName(), this.server.getPort());
/*      */ 
/*  419 */       if (!this.server.equals(currentAddr)) {
/*  420 */         Client.LOG.warn(new StringBuilder().append("Address change detected. Old: ").append(this.server.toString()).append(" New: ").append(currentAddr.toString()).toString());
/*      */ 
/*  422 */         this.server = currentAddr;
/*  423 */         return true;
/*      */       }
/*  425 */       return false;
/*      */     }
/*      */ 
/*      */     private synchronized void setupConnection() throws IOException {
/*  429 */       short ioFailures = 0;
/*  430 */       short timeoutFailures = 0;
/*      */       while (true)
/*      */         try {
/*  433 */           this.socket = Client.this.socketFactory.createSocket();
/*  434 */           this.socket.setTcpNoDelay(this.tcpNoDelay);
/*      */ 
/*  441 */           if (UserGroupInformation.isSecurityEnabled()) {
/*  442 */             KerberosInfo krbInfo = (KerberosInfo)this.remoteId.getProtocol().getAnnotation(KerberosInfo.class);
/*      */ 
/*  444 */             if ((krbInfo != null) && (krbInfo.clientPrincipal() != null)) {
/*  445 */               String host = SecurityUtil.getHostFromPrincipal(this.remoteId.getTicket().getUserName());
/*      */ 
/*  449 */               InetAddress localAddr = NetUtils.getLocalInetAddress(host);
/*  450 */               if (localAddr != null) {
/*  451 */                 this.socket.bind(new InetSocketAddress(localAddr, 0));
/*      */               }
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  457 */           NetUtils.connect(this.socket, this.server, 20000);
/*  458 */           if (this.rpcTimeout > 0) {
/*  459 */             this.pingInterval = this.rpcTimeout;
/*      */           }
/*      */ 
/*  462 */           this.socket.setSoTimeout(this.pingInterval);
/*  463 */           return;
/*      */         }
/*      */         catch (SocketTimeoutException toe)
/*      */         {
/*  468 */           if (updateAddress()) {
/*  469 */             timeoutFailures = ioFailures = 0;
/*      */           }
/*      */ 
/*  474 */           timeoutFailures = (short)(timeoutFailures + 1); handleConnectionFailure(timeoutFailures, 45, toe);
/*      */         } catch (IOException ie) {
/*  476 */           if (updateAddress()) {
/*  477 */             timeoutFailures = ioFailures = 0;
/*      */           }
/*  479 */           ioFailures = (short)(ioFailures + 1); handleConnectionFailure(ioFailures, ie);
/*      */         }
/*      */     }
/*      */ 
/*      */     private synchronized void handleSaslConnectionFailure(final int currRetries, final int maxRetries, final Exception ex, final Random rand, UserGroupInformation ugi)
/*      */       throws IOException, InterruptedException
/*      */     {
/*  507 */       ugi.doAs(new PrivilegedExceptionAction() {
/*      */         public Object run() throws IOException, InterruptedException {
/*  509 */           short maxBackoff = 5000;
/*  510 */           Client.Connection.this.closeConnection();
/*  511 */           Client.Connection.this.disposeSasl();
/*      */ 
/*  518 */           if ((ex instanceof SocketTimeoutException)) {
/*  519 */             if (currRetries < maxRetries) {
/*  520 */               Client.LOG.warn("Encountered " + ex + " while trying to establish" + " SASL connection to the server. Will retry SASL connection" + " to server with principal " + Client.Connection.this.serverPrincipal);
/*      */ 
/*  527 */               Thread.sleep(rand.nextInt(5000) + 1);
/*  528 */               return null;
/*      */             }
/*  530 */             throw new IOException(ex);
/*      */           }
/*      */ 
/*  533 */           if (Client.Connection.this.shouldAuthenticateOverKrb()) {
/*  534 */             if (currRetries < maxRetries) {
/*  535 */               Client.LOG.debug("Exception encountered while connecting to the server : " + ex);
/*      */ 
/*  538 */               if (UserGroupInformation.isLoginKeytabBased())
/*  539 */                 UserGroupInformation.getLoginUser().reloginFromKeytab();
/*      */               else {
/*  541 */                 UserGroupInformation.getLoginUser().reloginFromTicketCache();
/*      */               }
/*      */ 
/*  547 */               Thread.sleep(rand.nextInt(5000) + 1);
/*  548 */               return null;
/*      */             }
/*  550 */             String msg = "Couldn't setup connection for " + UserGroupInformation.getLoginUser().getUserName() + " to " + Client.Connection.this.serverPrincipal;
/*      */ 
/*  553 */             Client.LOG.warn(msg);
/*  554 */             throw ((IOException)new IOException(msg).initCause(ex));
/*      */           }
/*      */ 
/*  557 */           Client.LOG.warn("Exception encountered while connecting to the server : " + ex);
/*      */ 
/*  560 */           if ((ex instanceof RemoteException))
/*  561 */             throw ((RemoteException)ex);
/*  562 */           throw new IOException(ex);
/*      */         }
/*      */       });
/*      */     }
/*      */ 
/*      */     private synchronized void setupIOstreams()
/*      */       throws InterruptedException
/*      */     {
/*  571 */       if ((this.socket != null) || (this.shouldCloseConnection.get())) {
/*  572 */         return;
/*      */       }
/*      */       try
/*      */       {
/*  576 */         if (Client.LOG.isDebugEnabled()) {
/*  577 */           Client.LOG.debug(new StringBuilder().append("Connecting to ").append(this.server).toString()); } short numRetries = 0;
/*  580 */         short maxRetries = 15;
/*  581 */         Random rand = null;
/*      */         InputStream inStream;
/*      */         OutputStream outStream;
/*      */         boolean continueSasl;
/*      */         while (true) { setupConnection();
/*  584 */           inStream = NetUtils.getInputStream(this.socket);
/*  585 */           outStream = NetUtils.getOutputStream(this.socket);
/*  586 */           writeRpcHeader(outStream);
/*  587 */           if (!this.useSasl) break label279;
/*  588 */           final InputStream in2 = inStream;
/*  589 */           final OutputStream out2 = outStream;
/*  590 */           UserGroupInformation ticket = this.remoteId.getTicket();
/*  591 */           if ((this.authMethod == SaslRpcServer.AuthMethod.KERBEROS) && 
/*  592 */             (ticket.getRealUser() != null)) {
/*  593 */             ticket = ticket.getRealUser();
/*      */           }
/*      */ 
/*  596 */           continueSasl = false;
/*      */           try {
/*  598 */             continueSasl = ((Boolean)ticket.doAs(new PrivilegedExceptionAction()
/*      */             {
/*      */               public Boolean run() throws IOException
/*      */               {
/*  602 */                 return Boolean.valueOf(Client.Connection.this.setupSaslConnection(in2, out2));
/*      */               }
/*      */             })).booleanValue();
/*      */           }
/*      */           catch (Exception ex)
/*      */           {
/*  606 */             if (rand == null) {
/*  607 */               rand = new Random();
/*      */             }
/*  609 */             numRetries = (short)(numRetries + 1); handleSaslConnectionFailure(numRetries, 15, ex, rand, ticket);
/*      */           }
/*      */         }
/*      */ 
/*  613 */         if (continueSasl)
/*      */         {
/*  615 */           inStream = this.saslRpcClient.getInputStream(inStream);
/*  616 */           outStream = this.saslRpcClient.getOutputStream(outStream);
/*      */         }
/*      */         else {
/*  619 */           this.authMethod = SaslRpcServer.AuthMethod.SIMPLE;
/*  620 */           this.header = new ConnectionHeader(this.header.getProtocol(), this.header.getUgi(), this.authMethod);
/*      */ 
/*  622 */           this.useSasl = false;
/*      */         }
/*      */ 
/*  625 */         label279: this.in = new DataInputStream(new BufferedInputStream(new PingInputStream(inStream)));
/*      */ 
/*  627 */         this.out = new DataOutputStream(new BufferedOutputStream(outStream));
/*      */ 
/*  629 */         writeHeader();
/*      */ 
/*  632 */         touch();
/*      */ 
/*  635 */         start();
/*  636 */         return;
/*      */       }
/*      */       catch (Throwable t) {
/*  639 */         if ((t instanceof IOException))
/*  640 */           markClosed((IOException)t);
/*      */         else {
/*  642 */           markClosed(new IOException("Couldn't set up IO streams", t));
/*      */         }
/*  644 */         close();
/*      */       }
/*      */     }
/*      */ 
/*      */     private void closeConnection()
/*      */     {
/*      */       try {
/*  651 */         this.socket.close();
/*      */       } catch (IOException e) {
/*  653 */         Client.LOG.warn("Not able to close a socket", e);
/*      */       }
/*      */ 
/*  657 */       this.socket = null;
/*      */     }
/*      */ 
/*      */     private void handleConnectionFailure(int curRetries, int maxRetries, IOException ioe)
/*      */       throws IOException
/*      */     {
/*  677 */       closeConnection();
/*      */ 
/*  680 */       if (curRetries >= maxRetries) {
/*  681 */         throw ioe;
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/*  686 */         Thread.sleep(1000L);
/*      */       } catch (InterruptedException ignored) {
/*      */       }
/*  689 */       Client.LOG.info(new StringBuilder().append("Retrying connect to server: ").append(this.server).append(". Already tried ").append(curRetries).append(" time(s); maxRetries=").append(maxRetries).toString());
/*      */     }
/*      */ 
/*      */     private void handleConnectionFailure(int curRetries, IOException ioe) throws IOException
/*      */     {
/*  695 */       closeConnection();
/*      */       boolean retry;
/*      */       try
/*      */       {
/*  699 */         retry = this.connectionRetryPolicy.shouldRetry(ioe, curRetries);
/*      */       } catch (Exception e) {
/*  701 */         throw ((e instanceof IOException) ? (IOException)e : new IOException(e));
/*      */       }
/*  703 */       if (!retry) {
/*  704 */         throw ioe;
/*      */       }
/*      */ 
/*  707 */       Client.LOG.info(new StringBuilder().append("Retrying connect to server: ").append(this.server).append(". Already tried ").append(curRetries).append(" time(s); retry policy is ").append(this.connectionRetryPolicy).toString());
/*      */     }
/*      */ 
/*      */     private void writeRpcHeader(OutputStream outStream)
/*      */       throws IOException
/*      */     {
/*  713 */       DataOutputStream out = new DataOutputStream(new BufferedOutputStream(outStream));
/*      */ 
/*  715 */       out.write(Server.HEADER.array());
/*  716 */       out.write(4);
/*  717 */       this.authMethod.write(out);
/*  718 */       out.flush();
/*      */     }
/*      */ 
/*      */     private void writeHeader()
/*      */       throws IOException
/*      */     {
/*  726 */       DataOutputBuffer buf = new DataOutputBuffer();
/*  727 */       this.header.write(buf);
/*      */ 
/*  730 */       int bufLen = buf.getLength();
/*  731 */       this.out.writeInt(bufLen);
/*  732 */       this.out.write(buf.getData(), 0, bufLen);
/*      */     }
/*      */ 
/*      */     private synchronized boolean waitForWork()
/*      */     {
/*  742 */       if ((this.calls.isEmpty()) && (!this.shouldCloseConnection.get()) && (Client.this.running.get())) {
/*  743 */         long timeout = this.maxIdleTime - (System.currentTimeMillis() - this.lastActivity.get());
/*      */ 
/*  745 */         if (timeout > 0L)
/*      */           try {
/*  747 */             wait(timeout);
/*      */           }
/*      */           catch (InterruptedException e) {
/*      */           }
/*      */       }
/*  752 */       if ((!this.calls.isEmpty()) && (!this.shouldCloseConnection.get()) && (Client.this.running.get()))
/*  753 */         return true;
/*  754 */       if (this.shouldCloseConnection.get())
/*  755 */         return false;
/*  756 */       if (this.calls.isEmpty()) {
/*  757 */         markClosed(null);
/*  758 */         return false;
/*      */       }
/*  760 */       markClosed((IOException)new IOException().initCause(new InterruptedException()));
/*      */ 
/*  762 */       return false;
/*      */     }
/*      */ 
/*      */     public InetSocketAddress getRemoteAddress()
/*      */     {
/*  767 */       return this.server;
/*      */     }
/*      */ 
/*      */     private synchronized void sendPing()
/*      */       throws IOException
/*      */     {
/*  774 */       long curTime = System.currentTimeMillis();
/*  775 */       if (curTime - this.lastActivity.get() >= this.pingInterval) {
/*  776 */         this.lastActivity.set(curTime);
/*  777 */         synchronized (this.out) {
/*  778 */           this.out.writeInt(-1);
/*  779 */           this.out.flush();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public void run() {
/*  785 */       if (Client.LOG.isDebugEnabled()) {
/*  786 */         Client.LOG.debug(new StringBuilder().append(getName()).append(": starting, having connections ").append(Client.this.connections.size()).toString());
/*      */       }
/*      */ 
/*  789 */       while (waitForWork()) {
/*  790 */         receiveResponse();
/*      */       }
/*      */ 
/*  793 */       close();
/*      */ 
/*  795 */       if (Client.LOG.isDebugEnabled())
/*  796 */         Client.LOG.debug(new StringBuilder().append(getName()).append(": stopped, remaining connections ").append(Client.this.connections.size()).toString());
/*      */     }
/*      */ 
/*      */     public void sendParam(Client.Call call)
/*      */     {
/*  805 */       if (this.shouldCloseConnection.get()) {
/*  806 */         return;
/*      */       }
/*      */ 
/*  809 */       DataOutputBuffer d = null;
/*      */       try {
/*  811 */         synchronized (this.out) {
/*  812 */           if (Client.LOG.isDebugEnabled()) {
/*  813 */             Client.LOG.debug(new StringBuilder().append(getName()).append(" sending #").append(call.id).toString());
/*      */           }
/*      */ 
/*  817 */           d = new DataOutputBuffer();
/*  818 */           d.writeInt(call.id);
/*  819 */           call.param.write(d);
/*  820 */           byte[] data = d.getData();
/*  821 */           int dataLength = d.getLength();
/*  822 */           this.out.writeInt(dataLength);
/*  823 */           this.out.write(data, 0, dataLength);
/*  824 */           this.out.flush();
/*      */         }
/*      */       } catch (IOException e) {
/*  827 */         markClosed(e);
/*      */       }
/*      */       finally
/*      */       {
/*  831 */         IOUtils.closeStream(d);
/*      */       }
/*      */     }
/*      */ 
/*      */     private void receiveResponse()
/*      */     {
/*  839 */       if (this.shouldCloseConnection.get()) {
/*  840 */         return;
/*      */       }
/*  842 */       touch();
/*      */       try
/*      */       {
/*  845 */         int id = this.in.readInt();
/*      */ 
/*  847 */         if (Client.LOG.isDebugEnabled()) {
/*  848 */           Client.LOG.debug(new StringBuilder().append(getName()).append(" got value #").append(id).toString());
/*      */         }
/*  850 */         Client.Call call = (Client.Call)this.calls.get(Integer.valueOf(id));
/*      */ 
/*  852 */         int state = this.in.readInt();
/*  853 */         if (state == Status.SUCCESS.state) {
/*  854 */           Writable value = (Writable)ReflectionUtils.newInstance(Client.this.valueClass, Client.this.conf);
/*  855 */           value.readFields(this.in);
/*  856 */           call.setValue(value);
/*  857 */           this.calls.remove(Integer.valueOf(id));
/*  858 */         } else if (state == Status.ERROR.state) {
/*  859 */           call.setException(new RemoteException(WritableUtils.readString(this.in), WritableUtils.readString(this.in)));
/*      */ 
/*  861 */           this.calls.remove(Integer.valueOf(id));
/*  862 */         } else if (state == Status.FATAL.state)
/*      */         {
/*  864 */           markClosed(new RemoteException(WritableUtils.readString(this.in), WritableUtils.readString(this.in)));
/*      */         }
/*      */       }
/*      */       catch (IOException e) {
/*  868 */         markClosed(e);
/*      */       }
/*      */     }
/*      */ 
/*      */     private synchronized void markClosed(IOException e) {
/*  873 */       if (this.shouldCloseConnection.compareAndSet(false, true)) {
/*  874 */         this.closeException = e;
/*  875 */         notifyAll();
/*      */       }
/*      */     }
/*      */ 
/*      */     private synchronized void close()
/*      */     {
/*  881 */       if (!this.shouldCloseConnection.get()) {
/*  882 */         Client.LOG.error("The connection is not in the closed state");
/*  883 */         return;
/*      */       }
/*      */ 
/*  888 */       synchronized (Client.this.connections) {
/*  889 */         if (Client.this.connections.get(this.remoteId) == this) {
/*  890 */           Client.this.connections.remove(this.remoteId);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  895 */       IOUtils.closeStream(this.out);
/*  896 */       IOUtils.closeStream(this.in);
/*  897 */       disposeSasl();
/*      */ 
/*  900 */       if (this.closeException == null) {
/*  901 */         if (!this.calls.isEmpty()) {
/*  902 */           Client.LOG.warn("A connection is closed for no cause and calls are not empty");
/*      */ 
/*  906 */           this.closeException = new IOException("Unexpected closed connection");
/*  907 */           cleanupCalls();
/*      */         }
/*      */       }
/*      */       else {
/*  911 */         if (Client.LOG.isDebugEnabled()) {
/*  912 */           Client.LOG.debug(new StringBuilder().append("closing ipc connection to ").append(this.server).append(": ").append(this.closeException.getMessage()).toString(), this.closeException);
/*      */         }
/*      */ 
/*  917 */         cleanupCalls();
/*      */       }
/*  919 */       if (Client.LOG.isDebugEnabled())
/*  920 */         Client.LOG.debug(new StringBuilder().append(getName()).append(": closed").toString());
/*      */     }
/*      */ 
/*      */     private void cleanupCalls()
/*      */     {
/*  925 */       Iterator itor = this.calls.entrySet().iterator();
/*  926 */       while (itor.hasNext()) {
/*  927 */         Client.Call c = (Client.Call)((Map.Entry)itor.next()).getValue();
/*  928 */         c.setException(this.closeException);
/*  929 */         itor.remove();
/*      */       }
/*      */     }
/*      */ 
/*      */     private class PingInputStream extends FilterInputStream
/*      */     {
/*      */       protected PingInputStream(InputStream in)
/*      */       {
/*  323 */         super();
/*      */       }
/*      */ 
/*      */       private void handleTimeout(SocketTimeoutException e)
/*      */         throws IOException
/*      */       {
/*  333 */         if ((Client.Connection.this.shouldCloseConnection.get()) || (!Client.this.running.get()) || (Client.Connection.this.rpcTimeout > 0)) {
/*  334 */           throw e;
/*      */         }
/*  336 */         Client.Connection.this.sendPing();
/*      */       }
/*      */ 
/*      */       public int read()
/*      */         throws IOException
/*      */       {
/*      */         while (true)
/*      */           try
/*      */           {
/*  348 */             return super.read();
/*      */           } catch (SocketTimeoutException e) {
/*  350 */             handleTimeout(e);
/*      */           }
/*      */       }
/*      */ 
/*      */       public int read(byte[] buf, int off, int len)
/*      */         throws IOException
/*      */       {
/*      */         while (true)
/*      */           try
/*      */           {
/*  364 */             return super.read(buf, off, len);
/*      */           } catch (SocketTimeoutException e) {
/*  366 */             handleTimeout(e);
/*      */           }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private class Call
/*      */   {
/*      */     int id;
/*      */     Writable param;
/*      */     Writable value;
/*      */     IOException error;
/*      */     boolean done;
/*      */ 
/*      */     protected Call(Writable param)
/*      */     {
/*  168 */       this.param = param;
/*  169 */       synchronized (Client.this) {
/*  170 */         this.id = Client.access$008(Client.this);
/*      */       }
/*      */     }
/*      */ 
/*      */     protected synchronized void callComplete()
/*      */     {
/*  177 */       this.done = true;
/*  178 */       notify();
/*      */     }
/*      */ 
/*      */     public synchronized void setException(IOException error)
/*      */     {
/*  187 */       this.error = error;
/*  188 */       callComplete();
/*      */     }
/*      */ 
/*      */     public synchronized void setValue(Writable value)
/*      */     {
/*  197 */       this.value = value;
/*  198 */       callComplete();
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.ipc.Client
 * JD-Core Version:    0.6.1
 */
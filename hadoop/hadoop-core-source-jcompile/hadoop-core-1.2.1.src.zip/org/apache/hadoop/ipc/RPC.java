/*     */ package org.apache.hadoop.ipc;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.net.ConnectException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketTimeoutException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.net.SocketFactory;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configurable;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.io.ObjectWritable;
/*     */ import org.apache.hadoop.io.UTF8;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.retry.RetryPolicy;
/*     */ import org.apache.hadoop.ipc.metrics.RpcInstrumentation;
/*     */ import org.apache.hadoop.net.NetUtils;
/*     */ import org.apache.hadoop.security.SaslRpcServer;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.token.SecretManager;
/*     */ import org.apache.hadoop.security.token.TokenIdentifier;
/*     */ 
/*     */ public class RPC
/*     */ {
/*  70 */   private static final Log LOG = LogFactory.getLog(RPC.class);
/*     */ 
/* 200 */   private static ClientCache CLIENTS = new ClientCache(null);
/*     */ 
/*     */   static Client getClient(Configuration conf)
/*     */   {
/* 204 */     return CLIENTS.getClient(conf);
/*     */   }
/*     */ 
/*     */   public static VersionedProtocol waitForProxy(Class<? extends VersionedProtocol> protocol, long clientVersion, InetSocketAddress addr, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 300 */     return waitForProxy(protocol, clientVersion, addr, conf, 0, 9223372036854775807L);
/*     */   }
/*     */ 
/*     */   static VersionedProtocol waitForProxy(Class<? extends VersionedProtocol> protocol, long clientVersion, InetSocketAddress addr, Configuration conf, long connTimeout)
/*     */     throws IOException
/*     */   {
/* 320 */     return waitForProxy(protocol, clientVersion, addr, conf, 0, connTimeout);
/*     */   }
/*     */ 
/*     */   static VersionedProtocol waitForProxy(Class<? extends VersionedProtocol> protocol, long clientVersion, InetSocketAddress addr, Configuration conf, int rpcTimeout, long connTimeout)
/*     */     throws IOException
/*     */   {
/* 331 */     long startTime = System.currentTimeMillis();
/*     */     while (true) {
/*     */       IOException ioe;
/*     */       try {
/* 335 */         return getProxy(protocol, clientVersion, addr, conf, rpcTimeout);
/*     */       } catch (ConnectException se) {
/* 337 */         LOG.info("Server at " + addr + " not available yet, Zzzzz...");
/* 338 */         ioe = se;
/*     */       } catch (SocketTimeoutException te) {
/* 340 */         LOG.info("Problem connecting to server: " + addr);
/* 341 */         ioe = te;
/*     */       }
/*     */ 
/* 344 */       if (System.currentTimeMillis() - connTimeout >= startTime) {
/* 345 */         throw ioe;
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 350 */         Thread.sleep(1000L);
/*     */       }
/*     */       catch (InterruptedException ie)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static VersionedProtocol getProxy(Class<? extends VersionedProtocol> protocol, long clientVersion, InetSocketAddress addr, Configuration conf, SocketFactory factory)
/*     */     throws IOException
/*     */   {
/* 363 */     UserGroupInformation ugi = UserGroupInformation.getCurrentUser();
/* 364 */     return getProxy(protocol, clientVersion, addr, ugi, conf, factory, 0);
/*     */   }
/*     */ 
/*     */   public static VersionedProtocol getProxy(Class<? extends VersionedProtocol> protocol, long clientVersion, InetSocketAddress addr, Configuration conf, SocketFactory factory, int rpcTimeout)
/*     */     throws IOException
/*     */   {
/* 373 */     UserGroupInformation ugi = UserGroupInformation.getCurrentUser();
/* 374 */     return getProxy(protocol, clientVersion, addr, ugi, conf, factory, rpcTimeout);
/*     */   }
/*     */ 
/*     */   public static VersionedProtocol getProxy(Class<? extends VersionedProtocol> protocol, long clientVersion, InetSocketAddress addr, UserGroupInformation ticket, Configuration conf, SocketFactory factory)
/*     */     throws IOException
/*     */   {
/* 383 */     return getProxy(protocol, clientVersion, addr, ticket, conf, factory, 0);
/*     */   }
/*     */ 
/*     */   public static VersionedProtocol getProxy(Class<? extends VersionedProtocol> protocol, long clientVersion, InetSocketAddress addr, UserGroupInformation ticket, Configuration conf, SocketFactory factory, int rpcTimeout)
/*     */     throws IOException
/*     */   {
/* 392 */     return getProxy(protocol, clientVersion, addr, ticket, conf, factory, rpcTimeout, null, true);
/*     */   }
/*     */ 
/*     */   public static VersionedProtocol getProxy(Class<? extends VersionedProtocol> protocol, long clientVersion, InetSocketAddress addr, UserGroupInformation ticket, Configuration conf, SocketFactory factory, int rpcTimeout, RetryPolicy connectionRetryPolicy, boolean checkVersion)
/*     */     throws IOException
/*     */   {
/* 405 */     if (UserGroupInformation.isSecurityEnabled()) {
/* 406 */       SaslRpcServer.init(conf);
/*     */     }
/* 408 */     Invoker invoker = new Invoker(protocol, addr, ticket, conf, factory, rpcTimeout, connectionRetryPolicy, null);
/*     */ 
/* 410 */     VersionedProtocol proxy = (VersionedProtocol)Proxy.newProxyInstance(protocol.getClassLoader(), new Class[] { protocol }, invoker);
/*     */ 
/* 413 */     if (checkVersion) {
/* 414 */       checkVersion(protocol, clientVersion, proxy);
/*     */     }
/* 416 */     return proxy;
/*     */   }
/*     */ 
/*     */   public static void checkVersion(Class<? extends VersionedProtocol> protocol, long clientVersion, VersionedProtocol proxy)
/*     */     throws IOException
/*     */   {
/* 422 */     long serverVersion = proxy.getProtocolVersion(protocol.getName(), clientVersion);
/*     */ 
/* 424 */     if (serverVersion != clientVersion)
/* 425 */       throw new VersionMismatch(protocol.getName(), clientVersion, serverVersion);
/*     */   }
/*     */ 
/*     */   public static VersionedProtocol getProxy(Class<? extends VersionedProtocol> protocol, long clientVersion, InetSocketAddress addr, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 444 */     return getProxy(protocol, clientVersion, addr, conf, NetUtils.getDefaultSocketFactory(conf), 0);
/*     */   }
/*     */ 
/*     */   public static VersionedProtocol getProxy(Class<? extends VersionedProtocol> protocol, long clientVersion, InetSocketAddress addr, Configuration conf, int rpcTimeout)
/*     */     throws IOException
/*     */   {
/* 453 */     return getProxy(protocol, clientVersion, addr, conf, NetUtils.getDefaultSocketFactory(conf), rpcTimeout);
/*     */   }
/*     */ 
/*     */   public static void stopProxy(VersionedProtocol proxy)
/*     */   {
/* 462 */     if (proxy != null)
/* 463 */       ((Invoker)Proxy.getInvocationHandler(proxy)).close();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static Object[] call(Method method, Object[][] params, InetSocketAddress[] addrs, Configuration conf)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 474 */     return call(method, params, addrs, null, conf);
/*     */   }
/*     */ 
/*     */   public static Object[] call(Method method, Object[][] params, InetSocketAddress[] addrs, UserGroupInformation ticket, Configuration conf)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 483 */     Invocation[] invocations = new Invocation[params.length];
/* 484 */     for (int i = 0; i < params.length; i++)
/* 485 */       invocations[i] = new Invocation(method, params[i]);
/* 486 */     Client client = CLIENTS.getClient(conf);
/*     */     try {
/* 488 */       Writable[] wrappedValues = client.call(invocations, addrs, method.getDeclaringClass(), ticket, conf);
/*     */ 
/* 491 */       if (method.getReturnType() == Void.TYPE) {
/* 492 */         return null;
/*     */       }
/*     */ 
/* 495 */       Object[] values = (Object[])Array.newInstance(method.getReturnType(), wrappedValues.length);
/*     */ 
/* 497 */       for (int i = 0; i < values.length; i++) {
/* 498 */         if (wrappedValues[i] != null)
/* 499 */           values[i] = ((ObjectWritable)wrappedValues[i]).get();
/*     */       }
/* 501 */       return values;
/*     */     } finally {
/* 503 */       CLIENTS.stopClient(client);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Server getServer(Object instance, String bindAddress, int port, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 511 */     return getServer(instance, bindAddress, port, 1, false, conf);
/*     */   }
/*     */ 
/*     */   public static Server getServer(Object instance, String bindAddress, int port, int numHandlers, boolean verbose, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 520 */     return getServer(instance, bindAddress, port, numHandlers, verbose, conf, null);
/*     */   }
/*     */ 
/*     */   public static Server getServer(Object instance, String bindAddress, int port, int numHandlers, boolean verbose, Configuration conf, SecretManager<? extends TokenIdentifier> secretManager)
/*     */     throws IOException
/*     */   {
/* 530 */     return new Server(instance, conf, bindAddress, port, numHandlers, verbose, secretManager);
/*     */   }
/*     */ 
/*     */   private static void log(String value)
/*     */   {
/* 623 */     if ((value != null) && (value.length() > 55))
/* 624 */       value = value.substring(0, 55) + "...";
/* 625 */     LOG.info(value);
/*     */   }
/*     */ 
/*     */   public static class Server extends Server
/*     */   {
/*     */     private Object instance;
/*     */     private boolean verbose;
/*     */ 
/*     */     public Server(Object instance, Configuration conf, String bindAddress, int port)
/*     */       throws IOException
/*     */     {
/* 546 */       this(instance, conf, bindAddress, port, 1, false, null);
/*     */     }
/*     */ 
/*     */     private static String classNameBase(String className) {
/* 550 */       String[] names = className.split("\\.", -1);
/* 551 */       if ((names == null) || (names.length == 0)) {
/* 552 */         return className;
/*     */       }
/* 554 */       return names[(names.length - 1)];
/*     */     }
/*     */ 
/*     */     public Server(Object instance, Configuration conf, String bindAddress, int port, int numHandlers, boolean verbose, SecretManager<? extends TokenIdentifier> secretManager)
/*     */       throws IOException
/*     */     {
/* 569 */       super(port, RPC.Invocation.class, numHandlers, conf, classNameBase(instance.getClass().getName()), secretManager);
/*     */ 
/* 571 */       this.instance = instance;
/* 572 */       this.verbose = verbose;
/*     */     }
/*     */ 
/*     */     public Writable call(Class<?> protocol, Writable param, long receivedTime) throws IOException
/*     */     {
/*     */       try {
/* 578 */         RPC.Invocation call = (RPC.Invocation)param;
/* 579 */         if (this.verbose) RPC.log("Call: " + call);
/*     */ 
/* 581 */         Method method = protocol.getMethod(call.getMethodName(), call.getParameterClasses());
/*     */ 
/* 584 */         method.setAccessible(true);
/*     */ 
/* 586 */         long startTime = System.currentTimeMillis();
/* 587 */         Object value = method.invoke(this.instance, call.getParameters());
/* 588 */         int processingTime = (int)(System.currentTimeMillis() - startTime);
/* 589 */         int qTime = (int)(startTime - receivedTime);
/* 590 */         if (LOG.isDebugEnabled()) {
/* 591 */           LOG.debug("Served: " + call.getMethodName() + " queueTime= " + qTime + " procesingTime= " + processingTime);
/*     */         }
/*     */ 
/* 595 */         this.rpcMetrics.addRpcQueueTime(qTime);
/* 596 */         this.rpcMetrics.addRpcProcessingTime(processingTime);
/* 597 */         this.rpcMetrics.addRpcProcessingTime(call.getMethodName(), processingTime);
/* 598 */         if (this.verbose) RPC.log("Return: " + value);
/*     */ 
/* 600 */         return new ObjectWritable(method.getReturnType(), value);
/*     */       }
/*     */       catch (InvocationTargetException e) {
/* 603 */         Throwable target = e.getTargetException();
/* 604 */         if ((target instanceof IOException)) {
/* 605 */           throw ((IOException)target);
/*     */         }
/* 607 */         IOException ioe = new IOException(target.toString());
/* 608 */         ioe.setStackTrace(target.getStackTrace());
/* 609 */         throw ioe;
/*     */       }
/*     */       catch (Throwable e) {
/* 612 */         if (!(e instanceof IOException)) {
/* 613 */           LOG.error("Unexpected throwable object ", e);
/*     */         }
/* 615 */         IOException ioe = new IOException(e.toString());
/* 616 */         ioe.setStackTrace(e.getStackTrace());
/* 617 */         throw ioe;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class VersionMismatch extends IOException
/*     */   {
/*     */     private String interfaceName;
/*     */     private long clientVersion;
/*     */     private long serverVersion;
/*     */ 
/*     */     public VersionMismatch(String interfaceName, long clientVersion, long serverVersion)
/*     */     {
/* 263 */       super();
/*     */ 
/* 265 */       this.interfaceName = interfaceName;
/* 266 */       this.clientVersion = clientVersion;
/* 267 */       this.serverVersion = serverVersion;
/*     */     }
/*     */ 
/*     */     public String getInterfaceName()
/*     */     {
/* 276 */       return this.interfaceName;
/*     */     }
/*     */ 
/*     */     public long getClientVersion()
/*     */     {
/* 283 */       return this.clientVersion;
/*     */     }
/*     */ 
/*     */     public long getServerVersion()
/*     */     {
/* 290 */       return this.serverVersion;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class Invoker
/*     */     implements InvocationHandler
/*     */   {
/*     */     private Client.ConnectionId remoteId;
/*     */     private Client client;
/* 210 */     private boolean isClosed = false;
/*     */ 
/*     */     private Invoker(Class<? extends VersionedProtocol> protocol, InetSocketAddress address, UserGroupInformation ticket, Configuration conf, SocketFactory factory, int rpcTimeout, RetryPolicy connectionRetryPolicy)
/*     */       throws IOException
/*     */     {
/* 216 */       this.remoteId = Client.ConnectionId.getConnectionId(address, protocol, ticket, rpcTimeout, connectionRetryPolicy, conf);
/*     */ 
/* 218 */       this.client = RPC.ClientCache.access$300(RPC.CLIENTS, conf, factory);
/*     */     }
/*     */ 
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*     */     {
/* 223 */       boolean logDebug = RPC.LOG.isDebugEnabled();
/* 224 */       long startTime = 0L;
/* 225 */       if (logDebug) {
/* 226 */         startTime = System.currentTimeMillis();
/*     */       }
/*     */ 
/* 229 */       ObjectWritable value = (ObjectWritable)this.client.call(new RPC.Invocation(method, args), this.remoteId);
/*     */ 
/* 231 */       if (logDebug) {
/* 232 */         long callTime = System.currentTimeMillis() - startTime;
/* 233 */         RPC.LOG.debug("Call: " + method.getName() + " " + callTime);
/*     */       }
/* 235 */       return value.get();
/*     */     }
/*     */ 
/*     */     private synchronized void close()
/*     */     {
/* 240 */       if (!this.isClosed) {
/* 241 */         this.isClosed = true;
/* 242 */         RPC.ClientCache.access$500(RPC.CLIENTS, this.client);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ClientCache
/*     */   {
/* 145 */     private Map<SocketFactory, Client> clients = new HashMap();
/*     */ 
/*     */     private synchronized Client getClient(Configuration conf, SocketFactory factory)
/*     */     {
/* 162 */       Client client = (Client)this.clients.get(factory);
/* 163 */       if (client == null) {
/* 164 */         client = new Client(ObjectWritable.class, conf, factory);
/* 165 */         this.clients.put(factory, client);
/*     */       } else {
/* 167 */         client.incCount();
/*     */       }
/* 169 */       return client;
/*     */     }
/*     */ 
/*     */     private synchronized Client getClient(Configuration conf)
/*     */     {
/* 180 */       return getClient(conf, SocketFactory.getDefault());
/*     */     }
/*     */ 
/*     */     private void stopClient(Client client)
/*     */     {
/* 188 */       synchronized (this) {
/* 189 */         client.decCount();
/* 190 */         if (client.isZeroReference()) {
/* 191 */           this.clients.remove(client.getSocketFactory());
/*     */         }
/*     */       }
/* 194 */       if (client.isZeroReference())
/* 195 */         client.stop();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class Invocation
/*     */     implements Writable, Configurable
/*     */   {
/*     */     private String methodName;
/*     */     private Class[] parameterClasses;
/*     */     private Object[] parameters;
/*     */     private Configuration conf;
/*     */ 
/*     */     public Invocation()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Invocation(Method method, Object[] parameters)
/*     */     {
/*  86 */       this.methodName = method.getName();
/*  87 */       this.parameterClasses = method.getParameterTypes();
/*  88 */       this.parameters = parameters;
/*     */     }
/*     */ 
/*     */     public String getMethodName() {
/*  92 */       return this.methodName;
/*     */     }
/*     */     public Class[] getParameterClasses() {
/*  95 */       return this.parameterClasses;
/*     */     }
/*     */     public Object[] getParameters() {
/*  98 */       return this.parameters;
/*     */     }
/*     */     public void readFields(DataInput in) throws IOException {
/* 101 */       this.methodName = UTF8.readString(in);
/* 102 */       this.parameters = new Object[in.readInt()];
/* 103 */       this.parameterClasses = new Class[this.parameters.length];
/* 104 */       ObjectWritable objectWritable = new ObjectWritable();
/* 105 */       for (int i = 0; i < this.parameters.length; i++) {
/* 106 */         this.parameters[i] = ObjectWritable.readObject(in, objectWritable, this.conf);
/* 107 */         this.parameterClasses[i] = objectWritable.getDeclaredClass();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void write(DataOutput out) throws IOException {
/* 112 */       UTF8.writeString(out, this.methodName);
/* 113 */       out.writeInt(this.parameterClasses.length);
/* 114 */       for (int i = 0; i < this.parameterClasses.length; i++)
/* 115 */         ObjectWritable.writeObject(out, this.parameters[i], this.parameterClasses[i], this.conf);
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 121 */       StringBuffer buffer = new StringBuffer();
/* 122 */       buffer.append(this.methodName);
/* 123 */       buffer.append("(");
/* 124 */       for (int i = 0; i < this.parameters.length; i++) {
/* 125 */         if (i != 0)
/* 126 */           buffer.append(", ");
/* 127 */         buffer.append(this.parameters[i]);
/*     */       }
/* 129 */       buffer.append(")");
/* 130 */       return buffer.toString();
/*     */     }
/*     */ 
/*     */     public void setConf(Configuration conf) {
/* 134 */       this.conf = conf;
/*     */     }
/*     */ 
/*     */     public Configuration getConf() {
/* 138 */       return this.conf;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.ipc.RPC
 * JD-Core Version:    0.6.1
 */
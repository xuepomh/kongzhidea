/*    */ package org.apache.hadoop.ipc;
/*    */ 
/*    */  enum Status
/*    */ {
/* 24 */   SUCCESS(0), 
/* 25 */   ERROR(1), 
/* 26 */   FATAL(-1);
/*    */ 
/*    */   int state;
/*    */ 
/* 30 */   private Status(int state) { this.state = state; }
/*    */ 
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.ipc.Status
 * JD-Core Version:    0.6.1
 */
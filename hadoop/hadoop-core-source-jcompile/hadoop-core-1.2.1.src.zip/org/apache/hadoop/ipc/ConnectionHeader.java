/*     */ package org.apache.hadoop.ipc;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.io.Text;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.security.SaslRpcServer.AuthMethod;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ 
/*     */ class ConnectionHeader
/*     */   implements Writable
/*     */ {
/*  36 */   public static final Log LOG = LogFactory.getLog(ConnectionHeader.class);
/*     */   private String protocol;
/*  39 */   private UserGroupInformation ugi = null;
/*     */   private SaslRpcServer.AuthMethod authMethod;
/*     */ 
/*     */   public ConnectionHeader()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ConnectionHeader(String protocol, UserGroupInformation ugi, SaslRpcServer.AuthMethod authMethod)
/*     */   {
/*  53 */     this.protocol = protocol;
/*  54 */     this.ugi = ugi;
/*  55 */     this.authMethod = authMethod;
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException
/*     */   {
/*  60 */     this.protocol = Text.readString(in);
/*  61 */     if (this.protocol.isEmpty()) {
/*  62 */       this.protocol = null;
/*     */     }
/*     */ 
/*  65 */     boolean ugiUsernamePresent = in.readBoolean();
/*  66 */     if (ugiUsernamePresent) {
/*  67 */       String username = in.readUTF();
/*  68 */       boolean realUserNamePresent = in.readBoolean();
/*  69 */       if (realUserNamePresent) {
/*  70 */         String realUserName = in.readUTF();
/*  71 */         UserGroupInformation realUserUgi = UserGroupInformation.createRemoteUser(realUserName);
/*     */ 
/*  73 */         this.ugi = UserGroupInformation.createProxyUser(username, realUserUgi);
/*     */       } else {
/*  75 */         this.ugi = UserGroupInformation.createRemoteUser(username);
/*     */       }
/*     */     } else {
/*  78 */       this.ugi = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out) throws IOException
/*     */   {
/*  84 */     Text.writeString(out, this.protocol == null ? "" : this.protocol);
/*  85 */     if (this.ugi != null) {
/*  86 */       if (this.authMethod == SaslRpcServer.AuthMethod.KERBEROS)
/*     */       {
/*  88 */         out.writeBoolean(true);
/*  89 */         out.writeUTF(this.ugi.getUserName());
/*  90 */         out.writeBoolean(false);
/*  91 */       } else if (this.authMethod == SaslRpcServer.AuthMethod.DIGEST)
/*     */       {
/*  93 */         out.writeBoolean(false);
/*     */       }
/*     */       else {
/*  96 */         out.writeBoolean(true);
/*  97 */         out.writeUTF(this.ugi.getUserName());
/*  98 */         if (this.ugi.getRealUser() != null) {
/*  99 */           out.writeBoolean(true);
/* 100 */           out.writeUTF(this.ugi.getRealUser().getUserName());
/*     */         } else {
/* 102 */           out.writeBoolean(false);
/*     */         }
/*     */       }
/*     */     }
/* 106 */     else out.writeBoolean(false);
/*     */   }
/*     */ 
/*     */   public String getProtocol()
/*     */   {
/* 111 */     return this.protocol;
/*     */   }
/*     */ 
/*     */   public UserGroupInformation getUgi() {
/* 115 */     return this.ugi;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 119 */     return this.protocol + "-" + this.ugi;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.ipc.ConnectionHeader
 * JD-Core Version:    0.6.1
 */
/*      */ package org.apache.hadoop.ipc;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.net.BindException;
/*      */ import java.net.InetAddress;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.ServerSocket;
/*      */ import java.net.Socket;
/*      */ import java.net.SocketException;
/*      */ import java.net.UnknownHostException;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.channels.CancelledKeyException;
/*      */ import java.nio.channels.Channels;
/*      */ import java.nio.channels.ClosedChannelException;
/*      */ import java.nio.channels.ReadableByteChannel;
/*      */ import java.nio.channels.SelectionKey;
/*      */ import java.nio.channels.Selector;
/*      */ import java.nio.channels.ServerSocketChannel;
/*      */ import java.nio.channels.SocketChannel;
/*      */ import java.nio.channels.WritableByteChannel;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.BlockingQueue;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ExecutorService;
/*      */ import java.util.concurrent.Executors;
/*      */ import java.util.concurrent.LinkedBlockingQueue;
/*      */ import javax.security.sasl.Sasl;
/*      */ import javax.security.sasl.SaslException;
/*      */ import javax.security.sasl.SaslServer;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.apache.hadoop.conf.Configuration;
/*      */ import org.apache.hadoop.io.BytesWritable;
/*      */ import org.apache.hadoop.io.IntWritable;
/*      */ import org.apache.hadoop.io.Writable;
/*      */ import org.apache.hadoop.io.WritableUtils;
/*      */ import org.apache.hadoop.ipc.metrics.RpcInstrumentation;
/*      */ import org.apache.hadoop.security.AccessControlException;
/*      */ import org.apache.hadoop.security.SaslRpcServer;
/*      */ import org.apache.hadoop.security.SaslRpcServer.AuthMethod;
/*      */ import org.apache.hadoop.security.SaslRpcServer.SaslDigestCallbackHandler;
/*      */ import org.apache.hadoop.security.SaslRpcServer.SaslGssCallbackHandler;
/*      */ import org.apache.hadoop.security.SaslRpcServer.SaslStatus;
/*      */ import org.apache.hadoop.security.UserGroupInformation;
/*      */ import org.apache.hadoop.security.UserGroupInformation.AuthenticationMethod;
/*      */ import org.apache.hadoop.security.authorize.AuthorizationException;
/*      */ import org.apache.hadoop.security.authorize.ProxyUsers;
/*      */ import org.apache.hadoop.security.authorize.ServiceAuthorizationManager;
/*      */ import org.apache.hadoop.security.token.SecretManager;
/*      */ import org.apache.hadoop.security.token.SecretManager.InvalidToken;
/*      */ import org.apache.hadoop.security.token.TokenIdentifier;
/*      */ import org.apache.hadoop.util.ReflectionUtils;
/*      */ import org.apache.hadoop.util.StringUtils;
/*      */ 
/*      */ public abstract class Server
/*      */ {
/*      */   private final boolean authorize;
/*      */   private boolean isSecurityEnabled;
/*  100 */   private ExceptionsHandler exceptionsHandler = new ExceptionsHandler();
/*      */ 
/*  141 */   public static final ByteBuffer HEADER = ByteBuffer.wrap("hrpc".getBytes());
/*      */   public static final byte CURRENT_VERSION = 4;
/*      */   private static final int IPC_SERVER_HANDLER_QUEUE_SIZE_DEFAULT = 100;
/*      */   private static final String IPC_SERVER_HANDLER_QUEUE_SIZE_KEY = "ipc.server.handler.queue.size";
/*  158 */   static int INITIAL_RESP_BUF_SIZE = 10240;
/*      */   static final String IPC_SERVER_RPC_MAX_RESPONSE_SIZE_KEY = "ipc.server.max.response.size";
/*      */   static final int IPC_SERVER_RPC_MAX_RESPONSE_SIZE_DEFAULT = 1048576;
/*  163 */   public static final Log LOG = LogFactory.getLog(Server.class);
/*  164 */   private static final Log AUDITLOG = LogFactory.getLog("SecurityLogger." + Server.class.getName());
/*      */   private static final String AUTH_FAILED_FOR = "Auth failed for ";
/*      */   private static final String AUTH_SUCCESSFULL_FOR = "Auth successfull for ";
/*  169 */   private static final ThreadLocal<Server> SERVER = new ThreadLocal();
/*      */ 
/*  171 */   private static final Map<String, Class<?>> PROTOCOL_CACHE = new ConcurrentHashMap();
/*      */ 
/*  195 */   private static final ThreadLocal<Call> CurCall = new ThreadLocal();
/*      */   private String bindAddress;
/*      */   private int port;
/*      */   private int handlerCount;
/*      */   private int readThreads;
/*      */   private Class<? extends Writable> paramClass;
/*      */   private int maxIdleTime;
/*      */   private int thresholdIdleConnections;
/*      */   int maxConnectionsToNuke;
/*      */   protected RpcInstrumentation rpcMetrics;
/*      */   private Configuration conf;
/*      */   private SecretManager<TokenIdentifier> secretManager;
/*      */   private int maxQueueSize;
/*      */   private final int maxRespSize;
/*      */   private int socketSendBufferSize;
/*      */   private final boolean tcpNoDelay;
/*  240 */   private volatile boolean running = true;
/*      */   private BlockingQueue<Call> callQueue;
/*  243 */   private List<Connection> connectionList = Collections.synchronizedList(new LinkedList());
/*      */ 
/*  247 */   private Listener listener = null;
/*  248 */   private Responder responder = null;
/*  249 */   private int numConnections = 0;
/*  250 */   private Handler[] handlers = null;
/*      */ 
/* 1741 */   private static int NIO_BUFFER_LIMIT = 8192;
/*      */ 
/*      */   public void addTerseExceptions(Class<?>[] exceptionClass)
/*      */   {
/*  103 */     this.exceptionsHandler.addTerseExceptions(exceptionClass);
/*      */   }
/*      */ 
/*      */   static Class<?> getProtocolClass(String protocolName, Configuration conf)
/*      */     throws ClassNotFoundException
/*      */   {
/*  176 */     Class protocol = (Class)PROTOCOL_CACHE.get(protocolName);
/*  177 */     if (protocol == null) {
/*  178 */       protocol = conf.getClassByName(protocolName);
/*  179 */       PROTOCOL_CACHE.put(protocolName, protocol);
/*      */     }
/*  181 */     return protocol;
/*      */   }
/*      */ 
/*      */   public static Server get()
/*      */   {
/*  189 */     return (Server)SERVER.get();
/*      */   }
/*      */ 
/*      */   public static InetAddress getRemoteIp()
/*      */   {
/*  201 */     Call call = (Call)CurCall.get();
/*  202 */     if (call != null) {
/*  203 */       return Call.access$000(call).socket.getInetAddress();
/*      */     }
/*  205 */     return null;
/*      */   }
/*      */ 
/*      */   public static String getRemoteAddress()
/*      */   {
/*  211 */     InetAddress addr = getRemoteIp();
/*  212 */     return addr == null ? null : addr.getHostAddress();
/*      */   }
/*      */ 
/*      */   public static void bind(ServerSocket socket, InetSocketAddress address, int backlog)
/*      */     throws IOException
/*      */   {
/*      */     try
/*      */     {
/*  265 */       socket.bind(address, backlog);
/*      */     } catch (BindException e) {
/*  267 */       BindException bindException = new BindException("Problem binding to " + address + " : " + e.getMessage());
/*      */ 
/*  269 */       bindException.initCause(e);
/*  270 */       throw bindException;
/*      */     }
/*      */     catch (SocketException e)
/*      */     {
/*  274 */       if ("Unresolved address".equals(e.getMessage())) {
/*  275 */         throw new UnknownHostException("Invalid hostname for server: " + address.getHostName());
/*      */       }
/*      */ 
/*  278 */       throw e;
/*      */     }
/*      */   }
/*      */ 
/*      */   public RpcInstrumentation getRpcMetrics()
/*      */   {
/*  288 */     return this.rpcMetrics;
/*      */   }
/*      */ 
/*      */   protected Server(String bindAddress, int port, Class<? extends Writable> paramClass, int handlerCount, Configuration conf)
/*      */     throws IOException
/*      */   {
/* 1494 */     this(bindAddress, port, paramClass, handlerCount, conf, Integer.toString(port), null);
/*      */   }
/*      */ 
/*      */   protected Server(String bindAddress, int port, Class<? extends Writable> paramClass, int handlerCount, Configuration conf, String serverName)
/*      */     throws IOException
/*      */   {
/* 1502 */     this(bindAddress, port, paramClass, handlerCount, conf, serverName, null);
/*      */   }
/*      */ 
/*      */   protected Server(String bindAddress, int port, Class<? extends Writable> paramClass, int handlerCount, Configuration conf, String serverName, SecretManager<? extends TokenIdentifier> secretManager)
/*      */     throws IOException
/*      */   {
/* 1515 */     this.bindAddress = bindAddress;
/* 1516 */     this.conf = conf;
/* 1517 */     this.port = port;
/* 1518 */     this.paramClass = paramClass;
/* 1519 */     this.handlerCount = handlerCount;
/* 1520 */     this.socketSendBufferSize = 0;
/* 1521 */     this.maxQueueSize = (handlerCount * conf.getInt("ipc.server.handler.queue.size", 100));
/*      */ 
/* 1524 */     this.maxRespSize = conf.getInt("ipc.server.max.response.size", 1048576);
/*      */ 
/* 1526 */     this.readThreads = conf.getInt("ipc.server.read.threadpool.size", 1);
/*      */ 
/* 1529 */     this.callQueue = new LinkedBlockingQueue(this.maxQueueSize);
/* 1530 */     this.maxIdleTime = (2 * conf.getInt("ipc.client.connection.maxidletime", 1000));
/* 1531 */     this.maxConnectionsToNuke = conf.getInt("ipc.client.kill.max", 10);
/* 1532 */     this.thresholdIdleConnections = conf.getInt("ipc.client.idlethreshold", 4000);
/* 1533 */     this.secretManager = secretManager;
/* 1534 */     this.authorize = conf.getBoolean("hadoop.security.authorization", false);
/*      */ 
/* 1536 */     this.isSecurityEnabled = UserGroupInformation.isSecurityEnabled();
/*      */ 
/* 1539 */     this.listener = new Listener();
/* 1540 */     this.port = this.listener.getAddress().getPort();
/* 1541 */     this.rpcMetrics = RpcInstrumentation.create(serverName, this.port);
/* 1542 */     this.tcpNoDelay = conf.getBoolean("ipc.server.tcpnodelay", false);
/*      */ 
/* 1545 */     this.responder = new Responder();
/*      */ 
/* 1547 */     if (this.isSecurityEnabled)
/* 1548 */       SaslRpcServer.init(conf);
/*      */   }
/*      */ 
/*      */   private void closeConnection(Connection connection)
/*      */   {
/* 1553 */     synchronized (this.connectionList) {
/* 1554 */       if (this.connectionList.remove(connection))
/* 1555 */         this.numConnections -= 1;
/*      */     }
/*      */     try {
/* 1558 */       connection.close();
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   private void setupResponse(ByteArrayOutputStream response, Call call, Status status, Writable rv, String errorClass, String error)
/*      */     throws IOException
/*      */   {
/* 1578 */     response.reset();
/* 1579 */     DataOutputStream out = new DataOutputStream(response);
/* 1580 */     out.writeInt(call.id);
/* 1581 */     out.writeInt(status.state);
/*      */ 
/* 1583 */     if (status == Status.SUCCESS) {
/* 1584 */       rv.write(out);
/*      */     } else {
/* 1586 */       WritableUtils.writeString(out, errorClass);
/* 1587 */       WritableUtils.writeString(out, error);
/*      */     }
/* 1589 */     if (Call.access$000(call).useWrap) {
/* 1590 */       wrapWithSasl(response, call);
/*      */     }
/* 1592 */     call.setResponse(ByteBuffer.wrap(response.toByteArray()));
/*      */   }
/*      */ 
/*      */   private void wrapWithSasl(ByteArrayOutputStream response, Call call) throws IOException
/*      */   {
/* 1597 */     if (call.connection.useSasl) {
/* 1598 */       byte[] token = response.toByteArray();
/*      */ 
/* 1601 */       synchronized (call.connection.saslServer) {
/* 1602 */         token = call.connection.saslServer.wrap(token, 0, token.length);
/*      */       }
/* 1604 */       if (LOG.isDebugEnabled()) {
/* 1605 */         LOG.debug("Adding saslServer wrapped token of size " + token.length + " as call response.");
/*      */       }
/* 1607 */       response.reset();
/* 1608 */       DataOutputStream saslOut = new DataOutputStream(response);
/* 1609 */       saslOut.writeInt(token.length);
/* 1610 */       saslOut.write(token, 0, token.length);
/*      */     }
/*      */   }
/*      */ 
/*      */   Configuration getConf() {
/* 1615 */     return this.conf;
/*      */   }
/*      */ 
/*      */   void disableSecurity()
/*      */   {
/* 1620 */     this.isSecurityEnabled = false;
/*      */   }
/*      */ 
/*      */   void enableSecurity()
/*      */   {
/* 1625 */     this.isSecurityEnabled = true;
/*      */   }
/*      */ 
/*      */   public void setSocketSendBufSize(int size) {
/* 1629 */     this.socketSendBufferSize = size;
/*      */   }
/*      */ 
/*      */   public synchronized void start() {
/* 1633 */     this.responder.start();
/* 1634 */     this.listener.start();
/* 1635 */     this.handlers = new Handler[this.handlerCount];
/*      */ 
/* 1637 */     for (int i = 0; i < this.handlerCount; i++) {
/* 1638 */       this.handlers[i] = new Handler(i);
/* 1639 */       this.handlers[i].start();
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void stop()
/*      */   {
/* 1645 */     LOG.info("Stopping server on " + this.port);
/* 1646 */     this.running = false;
/* 1647 */     if (this.handlers != null) {
/* 1648 */       for (int i = 0; i < this.handlerCount; i++) {
/* 1649 */         if (this.handlers[i] != null) {
/* 1650 */           this.handlers[i].interrupt();
/*      */         }
/*      */       }
/*      */     }
/* 1654 */     this.listener.interrupt();
/* 1655 */     this.listener.doStop();
/* 1656 */     this.responder.interrupt();
/* 1657 */     notifyAll();
/* 1658 */     if (this.rpcMetrics != null)
/* 1659 */       this.rpcMetrics.shutdown();
/*      */   }
/*      */ 
/*      */   public synchronized void join()
/*      */     throws InterruptedException
/*      */   {
/* 1668 */     while (this.running)
/* 1669 */       wait();
/*      */   }
/*      */ 
/*      */   public synchronized InetSocketAddress getListenerAddress()
/*      */   {
/* 1678 */     return this.listener.getAddress();
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public Writable call(Writable param, long receiveTime)
/*      */     throws IOException
/*      */   {
/* 1687 */     return call(null, param, receiveTime);
/*      */   }
/*      */ 
/*      */   public abstract Writable call(Class<?> paramClass1, Writable paramWritable, long paramLong)
/*      */     throws IOException;
/*      */ 
/*      */   public void authorize(UserGroupInformation user, ConnectionHeader connection, InetAddress addr)
/*      */     throws AuthorizationException
/*      */   {
/* 1707 */     if (this.authorize) {
/* 1708 */       Class protocol = null;
/*      */       try {
/* 1710 */         protocol = getProtocolClass(connection.getProtocol(), getConf());
/*      */       } catch (ClassNotFoundException cfne) {
/* 1712 */         throw new AuthorizationException("Unknown protocol: " + connection.getProtocol());
/*      */       }
/*      */ 
/* 1715 */       ServiceAuthorizationManager.authorize(user, protocol, getConf(), addr);
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getNumOpenConnections()
/*      */   {
/* 1724 */     return this.numConnections;
/*      */   }
/*      */ 
/*      */   public int getCallQueueLen()
/*      */   {
/* 1732 */     return this.callQueue.size();
/*      */   }
/*      */ 
/*      */   private int channelWrite(WritableByteChannel channel, ByteBuffer buffer)
/*      */     throws IOException
/*      */   {
/* 1756 */     int count = buffer.remaining() <= NIO_BUFFER_LIMIT ? channel.write(buffer) : channelIO(null, channel, buffer);
/*      */ 
/* 1758 */     if (count > 0) {
/* 1759 */       this.rpcMetrics.incrSentBytes(count);
/*      */     }
/* 1761 */     return count;
/*      */   }
/*      */ 
/*      */   private int channelRead(ReadableByteChannel channel, ByteBuffer buffer)
/*      */     throws IOException
/*      */   {
/* 1776 */     int count = buffer.remaining() <= NIO_BUFFER_LIMIT ? channel.read(buffer) : channelIO(channel, null, buffer);
/*      */ 
/* 1778 */     if (count > 0) {
/* 1779 */       this.rpcMetrics.incrReceivedBytes(count);
/*      */     }
/* 1781 */     return count;
/*      */   }
/*      */ 
/*      */   private static int channelIO(ReadableByteChannel readCh, WritableByteChannel writeCh, ByteBuffer buf)
/*      */     throws IOException
/*      */   {
/* 1796 */     int originalLimit = buf.limit();
/* 1797 */     int initialRemaining = buf.remaining();
/* 1798 */     int ret = 0;
/*      */ 
/* 1800 */     while (buf.remaining() > 0) {
/*      */       try {
/* 1802 */         int ioSize = Math.min(buf.remaining(), NIO_BUFFER_LIMIT);
/* 1803 */         buf.limit(buf.position() + ioSize);
/*      */ 
/* 1805 */         ret = readCh == null ? writeCh.write(buf) : readCh.read(buf);
/*      */ 
/* 1807 */         if (ret < ioSize)
/*      */         {
/* 1812 */           buf.limit(originalLimit); break; }  } finally { buf.limit(originalLimit); }
/*      */ 
/*      */     }
/*      */ 
/* 1816 */     int nBytes = initialRemaining - buf.remaining();
/* 1817 */     return nBytes > 0 ? nBytes : ret;
/*      */   }
/*      */ 
/*      */   private class Handler extends Thread
/*      */   {
/*      */     public Handler(int instanceNumber)
/*      */     {
/* 1396 */       setDaemon(true);
/* 1397 */       setName("IPC Server handler " + instanceNumber + " on " + Server.this.port);
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/* 1402 */       Server.LOG.info(getName() + ": starting");
/* 1403 */       Server.SERVER.set(Server.this);
/* 1404 */       ByteArrayOutputStream buf = new ByteArrayOutputStream(Server.INITIAL_RESP_BUF_SIZE);
/*      */ 
/* 1406 */       while (Server.this.running) {
/*      */         try {
/* 1408 */           final Server.Call call = (Server.Call)Server.this.callQueue.take();
/*      */ 
/* 1410 */           if (Server.LOG.isDebugEnabled()) {
/* 1411 */             Server.LOG.debug(getName() + ": has #" + Server.Call.access$1800(call) + " from " + Server.Call.access$000(call));
/*      */           }
/*      */ 
/* 1414 */           String errorClass = null;
/* 1415 */           String error = null;
/* 1416 */           Writable value = null;
/*      */ 
/* 1418 */           Server.CurCall.set(call);
/*      */           try
/*      */           {
/* 1422 */             if (Server.Call.access$000(call).user == null) {
/* 1423 */               value = Server.this.call(Server.Call.access$000(call).protocol, Server.Call.access$3200(call), Server.Call.access$1700(call));
/*      */             }
/*      */             else {
/* 1426 */               value = (Writable)Server.Call.access$000(call).user.doAs(new PrivilegedExceptionAction()
/*      */               {
/*      */                 public Writable run()
/*      */                   throws Exception
/*      */                 {
/* 1432 */                   return Server.this.call(Server.Call.access$000(call).protocol, Server.Call.access$3200(call), Server.Call.access$1700(call));
/*      */                 }
/*      */               });
/*      */             }
/*      */ 
/*      */           }
/*      */           catch (Throwable e)
/*      */           {
/* 1440 */             String logMsg = getName() + ", call " + call + ": error: " + e;
/* 1441 */             if (((e instanceof RuntimeException)) || ((e instanceof Error)))
/*      */             {
/* 1445 */               Server.LOG.warn(logMsg, e);
/* 1446 */             } else if (Server.this.exceptionsHandler.isTerse(e.getClass()))
/*      */             {
/* 1449 */               Server.LOG.info(logMsg);
/*      */             }
/* 1451 */             else Server.LOG.info(logMsg, e);
/*      */ 
/* 1453 */             errorClass = e.getClass().getName();
/* 1454 */             error = StringUtils.stringifyException(e);
/*      */           }
/* 1456 */           Server.CurCall.set(null);
/* 1457 */           synchronized (Server.Connection.access$1600(Server.Call.access$000(call)))
/*      */           {
/* 1462 */             Server.this.setupResponse(buf, call, error == null ? Status.SUCCESS : Status.ERROR, value, errorClass, error);
/*      */ 
/* 1467 */             if (buf.size() > Server.this.maxRespSize) {
/* 1468 */               Server.LOG.warn("Large response size " + buf.size() + " for call " + call.toString());
/*      */ 
/* 1470 */               buf = new ByteArrayOutputStream(Server.INITIAL_RESP_BUF_SIZE);
/*      */             }
/* 1472 */             Server.this.responder.doRespond(call);
/*      */           }
/*      */         } catch (InterruptedException e) {
/* 1475 */           if (Server.this.running)
/* 1476 */             Server.LOG.info(getName() + " caught: " + StringUtils.stringifyException(e));
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/* 1480 */           Server.LOG.info(getName() + " caught: " + StringUtils.stringifyException(e));
/*      */         }
/*      */       }
/*      */ 
/* 1484 */       Server.LOG.info(getName() + ": exiting");
/*      */     }
/*      */   }
/*      */ 
/*      */   public class Connection
/*      */   {
/*  867 */     private boolean rpcHeaderRead = false;
/*  868 */     private boolean headerRead = false;
/*      */     private SocketChannel channel;
/*      */     private ByteBuffer data;
/*      */     private ByteBuffer dataLengthBuffer;
/*      */     private LinkedList<Server.Call> responseQueue;
/*  875 */     private volatile int rpcCount = 0;
/*      */     private long lastContact;
/*      */     private int dataLength;
/*      */     private Socket socket;
/*      */     private String hostAddress;
/*      */     private int remotePort;
/*      */     private InetAddress addr;
/*  885 */     ConnectionHeader header = new ConnectionHeader();
/*      */     Class<?> protocol;
/*      */     boolean useSasl;
/*      */     SaslServer saslServer;
/*      */     private SaslRpcServer.AuthMethod authMethod;
/*      */     private boolean saslContextEstablished;
/*      */     private boolean skipInitialSaslHandshake;
/*      */     private ByteBuffer rpcHeaderBuffer;
/*      */     private ByteBuffer unwrappedData;
/*      */     private ByteBuffer unwrappedDataLengthBuffer;
/*  896 */     UserGroupInformation user = null;
/*  897 */     public UserGroupInformation attemptingUser = null;
/*      */ 
/*  900 */     private final int AUTHROIZATION_FAILED_CALLID = -1;
/*  901 */     private final Server.Call authFailedCall = new Server.Call(-1, null, this);
/*      */ 
/*  903 */     private ByteArrayOutputStream authFailedResponse = new ByteArrayOutputStream();
/*      */     private static final int SASL_CALLID = -33;
/*  906 */     private final Server.Call saslCall = new Server.Call(-33, null, this);
/*  907 */     private final ByteArrayOutputStream saslResponse = new ByteArrayOutputStream();
/*      */ 
/*  909 */     private boolean useWrap = false;
/*      */ 
/*      */     public Connection(SelectionKey key, SocketChannel channel, long lastContact)
/*      */     {
/*  913 */       this.channel = channel;
/*  914 */       this.lastContact = lastContact;
/*  915 */       this.data = null;
/*  916 */       this.dataLengthBuffer = ByteBuffer.allocate(4);
/*  917 */       this.unwrappedData = null;
/*  918 */       this.unwrappedDataLengthBuffer = ByteBuffer.allocate(4);
/*  919 */       this.socket = channel.socket();
/*  920 */       this.addr = this.socket.getInetAddress();
/*  921 */       if (this.addr == null)
/*  922 */         this.hostAddress = "*Unknown*";
/*      */       else {
/*  924 */         this.hostAddress = this.addr.getHostAddress();
/*      */       }
/*  926 */       this.remotePort = this.socket.getPort();
/*  927 */       this.responseQueue = new LinkedList();
/*  928 */       if (Server.this.socketSendBufferSize != 0)
/*      */         try {
/*  930 */           this.socket.setSendBufferSize(Server.this.socketSendBufferSize);
/*      */         } catch (IOException e) {
/*  932 */           Server.LOG.warn("Connection: unable to set socket send buffer size to " + Server.this.socketSendBufferSize);
/*      */         }
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/*  940 */       return getHostAddress() + ":" + this.remotePort;
/*      */     }
/*      */ 
/*      */     public String getHostAddress() {
/*  944 */       return this.hostAddress;
/*      */     }
/*      */ 
/*      */     public InetAddress getHostInetAddress() {
/*  948 */       return this.addr;
/*      */     }
/*      */ 
/*      */     public void setLastContact(long lastContact) {
/*  952 */       this.lastContact = lastContact;
/*      */     }
/*      */ 
/*      */     public long getLastContact() {
/*  956 */       return this.lastContact;
/*      */     }
/*      */ 
/*      */     private boolean isIdle()
/*      */     {
/*  961 */       return this.rpcCount == 0;
/*      */     }
/*      */ 
/*      */     private void decRpcCount()
/*      */     {
/*  966 */       this.rpcCount -= 1;
/*      */     }
/*      */ 
/*      */     private void incRpcCount()
/*      */     {
/*  971 */       this.rpcCount += 1;
/*      */     }
/*      */ 
/*      */     private boolean timedOut(long currentTime) {
/*  975 */       if ((isIdle()) && (currentTime - this.lastContact > Server.this.maxIdleTime))
/*  976 */         return true;
/*  977 */       return false;
/*      */     }
/*      */ 
/*      */     private UserGroupInformation getAuthorizedUgi(String authorizedId) throws IOException
/*      */     {
/*  982 */       if (this.authMethod == SaslRpcServer.AuthMethod.DIGEST) {
/*  983 */         TokenIdentifier tokenId = SaslRpcServer.getIdentifier(authorizedId, Server.this.secretManager);
/*      */ 
/*  985 */         UserGroupInformation ugi = tokenId.getUser();
/*  986 */         if (ugi == null) {
/*  987 */           throw new AccessControlException("Can't retrieve username from tokenIdentifier.");
/*      */         }
/*      */ 
/*  990 */         ugi.addTokenIdentifier(tokenId);
/*  991 */         return ugi;
/*      */       }
/*  993 */       return UserGroupInformation.createRemoteUser(authorizedId);
/*      */     }
/*      */ 
/*      */     private void saslReadAndProcess(byte[] saslToken)
/*      */       throws IOException, InterruptedException
/*      */     {
/*  999 */       if (!this.saslContextEstablished) {
/* 1000 */         byte[] replyToken = null;
/*      */         try {
/* 1002 */           if (this.saslServer == null) {
/* 1003 */             switch (Server.1.$SwitchMap$org$apache$hadoop$security$SaslRpcServer$AuthMethod[this.authMethod.ordinal()]) {
/*      */             case 1:
/* 1005 */               if (Server.this.secretManager == null) {
/* 1006 */                 throw new AccessControlException("Server is not configured to do DIGEST authentication.");
/*      */               }
/*      */ 
/* 1009 */               this.saslServer = Sasl.createSaslServer(SaslRpcServer.AuthMethod.DIGEST.getMechanismName(), null, "default", SaslRpcServer.SASL_PROPS, new SaslRpcServer.SaslDigestCallbackHandler(Server.this.secretManager, this));
/*      */ 
/* 1013 */               break;
/*      */             default:
/* 1015 */               UserGroupInformation current = UserGroupInformation.getCurrentUser();
/*      */ 
/* 1017 */               String fullName = current.getUserName();
/* 1018 */               if (Server.LOG.isDebugEnabled())
/* 1019 */                 Server.LOG.debug("Kerberos principal name is " + fullName);
/* 1020 */               final String[] names = SaslRpcServer.splitKerberosName(fullName);
/* 1021 */               if (names.length != 3) {
/* 1022 */                 throw new AccessControlException("Kerberos principal name does NOT have the expected hostname part: " + fullName);
/*      */               }
/*      */ 
/* 1026 */               current.doAs(new PrivilegedExceptionAction()
/*      */               {
/*      */                 public Object run() throws SaslException {
/* 1029 */                   Server.Connection.this.saslServer = Sasl.createSaslServer(SaslRpcServer.AuthMethod.KERBEROS.getMechanismName(), names[0], names[1], SaslRpcServer.SASL_PROPS, new SaslRpcServer.SaslGssCallbackHandler());
/*      */ 
/* 1032 */                   return null;
/*      */                 }
/*      */               });
/*      */             }
/* 1036 */             if (this.saslServer == null) {
/* 1037 */               throw new AccessControlException("Unable to find SASL server implementation for " + this.authMethod.getMechanismName());
/*      */             }
/*      */ 
/* 1040 */             if (Server.LOG.isDebugEnabled()) {
/* 1041 */               Server.LOG.debug("Created SASL server with mechanism = " + this.authMethod.getMechanismName());
/*      */             }
/*      */           }
/* 1044 */           if (Server.LOG.isDebugEnabled()) {
/* 1045 */             Server.LOG.debug("Have read input token of size " + saslToken.length + " for processing by saslServer.evaluateResponse()");
/*      */           }
/* 1047 */           replyToken = this.saslServer.evaluateResponse(saslToken);
/*      */         } catch (IOException e) {
/* 1049 */           IOException sendToClient = e;
/* 1050 */           Throwable cause = e;
/* 1051 */           while (cause != null) {
/* 1052 */             if ((cause instanceof SecretManager.InvalidToken)) {
/* 1053 */               sendToClient = (SecretManager.InvalidToken)cause;
/* 1054 */               break;
/*      */             }
/* 1056 */             cause = cause.getCause();
/*      */           }
/* 1058 */           doSaslReply(SaslRpcServer.SaslStatus.ERROR, null, sendToClient.getClass().getName(), sendToClient.getLocalizedMessage());
/*      */ 
/* 1060 */           Server.this.rpcMetrics.incrAuthenticationFailures();
/* 1061 */           String clientIP = toString();
/*      */ 
/* 1063 */           Server.AUDITLOG.warn("Auth failed for " + clientIP + ":" + this.attemptingUser);
/* 1064 */           throw e;
/*      */         }
/* 1066 */         if (replyToken != null) {
/* 1067 */           if (Server.LOG.isDebugEnabled()) {
/* 1068 */             Server.LOG.debug("Will send token of size " + replyToken.length + " from saslServer.");
/*      */           }
/* 1070 */           doSaslReply(SaslRpcServer.SaslStatus.SUCCESS, new BytesWritable(replyToken), null, null);
/*      */         }
/*      */ 
/* 1073 */         if (this.saslServer.isComplete()) {
/* 1074 */           if (Server.LOG.isDebugEnabled()) {
/* 1075 */             Server.LOG.debug("SASL server context established. Negotiated QoP is " + this.saslServer.getNegotiatedProperty("javax.security.sasl.qop"));
/*      */           }
/*      */ 
/* 1078 */           String qop = (String)this.saslServer.getNegotiatedProperty("javax.security.sasl.qop");
/* 1079 */           this.useWrap = ((qop != null) && (!"auth".equalsIgnoreCase(qop)));
/* 1080 */           this.user = getAuthorizedUgi(this.saslServer.getAuthorizationID());
/* 1081 */           if (Server.LOG.isDebugEnabled()) {
/* 1082 */             Server.LOG.debug("SASL server successfully authenticated client: " + this.user);
/*      */           }
/* 1084 */           Server.this.rpcMetrics.incrAuthenticationSuccesses();
/* 1085 */           Server.AUDITLOG.info("Auth successfull for " + this.user);
/* 1086 */           this.saslContextEstablished = true;
/*      */         }
/*      */       } else {
/* 1089 */         if (Server.LOG.isDebugEnabled()) {
/* 1090 */           Server.LOG.debug("Have read input token of size " + saslToken.length + " for processing by saslServer.unwrap()");
/*      */         }
/*      */ 
/* 1093 */         if (!this.useWrap) {
/* 1094 */           processOneRpc(saslToken);
/*      */         } else {
/* 1096 */           byte[] plaintextData = this.saslServer.unwrap(saslToken, 0, saslToken.length);
/*      */ 
/* 1098 */           processUnwrappedData(plaintextData);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     private void doSaslReply(SaslRpcServer.SaslStatus status, Writable rv, String errorClass, String error) throws IOException
/*      */     {
/* 1105 */       this.saslResponse.reset();
/* 1106 */       DataOutputStream out = new DataOutputStream(this.saslResponse);
/* 1107 */       out.writeInt(status.state);
/* 1108 */       if (status == SaslRpcServer.SaslStatus.SUCCESS) {
/* 1109 */         rv.write(out);
/*      */       } else {
/* 1111 */         WritableUtils.writeString(out, errorClass);
/* 1112 */         WritableUtils.writeString(out, error);
/*      */       }
/* 1114 */       this.saslCall.setResponse(ByteBuffer.wrap(this.saslResponse.toByteArray()));
/* 1115 */       Server.this.responder.doRespond(this.saslCall);
/*      */     }
/*      */ 
/*      */     private void disposeSasl() {
/* 1119 */       if (this.saslServer != null)
/*      */         try {
/* 1121 */           this.saslServer.dispose();
/*      */         } catch (SaslException ignored) {
/*      */         }
/*      */     }
/*      */ 
/*      */     public int readAndProcess() throws IOException, InterruptedException {
/*      */       int count;
/*      */       boolean isHeaderRead;
/*      */       do {
/*      */         while (true) {
/* 1132 */           count = -1;
/* 1133 */           if (this.dataLengthBuffer.remaining() > 0) {
/* 1134 */             count = Server.this.channelRead(this.channel, this.dataLengthBuffer);
/* 1135 */             if ((count < 0) || (this.dataLengthBuffer.remaining() > 0)) {
/* 1136 */               return count;
/*      */             }
/*      */           }
/* 1139 */           if (!this.rpcHeaderRead)
/*      */           {
/* 1141 */             if (this.rpcHeaderBuffer == null) {
/* 1142 */               this.rpcHeaderBuffer = ByteBuffer.allocate(2);
/*      */             }
/* 1144 */             count = Server.this.channelRead(this.channel, this.rpcHeaderBuffer);
/* 1145 */             if ((count < 0) || (this.rpcHeaderBuffer.remaining() > 0)) {
/* 1146 */               return count;
/*      */             }
/* 1148 */             int version = this.rpcHeaderBuffer.get(0);
/* 1149 */             byte[] method = { this.rpcHeaderBuffer.get(1) };
/* 1150 */             this.authMethod = SaslRpcServer.AuthMethod.read(new DataInputStream(new ByteArrayInputStream(method)));
/*      */ 
/* 1152 */             this.dataLengthBuffer.flip();
/* 1153 */             if ((!Server.HEADER.equals(this.dataLengthBuffer)) || (version != 4))
/*      */             {
/* 1155 */               Server.LOG.warn("Incorrect header or version mismatch from " + this.hostAddress + ":" + this.remotePort + " got version " + version + " expected version " + 4);
/*      */ 
/* 1159 */               return -1;
/*      */             }
/* 1161 */             this.dataLengthBuffer.clear();
/* 1162 */             if (this.authMethod == null) {
/* 1163 */               throw new IOException("Unable to read authentication method");
/*      */             }
/* 1165 */             if ((Server.this.isSecurityEnabled) && (this.authMethod == SaslRpcServer.AuthMethod.SIMPLE)) {
/* 1166 */               AccessControlException ae = new AccessControlException("Authorization (hadoop.security.authorization) is enabled but authentication (hadoop.security.authentication) is configured as simple. Please configure another method like kerberos or digest.");
/*      */ 
/* 1172 */               Server.this.setupResponse(this.authFailedResponse, this.authFailedCall, Status.FATAL, null, ae.getClass().getName(), ae.getMessage());
/*      */ 
/* 1174 */               Server.this.responder.doRespond(this.authFailedCall);
/* 1175 */               throw ae;
/*      */             }
/* 1177 */             if ((!Server.this.isSecurityEnabled) && (this.authMethod != SaslRpcServer.AuthMethod.SIMPLE)) {
/* 1178 */               doSaslReply(SaslRpcServer.SaslStatus.SUCCESS, new IntWritable(-88), null, null);
/*      */ 
/* 1180 */               this.authMethod = SaslRpcServer.AuthMethod.SIMPLE;
/*      */ 
/* 1184 */               this.skipInitialSaslHandshake = true;
/*      */             }
/* 1186 */             if (this.authMethod != SaslRpcServer.AuthMethod.SIMPLE) {
/* 1187 */               this.useSasl = true;
/*      */             }
/*      */ 
/* 1190 */             this.rpcHeaderBuffer = null;
/* 1191 */             this.rpcHeaderRead = true;
/*      */           }
/*      */           else
/*      */           {
/* 1195 */             if (this.data == null) {
/* 1196 */               this.dataLengthBuffer.flip();
/* 1197 */               this.dataLength = this.dataLengthBuffer.getInt();
/*      */ 
/* 1199 */               if ((this.dataLength == -1) && 
/* 1200 */                 (!this.useWrap)) {
/* 1201 */                 this.dataLengthBuffer.clear();
/* 1202 */                 return 0;
/*      */               }
/*      */ 
/* 1205 */               if (this.dataLength < 0) {
/* 1206 */                 Server.LOG.warn("Unexpected data length " + this.dataLength + "!! from " + getHostAddress());
/*      */               }
/*      */ 
/* 1209 */               this.data = ByteBuffer.allocate(this.dataLength);
/*      */             }
/*      */ 
/* 1212 */             count = Server.this.channelRead(this.channel, this.data);
/*      */ 
/* 1214 */             if (this.data.remaining() != 0) break label637;
/* 1215 */             this.dataLengthBuffer.clear();
/* 1216 */             this.data.flip();
/* 1217 */             if (!this.skipInitialSaslHandshake) break;
/* 1218 */             this.data = null;
/* 1219 */             this.skipInitialSaslHandshake = false;
/*      */           }
/*      */         }
/* 1222 */         isHeaderRead = this.headerRead;
/* 1223 */         if (this.useSasl)
/* 1224 */           saslReadAndProcess(this.data.array());
/*      */         else {
/* 1226 */           processOneRpc(this.data.array());
/*      */         }
/* 1228 */         this.data = null;
/* 1229 */       }while (!isHeaderRead);
/*      */ 
/* 1233 */       label637: return count;
/*      */     }
/*      */ 
/*      */     private void processHeader(byte[] buf)
/*      */       throws IOException
/*      */     {
/* 1239 */       DataInputStream in = new DataInputStream(new ByteArrayInputStream(buf));
/*      */ 
/* 1241 */       this.header.readFields(in);
/*      */       try {
/* 1243 */         String protocolClassName = this.header.getProtocol();
/* 1244 */         if (protocolClassName != null)
/* 1245 */           this.protocol = Server.getProtocolClass(this.header.getProtocol(), Server.this.conf);
/*      */       }
/*      */       catch (ClassNotFoundException cnfe) {
/* 1248 */         throw new IOException("Unknown protocol: " + this.header.getProtocol());
/*      */       }
/*      */ 
/* 1251 */       UserGroupInformation protocolUser = this.header.getUgi();
/* 1252 */       if (!this.useSasl) {
/* 1253 */         this.user = protocolUser;
/* 1254 */         if (this.user != null)
/* 1255 */           this.user.setAuthenticationMethod(SaslRpcServer.AuthMethod.SIMPLE.authenticationMethod);
/*      */       }
/*      */       else
/*      */       {
/* 1259 */         this.user.setAuthenticationMethod(this.authMethod.authenticationMethod);
/*      */ 
/* 1263 */         if ((protocolUser != null) && (!protocolUser.getUserName().equals(this.user.getUserName())))
/*      */         {
/* 1265 */           if (this.authMethod == SaslRpcServer.AuthMethod.DIGEST)
/*      */           {
/* 1267 */             throw new AccessControlException("Authenticated user (" + this.user + ") doesn't match what the client claims to be (" + protocolUser + ")");
/*      */           }
/*      */ 
/* 1274 */           UserGroupInformation realUser = this.user;
/* 1275 */           this.user = UserGroupInformation.createProxyUser(protocolUser.getUserName(), realUser);
/*      */ 
/* 1278 */           this.user.setAuthenticationMethod(UserGroupInformation.AuthenticationMethod.PROXY);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     private void processUnwrappedData(byte[] inBuf)
/*      */       throws IOException, InterruptedException
/*      */     {
/* 1286 */       ReadableByteChannel ch = Channels.newChannel(new ByteArrayInputStream(inBuf));
/*      */       while (true)
/*      */       {
/* 1290 */         int count = -1;
/* 1291 */         if (this.unwrappedDataLengthBuffer.remaining() > 0) {
/* 1292 */           count = Server.this.channelRead(ch, this.unwrappedDataLengthBuffer);
/* 1293 */           if ((count <= 0) || (this.unwrappedDataLengthBuffer.remaining() > 0)) {
/* 1294 */             return;
/*      */           }
/*      */         }
/* 1297 */         if (this.unwrappedData == null) {
/* 1298 */           this.unwrappedDataLengthBuffer.flip();
/* 1299 */           int unwrappedDataLength = this.unwrappedDataLengthBuffer.getInt();
/*      */ 
/* 1301 */           if (unwrappedDataLength == -1) {
/* 1302 */             if (Server.LOG.isDebugEnabled())
/* 1303 */               Server.LOG.debug("Received ping message");
/* 1304 */             this.unwrappedDataLengthBuffer.clear();
/*      */           }
/*      */           else {
/* 1307 */             this.unwrappedData = ByteBuffer.allocate(unwrappedDataLength);
/*      */           }
/*      */         } else {
/* 1310 */           count = Server.this.channelRead(ch, this.unwrappedData);
/* 1311 */           if ((count <= 0) || (this.unwrappedData.remaining() > 0)) {
/* 1312 */             return;
/*      */           }
/* 1314 */           if (this.unwrappedData.remaining() == 0) {
/* 1315 */             this.unwrappedDataLengthBuffer.clear();
/* 1316 */             this.unwrappedData.flip();
/* 1317 */             processOneRpc(this.unwrappedData.array());
/* 1318 */             this.unwrappedData = null;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     private void processOneRpc(byte[] buf) throws IOException, InterruptedException {
/* 1325 */       if (this.headerRead) {
/* 1326 */         processData(buf);
/*      */       } else {
/* 1328 */         processHeader(buf);
/* 1329 */         this.headerRead = true;
/* 1330 */         if (!authorizeConnection())
/* 1331 */           throw new AccessControlException("Connection from " + this + " for protocol " + this.header.getProtocol() + " is unauthorized for user " + this.user);
/*      */       }
/*      */     }
/*      */ 
/*      */     private void processData(byte[] buf)
/*      */       throws IOException, InterruptedException
/*      */     {
/* 1339 */       DataInputStream dis = new DataInputStream(new ByteArrayInputStream(buf));
/*      */ 
/* 1341 */       int id = dis.readInt();
/*      */ 
/* 1343 */       if (Server.LOG.isDebugEnabled()) {
/* 1344 */         Server.LOG.debug(" got #" + id);
/*      */       }
/* 1346 */       Writable param = (Writable)ReflectionUtils.newInstance(Server.this.paramClass, Server.this.conf);
/* 1347 */       param.readFields(dis);
/*      */ 
/* 1349 */       Server.Call call = new Server.Call(id, param, this);
/* 1350 */       Server.this.callQueue.put(call);
/* 1351 */       incRpcCount();
/*      */     }
/*      */ 
/*      */     private boolean authorizeConnection()
/*      */       throws IOException
/*      */     {
/*      */       try
/*      */       {
/* 1360 */         if ((this.user != null) && (this.user.getRealUser() != null) && (this.authMethod != SaslRpcServer.AuthMethod.DIGEST))
/*      */         {
/* 1362 */           ProxyUsers.authorize(this.user, getHostAddress(), Server.this.conf);
/*      */         }
/* 1364 */         Server.this.authorize(this.user, this.header, getHostInetAddress());
/* 1365 */         if (Server.LOG.isDebugEnabled()) {
/* 1366 */           Server.LOG.debug("Successfully authorized " + this.header);
/*      */         }
/* 1368 */         Server.this.rpcMetrics.incrAuthorizationSuccesses();
/*      */       } catch (AuthorizationException ae) {
/* 1370 */         Server.this.rpcMetrics.incrAuthorizationFailures();
/* 1371 */         Server.this.setupResponse(this.authFailedResponse, this.authFailedCall, Status.FATAL, null, ae.getClass().getName(), ae.getMessage());
/*      */ 
/* 1373 */         Server.this.responder.doRespond(this.authFailedCall);
/* 1374 */         return false;
/*      */       }
/* 1376 */       return true;
/*      */     }
/*      */ 
/*      */     private synchronized void close() throws IOException {
/* 1380 */       disposeSasl();
/* 1381 */       this.data = null;
/* 1382 */       this.dataLengthBuffer = null;
/* 1383 */       if (!this.channel.isOpen())
/* 1384 */         return; try {
/* 1385 */         this.socket.shutdownOutput(); } catch (Exception e) {
/* 1386 */       }if (this.channel.isOpen()) try {
/* 1387 */           this.channel.close(); } catch (Exception e) {
/*      */         } try {
/* 1389 */         this.socket.close();
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private class Responder extends Thread
/*      */   {
/*      */     private Selector writeSelector;
/*      */     private int pending;
/*      */     static final int PURGE_INTERVAL = 900000;
/*      */ 
/*      */     Responder()
/*      */       throws IOException
/*      */     {
/*  630 */       setName("IPC Server Responder");
/*  631 */       setDaemon(true);
/*  632 */       this.writeSelector = Selector.open();
/*  633 */       this.pending = 0;
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/*  638 */       Server.LOG.info(getName() + ": starting");
/*  639 */       Server.SERVER.set(Server.this);
/*  640 */       long lastPurgeTime = 0L;
/*      */ 
/*  642 */       while (Server.this.running) {
/*      */         try {
/*  644 */           waitPending();
/*  645 */           this.writeSelector.select(900000L);
/*  646 */           Iterator iter = this.writeSelector.selectedKeys().iterator();
/*  647 */           while (iter.hasNext()) {
/*  648 */             SelectionKey key = (SelectionKey)iter.next();
/*  649 */             iter.remove();
/*      */             try {
/*  651 */               if ((key.isValid()) && (key.isWritable()))
/*  652 */                 doAsyncWrite(key);
/*      */             }
/*      */             catch (IOException e) {
/*  655 */               Server.LOG.info(getName() + ": doAsyncWrite threw exception " + e);
/*      */             }
/*      */           }
/*  658 */           now = System.currentTimeMillis();
/*  659 */           if (now >= lastPurgeTime + 900000L)
/*      */           {
/*  662 */             lastPurgeTime = now;
/*      */ 
/*  667 */             Server.LOG.debug("Checking for old call responses.");
/*      */             ArrayList calls;
/*  671 */             synchronized (this.writeSelector.keys()) {
/*  672 */               calls = new ArrayList(this.writeSelector.keys().size());
/*  673 */               iter = this.writeSelector.keys().iterator();
/*  674 */               while (iter.hasNext()) {
/*  675 */                 SelectionKey key = (SelectionKey)iter.next();
/*  676 */                 Server.Call call = (Server.Call)key.attachment();
/*  677 */                 if ((call != null) && (key.channel() == Server.Call.access$000(call).channel)) {
/*  678 */                   calls.add(call);
/*      */                 }
/*      */               }
/*      */             }
/*      */ 
/*  683 */             for (Server.Call call : calls)
/*      */               try {
/*  685 */                 doPurge(call, now);
/*      */               } catch (IOException e) {
/*  687 */                 Server.LOG.warn("Error in purging old calls " + e);
/*      */               }
/*      */           }
/*      */         }
/*      */         catch (OutOfMemoryError e)
/*      */         {
/*      */           long now;
/*  696 */           Server.LOG.warn("Out of Memory in server select", e);
/*      */           try { Thread.sleep(60000L); } catch (Exception ie) {
/*      */           }
/*      */         } catch (Exception e) { Server.LOG.warn("Exception in Responder " + StringUtils.stringifyException(e)); }
/*      */ 
/*      */       }
/*      */ 
/*  703 */       Server.LOG.info("Stopping " + getName());
/*      */     }
/*      */ 
/*      */     private void doAsyncWrite(SelectionKey key) throws IOException {
/*  707 */       Server.Call call = (Server.Call)key.attachment();
/*  708 */       if (call == null) {
/*  709 */         return;
/*      */       }
/*  711 */       if (key.channel() != Server.Call.access$000(call).channel) {
/*  712 */         throw new IOException("doAsyncWrite: bad channel");
/*      */       }
/*      */ 
/*  715 */       synchronized (Server.Call.access$000(call).responseQueue) {
/*  716 */         if (processResponse(Server.Call.access$000(call).responseQueue, false))
/*      */           try {
/*  718 */             key.interestOps(0);
/*      */           }
/*      */           catch (CancelledKeyException e)
/*      */           {
/*  725 */             Server.LOG.warn("Exception while changing ops : " + e);
/*      */           }
/*      */       }
/*      */     }
/*      */ 
/*      */     private void doPurge(Server.Call call, long now)
/*      */       throws IOException
/*      */     {
/*  736 */       LinkedList responseQueue = Server.Call.access$000(call).responseQueue;
/*  737 */       synchronized (responseQueue) {
/*  738 */         Iterator iter = responseQueue.listIterator(0);
/*  739 */         while (iter.hasNext()) {
/*  740 */           call = (Server.Call)iter.next();
/*  741 */           if (now > Server.Call.access$1700(call) + 900000L)
/*  742 */             Server.this.closeConnection(Server.Call.access$000(call));
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     private boolean processResponse(LinkedList<Server.Call> responseQueue, boolean inHandler)
/*      */       throws IOException
/*      */     {
/*  754 */       boolean error = true;
/*  755 */       boolean done = false;
/*  756 */       int numElements = 0;
/*  757 */       Server.Call call = null;
/*      */       try {
/*  759 */         synchronized (responseQueue)
/*      */         {
/*  763 */           numElements = responseQueue.size();
/*  764 */           if (numElements == 0) {
/*  765 */             error = false;
/*  766 */             boolean bool1 = true;
/*      */ 
/*  828 */             if ((error) && (call != null)) {
/*  829 */               Server.LOG.warn(getName() + ", call " + call + ": output error");
/*  830 */               done = true;
/*  831 */               Server.this.closeConnection(Server.Call.access$000(call)); } return bool1;
/*      */           }
/*  771 */           call = (Server.Call)responseQueue.removeFirst();
/*  772 */           SocketChannel channel = Server.Call.access$000(call).channel;
/*  773 */           if (Server.LOG.isDebugEnabled()) {
/*  774 */             Server.LOG.debug(getName() + ": responding to #" + Server.Call.access$1800(call) + " from " + Server.Call.access$000(call));
/*      */           }
/*      */ 
/*  780 */           int numBytes = Server.this.channelWrite(channel, Server.Call.access$1900(call));
/*  781 */           if (numBytes < 0) {
/*  782 */             boolean bool2 = true;
/*      */ 
/*  828 */             if ((error) && (call != null)) {
/*  829 */               Server.LOG.warn(getName() + ", call " + call + ": output error");
/*  830 */               done = true;
/*  831 */               Server.this.closeConnection(Server.Call.access$000(call)); } return bool2;
/*      */           }
/*  784 */           if (!Server.Call.access$1900(call).hasRemaining()) {
/*  785 */             Server.Call.access$000(call).decRpcCount();
/*  786 */             if (numElements == 1)
/*  787 */               done = true;
/*      */             else {
/*  789 */               done = false;
/*      */             }
/*  791 */             if (Server.LOG.isDebugEnabled()) {
/*  792 */               Server.LOG.debug(getName() + ": responding to #" + Server.Call.access$1800(call) + " from " + Server.Call.access$000(call) + " Wrote " + numBytes + " bytes.");
/*      */             }
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*  800 */             Server.Call.access$000(call).responseQueue.addFirst(call);
/*      */ 
/*  802 */             if (inHandler)
/*      */             {
/*  804 */               Server.Call.access$1702(call, System.currentTimeMillis());
/*      */ 
/*  806 */               incPending();
/*      */               try
/*      */               {
/*  810 */                 this.writeSelector.wakeup();
/*  811 */                 channel.register(this.writeSelector, 4, call);
/*      */               }
/*      */               catch (ClosedChannelException e) {
/*  814 */                 done = true;
/*      */               } finally {
/*  816 */                 decPending();
/*      */               }
/*      */             }
/*  819 */             if (Server.LOG.isDebugEnabled()) {
/*  820 */               Server.LOG.debug(getName() + ": responding to #" + Server.Call.access$1800(call) + " from " + Server.Call.access$000(call) + " Wrote partial " + numBytes + " bytes.");
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  825 */           error = false;
/*      */         }
/*      */       } finally {
/*  828 */         if ((error) && (call != null)) {
/*  829 */           Server.LOG.warn(getName() + ", call " + call + ": output error");
/*  830 */           done = true;
/*  831 */           Server.this.closeConnection(Server.Call.access$000(call));
/*      */         }
/*      */       }
/*  834 */       return done;
/*      */     }
/*      */ 
/*      */     void doRespond(Server.Call call)
/*      */       throws IOException
/*      */     {
/*  841 */       synchronized (Server.Call.access$000(call).responseQueue) {
/*  842 */         Server.Call.access$000(call).responseQueue.addLast(call);
/*  843 */         if (Server.Call.access$000(call).responseQueue.size() == 1)
/*  844 */           processResponse(Server.Call.access$000(call).responseQueue, true);
/*      */       }
/*      */     }
/*      */ 
/*      */     private synchronized void incPending()
/*      */     {
/*  850 */       this.pending += 1;
/*      */     }
/*      */ 
/*      */     private synchronized void decPending() {
/*  854 */       this.pending -= 1;
/*  855 */       notify();
/*      */     }
/*      */ 
/*      */     private synchronized void waitPending() throws InterruptedException {
/*  859 */       while (this.pending > 0)
/*  860 */         wait();
/*      */     }
/*      */   }
/*      */ 
/*      */   private class Listener extends Thread
/*      */   {
/*  321 */     private ServerSocketChannel acceptChannel = null;
/*  322 */     private Selector selector = null;
/*  323 */     private Reader[] readers = null;
/*  324 */     private int currentReader = 0;
/*      */     private InetSocketAddress address;
/*  326 */     private Random rand = new Random();
/*  327 */     private long lastCleanupRunTime = 0L;
/*      */ 
/*  329 */     private long cleanupInterval = 10000L;
/*      */ 
/*  331 */     private int backlogLength = Server.this.conf.getInt("ipc.server.listen.queue.size", 128);
/*      */     private ExecutorService readPool;
/*      */ 
/*      */     public Listener()
/*      */       throws IOException
/*      */     {
/*  335 */       this.address = new InetSocketAddress(Server.this.bindAddress, Server.this.port);
/*      */ 
/*  337 */       this.acceptChannel = ServerSocketChannel.open();
/*  338 */       this.acceptChannel.configureBlocking(false);
/*      */ 
/*  341 */       Server.bind(this.acceptChannel.socket(), this.address, this.backlogLength);
/*  342 */       Server.this.port = this.acceptChannel.socket().getLocalPort();
/*      */ 
/*  344 */       this.selector = Selector.open();
/*  345 */       this.readers = new Reader[Server.this.readThreads];
/*  346 */       this.readPool = Executors.newFixedThreadPool(Server.this.readThreads);
/*  347 */       for (int i = 0; i < Server.this.readThreads; i++) {
/*  348 */         Selector readSelector = Selector.open();
/*  349 */         Reader reader = new Reader(readSelector);
/*  350 */         this.readers[i] = reader;
/*  351 */         this.readPool.execute(reader);
/*      */       }
/*      */ 
/*  355 */       this.acceptChannel.register(this.selector, 16);
/*  356 */       setName("IPC Server listener on " + Server.this.port);
/*  357 */       setDaemon(true);
/*      */     }
/*      */ 
/*      */     private void cleanupConnections(boolean force)
/*      */     {
/*  431 */       if ((force) || (Server.this.numConnections > Server.this.thresholdIdleConnections)) {
/*  432 */         long currentTime = System.currentTimeMillis();
/*  433 */         if ((!force) && (currentTime - this.lastCleanupRunTime < this.cleanupInterval)) {
/*  434 */           return;
/*      */         }
/*  436 */         int start = 0;
/*  437 */         int end = Server.this.numConnections - 1;
/*  438 */         if (!force) {
/*  439 */           start = this.rand.nextInt() % Server.this.numConnections;
/*  440 */           end = this.rand.nextInt() % Server.this.numConnections;
/*      */ 
/*  442 */           if (end < start) {
/*  443 */             int temp = start;
/*  444 */             start = end;
/*  445 */             end = temp;
/*      */           }
/*      */         }
/*  448 */         int i = start;
/*  449 */         int numNuked = 0;
/*  450 */         while (i <= end)
/*      */         {
/*      */           Server.Connection c;
/*  452 */           synchronized (Server.this.connectionList) {
/*      */             try {
/*  454 */               c = (Server.Connection)Server.this.connectionList.get(i); } catch (Exception e) {
/*  455 */               return;
/*      */             }
/*      */           }
/*  457 */           if (c.timedOut(currentTime)) {
/*  458 */             if (Server.LOG.isDebugEnabled())
/*  459 */               Server.LOG.debug(getName() + ": disconnecting client " + c.getHostAddress());
/*  460 */             Server.this.closeConnection(c);
/*  461 */             numNuked++;
/*  462 */             end--;
/*  463 */             c = null;
/*  464 */             if ((!force) && (numNuked == Server.this.maxConnectionsToNuke)) break; 
/*      */           }
/*  466 */           else { i++; }
/*      */         }
/*  468 */         this.lastCleanupRunTime = System.currentTimeMillis();
/*      */       }
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/*  474 */       Server.LOG.info(getName() + ": starting");
/*  475 */       Server.SERVER.set(Server.this);
/*  476 */       while (Server.this.running) {
/*  477 */         SelectionKey key = null;
/*      */         try {
/*  479 */           this.selector.select();
/*  480 */           Iterator iter = this.selector.selectedKeys().iterator();
/*  481 */           while (iter.hasNext()) {
/*  482 */             key = (SelectionKey)iter.next();
/*  483 */             iter.remove();
/*      */             try {
/*  485 */               if ((key.isValid()) && 
/*  486 */                 (key.isAcceptable()))
/*  487 */                 doAccept(key);
/*      */             }
/*      */             catch (IOException e) {
/*      */             }
/*  491 */             key = null;
/*      */           }
/*      */ 
/*      */         }
/*      */         catch (OutOfMemoryError e)
/*      */         {
/*  497 */           Server.LOG.warn("Out of Memory in server select", e);
/*  498 */           closeCurrentConnection(key, e);
/*  499 */           cleanupConnections(true);
/*      */           try { Thread.sleep(60000L); } catch (Exception ie) {
/*      */           }
/*      */         } catch (Exception e) { closeCurrentConnection(key, e); }
/*      */ 
/*  504 */         cleanupConnections(false);
/*      */       }
/*  506 */       Server.LOG.info("Stopping " + getName());
/*      */ 
/*  508 */       synchronized (this) {
/*      */         try {
/*  510 */           this.acceptChannel.close();
/*  511 */           this.selector.close();
/*      */         } catch (IOException e) {
/*      */         }
/*  514 */         this.selector = null;
/*  515 */         this.acceptChannel = null;
/*      */ 
/*  518 */         while (!Server.this.connectionList.isEmpty())
/*  519 */           Server.this.closeConnection((Server.Connection)Server.this.connectionList.remove(0));
/*      */       }
/*      */     }
/*      */ 
/*      */     private void closeCurrentConnection(SelectionKey key, Throwable e)
/*      */     {
/*  525 */       if (key != null) {
/*  526 */         Server.Connection c = (Server.Connection)key.attachment();
/*  527 */         if (c != null) {
/*  528 */           if (Server.LOG.isDebugEnabled())
/*  529 */             Server.LOG.debug(getName() + ": disconnecting client " + c.getHostAddress());
/*  530 */           Server.this.closeConnection(c);
/*  531 */           c = null;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     InetSocketAddress getAddress() {
/*  537 */       return (InetSocketAddress)this.acceptChannel.socket().getLocalSocketAddress();
/*      */     }
/*      */ 
/*      */     void doAccept(SelectionKey key) throws IOException, OutOfMemoryError {
/*  541 */       Server.Connection c = null;
/*  542 */       ServerSocketChannel server = (ServerSocketChannel)key.channel();
/*      */       SocketChannel channel;
/*  544 */       while ((channel = server.accept()) != null) {
/*  545 */         channel.configureBlocking(false);
/*  546 */         channel.socket().setTcpNoDelay(Server.this.tcpNoDelay);
/*  547 */         Reader reader = getReader();
/*      */         try {
/*  549 */           reader.startAdd();
/*  550 */           SelectionKey readKey = reader.registerChannel(channel);
/*  551 */           c = new Server.Connection(Server.this, readKey, channel, System.currentTimeMillis());
/*  552 */           readKey.attach(c);
/*  553 */           synchronized (Server.this.connectionList) {
/*  554 */             Server.this.connectionList.add(Server.this.numConnections, c);
/*  555 */             Server.access$708(Server.this);
/*      */           }
/*  557 */           if (Server.LOG.isDebugEnabled())
/*  558 */             Server.LOG.debug("Server connection from " + c.toString() + "; # active connections: " + Server.this.numConnections + "; # queued calls: " + Server.this.callQueue.size());
/*      */         }
/*      */         finally
/*      */         {
/*  562 */           reader.finishAdd();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     void doRead(SelectionKey key) throws InterruptedException
/*      */     {
/*  569 */       int count = 0;
/*  570 */       Server.Connection c = (Server.Connection)key.attachment();
/*  571 */       if (c == null) {
/*  572 */         return;
/*      */       }
/*  574 */       c.setLastContact(System.currentTimeMillis());
/*      */       try
/*      */       {
/*  577 */         count = c.readAndProcess();
/*      */       } catch (InterruptedException ieo) {
/*  579 */         Server.LOG.info(getName() + ": readAndProcess caught InterruptedException", ieo);
/*  580 */         throw ieo;
/*      */       } catch (Exception e) {
/*  582 */         Server.LOG.info(getName() + ": readAndProcess threw exception " + e + ". Count of bytes read: " + count, e);
/*  583 */         count = -1;
/*      */       }
/*  585 */       if (count < 0) {
/*  586 */         if (Server.LOG.isDebugEnabled()) {
/*  587 */           Server.LOG.debug(getName() + ": disconnecting client " + c + ". Number of active connections: " + Server.this.numConnections);
/*      */         }
/*      */ 
/*  590 */         Server.this.closeConnection(c);
/*  591 */         c = null;
/*      */       }
/*      */       else {
/*  594 */         c.setLastContact(System.currentTimeMillis());
/*      */       }
/*      */     }
/*      */ 
/*      */     synchronized void doStop() {
/*  599 */       if (this.selector != null) {
/*  600 */         this.selector.wakeup();
/*  601 */         Thread.yield();
/*      */       }
/*  603 */       if (this.acceptChannel != null) {
/*      */         try {
/*  605 */           this.acceptChannel.socket().close();
/*      */         } catch (IOException e) {
/*  607 */           Server.LOG.info(getName() + ":Exception in closing listener socket. " + e);
/*      */         }
/*      */       }
/*  610 */       this.readPool.shutdown();
/*      */     }
/*      */ 
/*      */     Reader getReader()
/*      */     {
/*  616 */       this.currentReader = ((this.currentReader + 1) % this.readers.length);
/*  617 */       return this.readers[this.currentReader];
/*      */     }
/*      */ 
/*      */     private class Reader
/*      */       implements Runnable
/*      */     {
/*  361 */       private volatile boolean adding = false;
/*  362 */       private Selector readSelector = null;
/*      */ 
/*      */       Reader(Selector readSelector) {
/*  365 */         this.readSelector = readSelector;
/*      */       }
/*      */       public void run() {
/*  368 */         Server.LOG.info("Starting SocketReader");
/*  369 */         synchronized (this) {
/*  370 */           while (Server.this.running) {
/*  371 */             SelectionKey key = null;
/*      */             try {
/*  373 */               this.readSelector.select();
/*  374 */               while (this.adding) {
/*  375 */                 wait(1000L);
/*      */               }
/*      */ 
/*  378 */               Iterator iter = this.readSelector.selectedKeys().iterator();
/*  379 */               while (iter.hasNext()) {
/*  380 */                 key = (SelectionKey)iter.next();
/*  381 */                 iter.remove();
/*  382 */                 if ((key.isValid()) && 
/*  383 */                   (key.isReadable())) {
/*  384 */                   Server.Listener.this.doRead(key);
/*      */                 }
/*      */ 
/*  387 */                 key = null;
/*      */               }
/*      */             } catch (InterruptedException e) {
/*  390 */               if (Server.this.running)
/*  391 */                 Server.LOG.info(Server.Listener.this.getName() + " caught: " + StringUtils.stringifyException(e));
/*      */             }
/*      */             catch (IOException ex)
/*      */             {
/*  395 */               Server.LOG.error("Error in Reader", ex);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       public void startAdd()
/*      */       {
/*  409 */         this.adding = true;
/*  410 */         this.readSelector.wakeup();
/*      */       }
/*      */ 
/*      */       public synchronized SelectionKey registerChannel(SocketChannel channel) throws IOException
/*      */       {
/*  415 */         return channel.register(this.readSelector, 1);
/*      */       }
/*      */ 
/*      */       public synchronized void finishAdd() {
/*  419 */         this.adding = false;
/*  420 */         notify();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class Call
/*      */   {
/*      */     private int id;
/*      */     private Writable param;
/*      */     private Server.Connection connection;
/*      */     private long timestamp;
/*      */     private ByteBuffer response;
/*      */ 
/*      */     public Call(int id, Writable param, Server.Connection connection)
/*      */     {
/*  301 */       this.id = id;
/*  302 */       this.param = param;
/*  303 */       this.connection = connection;
/*  304 */       this.timestamp = System.currentTimeMillis();
/*  305 */       this.response = null;
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/*  310 */       return this.param.toString() + " from " + this.connection.toString();
/*      */     }
/*      */ 
/*      */     public void setResponse(ByteBuffer response) {
/*  314 */       this.response = response;
/*      */     }
/*      */   }
/*      */ 
/*      */   static class ExceptionsHandler
/*      */   {
/*  111 */     private volatile Set<String> terseExceptions = new HashSet();
/*      */ 
/*      */     void addTerseExceptions(Class<?>[] exceptionClass)
/*      */     {
/*  123 */       HashSet newSet = new HashSet(this.terseExceptions);
/*      */ 
/*  126 */       for (Class name : exceptionClass) {
/*  127 */         newSet.add(name.toString());
/*      */       }
/*      */ 
/*  130 */       this.terseExceptions = Collections.unmodifiableSet(newSet);
/*      */     }
/*      */ 
/*      */     boolean isTerse(Class<?> t) {
/*  134 */       return this.terseExceptions.contains(t.toString());
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.ipc.Server
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.ipc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ public class RemoteException extends IOException
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String className;
/*     */ 
/*     */   public RemoteException(String className, String msg)
/*     */   {
/*  33 */     super(msg);
/*  34 */     this.className = className;
/*     */   }
/*     */ 
/*     */   public String getClassName() {
/*  38 */     return this.className;
/*     */   }
/*     */ 
/*     */   public IOException unwrapRemoteException(Class<?>[] lookupTypes)
/*     */   {
/*  51 */     if (lookupTypes == null)
/*  52 */       return this;
/*  53 */     for (Class lookupClass : lookupTypes) {
/*  54 */       if (lookupClass.getName().equals(getClassName())) {
/*     */         try
/*     */         {
/*  57 */           return instantiateException(lookupClass.asSubclass(IOException.class));
/*     */         }
/*     */         catch (Exception e) {
/*  60 */           return this;
/*     */         }
/*     */       }
/*     */     }
/*  64 */     return this;
/*     */   }
/*     */ 
/*     */   public IOException unwrapRemoteException()
/*     */   {
/*     */     try
/*     */     {
/*  78 */       Class realClass = Class.forName(getClassName());
/*  79 */       return instantiateException(realClass.asSubclass(IOException.class));
/*     */     }
/*     */     catch (Exception e) {
/*     */     }
/*  83 */     return this;
/*     */   }
/*     */ 
/*     */   private IOException instantiateException(Class<? extends IOException> cls) throws Exception
/*     */   {
/*  88 */     Constructor cn = cls.getConstructor(new Class[] { String.class });
/*  89 */     cn.setAccessible(true);
/*  90 */     String firstLine = getMessage();
/*  91 */     int eol = firstLine.indexOf(10);
/*  92 */     if (eol >= 0) {
/*  93 */       firstLine = firstLine.substring(0, eol);
/*     */     }
/*  95 */     IOException ex = (IOException)cn.newInstance(new Object[] { firstLine });
/*  96 */     ex.initCause(this);
/*  97 */     return ex;
/*     */   }
/*     */ 
/*     */   public static RemoteException valueOf(Attributes attrs)
/*     */   {
/* 102 */     return new RemoteException(attrs.getValue("class"), attrs.getValue("message"));
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.ipc.RemoteException
 * JD-Core Version:    0.6.1
 */
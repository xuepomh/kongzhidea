package org.apache.hadoop.ipc;

import java.io.IOException;

public abstract interface VersionedProtocol
{
  public abstract long getProtocolVersion(String paramString, long paramLong)
    throws IOException;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.ipc.VersionedProtocol
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.ipc.metrics;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.metrics2.MetricsBuilder;
/*     */ import org.apache.hadoop.metrics2.MetricsSource;
/*     */ import org.apache.hadoop.metrics2.MetricsSystem;
/*     */ import org.apache.hadoop.metrics2.lib.AbstractMetricsSource;
/*     */ import org.apache.hadoop.metrics2.lib.DefaultMetricsSystem;
/*     */ import org.apache.hadoop.metrics2.lib.MetricMutableCounterInt;
/*     */ import org.apache.hadoop.metrics2.lib.MetricMutableCounterLong;
/*     */ import org.apache.hadoop.metrics2.lib.MetricMutableGaugeInt;
/*     */ import org.apache.hadoop.metrics2.lib.MetricMutableStat;
/*     */ import org.apache.hadoop.metrics2.lib.MetricsRegistry;
/*     */ 
/*     */ public class RpcInstrumentation
/*     */   implements MetricsSource
/*     */ {
/*  39 */   static final Log LOG = LogFactory.getLog(RpcInstrumentation.class);
/*     */ 
/*  41 */   final MetricsRegistry registry = new MetricsRegistry("rpc");
/*  42 */   final MetricMutableCounterInt authenticationSuccesses = this.registry.newCounter("rpcAuthenticationSuccesses", "RPC authentication successes count", 0);
/*     */ 
/*  45 */   final MetricMutableCounterInt authenticationFailures = this.registry.newCounter("rpcAuthenticationFailures", "RPC authentication failures count", 0);
/*     */ 
/*  48 */   final MetricMutableCounterInt authorizationSuccesses = this.registry.newCounter("rpcAuthorizationSuccesses", "RPC authorization successes count", 0);
/*     */ 
/*  51 */   final MetricMutableCounterInt authorizationFailures = this.registry.newCounter("rpcAuthorizationFailures", "RPC authorization failures count", 0);
/*     */ 
/*  54 */   final MetricMutableCounterLong receivedBytes = this.registry.newCounter("ReceivedBytes", "RPC received bytes count", 0L);
/*     */ 
/*  56 */   final MetricMutableCounterLong sentBytes = this.registry.newCounter("SentBytes", "RPC sent bytes count", 0L);
/*     */ 
/*  58 */   final MetricMutableStat rpcQueueTime = this.registry.newStat("RpcQueueTime", "RPC queue time stats", "ops", "time");
/*     */ 
/*  60 */   final MetricMutableStat rpcProcessingTime = this.registry.newStat("RpcProcessingTime", "RPC processing time", "ops", "time");
/*     */ 
/*  62 */   final MetricMutableGaugeInt numOpenConnections = this.registry.newGauge("NumOpenConnections", "Number of open connections", 0);
/*     */ 
/*  64 */   final MetricMutableGaugeInt callQueueLen = this.registry.newGauge("callQueueLen", "RPC call queue length", 0);
/*     */   final Detailed detailed;
/*     */ 
/*     */   RpcInstrumentation(String serverName, int port)
/*     */   {
/*  70 */     String portStr = String.valueOf(port);
/*  71 */     this.registry.setContext("rpc").tag("port", "RPC port", portStr);
/*  72 */     this.detailed = new Detailed(portStr);
/*     */   }
/*     */ 
/*     */   public void getMetrics(MetricsBuilder builder, boolean all)
/*     */   {
/*  77 */     this.registry.snapshot(builder.addRecord(this.registry.name()), all);
/*     */   }
/*     */ 
/*     */   public static RpcInstrumentation create(String serverName, int port)
/*     */   {
/*  87 */     return create(serverName, port, DefaultMetricsSystem.INSTANCE);
/*     */   }
/*     */ 
/*     */   public static RpcInstrumentation create(String serverName, int port, MetricsSystem ms)
/*     */   {
/* 100 */     RpcInstrumentation rpc = new RpcInstrumentation(serverName, port);
/* 101 */     ms.register("RpcDetailedActivityForPort" + port, "Per call", rpc.detailed());
/* 102 */     return (RpcInstrumentation)ms.register("RpcActivityForPort" + port, "Aggregate metrics", rpc);
/*     */   }
/*     */ 
/*     */   public MetricsSource detailed()
/*     */   {
/* 109 */     return this.detailed;
/*     */   }
/*     */ 
/*     */   public void incrAuthenticationFailures()
/*     */   {
/* 122 */     this.authenticationFailures.incr();
/*     */   }
/*     */ 
/*     */   public void incrAuthenticationSuccesses()
/*     */   {
/* 130 */     this.authenticationSuccesses.incr();
/*     */   }
/*     */ 
/*     */   public void incrAuthorizationSuccesses()
/*     */   {
/* 138 */     this.authorizationSuccesses.incr();
/*     */   }
/*     */ 
/*     */   public void incrAuthorizationFailures()
/*     */   {
/* 146 */     this.authorizationFailures.incr();
/*     */   }
/*     */ 
/*     */   public void shutdown()
/*     */   {
/* 154 */     LOG.info("shut down");
/*     */   }
/*     */ 
/*     */   public void incrSentBytes(int count)
/*     */   {
/* 163 */     this.sentBytes.incr(count);
/*     */   }
/*     */ 
/*     */   public void incrReceivedBytes(int count)
/*     */   {
/* 172 */     this.receivedBytes.incr(count);
/*     */   }
/*     */ 
/*     */   public void addRpcQueueTime(int qTime)
/*     */   {
/* 181 */     this.rpcQueueTime.add(qTime);
/*     */   }
/*     */ 
/*     */   public void addRpcProcessingTime(int processingTime)
/*     */   {
/* 190 */     this.rpcProcessingTime.add(processingTime);
/*     */   }
/*     */ 
/*     */   public void addRpcProcessingTime(String methodName, int processingTime)
/*     */   {
/* 200 */     this.detailed.addRpcProcessingTime(methodName, processingTime);
/*     */   }
/*     */ 
/*     */   public static class Detailed extends AbstractMetricsSource
/*     */   {
/*     */     Detailed(String port)
/*     */     {
/* 210 */       super();
/* 211 */       this.registry.setContext("rpcdetailed").tag("port", "RPC port", port);
/*     */     }
/*     */ 
/*     */     public synchronized void addRpcProcessingTime(String methodName, int processingTime)
/*     */     {
/* 216 */       this.registry.add(methodName, processingTime);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.ipc.metrics.RpcInstrumentation
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.http;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.mortbay.jetty.servlet.DefaultServlet;
/*    */ 
/*    */ public class AdminAuthorizedServlet extends DefaultServlet
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   protected void doGet(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 40 */     if (HttpServer.hasAdministratorAccess(getServletContext(), request, response))
/*    */     {
/* 43 */       super.doGet(request, response);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.http.AdminAuthorizedServlet
 * JD-Core Version:    0.6.1
 */
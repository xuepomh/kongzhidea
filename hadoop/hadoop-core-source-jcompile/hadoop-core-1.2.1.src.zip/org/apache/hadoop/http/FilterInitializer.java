package org.apache.hadoop.http;

import org.apache.hadoop.conf.Configuration;

public abstract class FilterInitializer
{
  public abstract void initFilter(FilterContainer paramFilterContainer, Configuration paramConfiguration);
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.http.FilterInitializer
 * JD-Core Version:    0.6.1
 */
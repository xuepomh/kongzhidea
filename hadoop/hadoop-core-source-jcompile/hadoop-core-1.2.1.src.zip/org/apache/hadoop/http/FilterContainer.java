package org.apache.hadoop.http;

import java.util.Map;

public abstract interface FilterContainer
{
  public abstract void addFilter(String paramString1, String paramString2, Map<String, String> paramMap);

  public abstract void addGlobalFilter(String paramString1, String paramString2, Map<String, String> paramMap);
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.http.FilterContainer
 * JD-Core Version:    0.6.1
 */
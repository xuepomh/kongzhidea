/*     */ package org.apache.hadoop.http.lib;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.security.Principal;
/*     */ import java.util.HashMap;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletRequestWrapper;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.http.FilterContainer;
/*     */ import org.apache.hadoop.http.FilterInitializer;
/*     */ 
/*     */ public class StaticUserWebFilter extends FilterInitializer
/*     */ {
/*     */   private static final String WEB_USERNAME = "Dr.Who";
/*  44 */   private static final Principal WEB_USER = new User("Dr.Who");
/*     */ 
/*     */   public void initFilter(FilterContainer container, Configuration conf)
/*     */   {
/* 114 */     container.addFilter("static_user_filter", StaticUserFilter.class.getName(), new HashMap());
/*     */   }
/*     */ 
/*     */   public static class StaticUserFilter
/*     */     implements Filter
/*     */   {
/*     */     public void destroy()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */       throws IOException, ServletException
/*     */     {
/*  85 */       HttpServletRequest httpRequest = (HttpServletRequest)request;
/*     */ 
/*  87 */       if (httpRequest.getRemoteUser() != null) {
/*  88 */         chain.doFilter(request, response);
/*     */       } else {
/*  90 */         HttpServletRequestWrapper wrapper = new HttpServletRequestWrapper(httpRequest)
/*     */         {
/*     */           public Principal getUserPrincipal()
/*     */           {
/*  94 */             return StaticUserWebFilter.WEB_USER;
/*     */           }
/*     */ 
/*     */           public String getRemoteUser() {
/*  98 */             return "Dr.Who";
/*     */           }
/*     */         };
/* 101 */         chain.doFilter(wrapper, response);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void init(FilterConfig conf)
/*     */       throws ServletException
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   static class User
/*     */     implements Principal
/*     */   {
/*     */     private final String name;
/*     */ 
/*     */     public User(String name)
/*     */     {
/*  49 */       this.name = name;
/*     */     }
/*     */ 
/*     */     public String getName() {
/*  53 */       return this.name;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/*  57 */       return this.name.hashCode();
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other) {
/*  61 */       if (other == this)
/*  62 */         return true;
/*  63 */       if ((other == null) || (other.getClass() != getClass())) {
/*  64 */         return false;
/*     */       }
/*  66 */       return ((User)other).name.equals(this.name);
/*     */     }
/*     */ 
/*     */     public String toString() {
/*  70 */       return this.name;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.http.lib.StaticUserWebFilter
 * JD-Core Version:    0.6.1
 */
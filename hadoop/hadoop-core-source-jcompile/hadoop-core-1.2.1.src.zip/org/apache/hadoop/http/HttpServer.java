/*     */ package org.apache.hadoop.http;
/*     */ 
/*     */ import com.sun.jersey.spi.container.servlet.ServletContainer;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.BindException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletRequestWrapper;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.ConfServlet;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.jmx.JMXJsonServlet;
/*     */ import org.apache.hadoop.log.LogLevel.Servlet;
/*     */ import org.apache.hadoop.security.Krb5AndCertsSslSocketConnector;
/*     */ import org.apache.hadoop.security.Krb5AndCertsSslSocketConnector.Krb5SslFilter;
/*     */ import org.apache.hadoop.security.Krb5AndCertsSslSocketConnector.MODE;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.authorize.AccessControlList;
/*     */ import org.apache.hadoop.util.ReflectionUtils;
/*     */ import org.mortbay.io.Buffer;
/*     */ import org.mortbay.jetty.Connector;
/*     */ import org.mortbay.jetty.Handler;
/*     */ import org.mortbay.jetty.MimeTypes;
/*     */ import org.mortbay.jetty.Server;
/*     */ import org.mortbay.jetty.handler.ContextHandler;
/*     */ import org.mortbay.jetty.handler.ContextHandler.SContext;
/*     */ import org.mortbay.jetty.handler.ContextHandlerCollection;
/*     */ import org.mortbay.jetty.nio.SelectChannelConnector;
/*     */ import org.mortbay.jetty.security.SslSocketConnector;
/*     */ import org.mortbay.jetty.servlet.Context;
/*     */ import org.mortbay.jetty.servlet.DefaultServlet;
/*     */ import org.mortbay.jetty.servlet.FilterHolder;
/*     */ import org.mortbay.jetty.servlet.FilterMapping;
/*     */ import org.mortbay.jetty.servlet.ServletHandler;
/*     */ import org.mortbay.jetty.servlet.ServletHolder;
/*     */ import org.mortbay.jetty.webapp.WebAppContext;
/*     */ import org.mortbay.thread.QueuedThreadPool;
/*     */ import org.mortbay.util.MultiException;
/*     */ 
/*     */ public class HttpServer
/*     */   implements FilterContainer
/*     */ {
/*  85 */   public static final Log LOG = LogFactory.getLog(HttpServer.class);
/*     */   static final String FILTER_INITIALIZER_PROPERTY = "hadoop.http.filter.initializers";
/*     */   public static final String CONF_CONTEXT_ATTRIBUTE = "hadoop.conf";
/*     */   static final String ADMINS_ACL = "admins.acl";
/*     */   public static final String SPNEGO_FILTER = "SpnegoFilter";
/*     */   public static final String KRB5_FILTER = "krb5Filter";
/*     */   private AccessControlList adminsAcl;
/*     */   protected final Server webServer;
/*     */   protected final Connector listener;
/*     */   protected final WebAppContext webAppContext;
/*     */   protected final boolean findPort;
/* 103 */   protected final Map<Context, Boolean> defaultContexts = new HashMap();
/*     */ 
/* 105 */   protected final List<String> filterNames = new ArrayList();
/*     */   private static final int MAX_RETRIES = 10;
/*     */   private final Configuration conf;
/* 109 */   private boolean listenerStartedExternally = false;
/*     */ 
/*     */   public HttpServer(String name, String bindAddress, int port, boolean findPort)
/*     */     throws IOException
/*     */   {
/* 114 */     this(name, bindAddress, port, findPort, new Configuration());
/*     */   }
/*     */ 
/*     */   public HttpServer(String name, String bindAddress, int port, boolean findPort, Configuration conf) throws IOException
/*     */   {
/* 119 */     this(name, bindAddress, port, findPort, conf, null, null);
/*     */   }
/*     */ 
/*     */   public HttpServer(String name, String bindAddress, int port, boolean findPort, Configuration conf, Connector connector) throws IOException
/*     */   {
/* 124 */     this(name, bindAddress, port, findPort, conf, null, connector);
/*     */   }
/*     */ 
/*     */   public HttpServer(String name, String bindAddress, int port, boolean findPort, Configuration conf, AccessControlList adminsAcl)
/*     */     throws IOException
/*     */   {
/* 140 */     this(name, bindAddress, port, findPort, conf, adminsAcl, null);
/*     */   }
/*     */ 
/*     */   public HttpServer(String name, String bindAddress, int port, boolean findPort, Configuration conf, AccessControlList adminsAcl, Connector connector)
/*     */     throws IOException
/*     */   {
/* 146 */     this.webServer = new Server();
/* 147 */     this.findPort = findPort;
/* 148 */     this.conf = conf;
/* 149 */     this.adminsAcl = adminsAcl;
/*     */ 
/* 151 */     if (connector == null) {
/* 152 */       this.listenerStartedExternally = false;
/* 153 */       this.listener = createBaseListener(conf);
/* 154 */       this.listener.setHost(bindAddress);
/* 155 */       this.listener.setPort(port);
/*     */     } else {
/* 157 */       this.listenerStartedExternally = true;
/* 158 */       this.listener = connector;
/*     */     }
/*     */ 
/* 161 */     this.webServer.addConnector(this.listener);
/*     */ 
/* 163 */     this.webServer.setThreadPool(new QueuedThreadPool());
/*     */ 
/* 165 */     String appDir = getWebAppsPath();
/* 166 */     ContextHandlerCollection contexts = new ContextHandlerCollection();
/* 167 */     this.webServer.setHandler(contexts);
/*     */ 
/* 169 */     this.webAppContext = new WebAppContext();
/* 170 */     this.webAppContext.setDisplayName("WepAppsContext");
/* 171 */     this.webAppContext.setContextPath("/");
/* 172 */     this.webAppContext.setWar(appDir + "/" + name);
/* 173 */     this.webAppContext.getServletContext().setAttribute("hadoop.conf", conf);
/* 174 */     this.webAppContext.getServletContext().setAttribute("admins.acl", adminsAcl);
/* 175 */     this.webServer.addHandler(this.webAppContext);
/*     */ 
/* 177 */     addDefaultApps(contexts, appDir);
/*     */ 
/* 179 */     defineFilter(this.webAppContext, "krb5Filter", Krb5AndCertsSslSocketConnector.Krb5SslFilter.class.getName(), null, null);
/*     */ 
/* 183 */     addGlobalFilter("safety", QuotingInputFilter.class.getName(), null);
/* 184 */     FilterInitializer[] initializers = getFilterInitializers(conf);
/* 185 */     if (initializers != null) {
/* 186 */       for (FilterInitializer c : initializers) {
/* 187 */         c.initFilter(this, conf);
/*     */       }
/*     */     }
/* 190 */     addDefaultServlets();
/*     */   }
/*     */ 
/*     */   public Connector createBaseListener(Configuration conf)
/*     */     throws IOException
/*     */   {
/* 200 */     return createDefaultChannelConnector();
/*     */   }
/*     */ 
/*     */   public static Connector createDefaultChannelConnector()
/*     */   {
/* 205 */     SelectChannelConnector ret = new SelectChannelConnector();
/* 206 */     ret.setLowResourceMaxIdleTime(10000);
/* 207 */     ret.setAcceptQueueSize(128);
/* 208 */     ret.setResolveNames(false);
/* 209 */     ret.setUseDirectBuffers(false);
/* 210 */     return ret;
/*     */   }
/*     */ 
/*     */   private static FilterInitializer[] getFilterInitializers(Configuration conf)
/*     */   {
/* 215 */     if (conf == null) {
/* 216 */       return null;
/*     */     }
/*     */ 
/* 219 */     Class[] classes = conf.getClasses("hadoop.http.filter.initializers", new Class[0]);
/* 220 */     if (classes == null) {
/* 221 */       return null;
/*     */     }
/*     */ 
/* 224 */     FilterInitializer[] initializers = new FilterInitializer[classes.length];
/* 225 */     for (int i = 0; i < classes.length; i++) {
/* 226 */       initializers[i] = ((FilterInitializer)ReflectionUtils.newInstance(classes[i], conf));
/*     */     }
/*     */ 
/* 229 */     return initializers;
/*     */   }
/*     */ 
/*     */   protected void addDefaultApps(ContextHandlerCollection parent, String appDir)
/*     */     throws IOException
/*     */   {
/* 240 */     String logDir = System.getProperty("hadoop.log.dir");
/* 241 */     if (logDir != null) {
/* 242 */       Context logContext = new Context(parent, "/logs");
/* 243 */       logContext.setResourceBase(logDir);
/* 244 */       logContext.addServlet(AdminAuthorizedServlet.class, "/");
/* 245 */       if (this.conf.getBoolean("hadoop.jetty.logs.serve.aliases", true))
/*     */       {
/* 248 */         logContext.getInitParams().put("org.mortbay.jetty.servlet.Default.aliases", "true");
/*     */       }
/*     */ 
/* 251 */       logContext.setDisplayName("logs");
/* 252 */       setContextAttributes(logContext);
/* 253 */       this.defaultContexts.put(logContext, Boolean.valueOf(true));
/*     */     }
/*     */ 
/* 256 */     Context staticContext = new Context(parent, "/static");
/* 257 */     staticContext.setResourceBase(appDir + "/static");
/* 258 */     staticContext.addServlet(DefaultServlet.class, "/*");
/* 259 */     staticContext.setDisplayName("static");
/* 260 */     setContextAttributes(staticContext);
/* 261 */     this.defaultContexts.put(staticContext, Boolean.valueOf(true));
/*     */   }
/*     */ 
/*     */   private void setContextAttributes(Context context) {
/* 265 */     context.getServletContext().setAttribute("hadoop.conf", this.conf);
/* 266 */     context.getServletContext().setAttribute("admins.acl", this.adminsAcl);
/*     */   }
/*     */ 
/*     */   protected void addDefaultServlets()
/*     */   {
/* 274 */     addServlet("stacks", "/stacks", StackServlet.class);
/* 275 */     addServlet("logLevel", "/logLevel", LogLevel.Servlet.class);
/* 276 */     addServlet("jmx", "/jmx", JMXJsonServlet.class);
/* 277 */     addServlet("conf", "/conf", ConfServlet.class);
/*     */   }
/*     */ 
/*     */   public void addContext(Context ctxt, boolean isFiltered) throws IOException
/*     */   {
/* 282 */     this.webServer.addHandler(ctxt);
/* 283 */     this.defaultContexts.put(ctxt, Boolean.valueOf(isFiltered));
/*     */   }
/*     */ 
/*     */   protected void addContext(String pathSpec, String dir, boolean isFiltered)
/*     */     throws IOException
/*     */   {
/* 294 */     if (0 == this.webServer.getHandlers().length) {
/* 295 */       throw new RuntimeException("Couldn't find handler");
/*     */     }
/* 297 */     WebAppContext webAppCtx = new WebAppContext();
/* 298 */     webAppCtx.setContextPath(pathSpec);
/* 299 */     webAppCtx.setWar(dir);
/* 300 */     addContext(webAppCtx, true);
/*     */   }
/*     */ 
/*     */   public void setAttribute(String name, Object value)
/*     */   {
/* 310 */     setAttribute(this.webAppContext, name, value);
/*     */   }
/*     */ 
/*     */   public void setAttribute(Context context, String name, Object value)
/*     */   {
/* 321 */     context.setAttribute(name, value);
/*     */   }
/*     */ 
/*     */   public void addJerseyResourcePackage(String packageName, String pathSpec)
/*     */   {
/* 331 */     LOG.info("addJerseyResourcePackage: packageName=" + packageName + ", pathSpec=" + pathSpec);
/*     */ 
/* 333 */     ServletHolder sh = new ServletHolder(ServletContainer.class);
/* 334 */     sh.setInitParameter("com.sun.jersey.config.property.resourceConfigClass", "com.sun.jersey.api.core.PackagesResourceConfig");
/*     */ 
/* 336 */     sh.setInitParameter("com.sun.jersey.config.property.packages", packageName);
/* 337 */     this.webAppContext.addServlet(sh, pathSpec);
/*     */   }
/*     */ 
/*     */   public void addServlet(String name, String pathSpec, Class<? extends HttpServlet> clazz)
/*     */   {
/* 348 */     addInternalServlet(name, pathSpec, clazz, false, false);
/* 349 */     addFilterPathMapping(pathSpec, this.webAppContext);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void addInternalServlet(String name, String pathSpec, Class<? extends HttpServlet> clazz)
/*     */   {
/* 362 */     addInternalServlet(name, pathSpec, clazz, false, false);
/*     */   }
/*     */ 
/*     */   public void addInternalServlet(String name, String pathSpec, Class<? extends HttpServlet> clazz, boolean requireAuth, boolean useKsslForAuth)
/*     */   {
/* 382 */     ServletHolder holder = new ServletHolder(clazz);
/* 383 */     if (name != null) {
/* 384 */       holder.setName(name);
/*     */     }
/* 386 */     this.webAppContext.addServlet(holder, pathSpec);
/*     */ 
/* 388 */     if ((requireAuth) && (UserGroupInformation.isSecurityEnabled())) {
/* 389 */       ServletHandler handler = this.webAppContext.getServletHandler();
/* 390 */       FilterMapping fmap = new FilterMapping();
/* 391 */       fmap.setPathSpec(pathSpec);
/* 392 */       if (useKsslForAuth) {
/* 393 */         LOG.info("Adding Kerberos (KSSL) filter to " + name);
/* 394 */         fmap.setFilterName("krb5Filter");
/*     */       } else {
/* 396 */         LOG.info("Adding Kerberos (SPNEGO) filter to " + name);
/* 397 */         fmap.setFilterName("SpnegoFilter");
/*     */       }
/* 399 */       fmap.setDispatches(15);
/* 400 */       handler.addFilterMapping(fmap);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addFilter(String name, String classname, Map<String, String> parameters)
/*     */   {
/* 408 */     String[] USER_FACING_URLS = { "*.html", "*.jsp" };
/* 409 */     defineFilter(this.webAppContext, name, classname, parameters, USER_FACING_URLS);
/* 410 */     LOG.info("Added filter " + name + " (class=" + classname + ") to context " + this.webAppContext.getDisplayName());
/*     */ 
/* 412 */     String[] ALL_URLS = { "/*" };
/* 413 */     for (Map.Entry e : this.defaultContexts.entrySet()) {
/* 414 */       if (((Boolean)e.getValue()).booleanValue()) {
/* 415 */         Context ctx = (Context)e.getKey();
/* 416 */         defineFilter(ctx, name, classname, parameters, ALL_URLS);
/* 417 */         LOG.info("Added filter " + name + " (class=" + classname + ") to context " + ctx.getDisplayName());
/*     */       }
/*     */     }
/*     */ 
/* 421 */     this.filterNames.add(name);
/*     */   }
/*     */ 
/*     */   public void addGlobalFilter(String name, String classname, Map<String, String> parameters)
/*     */   {
/* 427 */     String[] ALL_URLS = { "/*" };
/* 428 */     defineFilter(this.webAppContext, name, classname, parameters, ALL_URLS);
/* 429 */     for (Context ctx : this.defaultContexts.keySet()) {
/* 430 */       defineFilter(ctx, name, classname, parameters, ALL_URLS);
/*     */     }
/* 432 */     LOG.info("Added global filter" + name + " (class=" + classname + ")");
/*     */   }
/*     */ 
/*     */   protected void defineFilter(Context ctx, String name, String classname, Map<String, String> parameters, String[] urls)
/*     */   {
/* 441 */     FilterHolder holder = new FilterHolder();
/* 442 */     holder.setName(name);
/* 443 */     holder.setClassName(classname);
/* 444 */     holder.setInitParameters(parameters);
/* 445 */     FilterMapping fmap = new FilterMapping();
/* 446 */     fmap.setPathSpecs(urls);
/* 447 */     fmap.setDispatches(15);
/* 448 */     fmap.setFilterName(name);
/* 449 */     ServletHandler handler = ctx.getServletHandler();
/* 450 */     handler.addFilter(holder, fmap);
/*     */   }
/*     */ 
/*     */   protected void addFilterPathMapping(String pathSpec, Context webAppCtx)
/*     */   {
/* 460 */     ServletHandler handler = webAppCtx.getServletHandler();
/* 461 */     for (String name : this.filterNames) {
/* 462 */       FilterMapping fmap = new FilterMapping();
/* 463 */       fmap.setPathSpec(pathSpec);
/* 464 */       fmap.setFilterName(name);
/* 465 */       fmap.setDispatches(15);
/* 466 */       handler.addFilterMapping(fmap);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object getAttribute(String name)
/*     */   {
/* 476 */     return this.webAppContext.getAttribute(name);
/*     */   }
/*     */ 
/*     */   protected String getWebAppsPath()
/*     */     throws IOException
/*     */   {
/* 485 */     URL url = getClass().getClassLoader().getResource("webapps");
/* 486 */     if (url == null)
/* 487 */       throw new IOException("webapps not found in CLASSPATH");
/* 488 */     return url.toString();
/*     */   }
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 496 */     return this.webServer.getConnectors()[0].getLocalPort();
/*     */   }
/*     */ 
/*     */   public void setThreads(int min, int max)
/*     */   {
/* 503 */     QueuedThreadPool pool = (QueuedThreadPool)this.webServer.getThreadPool();
/* 504 */     pool.setMinThreads(min);
/* 505 */     pool.setMaxThreads(max);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void addSslListener(InetSocketAddress addr, String keystore, String storPass, String keyPass)
/*     */     throws IOException
/*     */   {
/* 519 */     if (this.webServer.isStarted()) {
/* 520 */       throw new IOException("Failed to add ssl listener");
/*     */     }
/* 522 */     SslSocketConnector sslListener = new SslSocketConnector();
/* 523 */     sslListener.setHost(addr.getHostName());
/* 524 */     sslListener.setPort(addr.getPort());
/* 525 */     sslListener.setKeystore(keystore);
/* 526 */     sslListener.setPassword(storPass);
/* 527 */     sslListener.setKeyPassword(keyPass);
/* 528 */     this.webServer.addConnector(sslListener);
/*     */   }
/*     */ 
/*     */   public void addSslListener(InetSocketAddress addr, Configuration sslConf, boolean needClientAuth)
/*     */     throws IOException
/*     */   {
/* 539 */     addSslListener(addr, sslConf, needClientAuth, false);
/*     */   }
/*     */ 
/*     */   public void addSslListener(InetSocketAddress addr, Configuration sslConf, boolean needCertsAuth, boolean needKrbAuth)
/*     */     throws IOException
/*     */   {
/* 551 */     if (this.webServer.isStarted()) {
/* 552 */       throw new IOException("Failed to add ssl listener");
/*     */     }
/* 554 */     if (needCertsAuth)
/*     */     {
/* 556 */       System.setProperty("javax.net.ssl.trustStore", sslConf.get("ssl.server.truststore.location", ""));
/*     */ 
/* 558 */       System.setProperty("javax.net.ssl.trustStorePassword", sslConf.get("ssl.server.truststore.password", ""));
/*     */ 
/* 560 */       System.setProperty("javax.net.ssl.trustStoreType", sslConf.get("ssl.server.truststore.type", "jks"));
/*     */     }
/*     */     Krb5AndCertsSslSocketConnector.MODE mode;
/*     */     Krb5AndCertsSslSocketConnector.MODE mode;
/* 564 */     if ((needCertsAuth) && (needKrbAuth)) {
/* 565 */       mode = Krb5AndCertsSslSocketConnector.MODE.BOTH;
/*     */     }
/*     */     else
/*     */     {
/*     */       Krb5AndCertsSslSocketConnector.MODE mode;
/* 566 */       if ((!needCertsAuth) && (needKrbAuth))
/* 567 */         mode = Krb5AndCertsSslSocketConnector.MODE.KRB;
/*     */       else
/* 569 */         mode = Krb5AndCertsSslSocketConnector.MODE.CERTS;
/*     */     }
/* 571 */     SslSocketConnector sslListener = new Krb5AndCertsSslSocketConnector(mode);
/* 572 */     sslListener.setHost(addr.getHostName());
/* 573 */     sslListener.setPort(addr.getPort());
/* 574 */     sslListener.setKeystore(sslConf.get("ssl.server.keystore.location"));
/* 575 */     sslListener.setPassword(sslConf.get("ssl.server.keystore.password", ""));
/* 576 */     sslListener.setKeyPassword(sslConf.get("ssl.server.keystore.keypassword", ""));
/* 577 */     sslListener.setKeystoreType(sslConf.get("ssl.server.keystore.type", "jks"));
/* 578 */     sslListener.setNeedClientAuth(needCertsAuth);
/* 579 */     this.webServer.addConnector(sslListener);
/*     */   }
/*     */ 
/*     */   public void start()
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 587 */       if (this.listenerStartedExternally) {
/* 588 */         if (this.listener.getLocalPort() == -1) {
/* 589 */           throw new Exception("Exepected webserver's listener to be startedpreviously but wasn't");
/*     */         }
/*     */ 
/* 592 */         this.webServer.start();
/*     */       } else {
/* 594 */         int port = 0;
/* 595 */         int oriPort = this.listener.getPort();
/*     */         while (true) {
/*     */           try {
/* 598 */             port = this.webServer.getConnectors()[0].getLocalPort();
/* 599 */             LOG.info("Port returned by webServer.getConnectors()[0].getLocalPort() before open() is " + port + ". Opening the listener on " + oriPort);
/*     */ 
/* 602 */             this.listener.open();
/* 603 */             port = this.listener.getLocalPort();
/* 604 */             LOG.info("listener.getLocalPort() returned " + this.listener.getLocalPort() + " webServer.getConnectors()[0].getLocalPort() returned " + this.webServer.getConnectors()[0].getLocalPort());
/*     */ 
/* 608 */             if (port < 0) {
/* 609 */               Thread.sleep(100L);
/* 610 */               int numRetries = 1;
/* 611 */               if (port < 0) {
/* 612 */                 LOG.warn("listener.getLocalPort returned " + port);
/* 613 */                 if (numRetries++ > 10) {
/* 614 */                   throw new Exception(" listener.getLocalPort is returning less than 0 even after " + numRetries + " resets");
/*     */                 }
/*     */ 
/* 617 */                 int i = 0; if (i < 2) {
/* 618 */                   LOG.info("Retrying listener.getLocalPort()");
/* 619 */                   port = this.listener.getLocalPort();
/* 620 */                   if (port <= 0)
/*     */                   {
/* 623 */                     Thread.sleep(200L);
/*     */ 
/* 617 */                     i++; continue;
/*     */                   }
/*     */ 
/*     */                 }
/*     */ 
/* 625 */                 if (port <= 0)
/*     */                 {
/* 628 */                   LOG.info("Bouncing the listener");
/* 629 */                   this.listener.close();
/* 630 */                   Thread.sleep(1000L);
/* 631 */                   oriPort++; this.listener.setPort(oriPort == 0 ? 0 : oriPort);
/* 632 */                   this.listener.open();
/* 633 */                   Thread.sleep(100L);
/* 634 */                   port = this.listener.getLocalPort(); continue;
/*     */                 }
/*     */               }
/*     */             }
/* 637 */             LOG.info("Jetty bound to port " + port);
/* 638 */             this.webServer.start();
/*     */           }
/*     */           catch (IOException ex)
/*     */           {
/* 643 */             if ((ex instanceof BindException)) {
/* 644 */               if (!this.findPort)
/* 645 */                 throw ((BindException)ex);
/*     */             }
/*     */             else {
/* 648 */               LOG.info("HttpServer.start() threw a non Bind IOException");
/* 649 */               throw ex;
/*     */             }
/*     */           } catch (MultiException ex) {
/* 652 */             LOG.info("HttpServer.start() threw a MultiException");
/* 653 */             throw ex;
/*     */           }
/* 655 */           this.listener.setPort(++oriPort);
/*     */         }
/*     */       }
/*     */ 
/* 659 */       Handler[] handlers = this.webServer.getHandlers();
/* 660 */       for (int i = 0; i < handlers.length; i++) {
/* 661 */         if (handlers[i].isFailed()) {
/* 662 */           throw new IOException("Problem in starting http server. Server handlers failed");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 668 */       Throwable unavailableException = this.webAppContext.getUnavailableException();
/* 669 */       if (unavailableException != null)
/*     */       {
/* 672 */         this.webServer.stop();
/* 673 */         throw new IOException("Unable to initialize WebAppContext", unavailableException);
/*     */       }
/*     */     }
/*     */     catch (IOException e) {
/* 677 */       throw e;
/*     */     } catch (Exception e) {
/* 679 */       throw new IOException("Problem starting http server", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void stop()
/*     */     throws Exception
/*     */   {
/* 687 */     this.listener.close();
/* 688 */     this.webServer.stop();
/*     */   }
/*     */ 
/*     */   public void join() throws InterruptedException {
/* 692 */     this.webServer.join();
/*     */   }
/*     */ 
/*     */   public static boolean isInstrumentationAccessAllowed(ServletContext servletContext, HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException
/*     */   {
/* 713 */     Configuration conf = (Configuration)servletContext.getAttribute("hadoop.conf");
/*     */ 
/* 716 */     boolean access = true;
/* 717 */     boolean adminAccess = conf.getBoolean("hadoop.security.instrumentation.requires.admin", false);
/*     */ 
/* 720 */     if (adminAccess) {
/* 721 */       access = hasAdministratorAccess(servletContext, request, response);
/*     */     }
/* 723 */     return access;
/*     */   }
/*     */ 
/*     */   public static boolean hasAdministratorAccess(ServletContext servletContext, HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException
/*     */   {
/* 739 */     Configuration conf = (Configuration)servletContext.getAttribute("hadoop.conf");
/*     */ 
/* 743 */     if (!conf.getBoolean("hadoop.security.authorization", false))
/*     */     {
/* 745 */       return true;
/*     */     }
/*     */ 
/* 748 */     String remoteUser = request.getRemoteUser();
/* 749 */     if (remoteUser == null) {
/* 750 */       response.sendError(401, "Unauthenticated users are not authorized to access this page.");
/*     */ 
/* 753 */       return false;
/*     */     }
/* 755 */     AccessControlList adminsAcl = (AccessControlList)servletContext.getAttribute("admins.acl");
/*     */ 
/* 757 */     UserGroupInformation remoteUserUGI = UserGroupInformation.createRemoteUser(remoteUser);
/*     */ 
/* 759 */     if ((adminsAcl != null) && 
/* 760 */       (!adminsAcl.isUserAllowed(remoteUserUGI))) {
/* 761 */       response.sendError(401, "User " + remoteUser + " is unauthorized to access this page.");
/*     */ 
/* 763 */       return false;
/*     */     }
/*     */ 
/* 766 */     return true;
/*     */   }
/*     */ 
/*     */   public static class QuotingInputFilter
/*     */     implements Filter
/*     */   {
/*     */     private FilterConfig config;
/*     */ 
/*     */     public void init(FilterConfig config)
/*     */       throws ServletException
/*     */     {
/* 890 */       this.config = config;
/*     */     }
/*     */ 
/*     */     public void destroy()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */       throws IOException, ServletException
/*     */     {
/* 902 */       HttpServletRequestWrapper quoted = new RequestQuoter((HttpServletRequest)request);
/*     */ 
/* 904 */       HttpServletResponse httpResponse = (HttpServletResponse)response;
/*     */ 
/* 906 */       String mime = inferMimeType(request);
/* 907 */       if ((mime == null) || (mime.equals("text/html")))
/*     */       {
/* 912 */         httpResponse.setContentType("text/html; charset=utf-8");
/*     */       }
/* 914 */       chain.doFilter(quoted, httpResponse);
/*     */     }
/*     */ 
/*     */     private String inferMimeType(ServletRequest request)
/*     */     {
/* 922 */       String path = ((HttpServletRequest)request).getRequestURI();
/* 923 */       ContextHandler.SContext sContext = (ContextHandler.SContext)this.config.getServletContext();
/* 924 */       MimeTypes mimes = sContext.getContextHandler().getMimeTypes();
/* 925 */       Buffer mimeBuffer = mimes.getMimeByExtension(path);
/* 926 */       return mimeBuffer == null ? null : mimeBuffer.toString();
/*     */     }
/*     */ 
/*     */     public static class RequestQuoter extends HttpServletRequestWrapper
/*     */     {
/*     */       private final HttpServletRequest rawRequest;
/*     */ 
/*     */       public RequestQuoter(HttpServletRequest rawRequest)
/*     */       {
/* 807 */         super();
/* 808 */         this.rawRequest = rawRequest;
/*     */       }
/*     */ 
/*     */       public Enumeration<String> getParameterNames()
/*     */       {
/* 817 */         return new Enumeration() {
/* 818 */           private Enumeration<String> rawIterator = HttpServer.QuotingInputFilter.RequestQuoter.this.rawRequest.getParameterNames();
/*     */ 
/*     */           public boolean hasMoreElements()
/*     */           {
/* 822 */             return this.rawIterator.hasMoreElements();
/*     */           }
/*     */ 
/*     */           public String nextElement()
/*     */           {
/* 827 */             return HtmlQuoting.quoteHtmlChars((String)this.rawIterator.nextElement());
/*     */           }
/*     */         };
/*     */       }
/*     */ 
/*     */       public String getParameter(String name)
/*     */       {
/* 837 */         return HtmlQuoting.quoteHtmlChars(this.rawRequest.getParameter(HtmlQuoting.unquoteHtmlChars(name)));
/*     */       }
/*     */ 
/*     */       public String[] getParameterValues(String name)
/*     */       {
/* 843 */         String unquoteName = HtmlQuoting.unquoteHtmlChars(name);
/* 844 */         String[] unquoteValue = this.rawRequest.getParameterValues(unquoteName);
/* 845 */         String[] result = new String[unquoteValue.length];
/* 846 */         for (int i = 0; i < result.length; i++) {
/* 847 */           result[i] = HtmlQuoting.quoteHtmlChars(unquoteValue[i]);
/*     */         }
/* 849 */         return result;
/*     */       }
/*     */ 
/*     */       public Map<String, String[]> getParameterMap()
/*     */       {
/* 855 */         Map result = new HashMap();
/* 856 */         Map raw = this.rawRequest.getParameterMap();
/* 857 */         for (Map.Entry item : raw.entrySet()) {
/* 858 */           String[] rawValue = (String[])item.getValue();
/* 859 */           String[] cookedValue = new String[rawValue.length];
/* 860 */           for (int i = 0; i < rawValue.length; i++) {
/* 861 */             cookedValue[i] = HtmlQuoting.quoteHtmlChars(rawValue[i]);
/*     */           }
/* 863 */           result.put(HtmlQuoting.quoteHtmlChars((String)item.getKey()), cookedValue);
/*     */         }
/* 865 */         return result;
/*     */       }
/*     */ 
/*     */       public StringBuffer getRequestURL()
/*     */       {
/* 874 */         String url = this.rawRequest.getRequestURL().toString();
/* 875 */         return new StringBuffer(HtmlQuoting.quoteHtmlChars(url));
/*     */       }
/*     */ 
/*     */       public String getServerName()
/*     */       {
/* 884 */         return HtmlQuoting.quoteHtmlChars(this.rawRequest.getServerName());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class StackServlet extends HttpServlet
/*     */   {
/*     */     private static final long serialVersionUID = -6284183679759467039L;
/*     */ 
/*     */     public void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */       throws ServletException, IOException
/*     */     {
/* 783 */       if (!HttpServer.isInstrumentationAccessAllowed(getServletContext(), request, response))
/*     */       {
/* 785 */         return;
/*     */       }
/*     */ 
/* 788 */       PrintWriter out = new PrintWriter(HtmlQuoting.quoteOutputStream(response.getOutputStream()));
/*     */ 
/* 790 */       ReflectionUtils.printThreadInfo(out, "");
/* 791 */       out.close();
/* 792 */       ReflectionUtils.logThreadInfo(HttpServer.LOG, "jsp requested", 1L);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.http.HttpServer
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.http;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ public class HtmlQuoting
/*     */ {
/*  28 */   private static final byte[] ampBytes = "&amp;".getBytes();
/*  29 */   private static final byte[] aposBytes = "&apos;".getBytes();
/*  30 */   private static final byte[] gtBytes = "&gt;".getBytes();
/*  31 */   private static final byte[] ltBytes = "&lt;".getBytes();
/*  32 */   private static final byte[] quotBytes = "&quot;".getBytes();
/*     */ 
/*     */   public static boolean needsQuoting(byte[] data, int off, int len)
/*     */   {
/*  42 */     for (int i = off; i < off + len; i++) {
/*  43 */       switch (data[i]) {
/*     */       case 34:
/*     */       case 38:
/*     */       case 39:
/*     */       case 60:
/*     */       case 62:
/*  49 */         return true;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  54 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean needsQuoting(String str)
/*     */   {
/*  63 */     if (str == null) {
/*  64 */       return false;
/*     */     }
/*  66 */     byte[] bytes = str.getBytes();
/*  67 */     return needsQuoting(bytes, 0, bytes.length);
/*     */   }
/*     */ 
/*     */   public static void quoteHtmlChars(OutputStream output, byte[] buffer, int off, int len)
/*     */     throws IOException
/*     */   {
/*  80 */     for (int i = off; i < off + len; i++)
/*  81 */       switch (buffer[i]) { case 38:
/*  82 */         output.write(ampBytes); break;
/*     */       case 60:
/*  83 */         output.write(ltBytes); break;
/*     */       case 62:
/*  84 */         output.write(gtBytes); break;
/*     */       case 39:
/*  85 */         output.write(aposBytes); break;
/*     */       case 34:
/*  86 */         output.write(quotBytes); break;
/*     */       default:
/*  87 */         output.write(buffer, i, 1);
/*     */       }
/*     */   }
/*     */ 
/*     */   public static String quoteHtmlChars(String item)
/*     */   {
/*  98 */     if (item == null) {
/*  99 */       return null;
/*     */     }
/* 101 */     byte[] bytes = item.getBytes();
/* 102 */     if (needsQuoting(bytes, 0, bytes.length)) {
/* 103 */       ByteArrayOutputStream buffer = new ByteArrayOutputStream();
/*     */       try {
/* 105 */         quoteHtmlChars(buffer, bytes, 0, bytes.length);
/*     */       }
/*     */       catch (IOException ioe) {
/*     */       }
/* 109 */       return buffer.toString();
/*     */     }
/* 111 */     return item;
/*     */   }
/*     */ 
/*     */   public static OutputStream quoteOutputStream(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 123 */     return new OutputStream() {
/* 124 */       private byte[] data = new byte[1];
/*     */ 
/*     */       public void write(byte[] data, int off, int len) throws IOException {
/* 127 */         HtmlQuoting.quoteHtmlChars(this.val$out, data, off, len);
/*     */       }
/*     */ 
/*     */       public void write(int b) throws IOException
/*     */       {
/* 132 */         this.data[0] = (byte)b;
/* 133 */         HtmlQuoting.quoteHtmlChars(this.val$out, this.data, 0, 1);
/*     */       }
/*     */ 
/*     */       public void flush() throws IOException
/*     */       {
/* 138 */         this.val$out.flush();
/*     */       }
/*     */ 
/*     */       public void close() throws IOException
/*     */       {
/* 143 */         this.val$out.close();
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public static String unquoteHtmlChars(String item)
/*     */   {
/* 154 */     if (item == null) {
/* 155 */       return null;
/*     */     }
/* 157 */     int next = item.indexOf('&');
/*     */ 
/* 159 */     if (next == -1) {
/* 160 */       return item;
/*     */     }
/* 162 */     int len = item.length();
/* 163 */     int posn = 0;
/* 164 */     StringBuilder buffer = new StringBuilder();
/* 165 */     while (next != -1) {
/* 166 */       buffer.append(item.substring(posn, next));
/* 167 */       if (item.startsWith("&amp;", next)) {
/* 168 */         buffer.append('&');
/* 169 */         next += 5;
/* 170 */       } else if (item.startsWith("&apos;", next)) {
/* 171 */         buffer.append('\'');
/* 172 */         next += 6;
/* 173 */       } else if (item.startsWith("&gt;", next)) {
/* 174 */         buffer.append('>');
/* 175 */         next += 4;
/* 176 */       } else if (item.startsWith("&lt;", next)) {
/* 177 */         buffer.append('<');
/* 178 */         next += 4;
/* 179 */       } else if (item.startsWith("&quot;", next)) {
/* 180 */         buffer.append('"');
/* 181 */         next += 6;
/*     */       } else {
/* 183 */         int end = item.indexOf(';', next) + 1;
/* 184 */         if (end == 0) {
/* 185 */           end = len;
/*     */         }
/* 187 */         throw new IllegalArgumentException(new StringBuilder().append("Bad HTML quoting for ").append(item.substring(next, end)).toString());
/*     */       }
/*     */ 
/* 190 */       posn = next;
/* 191 */       next = item.indexOf('&', posn);
/*     */     }
/* 193 */     buffer.append(item.substring(posn, len));
/* 194 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception {
/* 198 */     for (String arg : args) {
/* 199 */       System.out.println(new StringBuilder().append("Original: ").append(arg).toString());
/* 200 */       String quoted = quoteHtmlChars(arg);
/* 201 */       System.out.println(new StringBuilder().append("Quoted: ").append(quoted).toString());
/* 202 */       String unquoted = unquoteHtmlChars(quoted);
/* 203 */       System.out.println(new StringBuilder().append("Unquoted: ").append(unquoted).toString());
/* 204 */       System.out.println();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.http.HtmlQuoting
 * JD-Core Version:    0.6.1
 */
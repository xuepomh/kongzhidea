package org.apache.hadoop;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({java.lang.annotation.ElementType.PACKAGE})
public @interface HadoopVersionAnnotation
{
  public abstract String version();

  public abstract String user();

  public abstract String date();

  public abstract String url();

  public abstract String revision();

  public abstract String srcChecksum();
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.HadoopVersionAnnotation
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.io.DataInputBuffer;
/*     */ import org.apache.hadoop.util.Progressable;
/*     */ 
/*     */ @Deprecated
/*     */ public class InMemoryFileSystem extends ChecksumFileSystem
/*     */ {
/*     */   public InMemoryFileSystem()
/*     */   {
/* 399 */     super(new RawInMemoryFileSystem());
/*     */   }
/*     */ 
/*     */   public InMemoryFileSystem(URI uri, Configuration conf) {
/* 403 */     super(new RawInMemoryFileSystem(uri, conf));
/*     */   }
/*     */ 
/*     */   public boolean reserveSpaceWithCheckSum(Path f, long size)
/*     */   {
/* 417 */     RawInMemoryFileSystem mfs = (RawInMemoryFileSystem)getRawFileSystem();
/* 418 */     synchronized (mfs) {
/* 419 */       boolean b = mfs.reserveSpace(f, size);
/* 420 */       if (b) {
/* 421 */         long checksumSize = getChecksumFileLength(f, size);
/* 422 */         b = mfs.reserveSpace(getChecksumFile(f), checksumSize);
/* 423 */         if (!b) {
/* 424 */           mfs.unreserveSpace(f);
/*     */         }
/*     */       }
/* 427 */       return b;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Path[] getFiles(PathFilter filter) {
/* 432 */     return ((RawInMemoryFileSystem)getRawFileSystem()).getFiles(filter);
/*     */   }
/*     */ 
/*     */   public int getNumFiles(PathFilter filter) {
/* 436 */     return ((RawInMemoryFileSystem)getRawFileSystem()).getNumFiles(filter);
/*     */   }
/*     */ 
/*     */   public long getFSSize() {
/* 440 */     return ((RawInMemoryFileSystem)getRawFileSystem()).getFSSize();
/*     */   }
/*     */ 
/*     */   public float getPercentUsed() {
/* 444 */     return ((RawInMemoryFileSystem)getRawFileSystem()).getPercentUsed();
/*     */   }
/*     */ 
/*     */   private static class RawInMemoryFileSystem extends FileSystem
/*     */   {
/*     */     private URI uri;
/*     */     private long fsSize;
/*     */     private volatile long totalUsed;
/*     */     private Path staticWorkingDir;
/*  47 */     private Map<String, FileAttributes> pathToFileAttribs = new HashMap();
/*     */ 
/*  54 */     private Map<String, FileAttributes> tempFileAttribs = new HashMap();
/*     */ 
/*     */     public RawInMemoryFileSystem()
/*     */     {
/*  58 */       setConf(new Configuration());
/*     */     }
/*     */ 
/*     */     public RawInMemoryFileSystem(URI uri, Configuration conf) {
/*  62 */       initialize(uri, conf);
/*     */     }
/*     */ 
/*     */     public void initialize(URI uri, Configuration conf)
/*     */     {
/*  67 */       setConf(conf);
/*  68 */       int size = Integer.parseInt(conf.get("fs.inmemory.size.mb", "100"));
/*  69 */       this.fsSize = (size * 1024L * 1024L);
/*  70 */       this.uri = URI.create(uri.getScheme() + "://" + uri.getAuthority());
/*  71 */       String path = this.uri.getPath();
/*  72 */       if (path.length() == 0) {
/*  73 */         path = ".";
/*     */       }
/*  75 */       this.staticWorkingDir = new Path(path);
/*  76 */       LOG.info("Initialized InMemoryFileSystem: " + uri.toString() + " of size (in bytes): " + this.fsSize);
/*     */     }
/*     */ 
/*     */     public URI getUri()
/*     */     {
/*  82 */       return this.uri;
/*     */     }
/*     */ 
/*     */     public FSDataInputStream open(Path f, int bufferSize)
/*     */       throws IOException
/*     */     {
/* 130 */       return new FSDataInputStream(new InMemoryInputStream(f));
/*     */     }
/*     */ 
/*     */     public FSDataOutputStream append(Path f, int bufferSize, Progressable progress)
/*     */       throws IOException
/*     */     {
/* 182 */       throw new IOException("Not supported");
/*     */     }
/*     */ 
/*     */     public FSDataOutputStream create(Path f, FsPermission permission, boolean overwrite, int bufferSize, short replication, long blockSize, Progressable progress)
/*     */       throws IOException
/*     */     {
/* 192 */       synchronized (this) {
/* 193 */         if ((exists(f)) && (!overwrite)) {
/* 194 */           throw new IOException("File already exists:" + f);
/*     */         }
/* 196 */         FileAttributes fAttr = (FileAttributes)this.tempFileAttribs.remove(getPath(f));
/* 197 */         if (fAttr != null)
/* 198 */           return create(f, fAttr);
/* 199 */         return null;
/*     */       }
/*     */     }
/*     */ 
/*     */     public FSDataOutputStream create(Path f, FileAttributes fAttr)
/*     */       throws IOException
/*     */     {
/* 209 */       return new FSDataOutputStream(new InMemoryOutputStream(f, fAttr), this.statistics);
/*     */     }
/*     */ 
/*     */     public void close() throws IOException
/*     */     {
/* 214 */       super.close();
/* 215 */       synchronized (this) {
/* 216 */         if (this.pathToFileAttribs != null) {
/* 217 */           this.pathToFileAttribs.clear();
/*     */         }
/* 219 */         this.pathToFileAttribs = null;
/* 220 */         if (this.tempFileAttribs != null) {
/* 221 */           this.tempFileAttribs.clear();
/*     */         }
/* 223 */         this.tempFileAttribs = null;
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean setReplication(Path src, short replication) throws IOException
/*     */     {
/* 229 */       return true;
/*     */     }
/*     */ 
/*     */     public boolean rename(Path src, Path dst) throws IOException {
/* 233 */       synchronized (this) {
/* 234 */         if (exists(dst)) {
/* 235 */           throw new IOException("Path " + dst + " already exists");
/*     */         }
/* 237 */         FileAttributes fAttr = (FileAttributes)this.pathToFileAttribs.remove(getPath(src));
/* 238 */         if (fAttr == null) return false;
/* 239 */         this.pathToFileAttribs.put(getPath(dst), fAttr);
/* 240 */         return true;
/*     */       }
/*     */     }
/*     */ 
/*     */     @Deprecated
/*     */     public boolean delete(Path f) throws IOException {
/* 246 */       return delete(f, true);
/*     */     }
/*     */ 
/*     */     public boolean delete(Path f, boolean recursive) throws IOException {
/* 250 */       synchronized (this) {
/* 251 */         FileAttributes fAttr = (FileAttributes)this.pathToFileAttribs.remove(getPath(f));
/* 252 */         if (fAttr != null) {
/* 253 */           fAttr.data = null;
/* 254 */           this.totalUsed -= fAttr.size;
/* 255 */           return true;
/*     */         }
/* 257 */         return false;
/*     */       }
/*     */     }
/*     */ 
/*     */     public FileStatus[] listStatus(Path f)
/*     */       throws IOException
/*     */     {
/* 265 */       return null;
/*     */     }
/*     */ 
/*     */     public void setWorkingDirectory(Path new_dir) {
/* 269 */       this.staticWorkingDir = new_dir;
/*     */     }
/*     */ 
/*     */     public Path getWorkingDirectory() {
/* 273 */       return this.staticWorkingDir;
/*     */     }
/*     */ 
/*     */     public boolean mkdirs(Path f, FsPermission permission)
/*     */       throws IOException
/*     */     {
/* 280 */       return true;
/*     */     }
/*     */ 
/*     */     public FileStatus getFileStatus(Path f) throws IOException {
/* 284 */       synchronized (this) {
/* 285 */         FileAttributes attr = (FileAttributes)this.pathToFileAttribs.get(getPath(f));
/* 286 */         if (attr == null) {
/* 287 */           throw new FileNotFoundException("File " + f + " does not exist.");
/*     */         }
/* 289 */         return new InMemoryFileStatus(f.makeQualified(this), attr);
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean reserveSpace(Path f, long size)
/*     */     {
/* 297 */       synchronized (this) {
/* 298 */         if (!canFitInMemory(size))
/* 299 */           return false;
/*     */         FileAttributes fileAttr;
/*     */         try {
/* 302 */           fileAttr = new FileAttributes((int)size);
/*     */         } catch (OutOfMemoryError o) {
/* 304 */           return false;
/*     */         }
/* 306 */         this.totalUsed += size;
/* 307 */         this.tempFileAttribs.put(getPath(f), fileAttr);
/* 308 */         return true;
/*     */       }
/*     */     }
/*     */ 
/* 312 */     public void unreserveSpace(Path f) { synchronized (this) {
/* 313 */         FileAttributes fAttr = (FileAttributes)this.tempFileAttribs.remove(getPath(f));
/* 314 */         if (fAttr != null) {
/* 315 */           fAttr.data = null;
/* 316 */           this.totalUsed -= fAttr.size;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public Path[] getFiles(PathFilter filter)
/*     */     {
/* 326 */       synchronized (this) {
/* 327 */         List closedFilesList = new ArrayList();
/* 328 */         synchronized (this.pathToFileAttribs) {
/* 329 */           Set paths = this.pathToFileAttribs.keySet();
/* 330 */           if ((paths == null) || (paths.isEmpty())) {
/* 331 */             return new Path[0];
/*     */           }
/* 333 */           Iterator iter = paths.iterator();
/* 334 */           while (iter.hasNext()) {
/* 335 */             String f = (String)iter.next();
/* 336 */             if (filter.accept(new Path(f))) {
/* 337 */               closedFilesList.add(f);
/*     */             }
/*     */           }
/*     */         }
/* 341 */         String[] names = (String[])closedFilesList.toArray(new String[closedFilesList.size()]);
/*     */ 
/* 343 */         Path[] results = new Path[names.length];
/* 344 */         for (int i = 0; i < names.length; i++) {
/* 345 */           results[i] = new Path(names[i]);
/*     */         }
/* 347 */         return results;
/*     */       }
/*     */     }
/*     */ 
/*     */     public int getNumFiles(PathFilter filter) {
/* 352 */       return getFiles(filter).length;
/*     */     }
/*     */ 
/*     */     public long getFSSize() {
/* 356 */       return this.fsSize;
/*     */     }
/*     */ 
/*     */     public float getPercentUsed() {
/* 360 */       if (this.fsSize > 0L)
/* 361 */         return (float)this.totalUsed / (float)this.fsSize;
/* 362 */       return 0.1F;
/*     */     }
/*     */ 
/*     */     private boolean canFitInMemory(long size)
/*     */     {
/* 371 */       if ((size <= 2147483647L) && (size + this.totalUsed < this.fsSize)) {
/* 372 */         return true;
/*     */       }
/* 374 */       return false;
/*     */     }
/*     */ 
/*     */     private String getPath(Path f) {
/* 378 */       return f.toUri().getPath();
/*     */     }
/*     */ 
/*     */     private class InMemoryFileStatus extends FileStatus
/*     */     {
/*     */       InMemoryFileStatus(Path f, InMemoryFileSystem.RawInMemoryFileSystem.FileAttributes attr)
/*     */         throws IOException
/*     */       {
/* 393 */         super(false, 1, InMemoryFileSystem.RawInMemoryFileSystem.this.getDefaultBlockSize(), 0L, f);
/*     */       }
/*     */     }
/*     */ 
/*     */     private static class FileAttributes
/*     */     {
/*     */       private byte[] data;
/*     */       private int size;
/*     */ 
/*     */       public FileAttributes(int size)
/*     */       {
/* 386 */         this.size = size;
/* 387 */         this.data = new byte[size];
/*     */       }
/*     */     }
/*     */ 
/*     */     private class InMemoryOutputStream extends OutputStream
/*     */     {
/*     */       private int count;
/*     */       private InMemoryFileSystem.RawInMemoryFileSystem.FileAttributes fAttr;
/*     */       private Path f;
/*     */ 
/*     */       public InMemoryOutputStream(Path f, InMemoryFileSystem.RawInMemoryFileSystem.FileAttributes fAttr)
/*     */         throws IOException
/*     */       {
/* 140 */         this.fAttr = fAttr;
/* 141 */         this.f = f;
/*     */       }
/*     */ 
/*     */       public long getPos() throws IOException {
/* 145 */         return this.count;
/*     */       }
/*     */ 
/*     */       public void close() throws IOException {
/* 149 */         synchronized (InMemoryFileSystem.RawInMemoryFileSystem.this) {
/* 150 */           InMemoryFileSystem.RawInMemoryFileSystem.this.pathToFileAttribs.put(InMemoryFileSystem.RawInMemoryFileSystem.this.getPath(this.f), this.fAttr);
/*     */         }
/*     */       }
/*     */ 
/*     */       public void write(byte[] b, int off, int len) throws IOException {
/* 155 */         if ((off < 0) || (off > b.length) || (len < 0) || (off + len > b.length) || (off + len < 0))
/*     */         {
/* 157 */           throw new IndexOutOfBoundsException();
/* 158 */         }if (len == 0) {
/* 159 */           return;
/*     */         }
/* 161 */         int newcount = this.count + len;
/* 162 */         if (newcount > this.fAttr.size) {
/* 163 */           throw new IOException("Insufficient space");
/*     */         }
/* 165 */         System.arraycopy(b, off, this.fAttr.data, this.count, len);
/* 166 */         this.count = newcount;
/*     */       }
/*     */ 
/*     */       public void write(int b) throws IOException {
/* 170 */         int newcount = this.count + 1;
/* 171 */         if (newcount > this.fAttr.size) {
/* 172 */           throw new IOException("Insufficient space");
/*     */         }
/* 174 */         this.fAttr.data[this.count] = (byte)b;
/* 175 */         this.count = newcount;
/*     */       }
/*     */     }
/*     */ 
/*     */     private class InMemoryInputStream extends FSInputStream
/*     */     {
/*  86 */       private DataInputBuffer din = new DataInputBuffer();
/*     */       private InMemoryFileSystem.RawInMemoryFileSystem.FileAttributes fAttr;
/*     */ 
/*     */       public InMemoryInputStream(Path f)
/*     */         throws IOException
/*     */       {
/*  90 */         synchronized (InMemoryFileSystem.RawInMemoryFileSystem.this) {
/*  91 */           this.fAttr = ((InMemoryFileSystem.RawInMemoryFileSystem.FileAttributes)InMemoryFileSystem.RawInMemoryFileSystem.this.pathToFileAttribs.get(InMemoryFileSystem.RawInMemoryFileSystem.this.getPath(f)));
/*  92 */           if (this.fAttr == null) {
/*  93 */             throw new FileNotFoundException("File " + f + " does not exist");
/*     */           }
/*  95 */           this.din.reset(this.fAttr.data, 0, this.fAttr.size);
/*     */         }
/*     */       }
/*     */ 
/*     */       public long getPos() throws IOException {
/* 100 */         return this.din.getPosition();
/*     */       }
/*     */ 
/*     */       public void seek(long pos) throws IOException {
/* 104 */         if ((int)pos > this.fAttr.size)
/* 105 */           throw new IOException("Cannot seek after EOF");
/* 106 */         this.din.reset(this.fAttr.data, (int)pos, this.fAttr.size - (int)pos);
/*     */       }
/*     */ 
/*     */       public boolean seekToNewSource(long targetPos) throws IOException {
/* 110 */         return false;
/*     */       }
/*     */ 
/*     */       public int available() throws IOException {
/* 114 */         return this.din.available();
/*     */       }
/* 116 */       public boolean markSupport() { return false; }
/*     */ 
/*     */       public int read() throws IOException {
/* 119 */         return this.din.read();
/*     */       }
/*     */ 
/*     */       public int read(byte[] b, int off, int len) throws IOException {
/* 123 */         return this.din.read(b, off, len);
/*     */       }
/*     */       public long skip(long n) throws IOException {
/* 126 */         return this.din.skip(n);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.InMemoryFileSystem
 * JD-Core Version:    0.6.1
 */
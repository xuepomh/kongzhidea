/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.util.Shell;
/*     */ 
/*     */ public class DU extends Shell
/*     */ {
/*     */   private String dirPath;
/*  32 */   private AtomicLong used = new AtomicLong();
/*  33 */   private volatile boolean shouldRun = true;
/*     */   private Thread refreshUsed;
/*  35 */   private IOException duException = null;
/*     */   private long refreshInterval;
/*     */ 
/*     */   public DU(File path, long interval)
/*     */     throws IOException
/*     */   {
/*  45 */     super(0L);
/*     */ 
/*  49 */     this.refreshInterval = interval;
/*  50 */     this.dirPath = path.getCanonicalPath();
/*     */ 
/*  53 */     run();
/*     */   }
/*     */ 
/*     */   public DU(File path, Configuration conf)
/*     */     throws IOException
/*     */   {
/*  63 */     this(path, 600000L);
/*     */   }
/*     */ 
/*     */   public void decDfsUsed(long value)
/*     */   {
/* 104 */     this.used.addAndGet(-value);
/*     */   }
/*     */ 
/*     */   public void incDfsUsed(long value)
/*     */   {
/* 112 */     this.used.addAndGet(value);
/*     */   }
/*     */ 
/*     */   public long getUsed()
/*     */     throws IOException
/*     */   {
/* 121 */     if (this.refreshUsed == null)
/* 122 */       run();
/*     */     else {
/* 124 */       synchronized (this)
/*     */       {
/* 126 */         if (this.duException != null) {
/* 127 */           IOException tmp = this.duException;
/* 128 */           this.duException = null;
/* 129 */           throw tmp;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 134 */     return this.used.longValue();
/*     */   }
/*     */ 
/*     */   public String getDirPath()
/*     */   {
/* 141 */     return this.dirPath;
/*     */   }
/*     */ 
/*     */   public void start()
/*     */   {
/* 149 */     if (this.refreshInterval > 0L) {
/* 150 */       this.refreshUsed = new Thread(new DURefreshThread(), "refreshUsed-" + this.dirPath);
/*     */ 
/* 152 */       this.refreshUsed.setDaemon(true);
/* 153 */       this.refreshUsed.start();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void shutdown()
/*     */   {
/* 161 */     this.shouldRun = false;
/*     */ 
/* 163 */     if (this.refreshUsed != null)
/* 164 */       this.refreshUsed.interrupt();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 169 */     return "du -sk " + this.dirPath + "\n" + this.used + "\t" + this.dirPath;
/*     */   }
/*     */ 
/*     */   protected String[] getExecString()
/*     */   {
/* 175 */     return new String[] { "du", "-sk", this.dirPath };
/*     */   }
/*     */ 
/*     */   protected void parseExecResult(BufferedReader lines) throws IOException {
/* 179 */     String line = lines.readLine();
/* 180 */     if (line == null) {
/* 181 */       throw new IOException("Expecting a line not the end of stream");
/*     */     }
/* 183 */     String[] tokens = line.split("\t");
/* 184 */     if (tokens.length == 0) {
/* 185 */       throw new IOException("Illegal du output");
/*     */     }
/* 187 */     this.used.set(Long.parseLong(tokens[0]) * 1024L);
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception {
/* 191 */     String path = ".";
/* 192 */     if (args.length > 0) {
/* 193 */       path = args[0];
/*     */     }
/*     */ 
/* 196 */     System.out.println(new DU(new File(path), new Configuration()).toString());
/*     */   }
/*     */ 
/*     */   class DURefreshThread
/*     */     implements Runnable
/*     */   {
/*     */     DURefreshThread()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/*  77 */       while (DU.this.shouldRun)
/*     */         try
/*     */         {
/*  80 */           Thread.sleep(DU.this.refreshInterval);
/*     */           try
/*     */           {
/*  84 */             DU.this.run();
/*     */           } catch (IOException e) {
/*  86 */             synchronized (DU.this)
/*     */             {
/*  88 */               DU.this.duException = e;
/*     */             }
/*     */ 
/*  91 */             Shell.LOG.warn("Could not get disk usage information", e);
/*     */           }
/*     */         }
/*     */         catch (InterruptedException e)
/*     */         {
/*     */         }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.DU
 * JD-Core Version:    0.6.1
 */
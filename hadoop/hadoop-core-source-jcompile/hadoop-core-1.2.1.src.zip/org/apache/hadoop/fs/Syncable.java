package org.apache.hadoop.fs;

import java.io.IOException;

public abstract interface Syncable
{
  public abstract void sync()
    throws IOException;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.Syncable
 * JD-Core Version:    0.6.1
 */
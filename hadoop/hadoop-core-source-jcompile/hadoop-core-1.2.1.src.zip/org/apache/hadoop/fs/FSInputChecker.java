/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.zip.Checksum;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ public abstract class FSInputChecker extends FSInputStream
/*     */ {
/*  34 */   public static final Log LOG = LogFactory.getLog(FSInputChecker.class);
/*     */   protected Path file;
/*     */   private Checksum sum;
/*  40 */   private boolean verifyChecksum = true;
/*     */   private byte[] buf;
/*     */   private byte[] checksum;
/*     */   private int pos;
/*     */   private int count;
/*     */   private int numOfRetries;
/*  49 */   private long chunkPos = 0L;
/*     */ 
/*     */   protected FSInputChecker(Path file, int numOfRetries)
/*     */   {
/*  57 */     this.file = file;
/*  58 */     this.numOfRetries = numOfRetries;
/*     */   }
/*     */ 
/*     */   protected FSInputChecker(Path file, int numOfRetries, boolean verifyChecksum, Checksum sum, int chunkSize, int checksumSize)
/*     */   {
/*  71 */     this(file, numOfRetries);
/*  72 */     set(verifyChecksum, sum, chunkSize, checksumSize);
/*     */   }
/*     */ 
/*     */   protected abstract int readChunk(long paramLong, byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2)
/*     */     throws IOException;
/*     */ 
/*     */   protected abstract long getChunkPosition(long paramLong);
/*     */ 
/*     */   protected synchronized boolean needChecksum()
/*     */   {
/*  97 */     return (this.verifyChecksum) && (this.sum != null);
/*     */   }
/*     */ 
/*     */   public synchronized int read()
/*     */     throws IOException
/*     */   {
/* 109 */     if (this.pos >= this.count) {
/* 110 */       fill();
/* 111 */       if (this.pos >= this.count) {
/* 112 */         return -1;
/*     */       }
/*     */     }
/* 115 */     return this.buf[(this.pos++)] & 0xFF;
/*     */   }
/*     */ 
/*     */   public synchronized int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 150 */     if ((off | len | off + len | b.length - (off + len)) < 0)
/* 151 */       throw new IndexOutOfBoundsException();
/* 152 */     if (len == 0) {
/* 153 */       return 0;
/*     */     }
/*     */ 
/* 156 */     int n = 0;
/*     */     while (true) {
/* 158 */       int nread = read1(b, off + n, len - n);
/* 159 */       if (nread <= 0)
/* 160 */         return n == 0 ? nread : n;
/* 161 */       n += nread;
/* 162 */       if (n >= len)
/* 163 */         return n;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void fill()
/*     */     throws IOException
/*     */   {
/* 174 */     assert (this.pos >= this.count);
/*     */ 
/* 176 */     this.count = readChecksumChunk(this.buf, 0, this.buf.length);
/*     */   }
/*     */ 
/*     */   private int read1(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 185 */     int avail = this.count - this.pos;
/* 186 */     if (avail <= 0) {
/* 187 */       if (len >= this.buf.length)
/*     */       {
/* 189 */         int nread = readChecksumChunk(b, off, len);
/* 190 */         return nread;
/*     */       }
/*     */ 
/* 193 */       fill();
/* 194 */       if (this.count <= 0) {
/* 195 */         return -1;
/*     */       }
/* 197 */       avail = this.count;
/*     */     }
/*     */ 
/* 203 */     int cnt = avail < len ? avail : len;
/* 204 */     System.arraycopy(this.buf, this.pos, b, off, cnt);
/* 205 */     this.pos += cnt;
/* 206 */     return cnt;
/*     */   }
/*     */ 
/*     */   private int readChecksumChunk(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 228 */     this.count = (this.pos = 0);
/*     */ 
/* 230 */     int read = 0;
/* 231 */     boolean retry = true;
/* 232 */     int retriesLeft = this.numOfRetries;
/*     */     do {
/* 234 */       retriesLeft--;
/*     */       try
/*     */       {
/* 237 */         read = readChunk(this.chunkPos, b, off, len, this.checksum);
/* 238 */         if (read > 0) {
/* 239 */           if (needChecksum()) {
/* 240 */             this.sum.update(b, off, read);
/* 241 */             verifySum(this.chunkPos);
/*     */           }
/* 243 */           this.chunkPos += read;
/*     */         }
/* 245 */         retry = false;
/*     */       } catch (ChecksumException ce) {
/* 247 */         LOG.info("Found checksum error: b[" + off + ", " + (off + read) + "]=" + StringUtils.byteToHexString(b, off, off + read), ce);
/*     */ 
/* 249 */         if (retriesLeft == 0) {
/* 250 */           throw ce;
/*     */         }
/*     */ 
/* 254 */         if (seekToNewSource(this.chunkPos))
/*     */         {
/* 257 */           seek(this.chunkPos);
/*     */         }
/*     */         else
/*     */         {
/* 262 */           throw ce;
/*     */         }
/*     */       }
/*     */     }
/* 265 */     while (retry);
/* 266 */     return read;
/*     */   }
/*     */ 
/*     */   private void verifySum(long errPos)
/*     */     throws ChecksumException
/*     */   {
/* 273 */     long crc = getChecksum();
/* 274 */     long sumValue = this.sum.getValue();
/* 275 */     this.sum.reset();
/* 276 */     if (crc != sumValue)
/* 277 */       throw new ChecksumException("Checksum error: " + this.file + " at " + errPos, errPos);
/*     */   }
/*     */ 
/*     */   private long getChecksum()
/*     */   {
/* 284 */     return checksum2long(this.checksum);
/*     */   }
/*     */ 
/*     */   public static long checksum2long(byte[] checksum)
/*     */   {
/* 289 */     long crc = 0L;
/* 290 */     for (int i = 0; i < checksum.length; i++) {
/* 291 */       crc |= (0xFF & checksum[i]) << (checksum.length - i - 1) * 8;
/*     */     }
/* 293 */     return crc;
/*     */   }
/*     */ 
/*     */   public synchronized long getPos() throws IOException
/*     */   {
/* 298 */     return this.chunkPos - Math.max(0L, this.count - this.pos);
/*     */   }
/*     */ 
/*     */   public synchronized int available() throws IOException
/*     */   {
/* 303 */     return Math.max(0, this.count - this.pos);
/*     */   }
/*     */ 
/*     */   public synchronized long skip(long n)
/*     */     throws IOException
/*     */   {
/* 324 */     if (n <= 0L) {
/* 325 */       return 0L;
/*     */     }
/*     */ 
/* 328 */     seek(getPos() + n);
/* 329 */     return n;
/*     */   }
/*     */ 
/*     */   public synchronized void seek(long pos)
/*     */     throws IOException
/*     */   {
/* 346 */     if (pos < 0L) {
/* 347 */       return;
/*     */     }
/*     */ 
/* 350 */     long start = this.chunkPos - this.count;
/* 351 */     if ((pos >= start) && (pos < this.chunkPos)) {
/* 352 */       this.pos = (int)(pos - start);
/* 353 */       return;
/*     */     }
/*     */ 
/* 357 */     resetState();
/*     */ 
/* 360 */     this.chunkPos = getChunkPosition(pos);
/*     */ 
/* 363 */     int delta = (int)(pos - this.chunkPos);
/* 364 */     if (delta > 0)
/* 365 */       readFully(this, new byte[delta], 0, delta);
/*     */   }
/*     */ 
/*     */   protected static int readFully(InputStream stm, byte[] buf, int offset, int len)
/*     */     throws IOException
/*     */   {
/* 382 */     int n = 0;
/*     */     while (true) {
/* 384 */       int nread = stm.read(buf, offset + n, len - n);
/* 385 */       if (nread <= 0)
/* 386 */         return n == 0 ? nread : n;
/* 387 */       n += nread;
/* 388 */       if (n >= len)
/* 389 */         return n;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected final synchronized void set(boolean verifyChecksum, Checksum sum, int maxChunkSize, int checksumSize)
/*     */   {
/* 402 */     this.verifyChecksum = verifyChecksum;
/* 403 */     this.sum = sum;
/* 404 */     this.buf = new byte[maxChunkSize];
/* 405 */     this.checksum = new byte[checksumSize];
/* 406 */     this.count = 0;
/* 407 */     this.pos = 0;
/*     */   }
/*     */ 
/*     */   public final boolean markSupported() {
/* 411 */     return false;
/*     */   }
/*     */ 
/*     */   public final void mark(int readlimit) {
/*     */   }
/*     */ 
/*     */   public final void reset() throws IOException {
/* 418 */     throw new IOException("mark/reset not supported");
/*     */   }
/*     */ 
/*     */   private void resetState()
/*     */   {
/* 425 */     this.count = 0;
/* 426 */     this.pos = 0;
/*     */ 
/* 428 */     if (this.sum != null)
/* 429 */       this.sum.reset();
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.FSInputChecker
 * JD-Core Version:    0.6.1
 */
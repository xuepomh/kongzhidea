/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.util.Shell;
/*     */ 
/*     */ public class DF extends Shell
/*     */ {
/*     */   public static final long DF_INTERVAL_DEFAULT = 3000L;
/*     */   private final String dirPath;
/*     */   private final File dirFile;
/*     */   private String filesystem;
/*     */   private String mount;
/*     */ 
/*     */   public DF(File path, Configuration conf)
/*     */     throws IOException
/*     */   {
/*  45 */     this(path, conf.getLong("dfs.df.interval", 3000L));
/*     */   }
/*     */ 
/*     */   public DF(File path, long dfInterval) throws IOException {
/*  49 */     super(dfInterval);
/*  50 */     this.dirPath = path.getCanonicalPath();
/*  51 */     this.dirFile = path.getCanonicalFile();
/*     */   }
/*     */ 
/*     */   public String getDirPath()
/*     */   {
/*  58 */     return this.dirPath;
/*     */   }
/*     */ 
/*     */   public String getFilesystem() throws IOException
/*     */   {
/*  63 */     run();
/*  64 */     return this.filesystem;
/*     */   }
/*     */ 
/*     */   public long getCapacity()
/*     */   {
/*  69 */     return this.dirFile.getTotalSpace();
/*     */   }
/*     */ 
/*     */   public long getUsed()
/*     */   {
/*  74 */     return this.dirFile.getTotalSpace() - this.dirFile.getFreeSpace();
/*     */   }
/*     */ 
/*     */   public long getAvailable()
/*     */   {
/*  79 */     return this.dirFile.getUsableSpace();
/*     */   }
/*     */ 
/*     */   public int getPercentUsed()
/*     */   {
/*  84 */     double cap = getCapacity();
/*  85 */     double used = cap - getAvailable();
/*  86 */     return (int)(used * 100.0D / cap);
/*     */   }
/*     */ 
/*     */   public String getMount() throws IOException
/*     */   {
/*  91 */     run();
/*  92 */     return this.mount;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  96 */     return "df -k " + this.mount + "\n" + this.filesystem + "\t" + getCapacity() / 1024L + "\t" + getUsed() / 1024L + "\t" + getAvailable() / 1024L + "\t" + getPercentUsed() + "%\t" + this.mount;
/*     */   }
/*     */ 
/*     */   protected String[] getExecString()
/*     */   {
/* 108 */     return new String[] { "bash", "-c", "exec 'df' '-k' '" + this.dirPath + "' 2>/dev/null" };
/*     */   }
/*     */ 
/*     */   protected void parseExecResult(BufferedReader lines) throws IOException
/*     */   {
/* 113 */     lines.readLine();
/*     */ 
/* 115 */     String line = lines.readLine();
/* 116 */     if (line == null) {
/* 117 */       throw new IOException("Expecting a line not the end of stream");
/*     */     }
/* 119 */     StringTokenizer tokens = new StringTokenizer(line, " \t\n\r\f%");
/*     */ 
/* 122 */     this.filesystem = tokens.nextToken();
/* 123 */     if (!tokens.hasMoreTokens()) {
/* 124 */       line = lines.readLine();
/* 125 */       if (line == null) {
/* 126 */         throw new IOException("Expecting a line not the end of stream");
/*     */       }
/* 128 */       tokens = new StringTokenizer(line, " \t\n\r\f%");
/*     */     }
/* 130 */     Long.parseLong(tokens.nextToken());
/* 131 */     Long.parseLong(tokens.nextToken());
/* 132 */     Long.parseLong(tokens.nextToken());
/* 133 */     Integer.parseInt(tokens.nextToken());
/* 134 */     this.mount = tokens.nextToken();
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception {
/* 138 */     String path = ".";
/* 139 */     if (args.length > 0) {
/* 140 */       path = args[0];
/*     */     }
/* 142 */     System.out.println(new DF(new File(path), 3000L).toString());
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.DF
 * JD-Core Version:    0.6.1
 */
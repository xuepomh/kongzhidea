/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.FileDescriptor;
/*     */ import java.io.IOException;
/*     */ 
/*     */ public class BufferedFSInputStream extends BufferedInputStream
/*     */   implements Seekable, PositionedReadable, HasFileDescriptor
/*     */ {
/*     */   public BufferedFSInputStream(FSInputStream in, int size)
/*     */   {
/*  46 */     super(in, size);
/*     */   }
/*     */ 
/*     */   public long getPos() throws IOException {
/*  50 */     return ((FSInputStream)this.in).getPos() - this.count - this.pos;
/*     */   }
/*     */ 
/*     */   public long skip(long n) throws IOException {
/*  54 */     if (n <= 0L) {
/*  55 */       return 0L;
/*     */     }
/*     */ 
/*  58 */     seek(getPos() + n);
/*  59 */     return n;
/*     */   }
/*     */ 
/*     */   public void seek(long pos) throws IOException {
/*  63 */     if (pos < 0L) {
/*  64 */       return;
/*     */     }
/*     */ 
/*  67 */     long end = ((FSInputStream)this.in).getPos();
/*  68 */     long start = end - this.count;
/*  69 */     if ((pos >= start) && (pos < end)) {
/*  70 */       this.pos = (int)(pos - start);
/*  71 */       return;
/*     */     }
/*     */ 
/*  75 */     this.pos = 0;
/*  76 */     this.count = 0;
/*     */ 
/*  78 */     ((FSInputStream)this.in).seek(pos);
/*     */   }
/*     */ 
/*     */   public boolean seekToNewSource(long targetPos) throws IOException {
/*  82 */     this.pos = 0;
/*  83 */     this.count = 0;
/*  84 */     return ((FSInputStream)this.in).seekToNewSource(targetPos);
/*     */   }
/*     */ 
/*     */   public int read(long position, byte[] buffer, int offset, int length) throws IOException {
/*  88 */     return ((FSInputStream)this.in).read(position, buffer, offset, length);
/*     */   }
/*     */ 
/*     */   public void readFully(long position, byte[] buffer, int offset, int length) throws IOException {
/*  92 */     ((FSInputStream)this.in).readFully(position, buffer, offset, length);
/*     */   }
/*     */ 
/*     */   public void readFully(long position, byte[] buffer) throws IOException {
/*  96 */     ((FSInputStream)this.in).readFully(position, buffer);
/*     */   }
/*     */ 
/*     */   public FileDescriptor getFileDescriptor() throws IOException
/*     */   {
/* 101 */     if ((this.in instanceof HasFileDescriptor)) {
/* 102 */       return ((HasFileDescriptor)this.in).getFileDescriptor();
/*     */     }
/* 104 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.BufferedFSInputStream
 * JD-Core Version:    0.6.1
 */
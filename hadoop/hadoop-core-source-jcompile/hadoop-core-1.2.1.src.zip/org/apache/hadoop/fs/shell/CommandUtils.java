/*    */ package org.apache.hadoop.fs.shell;
/*    */ 
/*    */ final class CommandUtils
/*    */ {
/*    */   static String formatDescription(String usage, String[] desciptions)
/*    */   {
/* 22 */     StringBuilder b = new StringBuilder(new StringBuilder().append(usage).append(": ").append(desciptions[0]).toString());
/* 23 */     for (int i = 1; i < desciptions.length; i++) {
/* 24 */       b.append(new StringBuilder().append("\n\t\t").append(desciptions[i]).toString());
/*    */     }
/* 26 */     return b.toString();
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.shell.CommandUtils
 * JD-Core Version:    0.6.1
 */
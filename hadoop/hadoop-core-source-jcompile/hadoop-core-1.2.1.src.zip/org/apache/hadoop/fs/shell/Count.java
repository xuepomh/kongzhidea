/*    */ package org.apache.hadoop.fs.shell;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.util.List;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ import org.apache.hadoop.fs.ContentSummary;
/*    */ import org.apache.hadoop.fs.FileSystem;
/*    */ import org.apache.hadoop.fs.Path;
/*    */ 
/*    */ public class Count extends Command
/*    */ {
/*    */   public static final String NAME = "count";
/*    */   public static final String USAGE = "-count[-q] <path>";
/* 33 */   public static final String DESCRIPTION = CommandUtils.formatDescription("-count[-q] <path>", new String[] { "Count the number of directories, files and bytes under the paths", "that match the specified file pattern.  The output columns are:", "DIR_COUNT FILE_COUNT CONTENT_SIZE FILE_NAME or", "QUOTA REMAINING_QUATA SPACE_QUOTA REMAINING_SPACE_QUOTA ", "      DIR_COUNT FILE_COUNT CONTENT_SIZE FILE_NAME" });
/*    */   private boolean qOption;
/*    */ 
/*    */   public Count(String[] cmd, int pos, Configuration conf)
/*    */   {
/* 48 */     super(conf);
/* 49 */     CommandFormat c = new CommandFormat("count", 1, 2147483647, new String[] { "q" });
/* 50 */     List parameters = c.parse(cmd, pos);
/* 51 */     this.args = ((String[])parameters.toArray(new String[parameters.size()]));
/* 52 */     if (this.args.length == 0) {
/* 53 */       this.args = new String[] { "." };
/*    */     }
/* 55 */     this.qOption = (c.getOpt("q"));
/*    */   }
/*    */ 
/*    */   public static boolean matches(String cmd)
/*    */   {
/* 64 */     return "-count".equals(cmd);
/*    */   }
/*    */ 
/*    */   public String getCommandName()
/*    */   {
/* 69 */     return "count";
/*    */   }
/*    */ 
/*    */   protected void run(Path path) throws IOException
/*    */   {
/* 74 */     FileSystem fs = path.getFileSystem(getConf());
/* 75 */     System.out.println(fs.getContentSummary(path).toString(this.qOption) + path);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.shell.Count
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.fs.shell;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ import org.apache.hadoop.conf.Configured;
/*    */ import org.apache.hadoop.fs.FileStatus;
/*    */ import org.apache.hadoop.fs.FileSystem;
/*    */ import org.apache.hadoop.fs.Path;
/*    */ import org.apache.hadoop.ipc.RemoteException;
/*    */ 
/*    */ public abstract class Command extends Configured
/*    */ {
/*    */   protected String[] args;
/*    */ 
/*    */   protected Command(Configuration conf)
/*    */   {
/* 37 */     super(conf);
/*    */   }
/*    */ 
/*    */   public abstract String getCommandName();
/*    */ 
/*    */   protected abstract void run(Path paramPath)
/*    */     throws IOException;
/*    */ 
/*    */   public int runAll()
/*    */   {
/* 57 */     int exitCode = 0;
/* 58 */     for (String src : this.args) {
/*    */       try {
/* 60 */         Path srcPath = new Path(src);
/* 61 */         FileSystem fs = srcPath.getFileSystem(getConf());
/* 62 */         FileStatus[] statuses = fs.globStatus(srcPath);
/* 63 */         if (statuses == null) {
/* 64 */           System.err.println("Can not find listing for " + src);
/* 65 */           exitCode = -1;
/*    */         } else {
/* 67 */           for (FileStatus s : statuses)
/* 68 */             run(s.getPath());
/*    */         }
/*    */       }
/*    */       catch (RemoteException re) {
/* 72 */         exitCode = -1;
/* 73 */         String content = re.getLocalizedMessage();
/* 74 */         int eol = content.indexOf('\n');
/* 75 */         if (eol >= 0) {
/* 76 */           content = content.substring(0, eol);
/*    */         }
/* 78 */         System.err.println(getCommandName() + ": " + content);
/*    */       } catch (IOException e) {
/* 80 */         exitCode = -1;
/* 81 */         System.err.println(getCommandName() + ": " + e.getLocalizedMessage());
/*    */       }
/*    */     }
/* 84 */     return exitCode;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.shell.Command
 * JD-Core Version:    0.6.1
 */
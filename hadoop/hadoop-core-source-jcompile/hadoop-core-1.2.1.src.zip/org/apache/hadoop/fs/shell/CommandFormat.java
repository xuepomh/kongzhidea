/*    */ package org.apache.hadoop.fs.shell;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class CommandFormat
/*    */ {
/*    */   final String name;
/*    */   final int minPar;
/*    */   final int maxPar;
/* 31 */   final Map<String, Boolean> options = new HashMap();
/*    */ 
/*    */   public CommandFormat(String n, int min, int max, String[] possibleOpt)
/*    */   {
/* 35 */     this.name = n;
/* 36 */     this.minPar = min;
/* 37 */     this.maxPar = max;
/* 38 */     for (String opt : possibleOpt)
/* 39 */       this.options.put(opt, Boolean.FALSE);
/*    */   }
/*    */ 
/*    */   public List<String> parse(String[] args, int pos)
/*    */   {
/* 49 */     List parameters = new ArrayList();
/* 50 */     for (; pos < args.length; pos++)
/* 51 */       if ((args[pos].charAt(0) == '-') && (args[pos].length() > 1)) {
/* 52 */         String opt = args[pos].substring(1);
/* 53 */         if (this.options.containsKey(opt))
/* 54 */           this.options.put(opt, Boolean.TRUE);
/*    */         else
/* 56 */           throw new IllegalArgumentException("Illegal option " + args[pos]);
/*    */       }
/*    */       else {
/* 59 */         parameters.add(args[pos]);
/*    */       }
/* 61 */     int psize = parameters.size();
/* 62 */     if ((psize < this.minPar) || (psize > this.maxPar))
/* 63 */       throw new IllegalArgumentException("Illegal number of arguments");
/* 64 */     return parameters;
/*    */   }
/*    */ 
/*    */   public boolean getOpt(String option)
/*    */   {
/* 73 */     return ((Boolean)this.options.get(option)).booleanValue();
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.shell.CommandFormat
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.fs.kfs;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.nio.ByteBuffer;
/*    */ import org.kosmix.kosmosfs.access.KfsAccess;
/*    */ import org.kosmix.kosmosfs.access.KfsOutputChannel;
/*    */ 
/*    */ class KFSOutputStream extends OutputStream
/*    */ {
/*    */   private String path;
/*    */   private KfsOutputChannel kfsChannel;
/*    */ 
/*    */   public KFSOutputStream(KfsAccess kfsAccess, String path, short replication)
/*    */   {
/* 42 */     this.path = path;
/*    */ 
/* 44 */     this.kfsChannel = kfsAccess.kfs_create(path, replication);
/*    */   }
/*    */ 
/*    */   public long getPos() throws IOException {
/* 48 */     if (this.kfsChannel == null) {
/* 49 */       throw new IOException("File closed");
/*    */     }
/* 51 */     return this.kfsChannel.tell();
/*    */   }
/*    */ 
/*    */   public void write(int v) throws IOException {
/* 55 */     if (this.kfsChannel == null) {
/* 56 */       throw new IOException("File closed");
/*    */     }
/* 58 */     byte[] b = new byte[1];
/*    */ 
/* 60 */     b[0] = (byte)v;
/* 61 */     write(b, 0, 1);
/*    */   }
/*    */ 
/*    */   public void write(byte[] b, int off, int len) throws IOException {
/* 65 */     if (this.kfsChannel == null) {
/* 66 */       throw new IOException("File closed");
/*    */     }
/*    */ 
/* 69 */     this.kfsChannel.write(ByteBuffer.wrap(b, off, len));
/*    */   }
/*    */ 
/*    */   public void flush() throws IOException {
/* 73 */     if (this.kfsChannel == null) {
/* 74 */       throw new IOException("File closed");
/*    */     }
/* 76 */     this.kfsChannel.sync();
/*    */   }
/*    */ 
/*    */   public synchronized void close() throws IOException {
/* 80 */     if (this.kfsChannel == null) {
/* 81 */       return;
/*    */     }
/* 83 */     flush();
/* 84 */     this.kfsChannel.close();
/* 85 */     this.kfsChannel = null;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.kfs.KFSOutputStream
 * JD-Core Version:    0.6.1
 */
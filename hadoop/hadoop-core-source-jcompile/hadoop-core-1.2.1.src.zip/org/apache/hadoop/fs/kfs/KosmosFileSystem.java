/*     */ package org.apache.hadoop.fs.kfs;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URI;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.BlockLocation;
/*     */ import org.apache.hadoop.fs.FSDataInputStream;
/*     */ import org.apache.hadoop.fs.FSDataOutputStream;
/*     */ import org.apache.hadoop.fs.FileStatus;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.FileUtil;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.util.Progressable;
/*     */ 
/*     */ public class KosmosFileSystem extends FileSystem
/*     */ {
/*     */   private FileSystem localFs;
/*  45 */   private IFSImpl kfsImpl = null;
/*     */   private URI uri;
/*  47 */   private Path workingDir = new Path("/");
/*     */ 
/*     */   public KosmosFileSystem()
/*     */   {
/*     */   }
/*     */ 
/*     */   KosmosFileSystem(IFSImpl fsimpl) {
/*  54 */     this.kfsImpl = fsimpl;
/*     */   }
/*     */ 
/*     */   public URI getUri() {
/*  58 */     return this.uri;
/*     */   }
/*     */ 
/*     */   public void initialize(URI uri, Configuration conf) throws IOException {
/*  62 */     super.initialize(uri, conf);
/*     */     try {
/*  64 */       if (this.kfsImpl == null) {
/*  65 */         if (uri.getHost() == null) {
/*  66 */           this.kfsImpl = new KFSImpl(conf.get("fs.kfs.metaServerHost", ""), conf.getInt("fs.kfs.metaServerPort", -1), this.statistics);
/*     */         }
/*     */         else
/*     */         {
/*  70 */           this.kfsImpl = new KFSImpl(uri.getHost(), uri.getPort(), this.statistics);
/*     */         }
/*     */       }
/*     */ 
/*  74 */       this.localFs = FileSystem.getLocal(conf);
/*  75 */       this.uri = URI.create(uri.getScheme() + "://" + uri.getAuthority());
/*  76 */       this.workingDir = new Path("/user", System.getProperty("user.name")).makeQualified(this);
/*     */ 
/*  78 */       setConf(conf);
/*     */     }
/*     */     catch (Exception e) {
/*  81 */       e.printStackTrace();
/*  82 */       System.out.println("Unable to initialize KFS");
/*  83 */       System.exit(-1);
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public String getName() {
/*  89 */     return getUri().toString();
/*     */   }
/*     */ 
/*     */   public Path getWorkingDirectory() {
/*  93 */     return this.workingDir;
/*     */   }
/*     */ 
/*     */   public void setWorkingDirectory(Path dir) {
/*  97 */     this.workingDir = makeAbsolute(dir);
/*     */   }
/*     */ 
/*     */   private Path makeAbsolute(Path path) {
/* 101 */     if (path.isAbsolute()) {
/* 102 */       return path;
/*     */     }
/* 104 */     return new Path(this.workingDir, path);
/*     */   }
/*     */ 
/*     */   public boolean mkdirs(Path path, FsPermission permission) throws IOException
/*     */   {
/* 109 */     Path absolute = makeAbsolute(path);
/* 110 */     String srep = absolute.toUri().getPath();
/*     */ 
/* 116 */     int res = this.kfsImpl.mkdirs(srep);
/*     */ 
/* 118 */     return res == 0;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public boolean isDirectory(Path path) throws IOException {
/* 123 */     Path absolute = makeAbsolute(path);
/* 124 */     String srep = absolute.toUri().getPath();
/*     */ 
/* 128 */     return this.kfsImpl.isDirectory(srep);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public boolean isFile(Path path) throws IOException {
/* 133 */     Path absolute = makeAbsolute(path);
/* 134 */     String srep = absolute.toUri().getPath();
/* 135 */     return this.kfsImpl.isFile(srep);
/*     */   }
/*     */ 
/*     */   public FileStatus[] listStatus(Path path) throws IOException {
/* 139 */     Path absolute = makeAbsolute(path);
/* 140 */     String srep = absolute.toUri().getPath();
/*     */ 
/* 142 */     if (this.kfsImpl.isFile(srep)) {
/* 143 */       return new FileStatus[] { getFileStatus(path) };
/*     */     }
/* 145 */     return this.kfsImpl.readdirplus(absolute);
/*     */   }
/*     */ 
/*     */   public FileStatus getFileStatus(Path path) throws IOException {
/* 149 */     Path absolute = makeAbsolute(path);
/* 150 */     String srep = absolute.toUri().getPath();
/* 151 */     if (!this.kfsImpl.exists(srep)) {
/* 152 */       throw new FileNotFoundException("File " + path + " does not exist.");
/*     */     }
/* 154 */     if (this.kfsImpl.isDirectory(srep))
/*     */     {
/* 156 */       return new FileStatus(0L, true, 1, 0L, this.kfsImpl.getModificationTime(srep), path.makeQualified(this));
/*     */     }
/*     */ 
/* 160 */     return new FileStatus(this.kfsImpl.filesize(srep), false, this.kfsImpl.getReplication(srep), getDefaultBlockSize(), this.kfsImpl.getModificationTime(srep), path.makeQualified(this));
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream append(Path f, int bufferSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 171 */     throw new IOException("Not supported");
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream create(Path file, FsPermission permission, boolean overwrite, int bufferSize, short replication, long blockSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 179 */     if (exists(file)) {
/* 180 */       if (overwrite)
/* 181 */         delete(file);
/*     */       else {
/* 183 */         throw new IOException("File already exists: " + file);
/*     */       }
/*     */     }
/*     */ 
/* 187 */     Path parent = file.getParent();
/* 188 */     if ((parent != null) && (!mkdirs(parent))) {
/* 189 */       throw new IOException("Mkdirs failed to create " + parent);
/*     */     }
/*     */ 
/* 192 */     Path absolute = makeAbsolute(file);
/* 193 */     String srep = absolute.toUri().getPath();
/*     */ 
/* 195 */     return this.kfsImpl.create(srep, replication, bufferSize);
/*     */   }
/*     */ 
/*     */   public FSDataInputStream open(Path path, int bufferSize) throws IOException {
/* 199 */     if (!exists(path)) {
/* 200 */       throw new IOException("File does not exist: " + path);
/*     */     }
/* 202 */     Path absolute = makeAbsolute(path);
/* 203 */     String srep = absolute.toUri().getPath();
/*     */ 
/* 205 */     return this.kfsImpl.open(srep, bufferSize);
/*     */   }
/*     */ 
/*     */   public boolean rename(Path src, Path dst) throws IOException {
/* 209 */     Path absoluteS = makeAbsolute(src);
/* 210 */     String srepS = absoluteS.toUri().getPath();
/* 211 */     Path absoluteD = makeAbsolute(dst);
/* 212 */     String srepD = absoluteD.toUri().getPath();
/*     */ 
/* 216 */     return this.kfsImpl.rename(srepS, srepD) == 0;
/*     */   }
/*     */ 
/*     */   public boolean delete(Path path, boolean recursive) throws IOException
/*     */   {
/* 221 */     Path absolute = makeAbsolute(path);
/* 222 */     String srep = absolute.toUri().getPath();
/* 223 */     if (this.kfsImpl.isFile(srep)) {
/* 224 */       return this.kfsImpl.remove(srep) == 0;
/*     */     }
/* 226 */     FileStatus[] dirEntries = listStatus(absolute);
/* 227 */     if ((!recursive) && (dirEntries != null) && (dirEntries.length != 0))
/*     */     {
/* 229 */       throw new IOException("Directory " + path.toString() + " is not empty.");
/*     */     }
/*     */ 
/* 232 */     if (dirEntries != null) {
/* 233 */       for (int i = 0; i < dirEntries.length; i++) {
/* 234 */         delete(new Path(absolute, dirEntries[i].getPath()), recursive);
/*     */       }
/*     */     }
/* 237 */     return this.kfsImpl.rmdir(srep) == 0;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public boolean delete(Path path) throws IOException {
/* 242 */     return delete(path, true);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public long getLength(Path path) throws IOException {
/* 247 */     Path absolute = makeAbsolute(path);
/* 248 */     String srep = absolute.toUri().getPath();
/* 249 */     return this.kfsImpl.filesize(srep);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public short getReplication(Path path) throws IOException {
/* 254 */     Path absolute = makeAbsolute(path);
/* 255 */     String srep = absolute.toUri().getPath();
/* 256 */     return this.kfsImpl.getReplication(srep);
/*     */   }
/*     */ 
/*     */   public short getDefaultReplication() {
/* 260 */     return 3;
/*     */   }
/*     */ 
/*     */   public boolean setReplication(Path path, short replication)
/*     */     throws IOException
/*     */   {
/* 266 */     Path absolute = makeAbsolute(path);
/* 267 */     String srep = absolute.toUri().getPath();
/*     */ 
/* 269 */     int res = this.kfsImpl.setReplication(srep, replication);
/* 270 */     return res >= 0;
/*     */   }
/*     */ 
/*     */   public long getDefaultBlockSize()
/*     */   {
/* 276 */     return 67108864L;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void lock(Path path, boolean shared)
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void release(Path path)
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   public BlockLocation[] getFileBlockLocations(FileStatus file, long start, long len)
/*     */     throws IOException
/*     */   {
/* 297 */     if (file == null) {
/* 298 */       return null;
/*     */     }
/* 300 */     String srep = makeAbsolute(file.getPath()).toUri().getPath();
/* 301 */     String[][] hints = this.kfsImpl.getDataLocation(srep, start, len);
/* 302 */     if (hints == null) {
/* 303 */       return null;
/*     */     }
/* 305 */     BlockLocation[] result = new BlockLocation[hints.length];
/* 306 */     long blockSize = getDefaultBlockSize();
/* 307 */     long length = len;
/* 308 */     long blockStart = start;
/* 309 */     for (int i = 0; i < result.length; i++) {
/* 310 */       result[i] = new BlockLocation(null, hints[i], blockStart, length < blockSize ? length : blockSize);
/*     */ 
/* 312 */       blockStart += blockSize;
/* 313 */       length -= blockSize;
/*     */     }
/* 315 */     return result;
/*     */   }
/*     */ 
/*     */   public void copyFromLocalFile(boolean delSrc, Path src, Path dst) throws IOException {
/* 319 */     FileUtil.copy(this.localFs, src, this, dst, delSrc, getConf());
/*     */   }
/*     */ 
/*     */   public void copyToLocalFile(boolean delSrc, Path src, Path dst) throws IOException {
/* 323 */     FileUtil.copy(this, src, this.localFs, dst, delSrc, getConf());
/*     */   }
/*     */ 
/*     */   public Path startLocalOutput(Path fsOutputFile, Path tmpLocalFile) throws IOException
/*     */   {
/* 328 */     return tmpLocalFile;
/*     */   }
/*     */ 
/*     */   public void completeLocalOutput(Path fsOutputFile, Path tmpLocalFile) throws IOException
/*     */   {
/* 333 */     moveFromLocalFile(tmpLocalFile, fsOutputFile);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.kfs.KosmosFileSystem
 * JD-Core Version:    0.6.1
 */
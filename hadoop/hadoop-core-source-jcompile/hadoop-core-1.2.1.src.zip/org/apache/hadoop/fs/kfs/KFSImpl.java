/*     */ package org.apache.hadoop.fs.kfs;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import org.apache.hadoop.fs.FSDataInputStream;
/*     */ import org.apache.hadoop.fs.FSDataOutputStream;
/*     */ import org.apache.hadoop.fs.FileStatus;
/*     */ import org.apache.hadoop.fs.FileSystem.Statistics;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.kosmix.kosmosfs.access.KfsAccess;
/*     */ import org.kosmix.kosmosfs.access.KfsFileAttr;
/*     */ 
/*     */ class KFSImpl
/*     */   implements IFSImpl
/*     */ {
/*  34 */   private KfsAccess kfsAccess = null;
/*     */   private FileSystem.Statistics statistics;
/*     */ 
/*     */   @Deprecated
/*     */   public KFSImpl(String metaServerHost, int metaServerPort)
/*     */     throws IOException
/*     */   {
/*  40 */     this(metaServerHost, metaServerPort, null);
/*     */   }
/*     */ 
/*     */   public KFSImpl(String metaServerHost, int metaServerPort, FileSystem.Statistics stats) throws IOException
/*     */   {
/*  45 */     this.kfsAccess = new KfsAccess(metaServerHost, metaServerPort);
/*  46 */     this.statistics = stats;
/*     */   }
/*     */ 
/*     */   public boolean exists(String path) throws IOException {
/*  50 */     return this.kfsAccess.kfs_exists(path);
/*     */   }
/*     */ 
/*     */   public boolean isDirectory(String path) throws IOException {
/*  54 */     return this.kfsAccess.kfs_isDirectory(path);
/*     */   }
/*     */ 
/*     */   public boolean isFile(String path) throws IOException {
/*  58 */     return this.kfsAccess.kfs_isFile(path);
/*     */   }
/*     */ 
/*     */   public String[] readdir(String path) throws IOException {
/*  62 */     return this.kfsAccess.kfs_readdir(path);
/*     */   }
/*     */ 
/*     */   public FileStatus[] readdirplus(Path path) throws IOException {
/*  66 */     String srep = path.toUri().getPath();
/*  67 */     KfsFileAttr[] fattr = this.kfsAccess.kfs_readdirplus(srep);
/*  68 */     if (fattr == null)
/*  69 */       return null;
/*  70 */     int numEntries = 0;
/*  71 */     for (int i = 0; i < fattr.length; i++)
/*  72 */       if ((fattr[i].filename.compareTo(".") != 0) && (fattr[i].filename.compareTo("..") != 0))
/*     */       {
/*  74 */         numEntries++;
/*     */       }
/*  76 */     FileStatus[] fstatus = new FileStatus[numEntries];
/*  77 */     int j = 0;
/*  78 */     for (int i = 0; i < fattr.length; i++)
/*  79 */       if ((fattr[i].filename.compareTo(".") != 0) && (fattr[i].filename.compareTo("..") != 0))
/*     */       {
/*  81 */         Path fn = new Path(path, fattr[i].filename);
/*     */ 
/*  83 */         if (fattr[i].isDirectory)
/*  84 */           fstatus[j] = new FileStatus(0L, true, 1, 0L, fattr[i].modificationTime, fn);
/*     */         else {
/*  86 */           fstatus[j] = new FileStatus(fattr[i].filesize, fattr[i].isDirectory, fattr[i].replication, 67108864L, fattr[i].modificationTime, fn);
/*     */         }
/*     */ 
/*  93 */         j++;
/*     */       }
/*  95 */     return fstatus;
/*     */   }
/*     */ 
/*     */   public int mkdirs(String path) throws IOException
/*     */   {
/* 100 */     return this.kfsAccess.kfs_mkdirs(path);
/*     */   }
/*     */ 
/*     */   public int rename(String source, String dest) throws IOException {
/* 104 */     return this.kfsAccess.kfs_rename(source, dest);
/*     */   }
/*     */ 
/*     */   public int rmdir(String path) throws IOException {
/* 108 */     return this.kfsAccess.kfs_rmdir(path);
/*     */   }
/*     */ 
/*     */   public int remove(String path) throws IOException {
/* 112 */     return this.kfsAccess.kfs_remove(path);
/*     */   }
/*     */ 
/*     */   public long filesize(String path) throws IOException {
/* 116 */     return this.kfsAccess.kfs_filesize(path);
/*     */   }
/*     */ 
/*     */   public short getReplication(String path) throws IOException {
/* 120 */     return this.kfsAccess.kfs_getReplication(path);
/*     */   }
/*     */ 
/*     */   public short setReplication(String path, short replication) throws IOException {
/* 124 */     return this.kfsAccess.kfs_setReplication(path, replication);
/*     */   }
/*     */ 
/*     */   public String[][] getDataLocation(String path, long start, long len) throws IOException {
/* 128 */     return this.kfsAccess.kfs_getDataLocation(path, start, len);
/*     */   }
/*     */ 
/*     */   public long getModificationTime(String path) throws IOException {
/* 132 */     return this.kfsAccess.kfs_getModificationTime(path);
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream create(String path, short replication, int bufferSize) throws IOException {
/* 136 */     return new FSDataOutputStream(new KFSOutputStream(this.kfsAccess, path, replication), this.statistics);
/*     */   }
/*     */ 
/*     */   public FSDataInputStream open(String path, int bufferSize) throws IOException
/*     */   {
/* 141 */     return new FSDataInputStream(new KFSInputStream(this.kfsAccess, path, this.statistics));
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.kfs.KFSImpl
 * JD-Core Version:    0.6.1
 */
package org.apache.hadoop.fs.kfs;

import java.io.IOException;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.Path;

abstract interface IFSImpl
{
  public abstract boolean exists(String paramString)
    throws IOException;

  public abstract boolean isDirectory(String paramString)
    throws IOException;

  public abstract boolean isFile(String paramString)
    throws IOException;

  public abstract String[] readdir(String paramString)
    throws IOException;

  public abstract FileStatus[] readdirplus(Path paramPath)
    throws IOException;

  public abstract int mkdirs(String paramString)
    throws IOException;

  public abstract int rename(String paramString1, String paramString2)
    throws IOException;

  public abstract int rmdir(String paramString)
    throws IOException;

  public abstract int remove(String paramString)
    throws IOException;

  public abstract long filesize(String paramString)
    throws IOException;

  public abstract short getReplication(String paramString)
    throws IOException;

  public abstract short setReplication(String paramString, short paramShort)
    throws IOException;

  public abstract String[][] getDataLocation(String paramString, long paramLong1, long paramLong2)
    throws IOException;

  public abstract long getModificationTime(String paramString)
    throws IOException;

  public abstract FSDataOutputStream create(String paramString, short paramShort, int paramInt)
    throws IOException;

  public abstract FSDataInputStream open(String paramString, int paramInt)
    throws IOException;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.kfs.IFSImpl
 * JD-Core Version:    0.6.1
 */
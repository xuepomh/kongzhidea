/*     */ package org.apache.hadoop.fs.kfs;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.hadoop.fs.FSInputStream;
/*     */ import org.apache.hadoop.fs.FileSystem.Statistics;
/*     */ import org.kosmix.kosmosfs.access.KfsAccess;
/*     */ import org.kosmix.kosmosfs.access.KfsInputChannel;
/*     */ 
/*     */ class KFSInputStream extends FSInputStream
/*     */ {
/*     */   private KfsInputChannel kfsChannel;
/*     */   private FileSystem.Statistics statistics;
/*     */   private long fsize;
/*     */ 
/*     */   @Deprecated
/*     */   public KFSInputStream(KfsAccess kfsAccess, String path)
/*     */   {
/*  40 */     this(kfsAccess, path, null);
/*     */   }
/*     */ 
/*     */   public KFSInputStream(KfsAccess kfsAccess, String path, FileSystem.Statistics stats)
/*     */   {
/*  45 */     this.statistics = stats;
/*  46 */     this.kfsChannel = kfsAccess.kfs_open(path);
/*  47 */     if (this.kfsChannel != null)
/*  48 */       this.fsize = kfsAccess.kfs_filesize(path);
/*     */     else
/*  50 */       this.fsize = 0L;
/*     */   }
/*     */ 
/*     */   public long getPos() throws IOException {
/*  54 */     if (this.kfsChannel == null) {
/*  55 */       throw new IOException("File closed");
/*     */     }
/*  57 */     return this.kfsChannel.tell();
/*     */   }
/*     */ 
/*     */   public synchronized int available() throws IOException {
/*  61 */     if (this.kfsChannel == null) {
/*  62 */       throw new IOException("File closed");
/*     */     }
/*  64 */     return (int)(this.fsize - getPos());
/*     */   }
/*     */ 
/*     */   public synchronized void seek(long targetPos) throws IOException {
/*  68 */     if (this.kfsChannel == null) {
/*  69 */       throw new IOException("File closed");
/*     */     }
/*  71 */     this.kfsChannel.seek(targetPos);
/*     */   }
/*     */ 
/*     */   public synchronized boolean seekToNewSource(long targetPos) throws IOException {
/*  75 */     return false;
/*     */   }
/*     */ 
/*     */   public synchronized int read() throws IOException {
/*  79 */     if (this.kfsChannel == null) {
/*  80 */       throw new IOException("File closed");
/*     */     }
/*  82 */     byte[] b = new byte[1];
/*  83 */     int res = read(b, 0, 1);
/*  84 */     if (res == 1) {
/*  85 */       if (this.statistics != null) {
/*  86 */         this.statistics.incrementBytesRead(1L);
/*     */       }
/*  88 */       return b[0] & 0xFF;
/*     */     }
/*  90 */     return -1;
/*     */   }
/*     */ 
/*     */   public synchronized int read(byte[] b, int off, int len) throws IOException {
/*  94 */     if (this.kfsChannel == null) {
/*  95 */       throw new IOException("File closed");
/*     */     }
/*     */ 
/*  99 */     int res = this.kfsChannel.read(ByteBuffer.wrap(b, off, len));
/*     */ 
/* 101 */     if (res == 0)
/* 102 */       return -1;
/* 103 */     if (this.statistics != null) {
/* 104 */       this.statistics.incrementBytesRead(res);
/*     */     }
/* 106 */     return res;
/*     */   }
/*     */ 
/*     */   public synchronized void close() throws IOException {
/* 110 */     if (this.kfsChannel == null) {
/* 111 */       return;
/*     */     }
/*     */ 
/* 114 */     this.kfsChannel.close();
/* 115 */     this.kfsChannel = null;
/*     */   }
/*     */ 
/*     */   public boolean markSupported() {
/* 119 */     return false;
/*     */   }
/*     */ 
/*     */   public void mark(int readLimit)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException {
/* 127 */     throw new IOException("Mark not supported");
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.kfs.KFSInputStream
 * JD-Core Version:    0.6.1
 */
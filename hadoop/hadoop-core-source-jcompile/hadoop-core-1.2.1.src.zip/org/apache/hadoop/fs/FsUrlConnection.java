/*    */ package org.apache.hadoop.fs;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.URISyntaxException;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ 
/*    */ class FsUrlConnection extends URLConnection
/*    */ {
/*    */   private Configuration conf;
/*    */   private InputStream is;
/*    */ 
/*    */   FsUrlConnection(Configuration conf, URL url)
/*    */   {
/* 38 */     super(url);
/* 39 */     this.conf = conf;
/*    */   }
/*    */ 
/*    */   public void connect() throws IOException
/*    */   {
/*    */     try {
/* 45 */       FileSystem fs = FileSystem.get(this.url.toURI(), this.conf);
/* 46 */       this.is = fs.open(new Path(this.url.getPath()));
/*    */     } catch (URISyntaxException e) {
/* 48 */       throw new IOException(e.toString());
/*    */     }
/*    */   }
/*    */ 
/*    */   public InputStream getInputStream()
/*    */     throws IOException
/*    */   {
/* 55 */     if (this.is == null) {
/* 56 */       connect();
/*    */     }
/* 58 */     return this.is;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.FsUrlConnection
 * JD-Core Version:    0.6.1
 */
package org.apache.hadoop.fs;

import java.io.IOException;

public abstract interface Seekable
{
  public abstract void seek(long paramLong)
    throws IOException;

  public abstract long getPos()
    throws IOException;

  public abstract boolean seekToNewSource(long paramLong)
    throws IOException;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.Seekable
 * JD-Core Version:    0.6.1
 */
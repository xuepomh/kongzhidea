/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ public class HardLink
/*     */ {
/*  57 */   public static OSType osType = getOSType();
/*     */   private static HardLinkCommandGetter getHardLinkCommand;
/*     */   public final LinkStats linkStats;
/*     */ 
/*     */   public HardLink()
/*     */   {
/*  77 */     this.linkStats = new LinkStats();
/*     */   }
/*     */ 
/*     */   private static OSType getOSType() {
/*  81 */     String osName = System.getProperty("os.name");
/*  82 */     if ((osName.contains("Windows")) && ((osName.contains("XP")) || (osName.contains("2003")) || (osName.contains("Vista")) || (osName.contains("Windows_7")) || (osName.contains("Windows 7")) || (osName.contains("Windows7"))))
/*     */     {
/*  89 */       return OSType.OS_TYPE_WINXP;
/*     */     }
/*  91 */     if ((osName.contains("SunOS")) || (osName.contains("Solaris")))
/*     */     {
/*  93 */       return OSType.OS_TYPE_SOLARIS;
/*     */     }
/*  95 */     if (osName.contains("Mac")) {
/*  96 */       return OSType.OS_TYPE_MAC;
/*     */     }
/*     */ 
/*  99 */     return OSType.OS_TYPE_UNIX;
/*     */   }
/*     */ 
/*     */   protected static int getLinkMultArgLength(File fileDir, String[] fileBaseNames, File linkDir)
/*     */     throws IOException
/*     */   {
/* 385 */     return getHardLinkCommand.getLinkMultArgLength(fileDir, fileBaseNames, linkDir);
/*     */   }
/*     */ 
/*     */   protected static int getMaxAllowedCmdArgLength()
/*     */   {
/* 395 */     return getHardLinkCommand.getMaxAllowedCmdArgLength();
/*     */   }
/*     */ 
/*     */   public static void createHardLink(File file, File linkName)
/*     */     throws IOException
/*     */   {
/* 411 */     if (file == null) {
/* 412 */       throw new IOException("invalid arguments to createHardLink: source file is null");
/*     */     }
/*     */ 
/* 415 */     if (linkName == null) {
/* 416 */       throw new IOException("invalid arguments to createHardLink: link name is null");
/*     */     }
/*     */ 
/* 420 */     String[] hardLinkCommand = getHardLinkCommand.linkOne(file, linkName);
/* 421 */     Process process = Runtime.getRuntime().exec(hardLinkCommand);
/*     */     try {
/* 423 */       if (process.waitFor() != 0) {
/* 424 */         String errMsg = new BufferedReader(new InputStreamReader(process.getInputStream())).readLine();
/*     */ 
/* 426 */         if (errMsg == null) errMsg = "";
/* 427 */         String inpMsg = new BufferedReader(new InputStreamReader(process.getErrorStream())).readLine();
/*     */ 
/* 429 */         if (inpMsg == null) inpMsg = "";
/* 430 */         throw new IOException(new StringBuilder().append(errMsg).append(inpMsg).toString());
/*     */       }
/*     */     } catch (InterruptedException e) {
/* 433 */       throw new IOException(e);
/*     */     } finally {
/* 435 */       process.destroy();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void createHardLinkMult(File parentDir, String[] fileBaseNames, File linkDir)
/*     */     throws IOException
/*     */   {
/* 455 */     createHardLinkMult(parentDir, fileBaseNames, linkDir, getHardLinkCommand.getMaxAllowedCmdArgLength());
/*     */   }
/*     */ 
/*     */   protected static int createHardLinkMult(File parentDir, String[] fileBaseNames, File linkDir, int maxLength)
/*     */     throws IOException
/*     */   {
/* 469 */     if (parentDir == null) {
/* 470 */       throw new IOException("invalid arguments to createHardLinkMult: parent directory is null");
/*     */     }
/*     */ 
/* 473 */     if (linkDir == null) {
/* 474 */       throw new IOException("invalid arguments to createHardLinkMult: link directory is null");
/*     */     }
/*     */ 
/* 477 */     if (fileBaseNames == null) {
/* 478 */       throw new IOException("invalid arguments to createHardLinkMult: filename list can be empty but not null");
/*     */     }
/*     */ 
/* 482 */     if (fileBaseNames.length == 0)
/*     */     {
/* 485 */       return 0;
/*     */     }
/* 487 */     if (!linkDir.exists()) {
/* 488 */       throw new FileNotFoundException(new StringBuilder().append(linkDir).append(" not found.").toString());
/*     */     }
/*     */ 
/* 492 */     int callCount = 0;
/* 493 */     if ((getLinkMultArgLength(parentDir, fileBaseNames, linkDir) > maxLength) && (fileBaseNames.length > 1))
/*     */     {
/* 495 */       String[] list1 = (String[])Arrays.copyOf(fileBaseNames, fileBaseNames.length / 2);
/* 496 */       callCount += createHardLinkMult(parentDir, list1, linkDir, maxLength);
/* 497 */       String[] list2 = (String[])Arrays.copyOfRange(fileBaseNames, fileBaseNames.length / 2, fileBaseNames.length);
/*     */ 
/* 499 */       callCount += createHardLinkMult(parentDir, list2, linkDir, maxLength);
/* 500 */       return callCount;
/*     */     }
/* 502 */     callCount = 1;
/*     */ 
/* 506 */     String[] hardLinkCommand = getHardLinkCommand.linkMult(fileBaseNames, linkDir);
/*     */ 
/* 508 */     Process process = Runtime.getRuntime().exec(hardLinkCommand, null, parentDir);
/*     */     try
/*     */     {
/* 511 */       if (process.waitFor() != 0) {
/* 512 */         String errMsg = new BufferedReader(new InputStreamReader(process.getInputStream())).readLine();
/*     */ 
/* 514 */         if (errMsg == null) errMsg = "";
/* 515 */         String inpMsg = new BufferedReader(new InputStreamReader(process.getErrorStream())).readLine();
/*     */ 
/* 517 */         if (inpMsg == null) inpMsg = "";
/* 518 */         throw new IOException(new StringBuilder().append(errMsg).append(inpMsg).toString());
/*     */       }
/*     */     } catch (InterruptedException e) {
/* 521 */       throw new IOException(e);
/*     */     } finally {
/* 523 */       process.destroy();
/*     */     }
/* 525 */     return callCount;
/*     */   }
/*     */ 
/*     */   public static int getLinkCount(File fileName)
/*     */     throws IOException
/*     */   {
/* 532 */     if (fileName == null) {
/* 533 */       throw new IOException("invalid argument to getLinkCount: file name is null");
/*     */     }
/*     */ 
/* 536 */     if (!fileName.exists()) {
/* 537 */       throw new FileNotFoundException(new StringBuilder().append(fileName).append(" not found.").toString());
/*     */     }
/*     */ 
/* 541 */     String[] cmd = getHardLinkCommand.linkCount(fileName);
/* 542 */     String inpMsg = null;
/* 543 */     String errMsg = null;
/* 544 */     int exitValue = -1;
/* 545 */     BufferedReader in = null;
/* 546 */     BufferedReader err = null;
/*     */ 
/* 548 */     Process process = Runtime.getRuntime().exec(cmd);
/*     */     try {
/* 550 */       exitValue = process.waitFor();
/* 551 */       in = new BufferedReader(new InputStreamReader(process.getInputStream()));
/*     */ 
/* 553 */       inpMsg = in.readLine();
/* 554 */       err = new BufferedReader(new InputStreamReader(process.getErrorStream()));
/*     */ 
/* 556 */       errMsg = err.readLine();
/* 557 */       if ((inpMsg == null) || (exitValue != 0))
/* 558 */         throw createIOException(fileName, inpMsg, errMsg, exitValue, null);
/*     */       String[] result;
/* 560 */       if (osType == OSType.OS_TYPE_SOLARIS) {
/* 561 */         result = inpMsg.split("\\s+");
/* 562 */         return Integer.parseInt(result[1]);
/*     */       }
/* 564 */       return Integer.parseInt(inpMsg);
/*     */     }
/*     */     catch (NumberFormatException e) {
/* 567 */       throw createIOException(fileName, inpMsg, errMsg, exitValue, e);
/*     */     } catch (InterruptedException e) {
/* 569 */       throw createIOException(fileName, inpMsg, errMsg, exitValue, e);
/*     */     } finally {
/* 571 */       process.destroy();
/* 572 */       if (in != null) in.close();
/* 573 */       if (err != null) err.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static IOException createIOException(File f, String message, String error, int exitvalue, Exception cause)
/*     */   {
/* 581 */     String winErrMsg = "; Windows errors in getLinkCount are often due to Cygwin misconfiguration";
/*     */ 
/* 584 */     String s = new StringBuilder().append("Failed to get link count on file ").append(f).append(": message=").append(message).append("; error=").append(error).append(osType == OSType.OS_TYPE_WINXP ? "; Windows errors in getLinkCount are often due to Cygwin misconfiguration" : "").append("; exit value=").append(exitvalue).toString();
/*     */ 
/* 589 */     return cause == null ? new IOException(s) : new IOException(s, cause);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  58 */     if (osType == OSType.OS_TYPE_WINXP)
/*     */     {
/*  60 */       getHardLinkCommand = new HardLinkCGWin();
/*     */     }
/*     */     else {
/*  63 */       getHardLinkCommand = new HardLinkCGUnix();
/*     */ 
/*  66 */       if (osType == OSType.OS_TYPE_MAC) {
/*  67 */         String[] linkCountCmdTemplate = { "stat", "-f%l", null };
/*  68 */         HardLinkCGUnix.setLinkCountCmdTemplate(linkCountCmdTemplate);
/*  69 */       } else if (osType == OSType.OS_TYPE_SOLARIS) {
/*  70 */         String[] linkCountCmdTemplate = { "ls", "-l", null };
/*  71 */         HardLinkCGUnix.setLinkCountCmdTemplate(linkCountCmdTemplate);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class LinkStats
/*     */   {
/* 603 */     public int countDirs = 0;
/* 604 */     public int countSingleLinks = 0;
/* 605 */     public int countMultLinks = 0;
/* 606 */     public int countFilesMultLinks = 0;
/* 607 */     public int countEmptyDirs = 0;
/* 608 */     public int countPhysicalFileCopies = 0;
/*     */ 
/*     */     public void clear() {
/* 611 */       this.countDirs = 0;
/* 612 */       this.countSingleLinks = 0;
/* 613 */       this.countMultLinks = 0;
/* 614 */       this.countFilesMultLinks = 0;
/* 615 */       this.countEmptyDirs = 0;
/* 616 */       this.countPhysicalFileCopies = 0;
/*     */     }
/*     */ 
/*     */     public String report() {
/* 620 */       return "HardLinkStats: " + this.countDirs + " Directories, including " + this.countEmptyDirs + " Empty Directories, " + this.countSingleLinks + " single Link operations, " + this.countMultLinks + " multi-Link operations, linking " + this.countFilesMultLinks + " files, total " + (this.countSingleLinks + this.countFilesMultLinks) + " linkable files.  Also physically copied " + this.countPhysicalFileCopies + " other files.";
/*     */     }
/*     */   }
/*     */ 
/*     */   static class HardLinkCGWin extends HardLink.HardLinkCommandGetter
/*     */   {
/* 268 */     static String[] hardLinkCommand = { "fsutil", "hardlink", "create", null, null };
/*     */ 
/* 270 */     static String[] hardLinkMultPrefix = { "cmd", "/q", "/c", "for", "%f", "in", "(" };
/*     */ 
/* 272 */     static String hardLinkMultDir = "\\%f";
/* 273 */     static String[] hardLinkMultSuffix = { ")", "do", "fsutil", "hardlink", "create", null, "%f", "1>NUL" };
/*     */ 
/* 276 */     static String[] getLinkCountCommand = { "stat", "-c%h", null };
/*     */     static final int maxAllowedCmdArgLength = 8127;
/*     */ 
/*     */     HardLinkCGWin()
/*     */     {
/* 263 */       super();
/*     */     }
/*     */ 
/*     */     String[] linkOne(File file, File linkName)
/*     */       throws IOException
/*     */     {
/* 287 */       String[] buf = new String[hardLinkCommand.length];
/* 288 */       System.arraycopy(hardLinkCommand, 0, buf, 0, hardLinkCommand.length);
/*     */ 
/* 290 */       buf[4] = file.getCanonicalPath();
/* 291 */       buf[3] = linkName.getCanonicalPath();
/* 292 */       return buf;
/*     */     }
/*     */ 
/*     */     String[] linkMult(String[] fileBaseNames, File linkDir)
/*     */       throws IOException
/*     */     {
/* 301 */       String[] buf = new String[fileBaseNames.length + hardLinkMultPrefix.length + hardLinkMultSuffix.length];
/*     */ 
/* 304 */       String td = linkDir.getCanonicalPath() + hardLinkMultDir;
/* 305 */       int mark = 0;
/* 306 */       System.arraycopy(hardLinkMultPrefix, 0, buf, mark, hardLinkMultPrefix.length);
/*     */ 
/* 308 */       mark += hardLinkMultPrefix.length;
/* 309 */       System.arraycopy(fileBaseNames, 0, buf, mark, fileBaseNames.length);
/* 310 */       mark += fileBaseNames.length;
/* 311 */       System.arraycopy(hardLinkMultSuffix, 0, buf, mark, hardLinkMultSuffix.length);
/*     */ 
/* 313 */       mark += hardLinkMultSuffix.length;
/* 314 */       buf[(mark - 3)] = td;
/* 315 */       return buf;
/*     */     }
/*     */ 
/*     */     String[] linkCount(File file)
/*     */       throws IOException
/*     */     {
/* 324 */       String[] buf = new String[getLinkCountCommand.length];
/* 325 */       System.arraycopy(getLinkCountCommand, 0, buf, 0, getLinkCountCommand.length);
/*     */ 
/* 333 */       buf[(getLinkCountCommand.length - 1)] = file.getCanonicalPath();
/* 334 */       return buf;
/*     */     }
/*     */ 
/*     */     int getLinkMultArgLength(File fileDir, String[] fileBaseNames, File linkDir)
/*     */       throws IOException
/*     */     {
/* 343 */       int sum = 0;
/* 344 */       for (String x : fileBaseNames)
/*     */       {
/* 346 */         sum += 1 + (x == null ? 0 : x.length());
/*     */       }
/* 348 */       sum += 2 + fileDir.getCanonicalPath().length() + linkDir.getCanonicalPath().length();
/*     */ 
/* 352 */       sum += "cmd.exe /q /c for %f in ( ) do fsutil hardlink create \\%f %f 1>NUL ".length();
/*     */ 
/* 354 */       return sum;
/*     */     }
/*     */ 
/*     */     int getMaxAllowedCmdArgLength()
/*     */     {
/* 362 */       return 8127;
/*     */     }
/*     */   }
/*     */ 
/*     */   static class HardLinkCGUnix extends HardLink.HardLinkCommandGetter
/*     */   {
/* 166 */     private static String[] hardLinkCommand = { "ln", null, null };
/* 167 */     private static String[] hardLinkMultPrefix = { "ln" };
/* 168 */     private static String[] hardLinkMultSuffix = { null };
/* 169 */     private static String[] getLinkCountCommand = { "stat", "-c%h", null };
/*     */     private static final int maxAllowedCmdArgLength = 32703;
/*     */ 
/*     */     HardLinkCGUnix()
/*     */     {
/* 165 */       super();
/*     */     }
/*     */ 
/*     */     private static synchronized void setLinkCountCmdTemplate(String[] template)
/*     */     {
/* 178 */       getLinkCountCommand = template;
/*     */     }
/*     */ 
/*     */     String[] linkOne(File file, File linkName)
/*     */       throws IOException
/*     */     {
/* 187 */       String[] buf = new String[hardLinkCommand.length];
/* 188 */       System.arraycopy(hardLinkCommand, 0, buf, 0, hardLinkCommand.length);
/*     */ 
/* 190 */       buf[1] = FileUtil.makeShellPath(file, true);
/* 191 */       buf[2] = FileUtil.makeShellPath(linkName, true);
/* 192 */       return buf;
/*     */     }
/*     */ 
/*     */     String[] linkMult(String[] fileBaseNames, File linkDir)
/*     */       throws IOException
/*     */     {
/* 201 */       String[] buf = new String[fileBaseNames.length + hardLinkMultPrefix.length + hardLinkMultSuffix.length];
/*     */ 
/* 204 */       int mark = 0;
/* 205 */       System.arraycopy(hardLinkMultPrefix, 0, buf, mark, hardLinkMultPrefix.length);
/*     */ 
/* 207 */       mark += hardLinkMultPrefix.length;
/* 208 */       System.arraycopy(fileBaseNames, 0, buf, mark, fileBaseNames.length);
/* 209 */       mark += fileBaseNames.length;
/* 210 */       buf[mark] = FileUtil.makeShellPath(linkDir, true);
/* 211 */       return buf;
/*     */     }
/*     */ 
/*     */     String[] linkCount(File file)
/*     */       throws IOException
/*     */     {
/* 220 */       String[] buf = new String[getLinkCountCommand.length];
/* 221 */       System.arraycopy(getLinkCountCommand, 0, buf, 0, getLinkCountCommand.length);
/*     */ 
/* 223 */       buf[(getLinkCountCommand.length - 1)] = FileUtil.makeShellPath(file, true);
/* 224 */       return buf;
/*     */     }
/*     */ 
/*     */     int getLinkMultArgLength(File fileDir, String[] fileBaseNames, File linkDir)
/*     */       throws IOException
/*     */     {
/* 233 */       int sum = 0;
/* 234 */       for (String x : fileBaseNames)
/*     */       {
/* 236 */         sum += 1 + (x == null ? 0 : x.length());
/*     */       }
/* 238 */       sum += 2 + FileUtil.makeShellPath(fileDir, true).length() + FileUtil.makeShellPath(linkDir, true).length();
/*     */ 
/* 241 */       sum += 3;
/* 242 */       return sum;
/*     */     }
/*     */ 
/*     */     int getMaxAllowedCmdArgLength()
/*     */     {
/* 250 */       return 32703;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static abstract class HardLinkCommandGetter
/*     */   {
/*     */     abstract String[] linkMult(String[] paramArrayOfString, File paramFile)
/*     */       throws IOException;
/*     */ 
/*     */     abstract String[] linkOne(File paramFile1, File paramFile2)
/*     */       throws IOException;
/*     */ 
/*     */     abstract String[] linkCount(File paramFile)
/*     */       throws IOException;
/*     */ 
/*     */     abstract int getLinkMultArgLength(File paramFile1, String[] paramArrayOfString, File paramFile2)
/*     */       throws IOException;
/*     */ 
/*     */     abstract int getMaxAllowedCmdArgLength();
/*     */   }
/*     */ 
/*     */   public static enum OSType
/*     */   {
/*  43 */     OS_TYPE_UNIX, 
/*  44 */     OS_TYPE_WINXP, 
/*  45 */     OS_TYPE_SOLARIS, 
/*  46 */     OS_TYPE_MAC;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.HardLink
 * JD-Core Version:    0.6.1
 */
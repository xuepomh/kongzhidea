/*    */ package org.apache.hadoop.fs.permission;
/*    */ 
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ class UmaskParser extends PermissionParser
/*    */ {
/* 28 */   private static Pattern chmodOctalPattern = Pattern.compile("^\\s*[+]?([0-7]{3})\\s*$");
/*    */ 
/* 30 */   private static Pattern umaskSymbolicPattern = Pattern.compile("\\G\\s*([ugoa]*)([+=-]+)([rwx]*)([,\\s]*)\\s*");
/*    */   final short umaskMode;
/*    */ 
/*    */   public UmaskParser(String modeStr)
/*    */     throws IllegalArgumentException
/*    */   {
/* 35 */     super(modeStr, umaskSymbolicPattern, chmodOctalPattern);
/*    */ 
/* 37 */     this.umaskMode = (short)combineModes(0, false);
/*    */   }
/*    */ 
/*    */   public short getUMask()
/*    */   {
/* 51 */     if (this.symbolic)
/*    */     {
/* 53 */       return (short)((this.umaskMode ^ 0xFFFFFFFF) & 0x1FF);
/*    */     }
/* 55 */     return this.umaskMode;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.permission.UmaskParser
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.fs.permission;
/*     */ 
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ class PermissionParser
/*     */ {
/*  29 */   protected boolean symbolic = false;
/*     */   protected short userMode;
/*     */   protected short groupMode;
/*     */   protected short othersMode;
/*  33 */   protected char userType = '+';
/*  34 */   protected char groupType = '+';
/*  35 */   protected char othersType = '+';
/*     */ 
/*     */   public PermissionParser(String modeStr, Pattern symbolic, Pattern octal)
/*     */     throws IllegalArgumentException
/*     */   {
/*  46 */     Matcher matcher = null;
/*     */ 
/*  48 */     if ((matcher = symbolic.matcher(modeStr)).find())
/*  49 */       applyNormalPattern(modeStr, matcher);
/*  50 */     else if ((matcher = octal.matcher(modeStr)).matches())
/*  51 */       applyOctalPattern(modeStr, matcher);
/*     */     else
/*  53 */       throw new IllegalArgumentException(modeStr);
/*     */   }
/*     */ 
/*     */   private void applyNormalPattern(String modeStr, Matcher matcher)
/*     */   {
/*  59 */     boolean commaSeperated = false;
/*     */ 
/*  61 */     for (int i = 0; (i < 1) || (matcher.end() < modeStr.length()); i++) {
/*  62 */       if ((i > 0) && ((!commaSeperated) || (!matcher.find()))) {
/*  63 */         throw new IllegalArgumentException(modeStr);
/*     */       }
/*     */ 
/*  70 */       String str = matcher.group(2);
/*  71 */       char type = str.charAt(str.length() - 1);
/*     */       boolean others;
/*     */       boolean group;
/*  74 */       boolean user = group = others = 0;
/*     */ 
/*  76 */       for (char c : matcher.group(1).toCharArray()) {
/*  77 */         switch (c) {
/*     */         case 'u':
/*  79 */           user = true;
/*  80 */           break;
/*     */         case 'g':
/*  82 */           group = true;
/*  83 */           break;
/*     */         case 'o':
/*  85 */           others = true;
/*  86 */           break;
/*     */         case 'a':
/*  88 */           break;
/*     */         default:
/*  90 */           throw new RuntimeException("Unexpected");
/*     */         }
/*     */       }
/*     */ 
/*  94 */       if ((!user) && (!group) && (!others)) {
/*  95 */         user = group = others = 1;
/*     */       }
/*     */ 
/*  98 */       short mode = 0;
/*     */ 
/* 100 */       for (char c : matcher.group(3).toCharArray()) {
/* 101 */         switch (c) {
/*     */         case 'r':
/* 103 */           mode = (short)(mode | 0x4);
/* 104 */           break;
/*     */         case 'w':
/* 106 */           mode = (short)(mode | 0x2);
/* 107 */           break;
/*     */         case 'x':
/* 109 */           mode = (short)(mode | 0x1);
/* 110 */           break;
/*     */         case 'X':
/* 112 */           mode = (short)(mode | 0x8);
/* 113 */           break;
/*     */         default:
/* 115 */           throw new RuntimeException("Unexpected");
/*     */         }
/*     */       }
/*     */ 
/* 119 */       if (user) {
/* 120 */         this.userMode = mode;
/* 121 */         this.userType = type;
/*     */       }
/*     */ 
/* 124 */       if (group) {
/* 125 */         this.groupMode = mode;
/* 126 */         this.groupType = type;
/*     */       }
/*     */ 
/* 129 */       if (others) {
/* 130 */         this.othersMode = mode;
/* 131 */         this.othersType = type;
/*     */       }
/*     */ 
/* 134 */       commaSeperated = matcher.group(4).contains(",");
/*     */     }
/* 136 */     this.symbolic = true;
/*     */   }
/*     */ 
/*     */   private void applyOctalPattern(String modeStr, Matcher matcher) {
/* 140 */     this.userType = (this.groupType = this.othersType = 61);
/*     */ 
/* 142 */     String str = matcher.group(1);
/* 143 */     this.userMode = Short.valueOf(str.substring(0, 1)).shortValue();
/* 144 */     this.groupMode = Short.valueOf(str.substring(1, 2)).shortValue();
/* 145 */     this.othersMode = Short.valueOf(str.substring(2, 3)).shortValue();
/*     */   }
/*     */ 
/*     */   protected int combineModes(int existing, boolean exeOk) {
/* 149 */     return combineModeSegments(this.userType, this.userMode, existing >>> 6 & 0x7, exeOk) << 6 | combineModeSegments(this.groupType, this.groupMode, existing >>> 3 & 0x7, exeOk) << 3 | combineModeSegments(this.othersType, this.othersMode, existing & 0x7, exeOk);
/*     */   }
/*     */ 
/*     */   protected int combineModeSegments(char type, int mode, int existing, boolean exeOk)
/*     */   {
/* 158 */     boolean capX = false;
/*     */ 
/* 160 */     if ((mode & 0x8) != 0) {
/* 161 */       capX = true;
/* 162 */       mode &= -9;
/* 163 */       mode |= 1;
/*     */     }
/*     */ 
/* 166 */     switch (type) { case '+':
/* 167 */       mode |= existing; break;
/*     */     case '-':
/* 168 */       mode = (mode ^ 0xFFFFFFFF) & existing; break;
/*     */     case '=':
/* 169 */       break;
/*     */     default:
/* 170 */       throw new RuntimeException("Unexpected");
/*     */     }
/*     */ 
/* 174 */     if ((capX) && (!exeOk) && ((mode & 0x1) != 0) && ((existing & 0x1) == 0)) {
/* 175 */       mode &= -2;
/*     */     }
/*     */ 
/* 178 */     return mode;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.permission.PermissionParser
 * JD-Core Version:    0.6.1
 */
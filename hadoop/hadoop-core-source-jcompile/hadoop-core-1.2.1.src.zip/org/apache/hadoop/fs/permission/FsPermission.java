/*     */ package org.apache.hadoop.fs.permission;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.WritableFactories;
/*     */ import org.apache.hadoop.io.WritableFactory;
/*     */ 
/*     */ public class FsPermission
/*     */   implements Writable
/*     */ {
/*  35 */   private static final Log LOG = LogFactory.getLog(FsPermission.class);
/*     */ 
/*  37 */   static final WritableFactory FACTORY = new WritableFactory() {
/*  38 */     public Writable newInstance() { return new FsPermission(null); }  } ;
/*     */ 
/*  51 */   private FsAction useraction = null;
/*  52 */   private FsAction groupaction = null;
/*  53 */   private FsAction otheraction = null;
/*     */   public static final String DEPRECATED_UMASK_LABEL = "dfs.umask";
/*     */   public static final String UMASK_LABEL = "dfs.umaskmode";
/*     */   public static final int DEFAULT_UMASK = 18;
/*     */ 
/*  47 */   public static FsPermission createImmutable(short permission) { return new ImmutableFsPermission(permission); }
/*     */ 
/*     */ 
/*     */   private FsPermission()
/*     */   {
/*     */   }
/*     */ 
/*     */   public FsPermission(FsAction u, FsAction g, FsAction o)
/*     */   {
/*  63 */     set(u, g, o);
/*     */   }
/*     */ 
/*     */   public FsPermission(short mode)
/*     */   {
/*  70 */     fromShort(mode);
/*     */   }
/*     */ 
/*     */   public FsPermission(FsPermission other)
/*     */   {
/*  78 */     this.useraction = other.useraction;
/*  79 */     this.groupaction = other.groupaction;
/*  80 */     this.otheraction = other.otheraction;
/*     */   }
/*     */ 
/*     */   public FsPermission(String mode)
/*     */   {
/*  89 */     this(new UmaskParser(mode).getUMask());
/*     */   }
/*     */ 
/*     */   public FsAction getUserAction() {
/*  93 */     return this.useraction;
/*     */   }
/*     */   public FsAction getGroupAction() {
/*  96 */     return this.groupaction;
/*     */   }
/*     */   public FsAction getOtherAction() {
/*  99 */     return this.otheraction;
/*     */   }
/*     */   private void set(FsAction u, FsAction g, FsAction o) {
/* 102 */     this.useraction = u;
/* 103 */     this.groupaction = g;
/* 104 */     this.otheraction = o;
/*     */   }
/*     */   public void fromShort(short n) {
/* 107 */     FsAction[] v = FsAction.values();
/* 108 */     set(v[(n >>> 6 & 0x7)], v[(n >>> 3 & 0x7)], v[(n & 0x7)]);
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out) throws IOException
/*     */   {
/* 113 */     out.writeShort(toShort());
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException
/*     */   {
/* 118 */     fromShort(in.readShort());
/*     */   }
/*     */ 
/*     */   public static FsPermission read(DataInput in)
/*     */     throws IOException
/*     */   {
/* 125 */     FsPermission p = new FsPermission();
/* 126 */     p.readFields(in);
/* 127 */     return p;
/*     */   }
/*     */ 
/*     */   public short toShort()
/*     */   {
/* 134 */     int s = this.useraction.ordinal() << 6 | this.groupaction.ordinal() << 3 | this.otheraction.ordinal();
/*     */ 
/* 136 */     return (short)s;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 141 */     if ((obj instanceof FsPermission)) {
/* 142 */       FsPermission that = (FsPermission)obj;
/* 143 */       return (this.useraction == that.useraction) && (this.groupaction == that.groupaction) && (this.otheraction == that.otheraction);
/*     */     }
/*     */ 
/* 147 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 151 */     return toShort();
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 155 */     return this.useraction.SYMBOL + this.groupaction.SYMBOL + this.otheraction.SYMBOL;
/*     */   }
/*     */ 
/*     */   public FsPermission applyUMask(FsPermission umask)
/*     */   {
/* 160 */     return new FsPermission(this.useraction.and(umask.useraction.not()), this.groupaction.and(umask.groupaction.not()), this.otheraction.and(umask.otheraction.not()));
/*     */   }
/*     */ 
/*     */   public static FsPermission getUMask(Configuration conf)
/*     */   {
/* 185 */     int umask = 18;
/*     */ 
/* 189 */     if (conf != null) {
/* 190 */       int oldStyleValue = conf.getInt("dfs.umask", -2147483648);
/* 191 */       if (oldStyleValue != -2147483648) {
/* 192 */         LOG.warn("dfs.umask configuration key is deprecated. Convert to dfs.umaskmode, using octal or symbolic umask specifications.");
/*     */ 
/* 195 */         umask = oldStyleValue;
/*     */       } else {
/* 197 */         String confUmask = conf.get("dfs.umaskmode");
/* 198 */         if (confUmask != null) {
/* 199 */           return new FsPermission(confUmask);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 204 */     return new FsPermission((short)umask);
/*     */   }
/*     */ 
/*     */   public static void setUMask(Configuration conf, FsPermission umask)
/*     */   {
/* 209 */     conf.set("dfs.umaskmode", String.format("%1$03o", new Object[] { Short.valueOf(umask.toShort()) }));
/*     */   }
/*     */ 
/*     */   public static FsPermission getDefault()
/*     */   {
/* 214 */     return new FsPermission((short)511);
/*     */   }
/*     */ 
/*     */   public static FsPermission valueOf(String unixSymbolicPermission)
/*     */   {
/* 222 */     if (unixSymbolicPermission == null) {
/* 223 */       return null;
/*     */     }
/* 225 */     if (unixSymbolicPermission.length() != 10) {
/* 226 */       throw new IllegalArgumentException("length != 10(unixSymbolicPermission=" + unixSymbolicPermission + ")");
/*     */     }
/*     */ 
/* 229 */     int n = 0;
/* 230 */     for (int i = 1; i < unixSymbolicPermission.length(); i++) {
/* 231 */       n <<= 1;
/* 232 */       char c = unixSymbolicPermission.charAt(i);
/* 233 */       n += ((c == '-') || (c == 'T') || (c == 'S') ? 0 : 1);
/*     */     }
/* 235 */     return new FsPermission((short)n);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  41 */     WritableFactories.setFactory(FsPermission.class, FACTORY);
/*  42 */     WritableFactories.setFactory(ImmutableFsPermission.class, FACTORY);
/*     */   }
/*     */ 
/*     */   private static class ImmutableFsPermission extends FsPermission
/*     */   {
/*     */     public ImmutableFsPermission(short permission)
/*     */     {
/* 240 */       super();
/*     */     }
/*     */     public FsPermission applyUMask(FsPermission umask) {
/* 243 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     public void readFields(DataInput in) throws IOException {
/* 246 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.permission.FsPermission
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.fs.permission;
/*    */ 
/*    */ import java.util.regex.Pattern;
/*    */ import org.apache.hadoop.fs.FileStatus;
/*    */ 
/*    */ public class ChmodParser extends PermissionParser
/*    */ {
/* 29 */   private static Pattern chmodOctalPattern = Pattern.compile("^\\s*[+]?([0-7]{3})\\s*$");
/*    */ 
/* 31 */   private static Pattern chmodNormalPattern = Pattern.compile("\\G\\s*([ugoa]*)([+=-]+)([rwxX]+)([,\\s]*)\\s*");
/*    */ 
/*    */   public ChmodParser(String modeStr) throws IllegalArgumentException
/*    */   {
/* 35 */     super(modeStr, chmodNormalPattern, chmodOctalPattern);
/*    */   }
/*    */ 
/*    */   public short applyNewPermission(FileStatus file)
/*    */   {
/* 45 */     FsPermission perms = file.getPermission();
/* 46 */     int existing = perms.toShort();
/* 47 */     boolean exeOk = (file.isDir()) || ((existing & 0x49) != 0);
/*    */ 
/* 49 */     return (short)combineModes(existing, exeOk);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.permission.ChmodParser
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.fs.permission;
/*    */ 
/*    */ public enum FsAction
/*    */ {
/* 25 */   NONE("---"), 
/* 26 */   EXECUTE("--x"), 
/* 27 */   WRITE("-w-"), 
/* 28 */   WRITE_EXECUTE("-wx"), 
/* 29 */   READ("r--"), 
/* 30 */   READ_EXECUTE("r-x"), 
/* 31 */   READ_WRITE("rw-"), 
/* 32 */   ALL("rwx");
/*    */ 
/* 35 */   private static final FsAction[] vals = values();
/*    */   public final String SYMBOL;
/*    */ 
/*    */   private FsAction(String s)
/*    */   {
/* 41 */     this.SYMBOL = s;
/*    */   }
/*    */ 
/*    */   public boolean implies(FsAction that)
/*    */   {
/* 49 */     if (that != null) {
/* 50 */       return (ordinal() & that.ordinal()) == that.ordinal();
/*    */     }
/* 52 */     return false;
/*    */   }
/*    */ 
/*    */   public FsAction and(FsAction that)
/*    */   {
/* 57 */     return vals[(ordinal() & that.ordinal())];
/*    */   }
/*    */ 
/*    */   public FsAction or(FsAction that) {
/* 61 */     return vals[(ordinal() | that.ordinal())];
/*    */   }
/*    */ 
/*    */   public FsAction not() {
/* 65 */     return vals[(7 - ordinal())];
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.permission.FsAction
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.fs.permission;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.io.Text;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.WritableFactories;
/*     */ import org.apache.hadoop.io.WritableFactory;
/*     */ 
/*     */ public class PermissionStatus
/*     */   implements Writable
/*     */ {
/*  30 */   static final WritableFactory FACTORY = new WritableFactory() {
/*  31 */     public Writable newInstance() { return new PermissionStatus(null); } } ;
/*     */   private String username;
/*     */   private String groupname;
/*     */   private FsPermission permission;
/*     */ 
/*     */   public static PermissionStatus createImmutable(String user, String group, FsPermission permission) {
/*  40 */     return new PermissionStatus(user, group, permission) {
/*     */       public PermissionStatus applyUMask(FsPermission umask) {
/*  42 */         throw new UnsupportedOperationException();
/*     */       }
/*     */       public void readFields(DataInput in) throws IOException {
/*  45 */         throw new UnsupportedOperationException();
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   private PermissionStatus()
/*     */   {
/*     */   }
/*     */ 
/*     */   public PermissionStatus(String user, String group, FsPermission permission)
/*     */   {
/*  58 */     this.username = user;
/*  59 */     this.groupname = group;
/*  60 */     this.permission = permission;
/*     */   }
/*     */ 
/*     */   public String getUserName() {
/*  64 */     return this.username;
/*     */   }
/*     */   public String getGroupName() {
/*  67 */     return this.groupname;
/*     */   }
/*     */   public FsPermission getPermission() {
/*  70 */     return this.permission;
/*     */   }
/*     */ 
/*     */   public PermissionStatus applyUMask(FsPermission umask)
/*     */   {
/*  77 */     this.permission = this.permission.applyUMask(umask);
/*  78 */     return this;
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException
/*     */   {
/*  83 */     this.username = Text.readString(in);
/*  84 */     this.groupname = Text.readString(in);
/*  85 */     this.permission = FsPermission.read(in);
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out) throws IOException
/*     */   {
/*  90 */     write(out, this.username, this.groupname, this.permission);
/*     */   }
/*     */ 
/*     */   public static PermissionStatus read(DataInput in)
/*     */     throws IOException
/*     */   {
/*  97 */     PermissionStatus p = new PermissionStatus();
/*  98 */     p.readFields(in);
/*  99 */     return p;
/*     */   }
/*     */ 
/*     */   public static void write(DataOutput out, String username, String groupname, FsPermission permission)
/*     */     throws IOException
/*     */   {
/* 109 */     Text.writeString(out, username);
/* 110 */     Text.writeString(out, groupname);
/* 111 */     permission.write(out);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 116 */     return this.username + ":" + this.groupname + ":" + this.permission;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  34 */     WritableFactories.setFactory(PermissionStatus.class, FACTORY);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.permission.PermissionStatus
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.fs.permission;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ @Deprecated
/*    */ public class AccessControlException extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public AccessControlException()
/*    */   {
/* 37 */     super("Permission denied.");
/*    */   }
/*    */ 
/*    */   public AccessControlException(String s)
/*    */   {
/* 46 */     super(s);
/*    */   }
/*    */ 
/*    */   public AccessControlException(Throwable cause)
/*    */   {
/* 59 */     super(cause);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.permission.AccessControlException
 * JD-Core Version:    0.6.1
 */
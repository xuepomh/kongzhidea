/*     */ package org.apache.hadoop.fs.ftp;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.apache.commons.net.ftp.FTPClient;
/*     */ import org.apache.hadoop.fs.FSInputStream;
/*     */ import org.apache.hadoop.fs.FileSystem.Statistics;
/*     */ 
/*     */ public class FTPInputStream extends FSInputStream
/*     */ {
/*     */   InputStream wrappedStream;
/*     */   FTPClient client;
/*     */   FileSystem.Statistics stats;
/*     */   boolean closed;
/*     */   long pos;
/*     */ 
/*     */   public FTPInputStream(InputStream stream, FTPClient client, FileSystem.Statistics stats)
/*     */   {
/*  37 */     if (stream == null) {
/*  38 */       throw new IllegalArgumentException("Null InputStream");
/*     */     }
/*  40 */     if ((client == null) || (!client.isConnected())) {
/*  41 */       throw new IllegalArgumentException("FTP client null or not connected");
/*     */     }
/*  43 */     this.wrappedStream = stream;
/*  44 */     this.client = client;
/*  45 */     this.stats = stats;
/*  46 */     this.pos = 0L;
/*  47 */     this.closed = false;
/*     */   }
/*     */ 
/*     */   public long getPos() throws IOException {
/*  51 */     return this.pos;
/*     */   }
/*     */ 
/*     */   public void seek(long pos) throws IOException
/*     */   {
/*  56 */     throw new IOException("Seek not supported");
/*     */   }
/*     */ 
/*     */   public boolean seekToNewSource(long targetPos) throws IOException {
/*  60 */     throw new IOException("Seek not supported");
/*     */   }
/*     */ 
/*     */   public synchronized int read() throws IOException {
/*  64 */     if (this.closed) {
/*  65 */       throw new IOException("Stream closed");
/*     */     }
/*     */ 
/*  68 */     int byteRead = this.wrappedStream.read();
/*  69 */     if (byteRead >= 0) {
/*  70 */       this.pos += 1L;
/*     */     }
/*  72 */     if ((this.stats != null) && (byteRead >= 0)) {
/*  73 */       this.stats.incrementBytesRead(1L);
/*     */     }
/*  75 */     return byteRead;
/*     */   }
/*     */ 
/*     */   public synchronized int read(byte[] buf, int off, int len) throws IOException {
/*  79 */     if (this.closed) {
/*  80 */       throw new IOException("Stream closed");
/*     */     }
/*     */ 
/*  83 */     int result = this.wrappedStream.read(buf, off, len);
/*  84 */     if (result > 0) {
/*  85 */       this.pos += result;
/*     */     }
/*  87 */     if ((this.stats != null) && (result > 0)) {
/*  88 */       this.stats.incrementBytesRead(result);
/*     */     }
/*     */ 
/*  91 */     return result;
/*     */   }
/*     */ 
/*     */   public synchronized void close() throws IOException {
/*  95 */     if (this.closed) {
/*  96 */       throw new IOException("Stream closed");
/*     */     }
/*  98 */     super.close();
/*  99 */     this.closed = true;
/* 100 */     if (!this.client.isConnected()) {
/* 101 */       throw new FTPException("Client not connected");
/*     */     }
/*     */ 
/* 104 */     boolean cmdCompleted = this.client.completePendingCommand();
/* 105 */     this.client.logout();
/* 106 */     this.client.disconnect();
/* 107 */     if (!cmdCompleted)
/* 108 */       throw new FTPException("Could not complete transfer, Reply Code - " + this.client.getReplyCode());
/*     */   }
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/* 116 */     return false;
/*     */   }
/*     */ 
/*     */   public void mark(int readLimit)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException {
/* 124 */     throw new IOException("Mark not supported");
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.ftp.FTPInputStream
 * JD-Core Version:    0.6.1
 */
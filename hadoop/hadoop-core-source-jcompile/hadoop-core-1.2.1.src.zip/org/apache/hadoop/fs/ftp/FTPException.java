/*    */ package org.apache.hadoop.fs.ftp;
/*    */ 
/*    */ public class FTPException extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public FTPException(String message)
/*    */   {
/* 28 */     super(message);
/*    */   }
/*    */ 
/*    */   public FTPException(Throwable t) {
/* 32 */     super(t);
/*    */   }
/*    */ 
/*    */   public FTPException(String message, Throwable t) {
/* 36 */     super(message, t);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.ftp.FTPException
 * JD-Core Version:    0.6.1
 */
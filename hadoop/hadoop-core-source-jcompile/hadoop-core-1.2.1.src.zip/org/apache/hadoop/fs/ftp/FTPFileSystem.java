/*     */ package org.apache.hadoop.fs.ftp;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import java.util.Calendar;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.commons.net.ftp.FTPClient;
/*     */ import org.apache.commons.net.ftp.FTPFile;
/*     */ import org.apache.commons.net.ftp.FTPReply;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FSDataInputStream;
/*     */ import org.apache.hadoop.fs.FSDataOutputStream;
/*     */ import org.apache.hadoop.fs.FileStatus;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.FileSystem.Statistics;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.fs.permission.FsAction;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.util.Progressable;
/*     */ 
/*     */ public class FTPFileSystem extends FileSystem
/*     */ {
/*  48 */   public static final Log LOG = LogFactory.getLog(FTPFileSystem.class);
/*     */   public static final int DEFAULT_BUFFER_SIZE = 1048576;
/*     */   public static final int DEFAULT_BLOCK_SIZE = 4096;
/*     */   private URI uri;
/*     */ 
/*     */   public void initialize(URI uri, Configuration conf)
/*     */     throws IOException
/*     */   {
/*  59 */     super.initialize(uri, conf);
/*     */ 
/*  61 */     String host = uri.getHost();
/*  62 */     host = host == null ? conf.get("fs.ftp.host", null) : host;
/*  63 */     if (host == null) {
/*  64 */       throw new IOException("Invalid host specified");
/*     */     }
/*  66 */     conf.set("fs.ftp.host", host);
/*     */ 
/*  69 */     int port = uri.getPort();
/*  70 */     port = port == -1 ? 21 : port;
/*  71 */     conf.setInt("fs.ftp.host.port", port);
/*     */ 
/*  74 */     String userAndPassword = uri.getUserInfo();
/*  75 */     if (userAndPassword == null) {
/*  76 */       userAndPassword = conf.get(new StringBuilder().append("fs.ftp.user.").append(host).toString(), null) + ":" + conf.get(new StringBuilder().append("fs.ftp.password.").append(host).toString(), null);
/*     */ 
/*  78 */       if (userAndPassword == null) {
/*  79 */         throw new IOException("Invalid user/passsword specified");
/*     */       }
/*     */     }
/*  82 */     String[] userPasswdInfo = userAndPassword.split(":");
/*  83 */     conf.set("fs.ftp.user." + host, userPasswdInfo[0]);
/*  84 */     if (userPasswdInfo.length > 1)
/*  85 */       conf.set("fs.ftp.password." + host, userPasswdInfo[1]);
/*     */     else {
/*  87 */       conf.set("fs.ftp.password." + host, null);
/*     */     }
/*  89 */     setConf(conf);
/*  90 */     this.uri = uri;
/*     */   }
/*     */ 
/*     */   private FTPClient connect()
/*     */     throws IOException
/*     */   {
/* 100 */     FTPClient client = null;
/* 101 */     Configuration conf = getConf();
/* 102 */     String host = conf.get("fs.ftp.host");
/* 103 */     int port = conf.getInt("fs.ftp.host.port", 21);
/* 104 */     String user = conf.get("fs.ftp.user." + host);
/* 105 */     String password = conf.get("fs.ftp.password." + host);
/* 106 */     client = new FTPClient();
/* 107 */     client.connect(host, port);
/* 108 */     int reply = client.getReplyCode();
/* 109 */     if (!FTPReply.isPositiveCompletion(reply)) {
/* 110 */       throw new IOException("Server - " + host + " refused connection on port - " + port);
/*     */     }
/* 112 */     if (client.login(user, password)) {
/* 113 */       client.setFileTransferMode(11);
/* 114 */       client.setFileType(2);
/* 115 */       client.setBufferSize(1048576);
/*     */     } else {
/* 117 */       throw new IOException("Login failed on server - " + host + ", port - " + port);
/*     */     }
/*     */ 
/* 121 */     return client;
/*     */   }
/*     */ 
/*     */   private void disconnect(FTPClient client)
/*     */     throws IOException
/*     */   {
/* 131 */     if (client != null) {
/* 132 */       if (!client.isConnected()) {
/* 133 */         throw new FTPException("Client not connected");
/*     */       }
/* 135 */       boolean logoutSuccess = client.logout();
/* 136 */       client.disconnect();
/* 137 */       if (!logoutSuccess)
/* 138 */         LOG.warn("Logout failed while disconnecting, error code - " + client.getReplyCode());
/*     */     }
/*     */   }
/*     */ 
/*     */   private Path makeAbsolute(Path workDir, Path path)
/*     */   {
/* 152 */     if (path.isAbsolute()) {
/* 153 */       return path;
/*     */     }
/* 155 */     return new Path(workDir, path);
/*     */   }
/*     */ 
/*     */   public FSDataInputStream open(Path file, int bufferSize) throws IOException
/*     */   {
/* 160 */     FTPClient client = connect();
/* 161 */     Path workDir = new Path(client.printWorkingDirectory());
/* 162 */     Path absolute = makeAbsolute(workDir, file);
/* 163 */     FileStatus fileStat = getFileStatus(client, absolute);
/* 164 */     if (fileStat.isDir()) {
/* 165 */       disconnect(client);
/* 166 */       throw new IOException("Path " + file + " is a directory.");
/*     */     }
/* 168 */     client.allocate(bufferSize);
/* 169 */     Path parent = absolute.getParent();
/*     */ 
/* 177 */     client.changeWorkingDirectory(parent.toUri().getPath());
/* 178 */     InputStream is = client.retrieveFileStream(file.getName());
/* 179 */     FSDataInputStream fis = new FSDataInputStream(new FTPInputStream(is, client, this.statistics));
/*     */ 
/* 181 */     if (!FTPReply.isPositivePreliminary(client.getReplyCode()))
/*     */     {
/* 184 */       fis.close();
/* 185 */       throw new IOException("Unable to open file: " + file + ", Aborting");
/*     */     }
/* 187 */     return fis;
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream create(Path file, FsPermission permission, boolean overwrite, int bufferSize, short replication, long blockSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 198 */     final FTPClient client = connect();
/* 199 */     Path workDir = new Path(client.printWorkingDirectory());
/* 200 */     Path absolute = makeAbsolute(workDir, file);
/* 201 */     if (exists(client, file)) {
/* 202 */       if (overwrite) {
/* 203 */         delete(client, file);
/*     */       } else {
/* 205 */         disconnect(client);
/* 206 */         throw new IOException("File already exists: " + file);
/*     */       }
/*     */     }
/* 209 */     Path parent = absolute.getParent();
/* 210 */     if ((parent == null) || (!mkdirs(client, parent, FsPermission.getDefault()))) {
/* 211 */       parent = parent == null ? new Path("/") : parent;
/* 212 */       disconnect(client);
/* 213 */       throw new IOException("create(): Mkdirs failed to create: " + parent);
/*     */     }
/* 215 */     client.allocate(bufferSize);
/*     */ 
/* 221 */     client.changeWorkingDirectory(parent.toUri().getPath());
/* 222 */     FSDataOutputStream fos = new FSDataOutputStream(client.storeFileStream(file.getName()), this.statistics)
/*     */     {
/*     */       public void close() throws IOException
/*     */       {
/* 226 */         super.close();
/* 227 */         if (!client.isConnected()) {
/* 228 */           throw new FTPException("Client not connected");
/*     */         }
/* 230 */         boolean cmdCompleted = client.completePendingCommand();
/* 231 */         FTPFileSystem.this.disconnect(client);
/* 232 */         if (!cmdCompleted)
/* 233 */           throw new FTPException("Could not complete transfer, Reply Code - " + client.getReplyCode());
/*     */       }
/*     */     };
/* 238 */     if (!FTPReply.isPositivePreliminary(client.getReplyCode()))
/*     */     {
/* 241 */       fos.close();
/* 242 */       throw new IOException("Unable to create file: " + file + ", Aborting");
/*     */     }
/* 244 */     return fos;
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream append(Path f, int bufferSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 250 */     throw new IOException("Not supported");
/*     */   }
/*     */ 
/*     */   private boolean exists(FTPClient client, Path file)
/*     */   {
/*     */     try
/*     */     {
/* 260 */       return getFileStatus(client, file) != null;
/*     */     } catch (FileNotFoundException fnfe) {
/* 262 */       return false;
/*     */     } catch (IOException ioe) {
/* 264 */       throw new FTPException("Failed to get file status", ioe);
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public boolean delete(Path file)
/*     */     throws IOException
/*     */   {
/* 272 */     return delete(file, false);
/*     */   }
/*     */ 
/*     */   public boolean delete(Path file, boolean recursive) throws IOException
/*     */   {
/* 277 */     FTPClient client = connect();
/*     */     try {
/* 279 */       boolean success = delete(client, file, recursive);
/* 280 */       return success;
/*     */     } finally {
/* 282 */       disconnect(client);
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   private boolean delete(FTPClient client, Path file) throws IOException
/*     */   {
/* 289 */     return delete(client, file, false);
/*     */   }
/*     */ 
/*     */   private boolean delete(FTPClient client, Path file, boolean recursive)
/*     */     throws IOException
/*     */   {
/* 299 */     Path workDir = new Path(client.printWorkingDirectory());
/* 300 */     Path absolute = makeAbsolute(workDir, file);
/* 301 */     String pathName = absolute.toUri().getPath();
/* 302 */     FileStatus fileStat = getFileStatus(client, absolute);
/* 303 */     if (!fileStat.isDir()) {
/* 304 */       return client.deleteFile(pathName);
/*     */     }
/* 306 */     FileStatus[] dirEntries = listStatus(client, absolute);
/* 307 */     if ((dirEntries != null) && (dirEntries.length > 0) && (!recursive)) {
/* 308 */       throw new IOException("Directory: " + file + " is not empty.");
/*     */     }
/* 310 */     if (dirEntries != null) {
/* 311 */       for (int i = 0; i < dirEntries.length; i++) {
/* 312 */         delete(client, new Path(absolute, dirEntries[i].getPath()), recursive);
/*     */       }
/*     */     }
/* 315 */     return client.removeDirectory(pathName);
/*     */   }
/*     */ 
/*     */   private FsAction getFsAction(int accessGroup, FTPFile ftpFile) {
/* 319 */     FsAction action = FsAction.NONE;
/* 320 */     if (ftpFile.hasPermission(accessGroup, 0)) {
/* 321 */       action.or(FsAction.READ);
/*     */     }
/* 323 */     if (ftpFile.hasPermission(accessGroup, 1)) {
/* 324 */       action.or(FsAction.WRITE);
/*     */     }
/* 326 */     if (ftpFile.hasPermission(accessGroup, 2)) {
/* 327 */       action.or(FsAction.EXECUTE);
/*     */     }
/* 329 */     return action;
/*     */   }
/*     */ 
/*     */   private FsPermission getPermissions(FTPFile ftpFile)
/*     */   {
/* 334 */     FsAction user = getFsAction(0, ftpFile);
/* 335 */     FsAction group = getFsAction(1, ftpFile);
/* 336 */     FsAction others = getFsAction(2, ftpFile);
/* 337 */     return new FsPermission(user, group, others);
/*     */   }
/*     */ 
/*     */   public URI getUri()
/*     */   {
/* 342 */     return this.uri;
/*     */   }
/*     */ 
/*     */   public FileStatus[] listStatus(Path file) throws IOException
/*     */   {
/* 347 */     FTPClient client = connect();
/*     */     try {
/* 349 */       FileStatus[] stats = listStatus(client, file);
/* 350 */       return stats;
/*     */     } finally {
/* 352 */       disconnect(client);
/*     */     }
/*     */   }
/*     */ 
/*     */   private FileStatus[] listStatus(FTPClient client, Path file)
/*     */     throws IOException
/*     */   {
/* 363 */     Path workDir = new Path(client.printWorkingDirectory());
/* 364 */     Path absolute = makeAbsolute(workDir, file);
/* 365 */     FileStatus fileStat = getFileStatus(client, absolute);
/* 366 */     if (!fileStat.isDir()) {
/* 367 */       return new FileStatus[] { fileStat };
/*     */     }
/* 369 */     FTPFile[] ftpFiles = client.listFiles(absolute.toUri().getPath());
/* 370 */     FileStatus[] fileStats = new FileStatus[ftpFiles.length];
/* 371 */     for (int i = 0; i < ftpFiles.length; i++) {
/* 372 */       fileStats[i] = getFileStatus(ftpFiles[i], absolute);
/*     */     }
/* 374 */     return fileStats;
/*     */   }
/*     */ 
/*     */   public FileStatus getFileStatus(Path file) throws IOException
/*     */   {
/* 379 */     FTPClient client = connect();
/*     */     try {
/* 381 */       FileStatus status = getFileStatus(client, file);
/* 382 */       return status;
/*     */     } finally {
/* 384 */       disconnect(client);
/*     */     }
/*     */   }
/*     */ 
/*     */   private FileStatus getFileStatus(FTPClient client, Path file)
/*     */     throws IOException
/*     */   {
/* 395 */     FileStatus fileStat = null;
/* 396 */     Path workDir = new Path(client.printWorkingDirectory());
/* 397 */     Path absolute = makeAbsolute(workDir, file);
/* 398 */     Path parentPath = absolute.getParent();
/* 399 */     if (parentPath == null) {
/* 400 */       long length = -1L;
/* 401 */       boolean isDir = true;
/* 402 */       int blockReplication = 1;
/* 403 */       long blockSize = 4096L;
/* 404 */       long modTime = -1L;
/* 405 */       Path root = new Path("/");
/* 406 */       return new FileStatus(length, isDir, blockReplication, blockSize, modTime, root.makeQualified(this));
/*     */     }
/*     */ 
/* 409 */     String pathName = parentPath.toUri().getPath();
/* 410 */     FTPFile[] ftpFiles = client.listFiles(pathName);
/* 411 */     if (ftpFiles != null) {
/* 412 */       for (FTPFile ftpFile : ftpFiles) {
/* 413 */         if (ftpFile.getName().equals(file.getName())) {
/* 414 */           fileStat = getFileStatus(ftpFile, parentPath);
/* 415 */           break;
/*     */         }
/*     */       }
/* 418 */       if (fileStat == null)
/* 419 */         throw new FileNotFoundException("File " + file + " does not exist.");
/*     */     }
/*     */     else {
/* 422 */       throw new FileNotFoundException("File " + file + " does not exist.");
/*     */     }
/* 424 */     return fileStat;
/*     */   }
/*     */ 
/*     */   private FileStatus getFileStatus(FTPFile ftpFile, Path parentPath)
/*     */   {
/* 435 */     long length = ftpFile.getSize();
/* 436 */     boolean isDir = ftpFile.isDirectory();
/* 437 */     int blockReplication = 1;
/*     */ 
/* 440 */     long blockSize = 4096L;
/* 441 */     long modTime = ftpFile.getTimestamp().getTimeInMillis();
/* 442 */     long accessTime = 0L;
/* 443 */     FsPermission permission = getPermissions(ftpFile);
/* 444 */     String user = ftpFile.getUser();
/* 445 */     String group = ftpFile.getGroup();
/* 446 */     Path filePath = new Path(parentPath, ftpFile.getName());
/* 447 */     return new FileStatus(length, isDir, blockReplication, blockSize, modTime, accessTime, permission, user, group, filePath.makeQualified(this));
/*     */   }
/*     */ 
/*     */   public boolean mkdirs(Path file, FsPermission permission)
/*     */     throws IOException
/*     */   {
/* 453 */     FTPClient client = connect();
/*     */     try {
/* 455 */       boolean success = mkdirs(client, file, permission);
/* 456 */       return success;
/*     */     } finally {
/* 458 */       disconnect(client);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean mkdirs(FTPClient client, Path file, FsPermission permission)
/*     */     throws IOException
/*     */   {
/* 469 */     boolean created = true;
/* 470 */     Path workDir = new Path(client.printWorkingDirectory());
/* 471 */     Path absolute = makeAbsolute(workDir, file);
/* 472 */     String pathName = absolute.getName();
/* 473 */     if (!exists(client, absolute)) {
/* 474 */       Path parent = absolute.getParent();
/* 475 */       created = (parent == null) || (mkdirs(client, parent, FsPermission.getDefault()));
/*     */ 
/* 477 */       if (created) {
/* 478 */         String parentDir = parent.toUri().getPath();
/* 479 */         client.changeWorkingDirectory(parentDir);
/* 480 */         created = client.makeDirectory(pathName);
/*     */       }
/* 482 */     } else if (isFile(client, absolute)) {
/* 483 */       throw new IOException(String.format("Can't make directory for path %s since it is a file.", new Object[] { absolute }));
/*     */     }
/*     */ 
/* 486 */     return created;
/*     */   }
/*     */ 
/*     */   private boolean isFile(FTPClient client, Path file)
/*     */   {
/*     */     try
/*     */     {
/* 496 */       return !getFileStatus(client, file).isDir();
/*     */     } catch (FileNotFoundException e) {
/* 498 */       return false;
/*     */     } catch (IOException ioe) {
/* 500 */       throw new FTPException("File check failed", ioe);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean rename(Path src, Path dst)
/*     */     throws IOException
/*     */   {
/* 510 */     FTPClient client = connect();
/*     */     try {
/* 512 */       boolean success = rename(client, src, dst);
/* 513 */       return success;
/*     */     } finally {
/* 515 */       disconnect(client);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean rename(FTPClient client, Path src, Path dst)
/*     */     throws IOException
/*     */   {
/* 532 */     Path workDir = new Path(client.printWorkingDirectory());
/* 533 */     Path absoluteSrc = makeAbsolute(workDir, src);
/* 534 */     Path absoluteDst = makeAbsolute(workDir, dst);
/* 535 */     if (!exists(client, absoluteSrc)) {
/* 536 */       throw new IOException("Source path " + src + " does not exist");
/*     */     }
/* 538 */     if (exists(client, absoluteDst)) {
/* 539 */       throw new IOException("Destination path " + dst + " already exist, cannot rename!");
/*     */     }
/*     */ 
/* 542 */     String parentSrc = absoluteSrc.getParent().toUri().toString();
/* 543 */     String parentDst = absoluteDst.getParent().toUri().toString();
/* 544 */     String from = src.getName();
/* 545 */     String to = dst.getName();
/* 546 */     if (!parentSrc.equals(parentDst)) {
/* 547 */       throw new IOException("Cannot rename parent(source): " + parentSrc + ", parent(destination):  " + parentDst);
/*     */     }
/*     */ 
/* 550 */     client.changeWorkingDirectory(parentSrc);
/* 551 */     boolean renamed = client.rename(from, to);
/* 552 */     return renamed;
/*     */   }
/*     */ 
/*     */   public Path getWorkingDirectory()
/*     */   {
/* 558 */     return getHomeDirectory();
/*     */   }
/*     */ 
/*     */   public Path getHomeDirectory()
/*     */   {
/* 563 */     FTPClient client = null;
/*     */     try {
/* 565 */       client = connect();
/* 566 */       Path homeDir = new Path(client.printWorkingDirectory());
/* 567 */       return homeDir;
/*     */     } catch (IOException ioe) {
/* 569 */       throw new FTPException("Failed to get home directory", ioe);
/*     */     } finally {
/*     */       try {
/* 572 */         disconnect(client);
/*     */       } catch (IOException ioe) {
/* 574 */         throw new FTPException("Failed to disconnect", ioe);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setWorkingDirectory(Path newDir)
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.ftp.FTPFileSystem
 * JD-Core Version:    0.6.1
 */
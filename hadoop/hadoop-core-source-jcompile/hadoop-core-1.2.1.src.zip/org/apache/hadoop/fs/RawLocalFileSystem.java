/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.DataOutput;
/*     */ import java.io.File;
/*     */ import java.io.FileDescriptor;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.util.Progressable;
/*     */ import org.apache.hadoop.util.Shell;
/*     */ import org.apache.hadoop.util.Shell.ExitCodeException;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ public class RawLocalFileSystem extends FileSystem
/*     */ {
/*  38 */   static final URI NAME = URI.create("file:///");
/*     */   private Path workingDir;
/*     */ 
/*     */   public RawLocalFileSystem()
/*     */   {
/*  42 */     this.workingDir = new Path(System.getProperty("user.dir")).makeQualified(this);
/*     */   }
/*     */ 
/*     */   private Path makeAbsolute(Path f) {
/*  46 */     if (f.isAbsolute()) {
/*  47 */       return f;
/*     */     }
/*  49 */     return new Path(this.workingDir, f);
/*     */   }
/*     */ 
/*     */   public File pathToFile(Path path)
/*     */   {
/*  55 */     checkPath(path);
/*  56 */     if (!path.isAbsolute()) {
/*  57 */       path = new Path(getWorkingDirectory(), path);
/*     */     }
/*  59 */     return new File(path.toUri().getPath());
/*     */   }
/*     */   public URI getUri() {
/*  62 */     return NAME;
/*     */   }
/*     */   public void initialize(URI uri, Configuration conf) throws IOException {
/*  65 */     super.initialize(uri, conf);
/*  66 */     setConf(conf);
/*     */   }
/*     */ 
/*     */   public FSDataInputStream open(Path f, int bufferSize)
/*     */     throws IOException
/*     */   {
/* 179 */     if (!exists(f)) {
/* 180 */       throw new FileNotFoundException(f.toString());
/*     */     }
/* 182 */     return new FSDataInputStream(new BufferedFSInputStream(new LocalFSFileInputStream(f), bufferSize));
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream append(Path f, int bufferSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 226 */     if (!exists(f)) {
/* 227 */       throw new FileNotFoundException(new StringBuilder().append("File ").append(f).append(" not found.").toString());
/*     */     }
/* 229 */     if (getFileStatus(f).isDir()) {
/* 230 */       throw new IOException(new StringBuilder().append("Cannot append to a diretory (=").append(f).append(" ).").toString());
/*     */     }
/* 232 */     return new FSDataOutputStream(new BufferedOutputStream(new LocalFSFileOutputStream(f, true, null), bufferSize), this.statistics);
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream create(Path f, boolean overwrite, int bufferSize, short replication, long blockSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 241 */     return create(f, overwrite, true, bufferSize, replication, blockSize, progress);
/*     */   }
/*     */ 
/*     */   private FSDataOutputStream create(Path f, boolean overwrite, boolean createParent, int bufferSize, short replication, long blockSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 248 */     if ((exists(f)) && (!overwrite)) {
/* 249 */       throw new IOException(new StringBuilder().append("File already exists:").append(f).toString());
/*     */     }
/* 251 */     Path parent = f.getParent();
/* 252 */     if (parent != null) {
/* 253 */       if ((!createParent) && (!exists(parent))) {
/* 254 */         throw new FileNotFoundException(new StringBuilder().append("Parent directory doesn't exist: ").append(parent).toString());
/*     */       }
/* 256 */       if (!mkdirs(parent)) {
/* 257 */         throw new IOException(new StringBuilder().append("Mkdirs failed to create ").append(parent).toString());
/*     */       }
/*     */     }
/* 260 */     return new FSDataOutputStream(new BufferedOutputStream(new LocalFSFileOutputStream(f, false, null), bufferSize), this.statistics);
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream create(Path f, FsPermission permission, boolean overwrite, int bufferSize, short replication, long blockSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 269 */     FSDataOutputStream out = create(f, overwrite, bufferSize, replication, blockSize, progress);
/*     */ 
/* 271 */     setPermission(f, permission);
/* 272 */     return out;
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream createNonRecursive(Path f, FsPermission permission, boolean overwrite, int bufferSize, short replication, long blockSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 281 */     FSDataOutputStream out = create(f, overwrite, false, bufferSize, replication, blockSize, progress);
/*     */ 
/* 283 */     setPermission(f, permission);
/* 284 */     return out;
/*     */   }
/*     */ 
/*     */   public boolean rename(Path src, Path dst) throws IOException {
/* 288 */     if (pathToFile(src).renameTo(pathToFile(dst))) {
/* 289 */       return true;
/*     */     }
/* 291 */     LOG.debug(new StringBuilder().append("Falling through to a copy of ").append(src).append(" to ").append(dst).toString());
/* 292 */     return FileUtil.copy(this, src, this, dst, true, getConf());
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public boolean delete(Path p) throws IOException {
/* 297 */     return delete(p, true);
/*     */   }
/*     */ 
/*     */   public boolean delete(Path p, boolean recursive) throws IOException {
/* 301 */     File f = pathToFile(p);
/* 302 */     if (f.isFile())
/* 303 */       return f.delete();
/* 304 */     if ((!recursive) && (f.isDirectory()) && (FileUtil.listFiles(f).length != 0))
/*     */     {
/* 306 */       throw new IOException(new StringBuilder().append("Directory ").append(f.toString()).append(" is not empty").toString());
/*     */     }
/* 308 */     return FileUtil.fullyDelete(f);
/*     */   }
/*     */ 
/*     */   public FileStatus[] listStatus(Path f) throws IOException {
/* 312 */     File localf = pathToFile(f);
/*     */ 
/* 315 */     if (!localf.exists()) {
/* 316 */       return null;
/*     */     }
/* 318 */     if (localf.isFile()) {
/* 319 */       return new FileStatus[] { new RawLocalFileStatus(localf, getDefaultBlockSize(), this) };
/*     */     }
/*     */ 
/* 323 */     String[] names = localf.list();
/* 324 */     if (names == null) {
/* 325 */       return null;
/*     */     }
/* 327 */     FileStatus[] results = new FileStatus[names.length];
/* 328 */     for (int i = 0; i < names.length; i++) {
/* 329 */       results[i] = getFileStatus(new Path(f, names[i]));
/*     */     }
/* 331 */     return results;
/*     */   }
/*     */ 
/*     */   public boolean mkdirs(Path f)
/*     */     throws IOException
/*     */   {
/* 339 */     Path parent = f.getParent();
/* 340 */     File p2f = pathToFile(f);
/* 341 */     return ((parent == null) || (mkdirs(parent))) && ((p2f.mkdir()) || (p2f.isDirectory()));
/*     */   }
/*     */ 
/*     */   public boolean mkdirs(Path f, FsPermission permission)
/*     */     throws IOException
/*     */   {
/* 348 */     boolean b = mkdirs(f);
/* 349 */     setPermission(f, permission);
/* 350 */     return b;
/*     */   }
/*     */ 
/*     */   public Path getHomeDirectory()
/*     */   {
/* 355 */     return new Path(System.getProperty("user.home")).makeQualified(this);
/*     */   }
/*     */ 
/*     */   public void setWorkingDirectory(Path newDir)
/*     */   {
/* 363 */     this.workingDir = makeAbsolute(newDir);
/* 364 */     checkPath(this.workingDir);
/*     */   }
/*     */ 
/*     */   public Path getWorkingDirectory()
/*     */   {
/* 370 */     return this.workingDir;
/*     */   }
/*     */ 
/*     */   public void moveFromLocalFile(Path src, Path dst) throws IOException
/*     */   {
/* 375 */     rename(src, dst);
/*     */   }
/*     */ 
/*     */   public Path startLocalOutput(Path fsOutputFile, Path tmpLocalFile)
/*     */     throws IOException
/*     */   {
/* 381 */     return fsOutputFile;
/*     */   }
/*     */ 
/*     */   public void completeLocalOutput(Path fsWorkingFile, Path tmpLocalFile) throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void close() throws IOException
/*     */   {
/* 390 */     super.close();
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 394 */     return "LocalFS";
/*     */   }
/*     */ 
/*     */   public FileStatus getFileStatus(Path f) throws IOException {
/* 398 */     File path = pathToFile(f);
/* 399 */     if (path.exists()) {
/* 400 */       return new RawLocalFileStatus(pathToFile(f), getDefaultBlockSize(), this);
/*     */     }
/* 402 */     throw new FileNotFoundException(new StringBuilder().append("File ").append(f).append(" does not exist.").toString());
/*     */   }
/*     */ 
/*     */   public void setOwner(Path p, String username, String groupname)
/*     */     throws IOException
/*     */   {
/* 495 */     if ((username == null) && (groupname == null)) {
/* 496 */       throw new IOException("username == null && groupname == null");
/*     */     }
/*     */ 
/* 499 */     if (username == null) {
/* 500 */       FileUtil.execCommand(pathToFile(p), new String[] { "chgrp", groupname });
/*     */     }
/*     */     else {
/* 503 */       String s = new StringBuilder().append(username).append(groupname == null ? "" : new StringBuilder().append(":").append(groupname).toString()).toString();
/* 504 */       FileUtil.execCommand(pathToFile(p), new String[] { "chown", s });
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setPermission(Path p, FsPermission permission)
/*     */     throws IOException
/*     */   {
/* 514 */     FileUtil.setPermission(pathToFile(p), permission);
/*     */   }
/*     */ 
/*     */   static class RawLocalFileStatus extends FileStatus
/*     */   {
/*     */     private boolean isPermissionLoaded()
/*     */     {
/* 412 */       return !super.getOwner().equals("");
/*     */     }
/*     */ 
/*     */     RawLocalFileStatus(File f, long defaultBlockSize, FileSystem fs) {
/* 416 */       super(f.isDirectory(), 1, defaultBlockSize, f.lastModified(), new Path(f.getPath()).makeQualified(fs));
/*     */     }
/*     */ 
/*     */     public FsPermission getPermission()
/*     */     {
/* 422 */       if (!isPermissionLoaded()) {
/* 423 */         loadPermissionInfo();
/*     */       }
/* 425 */       return super.getPermission();
/*     */     }
/*     */ 
/*     */     public String getOwner()
/*     */     {
/* 430 */       if (!isPermissionLoaded()) {
/* 431 */         loadPermissionInfo();
/*     */       }
/* 433 */       return super.getOwner();
/*     */     }
/*     */ 
/*     */     public String getGroup()
/*     */     {
/* 438 */       if (!isPermissionLoaded()) {
/* 439 */         loadPermissionInfo();
/*     */       }
/* 441 */       return super.getGroup();
/*     */     }
/*     */ 
/*     */     private void loadPermissionInfo()
/*     */     {
/* 446 */       IOException e = null;
/*     */       try {
/* 448 */         StringTokenizer t = new StringTokenizer(FileUtil.execCommand(new File(getPath().toUri()), Shell.getGET_PERMISSION_COMMAND()));
/*     */ 
/* 453 */         String permission = t.nextToken();
/* 454 */         if (permission.length() > 10) {
/* 455 */           permission = permission.substring(0, 10);
/*     */         }
/* 457 */         setPermission(FsPermission.valueOf(permission));
/* 458 */         t.nextToken();
/* 459 */         setOwner(t.nextToken());
/* 460 */         setGroup(t.nextToken());
/*     */       } catch (Shell.ExitCodeException ioe) {
/* 462 */         if (ioe.getExitCode() != 1) {
/* 463 */           e = ioe;
/*     */         } else {
/* 465 */           setPermission(null);
/* 466 */           setOwner(null);
/* 467 */           setGroup(null);
/*     */         }
/*     */       } catch (IOException ioe) {
/* 470 */         e = ioe;
/*     */       } finally {
/* 472 */         if (e != null)
/* 473 */           throw new RuntimeException("Error while running command to get file permissions : " + StringUtils.stringifyException(e));
/*     */       }
/*     */     }
/*     */ 
/*     */     public void write(DataOutput out)
/*     */       throws IOException
/*     */     {
/* 482 */       if (!isPermissionLoaded()) {
/* 483 */         loadPermissionInfo();
/*     */       }
/* 485 */       super.write(out);
/*     */     }
/*     */   }
/*     */ 
/*     */   class LocalFSFileOutputStream extends OutputStream
/*     */     implements Syncable
/*     */   {
/*     */     FileOutputStream fos;
/*     */ 
/*     */     private LocalFSFileOutputStream(Path f, boolean append)
/*     */       throws IOException
/*     */     {
/* 193 */       this.fos = new FileOutputStream(RawLocalFileSystem.this.pathToFile(f), append);
/*     */     }
/*     */ 
/*     */     public void close()
/*     */       throws IOException
/*     */     {
/* 199 */       this.fos.close(); } 
/* 200 */     public void flush() throws IOException { this.fos.flush(); } 
/*     */     public void write(byte[] b, int off, int len) throws IOException {
/*     */       try {
/* 203 */         this.fos.write(b, off, len);
/*     */       } catch (IOException e) {
/* 205 */         throw new FSError(e);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void write(int b) throws IOException {
/*     */       try {
/* 211 */         this.fos.write(b);
/*     */       } catch (IOException e) {
/* 213 */         throw new FSError(e);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void sync() throws IOException
/*     */     {
/* 219 */       this.fos.getFD().sync();
/*     */     }
/*     */   }
/*     */ 
/*     */   class LocalFSFileInputStream extends FSInputStream
/*     */     implements HasFileDescriptor
/*     */   {
/*     */     FileInputStream fis;
/*     */     private long position;
/*     */ 
/*     */     public LocalFSFileInputStream(Path f)
/*     */       throws IOException
/*     */     {
/* 107 */       this.fis = new RawLocalFileSystem.TrackingFileInputStream(RawLocalFileSystem.this, RawLocalFileSystem.this.pathToFile(f));
/*     */     }
/*     */ 
/*     */     public void seek(long pos) throws IOException {
/* 111 */       this.fis.getChannel().position(pos);
/* 112 */       this.position = pos;
/*     */     }
/*     */ 
/*     */     public long getPos() throws IOException {
/* 116 */       return this.position;
/*     */     }
/*     */ 
/*     */     public boolean seekToNewSource(long targetPos) throws IOException {
/* 120 */       return false;
/*     */     }
/*     */ 
/*     */     public int available()
/*     */       throws IOException
/*     */     {
/* 126 */       return this.fis.available(); } 
/* 127 */     public void close() throws IOException { this.fis.close(); } 
/* 128 */     public boolean markSupport() { return false; }
/*     */ 
/*     */     public int read() throws IOException {
/*     */       try {
/* 132 */         int value = this.fis.read();
/* 133 */         if (value >= 0) {
/* 134 */           this.position += 1L;
/*     */         }
/* 136 */         return value;
/*     */       } catch (IOException e) {
/* 138 */         throw new FSError(e);
/*     */       }
/*     */     }
/*     */ 
/*     */     public int read(byte[] b, int off, int len) throws IOException {
/*     */       try {
/* 144 */         int value = this.fis.read(b, off, len);
/* 145 */         if (value > 0) {
/* 146 */           this.position += value;
/*     */         }
/* 148 */         return value;
/*     */       } catch (IOException e) {
/* 150 */         throw new FSError(e);
/*     */       }
/*     */     }
/*     */ 
/*     */     public int read(long position, byte[] b, int off, int len) throws IOException
/*     */     {
/* 156 */       ByteBuffer bb = ByteBuffer.wrap(b, off, len);
/*     */       try {
/* 158 */         return this.fis.getChannel().read(bb, position);
/*     */       } catch (IOException e) {
/* 160 */         throw new FSError(e);
/*     */       }
/*     */     }
/*     */ 
/*     */     public long skip(long n) throws IOException {
/* 165 */       long value = this.fis.skip(n);
/* 166 */       if (value > 0L) {
/* 167 */         this.position += value;
/*     */       }
/* 169 */       return value;
/*     */     }
/*     */ 
/*     */     public FileDescriptor getFileDescriptor() throws IOException
/*     */     {
/* 174 */       return this.fis.getFD();
/*     */     }
/*     */   }
/*     */ 
/*     */   class TrackingFileInputStream extends FileInputStream
/*     */   {
/*     */     public TrackingFileInputStream(File f)
/*     */       throws IOException
/*     */     {
/*  71 */       super();
/*     */     }
/*     */ 
/*     */     public int read() throws IOException {
/*  75 */       int result = super.read();
/*  76 */       if (result != -1) {
/*  77 */         RawLocalFileSystem.this.statistics.incrementBytesRead(1L);
/*     */       }
/*  79 */       return result;
/*     */     }
/*     */ 
/*     */     public int read(byte[] data) throws IOException {
/*  83 */       int result = super.read(data);
/*  84 */       if (result != -1) {
/*  85 */         RawLocalFileSystem.this.statistics.incrementBytesRead(result);
/*     */       }
/*  87 */       return result;
/*     */     }
/*     */ 
/*     */     public int read(byte[] data, int offset, int length) throws IOException {
/*  91 */       int result = super.read(data, offset, length);
/*  92 */       if (result != -1) {
/*  93 */         RawLocalFileSystem.this.statistics.incrementBytesRead(result);
/*     */       }
/*  95 */       return result;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.RawLocalFileSystem
 * JD-Core Version:    0.6.1
 */
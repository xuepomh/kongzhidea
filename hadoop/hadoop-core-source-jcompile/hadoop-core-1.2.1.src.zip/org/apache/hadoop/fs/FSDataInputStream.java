/*    */ package org.apache.hadoop.fs;
/*    */ 
/*    */ import java.io.Closeable;
/*    */ import java.io.DataInputStream;
/*    */ import java.io.FileDescriptor;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ public class FSDataInputStream extends DataInputStream
/*    */   implements Seekable, PositionedReadable, Closeable, HasFileDescriptor
/*    */ {
/*    */   public FSDataInputStream(InputStream in)
/*    */     throws IOException
/*    */   {
/* 29 */     super(in);
/* 30 */     if ((!(in instanceof HasFileDescriptor)) || (!(in instanceof PositionedReadable)))
/* 31 */       throw new IllegalArgumentException("In is not an instance of Seekable or PositionedReadable");
/*    */   }
/*    */ 
/*    */   public synchronized void seek(long desired)
/*    */     throws IOException
/*    */   {
/* 37 */     ((HasFileDescriptor)this.in).seek(desired);
/*    */   }
/*    */ 
/*    */   public long getPos() throws IOException {
/* 41 */     return ((HasFileDescriptor)this.in).getPos();
/*    */   }
/*    */ 
/*    */   public int read(long position, byte[] buffer, int offset, int length) throws IOException
/*    */   {
/* 46 */     return ((PositionedReadable)this.in).read(position, buffer, offset, length);
/*    */   }
/*    */ 
/*    */   public void readFully(long position, byte[] buffer, int offset, int length) throws IOException
/*    */   {
/* 51 */     ((PositionedReadable)this.in).readFully(position, buffer, offset, length);
/*    */   }
/*    */ 
/*    */   public void readFully(long position, byte[] buffer) throws IOException
/*    */   {
/* 56 */     ((PositionedReadable)this.in).readFully(position, buffer, 0, buffer.length);
/*    */   }
/*    */ 
/*    */   public boolean seekToNewSource(long targetPos) throws IOException {
/* 60 */     return ((HasFileDescriptor)this.in).seekToNewSource(targetPos);
/*    */   }
/*    */ 
/*    */   public FileDescriptor getFileDescriptor() throws IOException
/*    */   {
/* 65 */     if ((this.in instanceof HasFileDescriptor))
/* 66 */       return ((HasFileDescriptor)this.in).getFileDescriptor();
/* 67 */     if ((this.in instanceof FileInputStream)) {
/* 68 */       return ((FileInputStream)this.in).getFD();
/*    */     }
/* 70 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.FSDataInputStream
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.util.Random;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ public class LocalFileSystem extends ChecksumFileSystem
/*     */ {
/*  30 */   static final URI NAME = URI.create("file:///");
/*  31 */   private static Random rand = new Random();
/*     */   FileSystem rfs;
/*     */ 
/*     */   public LocalFileSystem()
/*     */   {
/*  35 */     this(new RawLocalFileSystem());
/*     */   }
/*     */ 
/*     */   public FileSystem getRaw() {
/*  39 */     return this.rfs;
/*     */   }
/*     */ 
/*     */   public LocalFileSystem(FileSystem rawLocalFileSystem) {
/*  43 */     super(rawLocalFileSystem);
/*  44 */     this.rfs = rawLocalFileSystem;
/*     */   }
/*     */ 
/*     */   public boolean exists(Path f)
/*     */     throws IOException
/*     */   {
/*  51 */     File path = pathToFile(f);
/*  52 */     if (path.exists()) {
/*  53 */       return true;
/*     */     }
/*  55 */     return false;
/*     */   }
/*     */ 
/*     */   public File pathToFile(Path path)
/*     */   {
/*  61 */     return ((RawLocalFileSystem)this.fs).pathToFile(path);
/*     */   }
/*     */ 
/*     */   public void copyFromLocalFile(boolean delSrc, Path src, Path dst)
/*     */     throws IOException
/*     */   {
/*  67 */     FileUtil.copy(this, src, this, dst, delSrc, getConf());
/*     */   }
/*     */ 
/*     */   public void copyToLocalFile(boolean delSrc, Path src, Path dst)
/*     */     throws IOException
/*     */   {
/*  73 */     FileUtil.copy(this, src, this, dst, delSrc, getConf());
/*     */   }
/*     */ 
/*     */   public boolean reportChecksumFailure(Path p, FSDataInputStream in, long inPos, FSDataInputStream sums, long sumsPos)
/*     */   {
/*     */     try
/*     */     {
/*  85 */       File f = ((RawLocalFileSystem)this.fs).pathToFile(p).getCanonicalFile();
/*     */ 
/*  88 */       String device = new DF(f, getConf()).getMount();
/*  89 */       File parent = f.getParentFile();
/*  90 */       File dir = null;
/*  91 */       while ((parent != null) && (parent.canWrite()) && (parent.toString().startsWith(device))) {
/*  92 */         dir = parent;
/*  93 */         parent = parent.getParentFile();
/*     */       }
/*     */ 
/*  96 */       if (dir == null) {
/*  97 */         throw new IOException("not able to find the highest writable parent dir");
/*     */       }
/*     */ 
/* 102 */       File badDir = new File(dir, "bad_files");
/* 103 */       if ((!badDir.mkdirs()) && 
/* 104 */         (!badDir.isDirectory())) {
/* 105 */         throw new IOException("Mkdirs failed to create " + badDir.toString());
/*     */       }
/*     */ 
/* 108 */       String suffix = "." + rand.nextInt();
/* 109 */       File badFile = new File(badDir, f.getName() + suffix);
/* 110 */       LOG.warn("Moving bad file " + f + " to " + badFile);
/* 111 */       in.close();
/* 112 */       f.renameTo(badFile);
/*     */ 
/* 115 */       File checkFile = ((RawLocalFileSystem)this.fs).pathToFile(getChecksumFile(p));
/* 116 */       checkFile.renameTo(new File(badDir, checkFile.getName() + suffix));
/*     */     }
/*     */     catch (IOException e) {
/* 119 */       LOG.warn("Error moving bad file " + p + ": " + e);
/*     */     }
/* 121 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.LocalFileSystem
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.zip.Checksum;
/*     */ 
/*     */ public abstract class FSOutputSummer extends OutputStream
/*     */ {
/*     */   private Checksum sum;
/*     */   private byte[] buf;
/*     */   private byte[] checksum;
/*     */   private int count;
/*     */ 
/*     */   protected FSOutputSummer(Checksum sum, int maxChunkSize, int checksumSize)
/*     */   {
/*  41 */     this.sum = sum;
/*  42 */     this.buf = new byte[maxChunkSize];
/*  43 */     this.checksum = new byte[checksumSize];
/*  44 */     this.count = 0;
/*     */   }
/*     */ 
/*     */   protected abstract void writeChunk(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2)
/*     */     throws IOException;
/*     */ 
/*     */   public synchronized void write(int b)
/*     */     throws IOException
/*     */   {
/*  55 */     this.sum.update(b);
/*  56 */     this.buf[(this.count++)] = (byte)b;
/*  57 */     if (this.count == this.buf.length)
/*  58 */       flushBuffer();
/*     */   }
/*     */ 
/*     */   public synchronized void write(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/*  82 */     if ((off < 0) || (len < 0) || (off > b.length - len)) {
/*  83 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/*     */ 
/*  86 */     for (int n = 0; n < len; n += write1(b, off + n, len - n));
/*     */   }
/*     */ 
/*     */   private int write1(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/*  95 */     if ((this.count == 0) && (len >= this.buf.length))
/*     */     {
/*  98 */       int length = this.buf.length;
/*  99 */       this.sum.update(b, off, length);
/* 100 */       writeChecksumChunk(b, off, length, false);
/* 101 */       return length;
/*     */     }
/*     */ 
/* 105 */     int bytesToCopy = this.buf.length - this.count;
/* 106 */     bytesToCopy = len < bytesToCopy ? len : bytesToCopy;
/* 107 */     this.sum.update(b, off, bytesToCopy);
/* 108 */     System.arraycopy(b, off, this.buf, this.count, bytesToCopy);
/* 109 */     this.count += bytesToCopy;
/* 110 */     if (this.count == this.buf.length)
/*     */     {
/* 112 */       flushBuffer();
/*     */     }
/* 114 */     return bytesToCopy;
/*     */   }
/*     */ 
/*     */   protected synchronized void flushBuffer()
/*     */     throws IOException
/*     */   {
/* 121 */     flushBuffer(false);
/*     */   }
/*     */ 
/*     */   protected synchronized void flushBuffer(boolean keep)
/*     */     throws IOException
/*     */   {
/* 129 */     if (this.count != 0) {
/* 130 */       int chunkLen = this.count;
/* 131 */       this.count = 0;
/* 132 */       writeChecksumChunk(this.buf, 0, chunkLen, keep);
/* 133 */       if (keep)
/* 134 */         this.count = chunkLen;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void writeChecksumChunk(byte[] b, int off, int len, boolean keep)
/*     */     throws IOException
/*     */   {
/* 145 */     int tempChecksum = (int)this.sum.getValue();
/* 146 */     if (!keep) {
/* 147 */       this.sum.reset();
/*     */     }
/* 149 */     int2byte(tempChecksum, this.checksum);
/* 150 */     writeChunk(b, off, len, this.checksum);
/*     */   }
/*     */ 
/*     */   public static byte[] convertToByteStream(Checksum sum, int checksumSize)
/*     */   {
/* 157 */     return int2byte((int)sum.getValue(), new byte[checksumSize]);
/*     */   }
/*     */ 
/*     */   static byte[] int2byte(int integer, byte[] bytes) {
/* 161 */     bytes[0] = (byte)(integer >>> 24 & 0xFF);
/* 162 */     bytes[1] = (byte)(integer >>> 16 & 0xFF);
/* 163 */     bytes[2] = (byte)(integer >>> 8 & 0xFF);
/* 164 */     bytes[3] = (byte)(integer >>> 0 & 0xFF);
/* 165 */     return bytes;
/*     */   }
/*     */ 
/*     */   protected synchronized void resetChecksumChunk(int size)
/*     */   {
/* 172 */     this.sum.reset();
/* 173 */     this.buf = new byte[size];
/* 174 */     this.count = 0;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.FSOutputSummer
 * JD-Core Version:    0.6.1
 */
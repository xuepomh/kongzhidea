/*    */ package org.apache.hadoop.fs;
/*    */ 
/*    */ import java.io.EOFException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ public abstract class FSInputStream extends InputStream
/*    */   implements Seekable, PositionedReadable
/*    */ {
/*    */   public abstract void seek(long paramLong)
/*    */     throws IOException;
/*    */ 
/*    */   public abstract long getPos()
/*    */     throws IOException;
/*    */ 
/*    */   public abstract boolean seekToNewSource(long paramLong)
/*    */     throws IOException;
/*    */ 
/*    */   public int read(long position, byte[] buffer, int offset, int length)
/*    */     throws IOException
/*    */   {
/* 49 */     synchronized (this) {
/* 50 */       long oldPos = getPos();
/* 51 */       int nread = -1;
/*    */       try {
/* 53 */         seek(position);
/* 54 */         nread = read(buffer, offset, length);
/*    */       } finally {
/* 56 */         seek(oldPos);
/*    */       }
/* 58 */       return nread;
/*    */     }
/*    */   }
/*    */ 
/*    */   public void readFully(long position, byte[] buffer, int offset, int length) throws IOException
/*    */   {
/* 64 */     int nread = 0;
/* 65 */     while (nread < length) {
/* 66 */       int nbytes = read(position + nread, buffer, offset + nread, length - nread);
/* 67 */       if (nbytes < 0) {
/* 68 */         throw new EOFException("End of file reached before reading fully.");
/*    */       }
/* 70 */       nread += nbytes;
/*    */     }
/*    */   }
/*    */ 
/*    */   public void readFully(long position, byte[] buffer) throws IOException
/*    */   {
/* 76 */     readFully(position, buffer, 0, buffer.length);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.FSInputStream
 * JD-Core Version:    0.6.1
 */
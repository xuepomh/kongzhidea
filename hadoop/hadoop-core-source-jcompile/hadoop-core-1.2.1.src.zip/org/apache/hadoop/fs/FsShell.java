/*      */ package org.apache.hadoop.fs;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.net.URI;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.List;
/*      */ import java.util.TimeZone;
/*      */ import java.util.zip.GZIPInputStream;
/*      */ import org.apache.hadoop.conf.Configuration;
/*      */ import org.apache.hadoop.conf.Configured;
/*      */ import org.apache.hadoop.fs.shell.CommandFormat;
/*      */ import org.apache.hadoop.fs.shell.Count;
/*      */ import org.apache.hadoop.io.DataInputBuffer;
/*      */ import org.apache.hadoop.io.DataOutputBuffer;
/*      */ import org.apache.hadoop.io.IOUtils;
/*      */ import org.apache.hadoop.io.SequenceFile.Reader;
/*      */ import org.apache.hadoop.io.Writable;
/*      */ import org.apache.hadoop.io.WritableComparable;
/*      */ import org.apache.hadoop.ipc.RPC.VersionMismatch;
/*      */ import org.apache.hadoop.ipc.RemoteException;
/*      */ import org.apache.hadoop.util.ReflectionUtils;
/*      */ import org.apache.hadoop.util.StringUtils;
/*      */ import org.apache.hadoop.util.Tool;
/*      */ import org.apache.hadoop.util.ToolRunner;
/*      */ 
/*      */ public class FsShell extends Configured
/*      */   implements Tool
/*      */ {
/*      */   private FileSystem fs;
/*      */   private Trash trash;
/*   54 */   public static final SimpleDateFormat dateForm = new SimpleDateFormat("yyyy-MM-dd HH:mm");
/*      */ 
/*   56 */   protected static final SimpleDateFormat modifFmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*      */   static final int BORDER = 2;
/*      */   static final String SETREP_SHORT_USAGE = "-setrep [-R] [-w] <rep> <path/file>";
/*      */   static final String GET_SHORT_USAGE = "-get [-ignoreCrc] [-crc] <src> <localdst>";
/*   64 */   static final String COPYTOLOCAL_SHORT_USAGE = "-get [-ignoreCrc] [-crc] <src> <localdst>".replace("-get", "-copyToLocal");
/*      */   static final String TAIL_USAGE = "-tail [-f] <file>";
/*      */   static final String COPYTOLOCAL_PREFIX = "_copyToLocal_";
/*      */ 
/*      */   public FsShell()
/*      */   {
/*   71 */     this(null);
/*      */   }
/*      */ 
/*      */   public FsShell(Configuration conf) {
/*   75 */     super(conf);
/*   76 */     this.fs = null;
/*   77 */     this.trash = null;
/*      */   }
/*      */ 
/*      */   protected void init() throws IOException {
/*   81 */     getConf().setQuietMode(true);
/*      */   }
/*      */ 
/*      */   protected FileSystem getFS() throws IOException {
/*   85 */     if (this.fs == null) {
/*   86 */       this.fs = FileSystem.get(getConf());
/*      */     }
/*   88 */     return this.fs;
/*      */   }
/*      */ 
/*      */   protected Trash getTrash() throws IOException {
/*   92 */     if (this.trash == null) {
/*   93 */       this.trash = new Trash(getConf());
/*      */     }
/*   95 */     return this.trash;
/*      */   }
/*      */ 
/*      */   private void copyFromStdin(Path dst, FileSystem dstFs)
/*      */     throws IOException
/*      */   {
/*  102 */     if (dstFs.isDirectory(dst)) {
/*  103 */       throw new IOException("When source is stdin, destination must be a file.");
/*      */     }
/*  105 */     if (dstFs.exists(dst)) {
/*  106 */       throw new IOException(new StringBuilder().append("Target ").append(dst.toString()).append(" already exists.").toString());
/*      */     }
/*  108 */     FSDataOutputStream out = dstFs.create(dst);
/*      */     try {
/*  110 */       IOUtils.copyBytes(System.in, out, getConf(), false);
/*      */     }
/*      */     finally {
/*  113 */       out.close();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void printToStdout(InputStream in)
/*      */     throws IOException
/*      */   {
/*      */     try
/*      */     {
/*  122 */       IOUtils.copyBytes(in, System.out, getConf(), false);
/*      */     } finally {
/*  124 */       in.close();
/*      */     }
/*      */   }
/*      */ 
/*      */   void copyFromLocal(Path[] srcs, String dstf)
/*      */     throws IOException
/*      */   {
/*  133 */     Path dstPath = new Path(dstf);
/*  134 */     FileSystem dstFs = dstPath.getFileSystem(getConf());
/*  135 */     if ((srcs.length == 1) && (srcs[0].toString().equals("-")))
/*  136 */       copyFromStdin(dstPath, dstFs);
/*      */     else
/*  138 */       dstFs.copyFromLocalFile(false, false, srcs, dstPath);
/*      */   }
/*      */ 
/*      */   void moveFromLocal(Path[] srcs, String dstf)
/*      */     throws IOException
/*      */   {
/*  145 */     Path dstPath = new Path(dstf);
/*  146 */     FileSystem dstFs = dstPath.getFileSystem(getConf());
/*  147 */     dstFs.moveFromLocalFile(srcs, dstPath);
/*      */   }
/*      */ 
/*      */   void moveFromLocal(Path src, String dstf)
/*      */     throws IOException
/*      */   {
/*  154 */     moveFromLocal(new Path[] { src }, dstf);
/*      */   }
/*      */ 
/*      */   void copyToLocal(String[] argv, int pos)
/*      */     throws IOException
/*      */   {
/*  168 */     CommandFormat cf = new CommandFormat("copyToLocal", 2, 2, new String[] { "crc", "ignoreCrc" });
/*      */ 
/*  170 */     String srcstr = null;
/*  171 */     String dststr = null;
/*      */     try {
/*  173 */       List parameters = cf.parse(argv, pos);
/*  174 */       srcstr = (String)parameters.get(0);
/*  175 */       dststr = (String)parameters.get(1);
/*      */     }
/*      */     catch (IllegalArgumentException iae) {
/*  178 */       System.err.println("Usage: java FsShell -get [-ignoreCrc] [-crc] <src> <localdst>");
/*  179 */       throw iae;
/*      */     }
/*  181 */     boolean copyCrc = cf.getOpt("crc");
/*  182 */     boolean verifyChecksum = !cf.getOpt("ignoreCrc");
/*      */ 
/*  184 */     if (dststr.equals("-")) {
/*  185 */       if (copyCrc) {
/*  186 */         System.err.println("-crc option is not valid when destination is stdout.");
/*      */       }
/*  188 */       cat(srcstr, verifyChecksum);
/*      */     } else {
/*  190 */       File dst = new File(dststr);
/*  191 */       Path srcpath = new Path(srcstr);
/*  192 */       FileSystem srcFS = getSrcFileSystem(srcpath, verifyChecksum);
/*  193 */       if ((copyCrc) && (!(srcFS instanceof ChecksumFileSystem))) {
/*  194 */         System.err.println("-crc option is not valid when source file system does not have crc files. Automatically turn the option off.");
/*      */ 
/*  196 */         copyCrc = false;
/*      */       }
/*  198 */       FileStatus[] srcs = srcFS.globStatus(srcpath);
/*  199 */       boolean dstIsDir = dst.isDirectory();
/*  200 */       if ((srcs.length > 1) && (!dstIsDir)) {
/*  201 */         throw new IOException("When copying multiple files, destination should be a directory.");
/*      */       }
/*      */ 
/*  204 */       for (FileStatus status : srcs) {
/*  205 */         Path p = status.getPath();
/*  206 */         File f = dstIsDir ? new File(dst, p.getName()) : dst;
/*  207 */         copyToLocal(srcFS, p, f, copyCrc);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private FileSystem getSrcFileSystem(Path src, boolean verifyChecksum)
/*      */     throws IOException
/*      */   {
/*  218 */     FileSystem srcFs = src.getFileSystem(getConf());
/*  219 */     srcFs.setVerifyChecksum(verifyChecksum);
/*  220 */     return srcFs;
/*      */   }
/*      */ 
/*      */   private void copyToLocal(FileSystem srcFS, Path src, File dst, boolean copyCrc)
/*      */     throws IOException
/*      */   {
/*  247 */     if (!srcFS.getFileStatus(src).isDir()) {
/*  248 */       if (dst.exists())
/*      */       {
/*  250 */         throw new IOException(new StringBuilder().append("Target ").append(dst).append(" already exists").toString());
/*      */       }
/*      */ 
/*  254 */       File tmp = FileUtil.createLocalTempFile(dst.getAbsoluteFile(), "_copyToLocal_", true);
/*      */ 
/*  256 */       if (!FileUtil.copy(srcFS, src, tmp, false, srcFS.getConf())) {
/*  257 */         throw new IOException(new StringBuilder().append("Failed to copy ").append(src).append(" to ").append(dst).toString());
/*      */       }
/*      */ 
/*  260 */       if (!tmp.renameTo(dst)) {
/*  261 */         throw new IOException(new StringBuilder().append("Failed to rename tmp file ").append(tmp).append(" to local destination \"").append(dst).append("\".").toString());
/*      */       }
/*      */ 
/*  265 */       if (copyCrc) {
/*  266 */         if (!(srcFS instanceof ChecksumFileSystem)) {
/*  267 */           throw new IOException("Source file system does not have crc files");
/*      */         }
/*      */ 
/*  270 */         ChecksumFileSystem csfs = (ChecksumFileSystem)srcFS;
/*  271 */         File dstcs = FileSystem.getLocal(srcFS.getConf()).pathToFile(csfs.getChecksumFile(new Path(dst.getCanonicalPath())));
/*      */ 
/*  273 */         copyToLocal(csfs.getRawFileSystem(), csfs.getChecksumFile(src), dstcs, false);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  278 */       dst.mkdirs();
/*  279 */       for (FileStatus path : srcFS.listStatus(src))
/*  280 */         copyToLocal(srcFS, path.getPath(), new File(dst, path.getPath().getName()), copyCrc);
/*      */     }
/*      */   }
/*      */ 
/*      */   void copyMergeToLocal(String srcf, Path dst)
/*      */     throws IOException
/*      */   {
/*  296 */     copyMergeToLocal(srcf, dst, false);
/*      */   }
/*      */ 
/*      */   void copyMergeToLocal(String srcf, Path dst, boolean endline)
/*      */     throws IOException
/*      */   {
/*  314 */     Path srcPath = new Path(srcf);
/*  315 */     FileSystem srcFs = srcPath.getFileSystem(getConf());
/*  316 */     Path[] srcs = FileUtil.stat2Paths(srcFs.globStatus(srcPath), srcPath);
/*      */ 
/*  318 */     for (int i = 0; i < srcs.length; i++)
/*  319 */       if (endline) {
/*  320 */         FileUtil.copyMerge(srcFs, srcs[i], FileSystem.getLocal(getConf()), dst, false, getConf(), "\n");
/*      */       }
/*      */       else
/*  323 */         FileUtil.copyMerge(srcFs, srcs[i], FileSystem.getLocal(getConf()), dst, false, getConf(), null);
/*      */   }
/*      */ 
/*      */   void moveToLocal(String srcf, Path dst)
/*      */     throws IOException
/*      */   {
/*  334 */     System.err.println("Option '-moveToLocal' is not implemented yet.");
/*      */   }
/*      */ 
/*      */   void cat(String src, boolean verifyChecksum)
/*      */     throws IOException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: new 31	org/apache/hadoop/fs/Path
/*      */     //   3: dup
/*      */     //   4: aload_1
/*      */     //   5: invokespecial 32	org/apache/hadoop/fs/Path:<init>	(Ljava/lang/String;)V
/*      */     //   8: astore_3
/*      */     //   9: new 97	org/apache/hadoop/fs/FsShell$1
/*      */     //   12: dup
/*      */     //   13: aload_0
/*      */     //   14: invokespecial 98	org/apache/hadoop/fs/FsShell$1:<init>	(Lorg/apache/hadoop/fs/FsShell;)V
/*      */     //   17: aload_3
/*      */     //   18: aload_0
/*      */     //   19: aload_3
/*      */     //   20: iload_2
/*      */     //   21: invokespecial 57	org/apache/hadoop/fs/FsShell:getSrcFileSystem	(Lorg/apache/hadoop/fs/Path;Z)Lorg/apache/hadoop/fs/FileSystem;
/*      */     //   24: invokevirtual 99	org/apache/hadoop/fs/FsShell$1:globAndProcess	(Lorg/apache/hadoop/fs/Path;Lorg/apache/hadoop/fs/FileSystem;)V
/*      */     //   27: return
/*      */   }
/*      */ 
/*      */   private InputStream forMagic(Path p, FileSystem srcFs)
/*      */     throws IOException
/*      */   {
/*  403 */     FSDataInputStream i = srcFs.open(p);
/*  404 */     switch (i.readShort()) {
/*      */     case 8075:
/*  406 */       i.seek(0L);
/*  407 */       return new GZIPInputStream(i);
/*      */     case 21317:
/*  409 */       if (i.readByte() == 81) {
/*  410 */         i.close();
/*  411 */         return new TextRecordInputStream(srcFs.getFileStatus(p));
/*      */       }
/*      */       break;
/*      */     }
/*  415 */     i.seek(0L);
/*  416 */     return i; } 
/*      */   void text(String srcf) throws IOException { // Byte code:
/*      */     //   0: new 31	org/apache/hadoop/fs/Path
/*      */     //   3: dup
/*      */     //   4: aload_1
/*      */     //   5: invokespecial 32	org/apache/hadoop/fs/Path:<init>	(Ljava/lang/String;)V
/*      */     //   8: astore_2
/*      */     //   9: new 109	org/apache/hadoop/fs/FsShell$2
/*      */     //   12: dup
/*      */     //   13: aload_0
/*      */     //   14: invokespecial 110	org/apache/hadoop/fs/FsShell$2:<init>	(Lorg/apache/hadoop/fs/FsShell;)V
/*      */     //   17: aload_2
/*      */     //   18: aload_2
/*      */     //   19: aload_0
/*      */     //   20: invokevirtual 8	org/apache/hadoop/fs/FsShell:getConf	()Lorg/apache/hadoop/conf/Configuration;
/*      */     //   23: invokevirtual 33	org/apache/hadoop/fs/Path:getFileSystem	(Lorg/apache/hadoop/conf/Configuration;)Lorg/apache/hadoop/fs/FileSystem;
/*      */     //   26: invokevirtual 111	org/apache/hadoop/fs/FsShell$2:globAndProcess	(Lorg/apache/hadoop/fs/Path;Lorg/apache/hadoop/fs/FileSystem;)V
/*      */     //   29: return } 
/*  439 */   private void setReplication(String[] cmd, int pos) throws IOException { CommandFormat c = new CommandFormat("setrep", 2, 2, new String[] { "R", "w" });
/*  440 */     String dst = null;
/*  441 */     short rep = 0;
/*      */     try
/*      */     {
/*  444 */       List parameters = c.parse(cmd, pos);
/*  445 */       rep = Short.parseShort((String)parameters.get(0));
/*  446 */       dst = (String)parameters.get(1);
/*      */     } catch (NumberFormatException nfe) {
/*  448 */       System.err.println("Illegal replication, a positive integer expected");
/*  449 */       throw nfe;
/*      */     }
/*      */     catch (IllegalArgumentException iae) {
/*  452 */       System.err.println("Usage: java FsShell -setrep [-R] [-w] <rep> <path/file>");
/*  453 */       throw iae;
/*      */     }
/*      */ 
/*  456 */     if (rep < 1) {
/*  457 */       System.err.println(new StringBuilder().append("Cannot set replication to: ").append(rep).toString());
/*  458 */       throw new IllegalArgumentException("replication must be >= 1");
/*      */     }
/*      */ 
/*  461 */     List waitList = c.getOpt("w") ? new ArrayList() : null;
/*  462 */     setReplication(rep, dst, c.getOpt("R"), waitList);
/*      */ 
/*  464 */     if (waitList != null)
/*  465 */       waitForReplication(waitList, rep);
/*      */   }
/*      */ 
/*      */   void waitForReplication(List<Path> waitList, int rep)
/*      */     throws IOException
/*      */   {
/*  476 */     for (Path f : waitList) {
/*  477 */       System.out.print(new StringBuilder().append("Waiting for ").append(f).append(" ...").toString());
/*  478 */       System.out.flush();
/*      */ 
/*  480 */       boolean printWarning = false;
/*  481 */       FileSystem pFS = f.getFileSystem(getConf());
/*  482 */       FileStatus status = pFS.getFileStatus(f);
/*  483 */       long len = status.getLen();
/*      */ 
/*  485 */       for (boolean done = false; !done; ) {
/*  486 */         BlockLocation[] locations = pFS.getFileBlockLocations(status, 0L, len);
/*  487 */         for (int i = 0; 
/*  489 */           (i < locations.length) && (locations[i].getHosts().length == rep); i++)
/*  490 */           if ((!printWarning) && (locations[i].getHosts().length > rep)) {
/*  491 */             System.out.println("\nWARNING: the waiting time may be long for DECREASING the number of replication.");
/*      */ 
/*  493 */             printWarning = true;
/*      */           }
/*  495 */         done = i == locations.length;
/*      */ 
/*  497 */         if (!done) {
/*  498 */           System.out.print(".");
/*  499 */           System.out.flush();
/*      */           try { Thread.sleep(10000L); } catch (InterruptedException e) {
/*      */           }
/*      */         }
/*      */       }
/*  504 */       System.out.println(" done");
/*      */     }
/*      */   }
/*      */ 
/*      */   void setReplication(short newRep, String srcf, boolean recursive, List<Path> waitingList)
/*      */     throws IOException
/*      */   {
/*  521 */     Path srcPath = new Path(srcf);
/*  522 */     FileSystem srcFs = srcPath.getFileSystem(getConf());
/*  523 */     Path[] srcs = FileUtil.stat2Paths(srcFs.globStatus(srcPath), srcPath);
/*      */ 
/*  525 */     for (int i = 0; i < srcs.length; i++)
/*  526 */       setReplication(newRep, srcFs, srcs[i], recursive, waitingList);
/*      */   }
/*      */ 
/*      */   private void setReplication(short newRep, FileSystem srcFs, Path src, boolean recursive, List<Path> waitingList)
/*      */     throws IOException
/*      */   {
/*  534 */     if (!srcFs.getFileStatus(src).isDir()) {
/*  535 */       setFileReplication(src, srcFs, newRep, waitingList);
/*  536 */       return;
/*      */     }
/*  538 */     FileStatus[] items = srcFs.listStatus(src);
/*  539 */     if (items == null) {
/*  540 */       throw new IOException(new StringBuilder().append("Could not get listing for ").append(src).toString());
/*      */     }
/*      */ 
/*  543 */     for (int i = 0; i < items.length; i++)
/*  544 */       if (!items[i].isDir())
/*  545 */         setFileReplication(items[i].getPath(), srcFs, newRep, waitingList);
/*  546 */       else if (recursive)
/*  547 */         setReplication(newRep, srcFs, items[i].getPath(), recursive, waitingList);
/*      */   }
/*      */ 
/*      */   private void setFileReplication(Path file, FileSystem srcFs, short newRep, List<Path> waitList)
/*      */     throws IOException
/*      */   {
/*  563 */     if (srcFs.setReplication(file, newRep)) {
/*  564 */       if (waitList != null) {
/*  565 */         waitList.add(file);
/*      */       }
/*  567 */       System.out.println(new StringBuilder().append("Replication ").append(newRep).append(" set: ").append(file).toString());
/*      */     } else {
/*  569 */       System.err.println(new StringBuilder().append("Could not set replication for: ").append(file).toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   private int ls(String srcf, boolean recursive)
/*      */     throws IOException
/*      */   {
/*  582 */     Path srcPath = new Path(srcf);
/*  583 */     FileSystem srcFs = srcPath.getFileSystem(getConf());
/*  584 */     FileStatus[] srcs = srcFs.globStatus(srcPath);
/*  585 */     if ((srcs == null) || (srcs.length == 0)) {
/*  586 */       throw new FileNotFoundException(new StringBuilder().append("Cannot access ").append(srcf).append(": No such file or directory.").toString());
/*      */     }
/*      */ 
/*  590 */     boolean printHeader = srcs.length == 1;
/*  591 */     int numOfErrors = 0;
/*  592 */     for (int i = 0; i < srcs.length; i++) {
/*  593 */       numOfErrors += ls(srcs[i], srcFs, recursive, printHeader);
/*      */     }
/*  595 */     return numOfErrors == 0 ? 0 : -1;
/*      */   }
/*      */ 
/*      */   private int ls(FileStatus src, FileSystem srcFs, boolean recursive, boolean printHeader)
/*      */     throws IOException
/*      */   {
/*  603 */     String cmd = recursive ? "lsr" : "ls";
/*  604 */     FileStatus[] items = shellListStatus(cmd, srcFs, src);
/*  605 */     if (items == null) {
/*  606 */       return 1;
/*      */     }
/*  608 */     int numOfErrors = 0;
/*  609 */     if ((!recursive) && (printHeader) && 
/*  610 */       (items.length != 0)) {
/*  611 */       System.out.println(new StringBuilder().append("Found ").append(items.length).append(" items").toString());
/*      */     }
/*      */ 
/*  615 */     int maxReplication = 3; int maxLen = 10; int maxOwner = 0; int maxGroup = 0;
/*      */ 
/*  617 */     for (int i = 0; i < items.length; i++) {
/*  618 */       FileStatus stat = items[i];
/*  619 */       int replication = String.valueOf(stat.getReplication()).length();
/*  620 */       int len = String.valueOf(stat.getLen()).length();
/*  621 */       int owner = String.valueOf(stat.getOwner()).length();
/*  622 */       int group = String.valueOf(stat.getGroup()).length();
/*      */ 
/*  624 */       if (replication > maxReplication) maxReplication = replication;
/*  625 */       if (len > maxLen) maxLen = len;
/*  626 */       if (owner > maxOwner) maxOwner = owner;
/*  627 */       if (group > maxGroup) maxGroup = group;
/*      */     }
/*      */ 
/*  630 */     for (int i = 0; i < items.length; i++) {
/*  631 */       FileStatus stat = items[i];
/*  632 */       Path cur = stat.getPath();
/*  633 */       String mdate = dateForm.format(new Date(stat.getModificationTime()));
/*      */ 
/*  635 */       System.out.print(new StringBuilder().append(stat.isDir() ? "d" : "-").append(stat.getPermission()).append(" ").toString());
/*      */ 
/*  637 */       System.out.printf(new StringBuilder().append("%").append(maxReplication).append("s ").toString(), new Object[] { !stat.isDir() ? Short.valueOf(stat.getReplication()) : "-" });
/*      */ 
/*  639 */       if (maxOwner > 0)
/*  640 */         System.out.printf(new StringBuilder().append("%-").append(maxOwner).append("s ").toString(), new Object[] { stat.getOwner() });
/*  641 */       if (maxGroup > 0)
/*  642 */         System.out.printf(new StringBuilder().append("%-").append(maxGroup).append("s ").toString(), new Object[] { stat.getGroup() });
/*  643 */       System.out.printf(new StringBuilder().append("%").append(maxLen).append("d ").toString(), new Object[] { Long.valueOf(stat.getLen()) });
/*  644 */       System.out.print(new StringBuilder().append(mdate).append(" ").toString());
/*  645 */       System.out.println(cur.toUri().getPath());
/*  646 */       if ((recursive) && (stat.isDir())) {
/*  647 */         numOfErrors += ls(stat, srcFs, recursive, printHeader);
/*      */       }
/*      */     }
/*  650 */     return numOfErrors;
/*      */   }
/*      */ 
/*      */   void du(String src)
/*      */     throws IOException
/*      */   {
/*  661 */     Path srcPath = new Path(src);
/*  662 */     FileSystem srcFs = srcPath.getFileSystem(getConf());
/*  663 */     Path[] pathItems = FileUtil.stat2Paths(srcFs.globStatus(srcPath), srcPath);
/*      */ 
/*  665 */     FileStatus[] items = srcFs.listStatus(pathItems);
/*  666 */     if ((items == null) || ((items.length == 0) && (!srcFs.exists(srcPath))))
/*      */     {
/*  668 */       throw new FileNotFoundException(new StringBuilder().append("Cannot access ").append(src).append(": No such file or directory.").toString());
/*      */     }
/*      */ 
/*  671 */     System.out.println(new StringBuilder().append("Found ").append(items.length).append(" items").toString());
/*  672 */     int maxLength = 10;
/*      */ 
/*  674 */     long[] length = new long[items.length];
/*  675 */     for (int i = 0; i < items.length; i++) {
/*  676 */       length[i] = (items[i].isDir() ? srcFs.getContentSummary(items[i].getPath()).getLength() : items[i].getLen());
/*      */ 
/*  679 */       int len = String.valueOf(length[i]).length();
/*  680 */       if (len > maxLength) maxLength = len;
/*      */     }
/*  682 */     for (int i = 0; i < items.length; i++) {
/*  683 */       System.out.printf(new StringBuilder().append("%-").append(maxLength + 2).append("d").toString(), new Object[] { Long.valueOf(length[i]) });
/*  684 */       System.out.println(items[i].getPath());
/*      */     }
/*      */   }
/*      */ 
/*      */   void dus(String src)
/*      */     throws IOException
/*      */   {
/*  697 */     Path srcPath = new Path(src);
/*  698 */     FileSystem srcFs = srcPath.getFileSystem(getConf());
/*  699 */     FileStatus[] status = srcFs.globStatus(new Path(src));
/*  700 */     if ((status == null) || (status.length == 0)) {
/*  701 */       throw new FileNotFoundException(new StringBuilder().append("Cannot access ").append(src).append(": No such file or directory.").toString());
/*      */     }
/*      */ 
/*  704 */     for (int i = 0; i < status.length; i++) {
/*  705 */       long totalSize = srcFs.getContentSummary(status[i].getPath()).getLength();
/*  706 */       String pathStr = status[i].getPath().toString();
/*  707 */       System.out.println(new StringBuilder().append("".equals(pathStr) ? "." : pathStr).append("\t").append(totalSize).toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   void mkdir(String src)
/*      */     throws IOException
/*      */   {
/*  715 */     Path f = new Path(src);
/*  716 */     FileSystem srcFs = f.getFileSystem(getConf());
/*  717 */     FileStatus fstatus = null;
/*      */     try {
/*  719 */       fstatus = srcFs.getFileStatus(f);
/*  720 */       if (fstatus.isDir()) {
/*  721 */         throw new IOException(new StringBuilder().append("cannot create directory ").append(src).append(": File exists").toString());
/*      */       }
/*      */ 
/*  725 */       throw new IOException(new StringBuilder().append(src).append(" exists but ").append("is not a directory").toString());
/*      */     }
/*      */     catch (FileNotFoundException e)
/*      */     {
/*  729 */       if (!srcFs.mkdirs(f))
/*  730 */         throw new IOException(new StringBuilder().append("failed to create ").append(src).toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   void touchz(String src)
/*      */     throws IOException
/*      */   {
/*  741 */     Path f = new Path(src);
/*  742 */     FileSystem srcFs = f.getFileSystem(getConf());
/*      */ 
/*  744 */     if (srcFs.exists(f)) {
/*  745 */       FileStatus st = srcFs.getFileStatus(f);
/*  746 */       if (st.isDir())
/*      */       {
/*  748 */         throw new IOException(new StringBuilder().append(src).append(" is a directory").toString());
/*  749 */       }if (st.getLen() != 0L)
/*  750 */         throw new IOException(new StringBuilder().append(src).append(" must be a zero-length file").toString());
/*      */     }
/*  752 */     FSDataOutputStream out = srcFs.create(f);
/*  753 */     out.close();
/*      */   }
/*      */ 
/*      */   int test(String[] argv, int i)
/*      */     throws IOException
/*      */   {
/*  760 */     if ((!argv[i].startsWith("-")) || (argv[i].length() > 2))
/*  761 */       throw new IOException(new StringBuilder().append("Not a flag: ").append(argv[i]).toString());
/*  762 */     char flag = argv[i].toCharArray()[1];
/*  763 */     Path f = new Path(argv[(++i)]);
/*  764 */     FileSystem srcFs = f.getFileSystem(getConf());
/*  765 */     switch (flag) {
/*      */     case 'e':
/*  767 */       return srcFs.exists(f) ? 0 : 1;
/*      */     case 'z':
/*  769 */       return srcFs.getFileStatus(f).getLen() == 0L ? 0 : 1;
/*      */     case 'd':
/*  771 */       return srcFs.getFileStatus(f).isDir() ? 0 : 1;
/*      */     }
/*  773 */     throw new IOException(new StringBuilder().append("Unknown flag: ").append(flag).toString());
/*      */   }
/*      */ 
/*      */   void stat(char[] fmt, String src)
/*      */     throws IOException
/*      */   {
/*  788 */     Path srcPath = new Path(src);
/*  789 */     FileSystem srcFs = srcPath.getFileSystem(getConf());
/*  790 */     FileStatus[] glob = srcFs.globStatus(srcPath);
/*  791 */     if (null == glob)
/*  792 */       throw new IOException(new StringBuilder().append("cannot stat `").append(src).append("': No such file or directory").toString());
/*  793 */     for (FileStatus f : glob) {
/*  794 */       StringBuilder buf = new StringBuilder();
/*  795 */       for (int i = 0; i < fmt.length; i++) {
/*  796 */         if (fmt[i] != '%') {
/*  797 */           buf.append(fmt[i]);
/*      */         } else {
/*  799 */           if (i + 1 == fmt.length) break;
/*  800 */           switch (fmt[(++i)]) {
/*      */           case 'b':
/*  802 */             buf.append(f.getLen());
/*  803 */             break;
/*      */           case 'F':
/*  805 */             buf.append(f.isDir() ? "directory" : "regular file");
/*  806 */             break;
/*      */           case 'n':
/*  808 */             buf.append(f.getPath().getName());
/*  809 */             break;
/*      */           case 'o':
/*  811 */             buf.append(f.getBlockSize());
/*  812 */             break;
/*      */           case 'r':
/*  814 */             buf.append(f.getReplication());
/*  815 */             break;
/*      */           case 'y':
/*  817 */             buf.append(modifFmt.format(new Date(f.getModificationTime())));
/*  818 */             break;
/*      */           case 'Y':
/*  820 */             buf.append(f.getModificationTime());
/*  821 */             break;
/*      */           default:
/*  823 */             buf.append(fmt[i]);
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*  828 */       System.out.println(buf.toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   void rename(String srcf, String dstf)
/*      */     throws IOException
/*      */   {
/*  843 */     Path srcPath = new Path(srcf);
/*  844 */     Path dstPath = new Path(dstf);
/*  845 */     FileSystem srcFs = srcPath.getFileSystem(getConf());
/*  846 */     FileSystem dstFs = dstPath.getFileSystem(getConf());
/*  847 */     URI srcURI = srcFs.getUri();
/*  848 */     URI dstURI = dstFs.getUri();
/*  849 */     if (srcURI.compareTo(dstURI) != 0) {
/*  850 */       throw new IOException("src and destination filesystems do not match.");
/*      */     }
/*  852 */     Path[] srcs = FileUtil.stat2Paths(srcFs.globStatus(srcPath), srcPath);
/*  853 */     Path dst = new Path(dstf);
/*  854 */     if ((srcs.length > 1) && (!srcFs.isDirectory(dst))) {
/*  855 */       throw new IOException("When moving multiple files, destination should be a directory.");
/*      */     }
/*      */ 
/*  858 */     for (int i = 0; i < srcs.length; i++)
/*  859 */       if (!srcFs.rename(srcs[i], dst)) {
/*  860 */         FileStatus srcFstatus = null;
/*  861 */         FileStatus dstFstatus = null;
/*      */         try {
/*  863 */           srcFstatus = srcFs.getFileStatus(srcs[i]);
/*      */         } catch (FileNotFoundException e) {
/*  865 */           throw new FileNotFoundException(new StringBuilder().append(srcs[i]).append(": No such file or directory").toString());
/*      */         }
/*      */         try
/*      */         {
/*  869 */           dstFstatus = dstFs.getFileStatus(dst);
/*      */         } catch (IOException e) {
/*      */         }
/*  872 */         if ((srcFstatus != null) && (dstFstatus != null) && 
/*  873 */           (srcFstatus.isDir()) && (!dstFstatus.isDir())) {
/*  874 */           throw new IOException(new StringBuilder().append("cannot overwrite non directory ").append(dst).append(" with directory ").append(srcs[i]).toString());
/*      */         }
/*      */ 
/*  878 */         throw new IOException(new StringBuilder().append("Failed to rename ").append(srcs[i]).append(" to ").append(dst).toString());
/*      */       }
/*      */   }
/*      */ 
/*      */   private int rename(String[] argv, Configuration conf)
/*      */     throws IOException
/*      */   {
/*  892 */     int i = 0;
/*  893 */     int exitCode = 0;
/*  894 */     String cmd = argv[(i++)];
/*  895 */     String dest = argv[(argv.length - 1)];
/*      */ 
/*  900 */     if (argv.length > 3) {
/*  901 */       Path dst = new Path(dest);
/*  902 */       FileSystem dstFs = dst.getFileSystem(getConf());
/*  903 */       if (!dstFs.isDirectory(dst)) {
/*  904 */         throw new IOException(new StringBuilder().append("When moving multiple files, destination ").append(dest).append(" should be a directory.").toString());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  911 */     for (; i < argv.length - 1; i++)
/*      */     {
/*      */       try
/*      */       {
/*  916 */         rename(argv[i], dest);
/*      */       }
/*      */       catch (RemoteException e)
/*      */       {
/*  922 */         exitCode = -1;
/*      */         try
/*      */         {
/*  925 */           String[] content = e.getLocalizedMessage().split("\n");
/*  926 */           System.err.println(new StringBuilder().append(cmd.substring(1)).append(": ").append(content[0]).toString());
/*      */         } catch (Exception ex) {
/*  928 */           System.err.println(new StringBuilder().append(cmd.substring(1)).append(": ").append(ex.getLocalizedMessage()).toString());
/*      */         }
/*      */ 
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/*  935 */         exitCode = -1;
/*  936 */         System.err.println(new StringBuilder().append(cmd.substring(1)).append(": ").append(e.getLocalizedMessage()).toString());
/*      */       }
/*      */     }
/*      */ 
/*  940 */     return exitCode;
/*      */   }
/*      */ 
/*      */   void copy(String srcf, String dstf, Configuration conf)
/*      */     throws IOException
/*      */   {
/*  954 */     Path srcPath = new Path(srcf);
/*  955 */     FileSystem srcFs = srcPath.getFileSystem(getConf());
/*  956 */     Path dstPath = new Path(dstf);
/*  957 */     FileSystem dstFs = dstPath.getFileSystem(getConf());
/*  958 */     Path[] srcs = FileUtil.stat2Paths(srcFs.globStatus(srcPath), srcPath);
/*  959 */     if ((srcs.length > 1) && (!dstFs.isDirectory(dstPath))) {
/*  960 */       throw new IOException("When copying multiple files, destination should be a directory.");
/*      */     }
/*      */ 
/*  963 */     for (int i = 0; i < srcs.length; i++)
/*  964 */       FileUtil.copy(srcFs, srcs[i], dstFs, dstPath, false, conf);
/*      */   }
/*      */ 
/*      */   private int copy(String[] argv, Configuration conf)
/*      */     throws IOException
/*      */   {
/*  977 */     int i = 0;
/*  978 */     int exitCode = 0;
/*  979 */     String cmd = argv[(i++)];
/*  980 */     String dest = argv[(argv.length - 1)];
/*      */ 
/*  985 */     if (argv.length > 3) {
/*  986 */       Path dst = new Path(dest);
/*  987 */       FileSystem pFS = dst.getFileSystem(conf);
/*  988 */       if (!pFS.isDirectory(dst)) {
/*  989 */         throw new IOException(new StringBuilder().append("When copying multiple files, destination ").append(dest).append(" should be a directory.").toString());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  996 */     for (; i < argv.length - 1; i++)
/*      */     {
/*      */       try
/*      */       {
/* 1001 */         copy(argv[i], dest, conf);
/*      */       }
/*      */       catch (RemoteException e)
/*      */       {
/* 1007 */         exitCode = -1;
/*      */         try
/*      */         {
/* 1010 */           String[] content = e.getLocalizedMessage().split("\n");
/* 1011 */           System.err.println(new StringBuilder().append(cmd.substring(1)).append(": ").append(content[0]).toString());
/*      */         }
/*      */         catch (Exception ex) {
/* 1014 */           System.err.println(new StringBuilder().append(cmd.substring(1)).append(": ").append(ex.getLocalizedMessage()).toString());
/*      */         }
/*      */ 
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/* 1021 */         exitCode = -1;
/* 1022 */         System.err.println(new StringBuilder().append(cmd.substring(1)).append(": ").append(e.getLocalizedMessage()).toString());
/*      */       }
/*      */     }
/*      */ 
/* 1026 */     return exitCode;
/*      */   }
/*      */ 
/*      */   void delete(String srcf, final boolean recursive, final boolean skipTrash)
/*      */     throws IOException
/*      */   {
/* 1045 */     Path srcPattern = new Path(srcf);
/* 1046 */     new DelayedExceptionThrowing(recursive, skipTrash)
/*      */     {
/*      */       void process(Path p, FileSystem srcFs) throws IOException {
/* 1049 */         FsShell.this.delete(p, srcFs, recursive, skipTrash);
/*      */       }
/*      */     }
/* 1046 */     .globAndProcess(srcPattern, srcPattern.getFileSystem(getConf()));
/*      */   }
/*      */ 
/*      */   private void delete(Path src, FileSystem srcFs, boolean recursive, boolean skipTrash)
/*      */     throws IOException
/*      */   {
/* 1057 */     FileStatus fs = null;
/*      */     try {
/* 1059 */       fs = srcFs.getFileStatus(src);
/*      */     }
/*      */     catch (FileNotFoundException fnfe) {
/* 1062 */       throw new FileNotFoundException(new StringBuilder().append("cannot remove ").append(src).append(": No such file or directory.").toString());
/*      */     }
/*      */ 
/* 1066 */     if ((fs.isDir()) && (!recursive)) {
/* 1067 */       throw new IOException(new StringBuilder().append("Cannot remove directory \"").append(src).append("\", use -rmr instead").toString());
/*      */     }
/*      */ 
/* 1071 */     if (!skipTrash) {
/*      */       try {
/* 1073 */         Trash trashTmp = new Trash(srcFs, getConf());
/* 1074 */         if (trashTmp.moveToTrash(src)) {
/* 1075 */           System.out.println(new StringBuilder().append("Moved to trash: ").append(src).toString());
/* 1076 */           return;
/*      */         }
/*      */       } catch (IOException e) {
/* 1079 */         Exception cause = (Exception)e.getCause();
/* 1080 */         String msg = "";
/* 1081 */         if (cause != null) {
/* 1082 */           msg = cause.getLocalizedMessage();
/*      */         }
/* 1084 */         System.err.println(new StringBuilder().append("Problem with Trash.").append(msg).append(". Consider using -skipTrash option").toString());
/* 1085 */         throw e;
/*      */       }
/*      */     }
/*      */ 
/* 1089 */     if (srcFs.delete(src, true))
/* 1090 */       System.out.println(new StringBuilder().append("Deleted ").append(src).toString());
/*      */     else
/* 1092 */       throw new IOException(new StringBuilder().append("Delete failed ").append(src).toString());
/*      */   }
/*      */ 
/*      */   private void expunge() throws IOException {
/* 1096 */     getTrash().expunge();
/* 1097 */     getTrash().checkpoint();
/*      */   }
/*      */ 
/*      */   public Path getCurrentTrashDir()
/*      */     throws IOException
/*      */   {
/* 1104 */     return getTrash().getCurrentTrashDir();
/*      */   }
/*      */ 
/*      */   private void tail(String[] cmd, int pos)
/*      */     throws IOException
/*      */   {
/* 1114 */     CommandFormat c = new CommandFormat("tail", 1, 1, new String[] { "f" });
/* 1115 */     String src = null;
/* 1116 */     Path path = null;
/*      */     try
/*      */     {
/* 1119 */       List parameters = c.parse(cmd, pos);
/* 1120 */       src = (String)parameters.get(0);
/*      */     } catch (IllegalArgumentException iae) {
/* 1122 */       System.err.println("Usage: java FsShell -tail [-f] <file>");
/* 1123 */       throw iae;
/*      */     }
/* 1125 */     boolean foption = c.getOpt("f");
/* 1126 */     path = new Path(src);
/* 1127 */     FileSystem srcFs = path.getFileSystem(getConf());
/* 1128 */     if (srcFs.isDirectory(path)) {
/* 1129 */       throw new IOException("Source must be a file.");
/*      */     }
/*      */ 
/* 1132 */     long fileSize = srcFs.getFileStatus(path).getLen();
/* 1133 */     long offset = fileSize > 1024L ? fileSize - 1024L : 0L;
/*      */     while (true)
/*      */     {
/* 1136 */       FSDataInputStream in = srcFs.open(path);
/* 1137 */       in.seek(offset);
/* 1138 */       IOUtils.copyBytes(in, System.out, 1024, false);
/* 1139 */       offset = in.getPos();
/* 1140 */       in.close();
/* 1141 */       if (!foption) {
/*      */         break;
/*      */       }
/* 1144 */       fileSize = srcFs.getFileStatus(path).getLen();
/* 1145 */       offset = fileSize > offset ? offset : fileSize;
/*      */       try {
/* 1147 */         Thread.sleep(5000L);
/*      */       } catch (InterruptedException e) {
/* 1149 */         break;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static FileStatus[] shellListStatus(String cmd, FileSystem srcFs, FileStatus src)
/*      */   {
/* 1179 */     if (!src.isDir()) {
/* 1180 */       FileStatus[] files = { src };
/* 1181 */       return files;
/*      */     }
/* 1183 */     Path path = src.getPath();
/*      */     try {
/* 1185 */       FileStatus[] files = srcFs.listStatus(path);
/* 1186 */       if (files == null) {
/* 1187 */         System.err.println(new StringBuilder().append(cmd).append(": could not get listing for '").append(path).append("'").toString());
/*      */       }
/*      */ 
/* 1190 */       return files;
/*      */     } catch (IOException e) {
/* 1192 */       System.err.println(new StringBuilder().append(cmd).append(": could not get get listing for '").append(path).append("' : ").append(e.getMessage().split("\n")[0]).toString());
/*      */     }
/*      */ 
/* 1196 */     return null;
/*      */   }
/*      */ 
/*      */   private static int runCmdHandler(CmdHandler handler, FileStatus stat, FileSystem srcFs, boolean recursive)
/*      */     throws IOException
/*      */   {
/* 1207 */     int errors = 0;
/* 1208 */     handler.run(stat, srcFs);
/* 1209 */     if ((recursive) && (stat.isDir()) && (handler.okToContinue())) {
/* 1210 */       FileStatus[] files = shellListStatus(handler.getName(), srcFs, stat);
/* 1211 */       if (files == null) {
/* 1212 */         return 1;
/*      */       }
/* 1214 */       for (FileStatus file : files) {
/* 1215 */         errors += runCmdHandler(handler, file, srcFs, recursive);
/*      */       }
/*      */     }
/* 1218 */     return errors;
/*      */   }
/*      */ 
/*      */   int runCmdHandler(CmdHandler handler, String[] args, int startIndex, boolean recursive)
/*      */     throws IOException
/*      */   {
/* 1225 */     int errors = 0;
/*      */ 
/* 1227 */     for (int i = startIndex; i < args.length; i++) {
/* 1228 */       Path srcPath = new Path(args[i]);
/* 1229 */       FileSystem srcFs = srcPath.getFileSystem(getConf());
/* 1230 */       Path[] paths = FileUtil.stat2Paths(srcFs.globStatus(srcPath), srcPath);
/*      */ 
/* 1232 */       if (paths.length == 0) {
/* 1233 */         System.err.println(new StringBuilder().append(handler.getName()).append(": could not get status for '").append(args[i]).append("'").toString());
/*      */ 
/* 1235 */         errors++;
/*      */       }
/* 1237 */       for (Path path : paths) {
/* 1238 */         FileStatus file = null;
/*      */         try {
/* 1240 */           file = srcFs.getFileStatus(path);
/* 1241 */           if (file == null) {
/* 1242 */             System.err.println(new StringBuilder().append(handler.getName()).append(": could not get status for '").append(path).append("'").toString());
/*      */ 
/* 1244 */             errors++;
/*      */           } else {
/* 1246 */             errors += runCmdHandler(handler, file, srcFs, recursive);
/*      */           }
/*      */         } catch (IOException e) {
/* 1249 */           String msg = e.getCause().getMessage() != null ? e.getCause().getLocalizedMessage() : e.getMessage() != null ? e.getLocalizedMessage() : "null";
/*      */ 
/* 1252 */           msg = msg.split("\n")[0];
/* 1253 */           if (file == null)
/*      */           {
/* 1255 */             msg = new StringBuilder().append(": could not get status for '").append(path).append("': ").append(msg).toString();
/*      */           }
/*      */           else {
/* 1258 */             msg = new StringBuilder().append(": failed on '").append(path).append("': ").append(msg).toString();
/*      */           }
/* 1260 */           System.err.println(new StringBuilder().append(handler.getName()).append(msg).toString());
/* 1261 */           errors++;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1266 */     return (errors > 0) || (handler.getErrorCode() != 0) ? 1 : 0;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static String byteDesc(long len)
/*      */   {
/* 1275 */     return StringUtils.byteDesc(len);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static synchronized String limitDecimalTo2(double d)
/*      */   {
/* 1283 */     return StringUtils.limitDecimalTo2(d);
/*      */   }
/*      */ 
/*      */   private void printHelp(String cmd) {
/* 1287 */     String summary = new StringBuilder().append("hadoop fs is the command to execute fs commands. The full syntax is: \n\nhadoop fs [-fs <local | file system URI>] [-conf <configuration file>]\n\t[-D <property=value>] [-ls <path>] [-lsr <path>] [-du <path>]\n\t[-dus <path>] [-mv <src> <dst>] [-cp <src> <dst>] [-rm [-skipTrash] <src>]\n\t[-rmr [-skipTrash] <src>] [-put <localsrc> ... <dst>] [-copyFromLocal <localsrc> ... <dst>]\n\t[-moveFromLocal <localsrc> ... <dst>] [-get [-ignoreCrc] [-crc] <src> <localdst>\n\t[-getmerge <src> <localdst> [addnl]] [-cat <src>]\n\t[").append(COPYTOLOCAL_SHORT_USAGE).append("] [-moveToLocal <src> <localdst>]\n\t").append("[-mkdir <path>] [-report] [").append("-setrep [-R] [-w] <rep> <path/file>").append("]\n\t").append("[-touchz <path>] [-test -[ezd] <path>] [-stat [format] <path>]\n\t").append("[-tail [-f] <path>] [-text <path>]\n\t").append("[").append(FsShellPermissions.CHMOD_USAGE).append("]\n\t").append("[").append(FsShellPermissions.CHOWN_USAGE).append("]\n\t").append("[").append(FsShellPermissions.CHGRP_USAGE).append("]\n\t").append("[").append("-count[-q] <path>").append("]\n\t").append("[-help [cmd]]\n").toString();
/*      */ 
/* 1306 */     String conf = "-conf <configuration file>:  Specify an application configuration file.";
/*      */ 
/* 1308 */     String D = "-D <property=value>:  Use value for given property.";
/*      */ 
/* 1310 */     String fs = "-fs [local | <file system URI>]: \tSpecify the file system to use.\n\t\tIf not specified, the current configuration is used, \n\t\ttaken from the following, in increasing precedence: \n\t\t\tcore-default.xml inside the hadoop jar file \n\t\t\tcore-site.xml in $HADOOP_CONF_DIR \n\t\t'local' means use the local file system as your DFS. \n\t\t<file system URI> specifies a particular file system to \n\t\tcontact. This argument is optional but if used must appear\n\t\tappear first on the command line.  Exactly one additional\n\t\targument must be specified. \n";
/*      */ 
/* 1322 */     String ls = "-ls <path>: \tList the contents that match the specified file pattern. If\n\t\tpath is not specified, the contents of /user/<currentUser>\n\t\twill be listed. Directory entries are of the form \n\t\t\tdirName (full path) <dir> \n\t\tand file entries are of the form \n\t\t\tfileName(full path) <r n> size \n\t\twhere n is the number of replicas specified for the file \n\t\tand size is the size of the file, in bytes.\n";
/*      */ 
/* 1331 */     String lsr = "-lsr <path>: \tRecursively list the contents that match the specified\n\t\tfile pattern.  Behaves very similarly to hadoop fs -ls,\n\t\texcept that the data is shown for all the entries in the\n\t\tsubtree.\n";
/*      */ 
/* 1336 */     String du = "-du <path>: \tShow the amount of space, in bytes, used by the files that \n\t\tmatch the specified file pattern.  Equivalent to the unix\n\t\tcommand \"du -sb <path>/*\" in case of a directory, \n\t\tand to \"du -b <path>\" in case of a file.\n\t\tThe output is in the form \n\t\t\tname(full path) size (in bytes)\n";
/*      */ 
/* 1343 */     String dus = "-dus <path>: \tShow the amount of space, in bytes, used by the files that \n\t\tmatch the specified file pattern.  Equivalent to the unix\n\t\tcommand \"du -sb\"  The output is in the form \n\t\t\tname(full path) size (in bytes)\n";
/*      */ 
/* 1348 */     String mv = "-mv <src> <dst>:   Move files that match the specified file pattern <src>\n\t\tto a destination <dst>.  When moving multiple files, the \n\t\tdestination must be a directory. \n";
/*      */ 
/* 1352 */     String cp = "-cp <src> <dst>:   Copy files that match the file pattern <src> to a \n\t\tdestination.  When copying multiple files, the destination\n\t\tmust be a directory. \n";
/*      */ 
/* 1356 */     String rm = "-rm [-skipTrash] <src>: \tDelete all files that match the specified file pattern.\n\t\tEquivalent to the Unix command \"rm <src>\"\n\t\t-skipTrash option bypasses trash, if enabled, and immediately\ndeletes <src>";
/*      */ 
/* 1361 */     String rmr = "-rmr [-skipTrash] <src>: \tRemove all directories which match the specified file \n\t\tpattern. Equivalent to the Unix command \"rm -rf <src>\"\n\t\t-skipTrash option bypasses trash, if enabled, and immediately\ndeletes <src>";
/*      */ 
/* 1366 */     String put = "-put <localsrc> ... <dst>: \tCopy files from the local file system \n\t\tinto fs. \n";
/*      */ 
/* 1369 */     String copyFromLocal = "-copyFromLocal <localsrc> ... <dst>: Identical to the -put command.\n";
/*      */ 
/* 1372 */     String moveFromLocal = "-moveFromLocal <localsrc> ... <dst>: Same as -put, except that the source is\n\t\tdeleted after it's copied.\n";
/*      */ 
/* 1375 */     String get = "-get [-ignoreCrc] [-crc] <src> <localdst>:  Copy files that match the file pattern <src> \n\t\tto the local name.  <src> is kept.  When copying mutiple, \n\t\tfiles, the destination must be a directory. \n";
/*      */ 
/* 1380 */     String getmerge = "-getmerge <src> <localdst>:  Get all the files in the directories that \n\t\tmatch the source file pattern and merge and sort them to only\n\t\tone file on local fs. <src> is kept.\n";
/*      */ 
/* 1384 */     String cat = "-cat <src>: \tFetch all files that match the file pattern <src> \n\t\tand display their content on stdout.\n";
/*      */ 
/* 1388 */     String text = "-text <src>: \tTakes a source file and outputs the file in text format.\n\t\tThe allowed formats are zip and TextRecordInputStream.\n";
/*      */ 
/* 1392 */     String copyToLocal = new StringBuilder().append(COPYTOLOCAL_SHORT_USAGE).append(":  Identical to the -get command.\n").toString();
/*      */ 
/* 1395 */     String moveToLocal = "-moveToLocal <src> <localdst>:  Not implemented yet \n";
/*      */ 
/* 1397 */     String mkdir = "-mkdir <path>: \tCreate a directory in specified location. \n";
/*      */ 
/* 1399 */     String setrep = "-setrep [-R] [-w] <rep> <path/file>:  Set the replication level of a file. \n\t\tThe -R flag requests a recursive change of replication level \n\t\tfor an entire tree.\n";
/*      */ 
/* 1404 */     String touchz = "-touchz <path>: Write a timestamp in yyyy-MM-dd HH:mm:ss format\n\t\tin a file at <path>. An error is returned if the file exists with non-zero length\n";
/*      */ 
/* 1407 */     String test = "-test -[ezd] <path>: If file { exists, has zero length, is a directory\n\t\tthen return 0, else return 1.\n";
/*      */ 
/* 1410 */     String stat = "-stat [format] <path>: Print statistics about the file/directory at <path>\n\t\tin the specified format. Format accepts filesize in blocks (%b), filename (%n),\n\t\tblock size (%o), replication (%r), modification date (%y, %Y)\n";
/*      */ 
/* 1414 */     String tail = "-tail [-f] <file>:  Show the last 1KB of the file. \n\t\tThe -f option shows apended data as the file grows. \n";
/*      */ 
/* 1418 */     String chmod = new StringBuilder().append(FsShellPermissions.CHMOD_USAGE).append("\n").append("\t\tChanges permissions of a file.\n").append("\t\tThis works similar to shell's chmod with a few exceptions.\n\n").append("\t-R\tmodifies the files recursively. This is the only option\n").append("\t\tcurrently supported.\n\n").append("\tMODE\tMode is same as mode used for chmod shell command.\n").append("\t\tOnly letters recognized are 'rwxX'. E.g. a+r,g-w,+rwx,o=r\n\n").append("\tOCTALMODE Mode specifed in 3 digits. Unlike shell command,\n").append("\t\tthis requires all three digits.\n").append("\t\tE.g. 754 is same as u=rwx,g=rx,o=r\n\n").append("\t\tIf none of 'augo' is specified, 'a' is assumed and unlike\n").append("\t\tshell command, no umask is applied.\n").toString();
/*      */ 
/* 1431 */     String chown = new StringBuilder().append(FsShellPermissions.CHOWN_USAGE).append("\n").append("\t\tChanges owner and group of a file.\n").append("\t\tThis is similar to shell's chown with a few exceptions.\n\n").append("\t-R\tmodifies the files recursively. This is the only option\n").append("\t\tcurrently supported.\n\n").append("\t\tIf only owner or group is specified then only owner or\n").append("\t\tgroup is modified.\n\n").append("\t\tThe owner and group names may only cosists of digits, alphabet,\n").append("\t\tand any of '-_.@/' i.e. [-_.@/a-zA-Z0-9]. The names are case\n").append("\t\tsensitive.\n\n").append("\t\tWARNING: Avoid using '.' to separate user name and group though\n").append("\t\tLinux allows it. If user names have dots in them and you are\n").append("\t\tusing local file system, you might see surprising results since\n").append("\t\tshell command 'chown' is used for local files.\n").toString();
/*      */ 
/* 1446 */     String chgrp = new StringBuilder().append(FsShellPermissions.CHGRP_USAGE).append("\n").append("\t\tThis is equivalent to -chown ... :GROUP ...\n").toString();
/*      */ 
/* 1449 */     String help = "-help [cmd]: \tDisplays help for given command or all commands if none\n\t\tis specified.\n";
/*      */ 
/* 1452 */     if ("fs".equals(cmd)) {
/* 1453 */       System.out.println(fs);
/* 1454 */     } else if ("conf".equals(cmd)) {
/* 1455 */       System.out.println(conf);
/* 1456 */     } else if ("D".equals(cmd)) {
/* 1457 */       System.out.println(D);
/* 1458 */     } else if ("ls".equals(cmd)) {
/* 1459 */       System.out.println(ls);
/* 1460 */     } else if ("lsr".equals(cmd)) {
/* 1461 */       System.out.println(lsr);
/* 1462 */     } else if ("du".equals(cmd)) {
/* 1463 */       System.out.println(du);
/* 1464 */     } else if ("dus".equals(cmd)) {
/* 1465 */       System.out.println(dus);
/* 1466 */     } else if ("rm".equals(cmd)) {
/* 1467 */       System.out.println(rm);
/* 1468 */     } else if ("rmr".equals(cmd)) {
/* 1469 */       System.out.println(rmr);
/* 1470 */     } else if ("mkdir".equals(cmd)) {
/* 1471 */       System.out.println(mkdir);
/* 1472 */     } else if ("mv".equals(cmd)) {
/* 1473 */       System.out.println(mv);
/* 1474 */     } else if ("cp".equals(cmd)) {
/* 1475 */       System.out.println(cp);
/* 1476 */     } else if ("put".equals(cmd)) {
/* 1477 */       System.out.println(put);
/* 1478 */     } else if ("copyFromLocal".equals(cmd)) {
/* 1479 */       System.out.println(copyFromLocal);
/* 1480 */     } else if ("moveFromLocal".equals(cmd)) {
/* 1481 */       System.out.println(moveFromLocal);
/* 1482 */     } else if ("get".equals(cmd)) {
/* 1483 */       System.out.println(get);
/* 1484 */     } else if ("getmerge".equals(cmd)) {
/* 1485 */       System.out.println(getmerge);
/* 1486 */     } else if ("copyToLocal".equals(cmd)) {
/* 1487 */       System.out.println(copyToLocal);
/* 1488 */     } else if ("moveToLocal".equals(cmd)) {
/* 1489 */       System.out.println(moveToLocal);
/* 1490 */     } else if ("cat".equals(cmd)) {
/* 1491 */       System.out.println(cat);
/* 1492 */     } else if ("get".equals(cmd)) {
/* 1493 */       System.out.println(get);
/* 1494 */     } else if ("setrep".equals(cmd)) {
/* 1495 */       System.out.println(setrep);
/* 1496 */     } else if ("touchz".equals(cmd)) {
/* 1497 */       System.out.println(touchz);
/* 1498 */     } else if ("test".equals(cmd)) {
/* 1499 */       System.out.println(test);
/* 1500 */     } else if ("text".equals(cmd)) {
/* 1501 */       System.out.println(text);
/* 1502 */     } else if ("stat".equals(cmd)) {
/* 1503 */       System.out.println(stat);
/* 1504 */     } else if ("tail".equals(cmd)) {
/* 1505 */       System.out.println(tail);
/* 1506 */     } else if ("chmod".equals(cmd)) {
/* 1507 */       System.out.println(chmod);
/* 1508 */     } else if ("chown".equals(cmd)) {
/* 1509 */       System.out.println(chown);
/* 1510 */     } else if ("chgrp".equals(cmd)) {
/* 1511 */       System.out.println(chgrp);
/* 1512 */     } else if (Count.matches(cmd)) {
/* 1513 */       System.out.println(Count.DESCRIPTION);
/* 1514 */     } else if ("help".equals(cmd)) {
/* 1515 */       System.out.println(help);
/*      */     } else {
/* 1517 */       System.out.println(summary);
/* 1518 */       System.out.println(fs);
/* 1519 */       System.out.println(ls);
/* 1520 */       System.out.println(lsr);
/* 1521 */       System.out.println(du);
/* 1522 */       System.out.println(dus);
/* 1523 */       System.out.println(mv);
/* 1524 */       System.out.println(cp);
/* 1525 */       System.out.println(rm);
/* 1526 */       System.out.println(rmr);
/* 1527 */       System.out.println(put);
/* 1528 */       System.out.println(copyFromLocal);
/* 1529 */       System.out.println(moveFromLocal);
/* 1530 */       System.out.println(get);
/* 1531 */       System.out.println(getmerge);
/* 1532 */       System.out.println(cat);
/* 1533 */       System.out.println(copyToLocal);
/* 1534 */       System.out.println(moveToLocal);
/* 1535 */       System.out.println(mkdir);
/* 1536 */       System.out.println(setrep);
/* 1537 */       System.out.println(tail);
/* 1538 */       System.out.println(touchz);
/* 1539 */       System.out.println(test);
/* 1540 */       System.out.println(text);
/* 1541 */       System.out.println(stat);
/* 1542 */       System.out.println(chmod);
/* 1543 */       System.out.println(chown);
/* 1544 */       System.out.println(chgrp);
/* 1545 */       System.out.println(Count.DESCRIPTION);
/* 1546 */       System.out.println(help);
/*      */     }
/*      */   }
/*      */ 
/*      */   private int doall(String cmd, String[] argv, int startindex)
/*      */   {
/* 1557 */     int exitCode = 0;
/* 1558 */     int i = startindex;
/* 1559 */     boolean rmSkipTrash = false;
/*      */ 
/* 1562 */     if ((("-rm".equals(cmd)) || ("-rmr".equals(cmd))) && ("-skipTrash".equals(argv[i])))
/*      */     {
/* 1564 */       rmSkipTrash = true;
/* 1565 */       i++;
/*      */     }
/*      */ 
/* 1571 */     for (; i < argv.length; i++)
/*      */     {
/*      */       try
/*      */       {
/* 1576 */         if ("-cat".equals(cmd))
/* 1577 */           cat(argv[i], true);
/* 1578 */         else if ("-mkdir".equals(cmd))
/* 1579 */           mkdir(argv[i]);
/* 1580 */         else if ("-rm".equals(cmd))
/* 1581 */           delete(argv[i], false, rmSkipTrash);
/* 1582 */         else if ("-rmr".equals(cmd))
/* 1583 */           delete(argv[i], true, rmSkipTrash);
/* 1584 */         else if ("-du".equals(cmd))
/* 1585 */           du(argv[i]);
/* 1586 */         else if ("-dus".equals(cmd))
/* 1587 */           dus(argv[i]);
/* 1588 */         else if (Count.matches(cmd))
/* 1589 */           new Count(argv, i, getConf()).runAll();
/* 1590 */         else if ("-ls".equals(cmd))
/* 1591 */           exitCode = ls(argv[i], false);
/* 1592 */         else if ("-lsr".equals(cmd))
/* 1593 */           exitCode = ls(argv[i], true);
/* 1594 */         else if ("-touchz".equals(cmd))
/* 1595 */           touchz(argv[i]);
/* 1596 */         else if ("-text".equals(cmd)) {
/* 1597 */           text(argv[i]);
/*      */         }
/*      */ 
/*      */       }
/*      */       catch (RemoteException e)
/*      */       {
/* 1604 */         exitCode = -1;
/*      */         try
/*      */         {
/* 1607 */           String[] content = e.getLocalizedMessage().split("\n");
/* 1608 */           System.err.println(new StringBuilder().append(cmd.substring(1)).append(": ").append(content[0]).toString());
/*      */         }
/*      */         catch (Exception ex) {
/* 1611 */           System.err.println(new StringBuilder().append(cmd.substring(1)).append(": ").append(ex.getLocalizedMessage()).toString());
/*      */         }
/*      */ 
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/* 1618 */         exitCode = -1;
/* 1619 */         String content = e.getLocalizedMessage();
/* 1620 */         if (content != null) {
/* 1621 */           content = content.split("\n")[0];
/*      */         }
/* 1623 */         System.err.println(new StringBuilder().append(cmd.substring(1)).append(": ").append(content).toString());
/*      */       }
/*      */     }
/*      */ 
/* 1627 */     return exitCode;
/*      */   }
/*      */ 
/*      */   private static void printUsage(String cmd)
/*      */   {
/* 1635 */     String prefix = new StringBuilder().append("Usage: java ").append(FsShell.class.getSimpleName()).toString();
/* 1636 */     if ("-fs".equals(cmd)) {
/* 1637 */       System.err.println("Usage: java FsShell [-fs <local | file system URI>]");
/*      */     }
/* 1639 */     else if ("-conf".equals(cmd)) {
/* 1640 */       System.err.println("Usage: java FsShell [-conf <configuration file>]");
/*      */     }
/* 1642 */     else if ("-D".equals(cmd)) {
/* 1643 */       System.err.println("Usage: java FsShell [-D <[property=value>]");
/*      */     }
/* 1645 */     else if (("-ls".equals(cmd)) || ("-lsr".equals(cmd)) || ("-du".equals(cmd)) || ("-dus".equals(cmd)) || ("-touchz".equals(cmd)) || ("-mkdir".equals(cmd)) || ("-text".equals(cmd)))
/*      */     {
/* 1649 */       System.err.println(new StringBuilder().append("Usage: java FsShell [").append(cmd).append(" <path>]").toString());
/*      */     }
/* 1651 */     else if (Count.matches(cmd)) {
/* 1652 */       System.err.println(new StringBuilder().append(prefix).append(" [").append("-count[-q] <path>").append("]").toString());
/* 1653 */     } else if (("-rm".equals(cmd)) || ("-rmr".equals(cmd))) {
/* 1654 */       System.err.println(new StringBuilder().append("Usage: java FsShell [").append(cmd).append(" [-skipTrash] <src>]").toString());
/*      */     }
/* 1656 */     else if (("-mv".equals(cmd)) || ("-cp".equals(cmd))) {
/* 1657 */       System.err.println(new StringBuilder().append("Usage: java FsShell [").append(cmd).append(" <src> <dst>]").toString());
/*      */     }
/* 1659 */     else if (("-put".equals(cmd)) || ("-copyFromLocal".equals(cmd)) || ("-moveFromLocal".equals(cmd)))
/*      */     {
/* 1661 */       System.err.println(new StringBuilder().append("Usage: java FsShell [").append(cmd).append(" <localsrc> ... <dst>]").toString());
/*      */     }
/* 1663 */     else if ("-get".equals(cmd)) {
/* 1664 */       System.err.println("Usage: java FsShell [-get [-ignoreCrc] [-crc] <src> <localdst>]");
/* 1665 */     } else if ("-copyToLocal".equals(cmd)) {
/* 1666 */       System.err.println(new StringBuilder().append("Usage: java FsShell [").append(COPYTOLOCAL_SHORT_USAGE).append("]").toString());
/* 1667 */     } else if ("-moveToLocal".equals(cmd)) {
/* 1668 */       System.err.println(new StringBuilder().append("Usage: java FsShell [").append(cmd).append(" [-crc] <src> <localdst>]").toString());
/*      */     }
/* 1670 */     else if ("-cat".equals(cmd)) {
/* 1671 */       System.err.println(new StringBuilder().append("Usage: java FsShell [").append(cmd).append(" <src>]").toString());
/*      */     }
/* 1673 */     else if ("-setrep".equals(cmd)) {
/* 1674 */       System.err.println("Usage: java FsShell [-setrep [-R] [-w] <rep> <path/file>]");
/* 1675 */     } else if ("-test".equals(cmd)) {
/* 1676 */       System.err.println("Usage: java FsShell [-test -[ezd] <path>]");
/*      */     }
/* 1678 */     else if ("-stat".equals(cmd)) {
/* 1679 */       System.err.println("Usage: java FsShell [-stat [format] <path>]");
/*      */     }
/* 1681 */     else if ("-tail".equals(cmd)) {
/* 1682 */       System.err.println("Usage: java FsShell [-tail [-f] <file>]");
/*      */     } else {
/* 1684 */       System.err.println("Usage: java FsShell");
/* 1685 */       System.err.println("           [-ls <path>]");
/* 1686 */       System.err.println("           [-lsr <path>]");
/* 1687 */       System.err.println("           [-du <path>]");
/* 1688 */       System.err.println("           [-dus <path>]");
/* 1689 */       System.err.println("           [-count[-q] <path>]");
/* 1690 */       System.err.println("           [-mv <src> <dst>]");
/* 1691 */       System.err.println("           [-cp <src> <dst>]");
/* 1692 */       System.err.println("           [-rm [-skipTrash] <path>]");
/* 1693 */       System.err.println("           [-rmr [-skipTrash] <path>]");
/* 1694 */       System.err.println("           [-expunge]");
/* 1695 */       System.err.println("           [-put <localsrc> ... <dst>]");
/* 1696 */       System.err.println("           [-copyFromLocal <localsrc> ... <dst>]");
/* 1697 */       System.err.println("           [-moveFromLocal <localsrc> ... <dst>]");
/* 1698 */       System.err.println("           [-get [-ignoreCrc] [-crc] <src> <localdst>]");
/* 1699 */       System.err.println("           [-getmerge <src> <localdst> [addnl]]");
/* 1700 */       System.err.println("           [-cat <src>]");
/* 1701 */       System.err.println("           [-text <src>]");
/* 1702 */       System.err.println(new StringBuilder().append("           [").append(COPYTOLOCAL_SHORT_USAGE).append("]").toString());
/* 1703 */       System.err.println("           [-moveToLocal [-crc] <src> <localdst>]");
/* 1704 */       System.err.println("           [-mkdir <path>]");
/* 1705 */       System.err.println("           [-setrep [-R] [-w] <rep> <path/file>]");
/* 1706 */       System.err.println("           [-touchz <path>]");
/* 1707 */       System.err.println("           [-test -[ezd] <path>]");
/* 1708 */       System.err.println("           [-stat [format] <path>]");
/* 1709 */       System.err.println("           [-tail [-f] <file>]");
/* 1710 */       System.err.println(new StringBuilder().append("           [").append(FsShellPermissions.CHMOD_USAGE).append("]").toString());
/* 1711 */       System.err.println(new StringBuilder().append("           [").append(FsShellPermissions.CHOWN_USAGE).append("]").toString());
/* 1712 */       System.err.println(new StringBuilder().append("           [").append(FsShellPermissions.CHGRP_USAGE).append("]").toString());
/* 1713 */       System.err.println("           [-help [cmd]]");
/* 1714 */       System.err.println();
/* 1715 */       ToolRunner.printGenericCommandUsage(System.err);
/*      */     }
/*      */   }
/*      */ 
/*      */   public int run(String[] argv)
/*      */     throws Exception
/*      */   {
/* 1724 */     if (argv.length < 1) {
/* 1725 */       printUsage("");
/* 1726 */       return -1;
/*      */     }
/*      */ 
/* 1729 */     int exitCode = -1;
/* 1730 */     int i = 0;
/* 1731 */     String cmd = argv[(i++)];
/*      */ 
/* 1736 */     if (("-put".equals(cmd)) || ("-test".equals(cmd)) || ("-copyFromLocal".equals(cmd)) || ("-moveFromLocal".equals(cmd)))
/*      */     {
/* 1738 */       if (argv.length < 3) {
/* 1739 */         printUsage(cmd);
/* 1740 */         return exitCode;
/*      */       }
/* 1742 */     } else if (("-get".equals(cmd)) || ("-copyToLocal".equals(cmd)) || ("-moveToLocal".equals(cmd)))
/*      */     {
/* 1744 */       if (argv.length < 3) {
/* 1745 */         printUsage(cmd);
/* 1746 */         return exitCode;
/*      */       }
/* 1748 */     } else if (("-mv".equals(cmd)) || ("-cp".equals(cmd))) {
/* 1749 */       if (argv.length < 3) {
/* 1750 */         printUsage(cmd);
/* 1751 */         return exitCode;
/*      */       }
/* 1753 */     } else if (("-rm".equals(cmd)) || ("-rmr".equals(cmd)) || ("-cat".equals(cmd)) || ("-mkdir".equals(cmd)) || ("-touchz".equals(cmd)) || ("-stat".equals(cmd)) || ("-text".equals(cmd)))
/*      */     {
/* 1757 */       if (argv.length < 2) {
/* 1758 */         printUsage(cmd);
/* 1759 */         return exitCode;
/*      */       }
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/* 1765 */       init();
/*      */     } catch (RPC.VersionMismatch v) {
/* 1767 */       System.err.println("Version Mismatch between client and server... command aborted.");
/*      */ 
/* 1769 */       return exitCode;
/*      */     } catch (IOException e) {
/* 1771 */       System.err.println(new StringBuilder().append("Bad connection to FS. command aborted. exception: ").append(e.getLocalizedMessage()).toString());
/*      */ 
/* 1773 */       return exitCode;
/*      */     }
/*      */ 
/* 1776 */     exitCode = 0;
/*      */     try {
/* 1778 */       if (("-put".equals(cmd)) || ("-copyFromLocal".equals(cmd))) {
/* 1779 */         Path[] srcs = new Path[argv.length - 2];
/* 1780 */         for (int j = 0; i < argv.length - 1; )
/* 1781 */           srcs[(j++)] = new Path(argv[(i++)]);
/* 1782 */         copyFromLocal(srcs, argv[(i++)]);
/* 1783 */       } else if ("-moveFromLocal".equals(cmd)) {
/* 1784 */         Path[] srcs = new Path[argv.length - 2];
/* 1785 */         for (int j = 0; i < argv.length - 1; )
/* 1786 */           srcs[(j++)] = new Path(argv[(i++)]);
/* 1787 */         moveFromLocal(srcs, argv[(i++)]);
/* 1788 */       } else if (("-get".equals(cmd)) || ("-copyToLocal".equals(cmd))) {
/* 1789 */         copyToLocal(argv, i);
/* 1790 */       } else if ("-getmerge".equals(cmd)) {
/* 1791 */         if (argv.length > i + 2)
/* 1792 */           copyMergeToLocal(argv[(i++)], new Path(argv[(i++)]), Boolean.parseBoolean(argv[(i++)]));
/*      */         else
/* 1794 */           copyMergeToLocal(argv[(i++)], new Path(argv[(i++)]));
/* 1795 */       } else if ("-cat".equals(cmd)) {
/* 1796 */         exitCode = doall(cmd, argv, i);
/* 1797 */       } else if ("-text".equals(cmd)) {
/* 1798 */         exitCode = doall(cmd, argv, i);
/* 1799 */       } else if ("-moveToLocal".equals(cmd)) {
/* 1800 */         moveToLocal(argv[(i++)], new Path(argv[(i++)]));
/* 1801 */       } else if ("-setrep".equals(cmd)) {
/* 1802 */         setReplication(argv, i);
/* 1803 */       } else if (("-chmod".equals(cmd)) || ("-chown".equals(cmd)) || ("-chgrp".equals(cmd)))
/*      */       {
/* 1807 */         exitCode = FsShellPermissions.changePermissions(this.fs, cmd, argv, i, this);
/* 1808 */       } else if ("-ls".equals(cmd)) {
/* 1809 */         if (i < argv.length)
/* 1810 */           exitCode = doall(cmd, argv, i);
/*      */         else
/* 1812 */           exitCode = ls(".", false);
/*      */       }
/* 1814 */       else if ("-lsr".equals(cmd)) {
/* 1815 */         if (i < argv.length)
/* 1816 */           exitCode = doall(cmd, argv, i);
/*      */         else
/* 1818 */           exitCode = ls(".", true);
/*      */       }
/* 1820 */       else if ("-mv".equals(cmd)) {
/* 1821 */         exitCode = rename(argv, getConf());
/* 1822 */       } else if ("-cp".equals(cmd)) {
/* 1823 */         exitCode = copy(argv, getConf());
/* 1824 */       } else if ("-rm".equals(cmd)) {
/* 1825 */         exitCode = doall(cmd, argv, i);
/* 1826 */       } else if ("-rmr".equals(cmd)) {
/* 1827 */         exitCode = doall(cmd, argv, i);
/* 1828 */       } else if ("-expunge".equals(cmd)) {
/* 1829 */         expunge();
/* 1830 */       } else if ("-du".equals(cmd)) {
/* 1831 */         if (i < argv.length)
/* 1832 */           exitCode = doall(cmd, argv, i);
/*      */         else
/* 1834 */           du(".");
/*      */       }
/* 1836 */       else if ("-dus".equals(cmd)) {
/* 1837 */         if (i < argv.length)
/* 1838 */           exitCode = doall(cmd, argv, i);
/*      */         else
/* 1840 */           dus(".");
/*      */       }
/* 1842 */       else if (Count.matches(cmd)) {
/* 1843 */         exitCode = new Count(argv, i, getConf()).runAll();
/* 1844 */       } else if ("-mkdir".equals(cmd)) {
/* 1845 */         exitCode = doall(cmd, argv, i);
/* 1846 */       } else if ("-touchz".equals(cmd)) {
/* 1847 */         exitCode = doall(cmd, argv, i);
/* 1848 */       } else if ("-test".equals(cmd)) {
/* 1849 */         exitCode = test(argv, i);
/* 1850 */       } else if ("-stat".equals(cmd)) {
/* 1851 */         if (i + 1 < argv.length)
/* 1852 */           stat(argv[(i++)].toCharArray(), argv[(i++)]);
/*      */         else
/* 1854 */           stat("%y".toCharArray(), argv[i]);
/*      */       }
/* 1856 */       else if ("-help".equals(cmd)) {
/* 1857 */         if (i < argv.length)
/* 1858 */           printHelp(argv[i]);
/*      */         else
/* 1860 */           printHelp("");
/*      */       }
/* 1862 */       else if ("-tail".equals(cmd)) {
/* 1863 */         tail(argv, i);
/*      */       } else {
/* 1865 */         exitCode = -1;
/* 1866 */         System.err.println(new StringBuilder().append(cmd.substring(1)).append(": Unknown command").toString());
/* 1867 */         printUsage("");
/*      */       }
/*      */     } catch (IllegalArgumentException arge) { arge = 
/* 1898 */         arge;
/*      */ 
/* 1870 */       exitCode = -1;
/* 1871 */       System.err.println(new StringBuilder().append(cmd.substring(1)).append(": ").append(arge.getLocalizedMessage()).toString());
/* 1872 */       printUsage(cmd); } catch (RemoteException e) {
/* 1873 */       e = 
/* 1898 */         e;
/*      */ 
/* 1877 */       exitCode = -1;
/*      */       try
/*      */       {
/* 1880 */         String[] content = e.getLocalizedMessage().split("\n");
/* 1881 */         System.err.println(new StringBuilder().append(cmd.substring(1)).append(": ").append(content[0]).toString());
/*      */       }
/*      */       catch (Exception ex) {
/* 1884 */         System.err.println(new StringBuilder().append(cmd.substring(1)).append(": ").append(ex.getLocalizedMessage()).toString());
/*      */       }
/*      */     } catch (IOException e) {
/* 1887 */       e = 
/* 1898 */         e;
/*      */ 
/* 1891 */       exitCode = -1;
/* 1892 */       System.err.println(new StringBuilder().append(cmd.substring(1)).append(": ").append(e.getLocalizedMessage()).toString());
/*      */     } catch (Exception re) {
/* 1894 */       re = 
/* 1898 */         re;
/*      */ 
/* 1895 */       exitCode = -1;
/* 1896 */       System.err.println(new StringBuilder().append(cmd.substring(1)).append(": ").append(re.getLocalizedMessage()).toString());
/*      */     } finally {
/*      */     }
/* 1899 */     return exitCode;
/*      */   }
/*      */ 
/*      */   public void close() throws IOException {
/* 1903 */     if (this.fs != null) {
/* 1904 */       this.fs.close();
/* 1905 */       this.fs = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void main(String[] argv) throws Exception
/*      */   {
/* 1913 */     FsShell shell = new FsShell();
/*      */     int res;
/*      */     try
/*      */     {
/* 1916 */       res = ToolRunner.run(shell, argv);
/*      */     } finally {
/* 1918 */       shell.close();
/*      */     }
/* 1920 */     System.exit(res);
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*   60 */     modifFmt.setTimeZone(TimeZone.getTimeZone("UTC"));
/*      */   }
/*      */ 
/*      */   private abstract class DelayedExceptionThrowing
/*      */   {
/*      */     private DelayedExceptionThrowing()
/*      */     {
/*      */     }
/*      */ 
/*      */     abstract void process(Path paramPath, FileSystem paramFileSystem)
/*      */       throws IOException;
/*      */ 
/*      */     final void globAndProcess(Path srcPattern, FileSystem srcFs)
/*      */       throws IOException
/*      */     {
/* 1931 */       List exceptions = new ArrayList();
/* 1932 */       for (Path p : FileUtil.stat2Paths(srcFs.globStatus(srcPattern), srcPattern))
/*      */         try {
/* 1934 */           process(p, srcFs); } catch (IOException ioe) {
/* 1935 */           exceptions.add(ioe);
/*      */         }
/* 1937 */       if (!exceptions.isEmpty()) {
/* 1938 */         if (exceptions.size() == 1) {
/* 1939 */           throw ((IOException)exceptions.get(0));
/*      */         }
/* 1941 */         throw new IOException("Multiple IOExceptions: " + exceptions);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static abstract class CmdHandler
/*      */   {
/* 1160 */     protected int errorCode = 0;
/* 1161 */     protected boolean okToContinue = true;
/*      */     protected String cmdName;
/*      */ 
/*      */     int getErrorCode()
/*      */     {
/* 1164 */       return this.errorCode; } 
/* 1165 */     boolean okToContinue() { return this.okToContinue; } 
/* 1166 */     String getName() { return this.cmdName; }
/*      */ 
/*      */     protected CmdHandler(String cmdName, FileSystem fs) {
/* 1169 */       this.cmdName = cmdName;
/*      */     }
/*      */ 
/*      */     public abstract void run(FileStatus paramFileStatus, FileSystem paramFileSystem)
/*      */       throws IOException;
/*      */   }
/*      */ 
/*      */   private class TextRecordInputStream extends InputStream
/*      */   {
/*      */     SequenceFile.Reader r;
/*      */     WritableComparable key;
/*      */     Writable val;
/*      */     DataInputBuffer inbuf;
/*      */     DataOutputBuffer outbuf;
/*      */ 
/*      */     public TextRecordInputStream(FileStatus f)
/*      */       throws IOException
/*      */     {
/*  371 */       FileSystem pFS = f == null ? FsShell.this.getFS() : f.getPath().getFileSystem(FsShell.this.getConf());
/*      */ 
/*  373 */       this.r = new SequenceFile.Reader(pFS, f.getPath(), FsShell.this.getConf());
/*  374 */       this.key = ((WritableComparable)ReflectionUtils.newInstance(this.r.getKeyClass().asSubclass(WritableComparable.class), FsShell.this.getConf()));
/*      */ 
/*  376 */       this.val = ((Writable)ReflectionUtils.newInstance(this.r.getValueClass().asSubclass(Writable.class), FsShell.this.getConf()));
/*      */ 
/*  378 */       this.inbuf = new DataInputBuffer();
/*  379 */       this.outbuf = new DataOutputBuffer();
/*      */     }
/*      */ 
/*      */     public int read()
/*      */       throws IOException
/*      */     {
/*      */       int ret;
/*      */       int ret;
/*  384 */       if ((null == this.inbuf) || (-1 == (ret = this.inbuf.read()))) {
/*  385 */         if (!this.r.next(this.key, this.val)) {
/*  386 */           return -1;
/*      */         }
/*  388 */         byte[] tmp = this.key.toString().getBytes();
/*  389 */         this.outbuf.write(tmp, 0, tmp.length);
/*  390 */         this.outbuf.write(9);
/*  391 */         tmp = this.val.toString().getBytes();
/*  392 */         this.outbuf.write(tmp, 0, tmp.length);
/*  393 */         this.outbuf.write(10);
/*  394 */         this.inbuf.reset(this.outbuf.getData(), this.outbuf.getLength());
/*  395 */         this.outbuf.reset();
/*  396 */         ret = this.inbuf.read();
/*      */       }
/*  398 */       return ret;
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.FsShell
 * JD-Core Version:    0.6.1
 */
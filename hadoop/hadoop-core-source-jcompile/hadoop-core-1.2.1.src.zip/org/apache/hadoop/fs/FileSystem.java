/*      */ package org.apache.hadoop.fs;
/*      */ 
/*      */ import java.io.Closeable;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.net.URI;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.IdentityHashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.TreeSet;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.apache.hadoop.classification.InterfaceAudience.Private;
/*      */ import org.apache.hadoop.conf.Configuration;
/*      */ import org.apache.hadoop.conf.Configured;
/*      */ import org.apache.hadoop.fs.permission.FsPermission;
/*      */ import org.apache.hadoop.io.MultipleIOException;
/*      */ import org.apache.hadoop.net.NetUtils;
/*      */ import org.apache.hadoop.security.SecurityUtil;
/*      */ import org.apache.hadoop.security.UserGroupInformation;
/*      */ import org.apache.hadoop.security.token.Token;
/*      */ import org.apache.hadoop.util.Progressable;
/*      */ import org.apache.hadoop.util.ReflectionUtils;
/*      */ 
/*      */ public abstract class FileSystem extends Configured
/*      */   implements Closeable
/*      */ {
/*      */   public static final String FS_DEFAULT_NAME_KEY = "fs.default.name";
/*   70 */   public static final Log LOG = LogFactory.getLog(FileSystem.class);
/*      */ 
/*   73 */   private static final Cache CACHE = new Cache();
/*      */   private FileSystem.Cache.Key key;
/*   80 */   private static final Map<Class<? extends FileSystem>, Statistics> statisticsTable = new IdentityHashMap();
/*      */   protected Statistics statistics;
/*   92 */   private Set<Path> deleteOnExit = new TreeSet();
/*      */ 
/*  275 */   private static final ClientFinalizer clientFinalizer = new ClientFinalizer(null);
/*      */ 
/*  838 */   private static final PathFilter DEFAULT_FILTER = new PathFilter() {
/*      */     public boolean accept(Path file) {
/*  840 */       return true;
/*      */     }
/*  838 */   };
/*      */ 
/*      */   public static void addFileSystemForTesting(URI uri, Configuration conf, FileSystem fs)
/*      */     throws IOException
/*      */   {
/*  104 */     CACHE.map.put(new FileSystem.Cache.Key(uri, conf), fs);
/*      */   }
/*      */ 
/*      */   public static FileSystem get(URI uri, final Configuration conf, String user)
/*      */     throws IOException, InterruptedException
/*      */   {
/*      */     UserGroupInformation ugi;
/*      */     UserGroupInformation ugi;
/*  111 */     if (user == null)
/*  112 */       ugi = UserGroupInformation.getCurrentUser();
/*      */     else {
/*  114 */       ugi = UserGroupInformation.createRemoteUser(user);
/*      */     }
/*  116 */     return (FileSystem)ugi.doAs(new PrivilegedExceptionAction() {
/*      */       public FileSystem run() throws IOException {
/*  118 */         return FileSystem.get(this.val$uri, conf);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public static FileSystem get(Configuration conf) throws IOException {
/*  124 */     return get(getDefaultUri(conf), conf);
/*      */   }
/*      */ 
/*      */   public static URI getDefaultUri(Configuration conf)
/*      */   {
/*  132 */     return URI.create(fixName(conf.get("fs.default.name", "file:///")));
/*      */   }
/*      */ 
/*      */   public static void setDefaultUri(Configuration conf, URI uri)
/*      */   {
/*  140 */     conf.set("fs.default.name", uri.toString());
/*      */   }
/*      */ 
/*      */   public static void setDefaultUri(Configuration conf, String uri)
/*      */   {
/*  148 */     setDefaultUri(conf, URI.create(fixName(uri)));
/*      */   }
/*      */ 
/*      */   @InterfaceAudience.Private
/*      */   public static int getCacheSize()
/*      */   {
/*  156 */     return CACHE.map.size();
/*      */   }
/*      */ 
/*      */   public void initialize(URI name, Configuration conf)
/*      */     throws IOException
/*      */   {
/*  165 */     this.statistics = getStatistics(name.getScheme(), getClass());
/*      */   }
/*      */ 
/*      */   public abstract URI getUri();
/*      */ 
/*      */   protected URI getCanonicalUri()
/*      */   {
/*  177 */     return NetUtils.getCanonicalUri(getUri(), getDefaultPort());
/*      */   }
/*      */ 
/*      */   protected int getDefaultPort()
/*      */   {
/*  185 */     return 0;
/*      */   }
/*      */ 
/*      */   public String getCanonicalServiceName()
/*      */   {
/*  198 */     return SecurityUtil.buildDTServiceName(getUri(), getDefaultPort());
/*      */   }
/*      */   /** @deprecated */
/*      */   public String getName() {
/*  202 */     return getUri().toString();
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public static FileSystem getNamed(String name, Configuration conf) throws IOException {
/*  207 */     return get(URI.create(fixName(name)), conf);
/*      */   }
/*      */ 
/*      */   private static String fixName(String name)
/*      */   {
/*  215 */     if (name.equals("local")) {
/*  216 */       LOG.warn("\"local\" is a deprecated filesystem name. Use \"file:///\" instead.");
/*      */ 
/*  218 */       name = "file:///";
/*  219 */     } else if (name.indexOf(47) == -1) {
/*  220 */       LOG.warn("\"" + name + "\" is a deprecated filesystem name." + " Use \"hdfs://" + name + "/\" instead.");
/*      */ 
/*  222 */       name = "hdfs://" + name;
/*      */     }
/*  224 */     return name;
/*      */   }
/*      */ 
/*      */   public static LocalFileSystem getLocal(Configuration conf)
/*      */     throws IOException
/*      */   {
/*  234 */     return (LocalFileSystem)get(LocalFileSystem.NAME, conf);
/*      */   }
/*      */ 
/*      */   public static FileSystem get(URI uri, Configuration conf)
/*      */     throws IOException
/*      */   {
/*  243 */     String scheme = uri.getScheme();
/*  244 */     String authority = uri.getAuthority();
/*      */ 
/*  246 */     if ((scheme == null) && (authority == null)) {
/*  247 */       return get(conf);
/*      */     }
/*      */ 
/*  250 */     if ((scheme != null) && (authority == null)) {
/*  251 */       URI defaultUri = getDefaultUri(conf);
/*  252 */       if ((scheme.equals(defaultUri.getScheme())) && (defaultUri.getAuthority() != null))
/*      */       {
/*  254 */         return get(defaultUri, conf);
/*      */       }
/*      */     }
/*      */ 
/*  258 */     String disableCacheName = String.format("fs.%s.impl.disable.cache", new Object[] { scheme });
/*  259 */     if (conf.getBoolean(disableCacheName, false)) {
/*  260 */       return createFileSystem(uri, conf);
/*      */     }
/*      */ 
/*  263 */     return CACHE.get(uri, conf);
/*      */   }
/*      */ 
/*      */   public static void closeAll()
/*      */     throws IOException
/*      */   {
/*  284 */     LOG.debug("Starting clear of FileSystem cache with " + CACHE.size() + " elements.");
/*      */ 
/*  286 */     CACHE.closeAll();
/*  287 */     LOG.debug("Done clearing cache");
/*      */   }
/*      */ 
/*      */   public static void closeAllForUGI(UserGroupInformation ugi)
/*      */     throws IOException
/*      */   {
/*  298 */     CACHE.closeAll(ugi);
/*      */   }
/*      */ 
/*      */   public Path makeQualified(Path path)
/*      */   {
/*  303 */     checkPath(path);
/*  304 */     return path.makeQualified(this);
/*      */   }
/*      */ 
/*      */   public static FSDataOutputStream create(FileSystem fs, Path file, FsPermission permission)
/*      */     throws IOException
/*      */   {
/*  324 */     FSDataOutputStream out = fs.create(file);
/*      */ 
/*  326 */     fs.setPermission(file, permission);
/*  327 */     return out;
/*      */   }
/*      */ 
/*      */   public static boolean mkdirs(FileSystem fs, Path dir, FsPermission permission)
/*      */     throws IOException
/*      */   {
/*  345 */     boolean result = fs.mkdirs(dir);
/*      */ 
/*  347 */     fs.setPermission(dir, permission);
/*  348 */     return result;
/*      */   }
/*      */ 
/*      */   protected FileSystem()
/*      */   {
/*  356 */     super(null);
/*      */   }
/*      */ 
/*      */   protected void checkPath(Path path)
/*      */   {
/*  361 */     URI uri = path.toUri();
/*  362 */     String thatScheme = uri.getScheme();
/*  363 */     if (thatScheme == null)
/*  364 */       return;
/*  365 */     URI thisUri = getCanonicalUri();
/*  366 */     String thisScheme = thisUri.getScheme();
/*      */ 
/*  368 */     if (thisScheme.equalsIgnoreCase(thatScheme)) {
/*  369 */       String thisAuthority = thisUri.getAuthority();
/*  370 */       String thatAuthority = uri.getAuthority();
/*  371 */       if ((thatAuthority == null) && (thisAuthority != null))
/*      */       {
/*  373 */         URI defaultUri = getDefaultUri(getConf());
/*  374 */         if (thisScheme.equalsIgnoreCase(defaultUri.getScheme()))
/*  375 */           uri = defaultUri;
/*      */         else {
/*  377 */           uri = null;
/*      */         }
/*      */       }
/*  380 */       if (uri != null)
/*      */       {
/*  382 */         uri = NetUtils.getCanonicalUri(uri, getDefaultPort());
/*  383 */         thatAuthority = uri.getAuthority();
/*  384 */         if ((thisAuthority == thatAuthority) || ((thisAuthority != null) && (thisAuthority.equalsIgnoreCase(thatAuthority))))
/*      */         {
/*  387 */           return;
/*      */         }
/*      */       }
/*      */     }
/*  390 */     throw new IllegalArgumentException("Wrong FS: " + path + ", expected: " + getUri());
/*      */   }
/*      */ 
/*      */   public BlockLocation[] getFileBlockLocations(FileStatus file, long start, long len)
/*      */     throws IOException
/*      */   {
/*  406 */     if (file == null) {
/*  407 */       return null;
/*      */     }
/*      */ 
/*  410 */     if ((start < 0L) || (len < 0L)) {
/*  411 */       throw new IllegalArgumentException("Invalid start or len parameter");
/*      */     }
/*      */ 
/*  414 */     if (file.getLen() <= start) {
/*  415 */       return new BlockLocation[0];
/*      */     }
/*      */ 
/*  418 */     String[] name = { "localhost:50010" };
/*  419 */     String[] host = { "localhost" };
/*  420 */     return new BlockLocation[] { new BlockLocation(name, host, 0L, file.getLen()) };
/*      */   }
/*      */ 
/*      */   public abstract FSDataInputStream open(Path paramPath, int paramInt)
/*      */     throws IOException;
/*      */ 
/*      */   public FSDataInputStream open(Path f)
/*      */     throws IOException
/*      */   {
/*  436 */     return open(f, getConf().getInt("io.file.buffer.size", 4096));
/*      */   }
/*      */ 
/*      */   public FSDataOutputStream create(Path f)
/*      */     throws IOException
/*      */   {
/*  444 */     return create(f, true);
/*      */   }
/*      */ 
/*      */   public FSDataOutputStream create(Path f, boolean overwrite)
/*      */     throws IOException
/*      */   {
/*  452 */     return create(f, overwrite, getConf().getInt("io.file.buffer.size", 4096), getDefaultReplication(), getDefaultBlockSize());
/*      */   }
/*      */ 
/*      */   public FSDataOutputStream create(Path f, Progressable progress)
/*      */     throws IOException
/*      */   {
/*  464 */     return create(f, true, getConf().getInt("io.file.buffer.size", 4096), getDefaultReplication(), getDefaultBlockSize(), progress);
/*      */   }
/*      */ 
/*      */   public FSDataOutputStream create(Path f, short replication)
/*      */     throws IOException
/*      */   {
/*  476 */     return create(f, true, getConf().getInt("io.file.buffer.size", 4096), replication, getDefaultBlockSize());
/*      */   }
/*      */ 
/*      */   public FSDataOutputStream create(Path f, short replication, Progressable progress)
/*      */     throws IOException
/*      */   {
/*  489 */     return create(f, true, getConf().getInt("io.file.buffer.size", 4096), replication, getDefaultBlockSize(), progress);
/*      */   }
/*      */ 
/*      */   public FSDataOutputStream create(Path f, boolean overwrite, int bufferSize)
/*      */     throws IOException
/*      */   {
/*  507 */     return create(f, overwrite, bufferSize, getDefaultReplication(), getDefaultBlockSize());
/*      */   }
/*      */ 
/*      */   public FSDataOutputStream create(Path f, boolean overwrite, int bufferSize, Progressable progress)
/*      */     throws IOException
/*      */   {
/*  525 */     return create(f, overwrite, bufferSize, getDefaultReplication(), getDefaultBlockSize(), progress);
/*      */   }
/*      */ 
/*      */   public FSDataOutputStream create(Path f, boolean overwrite, int bufferSize, short replication, long blockSize)
/*      */     throws IOException
/*      */   {
/*  545 */     return create(f, overwrite, bufferSize, replication, blockSize, null);
/*      */   }
/*      */ 
/*      */   public FSDataOutputStream create(Path f, boolean overwrite, int bufferSize, short replication, long blockSize, Progressable progress)
/*      */     throws IOException
/*      */   {
/*  564 */     return create(f, FsPermission.getDefault(), overwrite, bufferSize, replication, blockSize, progress);
/*      */   }
/*      */ 
/*      */   public abstract FSDataOutputStream create(Path paramPath, FsPermission paramFsPermission, boolean paramBoolean, int paramInt, short paramShort, long paramLong, Progressable paramProgressable)
/*      */     throws IOException;
/*      */ 
/*      */   @Deprecated
/*      */   public FSDataOutputStream createNonRecursive(Path f, boolean overwrite, int bufferSize, short replication, long blockSize, Progressable progress)
/*      */     throws IOException
/*      */   {
/*  610 */     return createNonRecursive(f, FsPermission.getDefault(), overwrite, bufferSize, replication, blockSize, progress);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public FSDataOutputStream createNonRecursive(Path f, FsPermission permission, boolean overwrite, int bufferSize, short replication, long blockSize, Progressable progress)
/*      */     throws IOException
/*      */   {
/*  635 */     throw new IOException("createNonRecursive unsupported for this filesystem " + getClass());
/*      */   }
/*      */ 
/*      */   public boolean createNewFile(Path f)
/*      */     throws IOException
/*      */   {
/*  644 */     if (exists(f)) {
/*  645 */       return false;
/*      */     }
/*  647 */     create(f, false, getConf().getInt("io.file.buffer.size", 4096)).close();
/*  648 */     return true;
/*      */   }
/*      */ 
/*      */   public FSDataOutputStream append(Path f)
/*      */     throws IOException
/*      */   {
/*  659 */     return append(f, getConf().getInt("io.file.buffer.size", 4096), null);
/*      */   }
/*      */ 
/*      */   public FSDataOutputStream append(Path f, int bufferSize)
/*      */     throws IOException
/*      */   {
/*  669 */     return append(f, bufferSize, null);
/*      */   }
/*      */ 
/*      */   public abstract FSDataOutputStream append(Path paramPath, int paramInt, Progressable paramProgressable)
/*      */     throws IOException;
/*      */ 
/*      */   public void concat(Path trg, Path[] srcs)
/*      */     throws IOException
/*      */   {
/*  689 */     throw new UnsupportedOperationException("Not implemented by the " + getClass().getSimpleName() + " FileSystem implementation");
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public short getReplication(Path src)
/*      */     throws IOException
/*      */   {
/*  703 */     return getFileStatus(src).getReplication();
/*      */   }
/*      */ 
/*      */   public boolean setReplication(Path src, short replication)
/*      */     throws IOException
/*      */   {
/*  717 */     return true;
/*      */   }
/*      */ 
/*      */   public abstract boolean rename(Path paramPath1, Path paramPath2)
/*      */     throws IOException;
/*      */ 
/*      */   @Deprecated
/*      */   public abstract boolean delete(Path paramPath)
/*      */     throws IOException;
/*      */ 
/*      */   public abstract boolean delete(Path paramPath, boolean paramBoolean)
/*      */     throws IOException;
/*      */ 
/*      */   public boolean deleteOnExit(Path f)
/*      */     throws IOException
/*      */   {
/*  755 */     if (!exists(f)) {
/*  756 */       return false;
/*      */     }
/*  758 */     synchronized (this.deleteOnExit) {
/*  759 */       this.deleteOnExit.add(f);
/*      */     }
/*  761 */     return true;
/*      */   }
/*      */ 
/*      */   protected void processDeleteOnExit()
/*      */   {
/*      */     Iterator iter;
/*  769 */     synchronized (this.deleteOnExit) {
/*  770 */       for (iter = this.deleteOnExit.iterator(); iter.hasNext(); ) {
/*  771 */         Path path = (Path)iter.next();
/*      */         try {
/*  773 */           delete(path, true);
/*      */         }
/*      */         catch (IOException e) {
/*  776 */           LOG.info("Ignoring failure to deleteOnExit for path " + path);
/*      */         }
/*  778 */         iter.remove();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean exists(Path f)
/*      */     throws IOException
/*      */   {
/*      */     try
/*      */     {
/*  788 */       return getFileStatus(f) != null; } catch (FileNotFoundException e) {
/*      */     }
/*  790 */     return false;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public boolean isDirectory(Path f) throws IOException
/*      */   {
/*      */     try
/*      */     {
/*  798 */       return getFileStatus(f).isDir(); } catch (FileNotFoundException e) {
/*      */     }
/*  800 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean isFile(Path f) throws IOException
/*      */   {
/*      */     try
/*      */     {
/*  807 */       return !getFileStatus(f).isDir(); } catch (FileNotFoundException e) {
/*      */     }
/*  809 */     return false;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public long getLength(Path f)
/*      */     throws IOException
/*      */   {
/*  816 */     return getFileStatus(f).getLen();
/*      */   }
/*      */ 
/*      */   public ContentSummary getContentSummary(Path f) throws IOException
/*      */   {
/*  821 */     FileStatus status = getFileStatus(f);
/*  822 */     if (!status.isDir())
/*      */     {
/*  824 */       return new ContentSummary(status.getLen(), 1L, 0L);
/*      */     }
/*      */ 
/*  827 */     long[] summary = { 0L, 0L, 1L };
/*  828 */     for (FileStatus s : listStatus(f)) {
/*  829 */       ContentSummary c = s.isDir() ? getContentSummary(s.getPath()) : new ContentSummary(s.getLen(), 1L, 0L);
/*      */ 
/*  831 */       summary[0] += c.getLength();
/*  832 */       summary[1] += c.getFileCount();
/*  833 */       summary[2] += c.getDirectoryCount();
/*      */     }
/*  835 */     return new ContentSummary(summary[0], summary[1], summary[2]);
/*      */   }
/*      */ 
/*      */   public abstract FileStatus[] listStatus(Path paramPath)
/*      */     throws IOException;
/*      */ 
/*      */   private void listStatus(ArrayList<FileStatus> results, Path f, PathFilter filter)
/*      */     throws IOException
/*      */   {
/*  862 */     FileStatus[] listing = listStatus(f);
/*  863 */     if (listing != null)
/*  864 */       for (int i = 0; i < listing.length; i++)
/*  865 */         if (filter.accept(listing[i].getPath()))
/*  866 */           results.add(listing[i]);
/*      */   }
/*      */ 
/*      */   public FileStatus[] listStatus(Path f, PathFilter filter)
/*      */     throws IOException
/*      */   {
/*  886 */     ArrayList results = new ArrayList();
/*  887 */     listStatus(results, f, filter);
/*  888 */     return (FileStatus[])results.toArray(new FileStatus[results.size()]);
/*      */   }
/*      */ 
/*      */   public FileStatus[] listStatus(Path[] files)
/*      */     throws IOException
/*      */   {
/*  903 */     return listStatus(files, DEFAULT_FILTER);
/*      */   }
/*      */ 
/*      */   public FileStatus[] listStatus(Path[] files, PathFilter filter)
/*      */     throws IOException
/*      */   {
/*  920 */     ArrayList results = new ArrayList();
/*  921 */     for (int i = 0; i < files.length; i++) {
/*  922 */       listStatus(results, files[i], filter);
/*      */     }
/*  924 */     return (FileStatus[])results.toArray(new FileStatus[results.size()]);
/*      */   }
/*      */ 
/*      */   public FileStatus[] globStatus(Path pathPattern)
/*      */     throws IOException
/*      */   {
/*  985 */     return globStatus(pathPattern, DEFAULT_FILTER);
/*      */   }
/*      */ 
/*      */   public FileStatus[] globStatus(Path pathPattern, PathFilter filter)
/*      */     throws IOException
/*      */   {
/* 1004 */     String filename = pathPattern.toUri().getPath();
/* 1005 */     List filePatterns = GlobExpander.expand(filename);
/* 1006 */     if (filePatterns.size() == 1) {
/* 1007 */       return globStatusInternal(pathPattern, filter);
/*      */     }
/* 1009 */     List results = new ArrayList();
/* 1010 */     for (String filePattern : filePatterns) {
/* 1011 */       FileStatus[] files = globStatusInternal(new Path(filePattern), filter);
/* 1012 */       for (FileStatus file : files) {
/* 1013 */         results.add(file);
/*      */       }
/*      */     }
/* 1016 */     return (FileStatus[])results.toArray(new FileStatus[results.size()]);
/*      */   }
/*      */ 
/*      */   private FileStatus[] globStatusInternal(Path pathPattern, PathFilter filter)
/*      */     throws IOException
/*      */   {
/* 1022 */     Path[] parents = new Path[1];
/* 1023 */     int level = 0;
/* 1024 */     String filename = pathPattern.toUri().getPath();
/*      */ 
/* 1027 */     if (("".equals(filename)) || ("/".equals(filename))) {
/* 1028 */       return getFileStatus(new Path[] { pathPattern });
/*      */     }
/*      */ 
/* 1032 */     String[] components = filename.split("/");
/*      */ 
/* 1034 */     if (pathPattern.isAbsolute()) {
/* 1035 */       parents[0] = new Path("/");
/* 1036 */       level = 1;
/*      */     } else {
/* 1038 */       parents[0] = new Path(".");
/*      */     }
/*      */ 
/* 1042 */     boolean[] hasGlob = { false };
/* 1043 */     Path[] parentPaths = globPathsLevel(parents, components, level, hasGlob);
/*      */     FileStatus[] results;
/*      */     FileStatus[] results;
/* 1045 */     if ((parentPaths == null) || (parentPaths.length == 0)) {
/* 1046 */       results = null;
/*      */     }
/*      */     else {
/* 1049 */       GlobFilter fp = new GlobFilter(components[(components.length - 1)], filter);
/* 1050 */       if (fp.hasPattern())
/*      */       {
/* 1052 */         FileStatus[] results = listStatus(parentPaths, fp);
/* 1053 */         hasGlob[0] = true;
/*      */       }
/*      */       else {
/* 1056 */         String name = unquotePathComponent(components[(components.length - 1)]);
/*      */ 
/* 1058 */         ArrayList filteredPaths = new ArrayList(parentPaths.length);
/* 1059 */         for (int i = 0; i < parentPaths.length; i++) {
/* 1060 */           parentPaths[i] = new Path(parentPaths[i], name);
/* 1061 */           if (fp.accept(parentPaths[i])) {
/* 1062 */             filteredPaths.add(parentPaths[i]);
/*      */           }
/*      */         }
/*      */ 
/* 1066 */         results = getFileStatus((Path[])filteredPaths.toArray(new Path[filteredPaths.size()]));
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1072 */     if (results == null) {
/* 1073 */       if (hasGlob[0] != 0) {
/* 1074 */         results = new FileStatus[0];
/*      */       }
/*      */     }
/* 1077 */     else if (results.length == 0) {
/* 1078 */       if (hasGlob[0] == 0)
/* 1079 */         results = null;
/*      */     }
/*      */     else {
/* 1082 */       Arrays.sort(results);
/*      */     }
/*      */ 
/* 1085 */     return results;
/*      */   }
/*      */ 
/*      */   private Path[] globPathsLevel(Path[] parents, String[] filePattern, int level, boolean[] hasGlob)
/*      */     throws IOException
/*      */   {
/* 1094 */     if (level == filePattern.length - 1)
/* 1095 */       return parents;
/* 1096 */     if ((parents == null) || (parents.length == 0)) {
/* 1097 */       return null;
/*      */     }
/* 1099 */     GlobFilter fp = new GlobFilter(filePattern[level]);
/* 1100 */     if (fp.hasPattern()) {
/* 1101 */       parents = FileUtil.stat2Paths(listStatus(parents, fp));
/* 1102 */       hasGlob[0] = true;
/*      */     }
/*      */     else {
/* 1105 */       String name = unquotePathComponent(filePattern[level]);
/* 1106 */       for (int i = 0; i < parents.length; i++) {
/* 1107 */         parents[i] = new Path(parents[i], name);
/*      */       }
/*      */     }
/* 1110 */     return globPathsLevel(parents, filePattern, level + 1, hasGlob);
/*      */   }
/*      */ 
/*      */   private String unquotePathComponent(String name)
/*      */   {
/* 1122 */     return name.replaceAll("\\\\(.)", "$1");
/*      */   }
/*      */ 
/*      */   public Path getHomeDirectory()
/*      */   {
/* 1129 */     return new Path("/user/" + System.getProperty("user.name")).makeQualified(this);
/*      */   }
/*      */ 
/*      */   public Token<?> getDelegationToken(String renewer)
/*      */     throws IOException
/*      */   {
/* 1140 */     return null;
/*      */   }
/*      */ 
/*      */   public abstract void setWorkingDirectory(Path paramPath);
/*      */ 
/*      */   public abstract Path getWorkingDirectory();
/*      */ 
/*      */   public boolean mkdirs(Path f)
/*      */     throws IOException
/*      */   {
/* 1161 */     return mkdirs(f, FsPermission.getDefault());
/*      */   }
/*      */ 
/*      */   public abstract boolean mkdirs(Path paramPath, FsPermission paramFsPermission)
/*      */     throws IOException;
/*      */ 
/*      */   public void copyFromLocalFile(Path src, Path dst)
/*      */     throws IOException
/*      */   {
/* 1178 */     copyFromLocalFile(false, src, dst);
/*      */   }
/*      */ 
/*      */   public void moveFromLocalFile(Path[] srcs, Path dst)
/*      */     throws IOException
/*      */   {
/* 1187 */     copyFromLocalFile(true, true, srcs, dst);
/*      */   }
/*      */ 
/*      */   public void moveFromLocalFile(Path src, Path dst)
/*      */     throws IOException
/*      */   {
/* 1196 */     copyFromLocalFile(true, src, dst);
/*      */   }
/*      */ 
/*      */   public void copyFromLocalFile(boolean delSrc, Path src, Path dst)
/*      */     throws IOException
/*      */   {
/* 1206 */     copyFromLocalFile(delSrc, true, src, dst);
/*      */   }
/*      */ 
/*      */   public void copyFromLocalFile(boolean delSrc, boolean overwrite, Path[] srcs, Path dst)
/*      */     throws IOException
/*      */   {
/* 1217 */     Configuration conf = getConf();
/* 1218 */     FileUtil.copy(getLocal(conf), srcs, this, dst, delSrc, overwrite, conf);
/*      */   }
/*      */ 
/*      */   public void copyFromLocalFile(boolean delSrc, boolean overwrite, Path src, Path dst)
/*      */     throws IOException
/*      */   {
/* 1229 */     Configuration conf = getConf();
/* 1230 */     FileUtil.copy(getLocal(conf), src, this, dst, delSrc, overwrite, conf);
/*      */   }
/*      */ 
/*      */   public void copyToLocalFile(Path src, Path dst)
/*      */     throws IOException
/*      */   {
/* 1238 */     copyToLocalFile(false, src, dst);
/*      */   }
/*      */ 
/*      */   public void moveToLocalFile(Path src, Path dst)
/*      */     throws IOException
/*      */   {
/* 1247 */     copyToLocalFile(true, src, dst);
/*      */   }
/*      */ 
/*      */   public void copyToLocalFile(boolean delSrc, Path src, Path dst)
/*      */     throws IOException
/*      */   {
/* 1257 */     FileUtil.copy(this, src, getLocal(getConf()), dst, delSrc, getConf());
/*      */   }
/*      */ 
/*      */   public Path startLocalOutput(Path fsOutputFile, Path tmpLocalFile)
/*      */     throws IOException
/*      */   {
/* 1268 */     return tmpLocalFile;
/*      */   }
/*      */ 
/*      */   public void completeLocalOutput(Path fsOutputFile, Path tmpLocalFile)
/*      */     throws IOException
/*      */   {
/* 1279 */     moveFromLocalFile(tmpLocalFile, fsOutputFile);
/*      */   }
/*      */ 
/*      */   public void close()
/*      */     throws IOException
/*      */   {
/* 1288 */     processDeleteOnExit();
/* 1289 */     CACHE.remove(this.key, this);
/* 1290 */     LOG.debug("Removing filesystem for " + getUri());
/*      */   }
/*      */ 
/*      */   public long getUsed() throws IOException
/*      */   {
/* 1295 */     long used = 0L;
/* 1296 */     FileStatus[] files = listStatus(new Path("/"));
/* 1297 */     for (FileStatus file : files) {
/* 1298 */       used += file.getLen();
/*      */     }
/* 1300 */     return used;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public long getBlockSize(Path f)
/*      */     throws IOException
/*      */   {
/* 1310 */     return getFileStatus(f).getBlockSize();
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public long getDefaultBlockSize()
/*      */   {
/* 1321 */     return getConf().getLong("fs.local.block.size", 33554432L);
/*      */   }
/*      */ 
/*      */   public long getDefaultBlockSize(Path f)
/*      */   {
/* 1331 */     return getDefaultBlockSize();
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public short getDefaultReplication()
/*      */   {
/* 1339 */     return 1;
/*      */   }
/*      */ 
/*      */   public short getDefaultReplication(Path path)
/*      */   {
/* 1347 */     return getDefaultReplication();
/*      */   }
/*      */ 
/*      */   public abstract FileStatus getFileStatus(Path paramPath)
/*      */     throws IOException;
/*      */ 
/*      */   public FileChecksum getFileChecksum(Path f)
/*      */     throws IOException
/*      */   {
/* 1368 */     return null;
/*      */   }
/*      */ 
/*      */   public void setVerifyChecksum(boolean verifyChecksum)
/*      */   {
/*      */   }
/*      */ 
/*      */   private FileStatus[] getFileStatus(Path[] paths)
/*      */     throws IOException
/*      */   {
/* 1391 */     if (paths == null) {
/* 1392 */       return null;
/*      */     }
/* 1394 */     ArrayList results = new ArrayList(paths.length);
/* 1395 */     for (int i = 0; i < paths.length; i++)
/*      */       try {
/* 1397 */         results.add(getFileStatus(paths[i]));
/*      */       }
/*      */       catch (FileNotFoundException e) {
/*      */       }
/* 1401 */     return (FileStatus[])results.toArray(new FileStatus[results.size()]);
/*      */   }
/*      */ 
/*      */   public void setPermission(Path p, FsPermission permission)
/*      */     throws IOException
/*      */   {
/*      */   }
/*      */ 
/*      */   public void setOwner(Path p, String username, String groupname)
/*      */     throws IOException
/*      */   {
/*      */   }
/*      */ 
/*      */   public void setTimes(Path p, long mtime, long atime)
/*      */     throws IOException
/*      */   {
/*      */   }
/*      */ 
/*      */   private static FileSystem createFileSystem(URI uri, Configuration conf)
/*      */     throws IOException
/*      */   {
/* 1440 */     Class clazz = conf.getClass("fs." + uri.getScheme() + ".impl", null);
/* 1441 */     LOG.debug("Creating filesystem for " + uri);
/* 1442 */     if (clazz == null) {
/* 1443 */       throw new IOException("No FileSystem for scheme: " + uri.getScheme());
/*      */     }
/* 1445 */     FileSystem fs = (FileSystem)ReflectionUtils.newInstance(clazz, conf);
/* 1446 */     fs.initialize(uri, conf);
/* 1447 */     return fs;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public static synchronized Map<String, Statistics> getStatistics()
/*      */   {
/* 1718 */     Map result = new HashMap();
/* 1719 */     for (Statistics stat : statisticsTable.values()) {
/* 1720 */       result.put(stat.getScheme(), stat);
/*      */     }
/* 1722 */     return result;
/*      */   }
/*      */ 
/*      */   public static synchronized List<Statistics> getAllStatistics()
/*      */   {
/* 1729 */     return new ArrayList(statisticsTable.values());
/*      */   }
/*      */ 
/*      */   public static synchronized Statistics getStatistics(String scheme, Class<? extends FileSystem> cls)
/*      */   {
/* 1739 */     Statistics result = (Statistics)statisticsTable.get(cls);
/* 1740 */     if (result == null) {
/* 1741 */       result = new Statistics(scheme);
/* 1742 */       statisticsTable.put(cls, result);
/*      */     }
/* 1744 */     return result;
/*      */   }
/*      */ 
/*      */   public static synchronized void clearStatistics() {
/* 1748 */     for (Statistics stat : statisticsTable.values())
/* 1749 */       stat.reset();
/*      */   }
/*      */ 
/*      */   public static synchronized void printStatistics()
/*      */     throws IOException
/*      */   {
/* 1756 */     for (Map.Entry pair : statisticsTable.entrySet())
/* 1757 */       System.out.println("  FileSystem " + ((Class)pair.getKey()).getName() + ": " + pair.getValue());
/*      */   }
/*      */ 
/*      */   public static final class Statistics
/*      */   {
/*      */     private final String scheme;
/* 1597 */     private AtomicLong bytesRead = new AtomicLong();
/* 1598 */     private AtomicLong bytesWritten = new AtomicLong();
/* 1599 */     private AtomicInteger readOps = new AtomicInteger();
/* 1600 */     private AtomicInteger largeReadOps = new AtomicInteger();
/* 1601 */     private AtomicInteger writeOps = new AtomicInteger();
/*      */ 
/*      */     public Statistics(String scheme) {
/* 1604 */       this.scheme = scheme;
/*      */     }
/*      */ 
/*      */     public void incrementBytesRead(long newBytes)
/*      */     {
/* 1612 */       this.bytesRead.getAndAdd(newBytes);
/*      */     }
/*      */ 
/*      */     public void incrementBytesWritten(long newBytes)
/*      */     {
/* 1620 */       this.bytesWritten.getAndAdd(newBytes);
/*      */     }
/*      */ 
/*      */     public void incrementReadOps(int count)
/*      */     {
/* 1628 */       this.readOps.getAndAdd(count);
/*      */     }
/*      */ 
/*      */     public void incrementLargeReadOps(int count)
/*      */     {
/* 1636 */       this.largeReadOps.getAndAdd(count);
/*      */     }
/*      */ 
/*      */     public void incrementWriteOps(int count)
/*      */     {
/* 1644 */       this.writeOps.getAndAdd(count);
/*      */     }
/*      */ 
/*      */     public long getBytesRead()
/*      */     {
/* 1652 */       return this.bytesRead.get();
/*      */     }
/*      */ 
/*      */     public long getBytesWritten()
/*      */     {
/* 1660 */       return this.bytesWritten.get();
/*      */     }
/*      */ 
/*      */     public int getReadOps()
/*      */     {
/* 1668 */       return this.readOps.get() + this.largeReadOps.get();
/*      */     }
/*      */ 
/*      */     public int getLargeReadOps()
/*      */     {
/* 1677 */       return this.largeReadOps.get();
/*      */     }
/*      */ 
/*      */     public int getWriteOps()
/*      */     {
/* 1686 */       return this.writeOps.get();
/*      */     }
/*      */ 
/*      */     public String toString() {
/* 1690 */       return this.bytesRead + " bytes read, " + this.bytesWritten + " bytes written, " + this.readOps + " read ops, " + this.largeReadOps + " large read ops, " + this.writeOps + " write ops";
/*      */     }
/*      */ 
/*      */     public void reset()
/*      */     {
/* 1699 */       this.bytesWritten.set(0L);
/* 1700 */       this.bytesRead.set(0L);
/*      */     }
/*      */ 
/*      */     public String getScheme()
/*      */     {
/* 1708 */       return this.scheme;
/*      */     }
/*      */   }
/*      */ 
/*      */   static class Cache
/*      */   {
/*      */     private final Map<Key, FileSystem> map;
/*      */ 
/*      */     Cache()
/*      */     {
/* 1452 */       this.map = new HashMap();
/*      */     }
/*      */     FileSystem get(URI uri, Configuration conf) throws IOException {
/* 1455 */       Key key = new Key(uri, conf);
/* 1456 */       FileSystem fs = null;
/* 1457 */       synchronized (this) {
/* 1458 */         fs = (FileSystem)this.map.get(key);
/*      */       }
/* 1460 */       if (fs != null) {
/* 1461 */         return fs;
/*      */       }
/*      */ 
/* 1464 */       fs = FileSystem.createFileSystem(uri, conf);
/* 1465 */       synchronized (this) {
/* 1466 */         FileSystem oldfs = (FileSystem)this.map.get(key);
/* 1467 */         if (oldfs != null) {
/* 1468 */           fs.close();
/* 1469 */           return oldfs;
/*      */         }
/*      */ 
/* 1473 */         if ((this.map.isEmpty()) && (!FileSystem.clientFinalizer.isAlive())) {
/* 1474 */           Runtime.getRuntime().addShutdownHook(FileSystem.clientFinalizer);
/*      */         }
/* 1476 */         fs.key = key;
/* 1477 */         this.map.put(key, fs);
/* 1478 */         return fs;
/*      */       }
/*      */     }
/*      */ 
/*      */     synchronized void remove(Key key, FileSystem fs) {
/* 1483 */       if ((this.map.containsKey(key)) && (fs == this.map.get(key))) {
/* 1484 */         this.map.remove(key);
/* 1485 */         if ((this.map.isEmpty()) && (!FileSystem.clientFinalizer.isAlive()) && 
/* 1486 */           (!Runtime.getRuntime().removeShutdownHook(FileSystem.clientFinalizer)))
/* 1487 */           FileSystem.LOG.info("Could not cancel cleanup thread, though no FileSystems are open");
/*      */       }
/*      */     }
/*      */ 
/*      */     synchronized void closeAll()
/*      */       throws IOException
/*      */     {
/* 1495 */       List exceptions = new ArrayList();
/* 1496 */       while (!this.map.isEmpty()) {
/* 1497 */         Map.Entry e = (Map.Entry)this.map.entrySet().iterator().next();
/* 1498 */         Key key = (Key)e.getKey();
/* 1499 */         FileSystem fs = (FileSystem)e.getValue();
/*      */ 
/* 1502 */         remove(key, fs);
/*      */ 
/* 1504 */         if (fs != null) {
/*      */           try {
/* 1506 */             fs.close();
/*      */           }
/*      */           catch (IOException ioe) {
/* 1509 */             exceptions.add(ioe);
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 1514 */       if (!exceptions.isEmpty())
/* 1515 */         throw MultipleIOException.createIOException(exceptions);
/*      */     }
/*      */ 
/*      */     synchronized void closeAll(UserGroupInformation ugi) throws IOException
/*      */     {
/* 1520 */       List targetFSList = new ArrayList();
/*      */ 
/* 1523 */       for (Map.Entry entry : this.map.entrySet()) {
/* 1524 */         Key key = (Key)entry.getKey();
/* 1525 */         FileSystem fs = (FileSystem)entry.getValue();
/* 1526 */         if ((ugi.equals(key.ugi)) && (fs != null)) {
/* 1527 */           targetFSList.add(fs);
/*      */         }
/*      */       }
/* 1530 */       List exceptions = new ArrayList();
/*      */ 
/* 1532 */       for (FileSystem fs : targetFSList) {
/*      */         try {
/* 1534 */           fs.close();
/*      */         }
/*      */         catch (IOException ioe) {
/* 1537 */           exceptions.add(ioe);
/*      */         }
/*      */       }
/* 1540 */       if (!exceptions.isEmpty())
/* 1541 */         throw MultipleIOException.createIOException(exceptions);
/*      */     }
/*      */ 
/*      */     int size()
/*      */     {
/* 1591 */       return this.map.size();
/*      */     }
/*      */ 
/*      */     static class Key
/*      */     {
/*      */       final String scheme;
/*      */       final String authority;
/*      */       final UserGroupInformation ugi;
/*      */ 
/*      */       Key(URI uri, Configuration conf)
/*      */         throws IOException
/*      */       {
/* 1552 */         this.scheme = (uri.getScheme() == null ? "" : uri.getScheme().toLowerCase());
/* 1553 */         this.authority = (uri.getAuthority() == null ? "" : uri.getAuthority().toLowerCase());
/* 1554 */         this.ugi = UserGroupInformation.getCurrentUser();
/*      */       }
/*      */ 
/*      */       public int hashCode()
/*      */       {
/* 1559 */         return (this.scheme + this.authority).hashCode() + this.ugi.hashCode();
/*      */       }
/*      */ 
/*      */       static boolean isEqual(Object a, Object b) {
/* 1563 */         return (a == b) || ((a != null) && (a.equals(b)));
/*      */       }
/*      */ 
/*      */       public boolean equals(Object obj)
/*      */       {
/* 1568 */         if (obj == this) {
/* 1569 */           return true;
/*      */         }
/* 1571 */         if ((obj != null) && ((obj instanceof Key))) {
/* 1572 */           Key that = (Key)obj;
/* 1573 */           return (isEqual(this.scheme, that.scheme)) && (isEqual(this.authority, that.authority)) && (isEqual(this.ugi, that.ugi));
/*      */         }
/*      */ 
/* 1577 */         return false;
/*      */       }
/*      */ 
/*      */       public String toString()
/*      */       {
/* 1582 */         return "(" + this.ugi.toString() + ")@" + this.scheme + "://" + this.authority;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class ClientFinalizer extends Thread
/*      */   {
/*      */     public synchronized void run()
/*      */     {
/*      */       try
/*      */       {
/*  269 */         FileSystem.closeAll();
/*      */       } catch (IOException e) {
/*  271 */         FileSystem.LOG.info("FileSystem.closeAll() threw an exception:\n" + e);
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.FileSystem
 * JD-Core Version:    0.6.1
 */
/*      */ package org.apache.hadoop.fs;
/*      */ 
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URLDecoder;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.TreeMap;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import org.apache.hadoop.conf.Configuration;
/*      */ import org.apache.hadoop.fs.permission.FsPermission;
/*      */ import org.apache.hadoop.io.Text;
/*      */ import org.apache.hadoop.util.LineReader;
/*      */ import org.apache.hadoop.util.Progressable;
/*      */ 
/*      */ public class HarFileSystem extends FilterFileSystem
/*      */ {
/*      */   public static final int VERSION = 3;
/*   55 */   private static final Map<URI, HarMetaData> harMetaCache = new ConcurrentHashMap();
/*      */   private URI uri;
/*      */   private Path archivePath;
/*      */   private String harAuth;
/*      */   private HarMetaData metadata;
/*      */ 
/*      */   public HarFileSystem()
/*      */   {
/*      */   }
/*      */ 
/*      */   public HarFileSystem(FileSystem fs)
/*      */   {
/*   82 */     super(fs);
/*      */   }
/*      */ 
/*      */   public void initialize(URI name, Configuration conf)
/*      */     throws IOException
/*      */   {
/*  100 */     URI underLyingURI = decodeHarURI(name, conf);
/*      */ 
/*  103 */     Path harPath = archivePath(new Path(name.getScheme(), name.getAuthority(), name.getPath()));
/*      */ 
/*  105 */     if (harPath == null) {
/*  106 */       throw new IOException("Invalid path for the Har Filesystem. " + name.toString());
/*      */     }
/*      */ 
/*  109 */     if (this.fs == null) {
/*  110 */       this.fs = FileSystem.get(underLyingURI, conf);
/*      */     }
/*  112 */     this.uri = harPath.toUri();
/*  113 */     this.archivePath = new Path(this.uri.getPath());
/*  114 */     this.harAuth = getHarAuth(underLyingURI);
/*      */ 
/*  117 */     Path masterIndexPath = new Path(this.archivePath, "_masterindex");
/*  118 */     Path archiveIndexPath = new Path(this.archivePath, "_index");
/*  119 */     if ((!this.fs.exists(masterIndexPath)) || (!this.fs.exists(archiveIndexPath))) {
/*  120 */       throw new IOException("Invalid path for the Har Filesystem. No index file in " + harPath);
/*      */     }
/*      */ 
/*  124 */     this.metadata = ((HarMetaData)harMetaCache.get(this.uri));
/*  125 */     if (this.metadata != null) {
/*  126 */       FileStatus mStat = this.fs.getFileStatus(masterIndexPath);
/*  127 */       FileStatus aStat = this.fs.getFileStatus(archiveIndexPath);
/*  128 */       if ((mStat.getModificationTime() != this.metadata.getMasterIndexTimestamp()) || (aStat.getModificationTime() != this.metadata.getArchiveIndexTimestamp()))
/*      */       {
/*  132 */         this.metadata = null;
/*  133 */         harMetaCache.remove(this.uri);
/*      */       }
/*      */     }
/*  136 */     if (this.metadata == null) {
/*  137 */       this.metadata = new HarMetaData(this.fs, masterIndexPath, archiveIndexPath);
/*  138 */       this.metadata.parseMetaData();
/*  139 */       harMetaCache.put(this.uri, this.metadata);
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getHarVersion()
/*      */     throws IOException
/*      */   {
/*  147 */     if (this.metadata != null) {
/*  148 */       return this.metadata.getVersion();
/*      */     }
/*      */ 
/*  151 */     throw new IOException("Invalid meta data for the Har Filesystem");
/*      */   }
/*      */ 
/*      */   private Path archivePath(Path p)
/*      */   {
/*  162 */     Path retPath = null;
/*  163 */     Path tmp = p;
/*  164 */     for (int i = 0; i < p.depth(); i++) {
/*  165 */       if (tmp.toString().endsWith(".har")) {
/*  166 */         retPath = tmp;
/*  167 */         break;
/*      */       }
/*  169 */       tmp = tmp.getParent();
/*      */     }
/*  171 */     return retPath;
/*      */   }
/*      */ 
/*      */   private URI decodeHarURI(URI rawURI, Configuration conf)
/*      */     throws IOException
/*      */   {
/*  180 */     String tmpAuth = rawURI.getAuthority();
/*      */ 
/*  185 */     if (tmpAuth == null)
/*      */     {
/*  187 */       return FileSystem.getDefaultUri(conf);
/*      */     }
/*  189 */     String host = rawURI.getHost();
/*  190 */     if (host == null) {
/*  191 */       throw new IOException("URI: " + rawURI + " is an invalid Har URI since host==null." + "  Expecting har://<scheme>-<host>/<path>.");
/*      */     }
/*      */ 
/*  195 */     int i = host.indexOf('-');
/*  196 */     if (i < 0) {
/*  197 */       throw new IOException("URI: " + rawURI + " is an invalid Har URI since '-' not found." + "  Expecting har://<scheme>-<host>/<path>.");
/*      */     }
/*      */ 
/*  201 */     String underLyingScheme = host.substring(0, i);
/*  202 */     i++;
/*  203 */     String underLyingHost = i == host.length() ? null : host.substring(i);
/*  204 */     int underLyingPort = rawURI.getPort();
/*  205 */     String auth = underLyingHost + ":" + underLyingPort;
/*      */ 
/*  207 */     URI tmp = null;
/*  208 */     if (rawURI.getQuery() != null)
/*      */     {
/*  210 */       throw new IOException("query component in Path not supported  " + rawURI);
/*      */     }
/*      */     try {
/*  213 */       tmp = new URI(underLyingScheme, auth, rawURI.getPath(), rawURI.getQuery(), rawURI.getFragment());
/*      */     }
/*      */     catch (URISyntaxException e)
/*      */     {
/*      */     }
/*  218 */     return tmp;
/*      */   }
/*      */ 
/*      */   private static String decodeString(String str) throws UnsupportedEncodingException
/*      */   {
/*  223 */     return URLDecoder.decode(str, "UTF-8");
/*      */   }
/*      */ 
/*      */   private String decodeFileName(String fname) throws UnsupportedEncodingException
/*      */   {
/*  228 */     int version = this.metadata.getVersion();
/*  229 */     if ((version == 2) || (version == 3)) {
/*  230 */       return decodeString(fname);
/*      */     }
/*  232 */     return fname;
/*      */   }
/*      */ 
/*      */   public Path getWorkingDirectory()
/*      */   {
/*  239 */     return new Path(this.uri.toString());
/*      */   }
/*      */ 
/*      */   private String getHarAuth(URI underLyingUri)
/*      */   {
/*  250 */     String auth = underLyingUri.getScheme() + "-";
/*  251 */     if (underLyingUri.getHost() != null) {
/*  252 */       auth = auth + underLyingUri.getHost() + ":";
/*  253 */       if (underLyingUri.getPort() != -1)
/*  254 */         auth = auth + underLyingUri.getPort();
/*      */     }
/*      */     else
/*      */     {
/*  258 */       auth = auth + ":";
/*      */     }
/*  260 */     return auth;
/*      */   }
/*      */ 
/*      */   public URI getUri()
/*      */   {
/*  270 */     return this.uri;
/*      */   }
/*      */ 
/*      */   public String getCanonicalServiceName()
/*      */   {
/*  275 */     return null;
/*      */   }
/*      */ 
/*      */   private Path getPathInHar(Path path)
/*      */   {
/*  287 */     Path harPath = new Path(path.toUri().getPath());
/*  288 */     if (this.archivePath.compareTo(harPath) == 0)
/*  289 */       return new Path("/");
/*  290 */     Path tmp = new Path(harPath.getName());
/*  291 */     Path parent = harPath.getParent();
/*  292 */     while (parent.compareTo(this.archivePath) != 0) {
/*  293 */       if (parent.toString().equals("/")) {
/*  294 */         tmp = null;
/*  295 */         break;
/*      */       }
/*  297 */       tmp = new Path(parent.getName(), tmp);
/*  298 */       parent = parent.getParent();
/*      */     }
/*  300 */     if (tmp != null)
/*  301 */       tmp = new Path("/", tmp);
/*  302 */     return tmp;
/*      */   }
/*      */ 
/*      */   private Path makeRelative(String initial, Path p)
/*      */   {
/*  310 */     String scheme = this.uri.getScheme();
/*  311 */     String authority = this.uri.getAuthority();
/*  312 */     Path root = new Path("/");
/*  313 */     if (root.compareTo(p) == 0)
/*  314 */       return new Path(scheme, authority, initial);
/*  315 */     Path retPath = new Path(p.getName());
/*  316 */     Path parent = p.getParent();
/*  317 */     for (int i = 0; i < p.depth() - 1; i++) {
/*  318 */       retPath = new Path(parent.getName(), retPath);
/*  319 */       parent = parent.getParent();
/*      */     }
/*  321 */     return new Path(new Path(scheme, authority, initial), retPath.toString());
/*      */   }
/*      */ 
/*      */   public Path makeQualified(Path path)
/*      */   {
/*  334 */     Path fsPath = path;
/*  335 */     if (!path.isAbsolute()) {
/*  336 */       fsPath = new Path(this.archivePath, path);
/*      */     }
/*      */ 
/*  339 */     URI tmpURI = fsPath.toUri();
/*      */ 
/*  341 */     return new Path(this.uri.getScheme(), this.harAuth, tmpURI.getPath());
/*      */   }
/*      */ 
/*      */   static BlockLocation[] fixBlockLocations(BlockLocation[] locations, long start, long len, long fileOffsetInHar)
/*      */   {
/*  358 */     long end = start + len;
/*      */ 
/*  360 */     for (BlockLocation location : locations)
/*      */     {
/*  363 */       long harBlockStart = location.getOffset() - fileOffsetInHar;
/*      */ 
/*  366 */       long harBlockEnd = harBlockStart + location.getLength();
/*      */ 
/*  368 */       if (start > harBlockStart)
/*      */       {
/*  371 */         location.setOffset(start);
/*      */ 
/*  373 */         location.setLength(location.getLength() - (start - harBlockStart));
/*      */       }
/*      */       else {
/*  376 */         location.setOffset(harBlockStart);
/*      */       }
/*      */ 
/*  379 */       if (harBlockEnd > end)
/*      */       {
/*  382 */         location.setLength(location.getLength() - (harBlockEnd - end));
/*      */       }
/*      */     }
/*      */ 
/*  386 */     return locations;
/*      */   }
/*      */ 
/*      */   public BlockLocation[] getFileBlockLocations(FileStatus file, long start, long len)
/*      */     throws IOException
/*      */   {
/*  401 */     HarStatus hstatus = getFileHarStatus(file.getPath());
/*  402 */     Path partPath = new Path(this.archivePath, hstatus.getPartName());
/*  403 */     FileStatus partStatus = this.metadata.getPartFileStatus(partPath);
/*      */ 
/*  406 */     BlockLocation[] locations = this.fs.getFileBlockLocations(partStatus, hstatus.getStartIndex() + start, len);
/*      */ 
/*  410 */     return fixBlockLocations(locations, start, len, hstatus.getStartIndex());
/*      */   }
/*      */ 
/*      */   public static int getHarHash(Path p)
/*      */   {
/*  420 */     return p.toString().hashCode() & 0x7FFFFFFF;
/*      */   }
/*      */ 
/*      */   private void fileStatusesInIndex(HarStatus parent, List<FileStatus> statuses, List<String> children)
/*      */     throws IOException
/*      */   {
/*  455 */     String parentString = parent.getName();
/*  456 */     if (!parentString.endsWith("/")) {
/*  457 */       parentString = parentString + "/";
/*      */     }
/*  459 */     Path harPath = new Path(parentString);
/*  460 */     int harlen = harPath.depth();
/*  461 */     Map cache = new TreeMap();
/*      */ 
/*  463 */     for (HarStatus hstatus : this.metadata.archive.values()) {
/*  464 */       String child = hstatus.getName();
/*  465 */       if (child.startsWith(parentString)) {
/*  466 */         Path thisPath = new Path(child);
/*  467 */         if (thisPath.depth() == harlen + 1)
/*  468 */           statuses.add(toFileStatus(hstatus, cache));
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private FileStatus toFileStatus(HarStatus h, Map<String, FileStatus> cache)
/*      */     throws IOException
/*      */   {
/*  483 */     FileStatus underlying = null;
/*  484 */     if (cache != null) {
/*  485 */       underlying = (FileStatus)cache.get(h.partName);
/*      */     }
/*  487 */     if (underlying == null) {
/*  488 */       Path p = h.isDir ? this.archivePath : new Path(this.archivePath, h.partName);
/*  489 */       underlying = this.fs.getFileStatus(p);
/*  490 */       if (cache != null) {
/*  491 */         cache.put(h.partName, underlying);
/*      */       }
/*      */     }
/*      */ 
/*  495 */     long modTime = 0L;
/*  496 */     int version = this.metadata.getVersion();
/*  497 */     if (version < 3)
/*  498 */       modTime = underlying.getModificationTime();
/*  499 */     else if (version == 3) {
/*  500 */       modTime = h.getModificationTime();
/*      */     }
/*      */ 
/*  503 */     return new FileStatus(h.isDir() ? 0L : h.getLength(), h.isDir(), underlying.getReplication(), underlying.getBlockSize(), modTime, underlying.getAccessTime(), underlying.getPermission(), underlying.getOwner(), underlying.getGroup(), makeRelative(this.uri.getPath(), new Path(h.name)));
/*      */   }
/*      */ 
/*      */   public FileStatus getFileStatus(Path f)
/*      */     throws IOException
/*      */   {
/*  610 */     HarStatus hstatus = getFileHarStatus(f);
/*  611 */     return toFileStatus(hstatus, null);
/*      */   }
/*      */ 
/*      */   private HarStatus getFileHarStatus(Path f)
/*      */     throws IOException
/*      */   {
/*  617 */     Path p = makeQualified(f);
/*  618 */     Path harPath = getPathInHar(p);
/*  619 */     if (harPath == null) {
/*  620 */       throw new IOException("Invalid file name: " + f + " in " + this.uri);
/*      */     }
/*  622 */     HarStatus hstatus = (HarStatus)this.metadata.archive.get(harPath);
/*  623 */     if (hstatus == null) {
/*  624 */       throw new FileNotFoundException("File: " + f + " does not exist in " + this.uri);
/*      */     }
/*  626 */     return hstatus;
/*      */   }
/*      */ 
/*      */   public FileChecksum getFileChecksum(Path f)
/*      */   {
/*  633 */     return null;
/*      */   }
/*      */ 
/*      */   public FSDataInputStream open(Path f, int bufferSize)
/*      */     throws IOException
/*      */   {
/*  644 */     HarStatus hstatus = getFileHarStatus(f);
/*      */ 
/*  646 */     if (hstatus.isDir()) {
/*  647 */       throw new FileNotFoundException(f + " : not a file in " + this.archivePath);
/*      */     }
/*      */ 
/*  650 */     return new HarFSDataInputStream(this.fs, new Path(this.archivePath, hstatus.getPartName()), hstatus.getStartIndex(), hstatus.getLength(), bufferSize);
/*      */   }
/*      */ 
/*      */   public FSDataOutputStream create(Path f, int bufferSize)
/*      */     throws IOException
/*      */   {
/*  661 */     throw new IOException("Har: Create not allowed");
/*      */   }
/*      */ 
/*      */   public FSDataOutputStream create(Path f, FsPermission permission, boolean overwrite, int bufferSize, short replication, long blockSize, Progressable progress)
/*      */     throws IOException
/*      */   {
/*  671 */     throw new IOException("Har: create not allowed.");
/*      */   }
/*      */ 
/*      */   public void close() throws IOException
/*      */   {
/*  676 */     if (this.fs != null)
/*      */       try {
/*  678 */         this.fs.close();
/*      */       }
/*      */       catch (IOException ie)
/*      */       {
/*      */       }
/*      */   }
/*      */ 
/*      */   public boolean setReplication(Path src, short replication)
/*      */     throws IOException
/*      */   {
/*  691 */     throw new IOException("Har: setreplication not allowed");
/*      */   }
/*      */ 
/*      */   public boolean delete(Path f, boolean recursive)
/*      */     throws IOException
/*      */   {
/*  699 */     throw new IOException("Har: delete not allowed");
/*      */   }
/*      */ 
/*      */   public FileStatus[] listStatus(Path f)
/*      */     throws IOException
/*      */   {
/*  712 */     List statuses = new ArrayList();
/*  713 */     Path tmpPath = makeQualified(f);
/*  714 */     Path harPath = getPathInHar(tmpPath);
/*  715 */     HarStatus hstatus = (HarStatus)this.metadata.archive.get(harPath);
/*  716 */     if (hstatus == null) {
/*  717 */       throw new FileNotFoundException("File " + f + " not found in " + this.archivePath);
/*      */     }
/*  719 */     if (hstatus.isDir())
/*  720 */       fileStatusesInIndex(hstatus, statuses, hstatus.children);
/*      */     else {
/*  722 */       statuses.add(toFileStatus(hstatus, null));
/*      */     }
/*      */ 
/*  725 */     return (FileStatus[])statuses.toArray(new FileStatus[statuses.size()]);
/*      */   }
/*      */ 
/*      */   public Path getHomeDirectory()
/*      */   {
/*  732 */     return new Path(this.uri.toString());
/*      */   }
/*      */ 
/*      */   public void setWorkingDirectory(Path newDir)
/*      */   {
/*      */   }
/*      */ 
/*      */   public boolean mkdirs(Path f, FsPermission permission)
/*      */     throws IOException
/*      */   {
/*  743 */     throw new IOException("Har: mkdirs not allowed");
/*      */   }
/*      */ 
/*      */   public void copyFromLocalFile(boolean delSrc, Path src, Path dst)
/*      */     throws IOException
/*      */   {
/*  751 */     throw new IOException("Har: copyfromlocalfile not allowed");
/*      */   }
/*      */ 
/*      */   public void copyToLocalFile(boolean delSrc, Path src, Path dst)
/*      */     throws IOException
/*      */   {
/*  759 */     FileUtil.copy(this, src, getLocal(getConf()), dst, false, getConf());
/*      */   }
/*      */ 
/*      */   public Path startLocalOutput(Path fsOutputFile, Path tmpLocalFile)
/*      */     throws IOException
/*      */   {
/*  767 */     throw new IOException("Har: startLocalOutput not allowed");
/*      */   }
/*      */ 
/*      */   public void completeLocalOutput(Path fsOutputFile, Path tmpLocalFile)
/*      */     throws IOException
/*      */   {
/*  775 */     throw new IOException("Har: completeLocalOutput not allowed");
/*      */   }
/*      */ 
/*      */   public void setOwner(Path p, String username, String groupname)
/*      */     throws IOException
/*      */   {
/*  783 */     throw new IOException("Har: setowner not allowed");
/*      */   }
/*      */ 
/*      */   public void setPermission(Path p, FsPermission permisssion)
/*      */     throws IOException
/*      */   {
/*  791 */     throw new IOException("Har: setPermission not allowed");
/*      */   }
/*      */ 
/*      */   private class HarMetaData
/*      */   {
/*      */     private FileSystem fs;
/*      */     private int version;
/*      */     private Path masterIndexPath;
/*      */     private Path archiveIndexPath;
/*      */     private long masterIndexTimestamp;
/*      */     private long archiveIndexTimestamp;
/*  978 */     List<HarFileSystem.Store> stores = new ArrayList();
/*  979 */     Map<Path, HarFileSystem.HarStatus> archive = new HashMap();
/*  980 */     private Map<Path, FileStatus> partFileStatuses = new HashMap();
/*      */ 
/*      */     public HarMetaData(FileSystem fs, Path masterIndexPath, Path archiveIndexPath) {
/*  983 */       this.fs = fs;
/*  984 */       this.masterIndexPath = masterIndexPath;
/*  985 */       this.archiveIndexPath = archiveIndexPath;
/*      */     }
/*      */ 
/*      */     public FileStatus getPartFileStatus(Path partPath) throws IOException
/*      */     {
/*  990 */       FileStatus status = (FileStatus)this.partFileStatuses.get(partPath);
/*  991 */       if (status == null) {
/*  992 */         status = this.fs.getFileStatus(partPath);
/*  993 */         this.partFileStatuses.put(partPath, status);
/*      */       }
/*  995 */       return status;
/*      */     }
/*      */ 
/*      */     public long getMasterIndexTimestamp() {
/*  999 */       return this.masterIndexTimestamp;
/*      */     }
/*      */ 
/*      */     public long getArchiveIndexTimestamp() {
/* 1003 */       return this.archiveIndexTimestamp;
/*      */     }
/*      */ 
/*      */     private int getVersion() {
/* 1007 */       return this.version;
/*      */     }
/*      */ 
/*      */     private void parseMetaData() throws IOException {
/* 1011 */       FSDataInputStream in = this.fs.open(this.masterIndexPath);
/* 1012 */       FileStatus masterStat = this.fs.getFileStatus(this.masterIndexPath);
/* 1013 */       this.masterIndexTimestamp = masterStat.getModificationTime();
/* 1014 */       LineReader lin = new LineReader(in, HarFileSystem.this.getConf());
/* 1015 */       Text line = new Text();
/* 1016 */       long read = lin.readLine(line);
/*      */ 
/* 1019 */       String versionLine = line.toString();
/* 1020 */       String[] arr = versionLine.split(" ");
/* 1021 */       this.version = Integer.parseInt(arr[0]);
/*      */ 
/* 1023 */       if (this.version > 3) {
/* 1024 */         throw new IOException("Invalid version " + this.version + " expected " + 3);
/*      */       }
/*      */ 
/* 1029 */       String[] readStr = null;
/* 1030 */       while (read < masterStat.getLen()) {
/* 1031 */         int b = lin.readLine(line);
/* 1032 */         read += b;
/* 1033 */         readStr = line.toString().split(" ");
/* 1034 */         int startHash = Integer.parseInt(readStr[0]);
/* 1035 */         int endHash = Integer.parseInt(readStr[1]);
/* 1036 */         this.stores.add(new HarFileSystem.Store(Long.parseLong(readStr[2]), Long.parseLong(readStr[3]), startHash, endHash));
/*      */ 
/* 1039 */         line.clear();
/*      */       }
/*      */       try
/*      */       {
/* 1043 */         lin.close();
/*      */       }
/*      */       catch (IOException io)
/*      */       {
/*      */       }
/* 1048 */       FSDataInputStream aIn = this.fs.open(this.archiveIndexPath);
/* 1049 */       FileStatus archiveStat = this.fs.getFileStatus(this.archiveIndexPath);
/* 1050 */       this.archiveIndexTimestamp = archiveStat.getModificationTime();
/*      */ 
/* 1054 */       for (HarFileSystem.Store s : this.stores) {
/* 1055 */         read = 0L;
/* 1056 */         aIn.seek(s.begin);
/* 1057 */         LineReader aLin = new LineReader(aIn, HarFileSystem.this.getConf());
/* 1058 */         while (read + s.begin < s.end) {
/* 1059 */           int tmp = aLin.readLine(line);
/* 1060 */           read += tmp;
/* 1061 */           String lineFeed = line.toString();
/* 1062 */           String[] parsed = lineFeed.split(" ");
/* 1063 */           parsed[0] = HarFileSystem.this.decodeFileName(parsed[0]);
/* 1064 */           this.archive.put(new Path(parsed[0]), new HarFileSystem.HarStatus(HarFileSystem.this, lineFeed));
/* 1065 */           line.clear();
/*      */         }
/*      */       }
/*      */       try
/*      */       {
/* 1070 */         aIn.close();
/*      */       }
/*      */       catch (IOException io)
/*      */       {
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class HarFSDataInputStream extends FSDataInputStream
/*      */   {
/*      */     public HarFSDataInputStream(FileSystem fs, Path p, long start, long length, int bufsize)
/*      */       throws IOException
/*      */     {
/*  950 */       super();
/*      */     }
/*      */ 
/*      */     public HarFSDataInputStream(FileSystem fs, Path p, long start, long length)
/*      */       throws IOException
/*      */     {
/*  963 */       super();
/*      */     }
/*      */ 
/*      */     private static class HarFsInputStream extends FSInputStream
/*      */     {
/*      */       private long position;
/*      */       private long start;
/*      */       private long end;
/*      */       private FSDataInputStream underLyingStream;
/*  808 */       private byte[] oneBytebuff = new byte[1];
/*      */ 
/*      */       HarFsInputStream(FileSystem fs, Path path, long start, long length, int bufferSize) throws IOException {
/*  811 */         this.underLyingStream = fs.open(path, bufferSize);
/*  812 */         this.underLyingStream.seek(start);
/*      */ 
/*  814 */         this.start = start;
/*      */ 
/*  816 */         this.position = start;
/*      */ 
/*  818 */         this.end = (start + length);
/*      */       }
/*      */ 
/*      */       public synchronized int available() throws IOException {
/*  822 */         long remaining = this.end - this.underLyingStream.getPos();
/*  823 */         if (remaining > 2147483647L) {
/*  824 */           return 2147483647;
/*      */         }
/*  826 */         return (int)remaining;
/*      */       }
/*      */ 
/*      */       public synchronized void close() throws IOException {
/*  830 */         this.underLyingStream.close();
/*  831 */         super.close();
/*      */       }
/*      */ 
/*      */       public void mark(int readLimit)
/*      */       {
/*      */       }
/*      */ 
/*      */       public void reset()
/*      */         throws IOException
/*      */       {
/*  844 */         throw new IOException("reset not implemented.");
/*      */       }
/*      */ 
/*      */       public synchronized int read() throws IOException {
/*  848 */         int ret = read(this.oneBytebuff, 0, 1);
/*  849 */         return ret <= 0 ? -1 : this.oneBytebuff[0] & 0xFF;
/*      */       }
/*      */ 
/*      */       public synchronized int read(byte[] b) throws IOException {
/*  853 */         int ret = read(b, 0, b.length);
/*  854 */         if (ret != -1) {
/*  855 */           this.position += ret;
/*      */         }
/*  857 */         return ret;
/*      */       }
/*      */ 
/*      */       public synchronized int read(byte[] b, int offset, int len)
/*      */         throws IOException
/*      */       {
/*  865 */         int newlen = len;
/*  866 */         int ret = -1;
/*  867 */         if (this.position + len > this.end) {
/*  868 */           newlen = (int)(this.end - this.position);
/*      */         }
/*      */ 
/*  871 */         if (newlen == 0)
/*  872 */           return ret;
/*  873 */         ret = this.underLyingStream.read(b, offset, newlen);
/*  874 */         this.position += ret;
/*  875 */         return ret;
/*      */       }
/*      */ 
/*      */       public synchronized long skip(long n) throws IOException {
/*  879 */         long tmpN = n;
/*  880 */         if (tmpN > 0L) {
/*  881 */           if (this.position + tmpN > this.end) {
/*  882 */             tmpN = this.end - this.position;
/*      */           }
/*  884 */           this.underLyingStream.seek(tmpN + this.position);
/*  885 */           this.position += tmpN;
/*  886 */           return tmpN;
/*      */         }
/*  888 */         return tmpN < 0L ? -1L : 0L;
/*      */       }
/*      */ 
/*      */       public synchronized long getPos() throws IOException {
/*  892 */         return this.position - this.start;
/*      */       }
/*      */ 
/*      */       public synchronized void seek(long pos) throws IOException {
/*  896 */         if ((pos < 0L) || (this.start + pos > this.end)) {
/*  897 */           throw new IOException("Failed to seek: EOF");
/*      */         }
/*  899 */         this.position = (this.start + pos);
/*  900 */         this.underLyingStream.seek(this.position);
/*      */       }
/*      */ 
/*      */       public boolean seekToNewSource(long targetPos)
/*      */         throws IOException
/*      */       {
/*  907 */         return false;
/*      */       }
/*      */ 
/*      */       public int read(long pos, byte[] b, int offset, int length)
/*      */         throws IOException
/*      */       {
/*  915 */         int nlength = length;
/*  916 */         if (this.start + nlength + pos > this.end) {
/*  917 */           nlength = (int)(this.end - (this.start + pos));
/*      */         }
/*  919 */         return this.underLyingStream.read(pos + this.start, b, offset, nlength);
/*      */       }
/*      */ 
/*      */       public void readFully(long pos, byte[] b, int offset, int length)
/*      */         throws IOException
/*      */       {
/*  927 */         if (this.start + length + pos > this.end) {
/*  928 */           throw new IOException("Not enough bytes to read.");
/*      */         }
/*  930 */         this.underLyingStream.readFully(pos + this.start, b, offset, length);
/*      */       }
/*      */ 
/*      */       public void readFully(long pos, byte[] b) throws IOException {
/*  934 */         readFully(pos, b, 0, b.length);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private class HarStatus
/*      */   {
/*      */     boolean isDir;
/*      */     String name;
/*      */     List<String> children;
/*      */     String partName;
/*      */     long startIndex;
/*      */     long length;
/*  528 */     long modificationTime = 0L;
/*      */ 
/*      */     public HarStatus(String harString) throws UnsupportedEncodingException {
/*  531 */       String[] splits = harString.split(" ");
/*  532 */       this.name = HarFileSystem.this.decodeFileName(splits[0]);
/*  533 */       this.isDir = ("dir".equals(splits[1]));
/*      */ 
/*  535 */       this.partName = splits[2];
/*  536 */       this.startIndex = Long.parseLong(splits[3]);
/*  537 */       this.length = Long.parseLong(splits[4]);
/*      */ 
/*  539 */       int version = HarFileSystem.this.metadata.getVersion();
/*  540 */       String[] propSplits = null;
/*      */ 
/*  550 */       if (this.isDir) {
/*  551 */         if (version == 3) {
/*  552 */           propSplits = HarFileSystem.decodeString(this.partName).split(" ");
/*      */         }
/*  554 */         this.children = new ArrayList();
/*  555 */         for (int i = 5; i < splits.length; i++)
/*  556 */           this.children.add(HarFileSystem.this.decodeFileName(splits[i]));
/*      */       }
/*  558 */       else if (version == 3) {
/*  559 */         propSplits = HarFileSystem.decodeString(splits[5]).split(" ");
/*      */       }
/*      */ 
/*  562 */       if ((propSplits != null) && (propSplits.length >= 4))
/*  563 */         this.modificationTime = Long.parseLong(propSplits[0]);
/*      */     }
/*      */ 
/*      */     public boolean isDir()
/*      */     {
/*  572 */       return this.isDir;
/*      */     }
/*      */ 
/*      */     public String getName() {
/*  576 */       return this.name;
/*      */     }
/*      */ 
/*      */     public List<String> getChildren() {
/*  580 */       return this.children;
/*      */     }
/*      */     public String getFileName() {
/*  583 */       return this.name;
/*      */     }
/*      */     public String getPartName() {
/*  586 */       return this.partName;
/*      */     }
/*      */     public long getStartIndex() {
/*  589 */       return this.startIndex;
/*      */     }
/*      */     public long getLength() {
/*  592 */       return this.length;
/*      */     }
/*      */     public long getModificationTime() {
/*  595 */       return this.modificationTime;
/*      */     }
/*      */   }
/*      */ 
/*      */   static class Store
/*      */   {
/*      */     public long begin;
/*      */     public long end;
/*      */     public int startHash;
/*      */     public int endHash;
/*      */ 
/*      */     public Store()
/*      */     {
/*  425 */       this.begin = (this.end = this.startHash = this.endHash = 0);
/*      */     }
/*      */     public Store(long begin, long end, int startHash, int endHash) {
/*  428 */       this.begin = begin;
/*  429 */       this.end = end;
/*  430 */       this.startHash = startHash;
/*  431 */       this.endHash = endHash;
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.HarFileSystem
 * JD-Core Version:    0.6.1
 */
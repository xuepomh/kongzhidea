/*    */ package org.apache.hadoop.fs;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.net.URLStreamHandler;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ 
/*    */ class FsUrlStreamHandler extends URLStreamHandler
/*    */ {
/*    */   private Configuration conf;
/*    */ 
/*    */   FsUrlStreamHandler(Configuration conf)
/*    */   {
/* 35 */     this.conf = conf;
/*    */   }
/*    */ 
/*    */   FsUrlStreamHandler() {
/* 39 */     this.conf = new Configuration();
/*    */   }
/*    */ 
/*    */   protected FsUrlConnection openConnection(URL url) throws IOException
/*    */   {
/* 44 */     return new FsUrlConnection(this.conf, url);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.FsUrlStreamHandler
 * JD-Core Version:    0.6.1
 */
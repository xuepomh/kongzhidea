package org.apache.hadoop.fs;

public abstract interface PathFilter
{
  public abstract boolean accept(Path paramPath);
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.PathFilter
 * JD-Core Version:    0.6.1
 */
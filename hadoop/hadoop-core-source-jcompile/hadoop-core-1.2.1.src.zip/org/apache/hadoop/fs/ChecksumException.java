/*    */ package org.apache.hadoop.fs;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class ChecksumException extends IOException
/*    */ {
/*    */   private long pos;
/*    */ 
/*    */   public ChecksumException(String description, long pos)
/*    */   {
/* 27 */     super(description);
/* 28 */     this.pos = pos;
/*    */   }
/*    */ 
/*    */   public long getPos() {
/* 32 */     return this.pos;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.ChecksumException
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.fs;
/*    */ 
/*    */ import java.net.URLStreamHandler;
/*    */ import java.net.URLStreamHandlerFactory;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ 
/*    */ public class FsUrlStreamHandlerFactory
/*    */   implements URLStreamHandlerFactory
/*    */ {
/*    */   private Configuration conf;
/* 43 */   private Map<String, Boolean> protocols = new HashMap();
/*    */   private URLStreamHandler handler;
/*    */ 
/*    */   public FsUrlStreamHandlerFactory()
/*    */   {
/* 49 */     this.conf = new Configuration();
/*    */ 
/* 53 */     this.conf.getClass("fs.file.impl", null);
/* 54 */     this.handler = new FsUrlStreamHandler(this.conf);
/*    */   }
/*    */ 
/*    */   public FsUrlStreamHandlerFactory(Configuration conf) {
/* 58 */     this.conf = new Configuration(conf);
/*    */ 
/* 60 */     this.conf.getClass("fs.file.impl", null);
/* 61 */     this.handler = new FsUrlStreamHandler(this.conf);
/*    */   }
/*    */ 
/*    */   public URLStreamHandler createURLStreamHandler(String protocol) {
/* 65 */     if (!this.protocols.containsKey(protocol)) {
/* 66 */       boolean known = this.conf.getClass("fs." + protocol + ".impl", null) != null;
/*    */ 
/* 68 */       this.protocols.put(protocol, Boolean.valueOf(known));
/*    */     }
/* 70 */     if (((Boolean)this.protocols.get(protocol)).booleanValue()) {
/* 71 */       return this.handler;
/*    */     }
/*    */ 
/* 74 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.FsUrlStreamHandlerFactory
 * JD-Core Version:    0.6.1
 */
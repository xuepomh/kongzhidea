/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.regex.PatternSyntaxException;
/*     */ 
/*     */ public class GlobPattern
/*     */ {
/*     */   private static final char BACKSLASH = '\\';
/*     */   private Pattern compiled;
/*  30 */   private boolean hasWildcard = false;
/*     */ 
/*     */   public GlobPattern(String globPattern)
/*     */   {
/*  37 */     set(globPattern);
/*     */   }
/*     */ 
/*     */   public Pattern compiled()
/*     */   {
/*  44 */     return this.compiled;
/*     */   }
/*     */ 
/*     */   public static Pattern compile(String globPattern)
/*     */   {
/*  53 */     return new GlobPattern(globPattern).compiled();
/*     */   }
/*     */ 
/*     */   public boolean matches(CharSequence s)
/*     */   {
/*  62 */     return this.compiled.matcher(s).matches();
/*     */   }
/*     */ 
/*     */   public void set(String glob)
/*     */   {
/*  70 */     StringBuilder regex = new StringBuilder();
/*  71 */     int setOpen = 0;
/*  72 */     int curlyOpen = 0;
/*  73 */     int len = glob.length();
/*  74 */     this.hasWildcard = false;
/*     */ 
/*  76 */     for (int i = 0; i < len; i++) {
/*  77 */       char c = glob.charAt(i);
/*     */ 
/*  79 */       switch (c) {
/*     */       case '\\':
/*  81 */         i++; if (i >= len) {
/*  82 */           error("Missing escaped character", glob, i);
/*     */         }
/*  84 */         regex.append(c).append(glob.charAt(i));
/*  85 */         break;
/*     */       case '$':
/*     */       case '(':
/*     */       case ')':
/*     */       case '+':
/*     */       case '.':
/*     */       case '|':
/*  93 */         regex.append('\\');
/*  94 */         break;
/*     */       case '*':
/*  96 */         regex.append('.');
/*  97 */         this.hasWildcard = true;
/*  98 */         break;
/*     */       case '?':
/* 100 */         regex.append('.');
/* 101 */         this.hasWildcard = true;
/* 102 */         break;
/*     */       case '{':
/* 104 */         regex.append("(?:");
/* 105 */         curlyOpen++;
/* 106 */         this.hasWildcard = true;
/* 107 */         break;
/*     */       case ',':
/* 109 */         regex.append(curlyOpen > 0 ? '|' : c);
/* 110 */         break;
/*     */       case '}':
/* 112 */         if (curlyOpen > 0)
/*     */         {
/* 114 */           curlyOpen--;
/* 115 */           regex.append(")");
/* 116 */         }break;
/*     */       case '[':
/* 120 */         if (setOpen > 0) {
/* 121 */           error("Unclosed character class", glob, i);
/*     */         }
/* 123 */         setOpen++;
/* 124 */         this.hasWildcard = true;
/* 125 */         break;
/*     */       case '^':
/* 127 */         if (setOpen == 0)
/* 128 */           regex.append('\\'); break;
/*     */       case '!':
/* 132 */         regex.append((setOpen > 0) && ('[' == glob.charAt(i - 1)) ? '^' : '!');
/* 133 */         break;
/*     */       case ']':
/* 138 */         setOpen = 0;
/* 139 */         break;
/*     */       }
/*     */ 
/* 142 */       regex.append(c);
/*     */     }
/*     */ 
/* 145 */     if (setOpen > 0) {
/* 146 */       error("Unclosed character class", glob, len);
/*     */     }
/* 148 */     if (curlyOpen > 0) {
/* 149 */       error("Unclosed group", glob, len);
/*     */     }
/* 151 */     this.compiled = Pattern.compile(regex.toString());
/*     */   }
/*     */ 
/*     */   public boolean hasWildcard()
/*     */   {
/* 158 */     return this.hasWildcard;
/*     */   }
/*     */ 
/*     */   private static void error(String message, String pattern, int pos) {
/* 162 */     throw new PatternSyntaxException(message, pattern, pos);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.GlobPattern
 * JD-Core Version:    0.6.1
 */
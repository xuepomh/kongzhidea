/*    */ package org.apache.hadoop.fs;
/*    */ 
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.FilterOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ public class FSDataOutputStream extends DataOutputStream
/*    */   implements Syncable
/*    */ {
/*    */   private OutputStream wrappedStream;
/*    */ 
/*    */   @Deprecated
/*    */   public FSDataOutputStream(OutputStream out)
/*    */     throws IOException
/*    */   {
/* 67 */     this(out, null);
/*    */   }
/*    */ 
/*    */   public FSDataOutputStream(OutputStream out, FileSystem.Statistics stats) throws IOException
/*    */   {
/* 72 */     this(out, stats, 0L);
/*    */   }
/*    */ 
/*    */   public FSDataOutputStream(OutputStream out, FileSystem.Statistics stats, long startPosition) throws IOException
/*    */   {
/* 77 */     super(new PositionCache(out, stats, startPosition));
/* 78 */     this.wrappedStream = out;
/*    */   }
/*    */ 
/*    */   public long getPos() throws IOException {
/* 82 */     return ((PositionCache)this.out).getPos();
/*    */   }
/*    */ 
/*    */   public void close() throws IOException {
/* 86 */     this.out.close();
/*    */   }
/*    */ 
/*    */   public OutputStream getWrappedStream()
/*    */   {
/* 91 */     return this.wrappedStream;
/*    */   }
/*    */ 
/*    */   public void sync() throws IOException
/*    */   {
/* 96 */     if ((this.wrappedStream instanceof Syncable))
/* 97 */       ((Syncable)this.wrappedStream).sync();
/*    */     else
/* 99 */       this.wrappedStream.flush();
/*    */   }
/*    */ 
/*    */   private static class PositionCache extends FilterOutputStream
/*    */   {
/*    */     private FileSystem.Statistics statistics;
/*    */     long position;
/*    */ 
/*    */     public PositionCache(OutputStream out, FileSystem.Statistics stats, long pos)
/*    */       throws IOException
/*    */     {
/* 35 */       super();
/* 36 */       this.statistics = stats;
/* 37 */       this.position = pos;
/*    */     }
/*    */ 
/*    */     public void write(int b) throws IOException {
/* 41 */       this.out.write(b);
/* 42 */       this.position += 1L;
/* 43 */       if (this.statistics != null)
/* 44 */         this.statistics.incrementBytesWritten(1L);
/*    */     }
/*    */ 
/*    */     public void write(byte[] b, int off, int len) throws IOException
/*    */     {
/* 49 */       this.out.write(b, off, len);
/* 50 */       this.position += len;
/* 51 */       if (this.statistics != null)
/* 52 */         this.statistics.incrementBytesWritten(len);
/*    */     }
/*    */ 
/*    */     public long getPos() throws IOException
/*    */     {
/* 57 */       return this.position;
/*    */     }
/*    */ 
/*    */     public void close() throws IOException {
/* 61 */       this.out.close();
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.FSDataOutputStream
 * JD-Core Version:    0.6.1
 */
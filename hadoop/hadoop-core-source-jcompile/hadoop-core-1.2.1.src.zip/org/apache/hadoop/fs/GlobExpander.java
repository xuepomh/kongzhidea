/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ class GlobExpander
/*     */ {
/*     */   public static List<String> expand(String filePattern)
/*     */     throws IOException
/*     */   {
/*  45 */     List fullyExpanded = new ArrayList();
/*  46 */     List toExpand = new ArrayList();
/*  47 */     toExpand.add(new StringWithOffset(filePattern, 0));
/*  48 */     while (!toExpand.isEmpty()) {
/*  49 */       StringWithOffset path = (StringWithOffset)toExpand.remove(0);
/*  50 */       List expanded = expandLeftmost(path);
/*  51 */       if (expanded == null)
/*  52 */         fullyExpanded.add(path.string);
/*     */       else {
/*  54 */         toExpand.addAll(0, expanded);
/*     */       }
/*     */     }
/*  57 */     return fullyExpanded;
/*     */   }
/*     */ 
/*     */   private static List<StringWithOffset> expandLeftmost(StringWithOffset filePatternWithOffset)
/*     */     throws IOException
/*     */   {
/*  70 */     String filePattern = filePatternWithOffset.string;
/*  71 */     int leftmost = leftmostOuterCurlyContainingSlash(filePattern, filePatternWithOffset.offset);
/*     */ 
/*  73 */     if (leftmost == -1) {
/*  74 */       return null;
/*     */     }
/*  76 */     int curlyOpen = 0;
/*  77 */     StringBuilder prefix = new StringBuilder(filePattern.substring(0, leftmost));
/*  78 */     StringBuilder suffix = new StringBuilder();
/*  79 */     List alts = new ArrayList();
/*  80 */     StringBuilder alt = new StringBuilder();
/*  81 */     StringBuilder cur = prefix;
/*  82 */     for (int i = leftmost; i < filePattern.length(); i++) {
/*  83 */       char c = filePattern.charAt(i);
/*  84 */       if (cur == suffix) {
/*  85 */         cur.append(c);
/*  86 */       } else if (c == '\\') {
/*  87 */         i++;
/*  88 */         if (i >= filePattern.length()) {
/*  89 */           throw new IOException(new StringBuilder().append("Illegal file pattern: An escaped character does not present for glob ").append(filePattern).append(" at ").append(i).toString());
/*     */         }
/*     */ 
/*  93 */         c = filePattern.charAt(i);
/*  94 */         cur.append(c);
/*  95 */       } else if (c == '{') {
/*  96 */         if (curlyOpen++ == 0) {
/*  97 */           alt.setLength(0);
/*  98 */           cur = alt;
/*     */         } else {
/* 100 */           cur.append(c);
/*     */         }
/*     */       }
/* 103 */       else if ((c == '}') && (curlyOpen > 0)) {
/* 104 */         curlyOpen--; if (curlyOpen == 0) {
/* 105 */           alts.add(alt.toString());
/* 106 */           alt.setLength(0);
/* 107 */           cur = suffix;
/*     */         } else {
/* 109 */           cur.append(c);
/*     */         }
/* 111 */       } else if (c == ',') {
/* 112 */         if (curlyOpen == 1) {
/* 113 */           alts.add(alt.toString());
/* 114 */           alt.setLength(0);
/*     */         } else {
/* 116 */           cur.append(c);
/*     */         }
/*     */       } else {
/* 119 */         cur.append(c);
/*     */       }
/*     */     }
/* 122 */     List exp = new ArrayList();
/* 123 */     for (String string : alts) {
/* 124 */       exp.add(new StringWithOffset(new StringBuilder().append(prefix).append(string).append(suffix).toString(), prefix.length()));
/*     */     }
/* 126 */     return exp;
/*     */   }
/*     */ 
/*     */   private static int leftmostOuterCurlyContainingSlash(String filePattern, int offset)
/*     */     throws IOException
/*     */   {
/* 139 */     int curlyOpen = 0;
/* 140 */     int leftmost = -1;
/* 141 */     boolean seenSlash = false;
/* 142 */     for (int i = offset; i < filePattern.length(); i++) {
/* 143 */       char c = filePattern.charAt(i);
/* 144 */       if (c == '\\') {
/* 145 */         i++;
/* 146 */         if (i >= filePattern.length()) {
/* 147 */           throw new IOException(new StringBuilder().append("Illegal file pattern: An escaped character does not present for glob ").append(filePattern).append(" at ").append(i).toString());
/*     */         }
/*     */ 
/*     */       }
/* 151 */       else if (c == '{') {
/* 152 */         if (curlyOpen++ == 0)
/* 153 */           leftmost = i;
/*     */       }
/* 155 */       else if ((c == '}') && (curlyOpen > 0)) {
/* 156 */         curlyOpen--; if ((curlyOpen == 0) && (leftmost != -1) && (seenSlash))
/* 157 */           return leftmost;
/*     */       }
/* 159 */       else if ((c == '/') && (curlyOpen > 0)) {
/* 160 */         seenSlash = true;
/*     */       }
/*     */     }
/* 163 */     return -1;
/*     */   }
/*     */ 
/*     */   static class StringWithOffset
/*     */   {
/*     */     String string;
/*     */     int offset;
/*     */ 
/*     */     public StringWithOffset(String string, int offset)
/*     */     {
/*  31 */       this.string = string;
/*  32 */       this.offset = offset;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.GlobExpander
 * JD-Core Version:    0.6.1
 */
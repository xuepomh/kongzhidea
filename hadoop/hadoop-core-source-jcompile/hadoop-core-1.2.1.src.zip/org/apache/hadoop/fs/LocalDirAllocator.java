/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.util.DiskChecker;
/*     */ import org.apache.hadoop.util.DiskChecker.DiskErrorException;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ public class LocalDirAllocator
/*     */ {
/*  68 */   private static Map<String, AllocatorPerContext> contexts = new TreeMap();
/*     */   private String contextCfgItemName;
/*     */   public static final int SIZE_UNKNOWN = -1;
/*     */ 
/*     */   public LocalDirAllocator(String contextCfgItemName)
/*     */   {
/*  79 */     this.contextCfgItemName = contextCfgItemName;
/*     */   }
/*     */ 
/*     */   private AllocatorPerContext obtainContext(String contextCfgItemName)
/*     */   {
/*  89 */     synchronized (contexts) {
/*  90 */       AllocatorPerContext l = (AllocatorPerContext)contexts.get(contextCfgItemName);
/*  91 */       if (l == null) {
/*  92 */         contexts.put(contextCfgItemName, l = new AllocatorPerContext(contextCfgItemName));
/*     */       }
/*     */ 
/*  95 */       return l;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Path getLocalPathForWrite(String pathStr, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 111 */     return getLocalPathForWrite(pathStr, -1L, conf);
/*     */   }
/*     */ 
/*     */   public Path getLocalPathForWrite(String pathStr, long size, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 127 */     return getLocalPathForWrite(pathStr, size, conf, true);
/*     */   }
/*     */ 
/*     */   public Path getLocalPathForWrite(String pathStr, long size, Configuration conf, boolean checkWrite)
/*     */     throws IOException
/*     */   {
/* 145 */     AllocatorPerContext context = obtainContext(this.contextCfgItemName);
/* 146 */     return context.getLocalPathForWrite(pathStr, size, conf, checkWrite);
/*     */   }
/*     */ 
/*     */   public Path getLocalPathToRead(String pathStr, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 159 */     AllocatorPerContext context = obtainContext(this.contextCfgItemName);
/* 160 */     return context.getLocalPathToRead(pathStr, conf);
/*     */   }
/*     */ 
/*     */   public Iterable<Path> getAllLocalPathsToRead(String pathStr, Configuration conf)
/*     */     throws IOException
/*     */   {
/*     */     AllocatorPerContext context;
/* 174 */     synchronized (this) {
/* 175 */       context = obtainContext(this.contextCfgItemName);
/*     */     }
/* 177 */     return context.getAllLocalPathsToRead(pathStr, conf);
/*     */   }
/*     */ 
/*     */   public File createTmpFileForWrite(String pathStr, long size, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 193 */     AllocatorPerContext context = obtainContext(this.contextCfgItemName);
/* 194 */     return context.createTmpFileForWrite(pathStr, size, conf);
/*     */   }
/*     */ 
/*     */   public static boolean isContextValid(String contextCfgItemName)
/*     */   {
/* 202 */     synchronized (contexts) {
/* 203 */       return contexts.containsKey(contextCfgItemName);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean ifExists(String pathStr, Configuration conf)
/*     */   {
/* 215 */     AllocatorPerContext context = obtainContext(this.contextCfgItemName);
/* 216 */     return context.ifExists(pathStr, conf);
/*     */   }
/*     */ 
/*     */   int getCurrentDirectoryIndex()
/*     */   {
/* 224 */     AllocatorPerContext context = obtainContext(this.contextCfgItemName);
/* 225 */     return context.getCurrentDirectoryIndex();
/*     */   }
/*     */ 
/*     */   private static class AllocatorPerContext
/*     */   {
/* 230 */     private final Log LOG = LogFactory.getLog(AllocatorPerContext.class);
/*     */     private int dirNumLastAccessed;
/* 234 */     private Random dirIndexRandomizer = new Random();
/*     */     private FileSystem localFS;
/*     */     private DF[] dirDF;
/*     */     private String contextCfgItemName;
/*     */     private Path[] localDirsPath;
/* 239 */     private String savedLocalDirs = "";
/*     */ 
/*     */     public AllocatorPerContext(String contextCfgItemName) {
/* 242 */       this.contextCfgItemName = contextCfgItemName;
/*     */     }
/*     */ 
/*     */     private synchronized void confChanged(Configuration conf)
/*     */       throws IOException
/*     */     {
/* 250 */       String newLocalDirs = conf.get(this.contextCfgItemName);
/* 251 */       if (!newLocalDirs.equals(this.savedLocalDirs)) {
/* 252 */         String[] localDirs = conf.getStrings(this.contextCfgItemName);
/* 253 */         this.localFS = FileSystem.getLocal(conf);
/* 254 */         int numDirs = localDirs.length;
/* 255 */         ArrayList dirs = new ArrayList(numDirs);
/* 256 */         ArrayList dfList = new ArrayList(numDirs);
/* 257 */         for (int i = 0; i < numDirs; i++) {
/*     */           try
/*     */           {
/* 260 */             Path tmpDir = new Path(localDirs[i]);
/* 261 */             if ((this.localFS.mkdirs(tmpDir)) || (this.localFS.exists(tmpDir))) {
/*     */               try {
/* 263 */                 DiskChecker.checkDir(new File(localDirs[i]));
/* 264 */                 dirs.add(localDirs[i]);
/* 265 */                 dfList.add(new DF(new File(localDirs[i]), 30000L));
/*     */               } catch (DiskChecker.DiskErrorException de) {
/* 267 */                 this.LOG.warn(localDirs[i] + "is not writable\n" + StringUtils.stringifyException(de));
/*     */               }
/*     */             }
/*     */             else
/* 271 */               this.LOG.warn("Failed to create " + localDirs[i]);
/*     */           }
/*     */           catch (IOException ie) {
/* 274 */             this.LOG.warn("Failed to create " + localDirs[i] + ": " + ie.getMessage() + "\n" + StringUtils.stringifyException(ie));
/*     */           }
/*     */         }
/*     */ 
/* 278 */         this.localDirsPath = new Path[dirs.size()];
/* 279 */         for (int i = 0; i < this.localDirsPath.length; i++) {
/* 280 */           this.localDirsPath[i] = new Path((String)dirs.get(i));
/*     */         }
/* 282 */         this.dirDF = ((DF[])dfList.toArray(new DF[dirs.size()]));
/* 283 */         this.savedLocalDirs = newLocalDirs;
/*     */ 
/* 286 */         this.dirNumLastAccessed = this.dirIndexRandomizer.nextInt(dirs.size());
/*     */       }
/*     */     }
/*     */ 
/*     */     private Path createPath(Path path, boolean checkWrite) throws IOException
/*     */     {
/* 292 */       Path file = new Path(this.localDirsPath[this.dirNumLastAccessed], path);
/*     */ 
/* 294 */       if (checkWrite)
/*     */       {
/*     */         try
/*     */         {
/* 298 */           DiskChecker.checkDir(new File(file.getParent().toUri().getPath()));
/*     */         } catch (DiskChecker.DiskErrorException d) {
/* 300 */           this.LOG.warn(StringUtils.stringifyException(d));
/* 301 */           return null;
/*     */         }
/*     */       }
/* 304 */       return file;
/*     */     }
/*     */ 
/*     */     int getCurrentDirectoryIndex()
/*     */     {
/* 312 */       return this.dirNumLastAccessed;
/*     */     }
/*     */ 
/*     */     public synchronized Path getLocalPathForWrite(String pathStr, long size, Configuration conf, boolean checkWrite)
/*     */       throws IOException
/*     */     {
/* 326 */       confChanged(conf);
/* 327 */       int numDirs = this.localDirsPath.length;
/* 328 */       int numDirsSearched = 0;
/*     */ 
/* 331 */       if (pathStr.startsWith("/")) {
/* 332 */         pathStr = pathStr.substring(1);
/*     */       }
/* 334 */       Path returnPath = null;
/* 335 */       Path path = new Path(pathStr);
/*     */ 
/* 337 */       if (size == -1L)
/*     */       {
/* 339 */         long[] availableOnDisk = new long[this.dirDF.length];
/* 340 */         long totalAvailable = 0L;
/*     */ 
/* 343 */         for (int i = 0; i < this.dirDF.length; i++) {
/* 344 */           availableOnDisk[i] = this.dirDF[i].getAvailable();
/* 345 */           totalAvailable += availableOnDisk[i];
/*     */         }
/*     */ 
/* 349 */         Random r = new Random();
/* 350 */         while ((numDirsSearched < numDirs) && (returnPath == null)) {
/* 351 */           long randomPosition = Math.abs(r.nextLong()) % totalAvailable;
/* 352 */           int dir = 0;
/* 353 */           while (randomPosition > availableOnDisk[dir]) {
/* 354 */             randomPosition -= availableOnDisk[dir];
/* 355 */             dir++;
/*     */           }
/* 357 */           this.dirNumLastAccessed = dir;
/* 358 */           returnPath = createPath(path, checkWrite);
/* 359 */           if (returnPath == null) {
/* 360 */             totalAvailable -= availableOnDisk[dir];
/* 361 */             availableOnDisk[dir] = 0L;
/* 362 */             numDirsSearched++;
/*     */           }
/*     */         }
/*     */       } else {
/* 366 */         while ((numDirsSearched < numDirs) && (returnPath == null)) {
/* 367 */           long capacity = this.dirDF[this.dirNumLastAccessed].getAvailable();
/* 368 */           if (capacity > size) {
/* 369 */             returnPath = createPath(path, checkWrite);
/*     */           }
/* 371 */           this.dirNumLastAccessed += 1;
/* 372 */           this.dirNumLastAccessed %= numDirs;
/* 373 */           numDirsSearched++;
/*     */         }
/*     */       }
/* 376 */       if (returnPath != null) {
/* 377 */         return returnPath;
/*     */       }
/*     */ 
/* 381 */       throw new DiskChecker.DiskErrorException("Could not find any valid local directory for " + pathStr);
/*     */     }
/*     */ 
/*     */     public File createTmpFileForWrite(String pathStr, long size, Configuration conf)
/*     */       throws IOException
/*     */     {
/* 395 */       Path path = getLocalPathForWrite(pathStr, size, conf, true);
/* 396 */       File dir = new File(path.getParent().toUri().getPath());
/* 397 */       String prefix = path.getName();
/*     */ 
/* 400 */       File result = File.createTempFile(prefix, null, dir);
/* 401 */       result.deleteOnExit();
/* 402 */       return result;
/*     */     }
/*     */ 
/*     */     public synchronized Path getLocalPathToRead(String pathStr, Configuration conf)
/*     */       throws IOException
/*     */     {
/* 411 */       confChanged(conf);
/* 412 */       int numDirs = this.localDirsPath.length;
/* 413 */       int numDirsSearched = 0;
/*     */ 
/* 416 */       if (pathStr.startsWith("/")) {
/* 417 */         pathStr = pathStr.substring(1);
/*     */       }
/* 419 */       Path childPath = new Path(pathStr);
/* 420 */       while (numDirsSearched < numDirs) {
/* 421 */         Path file = new Path(this.localDirsPath[numDirsSearched], childPath);
/* 422 */         if (this.localFS.exists(file)) {
/* 423 */           return file;
/*     */         }
/* 425 */         numDirsSearched++;
/*     */       }
/*     */ 
/* 429 */       throw new DiskChecker.DiskErrorException("Could not find " + pathStr + " in any of" + " the configured local directories");
/*     */     }
/*     */ 
/*     */     synchronized Iterable<Path> getAllLocalPathsToRead(String pathStr, Configuration conf)
/*     */       throws IOException
/*     */     {
/* 496 */       confChanged(conf);
/* 497 */       if (pathStr.startsWith("/")) {
/* 498 */         pathStr = pathStr.substring(1);
/*     */       }
/* 500 */       return new PathIterator(this.localFS, pathStr, this.localDirsPath, null);
/*     */     }
/*     */ 
/*     */     public synchronized boolean ifExists(String pathStr, Configuration conf)
/*     */     {
/*     */       try
/*     */       {
/* 508 */         int numDirs = this.localDirsPath.length;
/* 509 */         int numDirsSearched = 0;
/*     */ 
/* 512 */         if (pathStr.startsWith("/")) {
/* 513 */           pathStr = pathStr.substring(1);
/*     */         }
/* 515 */         Path childPath = new Path(pathStr);
/* 516 */         while (numDirsSearched < numDirs) {
/* 517 */           Path file = new Path(this.localDirsPath[numDirsSearched], childPath);
/* 518 */           if (this.localFS.exists(file)) {
/* 519 */             return true;
/*     */           }
/* 521 */           numDirsSearched++;
/*     */         }
/*     */       }
/*     */       catch (IOException e) {
/*     */       }
/* 526 */       return false;
/*     */     }
/*     */ 
/*     */     private static class PathIterator
/*     */       implements Iterator<Path>, Iterable<Path>
/*     */     {
/*     */       private final FileSystem fs;
/*     */       private final String pathStr;
/* 437 */       private int i = 0;
/*     */       private final Path[] rootDirs;
/* 439 */       private Path next = null;
/*     */ 
/*     */       private PathIterator(FileSystem fs, String pathStr, Path[] rootDirs) throws IOException
/*     */       {
/* 443 */         this.fs = fs;
/* 444 */         this.pathStr = pathStr;
/* 445 */         this.rootDirs = rootDirs;
/* 446 */         advance();
/*     */       }
/*     */ 
/*     */       public boolean hasNext()
/*     */       {
/* 451 */         return this.next != null;
/*     */       }
/*     */ 
/*     */       private void advance() throws IOException {
/* 455 */         while (this.i < this.rootDirs.length) {
/* 456 */           this.next = new Path(this.rootDirs[(this.i++)], this.pathStr);
/* 457 */           if (this.fs.exists(this.next)) {
/* 458 */             return;
/*     */           }
/*     */         }
/* 461 */         this.next = null;
/*     */       }
/*     */ 
/*     */       public Path next()
/*     */       {
/* 466 */         Path result = this.next;
/*     */         try {
/* 468 */           advance();
/*     */         } catch (IOException ie) {
/* 470 */           throw new RuntimeException("Can't check existance of " + this.next, ie);
/*     */         }
/* 472 */         return result;
/*     */       }
/*     */ 
/*     */       public void remove()
/*     */       {
/* 477 */         throw new UnsupportedOperationException("read only iterator");
/*     */       }
/*     */ 
/*     */       public Iterator<Path> iterator()
/*     */       {
/* 482 */         return this;
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.LocalDirAllocator
 * JD-Core Version:    0.6.1
 */
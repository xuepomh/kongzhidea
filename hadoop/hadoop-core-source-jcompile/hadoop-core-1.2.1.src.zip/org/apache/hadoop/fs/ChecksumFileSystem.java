/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.util.Progressable;
/*     */ import org.apache.hadoop.util.PureJavaCrc32;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ public abstract class ChecksumFileSystem extends FilterFileSystem
/*     */ {
/*  40 */   private static final byte[] CHECKSUM_VERSION = { 99, 114, 99, 0 };
/*  41 */   private int bytesPerChecksum = 512;
/*  42 */   private boolean verifyChecksum = true;
/*     */ 
/* 470 */   private static final PathFilter DEFAULT_FILTER = new PathFilter() {
/*     */     public boolean accept(Path file) {
/* 472 */       return !ChecksumFileSystem.isChecksumFile(file);
/*     */     }
/* 470 */   };
/*     */ 
/*     */   public static double getApproxChkSumLength(long size)
/*     */   {
/*  45 */     return 0.01F * (float)size;
/*     */   }
/*     */ 
/*     */   public ChecksumFileSystem(FileSystem fs) {
/*  49 */     super(fs);
/*     */   }
/*     */ 
/*     */   public void setConf(Configuration conf) {
/*  53 */     super.setConf(conf);
/*  54 */     if (conf != null)
/*  55 */       this.bytesPerChecksum = conf.getInt("io.bytes.per.checksum", 512);
/*     */   }
/*     */ 
/*     */   public void setVerifyChecksum(boolean verifyChecksum)
/*     */   {
/*  63 */     this.verifyChecksum = verifyChecksum;
/*     */   }
/*     */ 
/*     */   public FileSystem getRawFileSystem()
/*     */   {
/*  68 */     return this.fs;
/*     */   }
/*     */ 
/*     */   public Path getChecksumFile(Path file)
/*     */   {
/*  73 */     return new Path(file.getParent(), "." + file.getName() + ".crc");
/*     */   }
/*     */ 
/*     */   public static boolean isChecksumFile(Path file)
/*     */   {
/*  78 */     String name = file.getName();
/*  79 */     return (name.startsWith(".")) && (name.endsWith(".crc"));
/*     */   }
/*     */ 
/*     */   public long getChecksumFileLength(Path file, long fileSize)
/*     */   {
/*  86 */     return getChecksumLength(fileSize, getBytesPerSum());
/*     */   }
/*     */ 
/*     */   public int getBytesPerSum()
/*     */   {
/*  91 */     return this.bytesPerChecksum;
/*     */   }
/*     */ 
/*     */   private int getSumBufferSize(int bytesPerSum, int bufferSize) {
/*  95 */     int defaultBufferSize = getConf().getInt("io.file.buffer.size", 4096);
/*  96 */     int proportionalBufferSize = bufferSize / bytesPerSum;
/*  97 */     return Math.max(bytesPerSum, Math.max(proportionalBufferSize, defaultBufferSize));
/*     */   }
/*     */ 
/*     */   public FSDataInputStream open(Path f, int bufferSize)
/*     */     throws IOException
/*     */   {
/* 283 */     return new FSDataInputStream(new ChecksumFSInputChecker(this, f, bufferSize));
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream append(Path f, int bufferSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 290 */     throw new IOException("Not supported");
/*     */   }
/*     */ 
/*     */   public static long getChecksumLength(long size, int bytesPerSum)
/*     */   {
/* 302 */     return (size + bytesPerSum - 1L) / bytesPerSum * 4L + CHECKSUM_VERSION.length + 4L;
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream create(Path f, FsPermission permission, boolean overwrite, int bufferSize, short replication, long blockSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 364 */     return create(f, permission, overwrite, true, bufferSize, replication, blockSize, progress);
/*     */   }
/*     */ 
/*     */   private FSDataOutputStream create(Path f, FsPermission permission, boolean overwrite, boolean createParent, int bufferSize, short replication, long blockSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 372 */     Path parent = f.getParent();
/* 373 */     if (parent != null) {
/* 374 */       if ((!createParent) && (!exists(parent))) {
/* 375 */         throw new FileNotFoundException("Parent directory doesn't exist: " + parent);
/*     */       }
/* 377 */       if (!mkdirs(parent)) {
/* 378 */         throw new IOException("Mkdirs failed to create " + parent);
/*     */       }
/*     */     }
/* 381 */     FSDataOutputStream out = new FSDataOutputStream(new ChecksumFSOutputSummer(this, f, overwrite, bufferSize, replication, blockSize, progress), null);
/*     */ 
/* 384 */     if (permission != null) {
/* 385 */       setPermission(f, permission);
/*     */     }
/* 387 */     return out;
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream createNonRecursive(Path f, FsPermission permission, boolean overwrite, int bufferSize, short replication, long blockSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 395 */     return create(f, permission, overwrite, false, bufferSize, replication, blockSize, progress);
/*     */   }
/*     */ 
/*     */   public boolean setReplication(Path src, short replication)
/*     */     throws IOException
/*     */   {
/* 409 */     boolean value = this.fs.setReplication(src, replication);
/* 410 */     if (!value) {
/* 411 */       return false;
/*     */     }
/* 413 */     Path checkFile = getChecksumFile(src);
/* 414 */     if (exists(checkFile)) {
/* 415 */       this.fs.setReplication(checkFile, replication);
/*     */     }
/* 417 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean rename(Path src, Path dst)
/*     */     throws IOException
/*     */   {
/* 424 */     if (this.fs.isDirectory(src)) {
/* 425 */       return this.fs.rename(src, dst);
/*     */     }
/*     */ 
/* 428 */     boolean value = this.fs.rename(src, dst);
/* 429 */     if (!value) {
/* 430 */       return false;
/*     */     }
/* 432 */     Path checkFile = getChecksumFile(src);
/* 433 */     if (this.fs.exists(checkFile)) {
/* 434 */       if (this.fs.isDirectory(dst))
/* 435 */         value = this.fs.rename(checkFile, dst);
/*     */       else {
/* 437 */         value = this.fs.rename(checkFile, getChecksumFile(dst));
/*     */       }
/*     */     }
/*     */ 
/* 441 */     return value;
/*     */   }
/*     */ 
/*     */   public boolean delete(Path f, boolean recursive)
/*     */     throws IOException
/*     */   {
/* 450 */     FileStatus fstatus = null;
/*     */     try {
/* 452 */       fstatus = this.fs.getFileStatus(f);
/*     */     } catch (FileNotFoundException e) {
/* 454 */       return false;
/*     */     }
/* 456 */     if (fstatus.isDir())
/*     */     {
/* 460 */       return this.fs.delete(f, recursive);
/*     */     }
/* 462 */     Path checkFile = getChecksumFile(f);
/* 463 */     if (this.fs.exists(checkFile)) {
/* 464 */       this.fs.delete(checkFile, true);
/*     */     }
/* 466 */     return this.fs.delete(f, true);
/*     */   }
/*     */ 
/*     */   public FileStatus[] listStatus(Path f)
/*     */     throws IOException
/*     */   {
/* 487 */     return this.fs.listStatus(f, DEFAULT_FILTER);
/*     */   }
/*     */ 
/*     */   public boolean mkdirs(Path f) throws IOException
/*     */   {
/* 492 */     return this.fs.mkdirs(f);
/*     */   }
/*     */ 
/*     */   public void copyFromLocalFile(boolean delSrc, Path src, Path dst)
/*     */     throws IOException
/*     */   {
/* 498 */     Configuration conf = getConf();
/* 499 */     FileUtil.copy(getLocal(conf), src, this, dst, delSrc, conf);
/*     */   }
/*     */ 
/*     */   public void copyToLocalFile(boolean delSrc, Path src, Path dst)
/*     */     throws IOException
/*     */   {
/* 509 */     Configuration conf = getConf();
/* 510 */     FileUtil.copy(this, src, getLocal(conf), dst, delSrc, conf);
/*     */   }
/*     */ 
/*     */   public void copyToLocalFile(Path src, Path dst, boolean copyCrc)
/*     */     throws IOException
/*     */   {
/* 521 */     if (!this.fs.isDirectory(src)) {
/* 522 */       this.fs.copyToLocalFile(src, dst);
/* 523 */       FileSystem localFs = getLocal(getConf()).getRawFileSystem();
/* 524 */       if (localFs.isDirectory(dst)) {
/* 525 */         dst = new Path(dst, src.getName());
/*     */       }
/* 527 */       dst = getChecksumFile(dst);
/* 528 */       if (localFs.exists(dst)) {
/* 529 */         localFs.delete(dst, true);
/*     */       }
/* 531 */       Path checksumFile = getChecksumFile(src);
/* 532 */       if ((copyCrc) && (this.fs.exists(checksumFile)))
/* 533 */         this.fs.copyToLocalFile(checksumFile, dst);
/*     */     }
/*     */     else {
/* 536 */       FileStatus[] srcs = listStatus(src);
/* 537 */       for (FileStatus srcFile : srcs)
/* 538 */         copyToLocalFile(srcFile.getPath(), new Path(dst, srcFile.getPath().getName()), copyCrc);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Path startLocalOutput(Path fsOutputFile, Path tmpLocalFile)
/*     */     throws IOException
/*     */   {
/* 547 */     return tmpLocalFile;
/*     */   }
/*     */ 
/*     */   public void completeLocalOutput(Path fsOutputFile, Path tmpLocalFile)
/*     */     throws IOException
/*     */   {
/* 553 */     moveFromLocalFile(tmpLocalFile, fsOutputFile);
/*     */   }
/*     */ 
/*     */   public boolean reportChecksumFailure(Path f, FSDataInputStream in, long inPos, FSDataInputStream sums, long sumsPos)
/*     */   {
/* 567 */     return false;
/*     */   }
/*     */ 
/*     */   private static class ChecksumFSOutputSummer extends FSOutputSummer
/*     */   {
/*     */     private FSDataOutputStream datas;
/*     */     private FSDataOutputStream sums;
/*     */     private static final float CHKSUM_AS_FRACTION = 0.01F;
/*     */ 
/*     */     public ChecksumFSOutputSummer(ChecksumFileSystem fs, Path file, boolean overwrite, short replication, long blockSize, Configuration conf)
/*     */       throws IOException
/*     */     {
/* 320 */       this(fs, file, overwrite, conf.getInt("io.file.buffer.size", 4096), replication, blockSize, null);
/*     */     }
/*     */ 
/*     */     public ChecksumFSOutputSummer(ChecksumFileSystem fs, Path file, boolean overwrite, int bufferSize, short replication, long blockSize, Progressable progress)
/*     */       throws IOException
/*     */     {
/* 333 */       super(fs.getBytesPerSum(), 4);
/* 334 */       int bytesPerSum = fs.getBytesPerSum();
/* 335 */       this.datas = fs.getRawFileSystem().create(file, overwrite, bufferSize, replication, blockSize, progress);
/*     */ 
/* 337 */       int sumBufferSize = fs.getSumBufferSize(bytesPerSum, bufferSize);
/* 338 */       this.sums = fs.getRawFileSystem().create(fs.getChecksumFile(file), true, sumBufferSize, replication, blockSize);
/*     */ 
/* 341 */       this.sums.write(ChecksumFileSystem.CHECKSUM_VERSION, 0, ChecksumFileSystem.CHECKSUM_VERSION.length);
/* 342 */       this.sums.writeInt(bytesPerSum);
/*     */     }
/*     */ 
/*     */     public void close() throws IOException {
/* 346 */       flushBuffer();
/* 347 */       this.sums.close();
/* 348 */       this.datas.close();
/*     */     }
/*     */ 
/*     */     protected void writeChunk(byte[] b, int offset, int len, byte[] checksum)
/*     */       throws IOException
/*     */     {
/* 354 */       this.datas.write(b, offset, len);
/* 355 */       this.sums.write(checksum);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ChecksumFSInputChecker extends FSInputChecker
/*     */   {
/* 106 */     public static final Log LOG = LogFactory.getLog(FSInputChecker.class);
/*     */     private ChecksumFileSystem fs;
/*     */     private FSDataInputStream datas;
/*     */     private FSDataInputStream sums;
/*     */     private static final int HEADER_LENGTH = 8;
/* 115 */     private int bytesPerSum = 1;
/* 116 */     private long fileLen = -1L;
/*     */ 
/*     */     public ChecksumFSInputChecker(ChecksumFileSystem fs, Path file) throws IOException
/*     */     {
/* 120 */       this(fs, file, fs.getConf().getInt("io.file.buffer.size", 4096));
/*     */     }
/*     */ 
/*     */     public ChecksumFSInputChecker(ChecksumFileSystem fs, Path file, int bufferSize) throws IOException
/*     */     {
/* 125 */       super(fs.getFileStatus(file).getReplication());
/* 126 */       this.datas = fs.getRawFileSystem().open(file, bufferSize);
/* 127 */       this.fs = fs;
/* 128 */       Path sumFile = fs.getChecksumFile(file);
/*     */       try {
/* 130 */         int sumBufferSize = fs.getSumBufferSize(fs.getBytesPerSum(), bufferSize);
/* 131 */         this.sums = fs.getRawFileSystem().open(sumFile, sumBufferSize);
/*     */ 
/* 133 */         byte[] version = new byte[ChecksumFileSystem.CHECKSUM_VERSION.length];
/* 134 */         this.sums.readFully(version);
/* 135 */         if (!Arrays.equals(version, ChecksumFileSystem.CHECKSUM_VERSION))
/* 136 */           throw new IOException("Not a checksum file: " + sumFile);
/* 137 */         this.bytesPerSum = this.sums.readInt();
/* 138 */         set(fs.verifyChecksum, new PureJavaCrc32(), this.bytesPerSum, 4);
/*     */       } catch (FileNotFoundException e) {
/* 140 */         set(fs.verifyChecksum, null, 1, 0);
/*     */       } catch (IOException e) {
/* 142 */         LOG.warn("Problem opening checksum file: " + file + ".  Ignoring exception: " + StringUtils.stringifyException(e));
/*     */ 
/* 145 */         set(fs.verifyChecksum, null, 1, 0);
/*     */       }
/*     */     }
/*     */ 
/*     */     private long getChecksumFilePos(long dataPos) {
/* 150 */       return 8L + 4L * (dataPos / this.bytesPerSum);
/*     */     }
/*     */ 
/*     */     protected long getChunkPosition(long dataPos) {
/* 154 */       return dataPos / this.bytesPerSum * this.bytesPerSum;
/*     */     }
/*     */ 
/*     */     public int available() throws IOException {
/* 158 */       return this.datas.available() + super.available();
/*     */     }
/*     */ 
/*     */     public int read(long position, byte[] b, int off, int len)
/*     */       throws IOException
/*     */     {
/* 164 */       if ((off | len | off + len | b.length - (off + len)) < 0)
/* 165 */         throw new IndexOutOfBoundsException();
/* 166 */       if (len == 0) {
/* 167 */         return 0;
/*     */       }
/* 169 */       if (position < 0L) {
/* 170 */         throw new IllegalArgumentException("Parameter position can not to be negative");
/*     */       }
/*     */ 
/* 174 */       ChecksumFSInputChecker checker = new ChecksumFSInputChecker(this.fs, this.file);
/* 175 */       checker.seek(position);
/* 176 */       int nread = checker.read(b, off, len);
/* 177 */       checker.close();
/* 178 */       return nread;
/*     */     }
/*     */ 
/*     */     public void close() throws IOException {
/* 182 */       this.datas.close();
/* 183 */       if (this.sums != null) {
/* 184 */         this.sums.close();
/*     */       }
/* 186 */       set(this.fs.verifyChecksum, null, 1, 0);
/*     */     }
/*     */ 
/*     */     public boolean seekToNewSource(long targetPos)
/*     */       throws IOException
/*     */     {
/* 192 */       long sumsPos = getChecksumFilePos(targetPos);
/* 193 */       this.fs.reportChecksumFailure(this.file, this.datas, targetPos, this.sums, sumsPos);
/* 194 */       boolean newDataSource = this.datas.seekToNewSource(targetPos);
/* 195 */       return (this.sums.seekToNewSource(sumsPos)) || (newDataSource);
/*     */     }
/*     */ 
/*     */     protected int readChunk(long pos, byte[] buf, int offset, int len, byte[] checksum)
/*     */       throws IOException
/*     */     {
/* 201 */       boolean eof = false;
/* 202 */       if (needChecksum()) {
/*     */         try {
/* 204 */           long checksumPos = getChecksumFilePos(pos);
/* 205 */           if (checksumPos != this.sums.getPos()) {
/* 206 */             this.sums.seek(checksumPos);
/*     */           }
/* 208 */           this.sums.readFully(checksum);
/*     */         } catch (EOFException e) {
/* 210 */           eof = true;
/*     */         }
/* 212 */         len = this.bytesPerSum;
/*     */       }
/* 214 */       if (pos != this.datas.getPos()) {
/* 215 */         this.datas.seek(pos);
/*     */       }
/* 217 */       int nread = readFully(this.datas, buf, offset, len);
/* 218 */       if ((eof) && (nread > 0)) {
/* 219 */         throw new ChecksumException("Checksum error: " + this.file + " at " + pos, pos);
/*     */       }
/* 221 */       return nread;
/*     */     }
/*     */ 
/*     */     private long getFileLength() throws IOException
/*     */     {
/* 226 */       if (this.fileLen == -1L) {
/* 227 */         this.fileLen = this.fs.getContentSummary(this.file).getLength();
/*     */       }
/* 229 */       return this.fileLen;
/*     */     }
/*     */ 
/*     */     public synchronized long skip(long n)
/*     */       throws IOException
/*     */     {
/* 247 */       long curPos = getPos();
/* 248 */       long fileLength = getFileLength();
/* 249 */       if (n + curPos > fileLength) {
/* 250 */         n = fileLength - curPos;
/*     */       }
/* 252 */       return super.skip(n);
/*     */     }
/*     */ 
/*     */     public synchronized void seek(long pos)
/*     */       throws IOException
/*     */     {
/* 268 */       if (pos > getFileLength()) {
/* 269 */         throw new IOException("Cannot seek after EOF");
/*     */       }
/* 271 */       super.seek(pos);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.ChecksumFileSystem
 * JD-Core Version:    0.6.1
 */
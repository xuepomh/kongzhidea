package org.apache.hadoop.fs;

import java.io.IOException;

public abstract interface PositionedReadable
{
  public abstract int read(long paramLong, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException;

  public abstract void readFully(long paramLong, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException;

  public abstract void readFully(long paramLong, byte[] paramArrayOfByte)
    throws IOException;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.PositionedReadable
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.fs;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.regex.PatternSyntaxException;
/*    */ 
/*    */ class GlobFilter
/*    */   implements PathFilter
/*    */ {
/* 26 */   private static final PathFilter DEFAULT_FILTER = new PathFilter() {
/*    */     public boolean accept(Path file) {
/* 28 */       return true;
/*    */     } } ;
/*    */ 
/* 32 */   private PathFilter userFilter = DEFAULT_FILTER;
/*    */   private GlobPattern pattern;
/*    */ 
/* 36 */   GlobFilter(String filePattern) throws IOException { init(filePattern, DEFAULT_FILTER); }
/*    */ 
/*    */   GlobFilter(String filePattern, PathFilter filter) throws IOException
/*    */   {
/* 40 */     init(filePattern, filter);
/*    */   }
/*    */ 
/*    */   void init(String filePattern, PathFilter filter) throws IOException {
/*    */     try {
/* 45 */       this.userFilter = filter;
/* 46 */       this.pattern = new GlobPattern(filePattern);
/*    */     }
/*    */     catch (PatternSyntaxException e)
/*    */     {
/* 50 */       throw new IOException("Illegal file pattern: " + e.getMessage(), e);
/*    */     }
/*    */   }
/*    */ 
/*    */   boolean hasPattern() {
/* 55 */     return this.pattern.hasWildcard();
/*    */   }
/*    */ 
/*    */   public boolean accept(Path path) {
/* 59 */     return (this.pattern.matches(path.getName())) && (this.userFilter.accept(path));
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.GlobFilter
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.fs;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import org.apache.hadoop.io.Writable;
/*    */ 
/*    */ public abstract class FileChecksum
/*    */   implements Writable
/*    */ {
/*    */   public abstract String getAlgorithmName();
/*    */ 
/*    */   public abstract int getLength();
/*    */ 
/*    */   public abstract byte[] getBytes();
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 37 */     if (other == this) {
/* 38 */       return true;
/*    */     }
/* 40 */     if ((other == null) || (!(other instanceof FileChecksum))) {
/* 41 */       return false;
/*    */     }
/*    */ 
/* 44 */     FileChecksum that = (FileChecksum)other;
/* 45 */     return (getAlgorithmName().equals(that.getAlgorithmName())) && (Arrays.equals(getBytes(), that.getBytes()));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 51 */     return getAlgorithmName().hashCode() ^ Arrays.hashCode(getBytes());
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.FileChecksum
 * JD-Core Version:    0.6.1
 */
package org.apache.hadoop.fs.s3native;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import org.apache.hadoop.conf.Configuration;

abstract interface NativeFileSystemStore
{
  public abstract void initialize(URI paramURI, Configuration paramConfiguration)
    throws IOException;

  public abstract void storeFile(String paramString, File paramFile, byte[] paramArrayOfByte)
    throws IOException;

  public abstract void storeEmptyFile(String paramString)
    throws IOException;

  public abstract FileMetadata retrieveMetadata(String paramString)
    throws IOException;

  public abstract InputStream retrieve(String paramString)
    throws IOException;

  public abstract InputStream retrieve(String paramString, long paramLong)
    throws IOException;

  public abstract PartialListing list(String paramString, int paramInt)
    throws IOException;

  public abstract PartialListing list(String paramString1, int paramInt, String paramString2, boolean paramBoolean)
    throws IOException;

  public abstract void delete(String paramString)
    throws IOException;

  public abstract void copy(String paramString1, String paramString2)
    throws IOException;

  public abstract void purge(String paramString)
    throws IOException;

  public abstract void dump()
    throws IOException;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.s3native.NativeFileSystemStore
 * JD-Core Version:    0.6.1
 */
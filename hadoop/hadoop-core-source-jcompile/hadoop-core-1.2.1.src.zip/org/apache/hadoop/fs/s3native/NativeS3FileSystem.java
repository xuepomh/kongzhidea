/*     */ package org.apache.hadoop.fs.s3native;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import java.security.DigestOutputStream;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.BufferedFSInputStream;
/*     */ import org.apache.hadoop.fs.FSDataInputStream;
/*     */ import org.apache.hadoop.fs.FSDataOutputStream;
/*     */ import org.apache.hadoop.fs.FSInputStream;
/*     */ import org.apache.hadoop.fs.FileStatus;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.fs.s3.S3Exception;
/*     */ import org.apache.hadoop.io.retry.RetryPolicies;
/*     */ import org.apache.hadoop.io.retry.RetryPolicy;
/*     */ import org.apache.hadoop.io.retry.RetryProxy;
/*     */ import org.apache.hadoop.util.Progressable;
/*     */ 
/*     */ public class NativeS3FileSystem extends FileSystem
/*     */ {
/*  80 */   public static final Log LOG = LogFactory.getLog(NativeS3FileSystem.class);
/*     */   private static final String FOLDER_SUFFIX = "_$folder$";
/*     */   private static final long MAX_S3_FILE_SIZE = 5368709120L;
/*     */   static final String PATH_DELIMITER = "/";
/*     */   private static final int S3_MAX_LISTING_LENGTH = 1000;
/*     */   private URI uri;
/*     */   private NativeFileSystemStore store;
/*     */   private Path workingDir;
/*     */ 
/*     */   public NativeS3FileSystem()
/*     */   {
/*     */   }
/*     */ 
/*     */   public NativeS3FileSystem(NativeFileSystemStore store)
/*     */   {
/* 225 */     this.store = store;
/*     */   }
/*     */ 
/*     */   public void initialize(URI uri, Configuration conf) throws IOException
/*     */   {
/* 230 */     super.initialize(uri, conf);
/* 231 */     if (this.store == null) {
/* 232 */       this.store = createDefaultStore(conf);
/*     */     }
/* 234 */     this.store.initialize(uri, conf);
/* 235 */     setConf(conf);
/* 236 */     this.uri = URI.create(uri.getScheme() + "://" + uri.getAuthority());
/* 237 */     this.workingDir = new Path("/user", System.getProperty("user.name")).makeQualified(this);
/*     */   }
/*     */ 
/*     */   private static NativeFileSystemStore createDefaultStore(Configuration conf)
/*     */   {
/* 242 */     NativeFileSystemStore store = new Jets3tNativeFileSystemStore();
/*     */ 
/* 244 */     RetryPolicy basePolicy = RetryPolicies.retryUpToMaximumCountWithFixedSleep(conf.getInt("fs.s3.maxRetries", 4), conf.getLong("fs.s3.sleepTimeSeconds", 10L), TimeUnit.SECONDS);
/*     */ 
/* 247 */     Map exceptionToPolicyMap = new HashMap();
/*     */ 
/* 249 */     exceptionToPolicyMap.put(IOException.class, basePolicy);
/* 250 */     exceptionToPolicyMap.put(S3Exception.class, basePolicy);
/*     */ 
/* 252 */     RetryPolicy methodPolicy = RetryPolicies.retryByException(RetryPolicies.TRY_ONCE_THEN_FAIL, exceptionToPolicyMap);
/*     */ 
/* 254 */     Map methodNameToPolicyMap = new HashMap();
/*     */ 
/* 256 */     methodNameToPolicyMap.put("storeFile", methodPolicy);
/* 257 */     methodNameToPolicyMap.put("rename", methodPolicy);
/*     */ 
/* 259 */     return (NativeFileSystemStore)RetryProxy.create(NativeFileSystemStore.class, store, methodNameToPolicyMap);
/*     */   }
/*     */ 
/*     */   private static String pathToKey(Path path)
/*     */   {
/* 265 */     if (!path.isAbsolute()) {
/* 266 */       throw new IllegalArgumentException("Path must be absolute: " + path);
/*     */     }
/* 268 */     String ret = path.toUri().getPath().substring(1);
/* 269 */     if ((ret.endsWith("/")) && (ret.indexOf("/") != ret.length() - 1)) {
/* 270 */       ret = ret.substring(0, ret.length() - 1);
/*     */     }
/* 272 */     return ret;
/*     */   }
/*     */ 
/*     */   private static Path keyToPath(String key) {
/* 276 */     return new Path("/" + key);
/*     */   }
/*     */ 
/*     */   private Path makeAbsolute(Path path) {
/* 280 */     if (path.isAbsolute()) {
/* 281 */       return path;
/*     */     }
/* 283 */     return new Path(this.workingDir, path);
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream append(Path f, int bufferSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 290 */     throw new IOException("Not supported");
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream create(Path f, FsPermission permission, boolean overwrite, int bufferSize, short replication, long blockSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 298 */     if ((exists(f)) && (!overwrite)) {
/* 299 */       throw new IOException("File already exists:" + f);
/*     */     }
/* 301 */     Path absolutePath = makeAbsolute(f);
/* 302 */     String key = pathToKey(absolutePath);
/* 303 */     return new FSDataOutputStream(new NativeS3FsOutputStream(getConf(), this.store, key, progress, bufferSize), this.statistics);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public boolean delete(Path path)
/*     */     throws IOException
/*     */   {
/* 310 */     return delete(path, true);
/*     */   }
/*     */ 
/*     */   public boolean delete(Path f, boolean recurse) throws IOException
/*     */   {
/*     */     FileStatus status;
/*     */     try {
/* 317 */       status = getFileStatus(f);
/*     */     } catch (FileNotFoundException e) {
/* 319 */       LOG.debug("Delete called for '" + f + "' but file does not exist, so returning false");
/* 320 */       return false;
/*     */     }
/* 322 */     Path absolutePath = makeAbsolute(f);
/* 323 */     String key = pathToKey(absolutePath);
/* 324 */     if (status.isDir()) {
/* 325 */       if ((!recurse) && (listStatus(f).length > 0)) {
/* 326 */         throw new IOException("Can not delete " + f + " at is a not empty directory and recurse option is false");
/*     */       }
/*     */ 
/* 329 */       createParent(f);
/*     */ 
/* 331 */       LOG.debug("Deleting directory '" + f + "'");
/* 332 */       String priorLastKey = null;
/*     */       do {
/* 334 */         PartialListing listing = this.store.list(key, 1000, priorLastKey, true);
/* 335 */         for (FileMetadata file : listing.getFiles()) {
/* 336 */           this.store.delete(file.getKey());
/*     */         }
/* 338 */         priorLastKey = listing.getPriorLastKey();
/* 339 */       }while (priorLastKey != null);
/*     */       try
/*     */       {
/* 342 */         this.store.delete(key + "_$folder$");
/*     */       } catch (FileNotFoundException e) {
/*     */       }
/*     */     }
/*     */     else {
/* 347 */       LOG.debug("Deleting file '" + f + "'");
/* 348 */       createParent(f);
/* 349 */       this.store.delete(key);
/*     */     }
/* 351 */     return true;
/*     */   }
/*     */ 
/*     */   public FileStatus getFileStatus(Path f) throws IOException
/*     */   {
/* 356 */     Path absolutePath = makeAbsolute(f);
/* 357 */     String key = pathToKey(absolutePath);
/*     */ 
/* 359 */     if (key.length() == 0) {
/* 360 */       return newDirectory(absolutePath);
/*     */     }
/*     */ 
/* 363 */     LOG.debug("getFileStatus retrieving metadata for key '" + key + "'");
/* 364 */     FileMetadata meta = this.store.retrieveMetadata(key);
/* 365 */     if (meta != null) {
/* 366 */       LOG.debug("getFileStatus returning 'file' for key '" + key + "'");
/* 367 */       return newFile(meta, absolutePath);
/*     */     }
/* 369 */     if (this.store.retrieveMetadata(key + "_$folder$") != null) {
/* 370 */       LOG.debug("getFileStatus returning 'directory' for key '" + key + "' as '" + key + "_$folder$" + "' exists");
/*     */ 
/* 372 */       return newDirectory(absolutePath);
/*     */     }
/*     */ 
/* 375 */     LOG.debug("getFileStatus listing key '" + key + "'");
/* 376 */     PartialListing listing = this.store.list(key, 1);
/* 377 */     if ((listing.getFiles().length > 0) || (listing.getCommonPrefixes().length > 0))
/*     */     {
/* 379 */       LOG.debug("getFileStatus returning 'directory' for key '" + key + "' as it has contents");
/* 380 */       return newDirectory(absolutePath);
/*     */     }
/*     */ 
/* 383 */     LOG.debug("getFileStatus could not find key '" + key + "'");
/* 384 */     throw new FileNotFoundException("No such file or directory '" + absolutePath + "'");
/*     */   }
/*     */ 
/*     */   public URI getUri()
/*     */   {
/* 389 */     return this.uri;
/*     */   }
/*     */ 
/*     */   public FileStatus[] listStatus(Path f)
/*     */     throws IOException
/*     */   {
/* 403 */     Path absolutePath = makeAbsolute(f);
/* 404 */     String key = pathToKey(absolutePath);
/*     */ 
/* 406 */     if (key.length() > 0) {
/* 407 */       FileMetadata meta = this.store.retrieveMetadata(key);
/* 408 */       if (meta != null) {
/* 409 */         return new FileStatus[] { newFile(meta, absolutePath) };
/*     */       }
/*     */     }
/*     */ 
/* 413 */     URI pathUri = absolutePath.toUri();
/* 414 */     Set status = new TreeSet();
/* 415 */     String priorLastKey = null;
/*     */     do {
/* 417 */       PartialListing listing = this.store.list(key, 1000, priorLastKey, false);
/* 418 */       for (FileMetadata fileMetadata : listing.getFiles()) {
/* 419 */         Path subpath = keyToPath(fileMetadata.getKey());
/* 420 */         String relativePath = pathUri.relativize(subpath.toUri()).getPath();
/*     */ 
/* 422 */         if (!fileMetadata.getKey().equals(key + "/"))
/*     */         {
/* 425 */           if (relativePath.endsWith("_$folder$")) {
/* 426 */             status.add(newDirectory(new Path(absolutePath, relativePath.substring(0, relativePath.indexOf("_$folder$")))));
/*     */           }
/*     */           else
/*     */           {
/* 431 */             status.add(newFile(fileMetadata, subpath));
/*     */           }
/*     */         }
/*     */       }
/* 434 */       for (String commonPrefix : listing.getCommonPrefixes()) {
/* 435 */         Path subpath = keyToPath(commonPrefix);
/* 436 */         String relativePath = pathUri.relativize(subpath.toUri()).getPath();
/* 437 */         status.add(newDirectory(new Path(absolutePath, relativePath)));
/*     */       }
/* 439 */       priorLastKey = listing.getPriorLastKey();
/* 440 */     }while (priorLastKey != null);
/*     */ 
/* 442 */     if ((status.isEmpty()) && (this.store.retrieveMetadata(key + "_$folder$") == null))
/*     */     {
/* 444 */       return null;
/*     */     }
/*     */ 
/* 447 */     return (FileStatus[])status.toArray(new FileStatus[status.size()]);
/*     */   }
/*     */ 
/*     */   private FileStatus newFile(FileMetadata meta, Path path) {
/* 451 */     return new FileStatus(meta.getLength(), false, 1, 5368709120L, meta.getLastModified(), path.makeQualified(this));
/*     */   }
/*     */ 
/*     */   private FileStatus newDirectory(Path path)
/*     */   {
/* 456 */     return new FileStatus(0L, true, 1, 5368709120L, 0L, path.makeQualified(this));
/*     */   }
/*     */ 
/*     */   public boolean mkdirs(Path f, FsPermission permission)
/*     */     throws IOException
/*     */   {
/* 462 */     Path absolutePath = makeAbsolute(f);
/* 463 */     List paths = new ArrayList();
/*     */     do {
/* 465 */       paths.add(0, absolutePath);
/* 466 */       absolutePath = absolutePath.getParent();
/* 467 */     }while (absolutePath != null);
/*     */ 
/* 469 */     boolean result = true;
/* 470 */     for (Path path : paths) {
/* 471 */       result &= mkdir(path);
/*     */     }
/* 473 */     return result;
/*     */   }
/*     */ 
/*     */   private boolean mkdir(Path f) throws IOException {
/*     */     try {
/* 478 */       FileStatus fileStatus = getFileStatus(f);
/* 479 */       if (!fileStatus.isDir()) {
/* 480 */         throw new IOException(String.format("Can't make directory for path '%s' since it is a file.", new Object[] { f }));
/*     */       }
/*     */     }
/*     */     catch (FileNotFoundException e)
/*     */     {
/* 485 */       LOG.debug("Making dir '" + f + "' in S3");
/* 486 */       String key = pathToKey(f) + "_$folder$";
/* 487 */       this.store.storeEmptyFile(key);
/*     */     }
/* 489 */     return true;
/*     */   }
/*     */ 
/*     */   public FSDataInputStream open(Path f, int bufferSize) throws IOException
/*     */   {
/* 494 */     FileStatus fs = getFileStatus(f);
/* 495 */     if (fs.isDir()) {
/* 496 */       throw new IOException("'" + f + "' is a directory");
/*     */     }
/* 498 */     LOG.info("Opening '" + f + "' for reading");
/* 499 */     Path absolutePath = makeAbsolute(f);
/* 500 */     String key = pathToKey(absolutePath);
/* 501 */     return new FSDataInputStream(new BufferedFSInputStream(new NativeS3FsInputStream(this.store.retrieve(key), key), bufferSize));
/*     */   }
/*     */ 
/*     */   private void createParent(Path path)
/*     */     throws IOException
/*     */   {
/* 508 */     Path parent = path.getParent();
/* 509 */     if (parent != null) {
/* 510 */       String key = pathToKey(makeAbsolute(parent));
/* 511 */       if (key.length() > 0)
/* 512 */         this.store.storeEmptyFile(key + "_$folder$");
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean rename(Path src, Path dst)
/*     */     throws IOException
/*     */   {
/* 521 */     String srcKey = pathToKey(makeAbsolute(src));
/*     */ 
/* 523 */     if (srcKey.length() == 0)
/*     */     {
/* 525 */       return false;
/*     */     }
/*     */ 
/* 528 */     String debugPreamble = "Renaming '" + src + "' to '" + dst + "' - ";
/*     */     String dstKey;
/*     */     try
/*     */     {
/* 533 */       boolean dstIsFile = !getFileStatus(dst).isDir();
/* 534 */       if (dstIsFile) {
/* 535 */         LOG.debug(debugPreamble + "returning false as dst is an already existing file");
/* 536 */         return false;
/*     */       }
/* 538 */       LOG.debug(debugPreamble + "using dst as output directory");
/* 539 */       dstKey = pathToKey(makeAbsolute(new Path(dst, src.getName())));
/*     */     }
/*     */     catch (FileNotFoundException e) {
/* 542 */       LOG.debug(debugPreamble + "using dst as output destination");
/* 543 */       dstKey = pathToKey(makeAbsolute(dst));
/*     */       try {
/* 545 */         if (!getFileStatus(dst.getParent()).isDir()) {
/* 546 */           LOG.debug(debugPreamble + "returning false as dst parent exists and is a file");
/* 547 */           return false;
/*     */         }
/*     */       } catch (FileNotFoundException ex) {
/* 550 */         LOG.debug(debugPreamble + "returning false as dst parent does not exist");
/* 551 */         return false;
/*     */       }
/*     */     }
/*     */     boolean srcIsFile;
/*     */     try
/*     */     {
/* 557 */       srcIsFile = !getFileStatus(src).isDir();
/*     */     } catch (FileNotFoundException e) {
/* 559 */       LOG.debug(debugPreamble + "returning false as src does not exist");
/* 560 */       return false;
/*     */     }
/* 562 */     if (srcIsFile) {
/* 563 */       LOG.debug(debugPreamble + "src is file, so doing copy then delete in S3");
/* 564 */       this.store.copy(srcKey, dstKey);
/* 565 */       this.store.delete(srcKey);
/*     */     } else {
/* 567 */       LOG.debug(debugPreamble + "src is directory, so copying contents");
/* 568 */       this.store.storeEmptyFile(dstKey + "_$folder$");
/*     */ 
/* 570 */       List keysToDelete = new ArrayList();
/* 571 */       String priorLastKey = null;
/*     */       do {
/* 573 */         PartialListing listing = this.store.list(srcKey, 1000, priorLastKey, true);
/* 574 */         for (FileMetadata file : listing.getFiles()) {
/* 575 */           keysToDelete.add(file.getKey());
/* 576 */           this.store.copy(file.getKey(), dstKey + file.getKey().substring(srcKey.length()));
/*     */         }
/* 578 */         priorLastKey = listing.getPriorLastKey();
/* 579 */       }while (priorLastKey != null);
/*     */ 
/* 581 */       LOG.debug(debugPreamble + "all files in src copied, now removing src files");
/* 582 */       for (String key : keysToDelete) {
/* 583 */         this.store.delete(key);
/*     */       }
/*     */       try
/*     */       {
/* 587 */         this.store.delete(srcKey + "_$folder$");
/*     */       }
/*     */       catch (FileNotFoundException e) {
/*     */       }
/* 591 */       LOG.debug(debugPreamble + "done");
/*     */     }
/*     */ 
/* 594 */     return true;
/*     */   }
/*     */ 
/*     */   public void setWorkingDirectory(Path newDir)
/*     */   {
/* 602 */     this.workingDir = newDir;
/*     */   }
/*     */ 
/*     */   public Path getWorkingDirectory()
/*     */   {
/* 607 */     return this.workingDir;
/*     */   }
/*     */ 
/*     */   private class NativeS3FsOutputStream extends OutputStream
/*     */   {
/*     */     private Configuration conf;
/*     */     private String key;
/*     */     private File backupFile;
/*     */     private OutputStream backupStream;
/*     */     private MessageDigest digest;
/*     */     private boolean closed;
/*     */ 
/*     */     public NativeS3FsOutputStream(Configuration conf, NativeFileSystemStore store, String key, Progressable progress, int bufferSize)
/*     */       throws IOException
/*     */     {
/* 152 */       this.conf = conf;
/* 153 */       this.key = key;
/* 154 */       this.backupFile = newBackupFile();
/* 155 */       NativeS3FileSystem.LOG.info("OutputStream for key '" + key + "' writing to tempfile '" + this.backupFile + "'");
/*     */       try {
/* 157 */         this.digest = MessageDigest.getInstance("MD5");
/* 158 */         this.backupStream = new BufferedOutputStream(new DigestOutputStream(new FileOutputStream(this.backupFile), this.digest));
/*     */       }
/*     */       catch (NoSuchAlgorithmException e) {
/* 161 */         NativeS3FileSystem.LOG.warn("Cannot load MD5 digest algorithm,skipping message integrity check.", e);
/*     */ 
/* 163 */         this.backupStream = new BufferedOutputStream(new FileOutputStream(this.backupFile));
/*     */       }
/*     */     }
/*     */ 
/*     */     private File newBackupFile() throws IOException
/*     */     {
/* 169 */       File dir = new File(this.conf.get("fs.s3.buffer.dir"));
/* 170 */       if ((!dir.mkdirs()) && (!dir.exists())) {
/* 171 */         throw new IOException("Cannot create S3 buffer directory: " + dir);
/*     */       }
/* 173 */       File result = File.createTempFile("output-", ".tmp", dir);
/* 174 */       result.deleteOnExit();
/* 175 */       return result;
/*     */     }
/*     */ 
/*     */     public void flush() throws IOException
/*     */     {
/* 180 */       this.backupStream.flush();
/*     */     }
/*     */ 
/*     */     public synchronized void close() throws IOException
/*     */     {
/* 185 */       if (this.closed) {
/* 186 */         return;
/*     */       }
/*     */ 
/* 189 */       this.backupStream.close();
/* 190 */       NativeS3FileSystem.LOG.info("OutputStream for key '" + this.key + "' closed. Now beginning upload");
/*     */       try
/*     */       {
/* 193 */         byte[] md5Hash = this.digest == null ? null : this.digest.digest();
/* 194 */         NativeS3FileSystem.this.store.storeFile(this.key, this.backupFile, md5Hash);
/*     */       } finally {
/* 196 */         if (!this.backupFile.delete()) {
/* 197 */           NativeS3FileSystem.LOG.warn("Could not delete temporary s3n file: " + this.backupFile);
/*     */         }
/* 199 */         super.close();
/* 200 */         this.closed = true;
/*     */       }
/* 202 */       NativeS3FileSystem.LOG.info("OutputStream for key '" + this.key + "' upload complete");
/*     */     }
/*     */ 
/*     */     public void write(int b) throws IOException
/*     */     {
/* 207 */       this.backupStream.write(b);
/*     */     }
/*     */ 
/*     */     public void write(byte[] b, int off, int len) throws IOException
/*     */     {
/* 212 */       this.backupStream.write(b, off, len);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class NativeS3FsInputStream extends FSInputStream
/*     */   {
/*     */     private InputStream in;
/*     */     private final String key;
/*  92 */     private long pos = 0L;
/*     */ 
/*     */     public NativeS3FsInputStream(InputStream in, String key) {
/*  95 */       this.in = in;
/*  96 */       this.key = key;
/*     */     }
/*     */ 
/*     */     public synchronized int read() throws IOException
/*     */     {
/* 101 */       int result = this.in.read();
/* 102 */       if (result != -1) {
/* 103 */         this.pos += 1L;
/*     */       }
/* 105 */       return result;
/*     */     }
/*     */ 
/*     */     public synchronized int read(byte[] b, int off, int len)
/*     */       throws IOException
/*     */     {
/* 111 */       int result = this.in.read(b, off, len);
/* 112 */       if (result > 0) {
/* 113 */         this.pos += result;
/*     */       }
/* 115 */       return result;
/*     */     }
/*     */ 
/*     */     public void close() throws IOException
/*     */     {
/* 120 */       this.in.close();
/*     */     }
/*     */ 
/*     */     public synchronized void seek(long pos) throws IOException
/*     */     {
/* 125 */       this.in.close();
/* 126 */       NativeS3FileSystem.LOG.info("Opening key '" + this.key + "' for reading at position '" + pos + "'");
/* 127 */       this.in = NativeS3FileSystem.this.store.retrieve(this.key, pos);
/* 128 */       this.pos = pos;
/*     */     }
/*     */ 
/*     */     public synchronized long getPos() throws IOException {
/* 132 */       return this.pos;
/*     */     }
/*     */ 
/*     */     public boolean seekToNewSource(long targetPos) throws IOException {
/* 136 */       return false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.s3native.NativeS3FileSystem
 * JD-Core Version:    0.6.1
 */
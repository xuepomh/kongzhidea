/*     */ package org.apache.hadoop.fs.s3native;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URI;
/*     */ import java.util.Date;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.s3.S3Credentials;
/*     */ import org.apache.hadoop.fs.s3.S3Exception;
/*     */ import org.jets3t.service.S3ObjectsChunk;
/*     */ import org.jets3t.service.S3Service;
/*     */ import org.jets3t.service.S3ServiceException;
/*     */ import org.jets3t.service.impl.rest.httpclient.RestS3Service;
/*     */ import org.jets3t.service.model.S3Bucket;
/*     */ import org.jets3t.service.model.S3Object;
/*     */ import org.jets3t.service.security.AWSCredentials;
/*     */ 
/*     */ class Jets3tNativeFileSystemStore
/*     */   implements NativeFileSystemStore
/*     */ {
/*     */   private S3Service s3Service;
/*     */   private S3Bucket bucket;
/*     */ 
/*     */   public void initialize(URI uri, Configuration conf)
/*     */     throws IOException
/*     */   {
/*  49 */     S3Credentials s3Credentials = new S3Credentials();
/*  50 */     s3Credentials.initialize(uri, conf);
/*     */     try {
/*  52 */       AWSCredentials awsCredentials = new AWSCredentials(s3Credentials.getAccessKey(), s3Credentials.getSecretAccessKey());
/*     */ 
/*  55 */       this.s3Service = new RestS3Service(awsCredentials);
/*     */     } catch (S3ServiceException e) {
/*  57 */       handleServiceException(e);
/*     */     }
/*  59 */     this.bucket = new S3Bucket(uri.getHost());
/*     */   }
/*     */ 
/*     */   public void storeFile(String key, File file, byte[] md5Hash)
/*     */     throws IOException
/*     */   {
/*  65 */     BufferedInputStream in = null;
/*     */     try {
/*  67 */       in = new BufferedInputStream(new FileInputStream(file));
/*  68 */       S3Object object = new S3Object(key);
/*  69 */       object.setDataInputStream(in);
/*  70 */       object.setContentType("binary/octet-stream");
/*  71 */       object.setContentLength(file.length());
/*  72 */       if (md5Hash != null) {
/*  73 */         object.setMd5Hash(md5Hash);
/*     */       }
/*  75 */       this.s3Service.putObject(this.bucket, object);
/*     */     } catch (S3ServiceException e) {
/*  77 */       handleServiceException(e);
/*     */     } finally {
/*  79 */       if (in != null)
/*     */         try {
/*  81 */           in.close();
/*     */         }
/*     */         catch (IOException e)
/*     */         {
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void storeEmptyFile(String key) throws IOException {
/*     */     try {
/*  91 */       S3Object object = new S3Object(key);
/*  92 */       object.setDataInputStream(new ByteArrayInputStream(new byte[0]));
/*  93 */       object.setContentType("binary/octet-stream");
/*  94 */       object.setContentLength(0L);
/*  95 */       this.s3Service.putObject(this.bucket, object);
/*     */     } catch (S3ServiceException e) {
/*  97 */       handleServiceException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public FileMetadata retrieveMetadata(String key) throws IOException {
/*     */     try {
/* 103 */       S3Object object = this.s3Service.getObjectDetails(this.bucket, key);
/* 104 */       return new FileMetadata(key, object.getContentLength(), object.getLastModifiedDate().getTime());
/*     */     }
/*     */     catch (S3ServiceException e)
/*     */     {
/* 108 */       if (e.getMessage().contains("ResponseCode=404")) {
/* 109 */         return null;
/*     */       }
/* 111 */       handleServiceException(e);
/* 112 */     }return null;
/*     */   }
/*     */ 
/*     */   public InputStream retrieve(String key) throws IOException
/*     */   {
/*     */     try {
/* 118 */       S3Object object = this.s3Service.getObject(this.bucket, key);
/* 119 */       return object.getDataInputStream();
/*     */     } catch (S3ServiceException e) {
/* 121 */       handleServiceException(key, e);
/* 122 */     }return null;
/*     */   }
/*     */ 
/*     */   public InputStream retrieve(String key, long byteRangeStart) throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 129 */       S3Object object = this.s3Service.getObject(this.bucket, key, null, null, null, null, Long.valueOf(byteRangeStart), null);
/*     */ 
/* 131 */       return object.getDataInputStream();
/*     */     } catch (S3ServiceException e) {
/* 133 */       handleServiceException(key, e);
/* 134 */     }return null;
/*     */   }
/*     */ 
/*     */   public PartialListing list(String prefix, int maxListingLength)
/*     */     throws IOException
/*     */   {
/* 140 */     return list(prefix, maxListingLength, null, false);
/*     */   }
/*     */ 
/*     */   public PartialListing list(String prefix, int maxListingLength, String priorLastKey, boolean recurse)
/*     */     throws IOException
/*     */   {
/* 146 */     return list(prefix, recurse ? null : "/", maxListingLength, priorLastKey);
/*     */   }
/*     */ 
/*     */   private PartialListing list(String prefix, String delimiter, int maxListingLength, String priorLastKey) throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 153 */       if ((prefix.length() > 0) && (!prefix.endsWith("/"))) {
/* 154 */         prefix = new StringBuilder().append(prefix).append("/").toString();
/*     */       }
/* 156 */       S3ObjectsChunk chunk = this.s3Service.listObjectsChunked(this.bucket.getName(), prefix, delimiter, maxListingLength, priorLastKey);
/*     */ 
/* 159 */       FileMetadata[] fileMetadata = new FileMetadata[chunk.getObjects().length];
/*     */ 
/* 161 */       for (int i = 0; i < fileMetadata.length; i++) {
/* 162 */         S3Object object = chunk.getObjects()[i];
/* 163 */         fileMetadata[i] = new FileMetadata(object.getKey(), object.getContentLength(), object.getLastModifiedDate().getTime());
/*     */       }
/*     */ 
/* 166 */       return new PartialListing(chunk.getPriorLastKey(), fileMetadata, chunk.getCommonPrefixes());
/*     */     }
/*     */     catch (S3ServiceException e) {
/* 169 */       handleServiceException(e);
/* 170 */     }return null;
/*     */   }
/*     */ 
/*     */   public void delete(String key) throws IOException
/*     */   {
/*     */     try {
/* 176 */       this.s3Service.deleteObject(this.bucket, key);
/*     */     } catch (S3ServiceException e) {
/* 178 */       handleServiceException(key, e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void copy(String srcKey, String dstKey) throws IOException {
/*     */     try {
/* 184 */       this.s3Service.copyObject(this.bucket.getName(), srcKey, this.bucket.getName(), new S3Object(dstKey), false);
/*     */     }
/*     */     catch (S3ServiceException e) {
/* 187 */       handleServiceException(srcKey, e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void purge(String prefix) throws IOException {
/*     */     try {
/* 193 */       S3Object[] objects = this.s3Service.listObjects(this.bucket, prefix, null);
/* 194 */       for (S3Object object : objects)
/* 195 */         this.s3Service.deleteObject(this.bucket, object.getKey());
/*     */     }
/*     */     catch (S3ServiceException e) {
/* 198 */       handleServiceException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void dump() throws IOException {
/* 203 */     StringBuilder sb = new StringBuilder("S3 Native Filesystem, ");
/* 204 */     sb.append(this.bucket.getName()).append("\n");
/*     */     try {
/* 206 */       S3Object[] objects = this.s3Service.listObjects(this.bucket);
/* 207 */       for (S3Object object : objects)
/* 208 */         sb.append(object.getKey()).append("\n");
/*     */     }
/*     */     catch (S3ServiceException e) {
/* 211 */       handleServiceException(e);
/*     */     }
/* 213 */     System.out.println(sb);
/*     */   }
/*     */ 
/*     */   private void handleServiceException(String key, S3ServiceException e) throws IOException {
/* 217 */     if ("NoSuchKey".equals(e.getS3ErrorCode())) {
/* 218 */       throw new FileNotFoundException(new StringBuilder().append("Key '").append(key).append("' does not exist in S3").toString());
/*     */     }
/* 220 */     handleServiceException(e);
/*     */   }
/*     */ 
/*     */   private void handleServiceException(S3ServiceException e) throws IOException
/*     */   {
/* 225 */     if ((e.getCause() instanceof IOException)) {
/* 226 */       throw ((IOException)e.getCause());
/*     */     }
/*     */ 
/* 229 */     throw new S3Exception(e);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.s3native.Jets3tNativeFileSystemStore
 * JD-Core Version:    0.6.1
 */
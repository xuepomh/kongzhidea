/*    */ package org.apache.hadoop.fs.s3native;
/*    */ 
/*    */ class PartialListing
/*    */ {
/*    */   private final String priorLastKey;
/*    */   private final FileMetadata[] files;
/*    */   private final String[] commonPrefixes;
/*    */ 
/*    */   public PartialListing(String priorLastKey, FileMetadata[] files, String[] commonPrefixes)
/*    */   {
/* 42 */     this.priorLastKey = priorLastKey;
/* 43 */     this.files = files;
/* 44 */     this.commonPrefixes = commonPrefixes;
/*    */   }
/*    */ 
/*    */   public FileMetadata[] getFiles() {
/* 48 */     return this.files;
/*    */   }
/*    */ 
/*    */   public String[] getCommonPrefixes() {
/* 52 */     return this.commonPrefixes;
/*    */   }
/*    */ 
/*    */   public String getPriorLastKey() {
/* 56 */     return this.priorLastKey;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.s3native.PartialListing
 * JD-Core Version:    0.6.1
 */
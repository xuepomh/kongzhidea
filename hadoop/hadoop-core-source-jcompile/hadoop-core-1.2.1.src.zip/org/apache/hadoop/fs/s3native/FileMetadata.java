/*    */ package org.apache.hadoop.fs.s3native;
/*    */ 
/*    */ class FileMetadata
/*    */ {
/*    */   private final String key;
/*    */   private final long length;
/*    */   private final long lastModified;
/*    */ 
/*    */   public FileMetadata(String key, long length, long lastModified)
/*    */   {
/* 32 */     this.key = key;
/* 33 */     this.length = length;
/* 34 */     this.lastModified = lastModified;
/*    */   }
/*    */ 
/*    */   public String getKey() {
/* 38 */     return this.key;
/*    */   }
/*    */ 
/*    */   public long getLength() {
/* 42 */     return this.length;
/*    */   }
/*    */ 
/*    */   public long getLastModified() {
/* 46 */     return this.lastModified;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 51 */     return "FileMetadata[" + this.key + ", " + this.length + ", " + this.lastModified + "]";
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.s3native.FileMetadata
 * JD-Core Version:    0.6.1
 */
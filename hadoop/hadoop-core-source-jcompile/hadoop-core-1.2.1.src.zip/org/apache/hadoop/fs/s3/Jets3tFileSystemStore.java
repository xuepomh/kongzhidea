/*     */ package org.apache.hadoop.fs.s3;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URI;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.jets3t.service.S3Service;
/*     */ import org.jets3t.service.S3ServiceException;
/*     */ import org.jets3t.service.impl.rest.httpclient.RestS3Service;
/*     */ import org.jets3t.service.model.S3Bucket;
/*     */ import org.jets3t.service.model.S3Object;
/*     */ import org.jets3t.service.security.AWSCredentials;
/*     */ 
/*     */ class Jets3tFileSystemStore
/*     */   implements FileSystemStore
/*     */ {
/*     */   private static final String FILE_SYSTEM_NAME = "fs";
/*     */   private static final String FILE_SYSTEM_VALUE = "Hadoop";
/*     */   private static final String FILE_SYSTEM_TYPE_NAME = "fs-type";
/*     */   private static final String FILE_SYSTEM_TYPE_VALUE = "block";
/*     */   private static final String FILE_SYSTEM_VERSION_NAME = "fs-version";
/*     */   private static final String FILE_SYSTEM_VERSION_VALUE = "1";
/*  57 */   private static final Map<String, String> METADATA = new HashMap();
/*     */   private static final String PATH_DELIMITER = "/";
/*     */   private static final String BLOCK_PREFIX = "block_";
/*     */   private Configuration conf;
/*     */   private S3Service s3Service;
/*     */   private S3Bucket bucket;
/*     */   private int bufferSize;
/*     */ 
/*     */   public void initialize(URI uri, Configuration conf)
/*     */     throws IOException
/*     */   {
/*  79 */     this.conf = conf;
/*     */ 
/*  81 */     S3Credentials s3Credentials = new S3Credentials();
/*  82 */     s3Credentials.initialize(uri, conf);
/*     */     try {
/*  84 */       AWSCredentials awsCredentials = new AWSCredentials(s3Credentials.getAccessKey(), s3Credentials.getSecretAccessKey());
/*     */ 
/*  87 */       this.s3Service = new RestS3Service(awsCredentials);
/*     */     } catch (S3ServiceException e) {
/*  89 */       if ((e.getCause() instanceof IOException)) {
/*  90 */         throw ((IOException)e.getCause());
/*     */       }
/*  92 */       throw new S3Exception(e);
/*     */     }
/*  94 */     this.bucket = new S3Bucket(uri.getHost());
/*     */ 
/*  96 */     this.bufferSize = conf.getInt("io.file.buffer.size", 4096);
/*     */   }
/*     */ 
/*     */   public String getVersion() throws IOException {
/* 100 */     return "1";
/*     */   }
/*     */ 
/*     */   private void delete(String key) throws IOException {
/*     */     try {
/* 105 */       this.s3Service.deleteObject(this.bucket, key);
/*     */     } catch (S3ServiceException e) {
/* 107 */       if ((e.getCause() instanceof IOException)) {
/* 108 */         throw ((IOException)e.getCause());
/*     */       }
/* 110 */       throw new S3Exception(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteINode(Path path) throws IOException {
/* 115 */     delete(pathToKey(path));
/*     */   }
/*     */ 
/*     */   public void deleteBlock(Block block) throws IOException {
/* 119 */     delete(blockToKey(block));
/*     */   }
/*     */ 
/*     */   public boolean inodeExists(Path path) throws IOException {
/* 123 */     InputStream in = get(pathToKey(path), true);
/* 124 */     if (in == null) {
/* 125 */       return false;
/*     */     }
/* 127 */     in.close();
/* 128 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean blockExists(long blockId) throws IOException {
/* 132 */     InputStream in = get(blockToKey(blockId), false);
/* 133 */     if (in == null) {
/* 134 */       return false;
/*     */     }
/* 136 */     in.close();
/* 137 */     return true;
/*     */   }
/*     */ 
/*     */   private InputStream get(String key, boolean checkMetadata) throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 144 */       S3Object object = this.s3Service.getObject(this.bucket, key);
/* 145 */       if (checkMetadata) {
/* 146 */         checkMetadata(object);
/*     */       }
/* 148 */       return object.getDataInputStream();
/*     */     } catch (S3ServiceException e) {
/* 150 */       if ("NoSuchKey".equals(e.getS3ErrorCode())) {
/* 151 */         return null;
/*     */       }
/* 153 */       if ((e.getCause() instanceof IOException)) {
/* 154 */         throw ((IOException)e.getCause());
/*     */       }
/* 156 */       throw new S3Exception(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private InputStream get(String key, long byteRangeStart) throws IOException {
/*     */     try {
/* 162 */       S3Object object = this.s3Service.getObject(this.bucket, key, null, null, null, null, Long.valueOf(byteRangeStart), null);
/*     */ 
/* 164 */       return object.getDataInputStream();
/*     */     } catch (S3ServiceException e) {
/* 166 */       if ("NoSuchKey".equals(e.getS3ErrorCode())) {
/* 167 */         return null;
/*     */       }
/* 169 */       if ((e.getCause() instanceof IOException)) {
/* 170 */         throw ((IOException)e.getCause());
/*     */       }
/* 172 */       throw new S3Exception(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkMetadata(S3Object object)
/*     */     throws S3FileSystemException, S3ServiceException
/*     */   {
/* 179 */     String name = (String)object.getMetadata("fs");
/* 180 */     if (!"Hadoop".equals(name)) {
/* 181 */       throw new S3FileSystemException("Not a Hadoop S3 file.");
/*     */     }
/* 183 */     String type = (String)object.getMetadata("fs-type");
/* 184 */     if (!"block".equals(type)) {
/* 185 */       throw new S3FileSystemException("Not a block file.");
/*     */     }
/* 187 */     String dataVersion = (String)object.getMetadata("fs-version");
/* 188 */     if (!"1".equals(dataVersion))
/* 189 */       throw new VersionMismatchException("1", dataVersion);
/*     */   }
/*     */ 
/*     */   public INode retrieveINode(Path path)
/*     */     throws IOException
/*     */   {
/* 195 */     return INode.deserialize(get(pathToKey(path), true));
/*     */   }
/*     */ 
/*     */   public File retrieveBlock(Block block, long byteRangeStart) throws IOException
/*     */   {
/* 200 */     File fileBlock = null;
/* 201 */     InputStream in = null;
/* 202 */     OutputStream out = null;
/*     */     try {
/* 204 */       fileBlock = newBackupFile();
/* 205 */       in = get(blockToKey(block), byteRangeStart);
/* 206 */       out = new BufferedOutputStream(new FileOutputStream(fileBlock));
/* 207 */       byte[] buf = new byte[this.bufferSize];
/*     */       int numRead;
/* 209 */       while ((numRead = in.read(buf)) >= 0) {
/* 210 */         out.write(buf, 0, numRead);
/*     */       }
/* 212 */       return fileBlock;
/*     */     }
/*     */     catch (IOException e) {
/* 215 */       closeQuietly(out);
/* 216 */       out = null;
/* 217 */       if (fileBlock != null) {
/* 218 */         fileBlock.delete();
/*     */       }
/* 220 */       throw e;
/*     */     } finally {
/* 222 */       closeQuietly(out);
/* 223 */       closeQuietly(in);
/*     */     }
/*     */   }
/*     */ 
/*     */   private File newBackupFile() throws IOException {
/* 228 */     File dir = new File(this.conf.get("fs.s3.buffer.dir"));
/* 229 */     if ((!dir.exists()) && (!dir.mkdirs())) {
/* 230 */       throw new IOException(new StringBuilder().append("Cannot create S3 buffer directory: ").append(dir).toString());
/*     */     }
/* 232 */     File result = File.createTempFile("input-", ".tmp", dir);
/* 233 */     result.deleteOnExit();
/* 234 */     return result;
/*     */   }
/*     */ 
/*     */   public Set<Path> listSubPaths(Path path) throws IOException {
/*     */     try {
/* 239 */       String prefix = pathToKey(path);
/* 240 */       if (!prefix.endsWith("/")) {
/* 241 */         prefix = new StringBuilder().append(prefix).append("/").toString();
/*     */       }
/* 243 */       S3Object[] objects = this.s3Service.listObjects(this.bucket, prefix, "/");
/* 244 */       Set prefixes = new TreeSet();
/* 245 */       for (int i = 0; i < objects.length; i++) {
/* 246 */         prefixes.add(keyToPath(objects[i].getKey()));
/*     */       }
/* 248 */       prefixes.remove(path);
/* 249 */       return prefixes;
/*     */     } catch (S3ServiceException e) {
/* 251 */       if ((e.getCause() instanceof IOException)) {
/* 252 */         throw ((IOException)e.getCause());
/*     */       }
/* 254 */       throw new S3Exception(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Set<Path> listDeepSubPaths(Path path) throws IOException {
/*     */     try {
/* 260 */       String prefix = pathToKey(path);
/* 261 */       if (!prefix.endsWith("/")) {
/* 262 */         prefix = new StringBuilder().append(prefix).append("/").toString();
/*     */       }
/* 264 */       S3Object[] objects = this.s3Service.listObjects(this.bucket, prefix, null);
/* 265 */       Set prefixes = new TreeSet();
/* 266 */       for (int i = 0; i < objects.length; i++) {
/* 267 */         prefixes.add(keyToPath(objects[i].getKey()));
/*     */       }
/* 269 */       prefixes.remove(path);
/* 270 */       return prefixes;
/*     */     } catch (S3ServiceException e) {
/* 272 */       if ((e.getCause() instanceof IOException)) {
/* 273 */         throw ((IOException)e.getCause());
/*     */       }
/* 275 */       throw new S3Exception(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void put(String key, InputStream in, long length, boolean storeMetadata) throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 283 */       S3Object object = new S3Object(key);
/* 284 */       object.setDataInputStream(in);
/* 285 */       object.setContentType("binary/octet-stream");
/* 286 */       object.setContentLength(length);
/* 287 */       if (storeMetadata) {
/* 288 */         object.addAllMetadata(METADATA);
/*     */       }
/* 290 */       this.s3Service.putObject(this.bucket, object);
/*     */     } catch (S3ServiceException e) {
/* 292 */       if ((e.getCause() instanceof IOException)) {
/* 293 */         throw ((IOException)e.getCause());
/*     */       }
/* 295 */       throw new S3Exception(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void storeINode(Path path, INode inode) throws IOException {
/* 300 */     put(pathToKey(path), inode.serialize(), inode.getSerializedLength(), true);
/*     */   }
/*     */ 
/*     */   public void storeBlock(Block block, File file) throws IOException {
/* 304 */     BufferedInputStream in = null;
/*     */     try {
/* 306 */       in = new BufferedInputStream(new FileInputStream(file));
/* 307 */       put(blockToKey(block), in, block.getLength(), false);
/*     */     } finally {
/* 309 */       closeQuietly(in);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void closeQuietly(Closeable closeable) {
/* 314 */     if (closeable != null)
/*     */       try {
/* 316 */         closeable.close();
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/*     */       }
/*     */   }
/*     */ 
/*     */   private String pathToKey(Path path) {
/* 324 */     if (!path.isAbsolute()) {
/* 325 */       throw new IllegalArgumentException(new StringBuilder().append("Path must be absolute: ").append(path).toString());
/*     */     }
/* 327 */     return path.toUri().getPath();
/*     */   }
/*     */ 
/*     */   private Path keyToPath(String key) {
/* 331 */     return new Path(key);
/*     */   }
/*     */ 
/*     */   private String blockToKey(long blockId) {
/* 335 */     return new StringBuilder().append("block_").append(blockId).toString();
/*     */   }
/*     */ 
/*     */   private String blockToKey(Block block) {
/* 339 */     return blockToKey(block.getId());
/*     */   }
/*     */ 
/*     */   public void purge() throws IOException {
/*     */     try {
/* 344 */       S3Object[] objects = this.s3Service.listObjects(this.bucket);
/* 345 */       for (int i = 0; i < objects.length; i++)
/* 346 */         this.s3Service.deleteObject(this.bucket, objects[i].getKey());
/*     */     }
/*     */     catch (S3ServiceException e) {
/* 349 */       if ((e.getCause() instanceof IOException)) {
/* 350 */         throw ((IOException)e.getCause());
/*     */       }
/* 352 */       throw new S3Exception(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void dump() throws IOException {
/* 357 */     StringBuilder sb = new StringBuilder("S3 Filesystem, ");
/* 358 */     sb.append(this.bucket.getName()).append("\n");
/*     */     try {
/* 360 */       S3Object[] objects = this.s3Service.listObjects(this.bucket, "/", null);
/* 361 */       for (int i = 0; i < objects.length; i++) {
/* 362 */         Path path = keyToPath(objects[i].getKey());
/* 363 */         sb.append(path).append("\n");
/* 364 */         INode m = retrieveINode(path);
/* 365 */         sb.append("\t").append(m.getFileType()).append("\n");
/* 366 */         if (m.getFileType() != INode.FileType.DIRECTORY)
/*     */         {
/* 369 */           for (int j = 0; j < m.getBlocks().length; j++)
/* 370 */             sb.append("\t").append(m.getBlocks()[j]).append("\n");
/*     */         }
/*     */       }
/*     */     } catch (S3ServiceException e) {
/* 374 */       if ((e.getCause() instanceof IOException)) {
/* 375 */         throw ((IOException)e.getCause());
/*     */       }
/* 377 */       throw new S3Exception(e);
/*     */     }
/* 379 */     System.out.println(sb);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  61 */     METADATA.put("fs", "Hadoop");
/*  62 */     METADATA.put("fs-type", "block");
/*  63 */     METADATA.put("fs-version", "1");
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.s3.Jets3tFileSystemStore
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.fs.s3;
/*    */ 
/*    */ public class Block
/*    */ {
/*    */   private long id;
/*    */   private long length;
/*    */ 
/*    */   public Block(long id, long length)
/*    */   {
/* 30 */     this.id = id;
/* 31 */     this.length = length;
/*    */   }
/*    */ 
/*    */   public long getId() {
/* 35 */     return this.id;
/*    */   }
/*    */ 
/*    */   public long getLength() {
/* 39 */     return this.length;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 44 */     return "Block[" + this.id + ", " + this.length + "]";
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.s3.Block
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.fs.s3;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FSDataInputStream;
/*     */ import org.apache.hadoop.fs.FSDataOutputStream;
/*     */ import org.apache.hadoop.fs.FileStatus;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.io.retry.RetryPolicies;
/*     */ import org.apache.hadoop.io.retry.RetryPolicy;
/*     */ import org.apache.hadoop.io.retry.RetryProxy;
/*     */ import org.apache.hadoop.util.Progressable;
/*     */ 
/*     */ public class S3FileSystem extends FileSystem
/*     */ {
/*     */   private URI uri;
/*     */   private FileSystemStore store;
/*     */   private Path workingDir;
/*     */ 
/*     */   public S3FileSystem()
/*     */   {
/*     */   }
/*     */ 
/*     */   public S3FileSystem(FileSystemStore store)
/*     */   {
/*  63 */     this.store = store;
/*     */   }
/*     */ 
/*     */   public URI getUri()
/*     */   {
/*  68 */     return this.uri;
/*     */   }
/*     */ 
/*     */   public void initialize(URI uri, Configuration conf) throws IOException
/*     */   {
/*  73 */     super.initialize(uri, conf);
/*  74 */     if (this.store == null) {
/*  75 */       this.store = createDefaultStore(conf);
/*     */     }
/*  77 */     this.store.initialize(uri, conf);
/*  78 */     setConf(conf);
/*  79 */     this.uri = URI.create(uri.getScheme() + "://" + uri.getAuthority());
/*  80 */     this.workingDir = new Path("/user", System.getProperty("user.name")).makeQualified(this);
/*     */   }
/*     */ 
/*     */   private static FileSystemStore createDefaultStore(Configuration conf)
/*     */   {
/*  85 */     FileSystemStore store = new Jets3tFileSystemStore();
/*     */ 
/*  87 */     RetryPolicy basePolicy = RetryPolicies.retryUpToMaximumCountWithFixedSleep(conf.getInt("fs.s3.maxRetries", 4), conf.getLong("fs.s3.sleepTimeSeconds", 10L), TimeUnit.SECONDS);
/*     */ 
/*  90 */     Map exceptionToPolicyMap = new HashMap();
/*     */ 
/*  92 */     exceptionToPolicyMap.put(IOException.class, basePolicy);
/*  93 */     exceptionToPolicyMap.put(S3Exception.class, basePolicy);
/*     */ 
/*  95 */     RetryPolicy methodPolicy = RetryPolicies.retryByException(RetryPolicies.TRY_ONCE_THEN_FAIL, exceptionToPolicyMap);
/*     */ 
/*  97 */     Map methodNameToPolicyMap = new HashMap();
/*  98 */     methodNameToPolicyMap.put("storeBlock", methodPolicy);
/*  99 */     methodNameToPolicyMap.put("retrieveBlock", methodPolicy);
/*     */ 
/* 101 */     return (FileSystemStore)RetryProxy.create(FileSystemStore.class, store, methodNameToPolicyMap);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 107 */     return getUri().toString();
/*     */   }
/*     */ 
/*     */   public Path getWorkingDirectory()
/*     */   {
/* 112 */     return this.workingDir;
/*     */   }
/*     */ 
/*     */   public void setWorkingDirectory(Path dir)
/*     */   {
/* 117 */     this.workingDir = makeAbsolute(dir);
/*     */   }
/*     */ 
/*     */   private Path makeAbsolute(Path path) {
/* 121 */     if (path.isAbsolute()) {
/* 122 */       return path;
/*     */     }
/* 124 */     return new Path(this.workingDir, path);
/*     */   }
/*     */ 
/*     */   public boolean mkdirs(Path path, FsPermission permission)
/*     */     throws IOException
/*     */   {
/* 132 */     Path absolutePath = makeAbsolute(path);
/* 133 */     List paths = new ArrayList();
/*     */     do {
/* 135 */       paths.add(0, absolutePath);
/* 136 */       absolutePath = absolutePath.getParent();
/* 137 */     }while (absolutePath != null);
/*     */ 
/* 139 */     boolean result = true;
/* 140 */     for (Path p : paths) {
/* 141 */       result &= mkdir(p);
/*     */     }
/* 143 */     return result;
/*     */   }
/*     */ 
/*     */   private boolean mkdir(Path path) throws IOException {
/* 147 */     Path absolutePath = makeAbsolute(path);
/* 148 */     INode inode = this.store.retrieveINode(absolutePath);
/* 149 */     if (inode == null)
/* 150 */       this.store.storeINode(absolutePath, INode.DIRECTORY_INODE);
/* 151 */     else if (inode.isFile()) {
/* 152 */       throw new IOException(String.format("Can't make directory for path %s since it is a file.", new Object[] { absolutePath }));
/*     */     }
/*     */ 
/* 156 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isFile(Path path) throws IOException
/*     */   {
/* 161 */     INode inode = this.store.retrieveINode(makeAbsolute(path));
/* 162 */     if (inode == null) {
/* 163 */       return false;
/*     */     }
/* 165 */     return inode.isFile();
/*     */   }
/*     */ 
/*     */   private INode checkFile(Path path) throws IOException {
/* 169 */     INode inode = this.store.retrieveINode(makeAbsolute(path));
/* 170 */     if (inode == null) {
/* 171 */       throw new IOException("No such file.");
/*     */     }
/* 173 */     if (inode.isDirectory()) {
/* 174 */       throw new IOException("Path " + path + " is a directory.");
/*     */     }
/* 176 */     return inode;
/*     */   }
/*     */ 
/*     */   public FileStatus[] listStatus(Path f) throws IOException
/*     */   {
/* 181 */     Path absolutePath = makeAbsolute(f);
/* 182 */     INode inode = this.store.retrieveINode(absolutePath);
/* 183 */     if (inode == null) {
/* 184 */       return null;
/*     */     }
/* 186 */     if (inode.isFile()) {
/* 187 */       return new FileStatus[] { new S3FileStatus(f.makeQualified(this), inode) };
/*     */     }
/*     */ 
/* 191 */     ArrayList ret = new ArrayList();
/* 192 */     for (Path p : this.store.listSubPaths(absolutePath)) {
/* 193 */       ret.add(getFileStatus(p.makeQualified(this)));
/*     */     }
/* 195 */     return (FileStatus[])ret.toArray(new FileStatus[0]);
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream append(Path f, int bufferSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 201 */     throw new IOException("Not supported");
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream create(Path file, FsPermission permission, boolean overwrite, int bufferSize, short replication, long blockSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 213 */     INode inode = this.store.retrieveINode(makeAbsolute(file));
/* 214 */     if (inode != null) {
/* 215 */       if (overwrite)
/* 216 */         delete(file);
/*     */       else
/* 218 */         throw new IOException("File already exists: " + file);
/*     */     }
/*     */     else {
/* 221 */       Path parent = file.getParent();
/* 222 */       if ((parent != null) && 
/* 223 */         (!mkdirs(parent))) {
/* 224 */         throw new IOException("Mkdirs failed to create " + parent.toString());
/*     */       }
/*     */     }
/*     */ 
/* 228 */     return new FSDataOutputStream(new S3OutputStream(getConf(), this.store, makeAbsolute(file), blockSize, progress, bufferSize), this.statistics);
/*     */   }
/*     */ 
/*     */   public FSDataInputStream open(Path path, int bufferSize)
/*     */     throws IOException
/*     */   {
/* 236 */     INode inode = checkFile(path);
/* 237 */     return new FSDataInputStream(new S3InputStream(getConf(), this.store, inode, this.statistics));
/*     */   }
/*     */ 
/*     */   public boolean rename(Path src, Path dst)
/*     */     throws IOException
/*     */   {
/* 243 */     Path absoluteSrc = makeAbsolute(src);
/* 244 */     INode srcINode = this.store.retrieveINode(absoluteSrc);
/* 245 */     if (srcINode == null)
/*     */     {
/* 247 */       return false;
/*     */     }
/* 249 */     Path absoluteDst = makeAbsolute(dst);
/* 250 */     INode dstINode = this.store.retrieveINode(absoluteDst);
/* 251 */     if ((dstINode != null) && (dstINode.isDirectory())) {
/* 252 */       absoluteDst = new Path(absoluteDst, absoluteSrc.getName());
/* 253 */       dstINode = this.store.retrieveINode(absoluteDst);
/*     */     }
/* 255 */     if (dstINode != null)
/*     */     {
/* 257 */       return false;
/*     */     }
/* 259 */     Path dstParent = absoluteDst.getParent();
/* 260 */     if (dstParent != null) {
/* 261 */       INode dstParentINode = this.store.retrieveINode(dstParent);
/* 262 */       if ((dstParentINode == null) || (dstParentINode.isFile()))
/*     */       {
/* 264 */         return false;
/*     */       }
/*     */     }
/* 267 */     return renameRecursive(absoluteSrc, absoluteDst);
/*     */   }
/*     */ 
/*     */   private boolean renameRecursive(Path src, Path dst) throws IOException {
/* 271 */     INode srcINode = this.store.retrieveINode(src);
/* 272 */     this.store.storeINode(dst, srcINode);
/* 273 */     this.store.deleteINode(src);
/* 274 */     if (srcINode.isDirectory()) {
/* 275 */       for (Path oldSrc : this.store.listDeepSubPaths(src)) {
/* 276 */         INode inode = this.store.retrieveINode(oldSrc);
/* 277 */         if (inode == null) {
/* 278 */           return false;
/*     */         }
/* 280 */         String oldSrcPath = oldSrc.toUri().getPath();
/* 281 */         String srcPath = src.toUri().getPath();
/* 282 */         String dstPath = dst.toUri().getPath();
/* 283 */         Path newDst = new Path(oldSrcPath.replaceFirst(srcPath, dstPath));
/* 284 */         this.store.storeINode(newDst, inode);
/* 285 */         this.store.deleteINode(oldSrc);
/*     */       }
/*     */     }
/* 288 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean delete(Path path, boolean recursive) throws IOException {
/* 292 */     Path absolutePath = makeAbsolute(path);
/* 293 */     INode inode = this.store.retrieveINode(absolutePath);
/* 294 */     if (inode == null) {
/* 295 */       return false;
/*     */     }
/* 297 */     if (inode.isFile()) {
/* 298 */       this.store.deleteINode(absolutePath);
/* 299 */       for (Block block : inode.getBlocks())
/* 300 */         this.store.deleteBlock(block);
/*     */     }
/*     */     else {
/* 303 */       FileStatus[] contents = listStatus(absolutePath);
/* 304 */       if (contents == null) {
/* 305 */         return false;
/*     */       }
/* 307 */       if ((contents.length != 0) && (!recursive)) {
/* 308 */         throw new IOException("Directory " + path.toString() + " is not empty.");
/*     */       }
/*     */ 
/* 311 */       for (FileStatus p : contents) {
/* 312 */         if (!delete(p.getPath(), recursive)) {
/* 313 */           return false;
/*     */         }
/*     */       }
/* 316 */       this.store.deleteINode(absolutePath);
/*     */     }
/* 318 */     return true;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public boolean delete(Path path) throws IOException
/*     */   {
/* 324 */     return delete(path, true);
/*     */   }
/*     */ 
/*     */   public FileStatus getFileStatus(Path f)
/*     */     throws IOException
/*     */   {
/* 332 */     INode inode = this.store.retrieveINode(makeAbsolute(f));
/* 333 */     if (inode == null) {
/* 334 */       throw new FileNotFoundException(f + ": No such file or directory.");
/*     */     }
/* 336 */     return new S3FileStatus(f.makeQualified(this), inode);
/*     */   }
/*     */ 
/*     */   void dump()
/*     */     throws IOException
/*     */   {
/* 342 */     this.store.dump();
/*     */   }
/*     */ 
/*     */   void purge() throws IOException {
/* 346 */     this.store.purge();
/*     */   }
/*     */ 
/*     */   private static class S3FileStatus extends FileStatus
/*     */   {
/*     */     S3FileStatus(Path f, INode inode) throws IOException {
/* 352 */       super(inode.isDirectory(), 1, findBlocksize(inode), 0L, f);
/*     */     }
/*     */ 
/*     */     private static long findLength(INode inode)
/*     */     {
/* 357 */       if (!inode.isDirectory()) {
/* 358 */         long length = 0L;
/* 359 */         for (Block block : inode.getBlocks()) {
/* 360 */           length += block.getLength();
/*     */         }
/* 362 */         return length;
/*     */       }
/* 364 */       return 0L;
/*     */     }
/*     */ 
/*     */     private static long findBlocksize(INode inode) {
/* 368 */       Block[] ret = inode.getBlocks();
/* 369 */       return ret == null ? 0L : ret[0].getLength();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.s3.S3FileSystem
 * JD-Core Version:    0.6.1
 */
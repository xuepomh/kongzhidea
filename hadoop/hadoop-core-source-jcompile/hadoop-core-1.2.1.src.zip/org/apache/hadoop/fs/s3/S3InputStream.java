/*     */ package org.apache.hadoop.fs.s3;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FSInputStream;
/*     */ import org.apache.hadoop.fs.FileSystem.Statistics;
/*     */ 
/*     */ class S3InputStream extends FSInputStream
/*     */ {
/*     */   private FileSystemStore store;
/*     */   private Block[] blocks;
/*     */   private boolean closed;
/*     */   private long fileLength;
/*  40 */   private long pos = 0L;
/*     */   private File blockFile;
/*     */   private DataInputStream blockStream;
/*  46 */   private long blockEnd = -1L;
/*     */   private FileSystem.Statistics stats;
/*     */ 
/*     */   @Deprecated
/*     */   public S3InputStream(Configuration conf, FileSystemStore store, INode inode)
/*     */   {
/*  53 */     this(conf, store, inode, null);
/*     */   }
/*     */ 
/*     */   public S3InputStream(Configuration conf, FileSystemStore store, INode inode, FileSystem.Statistics stats)
/*     */   {
/*  59 */     this.store = store;
/*  60 */     this.stats = stats;
/*  61 */     this.blocks = inode.getBlocks();
/*  62 */     for (Block block : this.blocks)
/*  63 */       this.fileLength += block.getLength();
/*     */   }
/*     */ 
/*     */   public synchronized long getPos()
/*     */     throws IOException
/*     */   {
/*  69 */     return this.pos;
/*     */   }
/*     */ 
/*     */   public synchronized int available() throws IOException
/*     */   {
/*  74 */     return (int)(this.fileLength - this.pos);
/*     */   }
/*     */ 
/*     */   public synchronized void seek(long targetPos) throws IOException
/*     */   {
/*  79 */     if (targetPos > this.fileLength) {
/*  80 */       throw new IOException("Cannot seek after EOF");
/*     */     }
/*  82 */     this.pos = targetPos;
/*  83 */     this.blockEnd = -1L;
/*     */   }
/*     */ 
/*     */   public synchronized boolean seekToNewSource(long targetPos) throws IOException
/*     */   {
/*  88 */     return false;
/*     */   }
/*     */ 
/*     */   public synchronized int read() throws IOException
/*     */   {
/*  93 */     if (this.closed) {
/*  94 */       throw new IOException("Stream closed");
/*     */     }
/*  96 */     int result = -1;
/*  97 */     if (this.pos < this.fileLength) {
/*  98 */       if (this.pos > this.blockEnd) {
/*  99 */         blockSeekTo(this.pos);
/*     */       }
/* 101 */       result = this.blockStream.read();
/* 102 */       if (result >= 0) {
/* 103 */         this.pos += 1L;
/*     */       }
/*     */     }
/* 106 */     if ((this.stats != null) && (result >= 0)) {
/* 107 */       this.stats.incrementBytesRead(1L);
/*     */     }
/* 109 */     return result;
/*     */   }
/*     */ 
/*     */   public synchronized int read(byte[] buf, int off, int len) throws IOException
/*     */   {
/* 114 */     if (this.closed) {
/* 115 */       throw new IOException("Stream closed");
/*     */     }
/* 117 */     if (this.pos < this.fileLength) {
/* 118 */       if (this.pos > this.blockEnd) {
/* 119 */         blockSeekTo(this.pos);
/*     */       }
/* 121 */       int realLen = Math.min(len, (int)(this.blockEnd - this.pos + 1L));
/* 122 */       int result = this.blockStream.read(buf, off, realLen);
/* 123 */       if (result >= 0) {
/* 124 */         this.pos += result;
/*     */       }
/* 126 */       if ((this.stats != null) && (result > 0)) {
/* 127 */         this.stats.incrementBytesRead(result);
/*     */       }
/* 129 */       return result;
/*     */     }
/* 131 */     return -1;
/*     */   }
/*     */ 
/*     */   private synchronized void blockSeekTo(long target)
/*     */     throws IOException
/*     */   {
/* 138 */     int targetBlock = -1;
/* 139 */     long targetBlockStart = 0L;
/* 140 */     long targetBlockEnd = 0L;
/* 141 */     for (int i = 0; i < this.blocks.length; i++) {
/* 142 */       long blockLength = this.blocks[i].getLength();
/* 143 */       targetBlockEnd = targetBlockStart + blockLength - 1L;
/*     */ 
/* 145 */       if ((target >= targetBlockStart) && (target <= targetBlockEnd)) {
/* 146 */         targetBlock = i;
/* 147 */         break;
/*     */       }
/* 149 */       targetBlockStart = targetBlockEnd + 1L;
/*     */     }
/*     */ 
/* 152 */     if (targetBlock < 0) {
/* 153 */       throw new IOException("Impossible situation: could not find target position " + target);
/*     */     }
/*     */ 
/* 156 */     long offsetIntoBlock = target - targetBlockStart;
/*     */ 
/* 160 */     this.blockFile = this.store.retrieveBlock(this.blocks[targetBlock], offsetIntoBlock);
/*     */ 
/* 162 */     this.pos = target;
/* 163 */     this.blockEnd = targetBlockEnd;
/* 164 */     this.blockStream = new DataInputStream(new FileInputStream(this.blockFile));
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 170 */     if (this.closed) {
/* 171 */       return;
/*     */     }
/* 173 */     if (this.blockStream != null) {
/* 174 */       this.blockStream.close();
/* 175 */       this.blockStream = null;
/*     */     }
/* 177 */     if (this.blockFile != null) {
/* 178 */       this.blockFile.delete();
/*     */     }
/* 180 */     super.close();
/* 181 */     this.closed = true;
/*     */   }
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/* 189 */     return false;
/*     */   }
/*     */ 
/*     */   public void mark(int readLimit)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */     throws IOException
/*     */   {
/* 199 */     throw new IOException("Mark not supported");
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.s3.S3InputStream
 * JD-Core Version:    0.6.1
 */
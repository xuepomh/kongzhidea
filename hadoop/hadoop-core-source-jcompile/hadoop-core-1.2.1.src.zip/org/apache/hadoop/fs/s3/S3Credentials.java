/*    */ package org.apache.hadoop.fs.s3;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ 
/*    */ public class S3Credentials
/*    */ {
/*    */   private String accessKey;
/*    */   private String secretAccessKey;
/*    */ 
/*    */   public void initialize(URI uri, Configuration conf)
/*    */   {
/* 40 */     if (uri.getHost() == null) {
/* 41 */       throw new IllegalArgumentException("Invalid hostname in URI " + uri);
/*    */     }
/*    */ 
/* 44 */     String userInfo = uri.getUserInfo();
/* 45 */     if (userInfo != null) {
/* 46 */       int index = userInfo.indexOf(':');
/* 47 */       if (index != -1) {
/* 48 */         this.accessKey = userInfo.substring(0, index);
/* 49 */         this.secretAccessKey = userInfo.substring(index + 1);
/*    */       } else {
/* 51 */         this.accessKey = userInfo;
/*    */       }
/*    */     }
/*    */ 
/* 55 */     String scheme = uri.getScheme();
/* 56 */     String accessKeyProperty = String.format("fs.%s.awsAccessKeyId", new Object[] { scheme });
/* 57 */     String secretAccessKeyProperty = String.format("fs.%s.awsSecretAccessKey", new Object[] { scheme });
/*    */ 
/* 59 */     if (this.accessKey == null) {
/* 60 */       this.accessKey = conf.get(accessKeyProperty);
/*    */     }
/* 62 */     if (this.secretAccessKey == null) {
/* 63 */       this.secretAccessKey = conf.get(secretAccessKeyProperty);
/*    */     }
/* 65 */     if ((this.accessKey == null) && (this.secretAccessKey == null)) {
/* 66 */       throw new IllegalArgumentException("AWS Access Key ID and Secret Access Key must be specified as the username or password (respectively) of a " + scheme + " URL, or by setting the " + accessKeyProperty + " or " + secretAccessKeyProperty + " properties (respectively).");
/*    */     }
/*    */ 
/* 75 */     if (this.accessKey == null) {
/* 76 */       throw new IllegalArgumentException("AWS Access Key ID must be specified as the username of a " + scheme + " URL, or by setting the " + accessKeyProperty + " property.");
/*    */     }
/*    */ 
/* 81 */     if (this.secretAccessKey == null)
/* 82 */       throw new IllegalArgumentException("AWS Secret Access Key must be specified as the password of a " + scheme + " URL, or by setting the " + secretAccessKeyProperty + " property.");
/*    */   }
/*    */ 
/*    */   public String getAccessKey()
/*    */   {
/* 93 */     return this.accessKey;
/*    */   }
/*    */ 
/*    */   public String getSecretAccessKey() {
/* 97 */     return this.secretAccessKey;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.s3.S3Credentials
 * JD-Core Version:    0.6.1
 */
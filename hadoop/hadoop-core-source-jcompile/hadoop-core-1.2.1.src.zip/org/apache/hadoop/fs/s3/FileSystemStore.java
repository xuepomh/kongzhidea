package org.apache.hadoop.fs.s3;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.Set;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;

public abstract interface FileSystemStore
{
  public abstract void initialize(URI paramURI, Configuration paramConfiguration)
    throws IOException;

  public abstract String getVersion()
    throws IOException;

  public abstract void storeINode(Path paramPath, INode paramINode)
    throws IOException;

  public abstract void storeBlock(Block paramBlock, File paramFile)
    throws IOException;

  public abstract boolean inodeExists(Path paramPath)
    throws IOException;

  public abstract boolean blockExists(long paramLong)
    throws IOException;

  public abstract INode retrieveINode(Path paramPath)
    throws IOException;

  public abstract File retrieveBlock(Block paramBlock, long paramLong)
    throws IOException;

  public abstract void deleteINode(Path paramPath)
    throws IOException;

  public abstract void deleteBlock(Block paramBlock)
    throws IOException;

  public abstract Set<Path> listSubPaths(Path paramPath)
    throws IOException;

  public abstract Set<Path> listDeepSubPaths(Path paramPath)
    throws IOException;

  public abstract void purge()
    throws IOException;

  public abstract void dump()
    throws IOException;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.s3.FileSystemStore
 * JD-Core Version:    0.6.1
 */
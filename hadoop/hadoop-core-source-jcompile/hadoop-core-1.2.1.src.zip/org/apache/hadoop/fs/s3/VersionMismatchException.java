/*    */ package org.apache.hadoop.fs.s3;
/*    */ 
/*    */ public class VersionMismatchException extends S3FileSystemException
/*    */ {
/*    */   public VersionMismatchException(String clientVersion, String dataVersion)
/*    */   {
/* 26 */     super(new StringBuilder().append("Version mismatch: client expects version ").append(clientVersion).append(", but data has version ").append(dataVersion == null ? "[unversioned]" : dataVersion).toString());
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.s3.VersionMismatchException
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.fs.s3;
/*    */ 
/*    */ public class S3Exception extends RuntimeException
/*    */ {
/*    */   public S3Exception(Throwable t)
/*    */   {
/* 27 */     super(t);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.s3.S3Exception
 * JD-Core Version:    0.6.1
 */
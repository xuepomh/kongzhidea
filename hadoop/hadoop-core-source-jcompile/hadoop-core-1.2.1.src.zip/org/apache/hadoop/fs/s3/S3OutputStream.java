/*     */ package org.apache.hadoop.fs.s3;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.util.Progressable;
/*     */ 
/*     */ class S3OutputStream extends OutputStream
/*     */ {
/*     */   private Configuration conf;
/*     */   private int bufferSize;
/*     */   private FileSystemStore store;
/*     */   private Path path;
/*     */   private long blockSize;
/*     */   private File backupFile;
/*     */   private OutputStream backupStream;
/*  50 */   private Random r = new Random();
/*     */   private boolean closed;
/*  54 */   private int pos = 0;
/*     */ 
/*  56 */   private long filePos = 0L;
/*     */ 
/*  58 */   private int bytesWrittenToBlock = 0;
/*     */   private byte[] outBuf;
/*  62 */   private List<Block> blocks = new ArrayList();
/*     */   private Block nextBlock;
/*     */ 
/*     */   public S3OutputStream(Configuration conf, FileSystemStore store, Path path, long blockSize, Progressable progress, int buffersize)
/*     */     throws IOException
/*     */   {
/*  70 */     this.conf = conf;
/*  71 */     this.store = store;
/*  72 */     this.path = path;
/*  73 */     this.blockSize = blockSize;
/*  74 */     this.backupFile = newBackupFile();
/*  75 */     this.backupStream = new FileOutputStream(this.backupFile);
/*  76 */     this.bufferSize = buffersize;
/*  77 */     this.outBuf = new byte[this.bufferSize];
/*     */   }
/*     */ 
/*     */   private File newBackupFile() throws IOException
/*     */   {
/*  82 */     File dir = new File(this.conf.get("fs.s3.buffer.dir"));
/*  83 */     if ((!dir.exists()) && (!dir.mkdirs())) {
/*  84 */       throw new IOException("Cannot create S3 buffer directory: " + dir);
/*     */     }
/*  86 */     File result = File.createTempFile("output-", ".tmp", dir);
/*  87 */     result.deleteOnExit();
/*  88 */     return result;
/*     */   }
/*     */ 
/*     */   public long getPos() throws IOException {
/*  92 */     return this.filePos;
/*     */   }
/*     */ 
/*     */   public synchronized void write(int b) throws IOException
/*     */   {
/*  97 */     if (this.closed) {
/*  98 */       throw new IOException("Stream closed");
/*     */     }
/*     */ 
/* 101 */     if ((this.bytesWrittenToBlock + this.pos == this.blockSize) || (this.pos >= this.bufferSize)) {
/* 102 */       flush();
/*     */     }
/* 104 */     this.outBuf[(this.pos++)] = (byte)b;
/* 105 */     this.filePos += 1L;
/*     */   }
/*     */ 
/*     */   public synchronized void write(byte[] b, int off, int len) throws IOException
/*     */   {
/* 110 */     if (this.closed) {
/* 111 */       throw new IOException("Stream closed");
/*     */     }
/* 113 */     while (len > 0) {
/* 114 */       int remaining = this.bufferSize - this.pos;
/* 115 */       int toWrite = Math.min(remaining, len);
/* 116 */       System.arraycopy(b, off, this.outBuf, this.pos, toWrite);
/* 117 */       this.pos += toWrite;
/* 118 */       off += toWrite;
/* 119 */       len -= toWrite;
/* 120 */       this.filePos += toWrite;
/*     */ 
/* 122 */       if ((this.bytesWrittenToBlock + this.pos >= this.blockSize) || (this.pos == this.bufferSize))
/* 123 */         flush();
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void flush()
/*     */     throws IOException
/*     */   {
/* 130 */     if (this.closed) {
/* 131 */       throw new IOException("Stream closed");
/*     */     }
/*     */ 
/* 134 */     if (this.bytesWrittenToBlock + this.pos >= this.blockSize) {
/* 135 */       flushData((int)this.blockSize - this.bytesWrittenToBlock);
/*     */     }
/* 137 */     if (this.bytesWrittenToBlock == this.blockSize) {
/* 138 */       endBlock();
/*     */     }
/* 140 */     flushData(this.pos);
/*     */   }
/*     */ 
/*     */   private synchronized void flushData(int maxPos) throws IOException {
/* 144 */     int workingPos = Math.min(this.pos, maxPos);
/*     */ 
/* 146 */     if (workingPos > 0)
/*     */     {
/* 150 */       this.backupStream.write(this.outBuf, 0, workingPos);
/*     */ 
/* 155 */       this.bytesWrittenToBlock += workingPos;
/* 156 */       System.arraycopy(this.outBuf, workingPos, this.outBuf, 0, this.pos - workingPos);
/* 157 */       this.pos -= workingPos;
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized void endBlock()
/*     */     throws IOException
/*     */   {
/* 165 */     this.backupStream.close();
/*     */ 
/* 171 */     nextBlockOutputStream();
/* 172 */     this.store.storeBlock(this.nextBlock, this.backupFile);
/* 173 */     internalClose();
/*     */ 
/* 178 */     this.backupFile.delete();
/* 179 */     this.backupFile = newBackupFile();
/* 180 */     this.backupStream = new FileOutputStream(this.backupFile);
/* 181 */     this.bytesWrittenToBlock = 0;
/*     */   }
/*     */ 
/*     */   private synchronized void nextBlockOutputStream() throws IOException {
/* 185 */     long blockId = this.r.nextLong();
/* 186 */     while (this.store.blockExists(blockId)) {
/* 187 */       blockId = this.r.nextLong();
/*     */     }
/* 189 */     this.nextBlock = new Block(blockId, this.bytesWrittenToBlock);
/* 190 */     this.blocks.add(this.nextBlock);
/* 191 */     this.bytesWrittenToBlock = 0;
/*     */   }
/*     */ 
/*     */   private synchronized void internalClose() throws IOException {
/* 195 */     INode inode = new INode(INode.FileType.FILE, (Block[])this.blocks.toArray(new Block[this.blocks.size()]));
/*     */ 
/* 197 */     this.store.storeINode(this.path, inode);
/*     */   }
/*     */ 
/*     */   public synchronized void close() throws IOException
/*     */   {
/* 202 */     if (this.closed) {
/* 203 */       return;
/*     */     }
/*     */ 
/* 206 */     flush();
/* 207 */     if ((this.filePos == 0L) || (this.bytesWrittenToBlock != 0)) {
/* 208 */       endBlock();
/*     */     }
/*     */ 
/* 211 */     this.backupStream.close();
/* 212 */     this.backupFile.delete();
/*     */ 
/* 214 */     super.close();
/*     */ 
/* 216 */     this.closed = true;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.s3.S3OutputStream
 * JD-Core Version:    0.6.1
 */
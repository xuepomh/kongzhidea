/*     */ package org.apache.hadoop.fs.s3;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ public class INode
/*     */ {
/*  38 */   public static final FileType[] FILE_TYPES = { FileType.DIRECTORY, FileType.FILE };
/*     */ 
/*  43 */   public static final INode DIRECTORY_INODE = new INode(FileType.DIRECTORY, null);
/*     */   private FileType fileType;
/*     */   private Block[] blocks;
/*     */ 
/*     */   public INode(FileType fileType, Block[] blocks)
/*     */   {
/*  49 */     this.fileType = fileType;
/*  50 */     if ((isDirectory()) && (blocks != null)) {
/*  51 */       throw new IllegalArgumentException("A directory cannot contain blocks.");
/*     */     }
/*  53 */     this.blocks = blocks;
/*     */   }
/*     */ 
/*     */   public Block[] getBlocks() {
/*  57 */     return this.blocks;
/*     */   }
/*     */ 
/*     */   public FileType getFileType() {
/*  61 */     return this.fileType;
/*     */   }
/*     */ 
/*     */   public boolean isDirectory() {
/*  65 */     return this.fileType == FileType.DIRECTORY;
/*     */   }
/*     */ 
/*     */   public boolean isFile() {
/*  69 */     return this.fileType == FileType.FILE;
/*     */   }
/*     */ 
/*     */   public long getSerializedLength() {
/*  73 */     return 1L + this.blocks == null ? 0 : 4 + this.blocks.length * 16;
/*     */   }
/*     */ 
/*     */   public InputStream serialize() throws IOException
/*     */   {
/*  78 */     ByteArrayOutputStream bytes = new ByteArrayOutputStream();
/*  79 */     DataOutputStream out = new DataOutputStream(bytes);
/*  80 */     out.writeByte(this.fileType.ordinal());
/*  81 */     if (isFile()) {
/*  82 */       out.writeInt(this.blocks.length);
/*  83 */       for (int i = 0; i < this.blocks.length; i++) {
/*  84 */         out.writeLong(this.blocks[i].getId());
/*  85 */         out.writeLong(this.blocks[i].getLength());
/*     */       }
/*     */     }
/*  88 */     out.close();
/*  89 */     return new ByteArrayInputStream(bytes.toByteArray());
/*     */   }
/*     */ 
/*     */   public static INode deserialize(InputStream in) throws IOException {
/*  93 */     if (in == null) {
/*  94 */       return null;
/*     */     }
/*  96 */     DataInputStream dataIn = new DataInputStream(in);
/*  97 */     FileType fileType = FILE_TYPES[dataIn.readByte()];
/*  98 */     switch (1.$SwitchMap$org$apache$hadoop$fs$s3$INode$FileType[fileType.ordinal()]) {
/*     */     case 1:
/* 100 */       in.close();
/* 101 */       return DIRECTORY_INODE;
/*     */     case 2:
/* 103 */       int numBlocks = dataIn.readInt();
/* 104 */       Block[] blocks = new Block[numBlocks];
/* 105 */       for (int i = 0; i < numBlocks; i++) {
/* 106 */         long id = dataIn.readLong();
/* 107 */         long length = dataIn.readLong();
/* 108 */         blocks[i] = new Block(id, length);
/*     */       }
/* 110 */       in.close();
/* 111 */       return new INode(fileType, blocks);
/*     */     }
/* 113 */     throw new IllegalArgumentException("Cannot deserialize inode.");
/*     */   }
/*     */ 
/*     */   static enum FileType
/*     */   {
/*  35 */     DIRECTORY, FILE;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.s3.INode
 * JD-Core Version:    0.6.1
 */
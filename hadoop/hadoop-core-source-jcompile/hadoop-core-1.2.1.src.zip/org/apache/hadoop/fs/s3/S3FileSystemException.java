/*    */ package org.apache.hadoop.fs.s3;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class S3FileSystemException extends IOException
/*    */ {
/*    */   public S3FileSystemException(String message)
/*    */   {
/* 27 */     super(message);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.s3.S3FileSystemException
 * JD-Core Version:    0.6.1
 */
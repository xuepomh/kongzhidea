package org.apache.hadoop.fs;

import java.io.FileDescriptor;
import java.io.IOException;
import org.apache.hadoop.classification.InterfaceAudience.Private;
import org.apache.hadoop.classification.InterfaceStability.Evolving;

@InterfaceAudience.Private
@InterfaceStability.Evolving
public abstract interface HasFileDescriptor
{
  public abstract FileDescriptor getFileDescriptor()
    throws IOException;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.HasFileDescriptor
 * JD-Core Version:    0.6.1
 */
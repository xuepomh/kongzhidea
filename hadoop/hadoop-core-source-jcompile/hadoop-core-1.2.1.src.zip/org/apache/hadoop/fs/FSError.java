/*    */ package org.apache.hadoop.fs;
/*    */ 
/*    */ public class FSError extends Error
/*    */ {
/*    */   FSError(Throwable cause)
/*    */   {
/* 25 */     super(cause);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.FSError
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.hadoop.fs.permission.ChmodParser;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ 
/*     */ class FsShellPermissions
/*     */ {
/*  42 */   static String CHMOD_USAGE = "-chmod [-R] <MODE[,MODE]... | OCTALMODE> PATH...";
/*     */   private static ChmodParser pp;
/*  75 */   private static String allowedChars = "[-_./@a-zA-Z0-9]";
/*     */ 
/*  77 */   private static Pattern chownPattern = Pattern.compile("^\\s*(" + allowedChars + "+)?" + "([:](" + allowedChars + "*))?\\s*$");
/*     */ 
/*  80 */   private static Pattern chgrpPattern = Pattern.compile("^\\s*(" + allowedChars + "+)\\s*$");
/*     */ 
/*  83 */   static String CHOWN_USAGE = "-chown [-R] [OWNER][:[GROUP]] PATH...";
/*  84 */   static String CHGRP_USAGE = "-chgrp [-R] GROUP PATH...";
/*     */ 
/*     */   static int changePermissions(FileSystem fs, String cmd, String[] argv, int startIndex, FsShell shell)
/*     */     throws IOException
/*     */   {
/* 144 */     FsShell.CmdHandler handler = null;
/* 145 */     boolean recursive = false;
/*     */ 
/* 149 */     for (; (startIndex < argv.length) && (argv[startIndex].equals("-R")); 
/* 149 */       startIndex++) {
/* 150 */       recursive = true;
/*     */     }
/*     */ 
/* 153 */     if (startIndex >= argv.length) {
/* 154 */       throw new IOException("Not enough arguments for the command");
/*     */     }
/*     */ 
/* 157 */     if (cmd.equals("-chmod"))
/* 158 */       handler = new ChmodHandler(fs, argv[(startIndex++)]);
/* 159 */     else if (cmd.equals("-chown"))
/* 160 */       handler = new ChownHandler(fs, argv[(startIndex++)]);
/* 161 */     else if (cmd.equals("-chgrp")) {
/* 162 */       handler = new ChgrpHandler(fs, argv[(startIndex++)]);
/*     */     }
/*     */ 
/* 165 */     return shell.runCmdHandler(handler, argv, startIndex, recursive);
/*     */   }
/*     */ 
/*     */   private static class ChgrpHandler extends FsShellPermissions.ChownHandler
/*     */   {
/*     */     ChgrpHandler(FileSystem fs, String groupStr)
/*     */       throws IOException
/*     */     {
/* 130 */       super(fs);
/*     */ 
/* 132 */       Matcher matcher = FsShellPermissions.chgrpPattern.matcher(groupStr);
/* 133 */       if (!matcher.matches()) {
/* 134 */         throw new IOException("'" + groupStr + "' does not match " + "expected pattern for group");
/*     */       }
/*     */ 
/* 137 */       this.group = matcher.group(1);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ChownHandler extends FsShell.CmdHandler
/*     */   {
/*  87 */     protected String owner = null;
/*  88 */     protected String group = null;
/*     */ 
/*     */     protected ChownHandler(String cmd, FileSystem fs) {
/*  91 */       super(fs);
/*     */     }
/*     */ 
/*     */     ChownHandler(FileSystem fs, String ownerStr) throws IOException {
/*  95 */       super(fs);
/*  96 */       Matcher matcher = FsShellPermissions.chownPattern.matcher(ownerStr);
/*  97 */       if (!matcher.matches()) {
/*  98 */         throw new IOException("'" + ownerStr + "' does not match " + "expected pattern for [owner][:group].");
/*     */       }
/*     */ 
/* 101 */       this.owner = matcher.group(1);
/* 102 */       this.group = matcher.group(3);
/* 103 */       if ((this.group != null) && (this.group.length() == 0)) {
/* 104 */         this.group = null;
/*     */       }
/* 106 */       if ((this.owner == null) && (this.group == null))
/* 107 */         throw new IOException("'" + ownerStr + "' does not specify " + " owner or group.");
/*     */     }
/*     */ 
/*     */     public void run(FileStatus file, FileSystem srcFs)
/*     */       throws IOException
/*     */     {
/* 115 */       String newOwner = (this.owner == null) || (this.owner.equals(file.getOwner())) ? null : this.owner;
/*     */ 
/* 117 */       String newGroup = (this.group == null) || (this.group.equals(file.getGroup())) ? null : this.group;
/*     */ 
/* 120 */       if ((newOwner != null) || (newGroup != null))
/* 121 */         srcFs.setOwner(file.getPath(), newOwner, newGroup);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ChmodHandler extends FsShell.CmdHandler
/*     */   {
/*     */     ChmodHandler(FileSystem fs, String modeStr)
/*     */       throws IOException
/*     */     {
/*  50 */       super(fs);
/*     */       try {
/*  52 */         FsShellPermissions.access$002(new ChmodParser(modeStr));
/*     */       } catch (IllegalArgumentException iea) {
/*  54 */         patternError(iea.getMessage());
/*     */       }
/*     */     }
/*     */ 
/*     */     private void patternError(String mode) throws IOException {
/*  59 */       throw new IOException("chmod : mode '" + mode + "' does not match the expected pattern.");
/*     */     }
/*     */ 
/*     */     public void run(FileStatus file, FileSystem srcFs)
/*     */       throws IOException
/*     */     {
/*  65 */       int newperms = FsShellPermissions.pp.applyNewPermission(file);
/*     */ 
/*  67 */       if (file.getPermission().toShort() != newperms)
/*  68 */         srcFs.setPermission(file.getPath(), new FsPermission((short)newperms));
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.FsShellPermissions
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.fs;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class FileAlreadyExistsException extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public FileAlreadyExistsException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public FileAlreadyExistsException(String msg)
/*    */   {
/* 37 */     super(msg);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.FileAlreadyExistsException
 * JD-Core Version:    0.6.1
 */
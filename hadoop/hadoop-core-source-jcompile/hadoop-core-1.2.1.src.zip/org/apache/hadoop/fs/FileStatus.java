/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.io.Text;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ 
/*     */ public class FileStatus
/*     */   implements Writable, Comparable
/*     */ {
/*     */   private Path path;
/*     */   private long length;
/*     */   private boolean isdir;
/*     */   private short block_replication;
/*     */   private long blocksize;
/*     */   private long modification_time;
/*     */   private long access_time;
/*     */   private FsPermission permission;
/*     */   private String owner;
/*     */   private String group;
/*     */ 
/*     */   public FileStatus()
/*     */   {
/*  43 */     this(0L, false, 0, 0L, 0L, 0L, null, null, null, null);
/*     */   }
/*     */ 
/*     */   public FileStatus(long length, boolean isdir, int block_replication, long blocksize, long modification_time, Path path)
/*     */   {
/*  49 */     this(length, isdir, block_replication, blocksize, modification_time, 0L, null, null, null, path);
/*     */   }
/*     */ 
/*     */   public FileStatus(long length, boolean isdir, int block_replication, long blocksize, long modification_time, long access_time, FsPermission permission, String owner, String group, Path path)
/*     */   {
/*  57 */     this.length = length;
/*  58 */     this.isdir = isdir;
/*  59 */     this.block_replication = (short)block_replication;
/*  60 */     this.blocksize = blocksize;
/*  61 */     this.modification_time = modification_time;
/*  62 */     this.access_time = access_time;
/*  63 */     this.permission = (permission == null ? FsPermission.getDefault() : permission);
/*     */ 
/*  65 */     this.owner = (owner == null ? "" : owner);
/*  66 */     this.group = (group == null ? "" : group);
/*  67 */     this.path = path;
/*     */   }
/*     */ 
/*     */   public long getLen()
/*     */   {
/*  74 */     return this.length;
/*     */   }
/*     */ 
/*     */   public boolean isDir()
/*     */   {
/*  82 */     return this.isdir;
/*     */   }
/*     */ 
/*     */   public long getBlockSize()
/*     */   {
/*  90 */     return this.blocksize;
/*     */   }
/*     */ 
/*     */   public short getReplication()
/*     */   {
/*  98 */     return this.block_replication;
/*     */   }
/*     */ 
/*     */   public long getModificationTime()
/*     */   {
/* 106 */     return this.modification_time;
/*     */   }
/*     */ 
/*     */   public long getAccessTime()
/*     */   {
/* 114 */     return this.access_time;
/*     */   }
/*     */ 
/*     */   public FsPermission getPermission()
/*     */   {
/* 124 */     return this.permission;
/*     */   }
/*     */ 
/*     */   public String getOwner()
/*     */   {
/* 134 */     return this.owner;
/*     */   }
/*     */ 
/*     */   public String getGroup()
/*     */   {
/* 144 */     return this.group;
/*     */   }
/*     */ 
/*     */   public Path getPath() {
/* 148 */     return this.path;
/*     */   }
/*     */ 
/*     */   protected void setPermission(FsPermission permission)
/*     */   {
/* 160 */     this.permission = (permission == null ? FsPermission.getDefault() : permission);
/*     */   }
/*     */ 
/*     */   protected void setOwner(String owner)
/*     */   {
/* 169 */     this.owner = (owner == null ? "" : owner);
/*     */   }
/*     */ 
/*     */   protected void setGroup(String group)
/*     */   {
/* 177 */     this.group = (group == null ? "" : group);
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/* 184 */     Text.writeString(out, getPath().toString());
/* 185 */     out.writeLong(this.length);
/* 186 */     out.writeBoolean(this.isdir);
/* 187 */     out.writeShort(this.block_replication);
/* 188 */     out.writeLong(this.blocksize);
/* 189 */     out.writeLong(this.modification_time);
/* 190 */     out.writeLong(this.access_time);
/* 191 */     this.permission.write(out);
/* 192 */     Text.writeString(out, this.owner);
/* 193 */     Text.writeString(out, this.group);
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException {
/* 197 */     String strPath = Text.readString(in);
/* 198 */     this.path = new Path(strPath);
/* 199 */     this.length = in.readLong();
/* 200 */     this.isdir = in.readBoolean();
/* 201 */     this.block_replication = in.readShort();
/* 202 */     this.blocksize = in.readLong();
/* 203 */     this.modification_time = in.readLong();
/* 204 */     this.access_time = in.readLong();
/* 205 */     this.permission.readFields(in);
/* 206 */     this.owner = Text.readString(in);
/* 207 */     this.group = Text.readString(in);
/*     */   }
/*     */ 
/*     */   public int compareTo(Object o)
/*     */   {
/* 221 */     FileStatus other = (FileStatus)o;
/* 222 */     return getPath().compareTo(other.getPath());
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 230 */     if (o == null) {
/* 231 */       return false;
/*     */     }
/* 233 */     if (this == o) {
/* 234 */       return true;
/*     */     }
/* 236 */     if (!(o instanceof FileStatus)) {
/* 237 */       return false;
/*     */     }
/* 239 */     FileStatus other = (FileStatus)o;
/* 240 */     return getPath().equals(other.getPath());
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 250 */     return getPath().hashCode();
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.FileStatus
 * JD-Core Version:    0.6.1
 */
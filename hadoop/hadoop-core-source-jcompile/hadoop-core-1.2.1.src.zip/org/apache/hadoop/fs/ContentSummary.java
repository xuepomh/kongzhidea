/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ 
/*     */ public class ContentSummary
/*     */   implements Writable
/*     */ {
/*     */   private long length;
/*     */   private long fileCount;
/*     */   private long directoryCount;
/*     */   private long quota;
/*     */   private long spaceConsumed;
/*     */   private long spaceQuota;
/*     */   private static final String STRING_FORMAT = "%12d %12d %18d ";
/*     */   private static final String QUOTA_STRING_FORMAT = "%12s %15s ";
/*     */   private static final String SPACE_QUOTA_STRING_FORMAT = "%15s %15s ";
/* 109 */   private static final String HEADER = String.format("%12d %12d %18d ".replace('d', 's'), new Object[] { "directories", "files", "bytes" });
/*     */ 
/* 112 */   private static final String QUOTA_HEADER = String.format("%12s %15s %15s %15s ", new Object[] { "quota", "remaining quota", "space quota", "reamaining quota" }) + HEADER;
/*     */ 
/*     */   public ContentSummary()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ContentSummary(long length, long fileCount, long directoryCount)
/*     */   {
/*  41 */     this(length, fileCount, directoryCount, -1L, length, -1L);
/*     */   }
/*     */ 
/*     */   public ContentSummary(long length, long fileCount, long directoryCount, long quota, long spaceConsumed, long spaceQuota)
/*     */   {
/*  48 */     this.length = length;
/*  49 */     this.fileCount = fileCount;
/*  50 */     this.directoryCount = directoryCount;
/*  51 */     this.quota = quota;
/*  52 */     this.spaceConsumed = spaceConsumed;
/*  53 */     this.spaceQuota = spaceQuota;
/*     */   }
/*     */ 
/*     */   public long getLength() {
/*  57 */     return this.length;
/*     */   }
/*     */   public long getDirectoryCount() {
/*  60 */     return this.directoryCount;
/*     */   }
/*     */   public long getFileCount() {
/*  63 */     return this.fileCount;
/*     */   }
/*     */   public long getQuota() {
/*  66 */     return this.quota;
/*     */   }
/*     */   public long getSpaceConsumed() {
/*  69 */     return this.spaceConsumed;
/*     */   }
/*     */   public long getSpaceQuota() {
/*  72 */     return this.spaceQuota;
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out) throws IOException {
/*  76 */     out.writeLong(this.length);
/*  77 */     out.writeLong(this.fileCount);
/*  78 */     out.writeLong(this.directoryCount);
/*  79 */     out.writeLong(this.quota);
/*  80 */     out.writeLong(this.spaceConsumed);
/*  81 */     out.writeLong(this.spaceQuota);
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException
/*     */   {
/*  86 */     this.length = in.readLong();
/*  87 */     this.fileCount = in.readLong();
/*  88 */     this.directoryCount = in.readLong();
/*  89 */     this.quota = in.readLong();
/*  90 */     this.spaceConsumed = in.readLong();
/*  91 */     this.spaceQuota = in.readLong();
/*     */   }
/*     */ 
/*     */   public static String getHeader(boolean qOption)
/*     */   {
/* 125 */     return qOption ? QUOTA_HEADER : HEADER;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 130 */     return toString(true);
/*     */   }
/*     */ 
/*     */   public String toString(boolean qOption)
/*     */   {
/* 141 */     String prefix = "";
/* 142 */     if (qOption) {
/* 143 */       String quotaStr = "none";
/* 144 */       String quotaRem = "inf";
/* 145 */       String spaceQuotaStr = "none";
/* 146 */       String spaceQuotaRem = "inf";
/*     */ 
/* 148 */       if (this.quota > 0L) {
/* 149 */         quotaStr = Long.toString(this.quota);
/* 150 */         quotaRem = Long.toString(this.quota - (this.directoryCount + this.fileCount));
/*     */       }
/* 152 */       if (this.spaceQuota > 0L) {
/* 153 */         spaceQuotaStr = Long.toString(this.spaceQuota);
/* 154 */         spaceQuotaRem = Long.toString(this.spaceQuota - this.spaceConsumed);
/*     */       }
/*     */ 
/* 157 */       prefix = String.format("%12s %15s %15s %15s ", new Object[] { quotaStr, quotaRem, spaceQuotaStr, spaceQuotaRem });
/*     */     }
/*     */ 
/* 161 */     return prefix + String.format("%12d %12d %18d ", new Object[] { Long.valueOf(this.directoryCount), Long.valueOf(this.fileCount), Long.valueOf(this.length) });
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.ContentSummary
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.io.MD5Hash;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.WritableUtils;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.znerd.xmlenc.XMLOutputter;
/*     */ 
/*     */ public class MD5MD5CRC32FileChecksum extends FileChecksum
/*     */ {
/*     */   public static final int LENGTH = 28;
/*     */   private int bytesPerCRC;
/*     */   private long crcPerBlock;
/*     */   private MD5Hash md5;
/*     */ 
/*     */   public MD5MD5CRC32FileChecksum()
/*     */   {
/*  41 */     this(0, 0L, null);
/*     */   }
/*     */ 
/*     */   public MD5MD5CRC32FileChecksum(int bytesPerCRC, long crcPerBlock, MD5Hash md5)
/*     */   {
/*  46 */     this.bytesPerCRC = bytesPerCRC;
/*  47 */     this.crcPerBlock = crcPerBlock;
/*  48 */     this.md5 = md5;
/*     */   }
/*     */ 
/*     */   public String getAlgorithmName()
/*     */   {
/*  53 */     return "MD5-of-" + this.crcPerBlock + "MD5-of-" + this.bytesPerCRC + "CRC32";
/*     */   }
/*     */ 
/*     */   public int getLength() {
/*  57 */     return 28;
/*     */   }
/*     */ 
/*     */   public byte[] getBytes() {
/*  61 */     return WritableUtils.toByteArray(new Writable[] { this });
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException
/*     */   {
/*  66 */     this.bytesPerCRC = in.readInt();
/*  67 */     this.crcPerBlock = in.readLong();
/*  68 */     this.md5 = MD5Hash.read(in);
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out) throws IOException
/*     */   {
/*  73 */     out.writeInt(this.bytesPerCRC);
/*  74 */     out.writeLong(this.crcPerBlock);
/*  75 */     this.md5.write(out);
/*     */   }
/*     */ 
/*     */   public static void write(XMLOutputter xml, MD5MD5CRC32FileChecksum that)
/*     */     throws IOException
/*     */   {
/*  81 */     xml.startTag(MD5MD5CRC32FileChecksum.class.getName());
/*  82 */     if (that != null) {
/*  83 */       xml.attribute("bytesPerCRC", "" + that.bytesPerCRC);
/*  84 */       xml.attribute("crcPerBlock", "" + that.crcPerBlock);
/*  85 */       xml.attribute("md5", "" + that.md5);
/*     */     }
/*  87 */     xml.endTag();
/*     */   }
/*     */ 
/*     */   public static MD5MD5CRC32FileChecksum valueOf(Attributes attrs)
/*     */     throws SAXException
/*     */   {
/*  93 */     String bytesPerCRC = attrs.getValue("bytesPerCRC");
/*  94 */     String crcPerBlock = attrs.getValue("crcPerBlock");
/*  95 */     String md5 = attrs.getValue("md5");
/*  96 */     if ((bytesPerCRC == null) || (crcPerBlock == null) || (md5 == null)) {
/*  97 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 101 */       return new MD5MD5CRC32FileChecksum(Integer.valueOf(bytesPerCRC).intValue(), Integer.valueOf(crcPerBlock).intValue(), new MD5Hash(md5));
/*     */     }
/*     */     catch (Exception e) {
/* 104 */       throw new SAXException("Invalid attributes: bytesPerCRC=" + bytesPerCRC + ", crcPerBlock=" + crcPerBlock + ", md5=" + md5, e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 111 */     return getAlgorithmName() + ":" + this.md5;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.MD5MD5CRC32FileChecksum
 * JD-Core Version:    0.6.1
 */
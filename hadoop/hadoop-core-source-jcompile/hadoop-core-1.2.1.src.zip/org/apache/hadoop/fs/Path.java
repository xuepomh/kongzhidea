/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ 
/*     */ public class Path
/*     */   implements Comparable
/*     */ {
/*     */   public static final String SEPARATOR = "/";
/*     */   public static final char SEPARATOR_CHAR = '/';
/*     */   public static final String CUR_DIR = ".";
/*  38 */   static final boolean WINDOWS = System.getProperty("os.name").startsWith("Windows");
/*     */   private URI uri;
/*     */ 
/*     */   public Path(String parent, String child)
/*     */   {
/*  45 */     this(new Path(parent), new Path(child));
/*     */   }
/*     */ 
/*     */   public Path(Path parent, String child)
/*     */   {
/*  50 */     this(parent, new Path(child));
/*     */   }
/*     */ 
/*     */   public Path(String parent, Path child)
/*     */   {
/*  55 */     this(new Path(parent), child);
/*     */   }
/*     */ 
/*     */   public Path(Path parent, Path child)
/*     */   {
/*  61 */     URI parentUri = parent.uri;
/*  62 */     String parentPath = parentUri.getPath();
/*  63 */     if ((!parentPath.equals("/")) && (!parentPath.equals("")))
/*     */       try {
/*  65 */         parentUri = new URI(parentUri.getScheme(), parentUri.getAuthority(), parentUri.getPath() + "/", null, parentUri.getFragment());
/*     */       }
/*     */       catch (URISyntaxException e) {
/*  68 */         throw new IllegalArgumentException(e);
/*     */       }
/*  70 */     URI resolved = parentUri.resolve(child.uri);
/*  71 */     initialize(resolved.getScheme(), resolved.getAuthority(), normalizePath(resolved.getPath()), resolved.getFragment());
/*     */   }
/*     */ 
/*     */   private void checkPathArg(String path)
/*     */   {
/*  77 */     if (path == null) {
/*  78 */       throw new IllegalArgumentException("Can not create a Path from a null string");
/*     */     }
/*     */ 
/*  81 */     if (path.length() == 0)
/*  82 */       throw new IllegalArgumentException("Can not create a Path from an empty string");
/*     */   }
/*     */ 
/*     */   public Path(String pathString)
/*     */   {
/*  90 */     checkPathArg(pathString);
/*     */ 
/*  96 */     if (hasWindowsDrive(pathString, false)) {
/*  97 */       pathString = "/" + pathString;
/*     */     }
/*     */ 
/* 100 */     String scheme = null;
/* 101 */     String authority = null;
/*     */ 
/* 103 */     int start = 0;
/*     */ 
/* 106 */     int colon = pathString.indexOf(':');
/* 107 */     int slash = pathString.indexOf('/');
/* 108 */     if ((colon != -1) && ((slash == -1) || (colon < slash)))
/*     */     {
/* 110 */       scheme = pathString.substring(0, colon);
/* 111 */       start = colon + 1;
/*     */     }
/*     */ 
/* 115 */     if ((pathString.startsWith("//", start)) && (pathString.length() - start > 2))
/*     */     {
/* 117 */       int nextSlash = pathString.indexOf('/', start + 2);
/* 118 */       int authEnd = nextSlash > 0 ? nextSlash : pathString.length();
/* 119 */       authority = pathString.substring(start + 2, authEnd);
/* 120 */       start = authEnd;
/*     */     }
/*     */ 
/* 124 */     String path = pathString.substring(start, pathString.length());
/*     */ 
/* 126 */     initialize(scheme, authority, path, null);
/*     */   }
/*     */ 
/*     */   public Path(String scheme, String authority, String path)
/*     */   {
/* 131 */     checkPathArg(path);
/* 132 */     initialize(scheme, authority, path, null);
/*     */   }
/*     */ 
/*     */   public Path(URI aUri)
/*     */   {
/* 139 */     this.uri = aUri;
/*     */   }
/*     */ 
/*     */   private void initialize(String scheme, String authority, String path, String fragment)
/*     */   {
/*     */     try {
/* 145 */       this.uri = new URI(scheme, authority, normalizePath(path), null, fragment).normalize();
/*     */     }
/*     */     catch (URISyntaxException e) {
/* 148 */       throw new IllegalArgumentException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String normalizePath(String path)
/*     */   {
/* 154 */     if (path.indexOf("//") != -1) {
/* 155 */       path = path.replace("//", "/");
/*     */     }
/* 157 */     if ((WINDOWS) && (path.indexOf("\\") != -1)) {
/* 158 */       path = path.replace("\\", "/");
/*     */     }
/*     */ 
/* 162 */     int minLength = hasWindowsDrive(path, true) ? 4 : 1;
/* 163 */     if ((path.length() > minLength) && (path.endsWith("/"))) {
/* 164 */       path = path.substring(0, path.length() - 1);
/*     */     }
/*     */ 
/* 167 */     return path;
/*     */   }
/*     */ 
/*     */   private boolean hasWindowsDrive(String path, boolean slashed) {
/* 171 */     if (!WINDOWS) return false;
/* 172 */     int start = slashed ? 1 : 0;
/* 173 */     return (path.length() >= start + 2) && ((!slashed) || (path.charAt(0) == '/')) && (path.charAt(start + 1) == ':') && (((path.charAt(start) >= 'A') && (path.charAt(start) <= 'Z')) || ((path.charAt(start) >= 'a') && (path.charAt(start) <= 'z')));
/*     */   }
/*     */ 
/*     */   public URI toUri()
/*     */   {
/* 183 */     return this.uri;
/*     */   }
/*     */ 
/*     */   public FileSystem getFileSystem(Configuration conf) throws IOException {
/* 187 */     return FileSystem.get(toUri(), conf);
/*     */   }
/*     */ 
/*     */   public boolean isAbsolute()
/*     */   {
/* 192 */     int start = hasWindowsDrive(this.uri.getPath(), true) ? 3 : 0;
/* 193 */     return this.uri.getPath().startsWith("/", start);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 198 */     String path = this.uri.getPath();
/* 199 */     int slash = path.lastIndexOf("/");
/* 200 */     return path.substring(slash + 1);
/*     */   }
/*     */ 
/*     */   public Path getParent()
/*     */   {
/* 205 */     String path = this.uri.getPath();
/* 206 */     int lastSlash = path.lastIndexOf('/');
/* 207 */     int start = hasWindowsDrive(path, true) ? 3 : 0;
/* 208 */     if ((path.length() == start) || ((lastSlash == start) && (path.length() == start + 1)))
/*     */     {
/* 210 */       return null;
/*     */     }
/*     */     String parent;
/*     */     String parent;
/* 213 */     if (lastSlash == -1) {
/* 214 */       parent = ".";
/*     */     } else {
/* 216 */       int end = hasWindowsDrive(path, true) ? 3 : 0;
/* 217 */       parent = path.substring(0, lastSlash == end ? end + 1 : lastSlash);
/*     */     }
/* 219 */     return new Path(this.uri.getScheme(), this.uri.getAuthority(), parent);
/*     */   }
/*     */ 
/*     */   public Path suffix(String suffix)
/*     */   {
/* 224 */     return new Path(getParent(), getName() + suffix);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 230 */     StringBuffer buffer = new StringBuffer();
/* 231 */     if (this.uri.getScheme() != null) {
/* 232 */       buffer.append(this.uri.getScheme());
/* 233 */       buffer.append(":");
/*     */     }
/* 235 */     if (this.uri.getAuthority() != null) {
/* 236 */       buffer.append("//");
/* 237 */       buffer.append(this.uri.getAuthority());
/*     */     }
/* 239 */     if (this.uri.getPath() != null) {
/* 240 */       String path = this.uri.getPath();
/* 241 */       if ((path.indexOf('/') == 0) && (hasWindowsDrive(path, true)) && (this.uri.getScheme() == null) && (this.uri.getAuthority() == null))
/*     */       {
/* 245 */         path = path.substring(1);
/* 246 */       }buffer.append(path);
/*     */     }
/* 248 */     if (this.uri.getFragment() != null) {
/* 249 */       buffer.append("#");
/* 250 */       buffer.append(this.uri.getFragment());
/*     */     }
/* 252 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o) {
/* 256 */     if (!(o instanceof Path)) {
/* 257 */       return false;
/*     */     }
/* 259 */     Path that = (Path)o;
/* 260 */     return this.uri.equals(that.uri);
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 264 */     return this.uri.hashCode();
/*     */   }
/*     */ 
/*     */   public int compareTo(Object o) {
/* 268 */     Path that = (Path)o;
/* 269 */     return this.uri.compareTo(that.uri);
/*     */   }
/*     */ 
/*     */   public int depth()
/*     */   {
/* 274 */     String path = this.uri.getPath();
/* 275 */     int depth = 0;
/* 276 */     int slash = (path.length() == 1) && (path.charAt(0) == '/') ? -1 : 0;
/* 277 */     while (slash != -1) {
/* 278 */       depth++;
/* 279 */       slash = path.indexOf("/", slash + 1);
/*     */     }
/* 281 */     return depth;
/*     */   }
/*     */ 
/*     */   public Path makeQualified(FileSystem fs)
/*     */   {
/* 286 */     Path path = this;
/* 287 */     if (!isAbsolute()) {
/* 288 */       path = new Path(fs.getWorkingDirectory(), this);
/*     */     }
/*     */ 
/* 291 */     URI pathUri = path.toUri();
/* 292 */     URI fsUri = fs.getUri();
/*     */ 
/* 294 */     String scheme = pathUri.getScheme();
/* 295 */     String authority = pathUri.getAuthority();
/* 296 */     String fragment = pathUri.getFragment();
/* 297 */     if ((scheme != null) && ((authority != null) || (fsUri.getAuthority() == null)))
/*     */     {
/* 299 */       return path;
/*     */     }
/* 301 */     if (scheme == null) {
/* 302 */       scheme = fsUri.getScheme();
/*     */     }
/*     */ 
/* 305 */     if (authority == null) {
/* 306 */       authority = fsUri.getAuthority();
/* 307 */       if (authority == null) {
/* 308 */         authority = "";
/*     */       }
/*     */     }
/*     */ 
/* 312 */     URI newUri = null;
/*     */     try {
/* 314 */       newUri = new URI(scheme, authority, normalizePath(pathUri.getPath()), null, fragment);
/*     */     }
/*     */     catch (URISyntaxException e) {
/* 317 */       throw new IllegalArgumentException(e);
/*     */     }
/* 319 */     return new Path(newUri);
/*     */   }
/*     */ 
/*     */   public Path makeQualified(URI defaultUri, Path workingDir)
/*     */   {
/* 324 */     Path path = this;
/* 325 */     if (!isAbsolute()) {
/* 326 */       path = new Path(workingDir, this);
/*     */     }
/*     */ 
/* 329 */     URI pathUri = path.toUri();
/*     */ 
/* 331 */     String scheme = pathUri.getScheme();
/* 332 */     String authority = pathUri.getAuthority();
/* 333 */     String fragment = pathUri.getFragment();
/*     */ 
/* 335 */     if ((scheme != null) && ((authority != null) || (defaultUri.getAuthority() == null)))
/*     */     {
/* 337 */       return path;
/*     */     }
/* 339 */     if (scheme == null) {
/* 340 */       scheme = defaultUri.getScheme();
/*     */     }
/*     */ 
/* 343 */     if (authority == null) {
/* 344 */       authority = defaultUri.getAuthority();
/* 345 */       if (authority == null) {
/* 346 */         authority = "";
/*     */       }
/*     */     }
/*     */ 
/* 350 */     URI newUri = null;
/*     */     try {
/* 352 */       newUri = new URI(scheme, authority, normalizePath(pathUri.getPath()), null, fragment);
/*     */     }
/*     */     catch (URISyntaxException e) {
/* 355 */       throw new IllegalArgumentException(e);
/*     */     }
/* 357 */     return new Path(newUri);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.Path
 * JD-Core Version:    0.6.1
 */
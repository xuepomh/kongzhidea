package org.apache.hadoop.fs;

public class CommonConfigurationKeys
{
  public static final String FS_DEFAULT_NAME_KEY = "fs.default.name";
  public static final String FS_DEFAULT_NAME_DEFAULT = "file:///";
  public static final String HADOOP_SECURITY_GROUP_MAPPING = "hadoop.security.group.mapping";
  public static final String HADOOP_SECURITY_AUTHENTICATION = "hadoop.security.authentication";
  public static final String HADOOP_SECURITY_AUTHORIZATION = "hadoop.security.authorization";
  public static final String HADOOP_SECURITY_INSTRUMENTATION_REQUIRES_ADMIN = "hadoop.security.instrumentation.requires.admin";
  public static final String HADOOP_SECURITY_SERVICE_USER_NAME_KEY = "hadoop.security.service.user.name.key";
  public static final String HADOOP_SECURITY_TOKEN_SERVICE_USE_IP = "hadoop.security.token.service.use_ip";
  public static final boolean HADOOP_SECURITY_TOKEN_SERVICE_USE_IP_DEFAULT = true;
  public static final String HADOOP_SECURITY_USE_WEAK_HTTP_CRYPTO_KEY = "hadoop.security.use-weak-http-crypto";
  public static final boolean HADOOP_SECURITY_USE_WEAK_HTTP_CRYPTO_DEFAULT = false;
  public static final String IPC_SERVER_RPC_READ_THREADS_KEY = "ipc.server.read.threadpool.size";
  public static final int IPC_SERVER_RPC_READ_THREADS_DEFAULT = 1;
  public static final String IO_NATIVE_LIB_AVAILABLE_KEY = "hadoop.native.lib";
  public static final boolean IO_NATIVE_LIB_AVAILABLE_DEFAULT = true;
  public static final String IO_COMPRESSION_CODEC_SNAPPY_BUFFERSIZE_KEY = "io.compression.codec.snappy.buffersize";
  public static final int IO_COMPRESSION_CODEC_SNAPPY_BUFFERSIZE_DEFAULT = 262144;
  public static final String HADOOP_RELAXED_VERSION_CHECK_KEY = "hadoop.relaxed.worker.version.check";
  public static final boolean HADOOP_RELAXED_VERSION_CHECK_DEFAULT = false;
  public static final String HADOOP_SKIP_VERSION_CHECK_KEY = "hadoop.skip.worker.version.check";
  public static final boolean HADOOP_SKIP_VERSION_CHECK_DEFAULT = false;
  public static final String HADOOP_JETTY_LOGS_SERVE_ALIASES = "hadoop.jetty.logs.serve.aliases";
  public static final boolean DEFAULT_HADOOP_JETTY_LOGS_SERVE_ALIASES = true;
  public static final String IPC_CLIENT_FALLBACK_TO_SIMPLE_AUTH_ALLOWED_KEY = "ipc.client.fallback-to-simple-auth-allowed";
  public static final boolean IPC_CLIENT_FALLBACK_TO_SIMPLE_AUTH_ALLOWED_DEFAULT = false;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.CommonConfigurationKeys
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.conf.Configured;
/*     */ import org.apache.hadoop.fs.permission.FsAction;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ public class Trash extends Configured
/*     */ {
/*  40 */   private static final Log LOG = LogFactory.getLog(Trash.class);
/*     */ 
/*  43 */   private static final Path CURRENT = new Path("Current");
/*  44 */   private static final Path TRASH = new Path(".Trash/");
/*  45 */   private static final Path HOMES = new Path("/user/");
/*     */ 
/*  47 */   private static final FsPermission PERMISSION = new FsPermission(FsAction.ALL, FsAction.NONE, FsAction.NONE);
/*     */ 
/*  50 */   private static final DateFormat CHECKPOINT = new SimpleDateFormat("yyMMddHHmm");
/*     */   private static final int MSECS_PER_MINUTE = 60000;
/*     */   private final FileSystem fs;
/*     */   private final Path trash;
/*     */   private final Path current;
/*     */   private final long interval;
/*     */ 
/*     */   public Trash(Configuration conf)
/*     */     throws IOException
/*     */   {
/*  62 */     this(FileSystem.get(conf), conf);
/*     */   }
/*     */ 
/*     */   public Trash(FileSystem fs, Configuration conf)
/*     */     throws IOException
/*     */   {
/*  69 */     super(conf);
/*  70 */     this.fs = fs;
/*  71 */     this.trash = new Path(fs.getHomeDirectory(), TRASH);
/*  72 */     this.current = new Path(this.trash, CURRENT);
/*  73 */     this.interval = (conf.getLong("fs.trash.interval", 60L) * 60000L);
/*     */   }
/*     */ 
/*     */   private Trash(Path home, Configuration conf) throws IOException {
/*  77 */     super(conf);
/*  78 */     this.fs = home.getFileSystem(conf);
/*  79 */     this.trash = new Path(home, TRASH);
/*  80 */     this.current = new Path(this.trash, CURRENT);
/*  81 */     this.interval = (conf.getLong("fs.trash.interval", 60L) * 60000L);
/*     */   }
/*     */ 
/*     */   private Path makeTrashRelativePath(Path basePath, Path rmFilePath) {
/*  85 */     return new Path(basePath + rmFilePath.toUri().getPath());
/*     */   }
/*     */ 
/*     */   public boolean moveToTrash(Path path)
/*     */     throws IOException
/*     */   {
/*  92 */     if (this.interval == 0L) {
/*  93 */       return false;
/*     */     }
/*  95 */     if (!path.isAbsolute()) {
/*  96 */       path = new Path(this.fs.getWorkingDirectory(), path);
/*     */     }
/*  98 */     if (!this.fs.exists(path)) {
/*  99 */       throw new FileNotFoundException(path.toString());
/*     */     }
/* 101 */     String qpath = path.makeQualified(this.fs).toString();
/*     */ 
/* 103 */     if (qpath.startsWith(this.trash.toString())) {
/* 104 */       return false;
/*     */     }
/*     */ 
/* 107 */     if (this.trash.getParent().toString().startsWith(qpath)) {
/* 108 */       throw new IOException("Cannot move \"" + path + "\" to the trash, as it contains the trash");
/*     */     }
/*     */ 
/* 112 */     Path trashPath = makeTrashRelativePath(this.current, path);
/* 113 */     Path baseTrashPath = makeTrashRelativePath(this.current, path.getParent());
/*     */ 
/* 115 */     IOException cause = null;
/*     */ 
/* 118 */     for (int i = 0; i < 2; i++) {
/*     */       try {
/* 120 */         if (!this.fs.mkdirs(baseTrashPath, PERMISSION)) {
/* 121 */           LOG.warn("Can't create(mkdir) trash directory: " + baseTrashPath);
/* 122 */           return false;
/*     */         }
/*     */       } catch (IOException e) {
/* 125 */         LOG.warn("Can't create trash directory: " + baseTrashPath);
/* 126 */         cause = e;
/* 127 */         break;
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 134 */         String orig = trashPath.toString();
/* 135 */         for (int j = 1; this.fs.exists(trashPath); j++) {
/* 136 */           trashPath = new Path(orig + "." + j);
/*     */         }
/* 138 */         if (this.fs.rename(path, trashPath))
/* 139 */           return true;
/*     */       } catch (IOException e) {
/* 141 */         cause = e;
/*     */       }
/*     */     }
/* 144 */     throw ((IOException)new IOException("Failed to move to trash: " + path).initCause(cause));
/*     */   }
/*     */ 
/*     */   public void checkpoint()
/*     */     throws IOException
/*     */   {
/* 150 */     if (!this.fs.exists(this.current))
/*     */       return;
/*     */     Path checkpoint;
/* 154 */     synchronized (CHECKPOINT) {
/* 155 */       checkpoint = new Path(this.trash, CHECKPOINT.format(new Date()));
/*     */     }
/*     */ 
/* 158 */     if (this.fs.rename(this.current, checkpoint))
/* 159 */       LOG.info("Created trash checkpoint: " + checkpoint.toUri().getPath());
/*     */     else
/* 161 */       throw new IOException("Failed to checkpoint trash: " + checkpoint);
/*     */   }
/*     */ 
/*     */   public void expunge()
/*     */     throws IOException
/*     */   {
/* 167 */     FileStatus[] dirs = this.fs.listStatus(this.trash);
/* 168 */     if (dirs == null) {
/* 169 */       return;
/*     */     }
/* 171 */     long now = System.currentTimeMillis();
/* 172 */     for (int i = 0; i < dirs.length; i++) {
/* 173 */       Path path = dirs[i].getPath();
/* 174 */       String dir = path.toUri().getPath();
/* 175 */       String name = path.getName();
/* 176 */       if (!name.equals(CURRENT.getName()))
/*     */       {
/*     */         long time;
/*     */         try
/*     */         {
/* 181 */           synchronized (CHECKPOINT) {
/* 182 */             time = CHECKPOINT.parse(name).getTime();
/*     */           }
/*     */         } catch (ParseException e) {
/* 185 */           LOG.warn("Unexpected item in trash: " + dir + ". Ignoring.");
/* 186 */           continue;
/*     */         }
/*     */ 
/* 189 */         if (now - this.interval > time)
/* 190 */           if (this.fs.delete(path, true))
/* 191 */             LOG.info("Deleted trash checkpoint: " + dir);
/*     */           else
/* 193 */             LOG.warn("Couldn't delete checkpoint: " + dir + " Ignoring.");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   Path getCurrentTrashDir()
/*     */   {
/* 203 */     return this.current;
/*     */   }
/*     */ 
/*     */   public Runnable getEmptier()
/*     */     throws IOException
/*     */   {
/* 211 */     return new Emptier(getConf());
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/* 285 */     new Trash(new Configuration()).getEmptier().run();
/*     */   }
/*     */ 
/*     */   private static class Emptier
/*     */     implements Runnable
/*     */   {
/*     */     private Configuration conf;
/*     */     private FileSystem fs;
/*     */     private long interval;
/*     */ 
/*     */     public Emptier(Configuration conf)
/*     */       throws IOException
/*     */     {
/* 221 */       this.conf = conf;
/* 222 */       this.interval = (conf.getLong("fs.trash.interval", 60L) * 60000L);
/* 223 */       this.fs = FileSystem.get(conf);
/*     */     }
/*     */ 
/*     */     public void run() {
/* 227 */       if (this.interval == 0L) {
/* 228 */         return;
/*     */       }
/* 230 */       long now = System.currentTimeMillis();
/*     */       while (true)
/*     */       {
/* 233 */         long end = ceiling(now, this.interval);
/*     */         try {
/* 235 */           Thread.sleep(end - now);
/*     */         } catch (InterruptedException e) {
/* 237 */           return;
/*     */         }
/*     */         try
/*     */         {
/* 241 */           now = System.currentTimeMillis();
/* 242 */           if (now >= end)
/*     */           {
/* 244 */             FileStatus[] homes = null;
/*     */             try {
/* 246 */               homes = this.fs.listStatus(Trash.HOMES);
/*     */             } catch (IOException e) {
/* 248 */               Trash.LOG.warn("Trash can't list homes: " + e + " Sleeping.");
/* 249 */             }continue;
/*     */ 
/* 252 */             if (homes == null) {
/*     */               continue;
/*     */             }
/* 255 */             for (FileStatus home : homes)
/* 256 */               if (home.isDir())
/*     */                 try
/*     */                 {
/* 259 */                   Trash trash = new Trash(home.getPath(), this.conf, null);
/* 260 */                   trash.expunge();
/* 261 */                   trash.checkpoint();
/*     */                 } catch (IOException e) {
/* 263 */                   Trash.LOG.warn("Trash caught: " + e + ". Skipping " + home.getPath() + ".");
/*     */                 }
/*     */           }
/*     */         }
/*     */         catch (Exception e) {
/* 268 */           Trash.LOG.warn("RuntimeException during Trash.Emptier.run() " + StringUtils.stringifyException(e));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     private long ceiling(long time, long interval)
/*     */     {
/* 275 */       return floor(time, interval) + interval;
/*     */     }
/*     */     private long floor(long time, long interval) {
/* 278 */       return time / interval * interval;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.Trash
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.io.Text;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.WritableFactories;
/*     */ import org.apache.hadoop.io.WritableFactory;
/*     */ 
/*     */ public class BlockLocation
/*     */   implements Writable
/*     */ {
/*     */   private String[] hosts;
/*     */   private String[] names;
/*     */   private String[] topologyPaths;
/*     */   private long offset;
/*     */   private long length;
/*     */ 
/*     */   public BlockLocation()
/*     */   {
/*  49 */     this(new String[0], new String[0], 0L, 0L);
/*     */   }
/*     */ 
/*     */   public BlockLocation(String[] names, String[] hosts, long offset, long length)
/*     */   {
/*  57 */     if (names == null)
/*  58 */       this.names = new String[0];
/*     */     else {
/*  60 */       this.names = names;
/*     */     }
/*  62 */     if (hosts == null)
/*  63 */       this.hosts = new String[0];
/*     */     else {
/*  65 */       this.hosts = hosts;
/*     */     }
/*  67 */     this.offset = offset;
/*  68 */     this.length = length;
/*  69 */     this.topologyPaths = new String[0];
/*     */   }
/*     */ 
/*     */   public BlockLocation(String[] names, String[] hosts, String[] topologyPaths, long offset, long length)
/*     */   {
/*  77 */     this(names, hosts, offset, length);
/*  78 */     if (topologyPaths == null)
/*  79 */       this.topologyPaths = new String[0];
/*     */     else
/*  81 */       this.topologyPaths = topologyPaths;
/*     */   }
/*     */ 
/*     */   public String[] getHosts()
/*     */     throws IOException
/*     */   {
/*  89 */     if ((this.hosts == null) || (this.hosts.length == 0)) {
/*  90 */       return new String[0];
/*     */     }
/*  92 */     return this.hosts;
/*     */   }
/*     */ 
/*     */   public String[] getNames()
/*     */     throws IOException
/*     */   {
/* 100 */     if ((this.names == null) || (this.names.length == 0)) {
/* 101 */       return new String[0];
/*     */     }
/* 103 */     return this.names;
/*     */   }
/*     */ 
/*     */   public String[] getTopologyPaths()
/*     */     throws IOException
/*     */   {
/* 112 */     if ((this.topologyPaths == null) || (this.topologyPaths.length == 0)) {
/* 113 */       return new String[0];
/*     */     }
/* 115 */     return this.topologyPaths;
/*     */   }
/*     */ 
/*     */   public long getOffset()
/*     */   {
/* 123 */     return this.offset;
/*     */   }
/*     */ 
/*     */   public long getLength()
/*     */   {
/* 130 */     return this.length;
/*     */   }
/*     */ 
/*     */   public void setOffset(long offset)
/*     */   {
/* 137 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */   public void setLength(long length)
/*     */   {
/* 144 */     this.length = length;
/*     */   }
/*     */ 
/*     */   public void setHosts(String[] hosts)
/*     */     throws IOException
/*     */   {
/* 151 */     if (hosts == null)
/* 152 */       this.hosts = new String[0];
/*     */     else
/* 154 */       this.hosts = hosts;
/*     */   }
/*     */ 
/*     */   public void setNames(String[] names)
/*     */     throws IOException
/*     */   {
/* 162 */     if (names == null)
/* 163 */       this.names = new String[0];
/*     */     else
/* 165 */       this.names = names;
/*     */   }
/*     */ 
/*     */   public void setTopologyPaths(String[] topologyPaths)
/*     */     throws IOException
/*     */   {
/* 173 */     if (topologyPaths == null)
/* 174 */       this.topologyPaths = new String[0];
/*     */     else
/* 176 */       this.topologyPaths = topologyPaths;
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/* 184 */     out.writeLong(this.offset);
/* 185 */     out.writeLong(this.length);
/* 186 */     out.writeInt(this.names.length);
/* 187 */     for (int i = 0; i < this.names.length; i++) {
/* 188 */       Text name = new Text(this.names[i]);
/* 189 */       name.write(out);
/*     */     }
/* 191 */     out.writeInt(this.hosts.length);
/* 192 */     for (int i = 0; i < this.hosts.length; i++) {
/* 193 */       Text host = new Text(this.hosts[i]);
/* 194 */       host.write(out);
/*     */     }
/* 196 */     out.writeInt(this.topologyPaths.length);
/* 197 */     for (int i = 0; i < this.topologyPaths.length; i++) {
/* 198 */       Text host = new Text(this.topologyPaths[i]);
/* 199 */       host.write(out);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in)
/*     */     throws IOException
/*     */   {
/* 207 */     this.offset = in.readLong();
/* 208 */     this.length = in.readLong();
/* 209 */     int numNames = in.readInt();
/* 210 */     this.names = new String[numNames];
/* 211 */     for (int i = 0; i < numNames; i++) {
/* 212 */       Text name = new Text();
/* 213 */       name.readFields(in);
/* 214 */       this.names[i] = name.toString();
/*     */     }
/* 216 */     int numHosts = in.readInt();
/* 217 */     for (int i = 0; i < numHosts; i++) {
/* 218 */       Text host = new Text();
/* 219 */       host.readFields(in);
/* 220 */       this.hosts[i] = host.toString();
/*     */     }
/* 222 */     int numTops = in.readInt();
/* 223 */     Text path = new Text();
/* 224 */     for (int i = 0; i < numTops; i++) {
/* 225 */       path.readFields(in);
/* 226 */       this.topologyPaths[i] = path.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 231 */     StringBuilder result = new StringBuilder();
/* 232 */     result.append(this.offset);
/* 233 */     result.append(',');
/* 234 */     result.append(this.length);
/* 235 */     for (String h : this.hosts) {
/* 236 */       result.append(',');
/* 237 */       result.append(h);
/*     */     }
/* 239 */     return result.toString();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  32 */     WritableFactories.setFactory(BlockLocation.class, new WritableFactory()
/*     */     {
/*     */       public Writable newInstance() {
/*  35 */         return new BlockLocation();
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.BlockLocation
 * JD-Core Version:    0.6.1
 */
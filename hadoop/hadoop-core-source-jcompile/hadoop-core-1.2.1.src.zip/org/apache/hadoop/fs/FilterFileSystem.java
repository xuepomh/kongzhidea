/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.util.Progressable;
/*     */ 
/*     */ public class FilterFileSystem extends FileSystem
/*     */ {
/*     */   protected FileSystem fs;
/*     */ 
/*     */   public FilterFileSystem()
/*     */   {
/*     */   }
/*     */ 
/*     */   public FilterFileSystem(FileSystem fs)
/*     */   {
/*  55 */     this.fs = fs;
/*  56 */     this.statistics = fs.statistics;
/*     */   }
/*     */ 
/*     */   public void initialize(URI name, Configuration conf)
/*     */     throws IOException
/*     */   {
/*  65 */     this.fs.initialize(name, conf);
/*     */   }
/*     */ 
/*     */   public URI getUri()
/*     */   {
/*  70 */     return this.fs.getUri();
/*     */   }
/*     */ 
/*     */   public String getCanonicalServiceName()
/*     */   {
/*  75 */     return this.fs.getCanonicalServiceName();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public String getName() {
/*  80 */     return this.fs.getName();
/*     */   }
/*     */ 
/*     */   public Path makeQualified(Path path)
/*     */   {
/*  85 */     return this.fs.makeQualified(path);
/*     */   }
/*     */ 
/*     */   protected void checkPath(Path path)
/*     */   {
/*  94 */     this.fs.checkPath(path);
/*     */   }
/*     */ 
/*     */   public BlockLocation[] getFileBlockLocations(FileStatus file, long start, long len) throws IOException
/*     */   {
/*  99 */     return this.fs.getFileBlockLocations(file, start, len);
/*     */   }
/*     */ 
/*     */   public FSDataInputStream open(Path f, int bufferSize)
/*     */     throws IOException
/*     */   {
/* 108 */     return this.fs.open(f, bufferSize);
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream append(Path f, int bufferSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 114 */     return this.fs.append(f, bufferSize, progress);
/*     */   }
/*     */ 
/*     */   public void concat(Path f, Path[] psrcs) throws IOException
/*     */   {
/* 119 */     this.fs.concat(f, psrcs);
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream create(Path f, FsPermission permission, boolean overwrite, int bufferSize, short replication, long blockSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 126 */     return this.fs.create(f, permission, overwrite, bufferSize, replication, blockSize, progress);
/*     */   }
/*     */ 
/*     */   public boolean setReplication(Path src, short replication)
/*     */     throws IOException
/*     */   {
/* 140 */     return this.fs.setReplication(src, replication);
/*     */   }
/*     */ 
/*     */   public boolean rename(Path src, Path dst)
/*     */     throws IOException
/*     */   {
/* 148 */     return this.fs.rename(src, dst);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public boolean delete(Path f) throws IOException {
/* 153 */     return delete(f, true);
/*     */   }
/*     */ 
/*     */   public boolean delete(Path f, boolean recursive) throws IOException
/*     */   {
/* 158 */     return this.fs.delete(f, recursive);
/*     */   }
/*     */ 
/*     */   public FileStatus[] listStatus(Path f) throws IOException
/*     */   {
/* 163 */     return this.fs.listStatus(f);
/*     */   }
/*     */ 
/*     */   public Path getHomeDirectory() {
/* 167 */     return this.fs.getHomeDirectory();
/*     */   }
/*     */ 
/*     */   public void setWorkingDirectory(Path newDir)
/*     */   {
/* 178 */     this.fs.setWorkingDirectory(newDir);
/*     */   }
/*     */ 
/*     */   public Path getWorkingDirectory()
/*     */   {
/* 187 */     return this.fs.getWorkingDirectory();
/*     */   }
/*     */ 
/*     */   public boolean mkdirs(Path f, FsPermission permission)
/*     */     throws IOException
/*     */   {
/* 193 */     return this.fs.mkdirs(f, permission);
/*     */   }
/*     */ 
/*     */   public void copyFromLocalFile(boolean delSrc, Path src, Path dst)
/*     */     throws IOException
/*     */   {
/* 203 */     this.fs.copyFromLocalFile(delSrc, src, dst);
/*     */   }
/*     */ 
/*     */   public void copyToLocalFile(boolean delSrc, Path src, Path dst)
/*     */     throws IOException
/*     */   {
/* 213 */     this.fs.copyToLocalFile(delSrc, src, dst);
/*     */   }
/*     */ 
/*     */   public Path startLocalOutput(Path fsOutputFile, Path tmpLocalFile)
/*     */     throws IOException
/*     */   {
/* 224 */     return this.fs.startLocalOutput(fsOutputFile, tmpLocalFile);
/*     */   }
/*     */ 
/*     */   public void completeLocalOutput(Path fsOutputFile, Path tmpLocalFile)
/*     */     throws IOException
/*     */   {
/* 235 */     this.fs.completeLocalOutput(fsOutputFile, tmpLocalFile);
/*     */   }
/*     */ 
/*     */   public long getDefaultBlockSize()
/*     */   {
/* 241 */     return this.fs.getDefaultBlockSize();
/*     */   }
/*     */ 
/*     */   public short getDefaultReplication()
/*     */   {
/* 248 */     return this.fs.getDefaultReplication();
/*     */   }
/*     */ 
/*     */   public FileStatus getFileStatus(Path f)
/*     */     throws IOException
/*     */   {
/* 255 */     return this.fs.getFileStatus(f);
/*     */   }
/*     */ 
/*     */   public FileChecksum getFileChecksum(Path f) throws IOException
/*     */   {
/* 260 */     return this.fs.getFileChecksum(f);
/*     */   }
/*     */ 
/*     */   public void setVerifyChecksum(boolean verifyChecksum)
/*     */   {
/* 265 */     this.fs.setVerifyChecksum(verifyChecksum);
/*     */   }
/*     */ 
/*     */   public Configuration getConf()
/*     */   {
/* 270 */     return this.fs.getConf();
/*     */   }
/*     */ 
/*     */   public void close() throws IOException
/*     */   {
/* 275 */     super.close();
/* 276 */     this.fs.close();
/*     */   }
/*     */ 
/*     */   public void setOwner(Path p, String username, String groupname)
/*     */     throws IOException
/*     */   {
/* 283 */     this.fs.setOwner(p, username, groupname);
/*     */   }
/*     */ 
/*     */   public void setPermission(Path p, FsPermission permission)
/*     */     throws IOException
/*     */   {
/* 290 */     this.fs.setPermission(p, permission);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.FilterFileSystem
 * JD-Core Version:    0.6.1
 */
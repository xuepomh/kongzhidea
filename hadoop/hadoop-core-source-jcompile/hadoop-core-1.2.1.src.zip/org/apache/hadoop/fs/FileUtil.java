/*     */ package org.apache.hadoop.fs;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import org.apache.commons.io.FileUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.permission.FsAction;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.io.IOUtils;
/*     */ import org.apache.hadoop.io.nativeio.NativeIO;
/*     */ import org.apache.hadoop.util.Shell;
/*     */ import org.apache.hadoop.util.Shell.ShellCommandExecutor;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ public class FileUtil
/*     */ {
/*  40 */   private static final Log LOG = LogFactory.getLog(FileUtil.class);
/*     */ 
/*     */   public static Path[] stat2Paths(FileStatus[] stats)
/*     */   {
/*  50 */     if (stats == null)
/*  51 */       return null;
/*  52 */     Path[] ret = new Path[stats.length];
/*  53 */     for (int i = 0; i < stats.length; i++) {
/*  54 */       ret[i] = stats[i].getPath();
/*     */     }
/*  56 */     return ret;
/*     */   }
/*     */ 
/*     */   public static Path[] stat2Paths(FileStatus[] stats, Path path)
/*     */   {
/*  69 */     if (stats == null) {
/*  70 */       return new Path[] { path };
/*     */     }
/*  72 */     return stat2Paths(stats);
/*     */   }
/*     */ 
/*     */   public static boolean fullyDelete(File dir)
/*     */     throws IOException
/*     */   {
/*  80 */     if (!fullyDeleteContents(dir)) {
/*  81 */       return false;
/*     */     }
/*  83 */     return dir.delete();
/*     */   }
/*     */ 
/*     */   public static boolean fullyDeleteContents(File dir)
/*     */     throws IOException
/*     */   {
/*  91 */     boolean deletionSucceeded = true;
/*  92 */     File[] contents = dir.listFiles();
/*  93 */     if (contents != null) {
/*  94 */       for (int i = 0; i < contents.length; i++) {
/*  95 */         if (contents[i].isFile()) {
/*  96 */           if (!contents[i].delete()) {
/*  97 */             deletionSucceeded = false;
/*     */           }
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 103 */           boolean b = false;
/* 104 */           b = contents[i].delete();
/* 105 */           if (!b)
/*     */           {
/* 111 */             if (!fullyDelete(contents[i])) {
/* 112 */               deletionSucceeded = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 118 */     return deletionSucceeded;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static void fullyDelete(FileSystem fs, Path dir)
/*     */     throws IOException
/*     */   {
/* 132 */     fs.delete(dir, true);
/*     */   }
/*     */ 
/*     */   private static void checkDependencies(FileSystem srcFS, Path src, FileSystem dstFS, Path dst)
/*     */     throws IOException
/*     */   {
/* 144 */     if (srcFS == dstFS) {
/* 145 */       String srcq = new StringBuilder().append(src.makeQualified(srcFS).toString()).append("/").toString();
/* 146 */       String dstq = new StringBuilder().append(dst.makeQualified(dstFS).toString()).append("/").toString();
/* 147 */       if (dstq.startsWith(srcq)) {
/* 148 */         if (srcq.length() == dstq.length()) {
/* 149 */           throw new IOException(new StringBuilder().append("Cannot copy ").append(src).append(" to itself.").toString());
/*     */         }
/* 151 */         throw new IOException(new StringBuilder().append("Cannot copy ").append(src).append(" to its subdirectory ").append(dst).toString());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean copy(FileSystem srcFS, Path src, FileSystem dstFS, Path dst, boolean deleteSource, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 163 */     return copy(srcFS, src, dstFS, dst, deleteSource, true, conf);
/*     */   }
/*     */ 
/*     */   public static boolean copy(FileSystem srcFS, Path[] srcs, FileSystem dstFS, Path dst, boolean deleteSource, boolean overwrite, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 171 */     boolean gotException = false;
/* 172 */     boolean returnVal = true;
/* 173 */     StringBuffer exceptions = new StringBuffer();
/*     */ 
/* 175 */     if (srcs.length == 1) {
/* 176 */       return copy(srcFS, srcs[0], dstFS, dst, deleteSource, overwrite, conf);
/*     */     }
/*     */ 
/* 179 */     if (!dstFS.exists(dst)) {
/* 180 */       throw new IOException(new StringBuilder().append("`").append(dst).append("': specified destination directory ").append("does not exist").toString());
/*     */     }
/*     */ 
/* 183 */     FileStatus sdst = dstFS.getFileStatus(dst);
/* 184 */     if (!sdst.isDir()) {
/* 185 */       throw new IOException(new StringBuilder().append("copying multiple files, but last argument `").append(dst).append("' is not a directory").toString());
/*     */     }
/*     */ 
/* 189 */     for (Path src : srcs) {
/*     */       try {
/* 191 */         if (!copy(srcFS, src, dstFS, dst, deleteSource, overwrite, conf))
/* 192 */           returnVal = false;
/*     */       } catch (IOException e) {
/* 194 */         gotException = true;
/* 195 */         exceptions.append(e.getMessage());
/* 196 */         exceptions.append("\n");
/*     */       }
/*     */     }
/* 199 */     if (gotException) {
/* 200 */       throw new IOException(exceptions.toString());
/*     */     }
/* 202 */     return returnVal;
/*     */   }
/*     */ 
/*     */   public static boolean copy(FileSystem srcFS, Path src, FileSystem dstFS, Path dst, boolean deleteSource, boolean overwrite, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 211 */     dst = checkDest(src.getName(), dstFS, dst, overwrite);
/*     */ 
/* 213 */     if (srcFS.getFileStatus(src).isDir()) {
/* 214 */       checkDependencies(srcFS, src, dstFS, dst);
/* 215 */       if (!dstFS.mkdirs(dst)) {
/* 216 */         return false;
/*     */       }
/* 218 */       FileStatus[] contents = srcFS.listStatus(src);
/* 219 */       for (int i = 0; i < contents.length; i++) {
/* 220 */         copy(srcFS, contents[i].getPath(), dstFS, new Path(dst, contents[i].getPath().getName()), deleteSource, overwrite, conf);
/*     */       }
/*     */ 
/*     */     }
/* 224 */     else if (srcFS.isFile(src)) {
/* 225 */       InputStream in = null;
/* 226 */       OutputStream out = null;
/*     */       try {
/* 228 */         in = srcFS.open(src);
/* 229 */         out = dstFS.create(dst, overwrite);
/* 230 */         IOUtils.copyBytes(in, out, conf, true);
/*     */       } catch (IOException e) {
/* 232 */         IOUtils.closeStream(out);
/* 233 */         IOUtils.closeStream(in);
/* 234 */         throw e;
/*     */       }
/*     */     } else {
/* 237 */       throw new IOException(new StringBuilder().append(src.toString()).append(": No such file or directory").toString());
/*     */     }
/* 239 */     if (deleteSource) {
/* 240 */       return srcFS.delete(src, true);
/*     */     }
/* 242 */     return true;
/*     */   }
/*     */ 
/*     */   public static boolean copyMerge(FileSystem srcFS, Path srcDir, FileSystem dstFS, Path dstFile, boolean deleteSource, Configuration conf, String addString)
/*     */     throws IOException
/*     */   {
/* 252 */     dstFile = checkDest(srcDir.getName(), dstFS, dstFile, false);
/*     */ 
/* 254 */     if (!srcFS.getFileStatus(srcDir).isDir()) {
/* 255 */       return false;
/*     */     }
/* 257 */     OutputStream out = dstFS.create(dstFile);
/*     */     try
/*     */     {
/* 260 */       FileStatus[] contents = srcFS.listStatus(srcDir);
/* 261 */       for (int i = 0; i < contents.length; i++)
/* 262 */         if (!contents[i].isDir()) {
/* 263 */           InputStream in = srcFS.open(contents[i].getPath());
/*     */           try {
/* 265 */             IOUtils.copyBytes(in, out, conf, false);
/* 266 */             if (addString != null)
/* 267 */               out.write(addString.getBytes("UTF-8"));
/*     */           }
/*     */           finally
/*     */           {
/*     */           }
/*     */         }
/*     */     }
/*     */     finally {
/* 275 */       out.close();
/*     */     }
/*     */ 
/* 279 */     if (deleteSource) {
/* 280 */       return srcFS.delete(srcDir, true);
/*     */     }
/* 282 */     return true;
/*     */   }
/*     */ 
/*     */   public static boolean copy(File src, FileSystem dstFS, Path dst, boolean deleteSource, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 291 */     dst = checkDest(src.getName(), dstFS, dst, false);
/*     */ 
/* 293 */     if (src.isDirectory()) {
/* 294 */       if (!dstFS.mkdirs(dst)) {
/* 295 */         return false;
/*     */       }
/* 297 */       File[] contents = listFiles(src);
/* 298 */       for (int i = 0; i < contents.length; i++) {
/* 299 */         copy(contents[i], dstFS, new Path(dst, contents[i].getName()), deleteSource, conf);
/*     */       }
/*     */     }
/* 302 */     else if (src.isFile()) {
/* 303 */       InputStream in = null;
/* 304 */       OutputStream out = null;
/*     */       try {
/* 306 */         in = new FileInputStream(src);
/* 307 */         out = dstFS.create(dst);
/* 308 */         IOUtils.copyBytes(in, out, conf);
/*     */       } catch (IOException e) {
/* 310 */         IOUtils.closeStream(out);
/* 311 */         IOUtils.closeStream(in);
/* 312 */         throw e;
/*     */       }
/*     */     } else {
/* 315 */       throw new IOException(new StringBuilder().append(src.toString()).append(": No such file or directory").toString());
/*     */     }
/*     */ 
/* 318 */     if (deleteSource) {
/* 319 */       return fullyDelete(src);
/*     */     }
/* 321 */     return true;
/*     */   }
/*     */ 
/*     */   public static boolean copy(FileSystem srcFS, Path src, File dst, boolean deleteSource, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 329 */     if (srcFS.getFileStatus(src).isDir()) {
/* 330 */       if (!dst.mkdirs()) {
/* 331 */         return false;
/*     */       }
/* 333 */       FileStatus[] contents = srcFS.listStatus(src);
/* 334 */       for (int i = 0; i < contents.length; i++) {
/* 335 */         copy(srcFS, contents[i].getPath(), new File(dst, contents[i].getPath().getName()), deleteSource, conf);
/*     */       }
/*     */ 
/*     */     }
/* 339 */     else if (srcFS.isFile(src)) {
/* 340 */       InputStream in = srcFS.open(src);
/* 341 */       IOUtils.copyBytes(in, new FileOutputStream(dst), conf);
/*     */     } else {
/* 343 */       throw new IOException(new StringBuilder().append(src.toString()).append(": No such file or directory").toString());
/*     */     }
/*     */ 
/* 346 */     if (deleteSource) {
/* 347 */       return srcFS.delete(src, true);
/*     */     }
/* 349 */     return true;
/*     */   }
/*     */ 
/*     */   private static Path checkDest(String srcName, FileSystem dstFS, Path dst, boolean overwrite)
/*     */     throws IOException
/*     */   {
/* 355 */     if (dstFS.exists(dst)) {
/* 356 */       FileStatus sdst = dstFS.getFileStatus(dst);
/* 357 */       if (sdst.isDir()) {
/* 358 */         if (null == srcName) {
/* 359 */           throw new IOException(new StringBuilder().append("Target ").append(dst).append(" is a directory").toString());
/*     */         }
/* 361 */         return checkDest(null, dstFS, new Path(dst, srcName), overwrite);
/* 362 */       }if (!overwrite)
/* 363 */         throw new IOException(new StringBuilder().append("Target ").append(dst).append(" already exists").toString());
/*     */     }
/* 365 */     else if (dst.toString().isEmpty()) {
/* 366 */       return checkDest(null, dstFS, new Path(srcName), overwrite);
/*     */     }
/* 368 */     return dst;
/*     */   }
/*     */ 
/*     */   public static String makeShellPath(String filename)
/*     */     throws IOException
/*     */   {
/* 404 */     if (Path.WINDOWS) {
/* 405 */       return new CygPathCommand(filename).getResult();
/*     */     }
/* 407 */     return filename;
/*     */   }
/*     */ 
/*     */   public static String makeShellPath(File file)
/*     */     throws IOException
/*     */   {
/* 418 */     return makeShellPath(file, false);
/*     */   }
/*     */ 
/*     */   public static String makeShellPath(File file, boolean makeCanonicalPath)
/*     */     throws IOException
/*     */   {
/* 431 */     if (makeCanonicalPath) {
/* 432 */       return makeShellPath(file.getCanonicalPath());
/*     */     }
/* 434 */     return makeShellPath(file.toString());
/*     */   }
/*     */ 
/*     */   public static long getDU(File dir)
/*     */   {
/* 447 */     long size = 0L;
/* 448 */     if (!dir.exists())
/* 449 */       return 0L;
/* 450 */     if (!dir.isDirectory()) {
/* 451 */       return dir.length();
/*     */     }
/* 453 */     File[] allFiles = dir.listFiles();
/* 454 */     if (allFiles != null) {
/* 455 */       for (int i = 0; i < allFiles.length; i++) {
/*     */         boolean isSymLink;
/*     */         try {
/* 458 */           isSymLink = FileUtils.isSymlink(allFiles[i]);
/*     */         } catch (IOException ioe) {
/* 460 */           isSymLink = true;
/*     */         }
/* 462 */         if (!isSymLink) {
/* 463 */           size += getDU(allFiles[i]);
/*     */         }
/*     */       }
/*     */     }
/* 467 */     return size;
/*     */   }
/*     */ 
/*     */   public static void unZip(File inFile, File unzipDir)
/*     */     throws IOException
/*     */   {
/* 480 */     ZipFile zipFile = new ZipFile(inFile);
/*     */     try
/*     */     {
/* 483 */       Enumeration entries = zipFile.entries();
/* 484 */       while (entries.hasMoreElements()) {
/* 485 */         ZipEntry entry = (ZipEntry)entries.nextElement();
/* 486 */         if (!entry.isDirectory()) {
/* 487 */           InputStream in = zipFile.getInputStream(entry);
/*     */           try {
/* 489 */             File file = new File(unzipDir, entry.getName());
/* 490 */             if ((!file.getParentFile().mkdirs()) && 
/* 491 */               (!file.getParentFile().isDirectory())) {
/* 492 */               throw new IOException(new StringBuilder().append("Mkdirs failed to create ").append(file.getParentFile().toString()).toString());
/*     */             }
/*     */ 
/* 496 */             OutputStream out = new FileOutputStream(file);
/*     */             try {
/* 498 */               byte[] buffer = new byte[8192];
/*     */               int i;
/* 500 */               while ((i = in.read(buffer)) != -1)
/* 501 */                 out.write(buffer, 0, i);
/*     */             }
/*     */             finally {
/*     */             }
/*     */           }
/*     */           finally {
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     finally {
/* 512 */       zipFile.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void unTar(File inFile, File untarDir)
/*     */     throws IOException
/*     */   {
/* 527 */     if ((!untarDir.mkdirs()) && 
/* 528 */       (!untarDir.isDirectory())) {
/* 529 */       throw new IOException(new StringBuilder().append("Mkdirs failed to create ").append(untarDir).toString());
/*     */     }
/*     */ 
/* 533 */     StringBuffer untarCommand = new StringBuffer();
/* 534 */     boolean gzipped = inFile.toString().endsWith("gz");
/* 535 */     if (gzipped) {
/* 536 */       untarCommand.append(" gzip -dc '");
/* 537 */       untarCommand.append(makeShellPath(inFile));
/* 538 */       untarCommand.append("' | (");
/*     */     }
/* 540 */     untarCommand.append("cd '");
/* 541 */     untarCommand.append(makeShellPath(untarDir));
/* 542 */     untarCommand.append("' ; ");
/* 543 */     untarCommand.append("tar -xf ");
/*     */ 
/* 545 */     if (gzipped)
/* 546 */       untarCommand.append(" -)");
/*     */     else {
/* 548 */       untarCommand.append(makeShellPath(inFile));
/*     */     }
/* 550 */     String[] shellCmd = { "bash", "-c", untarCommand.toString() };
/* 551 */     Shell.ShellCommandExecutor shexec = new Shell.ShellCommandExecutor(shellCmd);
/* 552 */     shexec.execute();
/* 553 */     int exitcode = shexec.getExitCode();
/* 554 */     if (exitcode != 0)
/* 555 */       throw new IOException(new StringBuilder().append("Error untarring file ").append(inFile).append(". Tar process exited with exit code ").append(exitcode).toString());
/*     */   }
/*     */ 
/*     */   public static int symLink(String target, String linkname)
/*     */     throws IOException
/*     */   {
/* 568 */     String cmd = new StringBuilder().append("ln -s ").append(target).append(" ").append(linkname).toString();
/* 569 */     Process p = Runtime.getRuntime().exec(cmd, null);
/* 570 */     int returnVal = -1;
/*     */     try {
/* 572 */       returnVal = p.waitFor();
/*     */     }
/*     */     catch (InterruptedException e) {
/*     */     }
/* 576 */     if (returnVal != 0) {
/* 577 */       LOG.warn(new StringBuilder().append("Command '").append(cmd).append("' failed ").append(returnVal).append(" with: ").append(copyStderr(p)).toString());
/*     */     }
/*     */ 
/* 580 */     return returnVal;
/*     */   }
/*     */ 
/*     */   private static String copyStderr(Process p) throws IOException {
/* 584 */     InputStream err = p.getErrorStream();
/* 585 */     StringBuilder result = new StringBuilder();
/* 586 */     byte[] buff = new byte[4096];
/* 587 */     int len = err.read(buff);
/* 588 */     while (len > 0) {
/* 589 */       result.append(new String(buff, 0, len));
/* 590 */       len = err.read(buff);
/*     */     }
/* 592 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public static int chmod(String filename, String perm)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 605 */     return chmod(filename, perm, false);
/*     */   }
/*     */ 
/*     */   public static int chmod(String filename, String perm, boolean recursive)
/*     */     throws IOException
/*     */   {
/* 620 */     StringBuffer cmdBuf = new StringBuffer();
/* 621 */     cmdBuf.append("chmod ");
/* 622 */     if (recursive) {
/* 623 */       cmdBuf.append("-R ");
/*     */     }
/* 625 */     cmdBuf.append(perm).append(" ");
/* 626 */     cmdBuf.append(filename);
/* 627 */     String[] shellCmd = { "bash", "-c", cmdBuf.toString() };
/* 628 */     Shell.ShellCommandExecutor shExec = new Shell.ShellCommandExecutor(shellCmd);
/*     */     try {
/* 630 */       shExec.execute();
/*     */     } catch (IOException e) {
/* 632 */       if (LOG.isDebugEnabled()) {
/* 633 */         LOG.debug(new StringBuilder().append("Error while changing permission : ").append(filename).append(" Exception: ").append(StringUtils.stringifyException(e)).toString());
/*     */       }
/*     */     }
/*     */ 
/* 637 */     return shExec.getExitCode();
/*     */   }
/*     */ 
/*     */   public static void setPermission(File f, FsPermission permission)
/*     */     throws IOException
/*     */   {
/* 649 */     FsAction user = permission.getUserAction();
/* 650 */     FsAction group = permission.getGroupAction();
/* 651 */     FsAction other = permission.getOtherAction();
/*     */ 
/* 655 */     if ((group != other) || (NativeIO.isAvailable())) {
/* 656 */       execSetPermission(f, permission);
/* 657 */       return;
/*     */     }
/*     */ 
/* 660 */     boolean rv = true;
/*     */ 
/* 663 */     rv = f.setReadable(group.implies(FsAction.READ), false);
/* 664 */     checkReturnValue(rv, f, permission);
/* 665 */     if (group.implies(FsAction.READ) != user.implies(FsAction.READ)) {
/* 666 */       f.setReadable(user.implies(FsAction.READ), true);
/* 667 */       checkReturnValue(rv, f, permission);
/*     */     }
/*     */ 
/* 671 */     rv = f.setWritable(group.implies(FsAction.WRITE), false);
/* 672 */     checkReturnValue(rv, f, permission);
/* 673 */     if (group.implies(FsAction.WRITE) != user.implies(FsAction.WRITE)) {
/* 674 */       f.setWritable(user.implies(FsAction.WRITE), true);
/* 675 */       checkReturnValue(rv, f, permission);
/*     */     }
/*     */ 
/* 679 */     rv = f.setExecutable(group.implies(FsAction.EXECUTE), false);
/* 680 */     checkReturnValue(rv, f, permission);
/* 681 */     if (group.implies(FsAction.EXECUTE) != user.implies(FsAction.EXECUTE)) {
/* 682 */       f.setExecutable(user.implies(FsAction.EXECUTE), true);
/* 683 */       checkReturnValue(rv, f, permission);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void checkReturnValue(boolean rv, File p, FsPermission permission)
/*     */     throws IOException
/*     */   {
/* 690 */     if (!rv)
/* 691 */       throw new IOException(new StringBuilder().append("Failed to set permissions of path: ").append(p).append(" to ").append(String.format("%04o", new Object[] { Short.valueOf(permission.toShort()) })).toString());
/*     */   }
/*     */ 
/*     */   private static void execSetPermission(File f, FsPermission permission)
/*     */     throws IOException
/*     */   {
/* 700 */     if (NativeIO.isAvailable())
/* 701 */       NativeIO.chmod(f.getCanonicalPath(), permission.toShort());
/*     */     else
/* 703 */       execCommand(f, new String[] { "chmod", String.format("%04o", new Object[] { Short.valueOf(permission.toShort()) }) });
/*     */   }
/*     */ 
/*     */   static String execCommand(File f, String[] cmd)
/*     */     throws IOException
/*     */   {
/* 709 */     String[] args = new String[cmd.length + 1];
/* 710 */     System.arraycopy(cmd, 0, args, 0, cmd.length);
/* 711 */     args[cmd.length] = f.getCanonicalPath();
/* 712 */     String output = Shell.execCommand(args);
/* 713 */     return output;
/*     */   }
/*     */ 
/*     */   public static final File createLocalTempFile(File basefile, String prefix, boolean isDeleteOnExit)
/*     */     throws IOException
/*     */   {
/* 730 */     File tmp = File.createTempFile(new StringBuilder().append(prefix).append(basefile.getName()).toString(), "", basefile.getParentFile());
/*     */ 
/* 732 */     if (isDeleteOnExit) {
/* 733 */       tmp.deleteOnExit();
/*     */     }
/* 735 */     return tmp;
/*     */   }
/*     */ 
/*     */   public static void replaceFile(File src, File target)
/*     */     throws IOException
/*     */   {
/* 750 */     if (!src.renameTo(target)) {
/* 751 */       int retries = 5;
/* 752 */       while ((target.exists()) && (!target.delete()) && (retries-- >= 0)) {
/*     */         try {
/* 754 */           Thread.sleep(1000L);
/*     */         } catch (InterruptedException e) {
/* 756 */           throw new IOException("replaceFile interrupted.");
/*     */         }
/*     */       }
/* 759 */       if (!src.renameTo(target))
/* 760 */         throw new IOException(new StringBuilder().append("Unable to rename ").append(src).append(" to ").append(target).toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static File[] listFiles(File dir)
/*     */     throws IOException
/*     */   {
/* 777 */     File[] files = dir.listFiles();
/* 778 */     if (files == null) {
/* 779 */       throw new IOException(new StringBuilder().append("Invalid directory or I/O error occurred for dir: ").append(dir.toString()).toString());
/*     */     }
/*     */ 
/* 782 */     return files;
/*     */   }
/*     */ 
/*     */   public static String[] list(File dir)
/*     */     throws IOException
/*     */   {
/* 796 */     String[] fileNames = dir.list();
/* 797 */     if (fileNames == null) {
/* 798 */       throw new IOException(new StringBuilder().append("Invalid directory or I/O error occurred for dir: ").append(dir.toString()).toString());
/*     */     }
/*     */ 
/* 801 */     return fileNames;
/*     */   }
/*     */ 
/*     */   private static class CygPathCommand extends Shell
/*     */   {
/*     */     String[] command;
/*     */     String result;
/*     */ 
/*     */     CygPathCommand(String path)
/*     */       throws IOException
/*     */     {
/* 378 */       this.command = new String[] { "cygpath", "-u", path };
/* 379 */       run();
/*     */     }
/*     */     String getResult() throws IOException {
/* 382 */       return this.result;
/*     */     }
/*     */     protected String[] getExecString() {
/* 385 */       return this.command;
/*     */     }
/*     */     protected void parseExecResult(BufferedReader lines) throws IOException {
/* 388 */       String line = lines.readLine();
/* 389 */       if (line == null) {
/* 390 */         throw new IOException("Can't convert '" + this.command[2] + " to a cygwin path");
/*     */       }
/*     */ 
/* 393 */       this.result = line;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.fs.FileUtil
 * JD-Core Version:    0.6.1
 */
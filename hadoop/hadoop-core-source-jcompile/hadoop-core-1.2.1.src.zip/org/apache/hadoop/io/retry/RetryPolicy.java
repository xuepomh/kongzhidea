package org.apache.hadoop.io.retry;

public abstract interface RetryPolicy
{
  public abstract boolean shouldRetry(Exception paramException, int paramInt)
    throws Exception;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.retry.RetryPolicy
 * JD-Core Version:    0.6.1
 */
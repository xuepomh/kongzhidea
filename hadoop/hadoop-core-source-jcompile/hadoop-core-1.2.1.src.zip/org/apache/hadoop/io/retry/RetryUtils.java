/*     */ package org.apache.hadoop.io.retry;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.ipc.RemoteException;
/*     */ 
/*     */ public class RetryUtils
/*     */ {
/*  28 */   public static final Log LOG = LogFactory.getLog(RetryUtils.class);
/*     */ 
/*     */   public static RetryPolicy getDefaultRetryPolicy(Configuration conf, String retryPolicyEnabledKey, boolean defaultRetryPolicyEnabled, String retryPolicySpecKey, String defaultRetryPolicySpec, Class<? extends Exception>[] remoteExceptionsToRetry)
/*     */   {
/*  62 */     final RetryPolicy multipleLinearRandomRetry = getMultipleLinearRandomRetry(conf, retryPolicyEnabledKey, defaultRetryPolicyEnabled, retryPolicySpecKey, defaultRetryPolicySpec);
/*     */ 
/*  69 */     if (LOG.isDebugEnabled()) {
/*  70 */       LOG.debug("multipleLinearRandomRetry = " + multipleLinearRandomRetry);
/*     */     }
/*     */ 
/*  73 */     if (multipleLinearRandomRetry == null)
/*     */     {
/*  75 */       return RetryPolicies.TRY_ONCE_THEN_FAIL;
/*     */     }
/*  77 */     return new RetryPolicy()
/*     */     {
/*     */       public boolean shouldRetry(Exception e, int retries)
/*     */         throws Exception
/*     */       {
/*     */         RetryPolicy p;
/*     */         RetryPolicy p;
/*  82 */         if ((e instanceof RemoteException)) {
/*  83 */           RemoteException re = (RemoteException)e;
/*  84 */           RetryPolicy found = null;
/*  85 */           for (Class reToRetry : this.val$remoteExceptionsToRetry) {
/*  86 */             if (reToRetry.getName().equals(re.getClassName())) {
/*  87 */               found = multipleLinearRandomRetry;
/*  88 */               break;
/*     */             }
/*     */           }
/*  91 */           p = found != null ? found : RetryPolicies.TRY_ONCE_THEN_FAIL;
/*     */         }
/*     */         else
/*     */         {
/*     */           RetryPolicy p;
/*  92 */           if ((e instanceof IOException))
/*  93 */             p = multipleLinearRandomRetry;
/*     */           else {
/*  95 */             p = RetryPolicies.TRY_ONCE_THEN_FAIL;
/*     */           }
/*     */         }
/*  98 */         if (RetryUtils.LOG.isDebugEnabled()) {
/*  99 */           RetryUtils.LOG.debug("RETRY " + retries + ") policy=" + p.getClass().getSimpleName() + ", exception=" + e);
/*     */         }
/*     */ 
/* 102 */         return p.shouldRetry(e, retries);
/*     */       }
/*     */ 
/*     */       public String toString()
/*     */       {
/* 107 */         return "RetryPolicy[" + multipleLinearRandomRetry + ", " + RetryPolicies.TRY_ONCE_THEN_FAIL.getClass().getSimpleName() + "]";
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public static RetryPolicy getMultipleLinearRandomRetry(Configuration conf, String retryPolicyEnabledKey, boolean defaultRetryPolicyEnabled, String retryPolicySpecKey, String defaultRetryPolicySpec)
/*     */   {
/* 139 */     boolean enabled = conf.getBoolean(retryPolicyEnabledKey, defaultRetryPolicyEnabled);
/*     */ 
/* 141 */     if (!enabled) {
/* 142 */       return null;
/*     */     }
/*     */ 
/* 145 */     String policy = conf.get(retryPolicySpecKey, defaultRetryPolicySpec);
/*     */ 
/* 147 */     RetryPolicy r = RetryPolicies.MultipleLinearRandomRetry.parseCommaSeparatedString(policy);
/*     */ 
/* 150 */     return r != null ? r : RetryPolicies.MultipleLinearRandomRetry.parseCommaSeparatedString(defaultRetryPolicySpec);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.retry.RetryUtils
 * JD-Core Version:    0.6.1
 */
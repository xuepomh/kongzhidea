/*    */ package org.apache.hadoop.io.retry;
/*    */ 
/*    */ import java.lang.reflect.InvocationHandler;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.apache.hadoop.util.StringUtils;
/*    */ 
/*    */ class RetryInvocationHandler
/*    */   implements InvocationHandler
/*    */ {
/* 31 */   public static final Log LOG = LogFactory.getLog(RetryInvocationHandler.class);
/*    */   private Object implementation;
/*    */   private RetryPolicy defaultPolicy;
/*    */   private Map<String, RetryPolicy> methodNameToPolicyMap;
/*    */ 
/*    */   public RetryInvocationHandler(Object implementation, RetryPolicy retryPolicy)
/*    */   {
/* 38 */     this(implementation, retryPolicy, Collections.emptyMap());
/*    */   }
/*    */ 
/*    */   public RetryInvocationHandler(Object implementation, Map<String, RetryPolicy> methodNameToPolicyMap) {
/* 42 */     this(implementation, RetryPolicies.TRY_ONCE_THEN_FAIL, methodNameToPolicyMap);
/*    */   }
/*    */ 
/*    */   public RetryInvocationHandler(Object implementation, RetryPolicy defaultPolicy, Map<String, RetryPolicy> methodNameToPolicyMap)
/*    */   {
/* 47 */     this.implementation = implementation;
/* 48 */     this.defaultPolicy = defaultPolicy;
/* 49 */     this.methodNameToPolicyMap = methodNameToPolicyMap;
/*    */   }
/*    */ 
/*    */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*    */   {
/* 54 */     RetryPolicy policy = (RetryPolicy)this.methodNameToPolicyMap.get(method.getName());
/* 55 */     if (policy == null) {
/* 56 */       policy = this.defaultPolicy;
/*    */     }
/*    */ 
/* 59 */     int retries = 0;
/*    */     while (true)
/*    */       try {
/* 62 */         return invokeMethod(method, args);
/*    */       } catch (Exception e) {
/* 64 */         if (!policy.shouldRetry(e, retries++)) {
/* 65 */           LOG.info("Exception while invoking " + method.getName() + " of " + this.implementation.getClass() + ". Not retrying." + StringUtils.stringifyException(e));
/*    */ 
/* 68 */           if (!method.getReturnType().equals(Void.TYPE)) {
/* 69 */             throw e;
/*    */           }
/* 71 */           return null;
/*    */         }
/* 73 */         LOG.debug("Exception while invoking " + method.getName() + " of " + this.implementation.getClass() + ". Retrying." + StringUtils.stringifyException(e));
/*    */       }
/*    */   }
/*    */ 
/*    */   private Object invokeMethod(Method method, Object[] args)
/*    */     throws Throwable
/*    */   {
/*    */     try
/*    */     {
/* 82 */       if (!method.isAccessible()) {
/* 83 */         method.setAccessible(true);
/*    */       }
/* 85 */       return method.invoke(this.implementation, args);
/*    */     } catch (InvocationTargetException e) {
/* 87 */       throw e.getCause();
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.retry.RetryInvocationHandler
 * JD-Core Version:    0.6.1
 */
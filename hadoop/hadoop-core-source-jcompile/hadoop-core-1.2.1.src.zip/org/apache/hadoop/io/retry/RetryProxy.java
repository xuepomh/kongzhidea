/*    */ package org.apache.hadoop.io.retry;
/*    */ 
/*    */ import java.lang.reflect.Proxy;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class RetryProxy
/*    */ {
/*    */   public static Object create(Class<?> iface, Object implementation, RetryPolicy retryPolicy)
/*    */   {
/* 41 */     return Proxy.newProxyInstance(implementation.getClass().getClassLoader(), new Class[] { iface }, new RetryInvocationHandler(implementation, retryPolicy));
/*    */   }
/*    */ 
/*    */   public static Object create(Class<?> iface, Object implementation, Map<String, RetryPolicy> methodNameToPolicyMap)
/*    */   {
/* 62 */     return Proxy.newProxyInstance(implementation.getClass().getClassLoader(), new Class[] { iface }, new RetryInvocationHandler(implementation, methodNameToPolicyMap));
/*    */   }
/*    */ 
/*    */   public static Object create(Class<?> iface, Object implementation, RetryPolicy defaultPolicy, Map<String, RetryPolicy> methodNameToPolicyMap)
/*    */   {
/* 71 */     return Proxy.newProxyInstance(implementation.getClass().getClassLoader(), new Class[] { iface }, new RetryInvocationHandler(implementation, defaultPolicy, methodNameToPolicyMap));
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.retry.RetryProxy
 * JD-Core Version:    0.6.1
 */
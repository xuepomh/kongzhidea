/*     */ package org.apache.hadoop.io.retry;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Random;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.ipc.RemoteException;
/*     */ 
/*     */ public class RetryPolicies
/*     */ {
/*  39 */   private static final Log LOG = LogFactory.getLog(RetryPolicies.class);
/*     */ 
/*  41 */   private static ThreadLocal<Random> RANDOM = new ThreadLocal()
/*     */   {
/*     */     protected Random initialValue() {
/*  44 */       return new Random();
/*     */     }
/*  41 */   };
/*     */ 
/*  54 */   public static final RetryPolicy TRY_ONCE_THEN_FAIL = new TryOnceThenFail();
/*     */ 
/*  62 */   public static final RetryPolicy TRY_ONCE_DONT_FAIL = new TryOnceDontFail();
/*     */ 
/*  69 */   public static final RetryPolicy RETRY_FOREVER = new RetryForever();
/*     */ 
/*     */   public static final RetryPolicy retryUpToMaximumCountWithFixedSleep(int maxRetries, long sleepTime, TimeUnit timeUnit)
/*     */   {
/*  78 */     return new RetryUpToMaximumCountWithFixedSleep(maxRetries, sleepTime, timeUnit);
/*     */   }
/*     */ 
/*     */   public static final RetryPolicy retryUpToMaximumTimeWithFixedSleep(long maxTime, long sleepTime, TimeUnit timeUnit)
/*     */   {
/*  88 */     return new RetryUpToMaximumTimeWithFixedSleep(maxTime, sleepTime, timeUnit);
/*     */   }
/*     */ 
/*     */   public static final RetryPolicy retryUpToMaximumCountWithProportionalSleep(int maxRetries, long sleepTime, TimeUnit timeUnit)
/*     */   {
/*  99 */     return new RetryUpToMaximumCountWithProportionalSleep(maxRetries, sleepTime, timeUnit);
/*     */   }
/*     */ 
/*     */   public static final RetryPolicy exponentialBackoffRetry(int maxRetries, long sleepTime, TimeUnit timeUnit)
/*     */   {
/* 112 */     return new ExponentialBackoffRetry(maxRetries, sleepTime, timeUnit);
/*     */   }
/*     */ 
/*     */   public static final RetryPolicy retryByException(RetryPolicy defaultPolicy, Map<Class<? extends Exception>, RetryPolicy> exceptionToPolicyMap)
/*     */   {
/* 122 */     return new ExceptionDependentRetry(defaultPolicy, exceptionToPolicyMap);
/*     */   }
/*     */ 
/*     */   public static final RetryPolicy retryByRemoteException(RetryPolicy defaultPolicy, Map<Class<? extends Exception>, RetryPolicy> exceptionToPolicyMap)
/*     */   {
/* 134 */     return new RemoteExceptionDependentRetry(defaultPolicy, exceptionToPolicyMap);
/*     */   }
/*     */ 
/*     */   static class ExponentialBackoffRetry extends RetryPolicies.RetryLimited
/*     */   {
/* 464 */     private Random r = new Random();
/*     */ 
/*     */     public ExponentialBackoffRetry(int maxRetries, long sleepTime, TimeUnit timeUnit) {
/* 467 */       super(sleepTime, timeUnit);
/*     */ 
/* 469 */       if (maxRetries < 0)
/* 470 */         throw new IllegalArgumentException("maxRetries = " + maxRetries + " < 0");
/* 471 */       if (maxRetries > 30)
/*     */       {
/* 473 */         throw new IllegalArgumentException("maxRetries = " + maxRetries + " > 30");
/*     */       }
/*     */     }
/*     */ 
/*     */     protected long calculateSleepTime(int retries)
/*     */     {
/* 479 */       return this.sleepTime * this.r.nextInt(1 << retries + 1);
/*     */     }
/*     */   }
/*     */ 
/*     */   static class RemoteExceptionDependentRetry
/*     */     implements RetryPolicy
/*     */   {
/*     */     RetryPolicy defaultPolicy;
/*     */     Map<String, RetryPolicy> exceptionNameToPolicyMap;
/*     */ 
/*     */     public RemoteExceptionDependentRetry(RetryPolicy defaultPolicy, Map<Class<? extends Exception>, RetryPolicy> exceptionToPolicyMap)
/*     */     {
/* 442 */       this.defaultPolicy = defaultPolicy;
/* 443 */       this.exceptionNameToPolicyMap = new HashMap();
/*     */ 
/* 445 */       for (Map.Entry e : exceptionToPolicyMap.entrySet())
/* 446 */         this.exceptionNameToPolicyMap.put(((Class)e.getKey()).getName(), e.getValue());
/*     */     }
/*     */ 
/*     */     public boolean shouldRetry(Exception e, int retries) throws Exception
/*     */     {
/* 451 */       RetryPolicy policy = null;
/* 452 */       if ((e instanceof RemoteException)) {
/* 453 */         policy = (RetryPolicy)this.exceptionNameToPolicyMap.get(((RemoteException)e).getClassName());
/*     */       }
/*     */ 
/* 456 */       if (policy == null) {
/* 457 */         policy = this.defaultPolicy;
/*     */       }
/* 459 */       return policy.shouldRetry(e, retries);
/*     */     }
/*     */   }
/*     */ 
/*     */   static class ExceptionDependentRetry
/*     */     implements RetryPolicy
/*     */   {
/*     */     RetryPolicy defaultPolicy;
/*     */     Map<Class<? extends Exception>, RetryPolicy> exceptionToPolicyMap;
/*     */ 
/*     */     public ExceptionDependentRetry(RetryPolicy defaultPolicy, Map<Class<? extends Exception>, RetryPolicy> exceptionToPolicyMap)
/*     */     {
/* 420 */       this.defaultPolicy = defaultPolicy;
/* 421 */       this.exceptionToPolicyMap = exceptionToPolicyMap;
/*     */     }
/*     */ 
/*     */     public boolean shouldRetry(Exception e, int retries) throws Exception {
/* 425 */       RetryPolicy policy = (RetryPolicy)this.exceptionToPolicyMap.get(e.getClass());
/* 426 */       if (policy == null) {
/* 427 */         policy = this.defaultPolicy;
/*     */       }
/* 429 */       return policy.shouldRetry(e, retries);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class MultipleLinearRandomRetry
/*     */     implements RetryPolicy
/*     */   {
/*     */     private final List<Pair> pairs;
/*     */     private String myString;
/*     */ 
/*     */     public MultipleLinearRandomRetry(List<Pair> pairs)
/*     */     {
/* 288 */       if ((pairs == null) || (pairs.isEmpty())) {
/* 289 */         throw new IllegalArgumentException("pairs must be neither null nor empty.");
/*     */       }
/* 291 */       this.pairs = Collections.unmodifiableList(pairs);
/*     */     }
/*     */ 
/*     */     public boolean shouldRetry(Exception e, int curRetry) throws Exception
/*     */     {
/* 296 */       Pair p = searchPair(curRetry);
/* 297 */       if (p == null)
/*     */       {
/* 299 */         throw e;
/*     */       }
/*     */ 
/* 304 */       double ratio = ((Random)RetryPolicies.RANDOM.get()).nextDouble() + 0.5D;
/* 305 */       Thread.sleep(Math.round(p.sleepMillis * ratio));
/* 306 */       return true;
/*     */     }
/*     */ 
/*     */     private Pair searchPair(int curRetry)
/*     */     {
/* 315 */       for (int i = 0; 
/* 316 */         (i < this.pairs.size()) && (curRetry > ((Pair)this.pairs.get(i)).numRetries); i++) {
/* 317 */         curRetry -= ((Pair)this.pairs.get(i)).numRetries;
/*     */       }
/* 319 */       return i == this.pairs.size() ? null : (Pair)this.pairs.get(i);
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 324 */       return toString().hashCode();
/*     */     }
/*     */ 
/*     */     public boolean equals(Object that)
/*     */     {
/* 329 */       if (this == that)
/* 330 */         return true;
/* 331 */       if ((that == null) || (getClass() != that.getClass())) {
/* 332 */         return false;
/*     */       }
/* 334 */       return toString().equals(that.toString());
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 339 */       if (this.myString == null) {
/* 340 */         this.myString = (getClass().getSimpleName() + this.pairs);
/*     */       }
/* 342 */       return this.myString;
/*     */     }
/*     */ 
/*     */     public static MultipleLinearRandomRetry parseCommaSeparatedString(String s)
/*     */     {
/* 354 */       String[] elements = s.split(",");
/* 355 */       if (elements.length == 0) {
/* 356 */         RetryPolicies.LOG.warn("Illegal value: there is no element in \"" + s + "\".");
/* 357 */         return null;
/*     */       }
/* 359 */       if (elements.length % 2 != 0) {
/* 360 */         RetryPolicies.LOG.warn("Illegal value: the number of elements in \"" + s + "\" is " + elements.length + " but an even number of elements is expected.");
/*     */ 
/* 362 */         return null;
/*     */       }
/*     */ 
/* 365 */       List pairs = new ArrayList();
/*     */ 
/* 368 */       for (int i = 0; i < elements.length; )
/*     */       {
/* 370 */         int sleep = parsePositiveInt(elements, i++, s);
/* 371 */         if (sleep == -1) {
/* 372 */           return null;
/*     */         }
/*     */ 
/* 376 */         int retries = parsePositiveInt(elements, i++, s);
/* 377 */         if (retries == -1) {
/* 378 */           return null;
/*     */         }
/*     */ 
/* 381 */         pairs.add(new Pair(retries, sleep));
/*     */       }
/* 383 */       return new MultipleLinearRandomRetry(pairs);
/*     */     }
/*     */ 
/*     */     private static int parsePositiveInt(String[] elements, int i, String originalString)
/*     */     {
/* 393 */       String s = elements[i].trim();
/*     */       int n;
/*     */       try
/*     */       {
/* 396 */         n = Integer.parseInt(s);
/*     */       } catch (NumberFormatException nfe) {
/* 398 */         RetryPolicies.LOG.warn("Failed to parse \"" + s + "\", which is the index " + i + " element in \"" + originalString + "\"", nfe);
/*     */ 
/* 400 */         return -1;
/*     */       }
/*     */ 
/* 403 */       if (n <= 0) {
/* 404 */         RetryPolicies.LOG.warn("The value " + n + " <= 0: it is parsed from the string \"" + s + "\" which is the index " + i + " element in \"" + originalString + "\"");
/*     */ 
/* 407 */         return -1;
/*     */       }
/* 409 */       return n;
/*     */     }
/*     */ 
/*     */     public static class Pair
/*     */     {
/*     */       final int numRetries;
/*     */       final int sleepMillis;
/*     */ 
/*     */       public Pair(int numRetries, int sleepMillis)
/*     */       {
/* 267 */         if (numRetries < 0) {
/* 268 */           throw new IllegalArgumentException("numRetries = " + numRetries + " < 0");
/*     */         }
/* 270 */         if (sleepMillis < 0) {
/* 271 */           throw new IllegalArgumentException("sleepMillis = " + sleepMillis + " < 0");
/*     */         }
/*     */ 
/* 274 */         this.numRetries = numRetries;
/* 275 */         this.sleepMillis = sleepMillis;
/*     */       }
/*     */ 
/*     */       public String toString()
/*     */       {
/* 280 */         return this.numRetries + "x" + this.sleepMillis + "ms";
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static class RetryUpToMaximumCountWithProportionalSleep extends RetryPolicies.RetryLimited
/*     */   {
/*     */     public RetryUpToMaximumCountWithProportionalSleep(int maxRetries, long sleepTime, TimeUnit timeUnit)
/*     */     {
/* 241 */       super(sleepTime, timeUnit);
/*     */     }
/*     */ 
/*     */     protected long calculateSleepTime(int retries)
/*     */     {
/* 246 */       return this.sleepTime * retries + 1;
/*     */     }
/*     */   }
/*     */ 
/*     */   static class RetryUpToMaximumTimeWithFixedSleep extends RetryPolicies.RetryUpToMaximumCountWithFixedSleep
/*     */   {
/*     */     public RetryUpToMaximumTimeWithFixedSleep(long maxTime, long sleepTime, TimeUnit timeUnit)
/*     */     {
/* 235 */       super(sleepTime, timeUnit);
/*     */     }
/*     */   }
/*     */ 
/*     */   static class RetryUpToMaximumCountWithFixedSleep extends RetryPolicies.RetryLimited
/*     */   {
/*     */     public RetryUpToMaximumCountWithFixedSleep(int maxRetries, long sleepTime, TimeUnit timeUnit)
/*     */     {
/* 224 */       super(sleepTime, timeUnit);
/*     */     }
/*     */ 
/*     */     protected long calculateSleepTime(int retries)
/*     */     {
/* 229 */       return this.sleepTime;
/*     */     }
/*     */   }
/*     */ 
/*     */   static abstract class RetryLimited
/*     */     implements RetryPolicy
/*     */   {
/*     */     final int maxRetries;
/*     */     final long sleepTime;
/*     */     final TimeUnit timeUnit;
/*     */     private String myString;
/*     */ 
/*     */     RetryLimited(int maxRetries, long sleepTime, TimeUnit timeUnit)
/*     */     {
/* 170 */       if (maxRetries < 0) {
/* 171 */         throw new IllegalArgumentException("maxRetries = " + maxRetries + " < 0");
/*     */       }
/* 173 */       if (sleepTime < 0L) {
/* 174 */         throw new IllegalArgumentException("sleepTime = " + sleepTime + " < 0");
/*     */       }
/*     */ 
/* 177 */       this.maxRetries = maxRetries;
/* 178 */       this.sleepTime = sleepTime;
/* 179 */       this.timeUnit = timeUnit;
/*     */     }
/*     */ 
/*     */     public boolean shouldRetry(Exception e, int retries) throws Exception
/*     */     {
/* 184 */       if (retries >= this.maxRetries)
/* 185 */         throw e;
/*     */       try
/*     */       {
/* 188 */         this.timeUnit.sleep(calculateSleepTime(retries));
/*     */       }
/*     */       catch (InterruptedException ie) {
/*     */       }
/* 192 */       return true;
/*     */     }
/*     */ 
/*     */     protected abstract long calculateSleepTime(int paramInt);
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 199 */       return toString().hashCode();
/*     */     }
/*     */ 
/*     */     public boolean equals(Object that)
/*     */     {
/* 204 */       if (this == that)
/* 205 */         return true;
/* 206 */       if ((that == null) || (getClass() != that.getClass())) {
/* 207 */         return false;
/*     */       }
/* 209 */       return toString().equals(that.toString());
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 214 */       if (this.myString == null) {
/* 215 */         this.myString = (getClass().getSimpleName() + "(maxRetries=" + this.maxRetries + ", sleepTime=" + this.sleepTime + " " + this.timeUnit + ")");
/*     */       }
/*     */ 
/* 218 */       return this.myString;
/*     */     }
/*     */   }
/*     */ 
/*     */   static class RetryForever
/*     */     implements RetryPolicy
/*     */   {
/*     */     public boolean shouldRetry(Exception e, int retries)
/*     */       throws Exception
/*     */     {
/* 150 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   static class TryOnceDontFail
/*     */     implements RetryPolicy
/*     */   {
/*     */     public boolean shouldRetry(Exception e, int retries)
/*     */       throws Exception
/*     */     {
/* 144 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   static class TryOnceThenFail
/*     */     implements RetryPolicy
/*     */   {
/*     */     public boolean shouldRetry(Exception e, int retries)
/*     */       throws Exception
/*     */     {
/* 139 */       throw e;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.retry.RetryPolicies
 * JD-Core Version:    0.6.1
 */
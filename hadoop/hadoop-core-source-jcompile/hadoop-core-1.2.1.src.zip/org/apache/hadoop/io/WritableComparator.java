/*     */ package org.apache.hadoop.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import org.apache.hadoop.util.ReflectionUtils;
/*     */ 
/*     */ public class WritableComparator
/*     */   implements RawComparator
/*     */ {
/*  37 */   private static HashMap<Class, WritableComparator> comparators = new HashMap();
/*     */   private final Class<? extends WritableComparable> keyClass;
/*     */   private final WritableComparable key1;
/*     */   private final WritableComparable key2;
/*     */   private final DataInputBuffer buffer;
/*     */ 
/*     */   public static synchronized WritableComparator get(Class<? extends WritableComparable> c)
/*     */   {
/*  42 */     WritableComparator comparator = (WritableComparator)comparators.get(c);
/*  43 */     if (comparator == null)
/*  44 */       comparator = new WritableComparator(c, true);
/*  45 */     return comparator;
/*     */   }
/*     */ 
/*     */   public static synchronized void define(Class c, WritableComparator comparator)
/*     */   {
/*  52 */     comparators.put(c, comparator);
/*     */   }
/*     */ 
/*     */   protected WritableComparator(Class<? extends WritableComparable> keyClass)
/*     */   {
/*  63 */     this(keyClass, false);
/*     */   }
/*     */ 
/*     */   protected WritableComparator(Class<? extends WritableComparable> keyClass, boolean createInstances)
/*     */   {
/*  68 */     this.keyClass = keyClass;
/*  69 */     if (createInstances) {
/*  70 */       this.key1 = newKey();
/*  71 */       this.key2 = newKey();
/*  72 */       this.buffer = new DataInputBuffer();
/*     */     } else {
/*  74 */       this.key1 = (this.key2 = null);
/*  75 */       this.buffer = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Class<? extends WritableComparable> getKeyClass() {
/*  80 */     return this.keyClass;
/*     */   }
/*     */ 
/*     */   public WritableComparable newKey() {
/*  84 */     return (WritableComparable)ReflectionUtils.newInstance(this.keyClass, null);
/*     */   }
/*     */ 
/*     */   public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2)
/*     */   {
/*     */     try
/*     */     {
/*  96 */       this.buffer.reset(b1, s1, l1);
/*  97 */       this.key1.readFields(this.buffer);
/*     */ 
/*  99 */       this.buffer.reset(b2, s2, l2);
/* 100 */       this.key2.readFields(this.buffer);
/*     */     }
/*     */     catch (IOException e) {
/* 103 */       throw new RuntimeException(e);
/*     */     }
/*     */ 
/* 106 */     return compare(this.key1, this.key2);
/*     */   }
/*     */ 
/*     */   public int compare(WritableComparable a, WritableComparable b)
/*     */   {
/* 115 */     return a.compareTo(b);
/*     */   }
/*     */ 
/*     */   public int compare(Object a, Object b) {
/* 119 */     return compare((WritableComparable)a, (WritableComparable)b);
/*     */   }
/*     */ 
/*     */   public static int compareBytes(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2)
/*     */   {
/* 125 */     int end1 = s1 + l1;
/* 126 */     int end2 = s2 + l2;
/* 127 */     int i = s1; for (int j = s2; (i < end1) && (j < end2); j++) {
/* 128 */       int a = b1[i] & 0xFF;
/* 129 */       int b = b2[j] & 0xFF;
/* 130 */       if (a != b)
/* 131 */         return a - b;
/* 127 */       i++;
/*     */     }
/*     */ 
/* 134 */     return l1 - l2;
/*     */   }
/*     */ 
/*     */   public static int hashBytes(byte[] bytes, int offset, int length)
/*     */   {
/* 139 */     int hash = 1;
/* 140 */     for (int i = offset; i < offset + length; i++)
/* 141 */       hash = 31 * hash + bytes[i];
/* 142 */     return hash;
/*     */   }
/*     */ 
/*     */   public static int hashBytes(byte[] bytes, int length)
/*     */   {
/* 147 */     return hashBytes(bytes, 0, length);
/*     */   }
/*     */ 
/*     */   public static int readUnsignedShort(byte[] bytes, int start)
/*     */   {
/* 152 */     return ((bytes[start] & 0xFF) << 8) + (bytes[(start + 1)] & 0xFF);
/*     */   }
/*     */ 
/*     */   public static int readInt(byte[] bytes, int start)
/*     */   {
/* 158 */     return ((bytes[start] & 0xFF) << 24) + ((bytes[(start + 1)] & 0xFF) << 16) + ((bytes[(start + 2)] & 0xFF) << 8) + (bytes[(start + 3)] & 0xFF);
/*     */   }
/*     */ 
/*     */   public static float readFloat(byte[] bytes, int start)
/*     */   {
/* 167 */     return Float.intBitsToFloat(readInt(bytes, start));
/*     */   }
/*     */ 
/*     */   public static long readLong(byte[] bytes, int start)
/*     */   {
/* 172 */     return (readInt(bytes, start) << 32) + (readInt(bytes, start + 4) & 0xFFFFFFFF);
/*     */   }
/*     */ 
/*     */   public static double readDouble(byte[] bytes, int start)
/*     */   {
/* 178 */     return Double.longBitsToDouble(readLong(bytes, start));
/*     */   }
/*     */ 
/*     */   public static long readVLong(byte[] bytes, int start)
/*     */     throws IOException
/*     */   {
/* 189 */     int len = bytes[start];
/* 190 */     if (len >= -112) {
/* 191 */       return len;
/*     */     }
/* 193 */     boolean isNegative = len < -120;
/* 194 */     len = isNegative ? -(len + 120) : -(len + 112);
/* 195 */     if (start + 1 + len > bytes.length) {
/* 196 */       throw new IOException("Not enough number of bytes for a zero-compressed integer");
/*     */     }
/* 198 */     long i = 0L;
/* 199 */     for (int idx = 0; idx < len; idx++) {
/* 200 */       i <<= 8;
/* 201 */       i |= bytes[(start + 1 + idx)] & 0xFF;
/*     */     }
/* 203 */     return isNegative ? i ^ 0xFFFFFFFF : i;
/*     */   }
/*     */ 
/*     */   public static int readVInt(byte[] bytes, int start)
/*     */     throws IOException
/*     */   {
/* 214 */     return (int)readVLong(bytes, start);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.WritableComparator
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.io;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.hadoop.util.ReflectionUtils;
/*     */ 
/*     */ public class MapWritable extends AbstractMapWritable
/*     */   implements Map<Writable, Writable>
/*     */ {
/*     */   private Map<Writable, Writable> instance;
/*     */ 
/*     */   public MapWritable()
/*     */   {
/*  43 */     this.instance = new HashMap();
/*     */   }
/*     */ 
/*     */   public MapWritable(MapWritable other)
/*     */   {
/*  52 */     this();
/*  53 */     copy(other);
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/*  58 */     this.instance.clear();
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key)
/*     */   {
/*  63 */     return this.instance.containsKey(key);
/*     */   }
/*     */ 
/*     */   public boolean containsValue(Object value)
/*     */   {
/*  68 */     return this.instance.containsValue(value);
/*     */   }
/*     */ 
/*     */   public Set<Map.Entry<Writable, Writable>> entrySet()
/*     */   {
/*  73 */     return this.instance.entrySet();
/*     */   }
/*     */ 
/*     */   public Writable get(Object key)
/*     */   {
/*  78 */     return (Writable)this.instance.get(key);
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/*  83 */     return this.instance.isEmpty();
/*     */   }
/*     */ 
/*     */   public Set<Writable> keySet()
/*     */   {
/*  88 */     return this.instance.keySet();
/*     */   }
/*     */ 
/*     */   public Writable put(Writable key, Writable value)
/*     */   {
/*  94 */     addToMap(key.getClass());
/*  95 */     addToMap(value.getClass());
/*  96 */     return (Writable)this.instance.put(key, value);
/*     */   }
/*     */ 
/*     */   public void putAll(Map<? extends Writable, ? extends Writable> t)
/*     */   {
/* 101 */     for (Map.Entry e : t.entrySet())
/* 102 */       put((Writable)e.getKey(), (Writable)e.getValue());
/*     */   }
/*     */ 
/*     */   public Writable remove(Object key)
/*     */   {
/* 108 */     return (Writable)this.instance.remove(key);
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 113 */     return this.instance.size();
/*     */   }
/*     */ 
/*     */   public Collection<Writable> values()
/*     */   {
/* 118 */     return this.instance.values();
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/* 126 */     super.write(out);
/*     */ 
/* 130 */     out.writeInt(this.instance.size());
/*     */ 
/* 134 */     for (Map.Entry e : this.instance.entrySet()) {
/* 135 */       out.writeByte(getId(((Writable)e.getKey()).getClass()));
/* 136 */       ((Writable)e.getKey()).write(out);
/* 137 */       out.writeByte(getId(((Writable)e.getValue()).getClass()));
/* 138 */       ((Writable)e.getValue()).write(out);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in)
/*     */     throws IOException
/*     */   {
/* 146 */     super.readFields(in);
/*     */ 
/* 150 */     this.instance.clear();
/*     */ 
/* 154 */     int entries = in.readInt();
/*     */ 
/* 158 */     for (int i = 0; i < entries; i++) {
/* 159 */       Writable key = (Writable)ReflectionUtils.newInstance(getClass(in.readByte()), getConf());
/*     */ 
/* 162 */       key.readFields(in);
/*     */ 
/* 164 */       Writable value = (Writable)ReflectionUtils.newInstance(getClass(in.readByte()), getConf());
/*     */ 
/* 167 */       value.readFields(in);
/* 168 */       this.instance.put(key, value);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.MapWritable
 * JD-Core Version:    0.6.1
 */
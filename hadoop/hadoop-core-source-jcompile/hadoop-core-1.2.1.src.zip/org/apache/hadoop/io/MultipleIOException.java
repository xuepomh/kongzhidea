/*    */ package org.apache.hadoop.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ 
/*    */ public class MultipleIOException extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final List<IOException> exceptions;
/*    */ 
/*    */   private MultipleIOException(List<IOException> exceptions)
/*    */   {
/* 32 */     super(exceptions.size() + " exceptions " + exceptions);
/* 33 */     this.exceptions = exceptions;
/*    */   }
/*    */ 
/*    */   public List<IOException> getExceptions() {
/* 37 */     return this.exceptions;
/*    */   }
/*    */ 
/*    */   public static IOException createIOException(List<IOException> exceptions) {
/* 41 */     if ((exceptions == null) || (exceptions.isEmpty())) {
/* 42 */       return null;
/*    */     }
/* 44 */     if (exceptions.size() == 1) {
/* 45 */       return (IOException)exceptions.get(0);
/*    */     }
/* 47 */     return new MultipleIOException(exceptions);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.MultipleIOException
 * JD-Core Version:    0.6.1
 */
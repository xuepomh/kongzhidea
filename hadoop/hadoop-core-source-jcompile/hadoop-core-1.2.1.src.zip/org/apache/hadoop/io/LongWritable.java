/*    */ package org.apache.hadoop.io;
/*    */ 
/*    */ import java.io.DataInput;
/*    */ import java.io.DataOutput;
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class LongWritable
/*    */   implements WritableComparable
/*    */ {
/*    */   private long value;
/*    */ 
/*    */   public LongWritable()
/*    */   {
/*    */   }
/*    */ 
/*    */   public LongWritable(long value)
/*    */   {
/* 29 */     set(value);
/*    */   }
/*    */   public void set(long value) {
/* 32 */     this.value = value;
/*    */   }
/*    */   public long get() {
/* 35 */     return this.value;
/*    */   }
/*    */   public void readFields(DataInput in) throws IOException {
/* 38 */     this.value = in.readLong();
/*    */   }
/*    */ 
/*    */   public void write(DataOutput out) throws IOException {
/* 42 */     out.writeLong(this.value);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 47 */     if (!(o instanceof LongWritable))
/* 48 */       return false;
/* 49 */     LongWritable other = (LongWritable)o;
/* 50 */     return this.value == other.value;
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 54 */     return (int)this.value;
/*    */   }
/*    */ 
/*    */   public int compareTo(Object o)
/*    */   {
/* 59 */     long thisValue = this.value;
/* 60 */     long thatValue = ((LongWritable)o).value;
/* 61 */     return thisValue == thatValue ? 0 : thisValue < thatValue ? -1 : 1;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 65 */     return Long.toString(this.value);
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 93 */     WritableComparator.define(LongWritable.class, new Comparator());
/*    */   }
/*    */ 
/*    */   public static class DecreasingComparator extends LongWritable.Comparator
/*    */   {
/*    */     public int compare(WritableComparable a, WritableComparable b)
/*    */     {
/* 85 */       return -super.compare(a, b);
/*    */     }
/*    */     public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
/* 88 */       return -super.compare(b1, s1, l1, b2, s2, l2);
/*    */     }
/*    */   }
/*    */ 
/*    */   public static class Comparator extends WritableComparator
/*    */   {
/*    */     public Comparator()
/*    */     {
/* 71 */       super();
/*    */     }
/*    */ 
/*    */     public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2)
/*    */     {
/* 76 */       long thisValue = readLong(b1, s1);
/* 77 */       long thatValue = readLong(b2, s2);
/* 78 */       return thisValue == thatValue ? 0 : thisValue < thatValue ? -1 : 1;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.LongWritable
 * JD-Core Version:    0.6.1
 */
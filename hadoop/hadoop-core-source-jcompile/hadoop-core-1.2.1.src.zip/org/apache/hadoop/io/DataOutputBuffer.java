/*     */ package org.apache.hadoop.io;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public class DataOutputBuffer extends DataOutputStream
/*     */ {
/*     */   private Buffer buffer;
/*     */ 
/*     */   public DataOutputBuffer()
/*     */   {
/*  72 */     this(new Buffer());
/*     */   }
/*     */ 
/*     */   public DataOutputBuffer(int size) {
/*  76 */     this(new Buffer(size));
/*     */   }
/*     */ 
/*     */   private DataOutputBuffer(Buffer buffer) {
/*  80 */     super(buffer);
/*  81 */     this.buffer = buffer;
/*     */   }
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/*  87 */     return this.buffer.getData();
/*     */   }
/*     */   public int getLength() {
/*  90 */     return this.buffer.getLength();
/*     */   }
/*     */ 
/*     */   public DataOutputBuffer reset() {
/*  94 */     this.written = 0;
/*  95 */     this.buffer.reset();
/*  96 */     return this;
/*     */   }
/*     */ 
/*     */   public void write(DataInput in, int length) throws IOException
/*     */   {
/* 101 */     this.buffer.write(in, length);
/*     */   }
/*     */ 
/*     */   public void writeTo(OutputStream out) throws IOException
/*     */   {
/* 106 */     this.buffer.writeTo(out);
/*     */   }
/*     */ 
/*     */   private static class Buffer extends ByteArrayOutputStream
/*     */   {
/*     */     public byte[] getData()
/*     */     {
/*  45 */       return this.buf; } 
/*  46 */     public int getLength() { return this.count; }
/*     */ 
/*     */     public Buffer()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Buffer(int size) {
/*  53 */       super();
/*     */     }
/*     */ 
/*     */     public void write(DataInput in, int len) throws IOException {
/*  57 */       int newcount = this.count + len;
/*  58 */       if (newcount > this.buf.length) {
/*  59 */         byte[] newbuf = new byte[Math.max(this.buf.length << 1, newcount)];
/*  60 */         System.arraycopy(this.buf, 0, newbuf, 0, this.count);
/*  61 */         this.buf = newbuf;
/*     */       }
/*  63 */       in.readFully(this.buf, this.count, len);
/*  64 */       this.count = newcount;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.DataOutputBuffer
 * JD-Core Version:    0.6.1
 */
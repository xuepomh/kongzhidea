/*     */ package org.apache.hadoop.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ 
/*     */ public class SetFile extends MapFile
/*     */ {
/*     */   public static class Reader extends MapFile.Reader
/*     */   {
/*     */     public Reader(FileSystem fs, String dirName, Configuration conf)
/*     */       throws IOException
/*     */     {
/*  71 */       super(dirName, conf);
/*     */     }
/*     */ 
/*     */     public Reader(FileSystem fs, String dirName, WritableComparator comparator, Configuration conf)
/*     */       throws IOException
/*     */     {
/*  77 */       super(dirName, comparator, conf);
/*     */     }
/*     */ 
/*     */     public boolean seek(WritableComparable key)
/*     */       throws IOException
/*     */     {
/*  83 */       return super.seek(key);
/*     */     }
/*     */ 
/*     */     public boolean next(WritableComparable key)
/*     */       throws IOException
/*     */     {
/*  90 */       return next(key, NullWritable.get());
/*     */     }
/*     */ 
/*     */     public WritableComparable get(WritableComparable key)
/*     */       throws IOException
/*     */     {
/*  97 */       if (seek(key)) {
/*  98 */         next(key);
/*  99 */         return key;
/*     */       }
/* 101 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Writer extends MapFile.Writer
/*     */   {
/*     */     /** @deprecated */
/*     */     public Writer(FileSystem fs, String dirName, Class<? extends WritableComparable> keyClass)
/*     */       throws IOException
/*     */     {
/*  41 */       super(fs, dirName, keyClass, NullWritable.class);
/*     */     }
/*     */ 
/*     */     public Writer(Configuration conf, FileSystem fs, String dirName, Class<? extends WritableComparable> keyClass, SequenceFile.CompressionType compress)
/*     */       throws IOException
/*     */     {
/*  49 */       this(conf, fs, dirName, WritableComparator.get(keyClass), compress);
/*     */     }
/*     */ 
/*     */     public Writer(Configuration conf, FileSystem fs, String dirName, WritableComparator comparator, SequenceFile.CompressionType compress)
/*     */       throws IOException
/*     */     {
/*  56 */       super(fs, dirName, comparator, NullWritable.class, compress);
/*     */     }
/*     */ 
/*     */     public void append(WritableComparable key)
/*     */       throws IOException
/*     */     {
/*  62 */       append(key, NullWritable.get());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.SetFile
 * JD-Core Version:    0.6.1
 */
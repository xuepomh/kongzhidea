/*    */ package org.apache.hadoop.io;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.DataInput;
/*    */ import java.io.DataInputStream;
/*    */ import java.io.DataOutput;
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.util.zip.Deflater;
/*    */ import java.util.zip.DeflaterOutputStream;
/*    */ import java.util.zip.InflaterInputStream;
/*    */ 
/*    */ public abstract class CompressedWritable
/*    */   implements Writable
/*    */ {
/*    */   private byte[] compressed;
/*    */ 
/*    */   public final void readFields(DataInput in)
/*    */     throws IOException
/*    */   {
/* 44 */     this.compressed = new byte[in.readInt()];
/* 45 */     in.readFully(this.compressed, 0, this.compressed.length);
/*    */   }
/*    */ 
/*    */   protected void ensureInflated()
/*    */   {
/* 51 */     if (this.compressed != null)
/*    */       try {
/* 53 */         ByteArrayInputStream deflated = new ByteArrayInputStream(this.compressed);
/* 54 */         DataInput inflater = new DataInputStream(new InflaterInputStream(deflated));
/*    */ 
/* 56 */         readFieldsCompressed(inflater);
/* 57 */         this.compressed = null;
/*    */       } catch (IOException e) {
/* 59 */         throw new RuntimeException(e);
/*    */       }
/*    */   }
/*    */ 
/*    */   protected abstract void readFieldsCompressed(DataInput paramDataInput)
/*    */     throws IOException;
/*    */ 
/*    */   public final void write(DataOutput out)
/*    */     throws IOException
/*    */   {
/* 69 */     if (this.compressed == null) {
/* 70 */       ByteArrayOutputStream deflated = new ByteArrayOutputStream();
/* 71 */       Deflater deflater = new Deflater(1);
/* 72 */       DataOutputStream dout = new DataOutputStream(new DeflaterOutputStream(deflated, deflater));
/*    */ 
/* 74 */       writeCompressed(dout);
/* 75 */       dout.close();
/* 76 */       deflater.end();
/* 77 */       this.compressed = deflated.toByteArray();
/*    */     }
/* 79 */     out.writeInt(this.compressed.length);
/* 80 */     out.write(this.compressed);
/*    */   }
/*    */ 
/*    */   protected abstract void writeCompressed(DataOutput paramDataOutput)
/*    */     throws IOException;
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.CompressedWritable
 * JD-Core Version:    0.6.1
 */
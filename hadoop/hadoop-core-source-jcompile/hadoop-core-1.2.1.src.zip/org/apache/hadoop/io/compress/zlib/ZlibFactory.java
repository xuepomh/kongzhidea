/*     */ package org.apache.hadoop.io.compress.zlib;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.io.compress.Compressor;
/*     */ import org.apache.hadoop.io.compress.Decompressor;
/*     */ import org.apache.hadoop.util.NativeCodeLoader;
/*     */ 
/*     */ public class ZlibFactory
/*     */ {
/*  36 */   private static final Log LOG = LogFactory.getLog(ZlibFactory.class);
/*     */ 
/*  39 */   private static boolean nativeZlibLoaded = false;
/*     */ 
/*     */   public static boolean isNativeZlibLoaded(Configuration conf)
/*     */   {
/*  63 */     return (nativeZlibLoaded) && (conf.getBoolean("hadoop.native.lib", true));
/*     */   }
/*     */ 
/*     */   public static Class<? extends Compressor> getZlibCompressorType(Configuration conf)
/*     */   {
/*  74 */     return isNativeZlibLoaded(conf) ? ZlibCompressor.class : BuiltInZlibDeflater.class;
/*     */   }
/*     */ 
/*     */   public static Compressor getZlibCompressor(Configuration conf)
/*     */   {
/*  85 */     return isNativeZlibLoaded(conf) ? new ZlibCompressor(conf) : new BuiltInZlibDeflater(conf);
/*     */   }
/*     */ 
/*     */   public static Class<? extends Decompressor> getZlibDecompressorType(Configuration conf)
/*     */   {
/*  98 */     return isNativeZlibLoaded(conf) ? ZlibDecompressor.class : BuiltInZlibInflater.class;
/*     */   }
/*     */ 
/*     */   public static Decompressor getZlibDecompressor(Configuration conf)
/*     */   {
/* 109 */     return isNativeZlibLoaded(conf) ? new ZlibDecompressor() : new BuiltInZlibInflater();
/*     */   }
/*     */ 
/*     */   public static void setCompressionStrategy(Configuration conf, ZlibCompressor.CompressionStrategy strategy)
/*     */   {
/* 115 */     conf.setEnum("zlib.compress.strategy", strategy);
/*     */   }
/*     */ 
/*     */   public static ZlibCompressor.CompressionStrategy getCompressionStrategy(Configuration conf) {
/* 119 */     return (ZlibCompressor.CompressionStrategy)conf.getEnum("zlib.compress.strategy", ZlibCompressor.CompressionStrategy.DEFAULT_STRATEGY);
/*     */   }
/*     */ 
/*     */   public static void setCompressionLevel(Configuration conf, ZlibCompressor.CompressionLevel level)
/*     */   {
/* 125 */     conf.setEnum("zlib.compress.level", level);
/*     */   }
/*     */ 
/*     */   public static ZlibCompressor.CompressionLevel getCompressionLevel(Configuration conf) {
/* 129 */     return (ZlibCompressor.CompressionLevel)conf.getEnum("zlib.compress.level", ZlibCompressor.CompressionLevel.DEFAULT_COMPRESSION);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  42 */     if (NativeCodeLoader.isNativeCodeLoaded()) {
/*  43 */       nativeZlibLoaded = (ZlibCompressor.isNativeZlibLoaded()) && (ZlibDecompressor.isNativeZlibLoaded());
/*     */ 
/*  46 */       if (nativeZlibLoaded)
/*  47 */         LOG.info("Successfully loaded & initialized native-zlib library");
/*     */       else
/*  49 */         LOG.warn("Failed to load/initialize native-zlib library");
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.zlib.ZlibFactory
 * JD-Core Version:    0.6.1
 */
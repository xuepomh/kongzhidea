/*    */ package org.apache.hadoop.io.compress.snappy;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.apache.hadoop.util.NativeCodeLoader;
/*    */ 
/*    */ public class LoadSnappy
/*    */ {
/* 28 */   private static final Log LOG = LogFactory.getLog(LoadSnappy.class.getName());
/*    */ 
/* 30 */   private static boolean AVAILABLE = false;
/* 31 */   private static boolean LOADED = false;
/*    */ 
/*    */   public static boolean isAvailable()
/*    */   {
/* 57 */     return AVAILABLE;
/*    */   }
/*    */ 
/*    */   public static boolean isLoaded()
/*    */   {
/* 67 */     return LOADED;
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 35 */       System.loadLibrary("snappy");
/* 36 */       LOG.warn("Snappy native library is available");
/* 37 */       AVAILABLE = true;
/*    */     }
/*    */     catch (UnsatisfiedLinkError ex) {
/*    */     }
/* 41 */     boolean hadoopNativeAvailable = NativeCodeLoader.isNativeCodeLoaded();
/* 42 */     LOADED = (AVAILABLE) && (hadoopNativeAvailable);
/* 43 */     if (LOADED)
/* 44 */       LOG.info("Snappy native library loaded");
/*    */     else
/* 46 */       LOG.warn("Snappy native library not loaded");
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.snappy.LoadSnappy
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.io.compress.zlib;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.zip.Deflater;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ import org.apache.hadoop.io.compress.Compressor;
/*    */ import org.mortbay.log.Log;
/*    */ 
/*    */ public class BuiltInZlibDeflater extends Deflater
/*    */   implements Compressor
/*    */ {
/*    */   public BuiltInZlibDeflater(int level, boolean nowrap)
/*    */   {
/* 36 */     super(level, nowrap);
/*    */   }
/*    */ 
/*    */   BuiltInZlibDeflater(Configuration conf) {
/* 40 */     this(null == conf ? -1 : ZlibFactory.getCompressionLevel(conf).compressionLevel());
/*    */ 
/* 43 */     if (conf != null) {
/* 44 */       ZlibCompressor.CompressionStrategy strategy = ZlibFactory.getCompressionStrategy(conf);
/*    */       try
/*    */       {
/* 47 */         setStrategy(strategy.compressionStrategy());
/*    */       } catch (IllegalArgumentException ill) {
/* 49 */         Log.warn(strategy + " not supported by BuiltInZlibDeflater.");
/* 50 */         setStrategy(0);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public BuiltInZlibDeflater(int level) {
/* 56 */     super(level);
/*    */   }
/*    */ 
/*    */   public BuiltInZlibDeflater()
/*    */   {
/*    */   }
/*    */ 
/*    */   public synchronized int compress(byte[] b, int off, int len) throws IOException
/*    */   {
/* 65 */     return super.deflate(b, off, len);
/*    */   }
/*    */ 
/*    */   public void reinit(Configuration conf)
/*    */   {
/* 78 */     reset();
/* 79 */     if (conf == null) {
/* 80 */       return;
/*    */     }
/* 82 */     setLevel(ZlibFactory.getCompressionLevel(conf).compressionLevel());
/* 83 */     ZlibCompressor.CompressionStrategy strategy = ZlibFactory.getCompressionStrategy(conf);
/*    */     try
/*    */     {
/* 86 */       setStrategy(strategy.compressionStrategy());
/*    */     } catch (IllegalArgumentException ill) {
/* 88 */       Log.warn(strategy + " not supported by BuiltInZlibDeflater.");
/* 89 */       setStrategy(0);
/*    */     }
/* 91 */     Log.debug("Reinit compressor with new compression configuration");
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.zlib.BuiltInZlibDeflater
 * JD-Core Version:    0.6.1
 */
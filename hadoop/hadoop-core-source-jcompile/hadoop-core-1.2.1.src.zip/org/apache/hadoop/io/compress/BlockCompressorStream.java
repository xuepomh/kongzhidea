/*     */ package org.apache.hadoop.io.compress;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public class BlockCompressorStream extends CompressorStream
/*     */ {
/*     */   private final int MAX_INPUT_SIZE;
/*     */ 
/*     */   public BlockCompressorStream(OutputStream out, Compressor compressor, int bufferSize, int compressionOverhead)
/*     */   {
/*  51 */     super(out, compressor, bufferSize);
/*  52 */     this.MAX_INPUT_SIZE = (bufferSize - compressionOverhead);
/*     */   }
/*     */ 
/*     */   public BlockCompressorStream(OutputStream out, Compressor compressor)
/*     */   {
/*  65 */     this(out, compressor, 512, 18);
/*     */   }
/*     */ 
/*     */   public void write(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/*  78 */     if (this.compressor.finished()) {
/*  79 */       throw new IOException("write beyond end of stream");
/*     */     }
/*  81 */     if (b == null)
/*  82 */       throw new NullPointerException();
/*  83 */     if ((off < 0) || (off > b.length) || (len < 0) || (off + len > b.length))
/*     */     {
/*  85 */       throw new IndexOutOfBoundsException();
/*  86 */     }if (len == 0) {
/*  87 */       return;
/*     */     }
/*     */ 
/*  90 */     long limlen = this.compressor.getBytesRead();
/*  91 */     if ((len + limlen > this.MAX_INPUT_SIZE) && (limlen > 0L))
/*     */     {
/*  94 */       finish();
/*  95 */       this.compressor.reset();
/*     */     }
/*     */ 
/*  98 */     if (len > this.MAX_INPUT_SIZE)
/*     */     {
/* 102 */       rawWriteInt(len);
/*     */       do {
/* 104 */         int bufLen = Math.min(len, this.MAX_INPUT_SIZE);
/*     */ 
/* 106 */         this.compressor.setInput(b, off, bufLen);
/* 107 */         this.compressor.finish();
/* 108 */         while (!this.compressor.finished()) {
/* 109 */           compress();
/*     */         }
/* 111 */         this.compressor.reset();
/* 112 */         off += bufLen;
/* 113 */         len -= bufLen;
/* 114 */       }while (len > 0);
/* 115 */       return;
/*     */     }
/*     */ 
/* 119 */     this.compressor.setInput(b, off, len);
/* 120 */     if (!this.compressor.needsInput())
/*     */     {
/* 123 */       rawWriteInt((int)this.compressor.getBytesRead());
/*     */       do
/* 125 */         compress();
/* 126 */       while (!this.compressor.needsInput());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void finish() throws IOException {
/* 131 */     if (!this.compressor.finished()) {
/* 132 */       rawWriteInt((int)this.compressor.getBytesRead());
/* 133 */       this.compressor.finish();
/* 134 */       while (!this.compressor.finished())
/* 135 */         compress();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void compress() throws IOException
/*     */   {
/* 141 */     int len = this.compressor.compress(this.buffer, 0, this.buffer.length);
/* 142 */     if (len > 0)
/*     */     {
/* 144 */       rawWriteInt(len);
/* 145 */       this.out.write(this.buffer, 0, len);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void rawWriteInt(int v) throws IOException {
/* 150 */     this.out.write(v >>> 24 & 0xFF);
/* 151 */     this.out.write(v >>> 16 & 0xFF);
/* 152 */     this.out.write(v >>> 8 & 0xFF);
/* 153 */     this.out.write(v >>> 0 & 0xFF);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.BlockCompressorStream
 * JD-Core Version:    0.6.1
 */
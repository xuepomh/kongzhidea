/*     */ package org.apache.hadoop.io.compress;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ public class BlockDecompressorStream extends DecompressorStream
/*     */ {
/*  32 */   private int originalBlockSize = 0;
/*  33 */   private int noUncompressedBytes = 0;
/*     */ 
/*     */   public BlockDecompressorStream(InputStream in, Decompressor decompressor, int bufferSize)
/*     */     throws IOException
/*     */   {
/*  45 */     super(in, decompressor, bufferSize);
/*     */   }
/*     */ 
/*     */   public BlockDecompressorStream(InputStream in, Decompressor decompressor)
/*     */     throws IOException
/*     */   {
/*  56 */     super(in, decompressor);
/*     */   }
/*     */ 
/*     */   protected BlockDecompressorStream(InputStream in) throws IOException {
/*  60 */     super(in);
/*     */   }
/*     */ 
/*     */   protected int decompress(byte[] b, int off, int len) throws IOException
/*     */   {
/*  65 */     if (this.noUncompressedBytes == this.originalBlockSize)
/*     */     {
/*     */       try {
/*  68 */         this.originalBlockSize = rawReadInt();
/*     */       } catch (IOException ioe) {
/*  70 */         return -1;
/*     */       }
/*  72 */       this.noUncompressedBytes = 0;
/*     */     }
/*     */ 
/*  75 */     int n = 0;
/*  76 */     while ((n = this.decompressor.decompress(b, off, len)) == 0) {
/*  77 */       if (((this.decompressor.finished()) || (this.decompressor.needsDictionary())) && 
/*  78 */         (this.noUncompressedBytes >= this.originalBlockSize)) {
/*  79 */         this.eof = true;
/*  80 */         return -1;
/*     */       }
/*     */ 
/*  83 */       if (this.decompressor.needsInput()) {
/*     */         int m;
/*     */         try {
/*  86 */           m = getCompressedData();
/*     */         } catch (EOFException e) {
/*  88 */           this.eof = true;
/*  89 */           return -1;
/*     */         }
/*     */ 
/*  92 */         this.decompressor.setInput(this.buffer, 0, m);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  97 */     this.noUncompressedBytes += n;
/*     */ 
/*  99 */     return n;
/*     */   }
/*     */ 
/*     */   protected int getCompressedData() throws IOException {
/* 103 */     checkStream();
/*     */ 
/* 106 */     int len = rawReadInt();
/*     */ 
/* 109 */     if (len > this.buffer.length) {
/* 110 */       this.buffer = new byte[len];
/*     */     }
/* 112 */     int n = 0; int off = 0;
/* 113 */     while (n < len) {
/* 114 */       int count = this.in.read(this.buffer, off + n, len - n);
/* 115 */       if (count < 0) {
/* 116 */         throw new EOFException("Unexpected end of block in input stream");
/*     */       }
/* 118 */       n += count;
/*     */     }
/*     */ 
/* 121 */     return len;
/*     */   }
/*     */ 
/*     */   public void resetState() throws IOException {
/* 125 */     this.originalBlockSize = 0;
/* 126 */     this.noUncompressedBytes = 0;
/* 127 */     super.resetState();
/*     */   }
/*     */ 
/*     */   private int rawReadInt() throws IOException {
/* 131 */     int b1 = this.in.read();
/* 132 */     int b2 = this.in.read();
/* 133 */     int b3 = this.in.read();
/* 134 */     int b4 = this.in.read();
/* 135 */     if ((b1 | b2 | b3 | b4) < 0)
/* 136 */       throw new EOFException();
/* 137 */     return (b1 << 24) + (b2 << 16) + (b3 << 8) + (b4 << 0);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.BlockDecompressorStream
 * JD-Core Version:    0.6.1
 */
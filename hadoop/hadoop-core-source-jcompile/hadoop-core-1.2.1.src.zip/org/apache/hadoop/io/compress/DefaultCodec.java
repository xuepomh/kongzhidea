/*    */ package org.apache.hadoop.io.compress;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import org.apache.hadoop.conf.Configurable;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ import org.apache.hadoop.io.compress.zlib.ZlibFactory;
/*    */ 
/*    */ public class DefaultCodec
/*    */   implements Configurable, CompressionCodec
/*    */ {
/*    */   Configuration conf;
/*    */ 
/*    */   public void setConf(Configuration conf)
/*    */   {
/* 34 */     this.conf = conf;
/*    */   }
/*    */ 
/*    */   public Configuration getConf() {
/* 38 */     return this.conf;
/*    */   }
/*    */ 
/*    */   public CompressionOutputStream createOutputStream(OutputStream out) throws IOException
/*    */   {
/* 43 */     return new CompressorStream(out, createCompressor(), this.conf.getInt("io.file.buffer.size", 4096));
/*    */   }
/*    */ 
/*    */   public CompressionOutputStream createOutputStream(OutputStream out, Compressor compressor)
/*    */     throws IOException
/*    */   {
/* 50 */     return new CompressorStream(out, compressor, this.conf.getInt("io.file.buffer.size", 4096));
/*    */   }
/*    */ 
/*    */   public Class<? extends Compressor> getCompressorType()
/*    */   {
/* 55 */     return ZlibFactory.getZlibCompressorType(this.conf);
/*    */   }
/*    */ 
/*    */   public Compressor createCompressor() {
/* 59 */     return ZlibFactory.getZlibCompressor(this.conf);
/*    */   }
/*    */ 
/*    */   public CompressionInputStream createInputStream(InputStream in) throws IOException
/*    */   {
/* 64 */     return new DecompressorStream(in, createDecompressor(), this.conf.getInt("io.file.buffer.size", 4096));
/*    */   }
/*    */ 
/*    */   public CompressionInputStream createInputStream(InputStream in, Decompressor decompressor)
/*    */     throws IOException
/*    */   {
/* 71 */     return new DecompressorStream(in, decompressor, this.conf.getInt("io.file.buffer.size", 4096));
/*    */   }
/*    */ 
/*    */   public Class<? extends Decompressor> getDecompressorType()
/*    */   {
/* 76 */     return ZlibFactory.getZlibDecompressorType(this.conf);
/*    */   }
/*    */ 
/*    */   public Decompressor createDecompressor() {
/* 80 */     return ZlibFactory.getZlibDecompressor(this.conf);
/*    */   }
/*    */ 
/*    */   public String getDefaultExtension() {
/* 84 */     return ".deflate";
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.DefaultCodec
 * JD-Core Version:    0.6.1
 */
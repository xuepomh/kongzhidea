/*     */ package org.apache.hadoop.io.compress;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.util.ReflectionUtils;
/*     */ 
/*     */ public class CompressionCodecFactory
/*     */ {
/*  33 */   public static final Log LOG = LogFactory.getLog(CompressionCodecFactory.class.getName());
/*     */ 
/*  41 */   private SortedMap<String, CompressionCodec> codecs = null;
/*     */ 
/*  48 */   private Map<String, CompressionCodec> codecsByName = null;
/*     */ 
/*  53 */   private HashMap<String, CompressionCodec> codecsByClassName = null;
/*     */ 
/*     */   private void addCodec(CompressionCodec codec) {
/*  56 */     String suffix = codec.getDefaultExtension();
/*  57 */     this.codecs.put(new StringBuffer(suffix).reverse().toString(), codec);
/*  58 */     this.codecsByClassName.put(codec.getClass().getCanonicalName(), codec);
/*     */ 
/*  60 */     String codecName = codec.getClass().getSimpleName();
/*  61 */     this.codecsByName.put(codecName.toLowerCase(), codec);
/*  62 */     if (codecName.endsWith("Codec")) {
/*  63 */       codecName = codecName.substring(0, codecName.length() - "Codec".length());
/*  64 */       this.codecsByName.put(codecName.toLowerCase(), codec);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  72 */     StringBuffer buf = new StringBuffer();
/*  73 */     Iterator itr = this.codecs.entrySet().iterator();
/*     */ 
/*  75 */     buf.append("{ ");
/*  76 */     if (itr.hasNext()) {
/*  77 */       Map.Entry entry = (Map.Entry)itr.next();
/*  78 */       buf.append((String)entry.getKey());
/*  79 */       buf.append(": ");
/*  80 */       buf.append(((CompressionCodec)entry.getValue()).getClass().getName());
/*  81 */       while (itr.hasNext()) {
/*  82 */         entry = (Map.Entry)itr.next();
/*  83 */         buf.append(", ");
/*  84 */         buf.append((String)entry.getKey());
/*  85 */         buf.append(": ");
/*  86 */         buf.append(((CompressionCodec)entry.getValue()).getClass().getName());
/*     */       }
/*     */     }
/*  89 */     buf.append(" }");
/*  90 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   public static List<Class<? extends CompressionCodec>> getCodecClasses(Configuration conf)
/*     */   {
/* 100 */     String codecsString = conf.get("io.compression.codecs");
/* 101 */     if (codecsString != null) {
/* 102 */       List result = new ArrayList();
/*     */ 
/* 104 */       StringTokenizer codecSplit = new StringTokenizer(codecsString, ",");
/* 105 */       while (codecSplit.hasMoreElements()) {
/* 106 */         String codecSubstring = codecSplit.nextToken();
/* 107 */         if (codecSubstring.length() != 0) {
/*     */           try {
/* 109 */             Class cls = conf.getClassByName(codecSubstring);
/* 110 */             if (!CompressionCodec.class.isAssignableFrom(cls)) {
/* 111 */               throw new IllegalArgumentException("Class " + codecSubstring + " is not a CompressionCodec");
/*     */             }
/*     */ 
/* 114 */             result.add(cls.asSubclass(CompressionCodec.class));
/*     */           } catch (ClassNotFoundException ex) {
/* 116 */             throw new IllegalArgumentException("Compression codec " + codecSubstring + " not found.", ex);
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 122 */       return result;
/*     */     }
/* 124 */     return null;
/*     */   }
/*     */ 
/*     */   public static void setCodecClasses(Configuration conf, List<Class> classes)
/*     */   {
/* 135 */     StringBuffer buf = new StringBuffer();
/* 136 */     Iterator itr = classes.iterator();
/* 137 */     if (itr.hasNext()) {
/* 138 */       Class cls = (Class)itr.next();
/* 139 */       buf.append(cls.getName());
/* 140 */       while (itr.hasNext()) {
/* 141 */         buf.append(',');
/* 142 */         buf.append(((Class)itr.next()).getName());
/*     */       }
/*     */     }
/* 145 */     conf.set("io.compression.codecs", buf.toString());
/*     */   }
/*     */ 
/*     */   public CompressionCodecFactory(Configuration conf)
/*     */   {
/* 153 */     this.codecs = new TreeMap();
/* 154 */     this.codecsByClassName = new HashMap();
/* 155 */     this.codecsByName = new HashMap();
/* 156 */     List codecClasses = getCodecClasses(conf);
/* 157 */     if (codecClasses == null) {
/* 158 */       addCodec(new GzipCodec());
/* 159 */       addCodec(new DefaultCodec());
/*     */     } else {
/* 161 */       Iterator itr = codecClasses.iterator();
/* 162 */       while (itr.hasNext()) {
/* 163 */         CompressionCodec codec = (CompressionCodec)ReflectionUtils.newInstance((Class)itr.next(), conf);
/* 164 */         addCodec(codec);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public CompressionCodec getCodec(Path file)
/*     */   {
/* 176 */     CompressionCodec result = null;
/* 177 */     if (this.codecs != null) {
/* 178 */       String filename = file.getName();
/* 179 */       String reversedFilename = new StringBuffer(filename).reverse().toString();
/* 180 */       SortedMap subMap = this.codecs.headMap(reversedFilename);
/*     */ 
/* 182 */       if (!subMap.isEmpty()) {
/* 183 */         String potentialSuffix = (String)subMap.lastKey();
/* 184 */         if (reversedFilename.startsWith(potentialSuffix)) {
/* 185 */           result = (CompressionCodec)this.codecs.get(potentialSuffix);
/*     */         }
/*     */       }
/*     */     }
/* 189 */     return result;
/*     */   }
/*     */ 
/*     */   public CompressionCodec getCodecByClassName(String classname)
/*     */   {
/* 198 */     if (this.codecsByClassName == null) {
/* 199 */       return null;
/*     */     }
/* 201 */     return (CompressionCodec)this.codecsByClassName.get(classname);
/*     */   }
/*     */ 
/*     */   public CompressionCodec getCodecByName(String codecName)
/*     */   {
/* 220 */     if (this.codecsByClassName == null) {
/* 221 */       return null;
/*     */     }
/* 223 */     CompressionCodec codec = getCodecByClassName(codecName);
/* 224 */     if (codec == null)
/*     */     {
/* 226 */       codec = (CompressionCodec)this.codecsByName.get(codecName.toLowerCase());
/*     */     }
/* 228 */     return codec;
/*     */   }
/*     */ 
/*     */   public Class<? extends CompressionCodec> getCodecClassByName(String codecName)
/*     */   {
/* 247 */     CompressionCodec codec = getCodecByName(codecName);
/* 248 */     if (codec == null) {
/* 249 */       return null;
/*     */     }
/* 251 */     return codec.getClass();
/*     */   }
/*     */ 
/*     */   public static String removeSuffix(String filename, String suffix)
/*     */   {
/* 261 */     if (filename.endsWith(suffix)) {
/* 262 */       return filename.substring(0, filename.length() - suffix.length());
/*     */     }
/* 264 */     return filename;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/* 272 */     Configuration conf = new Configuration();
/* 273 */     CompressionCodecFactory factory = new CompressionCodecFactory(conf);
/* 274 */     boolean encode = false;
/* 275 */     for (int i = 0; i < args.length; i++)
/* 276 */       if ("-in".equals(args[i])) {
/* 277 */         encode = true;
/* 278 */       } else if ("-out".equals(args[i])) {
/* 279 */         encode = false;
/*     */       } else {
/* 281 */         CompressionCodec codec = factory.getCodec(new Path(args[i]));
/* 282 */         if (codec == null) {
/* 283 */           System.out.println("Codec for " + args[i] + " not found.");
/*     */         }
/* 285 */         else if (encode) {
/* 286 */           CompressionOutputStream out = codec.createOutputStream(new FileOutputStream(args[i]));
/*     */ 
/* 288 */           byte[] buffer = new byte[100];
/* 289 */           String inFilename = removeSuffix(args[i], codec.getDefaultExtension());
/*     */ 
/* 291 */           InputStream in = new FileInputStream(inFilename);
/* 292 */           int len = in.read(buffer);
/* 293 */           while (len > 0) {
/* 294 */             out.write(buffer, 0, len);
/* 295 */             len = in.read(buffer);
/*     */           }
/* 297 */           in.close();
/* 298 */           out.close();
/*     */         } else {
/* 300 */           CompressionInputStream in = codec.createInputStream(new FileInputStream(args[i]));
/*     */ 
/* 302 */           byte[] buffer = new byte[100];
/* 303 */           int len = in.read(buffer);
/* 304 */           while (len > 0) {
/* 305 */             System.out.write(buffer, 0, len);
/* 306 */             len = in.read(buffer);
/*     */           }
/* 308 */           in.close();
/*     */         }
/*     */       }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.CompressionCodecFactory
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.io.compress;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ public abstract interface SplittableCompressionCodec extends CompressionCodec
/*    */ {
/*    */   public abstract SplitCompressionInputStream createInputStream(InputStream paramInputStream, Decompressor paramDecompressor, long paramLong1, long paramLong2, READ_MODE paramREAD_MODE)
/*    */     throws IOException;
/*    */ 
/*    */   public static enum READ_MODE
/*    */   {
/* 52 */     CONTINUOUS, BYBLOCK;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.SplittableCompressionCodec
 * JD-Core Version:    0.6.1
 */
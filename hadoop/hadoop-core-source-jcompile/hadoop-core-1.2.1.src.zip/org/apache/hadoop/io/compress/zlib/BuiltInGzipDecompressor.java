/*     */ package org.apache.hadoop.io.compress.zlib;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.zip.CRC32;
/*     */ import java.util.zip.DataFormatException;
/*     */ import java.util.zip.Inflater;
/*     */ import org.apache.hadoop.io.compress.Decompressor;
/*     */ import org.apache.hadoop.io.compress.DoNotPool;
/*     */ 
/*     */ @DoNotPool
/*     */ public class BuiltInGzipDecompressor
/*     */   implements Decompressor
/*     */ {
/*     */   private static final int GZIP_MAGIC_ID = 35615;
/*     */   private static final int GZIP_DEFLATE_METHOD = 8;
/*     */   private static final int GZIP_FLAGBIT_HEADER_CRC = 2;
/*     */   private static final int GZIP_FLAGBIT_EXTRA_FIELD = 4;
/*     */   private static final int GZIP_FLAGBIT_FILENAME = 8;
/*     */   private static final int GZIP_FLAGBIT_COMMENT = 16;
/*     */   private static final int GZIP_FLAGBITS_RESERVED = 224;
/*  45 */   private Inflater inflater = new Inflater(true);
/*     */ 
/*  47 */   private byte[] userBuf = null;
/*  48 */   private int userBufOff = 0;
/*  49 */   private int userBufLen = 0;
/*     */ 
/*  51 */   private byte[] localBuf = new byte[256];
/*  52 */   private int localBufOff = 0;
/*     */ 
/*  54 */   private int headerBytesRead = 0;
/*  55 */   private int trailerBytesRead = 0;
/*  56 */   private int numExtraFieldBytesRemaining = -1;
/*  57 */   private CRC32 crc = new CRC32();
/*  58 */   private boolean hasExtraField = false;
/*  59 */   private boolean hasFilename = false;
/*  60 */   private boolean hasComment = false;
/*  61 */   private boolean hasHeaderCRC = false;
/*     */   private GzipStateLabel state;
/*     */ 
/*     */   public BuiltInGzipDecompressor()
/*     */   {
/* 114 */     this.state = GzipStateLabel.HEADER_BASIC;
/* 115 */     this.crc.reset();
/*     */   }
/*     */ 
/*     */   public synchronized boolean needsInput()
/*     */   {
/* 127 */     if (this.state == GzipStateLabel.DEFLATE_STREAM) {
/* 128 */       return this.inflater.needsInput();
/*     */     }
/*     */ 
/* 132 */     return this.state != GzipStateLabel.FINISHED;
/*     */   }
/*     */ 
/*     */   public synchronized void setInput(byte[] b, int off, int len)
/*     */   {
/* 148 */     if (b == null) {
/* 149 */       throw new NullPointerException();
/*     */     }
/* 151 */     if ((off < 0) || (len < 0) || (off > b.length - len)) {
/* 152 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/*     */ 
/* 155 */     this.userBuf = b;
/* 156 */     this.userBufOff = off;
/* 157 */     this.userBufLen = len;
/*     */   }
/*     */ 
/*     */   public synchronized int decompress(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 180 */     int numAvailBytes = 0;
/*     */ 
/* 182 */     if (this.state != GzipStateLabel.DEFLATE_STREAM) {
/* 183 */       executeHeaderState();
/*     */ 
/* 185 */       if (this.userBufLen <= 0) {
/* 186 */         return numAvailBytes;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 191 */     if (this.state == GzipStateLabel.DEFLATE_STREAM)
/*     */     {
/* 196 */       if (this.userBufLen > 0) {
/* 197 */         this.inflater.setInput(this.userBuf, this.userBufOff, this.userBufLen);
/* 198 */         this.userBufOff += this.userBufLen;
/* 199 */         this.userBufLen = 0;
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 204 */         numAvailBytes = this.inflater.inflate(b, off, len);
/*     */       } catch (DataFormatException dfe) {
/* 206 */         throw new IOException(dfe.getMessage());
/*     */       }
/* 208 */       this.crc.update(b, off, numAvailBytes);
/* 209 */       if (this.inflater.finished()) {
/* 210 */         this.state = GzipStateLabel.TRAILER_CRC;
/* 211 */         int bytesRemaining = this.inflater.getRemaining();
/*     */ 
/* 213 */         assert (bytesRemaining >= 0) : "logic error: Inflater finished; byte-count is inconsistent";
/*     */ 
/* 217 */         this.userBufOff -= bytesRemaining;
/* 218 */         this.userBufLen = bytesRemaining;
/*     */       } else {
/* 220 */         return numAvailBytes;
/*     */       }
/*     */     }
/*     */ 
/* 224 */     executeTrailerState();
/*     */ 
/* 226 */     return numAvailBytes;
/*     */   }
/*     */ 
/*     */   private void executeHeaderState()
/*     */     throws IOException
/*     */   {
/* 245 */     if (this.userBufLen <= 0) {
/* 246 */       return;
/*     */     }
/*     */ 
/* 250 */     if (this.state == GzipStateLabel.HEADER_BASIC) {
/* 251 */       int n = Math.min(this.userBufLen, 10 - this.localBufOff);
/* 252 */       checkAndCopyBytesToLocal(n);
/* 253 */       if (this.localBufOff >= 10) {
/* 254 */         processBasicHeader();
/* 255 */         this.localBufOff = 0;
/* 256 */         this.state = GzipStateLabel.HEADER_EXTRA_FIELD;
/*     */       }
/*     */     }
/*     */ 
/* 260 */     if (this.userBufLen <= 0) {
/* 261 */       return;
/*     */     }
/*     */ 
/* 266 */     if (this.state == GzipStateLabel.HEADER_EXTRA_FIELD) {
/* 267 */       if (this.hasExtraField)
/*     */       {
/* 270 */         if (this.numExtraFieldBytesRemaining < 0) {
/* 271 */           int n = Math.min(this.userBufLen, 2 - this.localBufOff);
/* 272 */           checkAndCopyBytesToLocal(n);
/* 273 */           if (this.localBufOff >= 2) {
/* 274 */             this.numExtraFieldBytesRemaining = readUShortLE(this.localBuf, 0);
/* 275 */             this.localBufOff = 0;
/*     */           }
/*     */         }
/* 278 */         if ((this.numExtraFieldBytesRemaining > 0) && (this.userBufLen > 0)) {
/* 279 */           int n = Math.min(this.userBufLen, this.numExtraFieldBytesRemaining);
/* 280 */           checkAndSkipBytes(n);
/* 281 */           this.numExtraFieldBytesRemaining -= n;
/*     */         }
/* 283 */         if (this.numExtraFieldBytesRemaining == 0)
/* 284 */           this.state = GzipStateLabel.HEADER_FILENAME;
/*     */       }
/*     */       else {
/* 287 */         this.state = GzipStateLabel.HEADER_FILENAME;
/*     */       }
/*     */     }
/*     */ 
/* 291 */     if (this.userBufLen <= 0) {
/* 292 */       return;
/*     */     }
/*     */ 
/* 295 */     if (this.state == GzipStateLabel.HEADER_FILENAME) {
/* 296 */       if (this.hasFilename) {
/* 297 */         boolean doneWithFilename = checkAndSkipBytesUntilNull();
/* 298 */         if (!doneWithFilename) {
/* 299 */           return;
/*     */         }
/*     */       }
/* 302 */       this.state = GzipStateLabel.HEADER_COMMENT;
/*     */     }
/*     */ 
/* 305 */     if (this.userBufLen <= 0) {
/* 306 */       return;
/*     */     }
/*     */ 
/* 309 */     if (this.state == GzipStateLabel.HEADER_COMMENT) {
/* 310 */       if (this.hasComment) {
/* 311 */         boolean doneWithComment = checkAndSkipBytesUntilNull();
/* 312 */         if (!doneWithComment) {
/* 313 */           return;
/*     */         }
/*     */       }
/* 316 */       this.state = GzipStateLabel.HEADER_CRC;
/*     */     }
/*     */ 
/* 319 */     if (this.userBufLen <= 0) {
/* 320 */       return;
/*     */     }
/*     */ 
/* 323 */     if (this.state == GzipStateLabel.HEADER_CRC)
/* 324 */       if (this.hasHeaderCRC) {
/* 325 */         assert (this.localBufOff < 2);
/* 326 */         int n = Math.min(this.userBufLen, 2 - this.localBufOff);
/* 327 */         copyBytesToLocal(n);
/* 328 */         if (this.localBufOff >= 2) {
/* 329 */           long headerCRC = readUShortLE(this.localBuf, 0);
/* 330 */           if (headerCRC != (this.crc.getValue() & 0xFFFF)) {
/* 331 */             throw new IOException("gzip header CRC failure");
/*     */           }
/* 333 */           this.localBufOff = 0;
/* 334 */           this.crc.reset();
/* 335 */           this.state = GzipStateLabel.DEFLATE_STREAM;
/*     */         }
/*     */       } else {
/* 338 */         this.crc.reset();
/* 339 */         this.state = GzipStateLabel.DEFLATE_STREAM;
/*     */       }
/*     */   }
/*     */ 
/*     */   private void executeTrailerState()
/*     */     throws IOException
/*     */   {
/* 353 */     if (this.userBufLen <= 0) {
/* 354 */       return;
/*     */     }
/*     */ 
/* 359 */     if (this.state == GzipStateLabel.TRAILER_CRC)
/*     */     {
/* 362 */       assert (this.localBufOff < 4);
/* 363 */       int n = Math.min(this.userBufLen, 4 - this.localBufOff);
/* 364 */       copyBytesToLocal(n);
/* 365 */       if (this.localBufOff >= 4) {
/* 366 */         long streamCRC = readUIntLE(this.localBuf, 0);
/* 367 */         if (streamCRC != this.crc.getValue()) {
/* 368 */           throw new IOException("gzip stream CRC failure");
/*     */         }
/* 370 */         this.localBufOff = 0;
/* 371 */         this.crc.reset();
/* 372 */         this.state = GzipStateLabel.TRAILER_SIZE;
/*     */       }
/*     */     }
/*     */ 
/* 376 */     if (this.userBufLen <= 0) {
/* 377 */       return;
/*     */     }
/*     */ 
/* 382 */     if (this.state == GzipStateLabel.TRAILER_SIZE) {
/* 383 */       assert (this.localBufOff < 4);
/* 384 */       int n = Math.min(this.userBufLen, 4 - this.localBufOff);
/* 385 */       copyBytesToLocal(n);
/* 386 */       if (this.localBufOff >= 4) {
/* 387 */         long inputSize = readUIntLE(this.localBuf, 0);
/* 388 */         if (inputSize != (this.inflater.getBytesWritten() & 0xFFFFFFFF)) {
/* 389 */           throw new IOException("stored gzip size doesn't match decompressed size");
/*     */         }
/*     */ 
/* 392 */         this.localBufOff = 0;
/* 393 */         this.state = GzipStateLabel.FINISHED;
/*     */       }
/*     */     }
/*     */ 
/* 397 */     if (this.state == GzipStateLabel.FINISHED);
/*     */   }
/*     */ 
/*     */   public synchronized long getBytesRead()
/*     */   {
/* 409 */     return this.headerBytesRead + this.inflater.getBytesRead() + this.trailerBytesRead;
/*     */   }
/*     */ 
/*     */   public synchronized int getRemaining()
/*     */   {
/* 425 */     return this.userBufLen;
/*     */   }
/*     */ 
/*     */   public synchronized boolean needsDictionary()
/*     */   {
/* 430 */     return this.inflater.needsDictionary();
/*     */   }
/*     */ 
/*     */   public synchronized void setDictionary(byte[] b, int off, int len)
/*     */   {
/* 435 */     this.inflater.setDictionary(b, off, len);
/*     */   }
/*     */ 
/*     */   public synchronized boolean finished()
/*     */   {
/* 443 */     return this.state == GzipStateLabel.FINISHED;
/*     */   }
/*     */ 
/*     */   public synchronized void reset()
/*     */   {
/* 452 */     this.inflater.reset();
/* 453 */     this.state = GzipStateLabel.HEADER_BASIC;
/* 454 */     this.crc.reset();
/* 455 */     this.userBufOff = (this.userBufLen = 0);
/* 456 */     this.localBufOff = 0;
/* 457 */     this.headerBytesRead = 0;
/* 458 */     this.trailerBytesRead = 0;
/* 459 */     this.numExtraFieldBytesRemaining = -1;
/* 460 */     this.hasExtraField = false;
/* 461 */     this.hasFilename = false;
/* 462 */     this.hasComment = false;
/* 463 */     this.hasHeaderCRC = false;
/*     */   }
/*     */ 
/*     */   public synchronized void end()
/*     */   {
/* 468 */     this.inflater.end();
/*     */   }
/*     */ 
/*     */   private void processBasicHeader()
/*     */     throws IOException
/*     */   {
/* 489 */     if (readUShortLE(this.localBuf, 0) != 35615) {
/* 490 */       throw new IOException("not a gzip file");
/*     */     }
/* 492 */     if (readUByte(this.localBuf, 2) != 8) {
/* 493 */       throw new IOException("gzip data not compressed with deflate method");
/*     */     }
/* 495 */     int flg = readUByte(this.localBuf, 3);
/* 496 */     if ((flg & 0xE0) != 0) {
/* 497 */       throw new IOException("unknown gzip format (reserved flagbits set)");
/*     */     }
/* 499 */     this.hasExtraField = ((flg & 0x4) != 0);
/* 500 */     this.hasFilename = ((flg & 0x8) != 0);
/* 501 */     this.hasComment = ((flg & 0x10) != 0);
/* 502 */     this.hasHeaderCRC = ((flg & 0x2) != 0);
/*     */   }
/*     */ 
/*     */   private void checkAndCopyBytesToLocal(int len) {
/* 506 */     System.arraycopy(this.userBuf, this.userBufOff, this.localBuf, this.localBufOff, len);
/* 507 */     this.localBufOff += len;
/*     */ 
/* 509 */     this.crc.update(this.userBuf, this.userBufOff, len);
/* 510 */     this.userBufOff += len;
/* 511 */     this.userBufLen -= len;
/* 512 */     this.headerBytesRead += len;
/*     */   }
/*     */ 
/*     */   private void checkAndSkipBytes(int len) {
/* 516 */     this.crc.update(this.userBuf, this.userBufOff, len);
/* 517 */     this.userBufOff += len;
/* 518 */     this.userBufLen -= len;
/* 519 */     this.headerBytesRead += len;
/*     */   }
/*     */ 
/*     */   private boolean checkAndSkipBytesUntilNull()
/*     */   {
/* 526 */     boolean hitNull = false;
/* 527 */     if (this.userBufLen > 0) {
/*     */       do {
/* 529 */         hitNull = this.userBuf[this.userBufOff] == 0;
/* 530 */         this.crc.update(this.userBuf[this.userBufOff]);
/* 531 */         this.userBufOff += 1;
/* 532 */         this.userBufLen -= 1;
/* 533 */         this.headerBytesRead += 1;
/* 534 */       }while ((this.userBufLen > 0) && (!hitNull));
/*     */     }
/* 536 */     return hitNull;
/*     */   }
/*     */ 
/*     */   private void copyBytesToLocal(int len)
/*     */   {
/* 542 */     System.arraycopy(this.userBuf, this.userBufOff, this.localBuf, this.localBufOff, len);
/* 543 */     this.localBufOff += len;
/* 544 */     this.userBufOff += len;
/* 545 */     this.userBufLen -= len;
/* 546 */     if ((this.state == GzipStateLabel.TRAILER_CRC) || (this.state == GzipStateLabel.TRAILER_SIZE))
/*     */     {
/* 548 */       this.trailerBytesRead += len;
/*     */     }
/* 550 */     else this.headerBytesRead += len;
/*     */   }
/*     */ 
/*     */   private int readUByte(byte[] b, int off)
/*     */   {
/* 555 */     return b[off] & 0xFF;
/*     */   }
/*     */ 
/*     */   private int readUShortLE(byte[] b, int off)
/*     */   {
/* 560 */     return ((b[(off + 1)] & 0xFF) << 8 | b[off] & 0xFF) & 0xFFFF;
/*     */   }
/*     */ 
/*     */   private long readUIntLE(byte[] b, int off)
/*     */   {
/* 566 */     return (b[(off + 3)] & 0xFF << 24 | b[(off + 2)] & 0xFF << 16 | b[(off + 1)] & 0xFF << 8 | b[off] & 0xFF) & 0xFFFFFFFF;
/*     */   }
/*     */ 
/*     */   private static enum GzipStateLabel
/*     */   {
/*  74 */     HEADER_BASIC, 
/*     */ 
/*  78 */     HEADER_EXTRA_FIELD, 
/*     */ 
/*  82 */     HEADER_FILENAME, 
/*     */ 
/*  86 */     HEADER_COMMENT, 
/*     */ 
/*  90 */     HEADER_CRC, 
/*     */ 
/*  94 */     DEFLATE_STREAM, 
/*     */ 
/*  98 */     TRAILER_CRC, 
/*     */ 
/* 102 */     TRAILER_SIZE, 
/*     */ 
/* 107 */     FINISHED;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.zlib.BuiltInGzipDecompressor
 * JD-Core Version:    0.6.1
 */
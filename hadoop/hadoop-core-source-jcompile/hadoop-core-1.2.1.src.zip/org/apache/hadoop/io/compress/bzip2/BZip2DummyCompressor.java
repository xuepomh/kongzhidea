/*    */ package org.apache.hadoop.io.compress.bzip2;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ import org.apache.hadoop.io.compress.Compressor;
/*    */ 
/*    */ public class BZip2DummyCompressor
/*    */   implements Compressor
/*    */ {
/*    */   public int compress(byte[] b, int off, int len)
/*    */     throws IOException
/*    */   {
/* 30 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public void end()
/*    */   {
/* 35 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public void finish()
/*    */   {
/* 40 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public boolean finished()
/*    */   {
/* 45 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public long getBytesRead()
/*    */   {
/* 50 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public long getBytesWritten()
/*    */   {
/* 55 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public boolean needsInput()
/*    */   {
/* 60 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public void reset()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void setDictionary(byte[] b, int off, int len)
/*    */   {
/* 70 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public void setInput(byte[] b, int off, int len)
/*    */   {
/* 75 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public void reinit(Configuration conf)
/*    */   {
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.bzip2.BZip2DummyCompressor
 * JD-Core Version:    0.6.1
 */
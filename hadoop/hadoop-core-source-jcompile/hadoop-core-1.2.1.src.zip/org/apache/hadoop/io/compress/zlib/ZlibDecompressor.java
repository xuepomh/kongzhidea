/*     */ package org.apache.hadoop.io.compress.zlib;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.hadoop.io.compress.Decompressor;
/*     */ import org.apache.hadoop.util.NativeCodeLoader;
/*     */ 
/*     */ public class ZlibDecompressor
/*     */   implements Decompressor
/*     */ {
/*     */   private static final int DEFAULT_DIRECT_BUFFER_SIZE = 65536;
/*  38 */   private static Class clazz = ZlibDecompressor.class;
/*     */   private long stream;
/*     */   private CompressionHeader header;
/*     */   private int directBufferSize;
/*  43 */   private Buffer compressedDirectBuf = null;
/*     */   private int compressedDirectBufOff;
/*     */   private int compressedDirectBufLen;
/*  45 */   private Buffer uncompressedDirectBuf = null;
/*  46 */   private byte[] userBuf = null;
/*  47 */   private int userBufOff = 0; private int userBufLen = 0;
/*     */   private boolean finished;
/*     */   private boolean needDict;
/*  86 */   private static boolean nativeZlibLoaded = false;
/*     */ 
/*     */   static boolean isNativeZlibLoaded()
/*     */   {
/* 101 */     return nativeZlibLoaded;
/*     */   }
/*     */ 
/*     */   public ZlibDecompressor(CompressionHeader header, int directBufferSize)
/*     */   {
/* 108 */     this.header = header;
/* 109 */     this.directBufferSize = directBufferSize;
/* 110 */     this.compressedDirectBuf = ByteBuffer.allocateDirect(directBufferSize);
/* 111 */     this.uncompressedDirectBuf = ByteBuffer.allocateDirect(directBufferSize);
/* 112 */     this.uncompressedDirectBuf.position(directBufferSize);
/*     */ 
/* 114 */     this.stream = init(this.header.windowBits());
/*     */   }
/*     */ 
/*     */   public ZlibDecompressor() {
/* 118 */     this(CompressionHeader.DEFAULT_HEADER, 65536);
/*     */   }
/*     */ 
/*     */   public synchronized void setInput(byte[] b, int off, int len) {
/* 122 */     if (b == null) {
/* 123 */       throw new NullPointerException();
/*     */     }
/* 125 */     if ((off < 0) || (len < 0) || (off > b.length - len)) {
/* 126 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/*     */ 
/* 129 */     this.userBuf = b;
/* 130 */     this.userBufOff = off;
/* 131 */     this.userBufLen = len;
/*     */ 
/* 133 */     setInputFromSavedData();
/*     */ 
/* 136 */     this.uncompressedDirectBuf.limit(this.directBufferSize);
/* 137 */     this.uncompressedDirectBuf.position(this.directBufferSize);
/*     */   }
/*     */ 
/*     */   synchronized void setInputFromSavedData() {
/* 141 */     this.compressedDirectBufOff = 0;
/* 142 */     this.compressedDirectBufLen = this.userBufLen;
/* 143 */     if (this.compressedDirectBufLen > this.directBufferSize) {
/* 144 */       this.compressedDirectBufLen = this.directBufferSize;
/*     */     }
/*     */ 
/* 148 */     this.compressedDirectBuf.rewind();
/* 149 */     ((ByteBuffer)this.compressedDirectBuf).put(this.userBuf, this.userBufOff, this.compressedDirectBufLen);
/*     */ 
/* 153 */     this.userBufOff += this.compressedDirectBufLen;
/* 154 */     this.userBufLen -= this.compressedDirectBufLen;
/*     */   }
/*     */ 
/*     */   public synchronized void setDictionary(byte[] b, int off, int len) {
/* 158 */     if ((this.stream == 0L) || (b == null)) {
/* 159 */       throw new NullPointerException();
/*     */     }
/* 161 */     if ((off < 0) || (len < 0) || (off > b.length - len)) {
/* 162 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/* 164 */     setDictionary(this.stream, b, off, len);
/* 165 */     this.needDict = false;
/*     */   }
/*     */ 
/*     */   public synchronized boolean needsInput()
/*     */   {
/* 170 */     if (this.uncompressedDirectBuf.remaining() > 0) {
/* 171 */       return false;
/*     */     }
/*     */ 
/* 175 */     if (this.compressedDirectBufLen <= 0)
/*     */     {
/* 177 */       if (this.userBufLen <= 0) {
/* 178 */         return true;
/*     */       }
/* 180 */       setInputFromSavedData();
/*     */     }
/*     */ 
/* 184 */     return false;
/*     */   }
/*     */ 
/*     */   public synchronized boolean needsDictionary() {
/* 188 */     return this.needDict;
/*     */   }
/*     */ 
/*     */   public synchronized boolean finished()
/*     */   {
/* 194 */     return (this.finished) && (this.uncompressedDirectBuf.remaining() == 0);
/*     */   }
/*     */ 
/*     */   public synchronized int decompress(byte[] b, int off, int len) throws IOException
/*     */   {
/* 199 */     if (b == null) {
/* 200 */       throw new NullPointerException();
/*     */     }
/* 202 */     if ((off < 0) || (len < 0) || (off > b.length - len)) {
/* 203 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/*     */ 
/* 206 */     int n = 0;
/*     */ 
/* 209 */     n = this.uncompressedDirectBuf.remaining();
/* 210 */     if (n > 0) {
/* 211 */       n = Math.min(n, len);
/* 212 */       ((ByteBuffer)this.uncompressedDirectBuf).get(b, off, n);
/* 213 */       return n;
/*     */     }
/*     */ 
/* 217 */     this.uncompressedDirectBuf.rewind();
/* 218 */     this.uncompressedDirectBuf.limit(this.directBufferSize);
/*     */ 
/* 221 */     n = inflateBytesDirect();
/* 222 */     this.uncompressedDirectBuf.limit(n);
/*     */ 
/* 225 */     n = Math.min(n, len);
/* 226 */     ((ByteBuffer)this.uncompressedDirectBuf).get(b, off, n);
/*     */ 
/* 228 */     return n;
/*     */   }
/*     */ 
/*     */   public synchronized long getBytesWritten()
/*     */   {
/* 237 */     checkStream();
/* 238 */     return getBytesWritten(this.stream);
/*     */   }
/*     */ 
/*     */   public synchronized long getBytesRead()
/*     */   {
/* 247 */     checkStream();
/* 248 */     return getBytesRead(this.stream);
/*     */   }
/*     */ 
/*     */   public synchronized int getRemaining()
/*     */   {
/* 259 */     checkStream();
/* 260 */     return this.userBufLen + getRemaining(this.stream);
/*     */   }
/*     */ 
/*     */   public synchronized void reset()
/*     */   {
/* 267 */     checkStream();
/* 268 */     reset(this.stream);
/* 269 */     this.finished = false;
/* 270 */     this.needDict = false;
/* 271 */     this.compressedDirectBufOff = (this.compressedDirectBufLen = 0);
/* 272 */     this.uncompressedDirectBuf.limit(this.directBufferSize);
/* 273 */     this.uncompressedDirectBuf.position(this.directBufferSize);
/* 274 */     this.userBufOff = (this.userBufLen = 0);
/*     */   }
/*     */ 
/*     */   public synchronized void end() {
/* 278 */     if (this.stream != 0L) {
/* 279 */       end(this.stream);
/* 280 */       this.stream = 0L;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void finalize() {
/* 285 */     end();
/*     */   }
/*     */ 
/*     */   private void checkStream() {
/* 289 */     if (this.stream == 0L)
/* 290 */       throw new NullPointerException();
/*     */   }
/*     */ 
/*     */   private static native void initIDs();
/*     */ 
/*     */   private static native long init(int paramInt);
/*     */ 
/*     */   private static native void setDictionary(long paramLong, byte[] paramArrayOfByte, int paramInt1, int paramInt2);
/*     */ 
/*     */   private native int inflateBytesDirect();
/*     */ 
/*     */   private static native long getBytesRead(long paramLong);
/*     */ 
/*     */   private static native long getBytesWritten(long paramLong);
/*     */ 
/*     */   private static native int getRemaining(long paramLong);
/*     */ 
/*     */   private static native void reset(long paramLong);
/*     */ 
/*     */   private static native void end(long paramLong);
/*     */ 
/*     */   static
/*     */   {
/*  89 */     if (NativeCodeLoader.isNativeCodeLoaded())
/*     */       try
/*     */       {
/*  92 */         initIDs();
/*  93 */         nativeZlibLoaded = true;
/*     */       }
/*     */       catch (Throwable t)
/*     */       {
/*     */       }
/*     */   }
/*     */ 
/*     */   public static enum CompressionHeader
/*     */   {
/*  58 */     NO_HEADER(-15), 
/*     */ 
/*  63 */     DEFAULT_HEADER(15), 
/*     */ 
/*  68 */     GZIP_FORMAT(31), 
/*     */ 
/*  73 */     AUTODETECT_GZIP_ZLIB(47);
/*     */ 
/*     */     private final int windowBits;
/*     */ 
/*     */     private CompressionHeader(int windowBits) {
/*  78 */       this.windowBits = windowBits;
/*     */     }
/*     */ 
/*     */     public int windowBits() {
/*  82 */       return this.windowBits;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.zlib.ZlibDecompressor
 * JD-Core Version:    0.6.1
 */
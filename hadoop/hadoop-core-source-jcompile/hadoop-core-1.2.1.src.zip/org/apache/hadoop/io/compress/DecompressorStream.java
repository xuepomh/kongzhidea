/*     */ package org.apache.hadoop.io.compress;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ public class DecompressorStream extends CompressionInputStream
/*     */ {
/*  28 */   protected Decompressor decompressor = null;
/*     */   protected byte[] buffer;
/*  30 */   protected boolean eof = false;
/*  31 */   protected boolean closed = false;
/*  32 */   private int lastBytesSent = 0;
/*     */ 
/*  62 */   private byte[] oneByte = new byte[1];
/*     */ 
/* 164 */   private byte[] skipBytes = new byte[512];
/*     */ 
/*     */   public DecompressorStream(InputStream in, Decompressor decompressor, int bufferSize)
/*     */     throws IOException
/*     */   {
/*  36 */     super(in);
/*     */ 
/*  38 */     if ((in == null) || (decompressor == null))
/*  39 */       throw new NullPointerException();
/*  40 */     if (bufferSize <= 0) {
/*  41 */       throw new IllegalArgumentException("Illegal bufferSize");
/*     */     }
/*     */ 
/*  44 */     this.decompressor = decompressor;
/*  45 */     this.buffer = new byte[bufferSize];
/*     */   }
/*     */ 
/*     */   public DecompressorStream(InputStream in, Decompressor decompressor) throws IOException {
/*  49 */     this(in, decompressor, 512);
/*     */   }
/*     */ 
/*     */   protected DecompressorStream(InputStream in)
/*     */     throws IOException
/*     */   {
/*  59 */     super(in);
/*     */   }
/*     */ 
/*     */   public int read() throws IOException
/*     */   {
/*  64 */     checkStream();
/*  65 */     return read(this.oneByte, 0, this.oneByte.length) == -1 ? -1 : this.oneByte[0] & 0xFF;
/*     */   }
/*     */ 
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/*  69 */     checkStream();
/*     */ 
/*  71 */     if ((off | len | off + len | b.length - (off + len)) < 0)
/*  72 */       throw new IndexOutOfBoundsException();
/*  73 */     if (len == 0) {
/*  74 */       return 0;
/*     */     }
/*     */ 
/*  77 */     return decompress(b, off, len);
/*     */   }
/*     */ 
/*     */   protected int decompress(byte[] b, int off, int len) throws IOException {
/*  81 */     int n = 0;
/*     */ 
/*  83 */     while ((n = this.decompressor.decompress(b, off, len)) == 0) {
/*  84 */       if (this.decompressor.needsDictionary()) {
/*  85 */         this.eof = true;
/*  86 */         return -1;
/*     */       }
/*     */ 
/*  89 */       if (this.decompressor.finished())
/*     */       {
/*  94 */         int nRemaining = this.decompressor.getRemaining();
/*  95 */         if (nRemaining == 0) {
/*  96 */           int m = getCompressedData();
/*  97 */           if (m == -1)
/*     */           {
/* 100 */             this.eof = true;
/* 101 */             return -1;
/*     */           }
/* 103 */           this.decompressor.reset();
/* 104 */           this.decompressor.setInput(this.buffer, 0, m);
/* 105 */           this.lastBytesSent = m;
/*     */         }
/*     */         else
/*     */         {
/* 109 */           this.decompressor.reset();
/* 110 */           int leftoverOffset = this.lastBytesSent - nRemaining;
/* 111 */           assert (leftoverOffset >= 0);
/*     */ 
/* 113 */           this.decompressor.setInput(this.buffer, leftoverOffset, nRemaining);
/*     */         }
/*     */ 
/*     */       }
/* 134 */       else if (this.decompressor.needsInput()) {
/* 135 */         int m = getCompressedData();
/* 136 */         if (m == -1) {
/* 137 */           throw new EOFException("Unexpected end of input stream");
/*     */         }
/* 139 */         this.decompressor.setInput(this.buffer, 0, m);
/* 140 */         this.lastBytesSent = m;
/*     */       }
/*     */     }
/*     */ 
/* 144 */     return n;
/*     */   }
/*     */ 
/*     */   protected int getCompressedData() throws IOException {
/* 148 */     checkStream();
/*     */ 
/* 151 */     return this.in.read(this.buffer, 0, this.buffer.length);
/*     */   }
/*     */ 
/*     */   protected void checkStream() throws IOException {
/* 155 */     if (this.closed)
/* 156 */       throw new IOException("Stream closed");
/*     */   }
/*     */ 
/*     */   public void resetState() throws IOException
/*     */   {
/* 161 */     this.decompressor.reset();
/*     */   }
/*     */ 
/*     */   public long skip(long n)
/*     */     throws IOException
/*     */   {
/* 167 */     if (n < 0L) {
/* 168 */       throw new IllegalArgumentException("negative skip length");
/*     */     }
/* 170 */     checkStream();
/*     */ 
/* 173 */     int skipped = 0;
/* 174 */     while (skipped < n) {
/* 175 */       int len = Math.min((int)n - skipped, this.skipBytes.length);
/* 176 */       len = read(this.skipBytes, 0, len);
/* 177 */       if (len == -1) {
/* 178 */         this.eof = true;
/* 179 */         break;
/*     */       }
/* 181 */       skipped += len;
/*     */     }
/* 183 */     return skipped;
/*     */   }
/*     */ 
/*     */   public int available() throws IOException {
/* 187 */     checkStream();
/* 188 */     return this.eof ? 0 : 1;
/*     */   }
/*     */ 
/*     */   public void close() throws IOException {
/* 192 */     if (!this.closed) {
/* 193 */       this.in.close();
/* 194 */       this.closed = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean markSupported() {
/* 199 */     return false;
/*     */   }
/*     */ 
/*     */   public synchronized void mark(int readlimit) {
/*     */   }
/*     */ 
/*     */   public synchronized void reset() throws IOException {
/* 206 */     throw new IOException("mark/reset not supported");
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.DecompressorStream
 * JD-Core Version:    0.6.1
 */
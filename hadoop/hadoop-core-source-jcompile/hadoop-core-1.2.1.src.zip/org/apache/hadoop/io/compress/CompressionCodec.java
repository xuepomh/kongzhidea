package org.apache.hadoop.io.compress;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public abstract interface CompressionCodec
{
  public abstract CompressionOutputStream createOutputStream(OutputStream paramOutputStream)
    throws IOException;

  public abstract CompressionOutputStream createOutputStream(OutputStream paramOutputStream, Compressor paramCompressor)
    throws IOException;

  public abstract Class<? extends Compressor> getCompressorType();

  public abstract Compressor createCompressor();

  public abstract CompressionInputStream createInputStream(InputStream paramInputStream)
    throws IOException;

  public abstract CompressionInputStream createInputStream(InputStream paramInputStream, Decompressor paramDecompressor)
    throws IOException;

  public abstract Class<? extends Decompressor> getDecompressorType();

  public abstract Decompressor createDecompressor();

  public abstract String getDefaultExtension();
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.CompressionCodec
 * JD-Core Version:    0.6.1
 */
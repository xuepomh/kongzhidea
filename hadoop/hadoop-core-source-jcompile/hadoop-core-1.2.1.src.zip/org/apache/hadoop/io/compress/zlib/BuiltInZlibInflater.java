/*    */ package org.apache.hadoop.io.compress.zlib;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.zip.DataFormatException;
/*    */ import java.util.zip.Inflater;
/*    */ import org.apache.hadoop.io.compress.Decompressor;
/*    */ 
/*    */ public class BuiltInZlibInflater extends Inflater
/*    */   implements Decompressor
/*    */ {
/*    */   public BuiltInZlibInflater(boolean nowrap)
/*    */   {
/* 35 */     super(nowrap);
/*    */   }
/*    */ 
/*    */   public BuiltInZlibInflater()
/*    */   {
/*    */   }
/*    */ 
/*    */   public synchronized int decompress(byte[] b, int off, int len) throws IOException
/*    */   {
/*    */     try {
/* 45 */       return super.inflate(b, off, len);
/*    */     } catch (DataFormatException dfe) {
/* 47 */       throw new IOException(dfe.getMessage());
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.zlib.BuiltInZlibInflater
 * JD-Core Version:    0.6.1
 */
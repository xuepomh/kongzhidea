/*     */ package org.apache.hadoop.io.compress;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.hadoop.conf.Configurable;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.io.compress.snappy.LoadSnappy;
/*     */ import org.apache.hadoop.io.compress.snappy.SnappyCompressor;
/*     */ import org.apache.hadoop.io.compress.snappy.SnappyDecompressor;
/*     */ 
/*     */ public class SnappyCodec
/*     */   implements Configurable, CompressionCodec
/*     */ {
/*     */   Configuration conf;
/*     */ 
/*     */   public void setConf(Configuration conf)
/*     */   {
/*  50 */     this.conf = conf;
/*     */   }
/*     */ 
/*     */   public Configuration getConf()
/*     */   {
/*  60 */     return this.conf;
/*     */   }
/*     */ 
/*     */   public static boolean isNativeSnappyLoaded(Configuration conf)
/*     */   {
/*  70 */     return (LoadSnappy.isLoaded()) && (conf.getBoolean("hadoop.native.lib", true));
/*     */   }
/*     */ 
/*     */   public CompressionOutputStream createOutputStream(OutputStream out)
/*     */     throws IOException
/*     */   {
/*  86 */     return createOutputStream(out, createCompressor());
/*     */   }
/*     */ 
/*     */   public CompressionOutputStream createOutputStream(OutputStream out, Compressor compressor)
/*     */     throws IOException
/*     */   {
/* 102 */     if (!isNativeSnappyLoaded(this.conf)) {
/* 103 */       throw new RuntimeException("native snappy library not available");
/*     */     }
/* 105 */     int bufferSize = this.conf.getInt("io.compression.codec.snappy.buffersize", 262144);
/*     */ 
/* 109 */     int compressionOverhead = bufferSize / 6 + 32;
/*     */ 
/* 111 */     return new BlockCompressorStream(out, compressor, bufferSize, compressionOverhead);
/*     */   }
/*     */ 
/*     */   public Class<? extends Compressor> getCompressorType()
/*     */   {
/* 122 */     if (!isNativeSnappyLoaded(this.conf)) {
/* 123 */       throw new RuntimeException("native snappy library not available");
/*     */     }
/*     */ 
/* 126 */     return SnappyCompressor.class;
/*     */   }
/*     */ 
/*     */   public Compressor createCompressor()
/*     */   {
/* 136 */     if (!isNativeSnappyLoaded(this.conf)) {
/* 137 */       throw new RuntimeException("native snappy library not available");
/*     */     }
/* 139 */     int bufferSize = this.conf.getInt("io.compression.codec.snappy.buffersize", 262144);
/*     */ 
/* 142 */     return new SnappyCompressor(bufferSize);
/*     */   }
/*     */ 
/*     */   public CompressionInputStream createInputStream(InputStream in)
/*     */     throws IOException
/*     */   {
/* 156 */     return createInputStream(in, createDecompressor());
/*     */   }
/*     */ 
/*     */   public CompressionInputStream createInputStream(InputStream in, Decompressor decompressor)
/*     */     throws IOException
/*     */   {
/* 172 */     if (!isNativeSnappyLoaded(this.conf)) {
/* 173 */       throw new RuntimeException("native snappy library not available");
/*     */     }
/*     */ 
/* 176 */     return new BlockDecompressorStream(in, decompressor, this.conf.getInt("io.compression.codec.snappy.buffersize", 262144));
/*     */   }
/*     */ 
/*     */   public Class<? extends Decompressor> getDecompressorType()
/*     */   {
/* 188 */     if (!isNativeSnappyLoaded(this.conf)) {
/* 189 */       throw new RuntimeException("native snappy library not available");
/*     */     }
/*     */ 
/* 192 */     return SnappyDecompressor.class;
/*     */   }
/*     */ 
/*     */   public Decompressor createDecompressor()
/*     */   {
/* 202 */     if (!isNativeSnappyLoaded(this.conf)) {
/* 203 */       throw new RuntimeException("native snappy library not available");
/*     */     }
/* 205 */     int bufferSize = this.conf.getInt("io.compression.codec.snappy.buffersize", 262144);
/*     */ 
/* 208 */     return new SnappyDecompressor(bufferSize);
/*     */   }
/*     */ 
/*     */   public String getDefaultExtension()
/*     */   {
/* 218 */     return ".snappy";
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  38 */     LoadSnappy.isLoaded();
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.SnappyCodec
 * JD-Core Version:    0.6.1
 */
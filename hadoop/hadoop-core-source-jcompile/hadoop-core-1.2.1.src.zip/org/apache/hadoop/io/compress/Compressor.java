package org.apache.hadoop.io.compress;

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;

public abstract interface Compressor
{
  public abstract void setInput(byte[] paramArrayOfByte, int paramInt1, int paramInt2);

  public abstract boolean needsInput();

  public abstract void setDictionary(byte[] paramArrayOfByte, int paramInt1, int paramInt2);

  public abstract long getBytesRead();

  public abstract long getBytesWritten();

  public abstract void finish();

  public abstract boolean finished();

  public abstract int compress(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException;

  public abstract void reset();

  public abstract void end();

  public abstract void reinit(Configuration paramConfiguration);
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.Compressor
 * JD-Core Version:    0.6.1
 */
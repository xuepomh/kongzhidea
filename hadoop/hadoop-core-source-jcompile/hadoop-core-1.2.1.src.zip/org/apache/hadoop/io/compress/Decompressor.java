package org.apache.hadoop.io.compress;

import java.io.IOException;

public abstract interface Decompressor
{
  public abstract void setInput(byte[] paramArrayOfByte, int paramInt1, int paramInt2);

  public abstract boolean needsInput();

  public abstract void setDictionary(byte[] paramArrayOfByte, int paramInt1, int paramInt2);

  public abstract boolean needsDictionary();

  public abstract boolean finished();

  public abstract int decompress(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException;

  public abstract int getRemaining();

  public abstract void reset();

  public abstract void end();
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.Decompressor
 * JD-Core Version:    0.6.1
 */
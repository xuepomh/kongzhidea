/*    */ package org.apache.hadoop.io.compress.bzip2;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.hadoop.io.compress.Decompressor;
/*    */ 
/*    */ public class BZip2DummyDecompressor
/*    */   implements Decompressor
/*    */ {
/*    */   public int decompress(byte[] b, int off, int len)
/*    */     throws IOException
/*    */   {
/* 32 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public void end()
/*    */   {
/* 37 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public boolean finished()
/*    */   {
/* 42 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public boolean needsDictionary()
/*    */   {
/* 47 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public boolean needsInput()
/*    */   {
/* 52 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public int getRemaining()
/*    */   {
/* 57 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public void reset()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void setDictionary(byte[] b, int off, int len)
/*    */   {
/* 67 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public void setInput(byte[] b, int off, int len)
/*    */   {
/* 72 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.bzip2.BZip2DummyDecompressor
 * JD-Core Version:    0.6.1
 */
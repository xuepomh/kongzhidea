/*      */ package org.apache.hadoop.io.compress.bzip2;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import org.apache.hadoop.io.compress.SplittableCompressionCodec.READ_MODE;
/*      */ 
/*      */ public class CBZip2InputStream extends InputStream
/*      */   implements BZip2Constants
/*      */ {
/*      */   public static final long BLOCK_DELIMITER = 54156738319193L;
/*      */   public static final long EOS_DELIMITER = 25779555029136L;
/*      */   private static final int DELIMITER_BIT_LENGTH = 48;
/*   79 */   SplittableCompressionCodec.READ_MODE readMode = SplittableCompressionCodec.READ_MODE.CONTINUOUS;
/*      */ 
/*   81 */   private long reportedBytesReadFromCompressedStream = 0L;
/*      */ 
/*   83 */   private long bytesReadFromCompressedStream = 0L;
/*   84 */   private boolean lazyInitialization = false;
/*   85 */   private byte[] array = new byte[1];
/*      */   private int last;
/*      */   private int origPtr;
/*      */   private int blockSize100k;
/*  103 */   private boolean blockRandomised = false;
/*      */   private long bsBuff;
/*      */   private long bsLive;
/*  107 */   private final CRC crc = new CRC();
/*      */   private int nInUse;
/*      */   private BufferedInputStream in;
/*  113 */   private int currentChar = -1;
/*      */ 
/*  123 */   private STATE currentState = STATE.START_BLOCK_STATE;
/*      */   private int storedBlockCRC;
/*      */   private int storedCombinedCRC;
/*      */   private int computedBlockCRC;
/*      */   private int computedCombinedCRC;
/*  128 */   private boolean skipResult = false;
/*  129 */   private static boolean skipDecompression = false;
/*      */   private int su_count;
/*      */   private int su_ch2;
/*      */   private int su_chPrev;
/*      */   private int su_i2;
/*      */   private int su_j2;
/*      */   private int su_rNToGo;
/*      */   private int su_rTPos;
/*      */   private int su_tPos;
/*      */   private char su_z;
/*      */   private Data data;
/*      */ 
/*      */   public long getProcessedByteCount()
/*      */   {
/*  154 */     return this.reportedBytesReadFromCompressedStream;
/*      */   }
/*      */ 
/*      */   protected void updateProcessedByteCount(int count)
/*      */   {
/*  166 */     this.bytesReadFromCompressedStream += count;
/*      */   }
/*      */ 
/*      */   public void updateReportedByteCount(int count)
/*      */   {
/*  180 */     this.reportedBytesReadFromCompressedStream += count;
/*  181 */     updateProcessedByteCount(count);
/*      */   }
/*      */ 
/*      */   private int readAByte(InputStream inStream)
/*      */     throws IOException
/*      */   {
/*  192 */     int read = inStream.read();
/*  193 */     if (read >= 0) {
/*  194 */       updateProcessedByteCount(1);
/*      */     }
/*  196 */     return read;
/*      */   }
/*      */ 
/*      */   public boolean skipToNextMarker(long marker, int markerBitLength)
/*      */     throws IOException, IllegalArgumentException
/*      */   {
/*      */     try
/*      */     {
/*  216 */       if (markerBitLength > 63) {
/*  217 */         throw new IllegalArgumentException("skipToNextMarker can not find patterns greater than 63 bits");
/*      */       }
/*      */ 
/*  221 */       long bytes = 0L;
/*  222 */       bytes = bsR(markerBitLength);
/*  223 */       if (bytes == -1L)
/*  224 */         return false;
/*      */       while (true)
/*      */       {
/*  227 */         if (bytes == marker) {
/*  228 */           return true;
/*      */         }
/*      */ 
/*  231 */         bytes <<= 1;
/*  232 */         bytes &= (1L << markerBitLength) - 1L;
/*  233 */         int oneBit = (int)bsR(1L);
/*  234 */         if (oneBit != -1)
/*  235 */           bytes |= oneBit;
/*      */         else
/*  237 */           return false;
/*      */       }
/*      */     } catch (IOException ex) {
/*      */     }
/*  241 */     return false;
/*      */   }
/*      */ 
/*      */   protected void reportCRCError() throws IOException
/*      */   {
/*  246 */     throw new IOException("crc error");
/*      */   }
/*      */ 
/*      */   private void makeMaps() {
/*  250 */     boolean[] inUse = this.data.inUse;
/*  251 */     byte[] seqToUnseq = this.data.seqToUnseq;
/*      */ 
/*  253 */     int nInUseShadow = 0;
/*      */ 
/*  255 */     for (int i = 0; i < 256; i++) {
/*  256 */       if (inUse[i] != 0) {
/*  257 */         seqToUnseq[(nInUseShadow++)] = (byte)i;
/*      */       }
/*      */     }
/*  260 */     this.nInUse = nInUseShadow;
/*      */   }
/*      */ 
/*      */   public CBZip2InputStream(InputStream in, SplittableCompressionCodec.READ_MODE readMode)
/*      */     throws IOException
/*      */   {
/*  283 */     int blockSize = 57;
/*  284 */     this.blockSize100k = (blockSize - 48);
/*  285 */     this.in = new BufferedInputStream(in, 9216);
/*  286 */     this.readMode = readMode;
/*  287 */     if (readMode == SplittableCompressionCodec.READ_MODE.CONTINUOUS) {
/*  288 */       this.currentState = STATE.START_BLOCK_STATE;
/*  289 */       this.lazyInitialization = (in.available() == 0);
/*  290 */       if (!this.lazyInitialization)
/*  291 */         init();
/*      */     }
/*  293 */     else if (readMode == SplittableCompressionCodec.READ_MODE.BYBLOCK) {
/*  294 */       this.currentState = STATE.NO_PROCESS_STATE;
/*  295 */       this.skipResult = skipToNextMarker(54156738319193L, 48);
/*  296 */       this.reportedBytesReadFromCompressedStream = this.bytesReadFromCompressedStream;
/*  297 */       if (!skipDecompression)
/*  298 */         changeStateToProcessABlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static long numberOfBytesTillNextMarker(InputStream in)
/*      */     throws IOException
/*      */   {
/*  316 */     skipDecompression = true;
/*  317 */     CBZip2InputStream anObject = null;
/*      */ 
/*  319 */     anObject = new CBZip2InputStream(in, SplittableCompressionCodec.READ_MODE.BYBLOCK);
/*      */ 
/*  321 */     return anObject.getProcessedByteCount();
/*      */   }
/*      */ 
/*      */   public CBZip2InputStream(InputStream in) throws IOException {
/*  325 */     this(in, SplittableCompressionCodec.READ_MODE.CONTINUOUS);
/*      */   }
/*      */ 
/*      */   private void changeStateToProcessABlock() throws IOException {
/*  329 */     if (this.skipResult == true) {
/*  330 */       initBlock();
/*  331 */       setupBlock();
/*      */     } else {
/*  333 */       this.currentState = STATE.EOF;
/*      */     }
/*      */   }
/*      */ 
/*      */   public int read()
/*      */     throws IOException
/*      */   {
/*  340 */     if (this.in != null) {
/*  341 */       int result = read(this.array, 0, 1);
/*  342 */       int value = 0xFF & this.array[0];
/*  343 */       return result > 0 ? value : result;
/*      */     }
/*      */ 
/*  346 */     throw new IOException("stream closed");
/*      */   }
/*      */ 
/*      */   public int read(byte[] dest, int offs, int len)
/*      */     throws IOException
/*      */   {
/*  374 */     if (offs < 0) {
/*  375 */       throw new IndexOutOfBoundsException("offs(" + offs + ") < 0.");
/*      */     }
/*  377 */     if (len < 0) {
/*  378 */       throw new IndexOutOfBoundsException("len(" + len + ") < 0.");
/*      */     }
/*  380 */     if (offs + len > dest.length) {
/*  381 */       throw new IndexOutOfBoundsException("offs(" + offs + ") + len(" + len + ") > dest.length(" + dest.length + ").");
/*      */     }
/*      */ 
/*  384 */     if (this.in == null) {
/*  385 */       throw new IOException("stream closed");
/*      */     }
/*      */ 
/*  388 */     if (this.lazyInitialization) {
/*  389 */       init();
/*  390 */       this.lazyInitialization = false;
/*      */     }
/*      */ 
/*  393 */     if (skipDecompression) {
/*  394 */       changeStateToProcessABlock();
/*  395 */       skipDecompression = false;
/*      */     }
/*      */ 
/*  398 */     int hi = offs + len;
/*  399 */     int destOffs = offs;
/*  400 */     int b = 0;
/*      */ 
/*  404 */     while ((destOffs < hi) && ((b = read0()) >= 0)) {
/*  405 */       dest[(destOffs++)] = (byte)b;
/*      */     }
/*      */ 
/*  409 */     int result = destOffs - offs;
/*  410 */     if (result == 0)
/*      */     {
/*  412 */       result = b;
/*      */ 
/*  414 */       this.skipResult = skipToNextMarker(54156738319193L, 48);
/*      */ 
/*  416 */       this.reportedBytesReadFromCompressedStream = this.bytesReadFromCompressedStream;
/*      */ 
/*  418 */       changeStateToProcessABlock();
/*      */     }
/*  420 */     return result;
/*      */   }
/*      */ 
/*      */   private int read0() throws IOException {
/*  424 */     int retChar = this.currentChar;
/*      */ 
/*  426 */     switch (1.$SwitchMap$org$apache$hadoop$io$compress$bzip2$CBZip2InputStream$STATE[this.currentState.ordinal()]) {
/*      */     case 1:
/*  428 */       return -1;
/*      */     case 2:
/*  431 */       return -2;
/*      */     case 3:
/*  434 */       throw new IllegalStateException();
/*      */     case 4:
/*  437 */       throw new IllegalStateException();
/*      */     case 5:
/*  440 */       setupRandPartB();
/*  441 */       break;
/*      */     case 6:
/*  444 */       setupRandPartC();
/*  445 */       break;
/*      */     case 7:
/*  448 */       throw new IllegalStateException();
/*      */     case 8:
/*  451 */       setupNoRandPartB();
/*  452 */       break;
/*      */     case 9:
/*  455 */       setupNoRandPartC();
/*  456 */       break;
/*      */     default:
/*  459 */       throw new IllegalStateException();
/*      */     }
/*      */ 
/*  462 */     return retChar;
/*      */   }
/*      */ 
/*      */   private void init() throws IOException {
/*  466 */     int magic2 = readAByte(this.in);
/*  467 */     if (magic2 != 104) {
/*  468 */       throw new IOException("Stream is not BZip2 formatted: expected 'h' as first byte but got '" + (char)magic2 + "'");
/*      */     }
/*      */ 
/*  472 */     int blockSize = readAByte(this.in);
/*  473 */     if ((blockSize < 49) || (blockSize > 57)) {
/*  474 */       throw new IOException("Stream is not BZip2 formatted: illegal blocksize " + (char)blockSize);
/*      */     }
/*      */ 
/*  478 */     this.blockSize100k = (blockSize - 48);
/*      */ 
/*  480 */     initBlock();
/*  481 */     setupBlock();
/*      */   }
/*      */ 
/*      */   private void initBlock() throws IOException {
/*  485 */     if (this.readMode == SplittableCompressionCodec.READ_MODE.BYBLOCK)
/*      */     {
/*  487 */       this.storedBlockCRC = bsGetInt();
/*  488 */       this.blockRandomised = (bsR(1L) == 1L);
/*      */ 
/*  494 */       if (this.data == null) {
/*  495 */         this.data = new Data(this.blockSize100k);
/*      */       }
/*      */ 
/*  499 */       getAndMoveToFrontDecode();
/*      */ 
/*  501 */       this.crc.initialiseCRC();
/*  502 */       this.currentState = STATE.START_BLOCK_STATE;
/*  503 */       return;
/*      */     }
/*      */ 
/*  506 */     char magic0 = bsGetUByte();
/*  507 */     char magic1 = bsGetUByte();
/*  508 */     char magic2 = bsGetUByte();
/*  509 */     char magic3 = bsGetUByte();
/*  510 */     char magic4 = bsGetUByte();
/*  511 */     char magic5 = bsGetUByte();
/*      */ 
/*  513 */     if ((magic0 == '\027') && (magic1 == 'r') && (magic2 == 'E') && (magic3 == '8') && (magic4 == 'P') && (magic5 == ''))
/*      */     {
/*  515 */       complete(); } else {
/*  516 */       if ((magic0 != '1') || (magic1 != 'A') || (magic2 != 'Y') || (magic3 != '&') || (magic4 != 'S') || (magic5 != 'Y'))
/*      */       {
/*  523 */         this.currentState = STATE.EOF;
/*  524 */         throw new IOException("bad block header");
/*      */       }
/*  526 */       this.storedBlockCRC = bsGetInt();
/*  527 */       this.blockRandomised = (bsR(1L) == 1L);
/*      */ 
/*  533 */       if (this.data == null) {
/*  534 */         this.data = new Data(this.blockSize100k);
/*      */       }
/*      */ 
/*  538 */       getAndMoveToFrontDecode();
/*      */ 
/*  540 */       this.crc.initialiseCRC();
/*  541 */       this.currentState = STATE.START_BLOCK_STATE;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void endBlock() throws IOException {
/*  546 */     this.computedBlockCRC = this.crc.getFinalCRC();
/*      */ 
/*  549 */     if (this.storedBlockCRC != this.computedBlockCRC)
/*      */     {
/*  552 */       this.computedCombinedCRC = (this.storedCombinedCRC << 1 | this.storedCombinedCRC >>> 31);
/*      */ 
/*  554 */       this.computedCombinedCRC ^= this.storedBlockCRC;
/*      */ 
/*  556 */       reportCRCError();
/*      */     }
/*      */ 
/*  559 */     this.computedCombinedCRC = (this.computedCombinedCRC << 1 | this.computedCombinedCRC >>> 31);
/*      */ 
/*  561 */     this.computedCombinedCRC ^= this.computedBlockCRC;
/*      */   }
/*      */ 
/*      */   private void complete() throws IOException {
/*  565 */     this.storedCombinedCRC = bsGetInt();
/*  566 */     this.currentState = STATE.EOF;
/*  567 */     this.data = null;
/*      */ 
/*  569 */     if (this.storedCombinedCRC != this.computedCombinedCRC)
/*  570 */       reportCRCError();
/*      */   }
/*      */ 
/*      */   public void close() throws IOException
/*      */   {
/*  575 */     InputStream inShadow = this.in;
/*  576 */     if (inShadow != null)
/*      */       try {
/*  578 */         if (inShadow != System.in)
/*  579 */           inShadow.close();
/*      */       }
/*      */       finally {
/*  582 */         this.data = null;
/*  583 */         this.in = null;
/*      */       }
/*      */   }
/*      */ 
/*      */   private long bsR(long n) throws IOException
/*      */   {
/*  589 */     long bsLiveShadow = this.bsLive;
/*  590 */     long bsBuffShadow = this.bsBuff;
/*      */ 
/*  592 */     if (bsLiveShadow < n) {
/*  593 */       InputStream inShadow = this.in;
/*      */       do {
/*  595 */         int thech = readAByte(inShadow);
/*      */ 
/*  597 */         if (thech < 0) {
/*  598 */           throw new IOException("unexpected end of stream");
/*      */         }
/*      */ 
/*  601 */         bsBuffShadow = bsBuffShadow << 8 | thech;
/*  602 */         bsLiveShadow += 8L;
/*  603 */       }while (bsLiveShadow < n);
/*      */ 
/*  605 */       this.bsBuff = bsBuffShadow;
/*      */     }
/*      */ 
/*  608 */     this.bsLive = (bsLiveShadow - n);
/*  609 */     return bsBuffShadow >> (int)(bsLiveShadow - n) & (1L << (int)n) - 1L;
/*      */   }
/*      */ 
/*      */   private boolean bsGetBit() throws IOException {
/*  613 */     long bsLiveShadow = this.bsLive;
/*  614 */     long bsBuffShadow = this.bsBuff;
/*      */ 
/*  616 */     if (bsLiveShadow < 1L) {
/*  617 */       int thech = readAByte(this.in);
/*      */ 
/*  619 */       if (thech < 0) {
/*  620 */         throw new IOException("unexpected end of stream");
/*      */       }
/*      */ 
/*  623 */       bsBuffShadow = bsBuffShadow << 8 | thech;
/*  624 */       bsLiveShadow += 8L;
/*  625 */       this.bsBuff = bsBuffShadow;
/*      */     }
/*      */ 
/*  628 */     this.bsLive = (bsLiveShadow - 1L);
/*  629 */     return (bsBuffShadow >> (int)(bsLiveShadow - 1L) & 1L) != 0L;
/*      */   }
/*      */ 
/*      */   private char bsGetUByte() throws IOException {
/*  633 */     return (char)(int)bsR(8L);
/*      */   }
/*      */ 
/*      */   private int bsGetInt() throws IOException {
/*  637 */     return (int)(((bsR(8L) << 8 | bsR(8L)) << 8 | bsR(8L)) << 8 | bsR(8L));
/*      */   }
/*      */ 
/*      */   private static void hbCreateDecodeTables(int[] limit, int[] base, int[] perm, char[] length, int minLen, int maxLen, int alphaSize)
/*      */   {
/*  646 */     int i = minLen; for (int pp = 0; i <= maxLen; i++) {
/*  647 */       for (int j = 0; j < alphaSize; j++) {
/*  648 */         if (length[j] == i) {
/*  649 */           perm[(pp++)] = j;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  654 */     int i = 23;
/*      */     while (true) { i--; if (i <= 0) break;
/*  655 */       base[i] = 0;
/*  656 */       limit[i] = 0;
/*      */     }
/*      */ 
/*  659 */     for (int i = 0; i < alphaSize; i++) {
/*  660 */       base[(length[i] + '\001')] += 1;
/*      */     }
/*      */ 
/*  663 */     int i = 1; for (int b = base[0]; i < 23; i++) {
/*  664 */       b += base[i];
/*  665 */       base[i] = b;
/*      */     }
/*      */ 
/*  668 */     int i = minLen; int vec = 0; for (int b = base[i]; i <= maxLen; i++) {
/*  669 */       int nb = base[(i + 1)];
/*  670 */       vec += nb - b;
/*  671 */       b = nb;
/*  672 */       limit[i] = (vec - 1);
/*  673 */       vec <<= 1;
/*      */     }
/*      */ 
/*  676 */     for (int i = minLen + 1; i <= maxLen; i++)
/*  677 */       base[i] = ((limit[(i - 1)] + 1 << 1) - base[i]);
/*      */   }
/*      */ 
/*      */   private void recvDecodingTables() throws IOException
/*      */   {
/*  682 */     Data dataShadow = this.data;
/*  683 */     boolean[] inUse = dataShadow.inUse;
/*  684 */     byte[] pos = dataShadow.recvDecodingTables_pos;
/*  685 */     byte[] selector = dataShadow.selector;
/*  686 */     byte[] selectorMtf = dataShadow.selectorMtf;
/*      */ 
/*  688 */     int inUse16 = 0;
/*      */ 
/*  691 */     for (int i = 0; i < 16; i++) {
/*  692 */       if (bsGetBit()) {
/*  693 */         inUse16 |= 1 << i;
/*      */       }
/*      */     }
/*      */ 
/*  697 */     int i = 256;
/*      */     while (true) { i--; if (i < 0) break;
/*  698 */       inUse[i] = false;
/*      */     }
/*      */ 
/*  701 */     for (int i = 0; i < 16; i++) {
/*  702 */       if ((inUse16 & 1 << i) != 0) {
/*  703 */         int i16 = i << 4;
/*  704 */         for (int j = 0; j < 16; j++) {
/*  705 */           if (bsGetBit()) {
/*  706 */             inUse[(i16 + j)] = true;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  712 */     makeMaps();
/*  713 */     int alphaSize = this.nInUse + 2;
/*      */ 
/*  716 */     int nGroups = (int)bsR(3L);
/*  717 */     int nSelectors = (int)bsR(15L);
/*      */ 
/*  719 */     for (int i = 0; i < nSelectors; i++) {
/*  720 */       int j = 0;
/*  721 */       while (bsGetBit()) {
/*  722 */         j++;
/*      */       }
/*  724 */       selectorMtf[i] = (byte)j;
/*      */     }
/*      */ 
/*  728 */     int v = nGroups;
/*      */     while (true) { v--; if (v < 0) break;
/*  729 */       pos[v] = (byte)v;
/*      */     }
/*      */ 
/*  732 */     for (int i = 0; i < nSelectors; i++) {
/*  733 */       int v = selectorMtf[i] & 0xFF;
/*  734 */       byte tmp = pos[v];
/*  735 */       while (v > 0)
/*      */       {
/*  737 */         pos[v] = pos[(v - 1)];
/*  738 */         v--;
/*      */       }
/*  740 */       pos[0] = tmp;
/*  741 */       selector[i] = tmp;
/*      */     }
/*      */ 
/*  744 */     char[][] len = dataShadow.temp_charArray2d;
/*      */ 
/*  747 */     for (int t = 0; t < nGroups; t++) {
/*  748 */       int curr = (int)bsR(5L);
/*  749 */       char[] len_t = len[t];
/*  750 */       for (int i = 0; i < alphaSize; i++) {
/*  751 */         while (bsGetBit()) {
/*  752 */           curr += (bsGetBit() ? -1 : 1);
/*      */         }
/*  754 */         len_t[i] = (char)curr;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  759 */     createHuffmanDecodingTables(alphaSize, nGroups);
/*      */   }
/*      */ 
/*      */   private void createHuffmanDecodingTables(int alphaSize, int nGroups)
/*      */   {
/*  767 */     Data dataShadow = this.data;
/*  768 */     char[][] len = dataShadow.temp_charArray2d;
/*  769 */     int[] minLens = dataShadow.minLens;
/*  770 */     int[][] limit = dataShadow.limit;
/*  771 */     int[][] base = dataShadow.base;
/*  772 */     int[][] perm = dataShadow.perm;
/*      */ 
/*  774 */     for (int t = 0; t < nGroups; t++) {
/*  775 */       int minLen = 32;
/*  776 */       int maxLen = 0;
/*  777 */       char[] len_t = len[t];
/*  778 */       int i = alphaSize;
/*      */       while (true) { i--; if (i < 0) break;
/*  779 */         char lent = len_t[i];
/*  780 */         if (lent > maxLen) {
/*  781 */           maxLen = lent;
/*      */         }
/*  783 */         if (lent < minLen) {
/*  784 */           minLen = lent;
/*      */         }
/*      */       }
/*  787 */       hbCreateDecodeTables(limit[t], base[t], perm[t], len[t], minLen, maxLen, alphaSize);
/*      */ 
/*  789 */       minLens[t] = minLen;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void getAndMoveToFrontDecode() throws IOException {
/*  794 */     this.origPtr = (int)bsR(24L);
/*  795 */     recvDecodingTables();
/*      */ 
/*  797 */     InputStream inShadow = this.in;
/*  798 */     Data dataShadow = this.data;
/*  799 */     byte[] ll8 = dataShadow.ll8;
/*  800 */     int[] unzftab = dataShadow.unzftab;
/*  801 */     byte[] selector = dataShadow.selector;
/*  802 */     byte[] seqToUnseq = dataShadow.seqToUnseq;
/*  803 */     char[] yy = dataShadow.getAndMoveToFrontDecode_yy;
/*  804 */     int[] minLens = dataShadow.minLens;
/*  805 */     int[][] limit = dataShadow.limit;
/*  806 */     int[][] base = dataShadow.base;
/*  807 */     int[][] perm = dataShadow.perm;
/*  808 */     int limitLast = this.blockSize100k * 100000;
/*      */ 
/*  815 */     int i = 256;
/*      */     while (true) { i--; if (i < 0) break;
/*  816 */       yy[i] = (char)i;
/*  817 */       unzftab[i] = 0;
/*      */     }
/*      */ 
/*  820 */     int groupNo = 0;
/*  821 */     int groupPos = 49;
/*  822 */     int eob = this.nInUse + 1;
/*  823 */     int nextSym = getAndMoveToFrontDecode0(0);
/*  824 */     int bsBuffShadow = (int)this.bsBuff;
/*  825 */     int bsLiveShadow = (int)this.bsLive;
/*  826 */     int lastShadow = -1;
/*  827 */     int zt = selector[groupNo] & 0xFF;
/*  828 */     int[] base_zt = base[zt];
/*  829 */     int[] limit_zt = limit[zt];
/*  830 */     int[] perm_zt = perm[zt];
/*  831 */     int minLens_zt = minLens[zt];
/*      */ 
/*  833 */     while (nextSym != eob) {
/*  834 */       if ((nextSym == 0) || (nextSym == 1)) {
/*  835 */         int s = -1;
/*      */ 
/*  837 */         for (int n = 1; ; n <<= 1) {
/*  838 */           if (nextSym == 0) {
/*  839 */             s += n; } else {
/*  840 */             if (nextSym != 1) break;
/*  841 */             s += (n << 1);
/*      */           }
/*      */ 
/*  846 */           if (groupPos == 0) {
/*  847 */             groupPos = 49;
/*  848 */             zt = selector[(++groupNo)] & 0xFF;
/*  849 */             base_zt = base[zt];
/*  850 */             limit_zt = limit[zt];
/*  851 */             perm_zt = perm[zt];
/*  852 */             minLens_zt = minLens[zt];
/*      */           } else {
/*  854 */             groupPos--;
/*      */           }
/*      */ 
/*  857 */           int zn = minLens_zt;
/*      */ 
/*  859 */           while (bsLiveShadow < zn) {
/*  860 */             int thech = readAByte(inShadow);
/*  861 */             if (thech >= 0) {
/*  862 */               bsBuffShadow = bsBuffShadow << 8 | thech;
/*  863 */               bsLiveShadow += 8;
/*      */             }
/*      */             else {
/*  866 */               throw new IOException("unexpected end of stream");
/*      */             }
/*      */           }
/*  869 */           long zvec = bsBuffShadow >> bsLiveShadow - zn & (1 << zn) - 1;
/*      */ 
/*  871 */           bsLiveShadow -= zn;
/*      */ 
/*  873 */           while (zvec > limit_zt[zn]) {
/*  874 */             zn++;
/*  875 */             while (bsLiveShadow < 1) {
/*  876 */               int thech = readAByte(inShadow);
/*  877 */               if (thech >= 0) {
/*  878 */                 bsBuffShadow = bsBuffShadow << 8 | thech;
/*  879 */                 bsLiveShadow += 8;
/*      */               }
/*      */               else {
/*  882 */                 throw new IOException("unexpected end of stream");
/*      */               }
/*      */             }
/*      */ 
/*  886 */             bsLiveShadow--;
/*  887 */             zvec = zvec << 1 | bsBuffShadow >> bsLiveShadow & 0x1;
/*      */           }
/*      */ 
/*  890 */           nextSym = perm_zt[(int)(zvec - base_zt[zn])];
/*      */         }
/*      */ 
/*  893 */         byte ch = seqToUnseq[yy[0]];
/*  894 */         unzftab[(ch & 0xFF)] += s + 1;
/*      */ 
/*  896 */         while (s-- >= 0) {
/*  897 */           ll8[(++lastShadow)] = ch;
/*      */         }
/*      */ 
/*  900 */         if (lastShadow >= limitLast)
/*  901 */           throw new IOException("block overrun");
/*      */       }
/*      */       else {
/*  904 */         lastShadow++; if (lastShadow >= limitLast) {
/*  905 */           throw new IOException("block overrun");
/*      */         }
/*      */ 
/*  908 */         char tmp = yy[(nextSym - 1)];
/*  909 */         unzftab[(seqToUnseq[tmp] & 0xFF)] += 1;
/*  910 */         ll8[lastShadow] = seqToUnseq[tmp];
/*      */         int j;
/*  917 */         if (nextSym <= 16) {
/*  918 */           for (j = nextSym - 1; j > 0; )
/*  919 */             yy[j] = yy[(--j)];
/*      */         }
/*      */         else {
/*  922 */           System.arraycopy(yy, 0, yy, 1, nextSym - 1);
/*      */         }
/*      */ 
/*  925 */         yy[0] = tmp;
/*      */ 
/*  927 */         if (groupPos == 0) {
/*  928 */           groupPos = 49;
/*  929 */           zt = selector[(++groupNo)] & 0xFF;
/*  930 */           base_zt = base[zt];
/*  931 */           limit_zt = limit[zt];
/*  932 */           perm_zt = perm[zt];
/*  933 */           minLens_zt = minLens[zt];
/*      */         } else {
/*  935 */           groupPos--;
/*      */         }
/*      */ 
/*  938 */         int zn = minLens_zt;
/*      */ 
/*  940 */         while (bsLiveShadow < zn) {
/*  941 */           int thech = readAByte(inShadow);
/*  942 */           if (thech >= 0) {
/*  943 */             bsBuffShadow = bsBuffShadow << 8 | thech;
/*  944 */             bsLiveShadow += 8;
/*      */           }
/*      */           else {
/*  947 */             throw new IOException("unexpected end of stream");
/*      */           }
/*      */         }
/*  950 */         int zvec = bsBuffShadow >> bsLiveShadow - zn & (1 << zn) - 1;
/*      */ 
/*  952 */         bsLiveShadow -= zn;
/*      */ 
/*  954 */         while (zvec > limit_zt[zn]) {
/*  955 */           zn++;
/*  956 */           while (bsLiveShadow < 1) {
/*  957 */             int thech = readAByte(inShadow);
/*  958 */             if (thech >= 0) {
/*  959 */               bsBuffShadow = bsBuffShadow << 8 | thech;
/*  960 */               bsLiveShadow += 8;
/*      */             }
/*      */             else {
/*  963 */               throw new IOException("unexpected end of stream");
/*      */             }
/*      */           }
/*  966 */           bsLiveShadow--;
/*  967 */           zvec = zvec << 1 | bsBuffShadow >> bsLiveShadow & 0x1;
/*      */         }
/*  969 */         nextSym = perm_zt[(zvec - base_zt[zn])];
/*      */       }
/*      */     }
/*      */ 
/*  973 */     this.last = lastShadow;
/*  974 */     this.bsLive = bsLiveShadow;
/*  975 */     this.bsBuff = bsBuffShadow;
/*      */   }
/*      */ 
/*      */   private int getAndMoveToFrontDecode0(int groupNo) throws IOException {
/*  979 */     InputStream inShadow = this.in;
/*  980 */     Data dataShadow = this.data;
/*  981 */     int zt = dataShadow.selector[groupNo] & 0xFF;
/*  982 */     int[] limit_zt = dataShadow.limit[zt];
/*  983 */     int zn = dataShadow.minLens[zt];
/*  984 */     int zvec = (int)bsR(zn);
/*  985 */     int bsLiveShadow = (int)this.bsLive;
/*  986 */     int bsBuffShadow = (int)this.bsBuff;
/*      */ 
/*  988 */     while (zvec > limit_zt[zn]) {
/*  989 */       zn++;
/*  990 */       while (bsLiveShadow < 1) {
/*  991 */         int thech = readAByte(inShadow);
/*      */ 
/*  993 */         if (thech >= 0) {
/*  994 */           bsBuffShadow = bsBuffShadow << 8 | thech;
/*  995 */           bsLiveShadow += 8;
/*      */         }
/*      */         else {
/*  998 */           throw new IOException("unexpected end of stream");
/*      */         }
/*      */       }
/* 1001 */       bsLiveShadow--;
/* 1002 */       zvec = zvec << 1 | bsBuffShadow >> bsLiveShadow & 0x1;
/*      */     }
/*      */ 
/* 1005 */     this.bsLive = bsLiveShadow;
/* 1006 */     this.bsBuff = bsBuffShadow;
/*      */ 
/* 1008 */     return dataShadow.perm[zt][(zvec - dataShadow.base[zt][zn])];
/*      */   }
/*      */ 
/*      */   private void setupBlock() throws IOException {
/* 1012 */     if (this.data == null) {
/* 1013 */       return;
/*      */     }
/*      */ 
/* 1016 */     int[] cftab = this.data.cftab;
/* 1017 */     int[] tt = this.data.initTT(this.last + 1);
/* 1018 */     byte[] ll8 = this.data.ll8;
/* 1019 */     cftab[0] = 0;
/* 1020 */     System.arraycopy(this.data.unzftab, 0, cftab, 1, 256);
/*      */ 
/* 1022 */     int i = 1; for (int c = cftab[0]; i <= 256; i++) {
/* 1023 */       c += cftab[i];
/* 1024 */       cftab[i] = c;
/*      */     }
/*      */ 
/* 1027 */     int i = 0; for (int lastShadow = this.last; i <= lastShadow; i++)
/*      */     {
/*      */       byte tmp121_120 = (ll8[i] & 0xFF);
/*      */       int[] tmp121_112 = cftab;
/*      */       int tmp123_122 = tmp121_112[tmp121_120]; tmp121_112[tmp121_120] = (tmp123_122 + 1); tt[tmp123_122] = i;
/*      */     }
/*      */ 
/* 1031 */     if ((this.origPtr < 0) || (this.origPtr >= tt.length)) {
/* 1032 */       throw new IOException("stream corrupted");
/*      */     }
/*      */ 
/* 1035 */     this.su_tPos = tt[this.origPtr];
/* 1036 */     this.su_count = 0;
/* 1037 */     this.su_i2 = 0;
/* 1038 */     this.su_ch2 = 256;
/*      */ 
/* 1040 */     if (this.blockRandomised) {
/* 1041 */       this.su_rNToGo = 0;
/* 1042 */       this.su_rTPos = 0;
/* 1043 */       setupRandPartA();
/*      */     } else {
/* 1045 */       setupNoRandPartA();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void setupRandPartA() throws IOException {
/* 1050 */     if (this.su_i2 <= this.last) {
/* 1051 */       this.su_chPrev = this.su_ch2;
/* 1052 */       int su_ch2Shadow = this.data.ll8[this.su_tPos] & 0xFF;
/* 1053 */       this.su_tPos = this.data.tt[this.su_tPos];
/* 1054 */       if (this.su_rNToGo == 0) {
/* 1055 */         this.su_rNToGo = (BZip2Constants.rNums[this.su_rTPos] - 1);
/* 1056 */         if (++this.su_rTPos == 512)
/* 1057 */           this.su_rTPos = 0;
/*      */       }
/*      */       else {
/* 1060 */         this.su_rNToGo -= 1;
/*      */       }
/* 1062 */       this.su_ch2 = (su_ch2Shadow ^= (this.su_rNToGo == 1 ? 1 : 0));
/* 1063 */       this.su_i2 += 1;
/* 1064 */       this.currentChar = su_ch2Shadow;
/* 1065 */       this.currentState = STATE.RAND_PART_B_STATE;
/* 1066 */       this.crc.updateCRC(su_ch2Shadow);
/*      */     } else {
/* 1068 */       endBlock();
/* 1069 */       if (this.readMode == SplittableCompressionCodec.READ_MODE.CONTINUOUS) {
/* 1070 */         initBlock();
/* 1071 */         setupBlock();
/* 1072 */       } else if (this.readMode == SplittableCompressionCodec.READ_MODE.BYBLOCK) {
/* 1073 */         this.currentState = STATE.NO_PROCESS_STATE;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void setupNoRandPartA() throws IOException {
/* 1079 */     if (this.su_i2 <= this.last) {
/* 1080 */       this.su_chPrev = this.su_ch2;
/* 1081 */       int su_ch2Shadow = this.data.ll8[this.su_tPos] & 0xFF;
/* 1082 */       this.su_ch2 = su_ch2Shadow;
/* 1083 */       this.su_tPos = this.data.tt[this.su_tPos];
/* 1084 */       this.su_i2 += 1;
/* 1085 */       this.currentChar = su_ch2Shadow;
/* 1086 */       this.currentState = STATE.NO_RAND_PART_B_STATE;
/* 1087 */       this.crc.updateCRC(su_ch2Shadow);
/*      */     } else {
/* 1089 */       this.currentState = STATE.NO_RAND_PART_A_STATE;
/* 1090 */       endBlock();
/* 1091 */       if (this.readMode == SplittableCompressionCodec.READ_MODE.CONTINUOUS) {
/* 1092 */         initBlock();
/* 1093 */         setupBlock();
/* 1094 */       } else if (this.readMode == SplittableCompressionCodec.READ_MODE.BYBLOCK) {
/* 1095 */         this.currentState = STATE.NO_PROCESS_STATE;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void setupRandPartB() throws IOException {
/* 1101 */     if (this.su_ch2 != this.su_chPrev) {
/* 1102 */       this.currentState = STATE.RAND_PART_A_STATE;
/* 1103 */       this.su_count = 1;
/* 1104 */       setupRandPartA();
/* 1105 */     } else if (++this.su_count >= 4) {
/* 1106 */       this.su_z = (char)(this.data.ll8[this.su_tPos] & 0xFF);
/* 1107 */       this.su_tPos = this.data.tt[this.su_tPos];
/* 1108 */       if (this.su_rNToGo == 0) {
/* 1109 */         this.su_rNToGo = (BZip2Constants.rNums[this.su_rTPos] - 1);
/* 1110 */         if (++this.su_rTPos == 512)
/* 1111 */           this.su_rTPos = 0;
/*      */       }
/*      */       else {
/* 1114 */         this.su_rNToGo -= 1;
/*      */       }
/* 1116 */       this.su_j2 = 0;
/* 1117 */       this.currentState = STATE.RAND_PART_C_STATE;
/* 1118 */       if (this.su_rNToGo == 1) {
/* 1119 */         this.su_z = (char)(this.su_z ^ 0x1);
/*      */       }
/* 1121 */       setupRandPartC();
/*      */     } else {
/* 1123 */       this.currentState = STATE.RAND_PART_A_STATE;
/* 1124 */       setupRandPartA();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void setupRandPartC() throws IOException {
/* 1129 */     if (this.su_j2 < this.su_z) {
/* 1130 */       this.currentChar = this.su_ch2;
/* 1131 */       this.crc.updateCRC(this.su_ch2);
/* 1132 */       this.su_j2 += 1;
/*      */     } else {
/* 1134 */       this.currentState = STATE.RAND_PART_A_STATE;
/* 1135 */       this.su_i2 += 1;
/* 1136 */       this.su_count = 0;
/* 1137 */       setupRandPartA();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void setupNoRandPartB() throws IOException {
/* 1142 */     if (this.su_ch2 != this.su_chPrev) {
/* 1143 */       this.su_count = 1;
/* 1144 */       setupNoRandPartA();
/* 1145 */     } else if (++this.su_count >= 4) {
/* 1146 */       this.su_z = (char)(this.data.ll8[this.su_tPos] & 0xFF);
/* 1147 */       this.su_tPos = this.data.tt[this.su_tPos];
/* 1148 */       this.su_j2 = 0;
/* 1149 */       setupNoRandPartC();
/*      */     } else {
/* 1151 */       setupNoRandPartA();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void setupNoRandPartC() throws IOException {
/* 1156 */     if (this.su_j2 < this.su_z) {
/* 1157 */       int su_ch2Shadow = this.su_ch2;
/* 1158 */       this.currentChar = su_ch2Shadow;
/* 1159 */       this.crc.updateCRC(su_ch2Shadow);
/* 1160 */       this.su_j2 += 1;
/* 1161 */       this.currentState = STATE.NO_RAND_PART_C_STATE;
/*      */     } else {
/* 1163 */       this.su_i2 += 1;
/* 1164 */       this.su_count = 0;
/* 1165 */       setupNoRandPartA();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final class Data
/*      */   {
/* 1172 */     final boolean[] inUse = new boolean[256];
/*      */ 
/* 1174 */     final byte[] seqToUnseq = new byte[256];
/* 1175 */     final byte[] selector = new byte[18002];
/* 1176 */     final byte[] selectorMtf = new byte[18002];
/*      */ 
/* 1182 */     final int[] unzftab = new int[256];
/*      */ 
/* 1184 */     final int[][] limit = new int[6][258];
/* 1185 */     final int[][] base = new int[6][258];
/* 1186 */     final int[][] perm = new int[6][258];
/* 1187 */     final int[] minLens = new int[6];
/*      */ 
/* 1189 */     final int[] cftab = new int[257];
/* 1190 */     final char[] getAndMoveToFrontDecode_yy = new char[256];
/* 1191 */     final char[][] temp_charArray2d = new char[6][258];
/*      */ 
/* 1193 */     final byte[] recvDecodingTables_pos = new byte[6];
/*      */     int[] tt;
/*      */     byte[] ll8;
/*      */ 
/*      */     Data(int blockSize100k) {
/* 1207 */       this.ll8 = new byte[blockSize100k * 100000];
/*      */     }
/*      */ 
/*      */     final int[] initTT(int length)
/*      */     {
/* 1218 */       int[] ttShadow = this.tt;
/*      */ 
/* 1224 */       if ((ttShadow == null) || (ttShadow.length < length)) {
/* 1225 */         this.tt = (ttShadow = new int[length]);
/*      */       }
/*      */ 
/* 1228 */       return ttShadow;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static enum STATE
/*      */   {
/*  120 */     EOF, START_BLOCK_STATE, RAND_PART_A_STATE, RAND_PART_B_STATE, RAND_PART_C_STATE, NO_RAND_PART_A_STATE, NO_RAND_PART_B_STATE, NO_RAND_PART_C_STATE, NO_PROCESS_STATE;
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.bzip2.CBZip2InputStream
 * JD-Core Version:    0.6.1
 */
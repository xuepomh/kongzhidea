/*     */ package org.apache.hadoop.io.compress;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.util.ReflectionUtils;
/*     */ 
/*     */ public class CodecPool
/*     */ {
/*  35 */   private static final Log LOG = LogFactory.getLog(CodecPool.class);
/*     */ 
/*  41 */   private static final Map<Class<Compressor>, List<Compressor>> compressorPool = new HashMap();
/*     */ 
/*  48 */   private static final Map<Class<Decompressor>, List<Decompressor>> decompressorPool = new HashMap();
/*     */ 
/*     */   private static <T> T borrow(Map<Class<T>, List<T>> pool, Class<? extends T> codecClass)
/*     */   {
/*  53 */     Object codec = null;
/*     */ 
/*  56 */     synchronized (pool) {
/*  57 */       if (pool.containsKey(codecClass)) {
/*  58 */         List codecList = (List)pool.get(codecClass);
/*     */ 
/*  60 */         if (codecList != null) {
/*  61 */           synchronized (codecList) {
/*  62 */             if (!codecList.isEmpty()) {
/*  63 */               codec = codecList.remove(codecList.size() - 1);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  70 */     return codec;
/*     */   }
/*     */ 
/*     */   private static <T> void payback(Map<Class<T>, List<T>> pool, T codec) {
/*  74 */     if (codec != null) {
/*  75 */       Class codecClass = ReflectionUtils.getClass(codec);
/*  76 */       synchronized (pool) {
/*  77 */         if (!pool.containsKey(codecClass)) {
/*  78 */           pool.put(codecClass, new ArrayList());
/*     */         }
/*     */ 
/*  81 */         List codecList = (List)pool.get(codecClass);
/*  82 */         synchronized (codecList) {
/*  83 */           codecList.add(codec);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Compressor getCompressor(CompressionCodec codec, Configuration conf)
/*     */   {
/* 100 */     Compressor compressor = (Compressor)borrow(compressorPool, codec.getCompressorType());
/* 101 */     if (compressor == null) {
/* 102 */       compressor = codec.createCompressor();
/* 103 */       LOG.info("Got brand-new compressor");
/*     */     } else {
/* 105 */       compressor.reinit(conf);
/* 106 */       LOG.debug("Got recycled compressor");
/*     */     }
/* 108 */     return compressor;
/*     */   }
/*     */ 
/*     */   public static Compressor getCompressor(CompressionCodec codec) {
/* 112 */     return getCompressor(codec, null);
/*     */   }
/*     */ 
/*     */   public static Decompressor getDecompressor(CompressionCodec codec)
/*     */   {
/* 125 */     Decompressor decompressor = (Decompressor)borrow(decompressorPool, codec.getDecompressorType());
/* 126 */     if (decompressor == null) {
/* 127 */       decompressor = codec.createDecompressor();
/* 128 */       LOG.info("Got brand-new decompressor");
/*     */     } else {
/* 130 */       LOG.debug("Got recycled decompressor");
/*     */     }
/* 132 */     return decompressor;
/*     */   }
/*     */ 
/*     */   public static void returnCompressor(Compressor compressor)
/*     */   {
/* 141 */     if (compressor == null) {
/* 142 */       return;
/*     */     }
/*     */ 
/* 145 */     if (compressor.getClass().isAnnotationPresent(DoNotPool.class)) {
/* 146 */       return;
/*     */     }
/* 148 */     compressor.reset();
/* 149 */     payback(compressorPool, compressor);
/*     */   }
/*     */ 
/*     */   public static void returnDecompressor(Decompressor decompressor)
/*     */   {
/* 159 */     if (decompressor == null) {
/* 160 */       return;
/*     */     }
/*     */ 
/* 163 */     if (decompressor.getClass().isAnnotationPresent(DoNotPool.class)) {
/* 164 */       return;
/*     */     }
/* 166 */     decompressor.reset();
/* 167 */     payback(decompressorPool, decompressor);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.CodecPool
 * JD-Core Version:    0.6.1
 */
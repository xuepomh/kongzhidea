/*     */ package org.apache.hadoop.io.compress;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.apache.hadoop.fs.PositionedReadable;
/*     */ import org.apache.hadoop.fs.Seekable;
/*     */ 
/*     */ public abstract class CompressionInputStream extends InputStream
/*     */   implements Seekable
/*     */ {
/*     */   protected final InputStream in;
/*  39 */   protected long maxAvailableData = 0L;
/*     */ 
/*     */   protected CompressionInputStream(InputStream in)
/*     */     throws IOException
/*     */   {
/*  49 */     if ((!(in instanceof Seekable)) || (!(in instanceof PositionedReadable))) {
/*  50 */       this.maxAvailableData = in.available();
/*     */     }
/*  52 */     this.in = in;
/*     */   }
/*     */ 
/*     */   public void close() throws IOException {
/*  56 */     this.in.close();
/*     */   }
/*     */ 
/*     */   public abstract int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void resetState()
/*     */     throws IOException;
/*     */ 
/*     */   public long getPos()
/*     */     throws IOException
/*     */   {
/*  77 */     if ((!(this.in instanceof Seekable)) || (!(this.in instanceof PositionedReadable)))
/*     */     {
/*  81 */       return this.maxAvailableData - this.in.available();
/*     */     }
/*     */ 
/*  84 */     return ((Seekable)this.in).getPos();
/*     */   }
/*     */ 
/*     */   public void seek(long pos)
/*     */     throws UnsupportedOperationException
/*     */   {
/*  96 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public boolean seekToNewSource(long targetPos)
/*     */     throws UnsupportedOperationException
/*     */   {
/* 105 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.CompressionInputStream
 * JD-Core Version:    0.6.1
 */
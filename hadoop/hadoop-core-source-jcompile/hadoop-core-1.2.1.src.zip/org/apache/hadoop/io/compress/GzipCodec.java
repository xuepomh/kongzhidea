/*     */ package org.apache.hadoop.io.compress;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.zip.CRC32;
/*     */ import java.util.zip.Deflater;
/*     */ import java.util.zip.GZIPOutputStream;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.io.compress.zlib.BuiltInGzipDecompressor;
/*     */ import org.apache.hadoop.io.compress.zlib.ZlibCompressor;
/*     */ import org.apache.hadoop.io.compress.zlib.ZlibCompressor.CompressionHeader;
/*     */ import org.apache.hadoop.io.compress.zlib.ZlibCompressor.CompressionLevel;
/*     */ import org.apache.hadoop.io.compress.zlib.ZlibCompressor.CompressionStrategy;
/*     */ import org.apache.hadoop.io.compress.zlib.ZlibDecompressor;
/*     */ import org.apache.hadoop.io.compress.zlib.ZlibDecompressor.CompressionHeader;
/*     */ import org.apache.hadoop.io.compress.zlib.ZlibFactory;
/*     */ 
/*     */ public class GzipCodec extends DefaultCodec
/*     */ {
/*     */   public CompressionOutputStream createOutputStream(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 152 */     return ZlibFactory.isNativeZlibLoaded(this.conf) ? new CompressorStream(out, createCompressor(), this.conf.getInt("io.file.buffer.size", 4096)) : new GzipOutputStream(out);
/*     */   }
/*     */ 
/*     */   public CompressionOutputStream createOutputStream(OutputStream out, Compressor compressor)
/*     */     throws IOException
/*     */   {
/* 161 */     return compressor != null ? new CompressorStream(out, compressor, this.conf.getInt("io.file.buffer.size", 4096)) : createOutputStream(out);
/*     */   }
/*     */ 
/*     */   public Compressor createCompressor()
/*     */   {
/* 169 */     return ZlibFactory.isNativeZlibLoaded(this.conf) ? new GzipZlibCompressor(this.conf) : null;
/*     */   }
/*     */ 
/*     */   public Class<? extends Compressor> getCompressorType()
/*     */   {
/* 175 */     return ZlibFactory.isNativeZlibLoaded(this.conf) ? GzipZlibCompressor.class : null;
/*     */   }
/*     */ 
/*     */   public CompressionInputStream createInputStream(InputStream in)
/*     */     throws IOException
/*     */   {
/* 182 */     return createInputStream(in, null);
/*     */   }
/*     */ 
/*     */   public CompressionInputStream createInputStream(InputStream in, Decompressor decompressor)
/*     */     throws IOException
/*     */   {
/* 188 */     if (decompressor == null) {
/* 189 */       decompressor = createDecompressor();
/*     */     }
/* 191 */     return new DecompressorStream(in, decompressor, this.conf.getInt("io.file.buffer.size", 4096));
/*     */   }
/*     */ 
/*     */   public Decompressor createDecompressor()
/*     */   {
/* 196 */     return ZlibFactory.isNativeZlibLoaded(this.conf) ? new GzipZlibDecompressor() : new BuiltInGzipDecompressor();
/*     */   }
/*     */ 
/*     */   public Class<? extends Decompressor> getDecompressorType()
/*     */   {
/* 202 */     return ZlibFactory.isNativeZlibLoaded(this.conf) ? GzipZlibDecompressor.class : BuiltInGzipDecompressor.class;
/*     */   }
/*     */ 
/*     */   public String getDefaultExtension()
/*     */   {
/* 208 */     return ".gz";
/*     */   }
/*     */ 
/*     */   static final class GzipZlibDecompressor extends ZlibDecompressor
/*     */   {
/*     */     public GzipZlibDecompressor()
/*     */     {
/* 228 */       super(65536);
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class GzipZlibCompressor extends ZlibCompressor
/*     */   {
/*     */     public GzipZlibCompressor()
/*     */     {
/* 213 */       super(ZlibCompressor.CompressionStrategy.DEFAULT_STRATEGY, ZlibCompressor.CompressionHeader.GZIP_FORMAT, 65536);
/*     */     }
/*     */ 
/*     */     public GzipZlibCompressor(Configuration conf)
/*     */     {
/* 219 */       super(ZlibFactory.getCompressionStrategy(conf), ZlibCompressor.CompressionHeader.GZIP_FORMAT, 65536);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static class GzipOutputStream extends CompressorStream
/*     */   {
/*     */     public GzipOutputStream(OutputStream out)
/*     */       throws IOException
/*     */     {
/* 113 */       super();
/*     */     }
/*     */ 
/*     */     protected GzipOutputStream(CompressorStream out)
/*     */     {
/* 121 */       super();
/*     */     }
/*     */ 
/*     */     public void close() throws IOException {
/* 125 */       this.out.close();
/*     */     }
/*     */ 
/*     */     public void flush() throws IOException {
/* 129 */       this.out.flush();
/*     */     }
/*     */ 
/*     */     public void write(int b) throws IOException {
/* 133 */       this.out.write(b);
/*     */     }
/*     */ 
/*     */     public void write(byte[] data, int offset, int length) throws IOException
/*     */     {
/* 138 */       this.out.write(data, offset, length);
/*     */     }
/*     */ 
/*     */     public void finish() throws IOException {
/* 142 */       ((ResetableGZIPOutputStream)this.out).finish();
/*     */     }
/*     */ 
/*     */     public void resetState() throws IOException {
/* 146 */       ((ResetableGZIPOutputStream)this.out).resetState();
/*     */     }
/*     */ 
/*     */     private static class ResetableGZIPOutputStream extends GZIPOutputStream
/*     */     {
/*     */       private static final int TRAILER_SIZE = 8;
/*  43 */       public static final String JVMVendor = System.getProperty("java.vendor");
/*  44 */       public static final String JVMVersion = System.getProperty("java.version");
/*  45 */       private static final boolean HAS_BROKEN_FINISH = (JVMVendor.contains("IBM")) && (JVMVersion.contains("1.6.0"));
/*     */ 
/*     */       public ResetableGZIPOutputStream(OutputStream out) throws IOException
/*     */       {
/*  49 */         super();
/*     */       }
/*     */ 
/*     */       public void resetState() throws IOException {
/*  53 */         this.def.reset();
/*     */       }
/*     */ 
/*     */       public void finish()
/*     */         throws IOException
/*     */       {
/*  64 */         if (HAS_BROKEN_FINISH) {
/*  65 */           if (!this.def.finished()) {
/*  66 */             this.def.finish();
/*  67 */             while (!this.def.finished()) {
/*  68 */               int i = this.def.deflate(this.buf, 0, this.buf.length);
/*  69 */               if ((this.def.finished()) && (i <= this.buf.length - 8)) {
/*  70 */                 writeTrailer(this.buf, i);
/*  71 */                 i += 8;
/*  72 */                 this.out.write(this.buf, 0, i);
/*     */ 
/*  74 */                 return;
/*     */               }
/*  76 */               if (i > 0) {
/*  77 */                 this.out.write(this.buf, 0, i);
/*     */               }
/*     */             }
/*     */ 
/*  81 */             byte[] arrayOfByte = new byte[8];
/*  82 */             writeTrailer(arrayOfByte, 0);
/*  83 */             this.out.write(arrayOfByte);
/*     */           }
/*     */         }
/*  86 */         else super.finish();
/*     */       }
/*     */ 
/*     */       private void writeTrailer(byte[] paramArrayOfByte, int paramInt)
/*     */         throws IOException
/*     */       {
/*  93 */         writeInt((int)this.crc.getValue(), paramArrayOfByte, paramInt);
/*  94 */         writeInt(this.def.getTotalIn(), paramArrayOfByte, paramInt + 4);
/*     */       }
/*     */ 
/*     */       private void writeInt(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
/*     */         throws IOException
/*     */       {
/* 100 */         writeShort(paramInt1 & 0xFFFF, paramArrayOfByte, paramInt2);
/* 101 */         writeShort(paramInt1 >> 16 & 0xFFFF, paramArrayOfByte, paramInt2 + 2);
/*     */       }
/*     */ 
/*     */       private void writeShort(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
/*     */         throws IOException
/*     */       {
/* 107 */         paramArrayOfByte[paramInt2] = (byte)(paramInt1 & 0xFF);
/* 108 */         paramArrayOfByte[(paramInt2 + 1)] = (byte)(paramInt1 >> 8 & 0xFF);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.GzipCodec
 * JD-Core Version:    0.6.1
 */
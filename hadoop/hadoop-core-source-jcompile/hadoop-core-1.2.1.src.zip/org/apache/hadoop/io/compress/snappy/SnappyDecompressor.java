/*     */ package org.apache.hadoop.io.compress.snappy;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.io.compress.Decompressor;
/*     */ 
/*     */ public class SnappyDecompressor
/*     */   implements Decompressor
/*     */ {
/*  34 */   private static final Log LOG = LogFactory.getLog(SnappyCompressor.class.getName());
/*     */   private static final int DEFAULT_DIRECT_BUFFER_SIZE = 65536;
/*  40 */   private static Class clazz = SnappyDecompressor.class;
/*     */   private int directBufferSize;
/*  43 */   private Buffer compressedDirectBuf = null;
/*     */   private int compressedDirectBufLen;
/*  45 */   private Buffer uncompressedDirectBuf = null;
/*  46 */   private byte[] userBuf = null;
/*  47 */   private int userBufOff = 0; private int userBufLen = 0;
/*     */   private boolean finished;
/*     */ 
/*     */   public SnappyDecompressor(int directBufferSize)
/*     */   {
/*  71 */     this.directBufferSize = directBufferSize;
/*     */ 
/*  73 */     this.compressedDirectBuf = ByteBuffer.allocateDirect(directBufferSize);
/*  74 */     this.uncompressedDirectBuf = ByteBuffer.allocateDirect(directBufferSize);
/*  75 */     this.uncompressedDirectBuf.position(directBufferSize);
/*     */   }
/*     */ 
/*     */   public SnappyDecompressor()
/*     */   {
/*  83 */     this(65536);
/*     */   }
/*     */ 
/*     */   public synchronized void setInput(byte[] b, int off, int len)
/*     */   {
/* 102 */     if (b == null) {
/* 103 */       throw new NullPointerException();
/*     */     }
/* 105 */     if ((off < 0) || (len < 0) || (off > b.length - len)) {
/* 106 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/*     */ 
/* 109 */     this.userBuf = b;
/* 110 */     this.userBufOff = off;
/* 111 */     this.userBufLen = len;
/*     */ 
/* 113 */     setInputFromSavedData();
/*     */ 
/* 116 */     this.uncompressedDirectBuf.limit(this.directBufferSize);
/* 117 */     this.uncompressedDirectBuf.position(this.directBufferSize);
/*     */   }
/*     */ 
/*     */   synchronized void setInputFromSavedData()
/*     */   {
/* 126 */     this.compressedDirectBufLen = Math.min(this.userBufLen, this.directBufferSize);
/*     */ 
/* 129 */     this.compressedDirectBuf.rewind();
/* 130 */     ((ByteBuffer)this.compressedDirectBuf).put(this.userBuf, this.userBufOff, this.compressedDirectBufLen);
/*     */ 
/* 134 */     this.userBufOff += this.compressedDirectBufLen;
/* 135 */     this.userBufLen -= this.compressedDirectBufLen;
/*     */   }
/*     */ 
/*     */   public synchronized void setDictionary(byte[] b, int off, int len)
/*     */   {
/*     */   }
/*     */ 
/*     */   public synchronized boolean needsInput()
/*     */   {
/* 158 */     if (this.uncompressedDirectBuf.remaining() > 0) {
/* 159 */       return false;
/*     */     }
/*     */ 
/* 163 */     if (this.compressedDirectBufLen <= 0)
/*     */     {
/* 165 */       if (this.userBufLen <= 0) {
/* 166 */         return true;
/*     */       }
/* 168 */       setInputFromSavedData();
/*     */     }
/*     */ 
/* 172 */     return false;
/*     */   }
/*     */ 
/*     */   public synchronized boolean needsDictionary()
/*     */   {
/* 182 */     return false;
/*     */   }
/*     */ 
/*     */   public synchronized boolean finished()
/*     */   {
/* 194 */     return (this.finished) && (this.uncompressedDirectBuf.remaining() == 0);
/*     */   }
/*     */ 
/*     */   public synchronized int decompress(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 212 */     if (b == null) {
/* 213 */       throw new NullPointerException();
/*     */     }
/* 215 */     if ((off < 0) || (len < 0) || (off > b.length - len)) {
/* 216 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/*     */ 
/* 219 */     int n = 0;
/*     */ 
/* 222 */     n = this.uncompressedDirectBuf.remaining();
/* 223 */     if (n > 0) {
/* 224 */       n = Math.min(n, len);
/* 225 */       ((ByteBuffer)this.uncompressedDirectBuf).get(b, off, n);
/* 226 */       return n;
/*     */     }
/* 228 */     if (this.compressedDirectBufLen > 0)
/*     */     {
/* 230 */       this.uncompressedDirectBuf.rewind();
/* 231 */       this.uncompressedDirectBuf.limit(this.directBufferSize);
/*     */ 
/* 234 */       n = decompressBytesDirect();
/* 235 */       this.uncompressedDirectBuf.limit(n);
/*     */ 
/* 237 */       if (this.userBufLen <= 0) {
/* 238 */         this.finished = true;
/*     */       }
/*     */ 
/* 242 */       n = Math.min(n, len);
/* 243 */       ((ByteBuffer)this.uncompressedDirectBuf).get(b, off, n);
/*     */     }
/*     */ 
/* 246 */     return n;
/*     */   }
/*     */ 
/*     */   public synchronized int getRemaining()
/*     */   {
/* 257 */     return 0;
/*     */   }
/*     */ 
/*     */   public synchronized void reset() {
/* 261 */     this.finished = false;
/* 262 */     this.compressedDirectBufLen = 0;
/* 263 */     this.uncompressedDirectBuf.limit(this.directBufferSize);
/* 264 */     this.uncompressedDirectBuf.position(this.directBufferSize);
/* 265 */     this.userBufOff = (this.userBufLen = 0);
/*     */   }
/*     */ 
/*     */   public synchronized void end()
/*     */   {
/*     */   }
/*     */ 
/*     */   private static native void initIDs();
/*     */ 
/*     */   private native int decompressBytesDirect();
/*     */ 
/*     */   static
/*     */   {
/*  51 */     if (LoadSnappy.isLoaded())
/*     */       try
/*     */       {
/*  54 */         initIDs();
/*     */       }
/*     */       catch (Throwable t) {
/*  57 */         LOG.warn(t.toString());
/*     */       }
/*     */     else
/*  60 */       LOG.error("Cannot load " + SnappyDecompressor.class.getName() + " without snappy library!");
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.snappy.SnappyDecompressor
 * JD-Core Version:    0.6.1
 */
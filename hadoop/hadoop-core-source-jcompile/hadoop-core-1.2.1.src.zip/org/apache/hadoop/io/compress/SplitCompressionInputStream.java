/*    */ package org.apache.hadoop.io.compress;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ public abstract class SplitCompressionInputStream extends CompressionInputStream
/*    */ {
/*    */   private long start;
/*    */   private long end;
/*    */ 
/*    */   public SplitCompressionInputStream(InputStream in, long start, long end)
/*    */     throws IOException
/*    */   {
/* 36 */     super(in);
/* 37 */     this.start = start;
/* 38 */     this.end = end;
/*    */   }
/*    */ 
/*    */   protected void setStart(long start) {
/* 42 */     this.start = start;
/*    */   }
/*    */ 
/*    */   protected void setEnd(long end) {
/* 46 */     this.end = end;
/*    */   }
/*    */ 
/*    */   public long getAdjustedStart()
/*    */   {
/* 55 */     return this.start;
/*    */   }
/*    */ 
/*    */   public long getAdjustedEnd()
/*    */   {
/* 64 */     return this.end;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.SplitCompressionInputStream
 * JD-Core Version:    0.6.1
 */
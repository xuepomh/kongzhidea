/*    */ package org.apache.hadoop.io.compress;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ public abstract class CompressionOutputStream extends OutputStream
/*    */ {
/*    */   protected final OutputStream out;
/*    */ 
/*    */   protected CompressionOutputStream(OutputStream out)
/*    */   {
/* 39 */     this.out = out;
/*    */   }
/*    */ 
/*    */   public void close() throws IOException {
/* 43 */     finish();
/* 44 */     this.out.close();
/*    */   }
/*    */ 
/*    */   public void flush() throws IOException {
/* 48 */     this.out.flush();
/*    */   }
/*    */ 
/*    */   public abstract void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*    */     throws IOException;
/*    */ 
/*    */   public abstract void finish()
/*    */     throws IOException;
/*    */ 
/*    */   public abstract void resetState()
/*    */     throws IOException;
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.CompressionOutputStream
 * JD-Core Version:    0.6.1
 */
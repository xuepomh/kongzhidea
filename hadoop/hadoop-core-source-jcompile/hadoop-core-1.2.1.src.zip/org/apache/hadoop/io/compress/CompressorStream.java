/*     */ package org.apache.hadoop.io.compress;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public class CompressorStream extends CompressionOutputStream
/*     */ {
/*     */   protected Compressor compressor;
/*     */   protected byte[] buffer;
/*  30 */   protected boolean closed = false;
/*     */ 
/* 103 */   private byte[] oneByte = new byte[1];
/*     */ 
/*     */   public CompressorStream(OutputStream out, Compressor compressor, int bufferSize)
/*     */   {
/*  33 */     super(out);
/*     */ 
/*  35 */     if ((out == null) || (compressor == null))
/*  36 */       throw new NullPointerException();
/*  37 */     if (bufferSize <= 0) {
/*  38 */       throw new IllegalArgumentException("Illegal bufferSize");
/*     */     }
/*     */ 
/*  41 */     this.compressor = compressor;
/*  42 */     this.buffer = new byte[bufferSize];
/*     */   }
/*     */ 
/*     */   public CompressorStream(OutputStream out, Compressor compressor) {
/*  46 */     this(out, compressor, 512);
/*     */   }
/*     */ 
/*     */   protected CompressorStream(OutputStream out)
/*     */   {
/*  55 */     super(out);
/*     */   }
/*     */ 
/*     */   public void write(byte[] b, int off, int len) throws IOException
/*     */   {
/*  60 */     if (this.compressor.finished()) {
/*  61 */       throw new IOException("write beyond end of stream");
/*     */     }
/*  63 */     if ((off | len | off + len | b.length - (off + len)) < 0)
/*  64 */       throw new IndexOutOfBoundsException();
/*  65 */     if (len == 0) {
/*  66 */       return;
/*     */     }
/*     */ 
/*  69 */     this.compressor.setInput(b, off, len);
/*  70 */     while (!this.compressor.needsInput())
/*  71 */       compress();
/*     */   }
/*     */ 
/*     */   protected void compress() throws IOException
/*     */   {
/*  76 */     int len = this.compressor.compress(this.buffer, 0, this.buffer.length);
/*  77 */     if (len > 0)
/*  78 */       this.out.write(this.buffer, 0, len);
/*     */   }
/*     */ 
/*     */   public void finish() throws IOException
/*     */   {
/*  83 */     if (!this.compressor.finished()) {
/*  84 */       this.compressor.finish();
/*  85 */       while (!this.compressor.finished())
/*  86 */         compress();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void resetState() throws IOException
/*     */   {
/*  92 */     this.compressor.reset();
/*     */   }
/*     */ 
/*     */   public void close() throws IOException {
/*  96 */     if (!this.closed) {
/*  97 */       finish();
/*  98 */       this.out.close();
/*  99 */       this.closed = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void write(int b) throws IOException
/*     */   {
/* 105 */     this.oneByte[0] = (byte)(b & 0xFF);
/* 106 */     write(this.oneByte, 0, this.oneByte.length);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.CompressorStream
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.io.compress.snappy;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.io.compress.Compressor;
/*     */ 
/*     */ public class SnappyCompressor
/*     */   implements Compressor
/*     */ {
/*  35 */   private static final Log LOG = LogFactory.getLog(SnappyCompressor.class.getName());
/*     */   private static final int DEFAULT_DIRECT_BUFFER_SIZE = 65536;
/*  41 */   private static Class clazz = SnappyCompressor.class;
/*     */   private int directBufferSize;
/*  44 */   private Buffer compressedDirectBuf = null;
/*     */   private int uncompressedDirectBufLen;
/*  46 */   private Buffer uncompressedDirectBuf = null;
/*  47 */   private byte[] userBuf = null;
/*  48 */   private int userBufOff = 0; private int userBufLen = 0;
/*     */   private boolean finish;
/*     */   private boolean finished;
/*  51 */   private long bytesRead = 0L;
/*  52 */   private long bytesWritten = 0L;
/*     */ 
/*     */   public SnappyCompressor(int directBufferSize)
/*     */   {
/*  76 */     this.directBufferSize = directBufferSize;
/*     */ 
/*  78 */     this.uncompressedDirectBuf = ByteBuffer.allocateDirect(directBufferSize);
/*  79 */     this.compressedDirectBuf = ByteBuffer.allocateDirect(directBufferSize);
/*  80 */     this.compressedDirectBuf.position(directBufferSize);
/*     */   }
/*     */ 
/*     */   public SnappyCompressor()
/*     */   {
/*  87 */     this(65536);
/*     */   }
/*     */ 
/*     */   public synchronized void setInput(byte[] b, int off, int len)
/*     */   {
/* 101 */     if (b == null) {
/* 102 */       throw new NullPointerException();
/*     */     }
/* 104 */     if ((off < 0) || (len < 0) || (off > b.length - len)) {
/* 105 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/* 107 */     this.finished = false;
/*     */ 
/* 109 */     if (len > this.uncompressedDirectBuf.remaining())
/*     */     {
/* 111 */       this.userBuf = b;
/* 112 */       this.userBufOff = off;
/* 113 */       this.userBufLen = len;
/*     */     } else {
/* 115 */       ((ByteBuffer)this.uncompressedDirectBuf).put(b, off, len);
/* 116 */       this.uncompressedDirectBufLen = this.uncompressedDirectBuf.position();
/*     */     }
/*     */ 
/* 119 */     this.bytesRead += len;
/*     */   }
/*     */ 
/*     */   synchronized void setInputFromSavedData()
/*     */   {
/* 128 */     if (0 >= this.userBufLen) {
/* 129 */       return;
/*     */     }
/* 131 */     this.finished = false;
/*     */ 
/* 133 */     this.uncompressedDirectBufLen = Math.min(this.userBufLen, this.directBufferSize);
/* 134 */     ((ByteBuffer)this.uncompressedDirectBuf).put(this.userBuf, this.userBufOff, this.uncompressedDirectBufLen);
/*     */ 
/* 138 */     this.userBufOff += this.uncompressedDirectBufLen;
/* 139 */     this.userBufLen -= this.uncompressedDirectBufLen;
/*     */   }
/*     */ 
/*     */   public synchronized void setDictionary(byte[] b, int off, int len)
/*     */   {
/*     */   }
/*     */ 
/*     */   public synchronized boolean needsInput()
/*     */   {
/* 159 */     return (this.compressedDirectBuf.remaining() <= 0) && (this.uncompressedDirectBuf.remaining() != 0) && (this.userBufLen <= 0);
/*     */   }
/*     */ 
/*     */   public synchronized void finish()
/*     */   {
/* 169 */     this.finish = true;
/*     */   }
/*     */ 
/*     */   public synchronized boolean finished()
/*     */   {
/* 182 */     return (this.finish) && (this.finished) && (this.compressedDirectBuf.remaining() == 0);
/*     */   }
/*     */ 
/*     */   public synchronized int compress(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 199 */     if (b == null) {
/* 200 */       throw new NullPointerException();
/*     */     }
/* 202 */     if ((off < 0) || (len < 0) || (off > b.length - len)) {
/* 203 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/*     */ 
/* 207 */     int n = this.compressedDirectBuf.remaining();
/* 208 */     if (n > 0) {
/* 209 */       n = Math.min(n, len);
/* 210 */       ((ByteBuffer)this.compressedDirectBuf).get(b, off, n);
/* 211 */       this.bytesWritten += n;
/* 212 */       return n;
/*     */     }
/*     */ 
/* 216 */     this.compressedDirectBuf.clear();
/* 217 */     this.compressedDirectBuf.limit(0);
/* 218 */     if (0 == this.uncompressedDirectBuf.position())
/*     */     {
/* 220 */       setInputFromSavedData();
/* 221 */       if (0 == this.uncompressedDirectBuf.position())
/*     */       {
/* 223 */         this.finished = true;
/* 224 */         return 0;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 229 */     n = compressBytesDirect();
/* 230 */     this.compressedDirectBuf.limit(n);
/* 231 */     this.uncompressedDirectBuf.clear();
/*     */ 
/* 234 */     if (0 == this.userBufLen) {
/* 235 */       this.finished = true;
/*     */     }
/*     */ 
/* 239 */     n = Math.min(n, len);
/* 240 */     this.bytesWritten += n;
/* 241 */     ((ByteBuffer)this.compressedDirectBuf).get(b, off, n);
/*     */ 
/* 243 */     return n;
/*     */   }
/*     */ 
/*     */   public synchronized void reset()
/*     */   {
/* 251 */     this.finish = false;
/* 252 */     this.finished = false;
/* 253 */     this.uncompressedDirectBuf.clear();
/* 254 */     this.uncompressedDirectBufLen = 0;
/* 255 */     this.compressedDirectBuf.clear();
/* 256 */     this.compressedDirectBuf.limit(0);
/* 257 */     this.userBufOff = (this.userBufLen = 0);
/* 258 */     this.bytesRead = (this.bytesWritten = 0L);
/*     */   }
/*     */ 
/*     */   public synchronized void reinit(Configuration conf)
/*     */   {
/* 269 */     reset();
/*     */   }
/*     */ 
/*     */   public synchronized long getBytesRead()
/*     */   {
/* 277 */     return this.bytesRead;
/*     */   }
/*     */ 
/*     */   public synchronized long getBytesWritten()
/*     */   {
/* 285 */     return this.bytesWritten;
/*     */   }
/*     */ 
/*     */   public synchronized void end()
/*     */   {
/*     */   }
/*     */ 
/*     */   private static native void initIDs();
/*     */ 
/*     */   private native int compressBytesDirect();
/*     */ 
/*     */   static
/*     */   {
/*  56 */     if (LoadSnappy.isLoaded())
/*     */       try
/*     */       {
/*  59 */         initIDs();
/*     */       }
/*     */       catch (Throwable t) {
/*  62 */         LOG.warn(t.toString());
/*     */       }
/*     */     else
/*  65 */       LOG.error("Cannot load " + SnappyCompressor.class.getName() + " without snappy library!");
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.snappy.SnappyCompressor
 * JD-Core Version:    0.6.1
 */
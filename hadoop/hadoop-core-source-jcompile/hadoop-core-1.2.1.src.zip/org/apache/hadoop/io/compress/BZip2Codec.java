/*     */ package org.apache.hadoop.io.compress;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.hadoop.fs.Seekable;
/*     */ import org.apache.hadoop.io.compress.bzip2.BZip2DummyCompressor;
/*     */ import org.apache.hadoop.io.compress.bzip2.BZip2DummyDecompressor;
/*     */ import org.apache.hadoop.io.compress.bzip2.CBZip2InputStream;
/*     */ import org.apache.hadoop.io.compress.bzip2.CBZip2OutputStream;
/*     */ 
/*     */ public class BZip2Codec
/*     */   implements SplittableCompressionCodec
/*     */ {
/*     */   private static final String HEADER = "BZ";
/*  44 */   private static final int HEADER_LEN = "BZ".length();
/*     */   private static final String SUB_HEADER = "h9";
/*  46 */   private static final int SUB_HEADER_LEN = "h9".length();
/*     */ 
/*     */   public CompressionOutputStream createOutputStream(OutputStream out)
/*     */     throws IOException
/*     */   {
/*  64 */     return new BZip2CompressionOutputStream(out);
/*     */   }
/*     */ 
/*     */   public CompressionOutputStream createOutputStream(OutputStream out, Compressor compressor)
/*     */     throws IOException
/*     */   {
/*  75 */     return createOutputStream(out);
/*     */   }
/*     */ 
/*     */   public Class<? extends Compressor> getCompressorType()
/*     */   {
/*  84 */     return BZip2DummyCompressor.class;
/*     */   }
/*     */ 
/*     */   public Compressor createCompressor()
/*     */   {
/*  93 */     return new BZip2DummyCompressor();
/*     */   }
/*     */ 
/*     */   public CompressionInputStream createInputStream(InputStream in)
/*     */     throws IOException
/*     */   {
/* 107 */     return new BZip2CompressionInputStream(in);
/*     */   }
/*     */ 
/*     */   public CompressionInputStream createInputStream(InputStream in, Decompressor decompressor)
/*     */     throws IOException
/*     */   {
/* 117 */     return createInputStream(in);
/*     */   }
/*     */ 
/*     */   public SplitCompressionInputStream createInputStream(InputStream seekableIn, Decompressor decompressor, long start, long end, SplittableCompressionCodec.READ_MODE readMode)
/*     */     throws IOException
/*     */   {
/* 136 */     if (!(seekableIn instanceof Seekable)) {
/* 137 */       throw new IOException("seekableIn must be an instance of " + Seekable.class.getName());
/*     */     }
/*     */ 
/* 142 */     ((Seekable)seekableIn).seek(0L);
/*     */ 
/* 147 */     long FIRST_BZIP2_BLOCK_MARKER_POSITION = CBZip2InputStream.numberOfBytesTillNextMarker(seekableIn);
/*     */ 
/* 149 */     long adjStart = Math.max(0L, start - FIRST_BZIP2_BLOCK_MARKER_POSITION);
/*     */ 
/* 151 */     ((Seekable)seekableIn).seek(adjStart);
/* 152 */     SplitCompressionInputStream in = new BZip2CompressionInputStream(seekableIn, adjStart, end, readMode);
/*     */ 
/* 167 */     if (in.getPos() <= start) {
/* 168 */       ((Seekable)seekableIn).seek(start);
/* 169 */       in = new BZip2CompressionInputStream(seekableIn, start, end, readMode);
/*     */     }
/*     */ 
/* 172 */     return in;
/*     */   }
/*     */ 
/*     */   public Class<? extends Decompressor> getDecompressorType()
/*     */   {
/* 181 */     return BZip2DummyDecompressor.class;
/*     */   }
/*     */ 
/*     */   public Decompressor createDecompressor()
/*     */   {
/* 190 */     return new BZip2DummyDecompressor();
/*     */   }
/*     */ 
/*     */   public String getDefaultExtension()
/*     */   {
/* 199 */     return ".bz2";
/*     */   }
/*     */ 
/*     */   private static class BZip2CompressionInputStream extends SplitCompressionInputStream
/*     */   {
/*     */     private CBZip2InputStream input;
/*     */     boolean needsReset;
/*     */     private BufferedInputStream bufferedIn;
/* 300 */     private boolean isHeaderStripped = false;
/* 301 */     private boolean isSubHeaderStripped = false;
/* 302 */     private SplittableCompressionCodec.READ_MODE readMode = SplittableCompressionCodec.READ_MODE.CONTINUOUS;
/* 303 */     private long startingPos = 0L;
/*     */ 
/* 314 */     POS_ADVERTISEMENT_STATE_MACHINE posSM = POS_ADVERTISEMENT_STATE_MACHINE.HOLD;
/* 315 */     long compressedStreamPosition = 0L;
/*     */ 
/*     */     public BZip2CompressionInputStream(InputStream in)
/*     */       throws IOException
/*     */     {
/* 320 */       this(in, 0L, 9223372036854775807L, SplittableCompressionCodec.READ_MODE.CONTINUOUS);
/*     */     }
/*     */ 
/*     */     public BZip2CompressionInputStream(InputStream in, long start, long end, SplittableCompressionCodec.READ_MODE readMode) throws IOException
/*     */     {
/* 325 */       super(start, end);
/* 326 */       this.needsReset = false;
/* 327 */       this.bufferedIn = new BufferedInputStream(this.in);
/* 328 */       this.startingPos = super.getPos();
/* 329 */       this.readMode = readMode;
/* 330 */       if (this.startingPos == 0L)
/*     */       {
/* 332 */         this.bufferedIn = readStreamHeader();
/*     */       }
/* 334 */       this.input = new CBZip2InputStream(this.bufferedIn, readMode);
/* 335 */       if (this.isHeaderStripped) {
/* 336 */         this.input.updateReportedByteCount(BZip2Codec.HEADER_LEN);
/*     */       }
/*     */ 
/* 339 */       if (this.isSubHeaderStripped) {
/* 340 */         this.input.updateReportedByteCount(BZip2Codec.SUB_HEADER_LEN);
/*     */       }
/*     */ 
/* 343 */       updatePos(false);
/*     */     }
/*     */ 
/*     */     private BufferedInputStream readStreamHeader()
/*     */       throws IOException
/*     */     {
/* 350 */       if (this.in != null) {
/* 351 */         this.bufferedIn.mark(BZip2Codec.HEADER_LEN);
/* 352 */         byte[] headerBytes = new byte[BZip2Codec.HEADER_LEN];
/* 353 */         int actualRead = this.bufferedIn.read(headerBytes, 0, BZip2Codec.HEADER_LEN);
/* 354 */         if (actualRead != -1) {
/* 355 */           String header = new String(headerBytes);
/* 356 */           if (header.compareTo("BZ") != 0) {
/* 357 */             this.bufferedIn.reset();
/*     */           } else {
/* 359 */             this.isHeaderStripped = true;
/*     */ 
/* 362 */             if (this.readMode == SplittableCompressionCodec.READ_MODE.BYBLOCK) {
/* 363 */               actualRead = this.bufferedIn.read(headerBytes, 0, BZip2Codec.SUB_HEADER_LEN);
/*     */ 
/* 365 */               if (actualRead != -1) {
/* 366 */                 this.isSubHeaderStripped = true;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 373 */       if (this.bufferedIn == null) {
/* 374 */         throw new IOException("Failed to read bzip2 stream.");
/*     */       }
/*     */ 
/* 377 */       return this.bufferedIn;
/*     */     }
/*     */ 
/*     */     public void close() throws IOException
/*     */     {
/* 382 */       if (!this.needsReset) {
/* 383 */         this.input.close();
/* 384 */         this.needsReset = true;
/*     */       }
/*     */     }
/*     */ 
/*     */     public int read(byte[] b, int off, int len)
/*     */       throws IOException
/*     */     {
/* 417 */       if (this.needsReset) {
/* 418 */         internalReset();
/*     */       }
/*     */ 
/* 421 */       int result = 0;
/* 422 */       result = this.input.read(b, off, len);
/* 423 */       if (result == -2) {
/* 424 */         this.posSM = POS_ADVERTISEMENT_STATE_MACHINE.ADVERTISE;
/*     */       }
/*     */ 
/* 427 */       if (this.posSM == POS_ADVERTISEMENT_STATE_MACHINE.ADVERTISE) {
/* 428 */         result = this.input.read(b, off, off + 1);
/*     */ 
/* 431 */         updatePos(true);
/* 432 */         this.posSM = POS_ADVERTISEMENT_STATE_MACHINE.HOLD;
/*     */       }
/*     */ 
/* 435 */       return result;
/*     */     }
/*     */ 
/*     */     public int read() throws IOException
/*     */     {
/* 440 */       byte[] b = new byte[1];
/* 441 */       int result = read(b, 0, 1);
/* 442 */       return result < 0 ? result : b[0] & 0xFF;
/*     */     }
/*     */ 
/*     */     private void internalReset() throws IOException {
/* 446 */       if (this.needsReset) {
/* 447 */         this.needsReset = false;
/* 448 */         BufferedInputStream bufferedIn = readStreamHeader();
/* 449 */         this.input = new CBZip2InputStream(bufferedIn, this.readMode);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void resetState()
/*     */       throws IOException
/*     */     {
/* 457 */       this.needsReset = true;
/*     */     }
/*     */ 
/*     */     public long getPos() {
/* 461 */       return this.compressedStreamPosition;
/*     */     }
/*     */ 
/*     */     private void updatePos(boolean shouldAddOn)
/*     */     {
/* 475 */       int addOn = shouldAddOn ? 1 : 0;
/* 476 */       this.compressedStreamPosition = (this.startingPos + this.input.getProcessedByteCount() + addOn);
/*     */     }
/*     */ 
/*     */     private static enum POS_ADVERTISEMENT_STATE_MACHINE
/*     */     {
/* 311 */       HOLD, ADVERTISE;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class BZip2CompressionOutputStream extends CompressionOutputStream
/*     */   {
/*     */     private CBZip2OutputStream output;
/*     */     private boolean needsReset;
/*     */ 
/*     */     public BZip2CompressionOutputStream(OutputStream out)
/*     */       throws IOException
/*     */     {
/* 212 */       super();
/* 213 */       this.needsReset = true;
/*     */     }
/*     */ 
/*     */     private void writeStreamHeader() throws IOException {
/* 217 */       if (this.out != null)
/*     */       {
/* 221 */         this.out.write("BZ".getBytes());
/*     */       }
/*     */     }
/*     */ 
/*     */     public void finish() throws IOException {
/* 226 */       if (this.needsReset)
/*     */       {
/* 230 */         internalReset();
/*     */       }
/* 232 */       this.output.finish();
/* 233 */       this.needsReset = true;
/*     */     }
/*     */ 
/*     */     private void internalReset() throws IOException {
/* 237 */       if (this.needsReset) {
/* 238 */         this.needsReset = false;
/* 239 */         writeStreamHeader();
/* 240 */         this.output = new CBZip2OutputStream(this.out);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void resetState()
/*     */       throws IOException
/*     */     {
/* 247 */       this.needsReset = true;
/*     */     }
/*     */ 
/*     */     public void write(int b) throws IOException {
/* 251 */       if (this.needsReset) {
/* 252 */         internalReset();
/*     */       }
/* 254 */       this.output.write(b);
/*     */     }
/*     */ 
/*     */     public void write(byte[] b, int off, int len) throws IOException {
/* 258 */       if (this.needsReset) {
/* 259 */         internalReset();
/*     */       }
/* 261 */       this.output.write(b, off, len);
/*     */     }
/*     */ 
/*     */     public void close() throws IOException {
/* 265 */       if (this.needsReset)
/*     */       {
/* 269 */         internalReset();
/*     */       }
/* 271 */       this.output.flush();
/* 272 */       this.output.close();
/* 273 */       this.needsReset = true;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.BZip2Codec
 * JD-Core Version:    0.6.1
 */
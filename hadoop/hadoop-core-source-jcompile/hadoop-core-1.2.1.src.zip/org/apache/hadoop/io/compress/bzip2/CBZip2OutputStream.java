/*      */ package org.apache.hadoop.io.compress.bzip2;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ 
/*      */ public class CBZip2OutputStream extends OutputStream
/*      */   implements BZip2Constants
/*      */ {
/*      */   public static final int MIN_BLOCKSIZE = 1;
/*      */   public static final int MAX_BLOCKSIZE = 9;
/*      */   protected static final int SETMASK = 2097152;
/*      */   protected static final int CLEARMASK = -2097153;
/*      */   protected static final int GREATER_ICOST = 15;
/*      */   protected static final int LESSER_ICOST = 0;
/*      */   protected static final int SMALL_THRESH = 20;
/*      */   protected static final int DEPTH_THRESH = 10;
/*      */   protected static final int WORK_FACTOR = 30;
/*      */   protected static final int QSORT_STACK_SIZE = 1000;
/*  207 */   private static final int[] INCS = { 1, 4, 13, 40, 121, 364, 1093, 3280, 9841, 29524, 88573, 265720, 797161, 2391484 };
/*      */   private int last;
/*      */   private int origPtr;
/*      */   private final int blockSize100k;
/*      */   private boolean blockRandomised;
/*      */   private int bsBuff;
/*      */   private int bsLive;
/*  531 */   private final CRC crc = new CRC();
/*      */   private int nInUse;
/*      */   private int nMTF;
/*      */   private int workDone;
/*      */   private int workLimit;
/*      */   private boolean firstAttempt;
/*  545 */   private int currentChar = -1;
/*  546 */   private int runLength = 0;
/*      */   private int blockCRC;
/*      */   private int combinedCRC;
/*      */   private int allowableBlockSize;
/*      */   private Data data;
/*      */   private OutputStream out;
/*      */ 
/*      */   protected static void hbMakeCodeLengths(char[] len, int[] freq, int alphaSize, int maxLen)
/*      */   {
/*  220 */     int[] heap = new int[516];
/*  221 */     int[] weight = new int[516];
/*  222 */     int[] parent = new int[516];
/*      */ 
/*  224 */     int i = alphaSize;
/*      */     while (true) { i--; if (i < 0) break;
/*  225 */       weight[(i + 1)] = ((freq[i] == 0 ? 1 : freq[i]) << 8);
/*      */     }
/*      */ 
/*  228 */     for (boolean tooLong = true; tooLong; ) {
/*  229 */       tooLong = false;
/*      */ 
/*  231 */       int nNodes = alphaSize;
/*  232 */       int nHeap = 0;
/*  233 */       heap[0] = 0;
/*  234 */       weight[0] = 0;
/*  235 */       parent[0] = -2;
/*      */ 
/*  237 */       for (int i = 1; i <= alphaSize; i++) {
/*  238 */         parent[i] = -1;
/*  239 */         nHeap++;
/*  240 */         heap[nHeap] = i;
/*      */ 
/*  242 */         int zz = nHeap;
/*  243 */         int tmp = heap[zz];
/*  244 */         while (weight[tmp] < weight[heap[(zz >> 1)]]) {
/*  245 */           heap[zz] = heap[(zz >> 1)];
/*  246 */           zz >>= 1;
/*      */         }
/*  248 */         heap[zz] = tmp;
/*      */       }
/*      */ 
/*  253 */       while (nHeap > 1) {
/*  254 */         int n1 = heap[1];
/*  255 */         heap[1] = heap[nHeap];
/*  256 */         nHeap--;
/*      */ 
/*  258 */         int yy = 0;
/*  259 */         int zz = 1;
/*  260 */         int tmp = heap[1];
/*      */         while (true)
/*      */         {
/*  263 */           yy = zz << 1;
/*      */ 
/*  265 */           if (yy > nHeap)
/*      */           {
/*      */             break;
/*      */           }
/*  269 */           if ((yy < nHeap) && (weight[heap[(yy + 1)]] < weight[heap[yy]]))
/*      */           {
/*  271 */             yy++;
/*      */           }
/*      */ 
/*  274 */           if (weight[tmp] < weight[heap[yy]])
/*      */           {
/*      */             break;
/*      */           }
/*  278 */           heap[zz] = heap[yy];
/*  279 */           zz = yy;
/*      */         }
/*      */ 
/*  282 */         heap[zz] = tmp;
/*      */ 
/*  284 */         int n2 = heap[1];
/*  285 */         heap[1] = heap[nHeap];
/*  286 */         nHeap--;
/*      */ 
/*  288 */         yy = 0;
/*  289 */         zz = 1;
/*  290 */         tmp = heap[1];
/*      */         while (true)
/*      */         {
/*  293 */           yy = zz << 1;
/*      */ 
/*  295 */           if (yy > nHeap)
/*      */           {
/*      */             break;
/*      */           }
/*  299 */           if ((yy < nHeap) && (weight[heap[(yy + 1)]] < weight[heap[yy]]))
/*      */           {
/*  301 */             yy++;
/*      */           }
/*      */ 
/*  304 */           if (weight[tmp] < weight[heap[yy]])
/*      */           {
/*      */             break;
/*      */           }
/*  308 */           heap[zz] = heap[yy];
/*  309 */           zz = yy;
/*      */         }
/*      */ 
/*  312 */         heap[zz] = tmp;
/*  313 */         nNodes++;
/*      */         int tmp440_438 = nNodes; parent[n2] = tmp440_438; parent[n1] = tmp440_438;
/*      */ 
/*  316 */         int weight_n1 = weight[n1];
/*  317 */         int weight_n2 = weight[n2];
/*  318 */         weight[nNodes] = ((weight_n1 & 0xFFFFFF00) + (weight_n2 & 0xFFFFFF00) | 1 + ((weight_n1 & 0xFF) > (weight_n2 & 0xFF) ? weight_n1 & 0xFF : weight_n2 & 0xFF));
/*      */ 
/*  321 */         parent[nNodes] = -1;
/*  322 */         nHeap++;
/*  323 */         heap[nHeap] = nNodes;
/*      */ 
/*  325 */         tmp = 0;
/*  326 */         zz = nHeap;
/*  327 */         tmp = heap[zz];
/*  328 */         int weight_tmp = weight[tmp];
/*  329 */         while (weight_tmp < weight[heap[(zz >> 1)]]) {
/*  330 */           heap[zz] = heap[(zz >> 1)];
/*  331 */           zz >>= 1;
/*      */         }
/*  333 */         heap[zz] = tmp;
/*      */       }
/*      */ 
/*  339 */       for (int i = 1; i <= alphaSize; i++) {
/*  340 */         int j = 0;
/*  341 */         int k = i;
/*      */         int parent_k;
/*  343 */         while ((parent_k = parent[k]) >= 0) {
/*  344 */           k = parent_k;
/*  345 */           j++;
/*      */         }
/*      */ 
/*  348 */         len[(i - 1)] = (char)j;
/*  349 */         if (j > maxLen) {
/*  350 */           tooLong = true;
/*      */         }
/*      */       }
/*      */ 
/*  354 */       if (tooLong)
/*  355 */         for (int i = 1; i < alphaSize; i++) {
/*  356 */           int j = weight[i] >> 8;
/*  357 */           j = 1 + (j >> 1);
/*  358 */           weight[i] = (j << 8);
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void hbMakeCodeLengths(byte[] len, int[] freq, Data dat, int alphaSize, int maxLen)
/*      */   {
/*  370 */     int[] heap = dat.heap;
/*  371 */     int[] weight = dat.weight;
/*  372 */     int[] parent = dat.parent;
/*      */ 
/*  374 */     int i = alphaSize;
/*      */     while (true) { i--; if (i < 0) break;
/*  375 */       weight[(i + 1)] = ((freq[i] == 0 ? 1 : freq[i]) << 8);
/*      */     }
/*      */ 
/*  378 */     for (boolean tooLong = true; tooLong; ) {
/*  379 */       tooLong = false;
/*      */ 
/*  381 */       int nNodes = alphaSize;
/*  382 */       int nHeap = 0;
/*  383 */       heap[0] = 0;
/*  384 */       weight[0] = 0;
/*  385 */       parent[0] = -2;
/*      */ 
/*  387 */       for (int i = 1; i <= alphaSize; i++) {
/*  388 */         parent[i] = -1;
/*  389 */         nHeap++;
/*  390 */         heap[nHeap] = i;
/*      */ 
/*  392 */         int zz = nHeap;
/*  393 */         int tmp = heap[zz];
/*  394 */         while (weight[tmp] < weight[heap[(zz >> 1)]]) {
/*  395 */           heap[zz] = heap[(zz >> 1)];
/*  396 */           zz >>= 1;
/*      */         }
/*  398 */         heap[zz] = tmp;
/*      */       }
/*      */ 
/*  401 */       while (nHeap > 1) {
/*  402 */         int n1 = heap[1];
/*  403 */         heap[1] = heap[nHeap];
/*  404 */         nHeap--;
/*      */ 
/*  406 */         int yy = 0;
/*  407 */         int zz = 1;
/*  408 */         int tmp = heap[1];
/*      */         while (true)
/*      */         {
/*  411 */           yy = zz << 1;
/*      */ 
/*  413 */           if (yy > nHeap)
/*      */           {
/*      */             break;
/*      */           }
/*  417 */           if ((yy < nHeap) && (weight[heap[(yy + 1)]] < weight[heap[yy]]))
/*      */           {
/*  419 */             yy++;
/*      */           }
/*      */ 
/*  422 */           if (weight[tmp] < weight[heap[yy]])
/*      */           {
/*      */             break;
/*      */           }
/*  426 */           heap[zz] = heap[yy];
/*  427 */           zz = yy;
/*      */         }
/*      */ 
/*  430 */         heap[zz] = tmp;
/*      */ 
/*  432 */         int n2 = heap[1];
/*  433 */         heap[1] = heap[nHeap];
/*  434 */         nHeap--;
/*      */ 
/*  436 */         yy = 0;
/*  437 */         zz = 1;
/*  438 */         tmp = heap[1];
/*      */         while (true)
/*      */         {
/*  441 */           yy = zz << 1;
/*      */ 
/*  443 */           if (yy > nHeap)
/*      */           {
/*      */             break;
/*      */           }
/*  447 */           if ((yy < nHeap) && (weight[heap[(yy + 1)]] < weight[heap[yy]]))
/*      */           {
/*  449 */             yy++;
/*      */           }
/*      */ 
/*  452 */           if (weight[tmp] < weight[heap[yy]])
/*      */           {
/*      */             break;
/*      */           }
/*  456 */           heap[zz] = heap[yy];
/*  457 */           zz = yy;
/*      */         }
/*      */ 
/*  460 */         heap[zz] = tmp;
/*  461 */         nNodes++;
/*      */         int tmp437_435 = nNodes; parent[n2] = tmp437_435; parent[n1] = tmp437_435;
/*      */ 
/*  464 */         int weight_n1 = weight[n1];
/*  465 */         int weight_n2 = weight[n2];
/*  466 */         weight[nNodes] = ((weight_n1 & 0xFFFFFF00) + (weight_n2 & 0xFFFFFF00) | 1 + ((weight_n1 & 0xFF) > (weight_n2 & 0xFF) ? weight_n1 & 0xFF : weight_n2 & 0xFF));
/*      */ 
/*  470 */         parent[nNodes] = -1;
/*  471 */         nHeap++;
/*  472 */         heap[nHeap] = nNodes;
/*      */ 
/*  474 */         tmp = 0;
/*  475 */         zz = nHeap;
/*  476 */         tmp = heap[zz];
/*  477 */         int weight_tmp = weight[tmp];
/*  478 */         while (weight_tmp < weight[heap[(zz >> 1)]]) {
/*  479 */           heap[zz] = heap[(zz >> 1)];
/*  480 */           zz >>= 1;
/*      */         }
/*  482 */         heap[zz] = tmp;
/*      */       }
/*      */ 
/*  486 */       for (int i = 1; i <= alphaSize; i++) {
/*  487 */         int j = 0;
/*  488 */         int k = i;
/*      */         int parent_k;
/*  490 */         while ((parent_k = parent[k]) >= 0) {
/*  491 */           k = parent_k;
/*  492 */           j++;
/*      */         }
/*      */ 
/*  495 */         len[(i - 1)] = (byte)j;
/*  496 */         if (j > maxLen) {
/*  497 */           tooLong = true;
/*      */         }
/*      */       }
/*      */ 
/*  501 */       if (tooLong)
/*  502 */         for (int i = 1; i < alphaSize; i++) {
/*  503 */           int j = weight[i] >> 8;
/*  504 */           j = 1 + (j >> 1);
/*  505 */           weight[i] = (j << 8);
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static int chooseBlockSize(long inputLength)
/*      */   {
/*  572 */     return inputLength > 0L ? (int)Math.min(inputLength / 132000L + 1L, 9L) : 9;
/*      */   }
/*      */ 
/*      */   public CBZip2OutputStream(OutputStream out)
/*      */     throws IOException
/*      */   {
/*  594 */     this(out, 9);
/*      */   }
/*      */ 
/*      */   public CBZip2OutputStream(OutputStream out, int blockSize)
/*      */     throws IOException
/*      */   {
/*  626 */     if (blockSize < 1) {
/*  627 */       throw new IllegalArgumentException("blockSize(" + blockSize + ") < 1");
/*      */     }
/*      */ 
/*  630 */     if (blockSize > 9) {
/*  631 */       throw new IllegalArgumentException("blockSize(" + blockSize + ") > 9");
/*      */     }
/*      */ 
/*  635 */     this.blockSize100k = blockSize;
/*  636 */     this.out = out;
/*  637 */     init();
/*      */   }
/*      */ 
/*      */   public void write(int b) throws IOException {
/*  641 */     if (this.out != null)
/*  642 */       write0(b);
/*      */     else
/*  644 */       throw new IOException("closed");
/*      */   }
/*      */ 
/*      */   private void writeRun() throws IOException
/*      */   {
/*  649 */     int lastShadow = this.last;
/*      */ 
/*  651 */     if (lastShadow < this.allowableBlockSize) {
/*  652 */       int currentCharShadow = this.currentChar;
/*  653 */       Data dataShadow = this.data;
/*  654 */       dataShadow.inUse[currentCharShadow] = true;
/*  655 */       byte ch = (byte)currentCharShadow;
/*      */ 
/*  657 */       int runLengthShadow = this.runLength;
/*  658 */       this.crc.updateCRC(currentCharShadow, runLengthShadow);
/*      */ 
/*  660 */       switch (runLengthShadow) {
/*      */       case 1:
/*  662 */         dataShadow.block[(lastShadow + 2)] = ch;
/*  663 */         this.last = (lastShadow + 1);
/*  664 */         break;
/*      */       case 2:
/*  667 */         dataShadow.block[(lastShadow + 2)] = ch;
/*  668 */         dataShadow.block[(lastShadow + 3)] = ch;
/*  669 */         this.last = (lastShadow + 2);
/*  670 */         break;
/*      */       case 3:
/*  673 */         byte[] block = dataShadow.block;
/*  674 */         block[(lastShadow + 2)] = ch;
/*  675 */         block[(lastShadow + 3)] = ch;
/*  676 */         block[(lastShadow + 4)] = ch;
/*  677 */         this.last = (lastShadow + 3);
/*      */ 
/*  679 */         break;
/*      */       default:
/*  682 */         runLengthShadow -= 4;
/*  683 */         dataShadow.inUse[runLengthShadow] = true;
/*  684 */         byte[] block = dataShadow.block;
/*  685 */         block[(lastShadow + 2)] = ch;
/*  686 */         block[(lastShadow + 3)] = ch;
/*  687 */         block[(lastShadow + 4)] = ch;
/*  688 */         block[(lastShadow + 5)] = ch;
/*  689 */         block[(lastShadow + 6)] = (byte)runLengthShadow;
/*  690 */         this.last = (lastShadow + 5);
/*      */       }
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*  696 */       endBlock();
/*  697 */       initBlock();
/*  698 */       writeRun();
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void finalize()
/*      */     throws Throwable
/*      */   {
/*  706 */     finish();
/*  707 */     super.finalize();
/*      */   }
/*      */ 
/*      */   public void finish() throws IOException
/*      */   {
/*  712 */     if (this.out != null)
/*      */       try {
/*  714 */         if (this.runLength > 0) {
/*  715 */           writeRun();
/*      */         }
/*  717 */         this.currentChar = -1;
/*  718 */         endBlock();
/*  719 */         endCompression();
/*      */       } finally {
/*  721 */         this.out = null;
/*  722 */         this.data = null;
/*      */       }
/*      */   }
/*      */ 
/*      */   public void close() throws IOException
/*      */   {
/*  728 */     if (this.out != null) {
/*  729 */       OutputStream outShadow = this.out;
/*  730 */       finish();
/*  731 */       outShadow.close();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void flush() throws IOException {
/*  736 */     OutputStream outShadow = this.out;
/*  737 */     if (outShadow != null)
/*  738 */       outShadow.flush();
/*      */   }
/*      */ 
/*      */   private void init()
/*      */     throws IOException
/*      */   {
/*  747 */     this.data = new Data(this.blockSize100k);
/*      */ 
/*  753 */     bsPutUByte(104);
/*  754 */     bsPutUByte(48 + this.blockSize100k);
/*      */ 
/*  756 */     this.combinedCRC = 0;
/*  757 */     initBlock();
/*      */   }
/*      */ 
/*      */   private void initBlock()
/*      */   {
/*  762 */     this.crc.initialiseCRC();
/*  763 */     this.last = -1;
/*      */ 
/*  766 */     boolean[] inUse = this.data.inUse;
/*  767 */     int i = 256;
/*      */     while (true) { i--; if (i < 0) break;
/*  768 */       inUse[i] = false;
/*      */     }
/*      */ 
/*  772 */     this.allowableBlockSize = (this.blockSize100k * 100000 - 20);
/*      */   }
/*      */ 
/*      */   private void endBlock() throws IOException {
/*  776 */     this.blockCRC = this.crc.getFinalCRC();
/*  777 */     this.combinedCRC = (this.combinedCRC << 1 | this.combinedCRC >>> 31);
/*  778 */     this.combinedCRC ^= this.blockCRC;
/*      */ 
/*  781 */     if (this.last == -1) {
/*  782 */       return;
/*      */     }
/*      */ 
/*  786 */     blockSort();
/*      */ 
/*  799 */     bsPutUByte(49);
/*  800 */     bsPutUByte(65);
/*  801 */     bsPutUByte(89);
/*  802 */     bsPutUByte(38);
/*  803 */     bsPutUByte(83);
/*  804 */     bsPutUByte(89);
/*      */ 
/*  807 */     bsPutInt(this.blockCRC);
/*      */ 
/*  810 */     if (this.blockRandomised)
/*  811 */       bsW(1, 1);
/*      */     else {
/*  813 */       bsW(1, 0);
/*      */     }
/*      */ 
/*  817 */     moveToFrontCodeAndSend();
/*      */   }
/*      */ 
/*      */   private void endCompression()
/*      */     throws IOException
/*      */   {
/*  827 */     bsPutUByte(23);
/*  828 */     bsPutUByte(114);
/*  829 */     bsPutUByte(69);
/*  830 */     bsPutUByte(56);
/*  831 */     bsPutUByte(80);
/*  832 */     bsPutUByte(144);
/*      */ 
/*  834 */     bsPutInt(this.combinedCRC);
/*  835 */     bsFinishedWithStream();
/*      */   }
/*      */ 
/*      */   public final int getBlockSize()
/*      */   {
/*  842 */     return this.blockSize100k;
/*      */   }
/*      */ 
/*      */   public void write(byte[] buf, int offs, int len) throws IOException
/*      */   {
/*  847 */     if (offs < 0) {
/*  848 */       throw new IndexOutOfBoundsException("offs(" + offs + ") < 0.");
/*      */     }
/*  850 */     if (len < 0) {
/*  851 */       throw new IndexOutOfBoundsException("len(" + len + ") < 0.");
/*      */     }
/*  853 */     if (offs + len > buf.length) {
/*  854 */       throw new IndexOutOfBoundsException("offs(" + offs + ") + len(" + len + ") > buf.length(" + buf.length + ").");
/*      */     }
/*      */ 
/*  857 */     if (this.out == null) {
/*  858 */       throw new IOException("stream closed");
/*      */     }
/*      */ 
/*  861 */     for (int hi = offs + len; offs < hi; )
/*  862 */       write0(buf[(offs++)]);
/*      */   }
/*      */ 
/*      */   private void write0(int b) throws IOException
/*      */   {
/*  867 */     if (this.currentChar != -1) {
/*  868 */       b &= 255;
/*  869 */       if (this.currentChar == b) {
/*  870 */         if (++this.runLength > 254) {
/*  871 */           writeRun();
/*  872 */           this.currentChar = -1;
/*  873 */           this.runLength = 0;
/*      */         }
/*      */       }
/*      */       else {
/*  877 */         writeRun();
/*  878 */         this.runLength = 1;
/*  879 */         this.currentChar = b;
/*      */       }
/*      */     } else {
/*  882 */       this.currentChar = (b & 0xFF);
/*  883 */       this.runLength += 1;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void hbAssignCodes(int[] code, byte[] length, int minLen, int maxLen, int alphaSize)
/*      */   {
/*  889 */     int vec = 0;
/*  890 */     for (int n = minLen; n <= maxLen; n++) {
/*  891 */       for (int i = 0; i < alphaSize; i++) {
/*  892 */         if ((length[i] & 0xFF) == n) {
/*  893 */           code[i] = vec;
/*  894 */           vec++;
/*      */         }
/*      */       }
/*  897 */       vec <<= 1;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void bsFinishedWithStream() throws IOException {
/*  902 */     while (this.bsLive > 0) {
/*  903 */       int ch = this.bsBuff >> 24;
/*  904 */       this.out.write(ch);
/*  905 */       this.bsBuff <<= 8;
/*  906 */       this.bsLive -= 8;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void bsW(int n, int v) throws IOException {
/*  911 */     OutputStream outShadow = this.out;
/*  912 */     int bsLiveShadow = this.bsLive;
/*  913 */     int bsBuffShadow = this.bsBuff;
/*      */ 
/*  915 */     while (bsLiveShadow >= 8) {
/*  916 */       outShadow.write(bsBuffShadow >> 24);
/*  917 */       bsBuffShadow <<= 8;
/*  918 */       bsLiveShadow -= 8;
/*      */     }
/*      */ 
/*  921 */     this.bsBuff = (bsBuffShadow | v << 32 - bsLiveShadow - n);
/*  922 */     this.bsLive = (bsLiveShadow + n);
/*      */   }
/*      */ 
/*      */   private void bsPutUByte(int c) throws IOException {
/*  926 */     bsW(8, c);
/*      */   }
/*      */ 
/*      */   private void bsPutInt(int u) throws IOException {
/*  930 */     bsW(8, u >> 24 & 0xFF);
/*  931 */     bsW(8, u >> 16 & 0xFF);
/*  932 */     bsW(8, u >> 8 & 0xFF);
/*  933 */     bsW(8, u & 0xFF);
/*      */   }
/*      */ 
/*      */   private void sendMTFValues() throws IOException {
/*  937 */     byte[][] len = this.data.sendMTFValues_len;
/*  938 */     int alphaSize = this.nInUse + 2;
/*      */ 
/*  940 */     int t = 6;
/*      */     while (true) { t--; if (t < 0) break;
/*  941 */       byte[] len_t = len[t];
/*  942 */       int v = alphaSize;
/*      */       while (true) { v--; if (v < 0) break;
/*  943 */         len_t[v] = 15;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  949 */     int nGroups = this.nMTF < 2400 ? 5 : this.nMTF < 1200 ? 4 : this.nMTF < 600 ? 3 : this.nMTF < 200 ? 2 : 6;
/*      */ 
/*  953 */     sendMTFValues0(nGroups, alphaSize);
/*      */ 
/*  958 */     int nSelectors = sendMTFValues1(nGroups, alphaSize);
/*      */ 
/*  961 */     sendMTFValues2(nGroups, nSelectors);
/*      */ 
/*  964 */     sendMTFValues3(nGroups, alphaSize);
/*      */ 
/*  967 */     sendMTFValues4();
/*      */ 
/*  970 */     sendMTFValues5(nGroups, nSelectors);
/*      */ 
/*  973 */     sendMTFValues6(nGroups, alphaSize);
/*      */ 
/*  976 */     sendMTFValues7(nSelectors);
/*      */   }
/*      */ 
/*      */   private void sendMTFValues0(int nGroups, int alphaSize) {
/*  980 */     byte[][] len = this.data.sendMTFValues_len;
/*  981 */     int[] mtfFreq = this.data.mtfFreq;
/*      */ 
/*  983 */     int remF = this.nMTF;
/*  984 */     int gs = 0;
/*      */ 
/*  986 */     for (int nPart = nGroups; nPart > 0; nPart--) {
/*  987 */       int tFreq = remF / nPart;
/*  988 */       int ge = gs - 1;
/*  989 */       int aFreq = 0;
/*      */ 
/*  991 */       for (int a = alphaSize - 1; (aFreq < tFreq) && (ge < a); ) {
/*  992 */         aFreq += mtfFreq[(++ge)];
/*      */       }
/*      */ 
/*  995 */       if ((ge > gs) && (nPart != nGroups) && (nPart != 1) && ((nGroups - nPart & 0x1) != 0))
/*      */       {
/*  997 */         aFreq -= mtfFreq[(ge--)];
/*      */       }
/*      */ 
/* 1000 */       byte[] len_np = len[(nPart - 1)];
/* 1001 */       int v = alphaSize;
/*      */       while (true) { v--; if (v < 0) break;
/* 1002 */         if ((v >= gs) && (v <= ge))
/* 1003 */           len_np[v] = 0;
/*      */         else {
/* 1005 */           len_np[v] = 15;
/*      */         }
/*      */       }
/*      */ 
/* 1009 */       gs = ge + 1;
/* 1010 */       remF -= aFreq;
/*      */     }
/*      */   }
/*      */ 
/*      */   private int sendMTFValues1(int nGroups, int alphaSize) {
/* 1015 */     Data dataShadow = this.data;
/* 1016 */     int[][] rfreq = dataShadow.sendMTFValues_rfreq;
/* 1017 */     int[] fave = dataShadow.sendMTFValues_fave;
/* 1018 */     short[] cost = dataShadow.sendMTFValues_cost;
/* 1019 */     char[] sfmap = dataShadow.sfmap;
/* 1020 */     byte[] selector = dataShadow.selector;
/* 1021 */     byte[][] len = dataShadow.sendMTFValues_len;
/* 1022 */     byte[] len_0 = len[0];
/* 1023 */     byte[] len_1 = len[1];
/* 1024 */     byte[] len_2 = len[2];
/* 1025 */     byte[] len_3 = len[3];
/* 1026 */     byte[] len_4 = len[4];
/* 1027 */     byte[] len_5 = len[5];
/* 1028 */     int nMTFShadow = this.nMTF;
/*      */ 
/* 1030 */     int nSelectors = 0;
/*      */ 
/* 1032 */     for (int iter = 0; iter < 4; iter++) {
/* 1033 */       int t = nGroups;
/*      */       while (true) { t--; if (t < 0) break;
/* 1034 */         fave[t] = 0;
/* 1035 */         int[] rfreqt = rfreq[t];
/* 1036 */         int i = alphaSize;
/*      */         while (true) { i--; if (i < 0) break;
/* 1037 */           rfreqt[i] = 0;
/*      */         }
/*      */       }
/*      */ 
/* 1041 */       nSelectors = 0;
/*      */ 
/* 1043 */       for (int gs = 0; gs < this.nMTF; )
/*      */       {
/* 1051 */         int ge = Math.min(gs + 50 - 1, nMTFShadow - 1);
/*      */ 
/* 1053 */         if (nGroups == 6)
/*      */         {
/* 1056 */           short cost0 = 0;
/* 1057 */           short cost1 = 0;
/* 1058 */           short cost2 = 0;
/* 1059 */           short cost3 = 0;
/* 1060 */           short cost4 = 0;
/* 1061 */           short cost5 = 0;
/*      */ 
/* 1063 */           for (int i = gs; i <= ge; i++) {
/* 1064 */             int icv = sfmap[i];
/* 1065 */             cost0 = (short)(cost0 + (len_0[icv] & 0xFF));
/* 1066 */             cost1 = (short)(cost1 + (len_1[icv] & 0xFF));
/* 1067 */             cost2 = (short)(cost2 + (len_2[icv] & 0xFF));
/* 1068 */             cost3 = (short)(cost3 + (len_3[icv] & 0xFF));
/* 1069 */             cost4 = (short)(cost4 + (len_4[icv] & 0xFF));
/* 1070 */             cost5 = (short)(cost5 + (len_5[icv] & 0xFF));
/*      */           }
/*      */ 
/* 1073 */           cost[0] = cost0;
/* 1074 */           cost[1] = cost1;
/* 1075 */           cost[2] = cost2;
/* 1076 */           cost[3] = cost3;
/* 1077 */           cost[4] = cost4;
/* 1078 */           cost[5] = cost5;
/*      */         }
/*      */         else {
/* 1081 */           int t = nGroups;
/*      */           while (true) { t--; if (t < 0) break;
/* 1082 */             cost[t] = 0;
/*      */           }
/*      */ 
/* 1085 */           for (int i = gs; i <= ge; i++) {
/* 1086 */             int icv = sfmap[i];
/* 1087 */             int t = nGroups;
/*      */             while (true) { t--; if (t < 0)
/*      */                 break;
/*      */               int tmp403_401 = t;
/*      */               short[] tmp403_399 = cost; tmp403_399[tmp403_401] = (short)(tmp403_399[tmp403_401] + (len[t][icv] & 0xFF));
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1097 */         int bt = -1;
/* 1098 */         int t = nGroups; int bc = 999999999;
/*      */         while (true) { t--; if (t < 0) break;
/* 1099 */           int cost_t = cost[t];
/* 1100 */           if (cost_t < bc) {
/* 1101 */             bc = cost_t;
/* 1102 */             bt = t;
/*      */           }
/*      */         }
/*      */ 
/* 1106 */         fave[bt] += 1;
/* 1107 */         selector[nSelectors] = (byte)bt;
/* 1108 */         nSelectors++;
/*      */ 
/* 1113 */         int[] rfreq_bt = rfreq[bt];
/* 1114 */         for (int i = gs; i <= ge; i++) {
/* 1115 */           rfreq_bt[sfmap[i]] += 1;
/*      */         }
/*      */ 
/* 1118 */         gs = ge + 1;
/*      */       }
/*      */ 
/* 1124 */       for (int t = 0; t < nGroups; t++) {
/* 1125 */         hbMakeCodeLengths(len[t], rfreq[t], this.data, alphaSize, 20);
/*      */       }
/*      */     }
/*      */ 
/* 1129 */     return nSelectors;
/*      */   }
/*      */ 
/*      */   private void sendMTFValues2(int nGroups, int nSelectors)
/*      */   {
/* 1135 */     Data dataShadow = this.data;
/* 1136 */     byte[] pos = dataShadow.sendMTFValues2_pos;
/*      */ 
/* 1138 */     int i = nGroups;
/*      */     while (true) { i--; if (i < 0) break;
/* 1139 */       pos[i] = (byte)i;
/*      */     }
/*      */ 
/* 1142 */     for (int i = 0; i < nSelectors; i++) {
/* 1143 */       byte ll_i = dataShadow.selector[i];
/* 1144 */       byte tmp = pos[0];
/* 1145 */       int j = 0;
/*      */ 
/* 1147 */       while (ll_i != tmp) {
/* 1148 */         j++;
/* 1149 */         byte tmp2 = tmp;
/* 1150 */         tmp = pos[j];
/* 1151 */         pos[j] = tmp2;
/*      */       }
/*      */ 
/* 1154 */       pos[0] = tmp;
/* 1155 */       dataShadow.selectorMtf[i] = (byte)j;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void sendMTFValues3(int nGroups, int alphaSize) {
/* 1160 */     int[][] code = this.data.sendMTFValues_code;
/* 1161 */     byte[][] len = this.data.sendMTFValues_len;
/*      */ 
/* 1163 */     for (int t = 0; t < nGroups; t++) {
/* 1164 */       int minLen = 32;
/* 1165 */       int maxLen = 0;
/* 1166 */       byte[] len_t = len[t];
/* 1167 */       int i = alphaSize;
/*      */       while (true) { i--; if (i < 0) break;
/* 1168 */         int l = len_t[i] & 0xFF;
/* 1169 */         if (l > maxLen) {
/* 1170 */           maxLen = l;
/*      */         }
/* 1172 */         if (l < minLen) {
/* 1173 */           minLen = l;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1180 */       hbAssignCodes(code[t], len[t], minLen, maxLen, alphaSize);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void sendMTFValues4() throws IOException {
/* 1185 */     boolean[] inUse = this.data.inUse;
/* 1186 */     boolean[] inUse16 = this.data.sentMTFValues4_inUse16;
/*      */ 
/* 1188 */     int i = 16;
/*      */     while (true) { i--; if (i < 0) break;
/* 1189 */       inUse16[i] = false;
/* 1190 */       int i16 = i * 16;
/* 1191 */       int j = 16;
/*      */       while (true) { j--; if (j < 0) break;
/* 1192 */         if (inUse[(i16 + j)] != 0) {
/* 1193 */           inUse16[i] = true;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1198 */     for (int i = 0; i < 16; i++) {
/* 1199 */       bsW(1, inUse16[i] != 0 ? 1 : 0);
/*      */     }
/*      */ 
/* 1202 */     OutputStream outShadow = this.out;
/* 1203 */     int bsLiveShadow = this.bsLive;
/* 1204 */     int bsBuffShadow = this.bsBuff;
/*      */ 
/* 1206 */     for (int i = 0; i < 16; i++) {
/* 1207 */       if (inUse16[i] != 0) {
/* 1208 */         int i16 = i * 16;
/* 1209 */         for (int j = 0; j < 16; j++)
/*      */         {
/* 1211 */           while (bsLiveShadow >= 8) {
/* 1212 */             outShadow.write(bsBuffShadow >> 24);
/* 1213 */             bsBuffShadow <<= 8;
/* 1214 */             bsLiveShadow -= 8;
/*      */           }
/* 1216 */           if (inUse[(i16 + j)] != 0) {
/* 1217 */             bsBuffShadow |= 1 << 32 - bsLiveShadow - 1;
/*      */           }
/* 1219 */           bsLiveShadow++;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1224 */     this.bsBuff = bsBuffShadow;
/* 1225 */     this.bsLive = bsLiveShadow;
/*      */   }
/*      */ 
/*      */   private void sendMTFValues5(int nGroups, int nSelectors) throws IOException
/*      */   {
/* 1230 */     bsW(3, nGroups);
/* 1231 */     bsW(15, nSelectors);
/*      */ 
/* 1233 */     OutputStream outShadow = this.out;
/* 1234 */     byte[] selectorMtf = this.data.selectorMtf;
/*      */ 
/* 1236 */     int bsLiveShadow = this.bsLive;
/* 1237 */     int bsBuffShadow = this.bsBuff;
/*      */ 
/* 1239 */     for (int i = 0; i < nSelectors; i++) {
/* 1240 */       int j = 0; for (int hj = selectorMtf[i] & 0xFF; j < hj; j++)
/*      */       {
/* 1242 */         while (bsLiveShadow >= 8) {
/* 1243 */           outShadow.write(bsBuffShadow >> 24);
/* 1244 */           bsBuffShadow <<= 8;
/* 1245 */           bsLiveShadow -= 8;
/*      */         }
/* 1247 */         bsBuffShadow |= 1 << 32 - bsLiveShadow - 1;
/* 1248 */         bsLiveShadow++;
/*      */       }
/*      */ 
/* 1252 */       while (bsLiveShadow >= 8) {
/* 1253 */         outShadow.write(bsBuffShadow >> 24);
/* 1254 */         bsBuffShadow <<= 8;
/* 1255 */         bsLiveShadow -= 8;
/*      */       }
/*      */ 
/* 1258 */       bsLiveShadow++;
/*      */     }
/*      */ 
/* 1261 */     this.bsBuff = bsBuffShadow;
/* 1262 */     this.bsLive = bsLiveShadow;
/*      */   }
/*      */ 
/*      */   private void sendMTFValues6(int nGroups, int alphaSize) throws IOException
/*      */   {
/* 1267 */     byte[][] len = this.data.sendMTFValues_len;
/* 1268 */     OutputStream outShadow = this.out;
/*      */ 
/* 1270 */     int bsLiveShadow = this.bsLive;
/* 1271 */     int bsBuffShadow = this.bsBuff;
/*      */ 
/* 1273 */     for (int t = 0; t < nGroups; t++) {
/* 1274 */       byte[] len_t = len[t];
/* 1275 */       int curr = len_t[0] & 0xFF;
/*      */ 
/* 1278 */       while (bsLiveShadow >= 8) {
/* 1279 */         outShadow.write(bsBuffShadow >> 24);
/* 1280 */         bsBuffShadow <<= 8;
/* 1281 */         bsLiveShadow -= 8;
/*      */       }
/* 1283 */       bsBuffShadow |= curr << 32 - bsLiveShadow - 5;
/* 1284 */       bsLiveShadow += 5;
/*      */ 
/* 1286 */       for (int i = 0; i < alphaSize; i++) {
/* 1287 */         int lti = len_t[i] & 0xFF;
/* 1288 */         while (curr < lti)
/*      */         {
/* 1290 */           while (bsLiveShadow >= 8) {
/* 1291 */             outShadow.write(bsBuffShadow >> 24);
/* 1292 */             bsBuffShadow <<= 8;
/* 1293 */             bsLiveShadow -= 8;
/*      */           }
/* 1295 */           bsBuffShadow |= 2 << 32 - bsLiveShadow - 2;
/* 1296 */           bsLiveShadow += 2;
/*      */ 
/* 1298 */           curr++;
/*      */         }
/*      */ 
/* 1301 */         while (curr > lti)
/*      */         {
/* 1303 */           while (bsLiveShadow >= 8) {
/* 1304 */             outShadow.write(bsBuffShadow >> 24);
/* 1305 */             bsBuffShadow <<= 8;
/* 1306 */             bsLiveShadow -= 8;
/*      */           }
/* 1308 */           bsBuffShadow |= 3 << 32 - bsLiveShadow - 2;
/* 1309 */           bsLiveShadow += 2;
/*      */ 
/* 1311 */           curr--;
/*      */         }
/*      */ 
/* 1315 */         while (bsLiveShadow >= 8) {
/* 1316 */           outShadow.write(bsBuffShadow >> 24);
/* 1317 */           bsBuffShadow <<= 8;
/* 1318 */           bsLiveShadow -= 8;
/*      */         }
/*      */ 
/* 1321 */         bsLiveShadow++;
/*      */       }
/*      */     }
/*      */ 
/* 1325 */     this.bsBuff = bsBuffShadow;
/* 1326 */     this.bsLive = bsLiveShadow;
/*      */   }
/*      */ 
/*      */   private void sendMTFValues7(int nSelectors) throws IOException {
/* 1330 */     Data dataShadow = this.data;
/* 1331 */     byte[][] len = dataShadow.sendMTFValues_len;
/* 1332 */     int[][] code = dataShadow.sendMTFValues_code;
/* 1333 */     OutputStream outShadow = this.out;
/* 1334 */     byte[] selector = dataShadow.selector;
/* 1335 */     char[] sfmap = dataShadow.sfmap;
/* 1336 */     int nMTFShadow = this.nMTF;
/*      */ 
/* 1338 */     int selCtr = 0;
/*      */ 
/* 1340 */     int bsLiveShadow = this.bsLive;
/* 1341 */     int bsBuffShadow = this.bsBuff;
/*      */ 
/* 1343 */     for (int gs = 0; gs < nMTFShadow; ) {
/* 1344 */       int ge = Math.min(gs + 50 - 1, nMTFShadow - 1);
/* 1345 */       int selector_selCtr = selector[selCtr] & 0xFF;
/* 1346 */       int[] code_selCtr = code[selector_selCtr];
/* 1347 */       byte[] len_selCtr = len[selector_selCtr];
/*      */ 
/* 1349 */       while (gs <= ge) {
/* 1350 */         int sfmap_i = sfmap[gs];
/*      */ 
/* 1356 */         while (bsLiveShadow >= 8) {
/* 1357 */           outShadow.write(bsBuffShadow >> 24);
/* 1358 */           bsBuffShadow <<= 8;
/* 1359 */           bsLiveShadow -= 8;
/*      */         }
/* 1361 */         int n = len_selCtr[sfmap_i] & 0xFF;
/* 1362 */         bsBuffShadow |= code_selCtr[sfmap_i] << 32 - bsLiveShadow - n;
/* 1363 */         bsLiveShadow += n;
/*      */ 
/* 1365 */         gs++;
/*      */       }
/*      */ 
/* 1368 */       gs = ge + 1;
/* 1369 */       selCtr++;
/*      */     }
/*      */ 
/* 1372 */     this.bsBuff = bsBuffShadow;
/* 1373 */     this.bsLive = bsLiveShadow;
/*      */   }
/*      */ 
/*      */   private void moveToFrontCodeAndSend() throws IOException {
/* 1377 */     bsW(24, this.origPtr);
/* 1378 */     generateMTFValues();
/* 1379 */     sendMTFValues();
/*      */   }
/*      */ 
/*      */   private boolean mainSimpleSort(Data dataShadow, int lo, int hi, int d)
/*      */   {
/* 1394 */     int bigN = hi - lo + 1;
/* 1395 */     if (bigN < 2) {
/* 1396 */       return (this.firstAttempt) && (this.workDone > this.workLimit);
/*      */     }
/*      */ 
/* 1399 */     int hp = 0;
/* 1400 */     while (INCS[hp] < bigN) {
/* 1401 */       hp++; } 
/*      */ int[] fmap = dataShadow.fmap;
/* 1405 */     char[] quadrant = dataShadow.quadrant;
/* 1406 */     byte[] block = dataShadow.block;
/* 1407 */     int lastShadow = this.last;
/* 1408 */     int lastPlus1 = lastShadow + 1;
/* 1409 */     boolean firstAttemptShadow = this.firstAttempt;
/* 1410 */     int workLimitShadow = this.workLimit;
/* 1411 */     int workDoneShadow = this.workDone;
/*      */     int h;
/*      */     int mj;
/*      */     int i;
/*      */     label542: label570: label590: label618: label638: 
/*      */     while (true) { hp--; if (hp < 0) break;
/* 1417 */       h = INCS[hp];
/* 1418 */       mj = lo + h - 1;
/*      */ 
/* 1420 */       for (i = lo + h; i <= hi; )
/*      */       {
/* 1422 */         for (int k = 3; i <= hi; i++) { k--; if (k < 0)
/*      */             break;
/* 1423 */           int v = fmap[i];
/* 1424 */           int vd = v + d;
/* 1425 */           int j = i;
/*      */ 
/* 1437 */           boolean onceRunned = false;
/* 1438 */           int a = 0;
/*      */           int i1;
/*      */           int i2;
/*      */           do {
/*      */             while (true)
/*      */             {
/* 1441 */               if (onceRunned) {
/* 1442 */                 fmap[j] = a;
/* 1443 */                 if (j -= h <= mj)
/* 1444 */                   break label874;
/*      */               }
/*      */               else {
/* 1447 */                 onceRunned = true;
/*      */               }
/*      */ 
/* 1450 */               a = fmap[(j - h)];
/* 1451 */               i1 = a + d;
/* 1452 */               i2 = vd;
/*      */ 
/* 1456 */               if (block[(i1 + 1)] != block[(i2 + 1)]) break;
/* 1457 */               if (block[(i1 + 2)] == block[(i2 + 2)]) {
/* 1458 */                 if (block[(i1 + 3)] == block[(i2 + 3)]) {
/* 1459 */                   if (block[(i1 + 4)] == block[(i2 + 4)]) {
/* 1460 */                     if (block[(i1 + 5)] == block[(i2 + 5)]) {
/* 1461 */                       i1 += 6; i2 += 6; if (block[i1] == block[i2]) {
/* 1462 */                         int x = lastShadow;
/*      */                         while (true) { if (x <= 0) break label874;
/* 1464 */                           x -= 4;
/*      */ 
/* 1466 */                           if (block[(i1 + 1)] != block[(i2 + 1)]) break label682;
/* 1467 */                           if (quadrant[i1] != quadrant[i2]) break label666;
/* 1468 */                           if (block[(i1 + 2)] != block[(i2 + 2)]) break label638;
/* 1469 */                           if (quadrant[(i1 + 1)] != quadrant[(i2 + 1)]) break label618;
/* 1470 */                           if (block[(i1 + 3)] != block[(i2 + 3)]) break label590;
/* 1471 */                           if (quadrant[(i1 + 2)] != quadrant[(i2 + 2)]) break label570;
/* 1472 */                           if (block[(i1 + 4)] != block[(i2 + 4)]) break label542;
/* 1473 */                           if (quadrant[(i1 + 3)] != quadrant[(i2 + 3)]) break;
/* 1474 */                           i1 += 4; if (i1 >= lastPlus1) {
/* 1475 */                             i1 -= lastPlus1;
/*      */                           }
/* 1477 */                           i2 += 4; if (i2 >= lastPlus1) {
/* 1478 */                             i2 -= lastPlus1;
/*      */                           }
/* 1480 */                           workDoneShadow++;
/*      */                         }
/* 1482 */                         if (quadrant[(i1 + 3)] <= quadrant[(i2 + 3)]) break label874;
/* 1483 */                         continue;
/*      */ 
/* 1487 */                         if ((block[(i1 + 4)] & 0xFF) <= (block[(i2 + 4)] & 0xFF)) break label874;
/* 1488 */                         continue;
/*      */ 
/* 1492 */                         if (quadrant[(i1 + 2)] <= quadrant[(i2 + 2)]) break label874;
/* 1493 */                         continue;
/*      */ 
/* 1497 */                         if ((block[(i1 + 3)] & 0xFF) <= (block[(i2 + 3)] & 0xFF)) break label874;
/* 1498 */                         continue;
/*      */ 
/* 1502 */                         if (quadrant[(i1 + 1)] <= quadrant[(i2 + 1)]) break label874;
/* 1503 */                         continue;
/*      */ 
/* 1507 */                         if ((block[(i1 + 2)] & 0xFF) <= (block[(i2 + 2)] & 0xFF)) break label874;
/* 1508 */                         continue;
/*      */ 
/* 1512 */                         if (quadrant[i1] <= quadrant[i2]) break label874;
/* 1513 */                         continue;
/*      */ 
/* 1517 */                         if ((block[(i1 + 1)] & 0xFF) <= (block[(i2 + 1)] & 0xFF))
/*      */                         {
/*      */                           break label874;
/*      */                         }
/*      */ 
/*      */                       }
/*      */                       else
/*      */                       {
/* 1527 */                         if ((block[i1] & 0xFF) <= (block[i2] & 0xFF))
/*      */                           break label874;
/*      */                       }
/*      */                     }
/*      */                     else
/*      */                     {
/* 1533 */                       if ((block[(i1 + 5)] & 0xFF) <= (block[(i2 + 5)] & 0xFF))
/*      */                         break label874;
/*      */                     }
/*      */                   }
/*      */                   else {
/* 1538 */                     if ((block[(i1 + 4)] & 0xFF) <= (block[(i2 + 4)] & 0xFF))
/*      */                       break label874;
/*      */                   }
/*      */                 }
/*      */                 else {
/* 1543 */                   if ((block[(i1 + 3)] & 0xFF) <= (block[(i2 + 3)] & 0xFF))
/*      */                     break label874;
/*      */                 }
/*      */               }
/*      */               else {
/* 1548 */                 if ((block[(i1 + 2)] & 0xFF) <= (block[(i2 + 2)] & 0xFF))
/*      */                   break label874;
/*      */               }
/*      */             }
/*      */           }
/* 1553 */           while ((block[(i1 + 1)] & 0xFF) > (block[(i2 + 1)] & 0xFF));
/*      */ 
/* 1562 */           fmap[j] = v;
/*      */         }
/*      */ 
/* 1565 */         if ((firstAttemptShadow) && (i <= hi) && (workDoneShadow > workLimitShadow))
/*      */         {
/* 1567 */           break label911;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1572 */     label666: label682: label874: this.workDone = workDoneShadow;
/* 1573 */     label911: return (firstAttemptShadow) && (workDoneShadow > workLimitShadow);
/*      */   }
/*      */ 
/*      */   private static void vswap(int[] fmap, int p1, int p2, int n) {
/* 1577 */     n += p1;
/* 1578 */     while (p1 < n) {
/* 1579 */       int t = fmap[p1];
/* 1580 */       fmap[(p1++)] = fmap[p2];
/* 1581 */       fmap[(p2++)] = t;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static byte med3(byte a, byte b, byte c) {
/* 1586 */     return a > c ? c : b > c ? b : a < b ? a : a < c ? c : b < c ? b : a;
/*      */   }
/*      */ 
/*      */   private void blockSort()
/*      */   {
/* 1591 */     this.workLimit = (30 * this.last);
/* 1592 */     this.workDone = 0;
/* 1593 */     this.blockRandomised = false;
/* 1594 */     this.firstAttempt = true;
/* 1595 */     mainSort();
/*      */ 
/* 1597 */     if ((this.firstAttempt) && (this.workDone > this.workLimit)) {
/* 1598 */       randomiseBlock();
/* 1599 */       this.workLimit = (this.workDone = 0);
/* 1600 */       this.firstAttempt = false;
/* 1601 */       mainSort();
/*      */     }
/*      */ 
/* 1604 */     int[] fmap = this.data.fmap;
/* 1605 */     this.origPtr = -1;
/* 1606 */     int i = 0; for (int lastShadow = this.last; i <= lastShadow; i++)
/* 1607 */       if (fmap[i] == 0) {
/* 1608 */         this.origPtr = i;
/* 1609 */         break;
/*      */       }
/*      */   }
/*      */ 
/*      */   private void mainQSort3(Data dataShadow, int loSt, int hiSt, int dSt)
/*      */   {
/* 1621 */     int[] stack_ll = dataShadow.stack_ll;
/* 1622 */     int[] stack_hh = dataShadow.stack_hh;
/* 1623 */     int[] stack_dd = dataShadow.stack_dd;
/* 1624 */     int[] fmap = dataShadow.fmap;
/* 1625 */     byte[] block = dataShadow.block;
/*      */ 
/* 1627 */     stack_ll[0] = loSt;
/* 1628 */     stack_hh[0] = hiSt;
/* 1629 */     stack_dd[0] = dSt;
/*      */ 
/* 1631 */     int sp = 1;
/*      */     while (true) { sp--; if (sp < 0) break;
/* 1632 */       int lo = stack_ll[sp];
/* 1633 */       int hi = stack_hh[sp];
/* 1634 */       int d = stack_dd[sp];
/*      */ 
/* 1636 */       if ((hi - lo < 20) || (d > 10)) {
/* 1637 */         if (!mainSimpleSort(dataShadow, lo, hi, d));
/*      */       }
/*      */       else
/*      */       {
/* 1641 */         int d1 = d + 1;
/* 1642 */         int med = med3(block[(fmap[lo] + d1)], block[(fmap[hi] + d1)], block[(fmap[(lo + hi >>> 1)] + d1)]) & 0xFF;
/*      */ 
/* 1645 */         int unLo = lo;
/* 1646 */         int unHi = hi;
/* 1647 */         int ltLo = lo;
/* 1648 */         int gtHi = hi;
/*      */         while (true)
/*      */         {
/* 1651 */           if (unLo <= unHi) {
/* 1652 */             int n = (block[(fmap[unLo] + d1)] & 0xFF) - med;
/*      */ 
/* 1654 */             if (n == 0) {
/* 1655 */               int temp = fmap[unLo];
/* 1656 */               fmap[(unLo++)] = fmap[ltLo];
/* 1657 */               fmap[(ltLo++)] = temp; } else {
/* 1658 */               if (n >= 0) break label255;
/* 1659 */               unLo++;
/*      */             }
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/* 1665 */             label255: while (unLo <= unHi) {
/* 1666 */               int n = (block[(fmap[unHi] + d1)] & 0xFF) - med;
/*      */ 
/* 1668 */               if (n == 0) {
/* 1669 */                 int temp = fmap[unHi];
/* 1670 */                 fmap[(unHi--)] = fmap[gtHi];
/* 1671 */                 fmap[(gtHi--)] = temp; } else {
/* 1672 */                 if (n <= 0) break;
/* 1673 */                 unHi--;
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/* 1679 */             if (unLo > unHi) break;
/* 1680 */             int temp = fmap[unLo];
/* 1681 */             fmap[(unLo++)] = fmap[unHi];
/* 1682 */             fmap[(unHi--)] = temp;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1688 */         if (gtHi < ltLo) {
/* 1689 */           stack_ll[sp] = lo;
/* 1690 */           stack_hh[sp] = hi;
/* 1691 */           stack_dd[sp] = d1;
/* 1692 */           sp++;
/*      */         } else {
/* 1694 */           int n = ltLo - lo < unLo - ltLo ? ltLo - lo : unLo - ltLo;
/*      */ 
/* 1696 */           vswap(fmap, lo, unLo - n, n);
/* 1697 */           int m = hi - gtHi < gtHi - unHi ? hi - gtHi : gtHi - unHi;
/*      */ 
/* 1699 */           vswap(fmap, unLo, hi - m + 1, m);
/*      */ 
/* 1701 */           n = lo + unLo - ltLo - 1;
/* 1702 */           m = hi - (gtHi - unHi) + 1;
/*      */ 
/* 1704 */           stack_ll[sp] = lo;
/* 1705 */           stack_hh[sp] = n;
/* 1706 */           stack_dd[sp] = d;
/* 1707 */           sp++;
/*      */ 
/* 1709 */           stack_ll[sp] = (n + 1);
/* 1710 */           stack_hh[sp] = (m - 1);
/* 1711 */           stack_dd[sp] = d1;
/* 1712 */           sp++;
/*      */ 
/* 1714 */           stack_ll[sp] = m;
/* 1715 */           stack_hh[sp] = hi;
/* 1716 */           stack_dd[sp] = d;
/* 1717 */           sp++;
/*      */         }
/*      */       } }
/*      */   }
/*      */ 
/*      */   private void mainSort()
/*      */   {
/* 1724 */     Data dataShadow = this.data;
/* 1725 */     int[] runningOrder = dataShadow.mainSort_runningOrder;
/* 1726 */     int[] copy = dataShadow.mainSort_copy;
/* 1727 */     boolean[] bigDone = dataShadow.mainSort_bigDone;
/* 1728 */     int[] ftab = dataShadow.ftab;
/* 1729 */     byte[] block = dataShadow.block;
/* 1730 */     int[] fmap = dataShadow.fmap;
/* 1731 */     char[] quadrant = dataShadow.quadrant;
/* 1732 */     int lastShadow = this.last;
/* 1733 */     int workLimitShadow = this.workLimit;
/* 1734 */     boolean firstAttemptShadow = this.firstAttempt;
/*      */ 
/* 1737 */     int i = 65537;
/*      */     while (true) { i--; if (i < 0) break;
/* 1738 */       ftab[i] = 0;
/*      */     }
/*      */ 
/* 1746 */     for (int i = 0; i < 20; i++) {
/* 1747 */       block[(lastShadow + i + 2)] = block[(i % (lastShadow + 1) + 1)];
/*      */     }
/* 1749 */     int i = lastShadow + 20 + 1;
/*      */     while (true) { i--; if (i < 0) break;
/* 1750 */       quadrant[i] = '\000';
/*      */     }
/* 1752 */     block[0] = block[(lastShadow + 1)];
/*      */ 
/* 1756 */     int c1 = block[0] & 0xFF;
/* 1757 */     for (int i = 0; i <= lastShadow; i++) {
/* 1758 */       int c2 = block[(i + 1)] & 0xFF;
/* 1759 */       ftab[((c1 << 8) + c2)] += 1;
/* 1760 */       c1 = c2;
/*      */     }
/*      */ 
/* 1763 */     for (int i = 1; i <= 65536; i++) {
/* 1764 */       ftab[i] += ftab[(i - 1)];
/*      */     }
/* 1766 */     c1 = block[1] & 0xFF;
/* 1767 */     for (int i = 0; i < lastShadow; i++) {
/* 1768 */       int c2 = block[(i + 2)] & 0xFF;
/*      */       int tmp293_292 = ((c1 << 8) + c2);
/*      */       int[] tmp293_283 = ftab;
/*      */       int tmp297_296 = (tmp293_283[tmp293_292] - 1); tmp293_283[tmp293_292] = tmp297_296; fmap[tmp297_296] = i;
/* 1770 */       c1 = c2;
/*      */     }
/*      */     int tmp339_338 = (((block[(lastShadow + 1)] & 0xFF) << 8) + (block[1] & 0xFF));
/*      */     int[] tmp339_314 = ftab;
/*      */     int tmp343_342 = (tmp339_314[tmp339_338] - 1); tmp339_314[tmp339_338] = tmp343_342; fmap[tmp343_342] = lastShadow;
/*      */ 
/* 1779 */     int i = 256;
/*      */     while (true) { i--; if (i < 0) break;
/* 1780 */       bigDone[i] = false;
/* 1781 */       runningOrder[i] = i;
/*      */     }
/*      */ 
/* 1784 */     for (int h = 364; h != 1; ) {
/* 1785 */       h /= 3;
/* 1786 */       for (int i = h; i <= 255; i++) {
/* 1787 */         int vv = runningOrder[i];
/* 1788 */         int a = ftab[(vv + 1 << 8)] - ftab[(vv << 8)];
/* 1789 */         int b = h - 1;
/* 1790 */         int j = i;
/* 1791 */         for (int ro = runningOrder[(j - h)]; ftab[(ro + 1 << 8)] - ftab[(ro << 8)] > a; ro = runningOrder[(j - h)])
/*      */         {
/* 1793 */           runningOrder[j] = ro;
/* 1794 */           j -= h;
/* 1795 */           if (j <= b) {
/*      */             break;
/*      */           }
/*      */         }
/* 1799 */         runningOrder[j] = vv;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1806 */     for (int i = 0; i <= 255; i++)
/*      */     {
/* 1810 */       int ss = runningOrder[i];
/*      */ 
/* 1819 */       for (int j = 0; j <= 255; j++) {
/* 1820 */         int sb = (ss << 8) + j;
/* 1821 */         int ftab_sb = ftab[sb];
/* 1822 */         if ((ftab_sb & 0x200000) != 2097152) {
/* 1823 */           int lo = ftab_sb & 0xFFDFFFFF;
/* 1824 */           int hi = (ftab[(sb + 1)] & 0xFFDFFFFF) - 1;
/* 1825 */           if (hi > lo) {
/* 1826 */             mainQSort3(dataShadow, lo, hi, 2);
/* 1827 */             if ((firstAttemptShadow) && (this.workDone > workLimitShadow))
/*      */             {
/* 1829 */               return;
/*      */             }
/*      */           }
/* 1832 */           ftab[sb] = (ftab_sb | 0x200000);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1840 */       for (int j = 0; j <= 255; j++) {
/* 1841 */         copy[j] = (ftab[((j << 8) + ss)] & 0xFFDFFFFF);
/*      */       }
/*      */ 
/* 1844 */       int j = ftab[(ss << 8)] & 0xFFDFFFFF; for (int hj = ftab[(ss + 1 << 8)] & 0xFFDFFFFF; j < hj; j++) {
/* 1845 */         int fmap_j = fmap[j];
/* 1846 */         c1 = block[fmap_j] & 0xFF;
/* 1847 */         if (bigDone[c1] == 0) {
/* 1848 */           fmap[copy[c1]] = (fmap_j == 0 ? lastShadow : fmap_j - 1);
/* 1849 */           copy[c1] += 1;
/*      */         }
/*      */       }
/*      */ 
/* 1853 */       int j = 256;
/*      */       while (true) { j--; if (j < 0) break;
/* 1854 */         ftab[((j << 8) + ss)] |= 2097152;
/*      */       }
/*      */ 
/* 1864 */       bigDone[ss] = true;
/*      */ 
/* 1866 */       if (i < 255) {
/* 1867 */         int bbStart = ftab[(ss << 8)] & 0xFFDFFFFF;
/* 1868 */         int bbSize = (ftab[(ss + 1 << 8)] & 0xFFDFFFFF) - bbStart;
/* 1869 */         int shifts = 0;
/*      */ 
/* 1871 */         while (bbSize >> shifts > 65534) {
/* 1872 */           shifts++;
/*      */         }
/*      */ 
/* 1875 */         for (int j = 0; j < bbSize; j++) {
/* 1876 */           int a2update = fmap[(bbStart + j)];
/* 1877 */           char qVal = (char)(j >> shifts);
/* 1878 */           quadrant[a2update] = qVal;
/* 1879 */           if (a2update < 20)
/* 1880 */             quadrant[(a2update + lastShadow + 1)] = qVal;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void randomiseBlock()
/*      */   {
/* 1889 */     boolean[] inUse = this.data.inUse;
/* 1890 */     byte[] block = this.data.block;
/* 1891 */     int lastShadow = this.last;
/*      */ 
/* 1893 */     int i = 256;
/*      */     while (true) { i--; if (i < 0) break;
/* 1894 */       inUse[i] = false;
/*      */     }
/* 1896 */     int rNToGo = 0;
/* 1897 */     int rTPos = 0;
/* 1898 */     int i = 0; for (int j = 1; i <= lastShadow; j++) {
/* 1899 */       if (rNToGo == 0) {
/* 1900 */         rNToGo = (char)BZip2Constants.rNums[rTPos];
/* 1901 */         rTPos++; if (rTPos == 512) {
/* 1902 */           rTPos = 0;
/*      */         }
/*      */       }
/*      */ 
/* 1906 */       rNToGo--;
/*      */       int tmp94_92 = j;
/*      */       byte[] tmp94_91 = block; tmp94_91[tmp94_92] = (byte)(tmp94_91[tmp94_92] ^ (rNToGo == 1 ? 1 : 0));
/*      */ 
/* 1910 */       inUse[(block[j] & 0xFF)] = true;
/*      */ 
/* 1898 */       i = j;
/*      */     }
/*      */ 
/* 1913 */     this.blockRandomised = true;
/*      */   }
/*      */ 
/*      */   private void generateMTFValues() {
/* 1917 */     int lastShadow = this.last;
/* 1918 */     Data dataShadow = this.data;
/* 1919 */     boolean[] inUse = dataShadow.inUse;
/* 1920 */     byte[] block = dataShadow.block;
/* 1921 */     int[] fmap = dataShadow.fmap;
/* 1922 */     char[] sfmap = dataShadow.sfmap;
/* 1923 */     int[] mtfFreq = dataShadow.mtfFreq;
/* 1924 */     byte[] unseqToSeq = dataShadow.unseqToSeq;
/* 1925 */     byte[] yy = dataShadow.generateMTFValues_yy;
/*      */ 
/* 1928 */     int nInUseShadow = 0;
/* 1929 */     for (int i = 0; i < 256; i++) {
/* 1930 */       if (inUse[i] != 0) {
/* 1931 */         unseqToSeq[i] = (byte)nInUseShadow;
/* 1932 */         nInUseShadow++;
/*      */       }
/*      */     }
/* 1935 */     this.nInUse = nInUseShadow;
/*      */ 
/* 1937 */     int eob = nInUseShadow + 1;
/*      */ 
/* 1939 */     for (int i = eob; i >= 0; i--) {
/* 1940 */       mtfFreq[i] = 0;
/*      */     }
/*      */ 
/* 1943 */     int i = nInUseShadow;
/*      */     while (true) { i--; if (i < 0) break;
/* 1944 */       yy[i] = (byte)i;
/*      */     }
/*      */ 
/* 1947 */     int wr = 0;
/* 1948 */     int zPend = 0;
/*      */ 
/* 1950 */     for (int i = 0; i <= lastShadow; i++) {
/* 1951 */       byte ll_i = unseqToSeq[(block[fmap[i]] & 0xFF)];
/* 1952 */       byte tmp = yy[0];
/* 1953 */       int j = 0;
/*      */ 
/* 1955 */       while (ll_i != tmp) {
/* 1956 */         j++;
/* 1957 */         byte tmp2 = tmp;
/* 1958 */         tmp = yy[j];
/* 1959 */         yy[j] = tmp2;
/*      */       }
/* 1961 */       yy[0] = tmp;
/*      */ 
/* 1963 */       if (j == 0) {
/* 1964 */         zPend++;
/*      */       } else {
/* 1966 */         if (zPend > 0) {
/* 1967 */           zPend--;
/*      */           while (true) {
/* 1969 */             if ((zPend & 0x1) == 0) {
/* 1970 */               sfmap[wr] = '\000';
/* 1971 */               wr++;
/* 1972 */               mtfFreq[0] += 1;
/*      */             } else {
/* 1974 */               sfmap[wr] = '\001';
/* 1975 */               wr++;
/* 1976 */               mtfFreq[1] += 1;
/*      */             }
/*      */ 
/* 1979 */             if (zPend < 2) break;
/* 1980 */             zPend = zPend - 2 >> 1;
/*      */           }
/*      */ 
/* 1985 */           zPend = 0;
/*      */         }
/* 1987 */         sfmap[wr] = (char)(j + 1);
/* 1988 */         wr++;
/* 1989 */         mtfFreq[(j + 1)] += 1;
/*      */       }
/*      */     }
/*      */ 
/* 1993 */     if (zPend > 0) {
/* 1994 */       zPend--;
/*      */       while (true) {
/* 1996 */         if ((zPend & 0x1) == 0) {
/* 1997 */           sfmap[wr] = '\000';
/* 1998 */           wr++;
/* 1999 */           mtfFreq[0] += 1;
/*      */         } else {
/* 2001 */           sfmap[wr] = '\001';
/* 2002 */           wr++;
/* 2003 */           mtfFreq[1] += 1;
/*      */         }
/*      */ 
/* 2006 */         if (zPend < 2) break;
/* 2007 */         zPend = zPend - 2 >> 1;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2014 */     sfmap[wr] = (char)eob;
/* 2015 */     mtfFreq[eob] += 1;
/* 2016 */     this.nMTF = (wr + 1); } 
/* 2022 */   private static final class Data { final boolean[] inUse = new boolean[256];
/* 2023 */     final byte[] unseqToSeq = new byte[256];
/* 2024 */     final int[] mtfFreq = new int[258];
/* 2025 */     final byte[] selector = new byte[18002];
/* 2026 */     final byte[] selectorMtf = new byte[18002];
/*      */ 
/* 2028 */     final byte[] generateMTFValues_yy = new byte[256];
/* 2029 */     final byte[][] sendMTFValues_len = new byte[6][258];
/*      */ 
/* 2031 */     final int[][] sendMTFValues_rfreq = new int[6][258];
/*      */ 
/* 2033 */     final int[] sendMTFValues_fave = new int[6];
/* 2034 */     final short[] sendMTFValues_cost = new short[6];
/* 2035 */     final int[][] sendMTFValues_code = new int[6][258];
/*      */ 
/* 2037 */     final byte[] sendMTFValues2_pos = new byte[6];
/* 2038 */     final boolean[] sentMTFValues4_inUse16 = new boolean[16];
/*      */ 
/* 2040 */     final int[] stack_ll = new int[1000];
/* 2041 */     final int[] stack_hh = new int[1000];
/* 2042 */     final int[] stack_dd = new int[1000];
/*      */ 
/* 2044 */     final int[] mainSort_runningOrder = new int[256];
/* 2045 */     final int[] mainSort_copy = new int[256];
/* 2046 */     final boolean[] mainSort_bigDone = new boolean[256];
/*      */ 
/* 2048 */     final int[] heap = new int[260];
/* 2049 */     final int[] weight = new int[516];
/* 2050 */     final int[] parent = new int[516];
/*      */ 
/* 2052 */     final int[] ftab = new int[65537];
/*      */     final byte[] block;
/*      */     final int[] fmap;
/*      */     final char[] sfmap;
/*      */     final char[] quadrant;
/*      */ 
/* 2072 */     Data(int blockSize100k) { int n = blockSize100k * 100000;
/* 2073 */       this.block = new byte[n + 1 + 20];
/* 2074 */       this.fmap = new int[n];
/* 2075 */       this.sfmap = new char[2 * n];
/* 2076 */       this.quadrant = this.sfmap;
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.bzip2.CBZip2OutputStream
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.io.compress.zlib;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.io.compress.Compressor;
/*     */ import org.apache.hadoop.util.NativeCodeLoader;
/*     */ import org.mortbay.log.Log;
/*     */ 
/*     */ public class ZlibCompressor
/*     */   implements Compressor
/*     */ {
/*     */   private static final int DEFAULT_DIRECT_BUFFER_SIZE = 65536;
/*  40 */   private static Class clazz = ZlibCompressor.class;
/*     */   private long stream;
/*     */   private CompressionLevel level;
/*     */   private CompressionStrategy strategy;
/*     */   private final CompressionHeader windowBits;
/*     */   private int directBufferSize;
/*  47 */   private byte[] userBuf = null;
/*  48 */   private int userBufOff = 0; private int userBufLen = 0;
/*  49 */   private Buffer uncompressedDirectBuf = null;
/*  50 */   private int uncompressedDirectBufOff = 0; private int uncompressedDirectBufLen = 0;
/*  51 */   private Buffer compressedDirectBuf = null;
/*     */   private boolean finish;
/*     */   private boolean finished;
/* 165 */   private static boolean nativeZlibLoaded = false;
/*     */ 
/*     */   static boolean isNativeZlibLoaded()
/*     */   {
/* 180 */     return nativeZlibLoaded;
/*     */   }
/*     */ 
/*     */   protected final void construct(CompressionLevel level, CompressionStrategy strategy, CompressionHeader header, int directBufferSize)
/*     */   {
/*     */   }
/*     */ 
/*     */   public ZlibCompressor()
/*     */   {
/* 192 */     this(CompressionLevel.DEFAULT_COMPRESSION, CompressionStrategy.DEFAULT_STRATEGY, CompressionHeader.DEFAULT_HEADER, 65536);
/*     */   }
/*     */ 
/*     */   public ZlibCompressor(Configuration conf)
/*     */   {
/* 202 */     this(ZlibFactory.getCompressionLevel(conf), ZlibFactory.getCompressionStrategy(conf), CompressionHeader.DEFAULT_HEADER, 65536);
/*     */   }
/*     */ 
/*     */   public ZlibCompressor(CompressionLevel level, CompressionStrategy strategy, CompressionHeader header, int directBufferSize)
/*     */   {
/* 219 */     this.level = level;
/* 220 */     this.strategy = strategy;
/* 221 */     this.windowBits = header;
/* 222 */     this.stream = init(this.level.compressionLevel(), this.strategy.compressionStrategy(), this.windowBits.windowBits());
/*     */ 
/* 226 */     this.directBufferSize = directBufferSize;
/* 227 */     this.uncompressedDirectBuf = ByteBuffer.allocateDirect(directBufferSize);
/* 228 */     this.compressedDirectBuf = ByteBuffer.allocateDirect(directBufferSize);
/* 229 */     this.compressedDirectBuf.position(directBufferSize);
/*     */   }
/*     */ 
/*     */   public synchronized void reinit(Configuration conf)
/*     */   {
/* 241 */     reset();
/* 242 */     if (conf == null) {
/* 243 */       return;
/*     */     }
/* 245 */     end(this.stream);
/* 246 */     this.level = ZlibFactory.getCompressionLevel(conf);
/* 247 */     this.strategy = ZlibFactory.getCompressionStrategy(conf);
/* 248 */     this.stream = init(this.level.compressionLevel(), this.strategy.compressionStrategy(), this.windowBits.windowBits());
/*     */ 
/* 251 */     Log.debug("Reinit compressor with new compression configuration");
/*     */   }
/*     */ 
/*     */   public synchronized void setInput(byte[] b, int off, int len) {
/* 255 */     if (b == null) {
/* 256 */       throw new NullPointerException();
/*     */     }
/* 258 */     if ((off < 0) || (len < 0) || (off > b.length - len)) {
/* 259 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/*     */ 
/* 262 */     this.userBuf = b;
/* 263 */     this.userBufOff = off;
/* 264 */     this.userBufLen = len;
/* 265 */     setInputFromSavedData();
/*     */ 
/* 268 */     this.compressedDirectBuf.limit(this.directBufferSize);
/* 269 */     this.compressedDirectBuf.position(this.directBufferSize);
/*     */   }
/*     */ 
/*     */   synchronized void setInputFromSavedData() {
/* 273 */     this.uncompressedDirectBufOff = 0;
/* 274 */     this.uncompressedDirectBufLen = this.userBufLen;
/* 275 */     if (this.uncompressedDirectBufLen > this.directBufferSize) {
/* 276 */       this.uncompressedDirectBufLen = this.directBufferSize;
/*     */     }
/*     */ 
/* 280 */     this.uncompressedDirectBuf.rewind();
/* 281 */     ((ByteBuffer)this.uncompressedDirectBuf).put(this.userBuf, this.userBufOff, this.uncompressedDirectBufLen);
/*     */ 
/* 285 */     this.userBufOff += this.uncompressedDirectBufLen;
/* 286 */     this.userBufLen -= this.uncompressedDirectBufLen;
/*     */   }
/*     */ 
/*     */   public synchronized void setDictionary(byte[] b, int off, int len) {
/* 290 */     if ((this.stream == 0L) || (b == null)) {
/* 291 */       throw new NullPointerException();
/*     */     }
/* 293 */     if ((off < 0) || (len < 0) || (off > b.length - len)) {
/* 294 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/* 296 */     setDictionary(this.stream, b, off, len);
/*     */   }
/*     */ 
/*     */   public boolean needsInput()
/*     */   {
/* 301 */     if (this.compressedDirectBuf.remaining() > 0) {
/* 302 */       return false;
/*     */     }
/*     */ 
/* 306 */     if (this.uncompressedDirectBufLen <= 0)
/*     */     {
/* 308 */       if (this.userBufLen <= 0) {
/* 309 */         return true;
/*     */       }
/* 311 */       setInputFromSavedData();
/*     */     }
/*     */ 
/* 315 */     return false;
/*     */   }
/*     */ 
/*     */   public synchronized void finish() {
/* 319 */     this.finish = true;
/*     */   }
/*     */ 
/*     */   public synchronized boolean finished()
/*     */   {
/* 325 */     return (this.finished) && (this.compressedDirectBuf.remaining() == 0);
/*     */   }
/*     */ 
/*     */   public synchronized int compress(byte[] b, int off, int len) throws IOException
/*     */   {
/* 330 */     if (b == null) {
/* 331 */       throw new NullPointerException();
/*     */     }
/* 333 */     if ((off < 0) || (len < 0) || (off > b.length - len)) {
/* 334 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/*     */ 
/* 337 */     int n = 0;
/*     */ 
/* 340 */     n = this.compressedDirectBuf.remaining();
/* 341 */     if (n > 0) {
/* 342 */       n = Math.min(n, len);
/* 343 */       ((ByteBuffer)this.compressedDirectBuf).get(b, off, n);
/* 344 */       return n;
/*     */     }
/*     */ 
/* 348 */     this.compressedDirectBuf.rewind();
/* 349 */     this.compressedDirectBuf.limit(this.directBufferSize);
/*     */ 
/* 352 */     n = deflateBytesDirect();
/* 353 */     this.compressedDirectBuf.limit(n);
/*     */ 
/* 356 */     n = Math.min(n, len);
/* 357 */     ((ByteBuffer)this.compressedDirectBuf).get(b, off, n);
/*     */ 
/* 359 */     return n;
/*     */   }
/*     */ 
/*     */   public synchronized long getBytesWritten()
/*     */   {
/* 368 */     checkStream();
/* 369 */     return getBytesWritten(this.stream);
/*     */   }
/*     */ 
/*     */   public synchronized long getBytesRead()
/*     */   {
/* 378 */     checkStream();
/* 379 */     return getBytesRead(this.stream);
/*     */   }
/*     */ 
/*     */   public synchronized void reset() {
/* 383 */     checkStream();
/* 384 */     reset(this.stream);
/* 385 */     this.finish = false;
/* 386 */     this.finished = false;
/* 387 */     this.uncompressedDirectBuf.rewind();
/* 388 */     this.uncompressedDirectBufOff = (this.uncompressedDirectBufLen = 0);
/* 389 */     this.compressedDirectBuf.limit(this.directBufferSize);
/* 390 */     this.compressedDirectBuf.position(this.directBufferSize);
/* 391 */     this.userBufOff = (this.userBufLen = 0);
/*     */   }
/*     */ 
/*     */   public synchronized void end() {
/* 395 */     if (this.stream != 0L) {
/* 396 */       end(this.stream);
/* 397 */       this.stream = 0L;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkStream() {
/* 402 */     if (this.stream == 0L)
/* 403 */       throw new NullPointerException();
/*     */   }
/*     */ 
/*     */   private static native void initIDs();
/*     */ 
/*     */   private static native long init(int paramInt1, int paramInt2, int paramInt3);
/*     */ 
/*     */   private static native void setDictionary(long paramLong, byte[] paramArrayOfByte, int paramInt1, int paramInt2);
/*     */ 
/*     */   private native int deflateBytesDirect();
/*     */ 
/*     */   private static native long getBytesRead(long paramLong);
/*     */ 
/*     */   private static native long getBytesWritten(long paramLong);
/*     */ 
/*     */   private static native void reset(long paramLong);
/*     */ 
/*     */   private static native void end(long paramLong);
/*     */ 
/*     */   static
/*     */   {
/* 168 */     if (NativeCodeLoader.isNativeCodeLoaded())
/*     */       try
/*     */       {
/* 171 */         initIDs();
/* 172 */         nativeZlibLoaded = true;
/*     */       }
/*     */       catch (Throwable t)
/*     */       {
/*     */       }
/*     */   }
/*     */ 
/*     */   public static enum CompressionHeader
/*     */   {
/* 142 */     NO_HEADER(-15), 
/*     */ 
/* 147 */     DEFAULT_HEADER(15), 
/*     */ 
/* 152 */     GZIP_FORMAT(31);
/*     */ 
/*     */     private final int windowBits;
/*     */ 
/*     */     private CompressionHeader(int windowBits) {
/* 157 */       this.windowBits = windowBits;
/*     */     }
/*     */ 
/*     */     public int windowBits() {
/* 161 */       return this.windowBits;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static enum CompressionStrategy
/*     */   {
/*  99 */     FILTERED(1), 
/*     */ 
/* 104 */     HUFFMAN_ONLY(2), 
/*     */ 
/* 110 */     RLE(3), 
/*     */ 
/* 116 */     FIXED(4), 
/*     */ 
/* 121 */     DEFAULT_STRATEGY(0);
/*     */ 
/*     */     private final int compressionStrategy;
/*     */ 
/*     */     private CompressionStrategy(int strategy)
/*     */     {
/* 127 */       this.compressionStrategy = strategy;
/*     */     }
/*     */ 
/*     */     int compressionStrategy() {
/* 131 */       return this.compressionStrategy;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static enum CompressionLevel
/*     */   {
/*  61 */     NO_COMPRESSION(0), 
/*     */ 
/*  66 */     BEST_SPEED(1), 
/*     */ 
/*  71 */     BEST_COMPRESSION(9), 
/*     */ 
/*  76 */     DEFAULT_COMPRESSION(-1);
/*     */ 
/*     */     private final int compressionLevel;
/*     */ 
/*     */     private CompressionLevel(int level)
/*     */     {
/*  82 */       this.compressionLevel = level;
/*     */     }
/*     */ 
/*     */     int compressionLevel() {
/*  86 */       return this.compressionLevel;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.compress.zlib.ZlibCompressor
 * JD-Core Version:    0.6.1
 */
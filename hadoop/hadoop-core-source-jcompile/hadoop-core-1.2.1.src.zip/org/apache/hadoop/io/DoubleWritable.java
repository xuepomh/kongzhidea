/*    */ package org.apache.hadoop.io;
/*    */ 
/*    */ import java.io.DataInput;
/*    */ import java.io.DataOutput;
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class DoubleWritable
/*    */   implements WritableComparable
/*    */ {
/* 30 */   private double value = 0.0D;
/*    */ 
/*    */   public DoubleWritable()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DoubleWritable(double value) {
/* 37 */     set(value);
/*    */   }
/*    */ 
/*    */   public void readFields(DataInput in) throws IOException {
/* 41 */     this.value = in.readDouble();
/*    */   }
/*    */ 
/*    */   public void write(DataOutput out) throws IOException {
/* 45 */     out.writeDouble(this.value);
/*    */   }
/*    */   public void set(double value) {
/* 48 */     this.value = value;
/*    */   }
/* 50 */   public double get() { return this.value; }
/*    */ 
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 56 */     if (!(o instanceof DoubleWritable)) {
/* 57 */       return false;
/*    */     }
/* 59 */     DoubleWritable other = (DoubleWritable)o;
/* 60 */     return this.value == other.value;
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 64 */     return (int)Double.doubleToLongBits(this.value);
/*    */   }
/*    */ 
/*    */   public int compareTo(Object o) {
/* 68 */     DoubleWritable other = (DoubleWritable)o;
/* 69 */     return this.value == other.value ? 0 : this.value < other.value ? -1 : 1;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 73 */     return Double.toString(this.value);
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 91 */     WritableComparator.define(DoubleWritable.class, new Comparator());
/*    */   }
/*    */ 
/*    */   public static class Comparator extends WritableComparator
/*    */   {
/*    */     public Comparator()
/*    */     {
/* 79 */       super();
/*    */     }
/*    */ 
/*    */     public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2)
/*    */     {
/* 84 */       double thisValue = readDouble(b1, s1);
/* 85 */       double thatValue = readDouble(b2, s2);
/* 86 */       return thisValue == thatValue ? 0 : thisValue < thatValue ? -1 : 1;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.DoubleWritable
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.io;
/*    */ 
/*    */ import java.io.DataInput;
/*    */ import java.io.DataOutput;
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class FloatWritable
/*    */   implements WritableComparable
/*    */ {
/*    */   private float value;
/*    */ 
/*    */   public FloatWritable()
/*    */   {
/*    */   }
/*    */ 
/*    */   public FloatWritable(float value)
/*    */   {
/* 29 */     set(value);
/*    */   }
/*    */   public void set(float value) {
/* 32 */     this.value = value;
/*    */   }
/*    */   public float get() {
/* 35 */     return this.value;
/*    */   }
/*    */   public void readFields(DataInput in) throws IOException {
/* 38 */     this.value = in.readFloat();
/*    */   }
/*    */ 
/*    */   public void write(DataOutput out) throws IOException {
/* 42 */     out.writeFloat(this.value);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 47 */     if (!(o instanceof FloatWritable))
/* 48 */       return false;
/* 49 */     FloatWritable other = (FloatWritable)o;
/* 50 */     return this.value == other.value;
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 54 */     return Float.floatToIntBits(this.value);
/*    */   }
/*    */ 
/*    */   public int compareTo(Object o)
/*    */   {
/* 59 */     float thisValue = this.value;
/* 60 */     float thatValue = ((FloatWritable)o).value;
/* 61 */     return thisValue == thatValue ? 0 : thisValue < thatValue ? -1 : 1;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 65 */     return Float.toString(this.value);
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 83 */     WritableComparator.define(FloatWritable.class, new Comparator());
/*    */   }
/*    */ 
/*    */   public static class Comparator extends WritableComparator
/*    */   {
/*    */     public Comparator()
/*    */     {
/* 71 */       super();
/*    */     }
/*    */ 
/*    */     public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2)
/*    */     {
/* 76 */       float thisValue = readFloat(b1, s1);
/* 77 */       float thatValue = readFloat(b2, s2);
/* 78 */       return thisValue == thatValue ? 0 : thisValue < thatValue ? -1 : 1;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.FloatWritable
 * JD-Core Version:    0.6.1
 */
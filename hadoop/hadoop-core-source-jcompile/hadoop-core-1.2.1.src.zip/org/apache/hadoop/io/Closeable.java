package org.apache.hadoop.io;

@Deprecated
public abstract interface Closeable extends java.io.Closeable
{
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.Closeable
 * JD-Core Version:    0.6.1
 */
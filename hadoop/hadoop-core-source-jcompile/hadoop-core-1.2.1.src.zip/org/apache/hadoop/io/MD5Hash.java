/*     */ package org.apache.hadoop.io;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ public class MD5Hash
/*     */   implements WritableComparable<MD5Hash>
/*     */ {
/*     */   public static final int MD5_LEN = 16;
/*  33 */   private static ThreadLocal<MessageDigest> DIGESTER_FACTORY = new ThreadLocal() {
/*     */     protected MessageDigest initialValue() {
/*     */       try {
/*  36 */         return MessageDigest.getInstance("MD5");
/*     */       } catch (NoSuchAlgorithmException e) {
/*  38 */         throw new RuntimeException(e);
/*     */       }
/*     */     }
/*  33 */   };
/*     */   private byte[] digest;
/* 188 */   private static final char[] HEX_DIGITS = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
/*     */ 
/*     */   public MD5Hash()
/*     */   {
/*  47 */     this.digest = new byte[16];
/*     */   }
/*     */ 
/*     */   public MD5Hash(String hex)
/*     */   {
/*  52 */     setDigest(hex);
/*     */   }
/*     */ 
/*     */   public MD5Hash(byte[] digest)
/*     */   {
/*  57 */     if (digest.length != 16)
/*  58 */       throw new IllegalArgumentException("Wrong length: " + digest.length);
/*  59 */     this.digest = digest;
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException
/*     */   {
/*  64 */     in.readFully(this.digest);
/*     */   }
/*     */ 
/*     */   public static MD5Hash read(DataInput in) throws IOException
/*     */   {
/*  69 */     MD5Hash result = new MD5Hash();
/*  70 */     result.readFields(in);
/*  71 */     return result;
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out) throws IOException
/*     */   {
/*  76 */     out.write(this.digest);
/*     */   }
/*     */ 
/*     */   public void set(MD5Hash that)
/*     */   {
/*  81 */     System.arraycopy(that.digest, 0, this.digest, 0, 16);
/*     */   }
/*     */ 
/*     */   public byte[] getDigest() {
/*  85 */     return this.digest;
/*     */   }
/*     */ 
/*     */   public static MD5Hash digest(byte[] data) {
/*  89 */     return digest(data, 0, data.length);
/*     */   }
/*     */ 
/*     */   public static MessageDigest getDigester()
/*     */   {
/*  96 */     return (MessageDigest)DIGESTER_FACTORY.get();
/*     */   }
/*     */ 
/*     */   public static MD5Hash digest(InputStream in) throws IOException
/*     */   {
/* 101 */     byte[] buffer = new byte[4096];
/*     */ 
/* 103 */     MessageDigest digester = getDigester();
/*     */     int n;
/* 104 */     while ((n = in.read(buffer)) != -1) {
/* 105 */       digester.update(buffer, 0, n);
/*     */     }
/*     */ 
/* 108 */     return new MD5Hash(digester.digest());
/*     */   }
/*     */ 
/*     */   public static MD5Hash digest(byte[] data, int start, int len)
/*     */   {
/* 114 */     MessageDigest digester = getDigester();
/* 115 */     digester.update(data, start, len);
/* 116 */     byte[] digest = digester.digest();
/* 117 */     return new MD5Hash(digest);
/*     */   }
/*     */ 
/*     */   public static MD5Hash digest(String string)
/*     */   {
/* 122 */     return digest(UTF8.getBytes(string));
/*     */   }
/*     */ 
/*     */   public static MD5Hash digest(UTF8 utf8)
/*     */   {
/* 127 */     return digest(utf8.getBytes(), 0, utf8.getLength());
/*     */   }
/*     */ 
/*     */   public long halfDigest()
/*     */   {
/* 132 */     long value = 0L;
/* 133 */     for (int i = 0; i < 8; i++)
/* 134 */       value |= (this.digest[i] & 0xFF) << 8 * (7 - i);
/* 135 */     return value;
/*     */   }
/*     */ 
/*     */   public int quarterDigest()
/*     */   {
/* 143 */     int value = 0;
/* 144 */     for (int i = 0; i < 4; i++)
/* 145 */       value |= (this.digest[i] & 0xFF) << 8 * (3 - i);
/* 146 */     return value;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 152 */     if (!(o instanceof MD5Hash))
/* 153 */       return false;
/* 154 */     MD5Hash other = (MD5Hash)o;
/* 155 */     return Arrays.equals(this.digest, other.digest);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 162 */     return quarterDigest();
/*     */   }
/*     */ 
/*     */   public int compareTo(MD5Hash that)
/*     */   {
/* 168 */     return WritableComparator.compareBytes(this.digest, 0, 16, that.digest, 0, 16);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 193 */     StringBuffer buf = new StringBuffer(32);
/* 194 */     for (int i = 0; i < 16; i++) {
/* 195 */       int b = this.digest[i];
/* 196 */       buf.append(HEX_DIGITS[(b >> 4 & 0xF)]);
/* 197 */       buf.append(HEX_DIGITS[(b & 0xF)]);
/*     */     }
/* 199 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   public void setDigest(String hex)
/*     */   {
/* 204 */     if (hex.length() != 32)
/* 205 */       throw new IllegalArgumentException("Wrong length: " + hex.length());
/* 206 */     byte[] digest = new byte[16];
/* 207 */     for (int i = 0; i < 16; i++) {
/* 208 */       int j = i << 1;
/* 209 */       digest[i] = (byte)(charToNibble(hex.charAt(j)) << 4 | charToNibble(hex.charAt(j + 1)));
/*     */     }
/*     */ 
/* 212 */     this.digest = digest;
/*     */   }
/*     */ 
/*     */   private static final int charToNibble(char c) {
/* 216 */     if ((c >= '0') && (c <= '9'))
/* 217 */       return c - '0';
/* 218 */     if ((c >= 'a') && (c <= 'f'))
/* 219 */       return 10 + (c - 'a');
/* 220 */     if ((c >= 'A') && (c <= 'F')) {
/* 221 */       return 10 + (c - 'A');
/*     */     }
/* 223 */     throw new RuntimeException("Not a hex character: " + c);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 185 */     WritableComparator.define(MD5Hash.class, new Comparator());
/*     */   }
/*     */ 
/*     */   public static class Comparator extends WritableComparator
/*     */   {
/*     */     public Comparator()
/*     */     {
/* 175 */       super();
/*     */     }
/*     */ 
/*     */     public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2)
/*     */     {
/* 180 */       return compareBytes(b1, s1, 16, b2, s2, 16);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.MD5Hash
 * JD-Core Version:    0.6.1
 */
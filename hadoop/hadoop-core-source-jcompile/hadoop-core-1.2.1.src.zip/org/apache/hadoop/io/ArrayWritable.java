/*    */ package org.apache.hadoop.io;
/*    */ 
/*    */ import java.io.DataInput;
/*    */ import java.io.DataOutput;
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Array;
/*    */ 
/*    */ public class ArrayWritable
/*    */   implements Writable
/*    */ {
/*    */   private Class<? extends Writable> valueClass;
/*    */   private Writable[] values;
/*    */ 
/*    */   public ArrayWritable(Class<? extends Writable> valueClass)
/*    */   {
/* 44 */     if (valueClass == null) {
/* 45 */       throw new IllegalArgumentException("null valueClass");
/*    */     }
/* 47 */     this.valueClass = valueClass;
/*    */   }
/*    */ 
/*    */   public ArrayWritable(Class<? extends Writable> valueClass, Writable[] values) {
/* 51 */     this(valueClass);
/* 52 */     this.values = values;
/*    */   }
/*    */ 
/*    */   public ArrayWritable(String[] strings) {
/* 56 */     this(UTF8.class, new Writable[strings.length]);
/* 57 */     for (int i = 0; i < strings.length; i++)
/* 58 */       this.values[i] = new UTF8(strings[i]);
/*    */   }
/*    */ 
/*    */   public Class getValueClass()
/*    */   {
/* 63 */     return this.valueClass;
/*    */   }
/*    */ 
/*    */   public String[] toStrings() {
/* 67 */     String[] strings = new String[this.values.length];
/* 68 */     for (int i = 0; i < this.values.length; i++) {
/* 69 */       strings[i] = this.values[i].toString();
/*    */     }
/* 71 */     return strings;
/*    */   }
/*    */ 
/*    */   public Object toArray() {
/* 75 */     Object result = Array.newInstance(this.valueClass, this.values.length);
/* 76 */     for (int i = 0; i < this.values.length; i++) {
/* 77 */       Array.set(result, i, this.values[i]);
/*    */     }
/* 79 */     return result;
/*    */   }
/*    */   public void set(Writable[] values) {
/* 82 */     this.values = values;
/*    */   }
/* 84 */   public Writable[] get() { return this.values; }
/*    */ 
/*    */   public void readFields(DataInput in) throws IOException {
/* 87 */     this.values = new Writable[in.readInt()];
/* 88 */     for (int i = 0; i < this.values.length; i++) {
/* 89 */       Writable value = WritableFactories.newInstance(this.valueClass);
/* 90 */       value.readFields(in);
/* 91 */       this.values[i] = value;
/*    */     }
/*    */   }
/*    */ 
/*    */   public void write(DataOutput out) throws IOException {
/* 96 */     out.writeInt(this.values.length);
/* 97 */     for (int i = 0; i < this.values.length; i++)
/* 98 */       this.values[i].write(out);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.ArrayWritable
 * JD-Core Version:    0.6.1
 */
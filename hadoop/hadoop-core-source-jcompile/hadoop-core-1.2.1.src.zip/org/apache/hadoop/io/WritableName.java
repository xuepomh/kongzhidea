/*    */ package org.apache.hadoop.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.HashMap;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ 
/*    */ public class WritableName
/*    */ {
/* 30 */   private static HashMap<String, Class<?>> NAME_TO_CLASS = new HashMap();
/*    */ 
/* 32 */   private static HashMap<Class<?>, String> CLASS_TO_NAME = new HashMap();
/*    */ 
/*    */   public static synchronized void setName(Class writableClass, String name)
/*    */   {
/* 47 */     CLASS_TO_NAME.put(writableClass, name);
/* 48 */     NAME_TO_CLASS.put(name, writableClass);
/*    */   }
/*    */ 
/*    */   public static synchronized void addName(Class writableClass, String name)
/*    */   {
/* 53 */     NAME_TO_CLASS.put(name, writableClass);
/*    */   }
/*    */ 
/*    */   public static synchronized String getName(Class writableClass)
/*    */   {
/* 58 */     String name = (String)CLASS_TO_NAME.get(writableClass);
/* 59 */     if (name != null)
/* 60 */       return name;
/* 61 */     return writableClass.getName();
/*    */   }
/*    */ 
/*    */   public static synchronized Class<?> getClass(String name, Configuration conf)
/*    */     throws IOException
/*    */   {
/* 67 */     Class writableClass = (Class)NAME_TO_CLASS.get(name);
/* 68 */     if (writableClass != null)
/* 69 */       return writableClass.asSubclass(Writable.class);
/*    */     try {
/* 71 */       return conf.getClassByName(name);
/*    */     } catch (ClassNotFoundException e) {
/* 73 */       IOException newE = new IOException("WritableName can't load class: " + name);
/* 74 */       newE.initCause(e);
/* 75 */       throw newE;
/*    */     }
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 36 */     setName(NullWritable.class, "null");
/* 37 */     setName(LongWritable.class, "long");
/* 38 */     setName(UTF8.class, "UTF8");
/* 39 */     setName(MD5Hash.class, "MD5Hash");
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.WritableName
 * JD-Core Version:    0.6.1
 */
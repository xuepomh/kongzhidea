/*    */ package org.apache.hadoop.io;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.FilterInputStream;
/*    */ 
/*    */ public class InputBuffer extends FilterInputStream
/*    */ {
/*    */   private Buffer buffer;
/*    */ 
/*    */   public InputBuffer()
/*    */   {
/* 65 */     this(new Buffer());
/*    */   }
/*    */ 
/*    */   private InputBuffer(Buffer buffer) {
/* 69 */     super(buffer);
/* 70 */     this.buffer = buffer;
/*    */   }
/*    */ 
/*    */   public void reset(byte[] input, int length)
/*    */   {
/* 75 */     this.buffer.reset(input, 0, length);
/*    */   }
/*    */ 
/*    */   public void reset(byte[] input, int start, int length)
/*    */   {
/* 80 */     this.buffer.reset(input, start, length);
/*    */   }
/*    */ 
/*    */   public int getPosition() {
/* 84 */     return this.buffer.getPosition();
/*    */   }
/*    */   public int getLength() {
/* 87 */     return this.buffer.getLength();
/*    */   }
/*    */ 
/*    */   private static class Buffer extends ByteArrayInputStream
/*    */   {
/*    */     public Buffer()
/*    */     {
/* 47 */       super();
/*    */     }
/*    */ 
/*    */     public void reset(byte[] input, int start, int length) {
/* 51 */       this.buf = input;
/* 52 */       this.count = (start + length);
/* 53 */       this.mark = start;
/* 54 */       this.pos = start;
/*    */     }
/*    */     public int getPosition() {
/* 57 */       return this.pos; } 
/* 58 */     public int getLength() { return this.count; }
/*    */ 
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.InputBuffer
 * JD-Core Version:    0.6.1
 */
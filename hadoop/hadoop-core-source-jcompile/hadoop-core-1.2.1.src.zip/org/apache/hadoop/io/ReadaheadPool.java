/*     */ package org.apache.hadoop.io;
/*     */ 
/*     */ import java.io.FileDescriptor;
/*     */ import java.io.IOException;
/*     */ import java.util.concurrent.ArrayBlockingQueue;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.ThreadPoolExecutor.DiscardOldestPolicy;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.classification.InterfaceAudience.Private;
/*     */ import org.apache.hadoop.classification.InterfaceStability.Evolving;
/*     */ import org.apache.hadoop.io.nativeio.NativeIO;
/*     */ 
/*     */ @InterfaceAudience.Private
/*     */ @InterfaceStability.Evolving
/*     */ public class ReadaheadPool
/*     */ {
/*  41 */   static final Log LOG = LogFactory.getLog(ReadaheadPool.class);
/*     */   private static final int POOL_SIZE = 4;
/*     */   private static final int MAX_POOL_SIZE = 16;
/*     */   private static final int CAPACITY = 1024;
/*     */   private final ThreadPoolExecutor pool;
/*     */   private static ReadaheadPool instance;
/*  48 */   private static AtomicLong THREAD_COUNTER = new AtomicLong(0L);
/*     */ 
/*     */   public static ReadaheadPool getInstance()
/*     */   {
/*  54 */     synchronized (ReadaheadPool.class) {
/*  55 */       if ((instance == null) && (NativeIO.isAvailable())) {
/*  56 */         instance = new ReadaheadPool();
/*     */       }
/*  58 */       return instance;
/*     */     }
/*     */   }
/*     */ 
/*     */   private ReadaheadPool() {
/*  63 */     final ThreadFactory backingFactory = Executors.defaultThreadFactory();
/*  64 */     this.pool = new ThreadPoolExecutor(4, 16, 3L, TimeUnit.SECONDS, new ArrayBlockingQueue(1024));
/*     */ 
/*  66 */     this.pool.setRejectedExecutionHandler(new ThreadPoolExecutor.DiscardOldestPolicy());
/*  67 */     this.pool.setThreadFactory(new ThreadFactory()
/*     */     {
/*     */       public Thread newThread(Runnable runnable) {
/*  70 */         Thread thread = backingFactory.newThread(runnable);
/*  71 */         thread.setName(String.format("Readahead Thread #%d", new Object[] { Long.valueOf(ReadaheadPool.THREAD_COUNTER.getAndIncrement()) }));
/*     */ 
/*  73 */         thread.setDaemon(true);
/*  74 */         return thread;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public ReadaheadRequest readaheadStream(String identifier, FileDescriptor fd, long curPos, long readaheadLength, long maxOffsetToRead, ReadaheadRequest lastReadahead)
/*     */   {
/* 105 */     if (curPos > maxOffsetToRead) {
/* 106 */       throw new IllegalArgumentException("Readahead position" + curPos + "higher than maxOffsetToRead" + maxOffsetToRead);
/*     */     }
/*     */ 
/* 110 */     if (readaheadLength <= 0L) {
/* 111 */       return null;
/*     */     }
/*     */ 
/* 114 */     long lastOffset = -9223372036854775808L;
/*     */ 
/* 116 */     if (lastReadahead != null) {
/* 117 */       lastOffset = lastReadahead.getOffset();
/*     */     }
/*     */ 
/* 123 */     long nextOffset = lastOffset + readaheadLength / 2L;
/* 124 */     if (curPos >= nextOffset)
/*     */     {
/* 128 */       if (lastReadahead != null) {
/* 129 */         lastReadahead.cancel();
/* 130 */         lastReadahead = null;
/*     */       }
/*     */ 
/* 133 */       long length = Math.min(readaheadLength, maxOffsetToRead - curPos);
/*     */ 
/* 136 */       if (length <= 0L)
/*     */       {
/* 138 */         return null;
/*     */       }
/*     */ 
/* 141 */       return submitReadahead(identifier, fd, curPos, length);
/*     */     }
/* 143 */     return lastReadahead;
/*     */   }
/*     */ 
/*     */   public ReadaheadRequest submitReadahead(String identifier, FileDescriptor fd, long off, long len)
/*     */   {
/* 156 */     ReadaheadRequestImpl req = new ReadaheadRequestImpl(identifier, fd, off, len, null);
/*     */ 
/* 158 */     this.pool.execute(req);
/* 159 */     if (LOG.isTraceEnabled()) {
/* 160 */       LOG.trace("submit readahead: " + req);
/*     */     }
/* 162 */     return req;
/*     */   }
/*     */ 
/*     */   private static class ReadaheadRequestImpl
/*     */     implements Runnable, ReadaheadPool.ReadaheadRequest
/*     */   {
/*     */     private final String identifier;
/*     */     private final FileDescriptor fd;
/*     */     private final long off;
/*     */     private final long len;
/* 196 */     private volatile boolean canceled = false;
/*     */ 
/*     */     private ReadaheadRequestImpl(String identifier, FileDescriptor fd, long off, long len) {
/* 199 */       this.identifier = identifier;
/* 200 */       this.fd = fd;
/* 201 */       this.off = off;
/* 202 */       this.len = len;
/*     */     }
/*     */ 
/*     */     public void run() {
/* 206 */       if (this.canceled) return;
/*     */ 
/*     */       try
/*     */       {
/* 213 */         NativeIO.posixFadviseIfPossible(this.fd, this.off, this.len, 3);
/*     */       }
/*     */       catch (IOException ioe) {
/* 216 */         if (this.canceled)
/*     */         {
/* 219 */           return;
/*     */         }
/* 221 */         ReadaheadPool.LOG.warn("Failed readahead on " + this.identifier, ioe);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void cancel()
/*     */     {
/* 228 */       this.canceled = true;
/*     */     }
/*     */ 
/*     */     public long getOffset()
/*     */     {
/* 236 */       return this.off;
/*     */     }
/*     */ 
/*     */     public long getLength()
/*     */     {
/* 241 */       return this.len;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 246 */       return "ReadaheadRequestImpl [identifier='" + this.identifier + "', fd=" + this.fd + ", off=" + this.off + ", len=" + this.len + "]";
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface ReadaheadRequest
/*     */   {
/*     */     public abstract void cancel();
/*     */ 
/*     */     public abstract long getOffset();
/*     */ 
/*     */     public abstract long getLength();
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.ReadaheadPool
 * JD-Core Version:    0.6.1
 */
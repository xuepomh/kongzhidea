/*     */ package org.apache.hadoop.io;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.hadoop.util.ReflectionUtils;
/*     */ 
/*     */ public class SortedMapWritable extends AbstractMapWritable
/*     */   implements SortedMap<WritableComparable, Writable>
/*     */ {
/*     */   private SortedMap<WritableComparable, Writable> instance;
/*     */ 
/*     */   public SortedMapWritable()
/*     */   {
/*  45 */     this.instance = new TreeMap();
/*     */   }
/*     */ 
/*     */   public SortedMapWritable(SortedMapWritable other)
/*     */   {
/*  54 */     this();
/*  55 */     copy(other);
/*     */   }
/*     */ 
/*     */   public Comparator<? super WritableComparable> comparator()
/*     */   {
/*  61 */     return null;
/*     */   }
/*     */ 
/*     */   public WritableComparable firstKey()
/*     */   {
/*  66 */     return (WritableComparable)this.instance.firstKey();
/*     */   }
/*     */ 
/*     */   public SortedMap<WritableComparable, Writable> headMap(WritableComparable toKey)
/*     */   {
/*  73 */     return this.instance.headMap(toKey);
/*     */   }
/*     */ 
/*     */   public WritableComparable lastKey()
/*     */   {
/*  78 */     return (WritableComparable)this.instance.lastKey();
/*     */   }
/*     */ 
/*     */   public SortedMap<WritableComparable, Writable> subMap(WritableComparable fromKey, WritableComparable toKey)
/*     */   {
/*  85 */     return this.instance.subMap(fromKey, toKey);
/*     */   }
/*     */ 
/*     */   public SortedMap<WritableComparable, Writable> tailMap(WritableComparable fromKey)
/*     */   {
/*  92 */     return this.instance.tailMap(fromKey);
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/*  97 */     this.instance.clear();
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key)
/*     */   {
/* 102 */     return this.instance.containsKey(key);
/*     */   }
/*     */ 
/*     */   public boolean containsValue(Object value)
/*     */   {
/* 107 */     return this.instance.containsValue(value);
/*     */   }
/*     */ 
/*     */   public Set<Map.Entry<WritableComparable, Writable>> entrySet()
/*     */   {
/* 112 */     return this.instance.entrySet();
/*     */   }
/*     */ 
/*     */   public Writable get(Object key)
/*     */   {
/* 117 */     return (Writable)this.instance.get(key);
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 122 */     return this.instance.isEmpty();
/*     */   }
/*     */ 
/*     */   public Set<WritableComparable> keySet()
/*     */   {
/* 127 */     return this.instance.keySet();
/*     */   }
/*     */ 
/*     */   public Writable put(WritableComparable key, Writable value)
/*     */   {
/* 132 */     addToMap(key.getClass());
/* 133 */     addToMap(value.getClass());
/* 134 */     return (Writable)this.instance.put(key, value);
/*     */   }
/*     */ 
/*     */   public void putAll(Map<? extends WritableComparable, ? extends Writable> t)
/*     */   {
/* 140 */     for (Map.Entry e : t.entrySet())
/*     */     {
/* 142 */       put((WritableComparable)e.getKey(), (Writable)e.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   public Writable remove(Object key)
/*     */   {
/* 148 */     return (Writable)this.instance.remove(key);
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 153 */     return this.instance.size();
/*     */   }
/*     */ 
/*     */   public Collection<Writable> values()
/*     */   {
/* 158 */     return this.instance.values();
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in)
/*     */     throws IOException
/*     */   {
/* 165 */     super.readFields(in);
/*     */ 
/* 169 */     int entries = in.readInt();
/*     */ 
/* 173 */     for (int i = 0; i < entries; i++) {
/* 174 */       WritableComparable key = (WritableComparable)ReflectionUtils.newInstance(getClass(in.readByte()), getConf());
/*     */ 
/* 178 */       key.readFields(in);
/*     */ 
/* 180 */       Writable value = (Writable)ReflectionUtils.newInstance(getClass(in.readByte()), getConf());
/*     */ 
/* 183 */       value.readFields(in);
/* 184 */       this.instance.put(key, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/* 191 */     super.write(out);
/*     */ 
/* 195 */     out.writeInt(this.instance.size());
/*     */ 
/* 199 */     for (Map.Entry e : this.instance.entrySet()) {
/* 200 */       out.writeByte(getId(((WritableComparable)e.getKey()).getClass()));
/* 201 */       ((WritableComparable)e.getKey()).write(out);
/* 202 */       out.writeByte(getId(((Writable)e.getValue()).getClass()));
/* 203 */       ((Writable)e.getValue()).write(out);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 209 */     if (this == obj) {
/* 210 */       return true;
/*     */     }
/*     */ 
/* 213 */     if ((obj instanceof SortedMapWritable)) {
/* 214 */       Map map = (Map)obj;
/* 215 */       if (size() != map.size()) {
/* 216 */         return false;
/*     */       }
/*     */ 
/* 219 */       return entrySet().equals(map.entrySet());
/*     */     }
/*     */ 
/* 222 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 227 */     return this.instance.hashCode();
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.SortedMapWritable
 * JD-Core Version:    0.6.1
 */
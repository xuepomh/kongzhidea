package org.apache.hadoop.io;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public abstract interface Writable
{
  public abstract void write(DataOutput paramDataOutput)
    throws IOException;

  public abstract void readFields(DataInput paramDataInput)
    throws IOException;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.Writable
 * JD-Core Version:    0.6.1
 */
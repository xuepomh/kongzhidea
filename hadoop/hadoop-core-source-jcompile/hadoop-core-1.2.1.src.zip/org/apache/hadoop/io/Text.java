/*     */ package org.apache.hadoop.io;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.charset.CharacterCodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetDecoder;
/*     */ import java.nio.charset.CharsetEncoder;
/*     */ import java.nio.charset.CodingErrorAction;
/*     */ import java.nio.charset.MalformedInputException;
/*     */ import java.text.CharacterIterator;
/*     */ import java.text.StringCharacterIterator;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class Text extends BinaryComparable
/*     */   implements WritableComparable<BinaryComparable>
/*     */ {
/*  49 */   private static final Log LOG = LogFactory.getLog(Text.class);
/*     */ 
/*  51 */   private static ThreadLocal<CharsetEncoder> ENCODER_FACTORY = new ThreadLocal()
/*     */   {
/*     */     protected CharsetEncoder initialValue() {
/*  54 */       return Charset.forName("UTF-8").newEncoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT);
/*     */     }
/*  51 */   };
/*     */ 
/*  60 */   private static ThreadLocal<CharsetDecoder> DECODER_FACTORY = new ThreadLocal()
/*     */   {
/*     */     protected CharsetDecoder initialValue() {
/*  63 */       return Charset.forName("UTF-8").newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT);
/*     */     }
/*  60 */   };
/*     */ 
/*  69 */   private static final byte[] EMPTY_BYTES = new byte[0];
/*     */   private byte[] bytes;
/*     */   private int length;
/*     */   private static final int LEAD_BYTE = 0;
/*     */   private static final int TRAIL_BYTE_1 = 1;
/*     */   private static final int TRAIL_BYTE = 2;
/* 512 */   static final int[] bytesFromUTF8 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5 };
/*     */ 
/* 556 */   static final int[] offsetsFromUTF8 = { 0, 12416, 925824, 63447168, -100130688, -2113396608 };
/*     */ 
/*     */   public Text()
/*     */   {
/*  75 */     this.bytes = EMPTY_BYTES;
/*     */   }
/*     */ 
/*     */   public Text(String string)
/*     */   {
/*  81 */     set(string);
/*     */   }
/*     */ 
/*     */   public Text(Text utf8)
/*     */   {
/*  86 */     set(utf8);
/*     */   }
/*     */ 
/*     */   public Text(byte[] utf8)
/*     */   {
/*  92 */     set(utf8);
/*     */   }
/*     */ 
/*     */   public byte[] getBytes()
/*     */   {
/* 100 */     return this.bytes;
/*     */   }
/*     */ 
/*     */   public int getLength()
/*     */   {
/* 105 */     return this.length;
/*     */   }
/*     */ 
/*     */   public int charAt(int position)
/*     */   {
/* 117 */     if (position > this.length) return -1;
/* 118 */     if (position < 0) return -1;
/*     */ 
/* 120 */     ByteBuffer bb = (ByteBuffer)ByteBuffer.wrap(this.bytes).position(position);
/* 121 */     return bytesToCodePoint(bb.slice());
/*     */   }
/*     */ 
/*     */   public int find(String what) {
/* 125 */     return find(what, 0);
/*     */   }
/*     */ 
/*     */   public int find(String what, int start)
/*     */   {
/*     */     try
/*     */     {
/* 139 */       ByteBuffer src = ByteBuffer.wrap(this.bytes, 0, this.length);
/* 140 */       ByteBuffer tgt = encode(what);
/* 141 */       byte b = tgt.get();
/* 142 */       src.position(start);
/*     */ 
/* 144 */       while (src.hasRemaining()) {
/* 145 */         if (b == src.get()) {
/* 146 */           src.mark();
/* 147 */           tgt.mark();
/* 148 */           boolean found = true;
/* 149 */           int pos = src.position() - 1;
/* 150 */           while (tgt.hasRemaining()) {
/* 151 */             if (!src.hasRemaining()) {
/* 152 */               tgt.reset();
/* 153 */               src.reset();
/* 154 */               found = false;
/*     */             }
/* 157 */             else if (tgt.get() != src.get()) {
/* 158 */               tgt.reset();
/* 159 */               src.reset();
/* 160 */               found = false;
/*     */             }
/*     */           }
/*     */ 
/* 164 */           if (found) return pos;
/*     */         }
/*     */       }
/* 167 */       return -1;
/*     */     }
/*     */     catch (CharacterCodingException e) {
/* 170 */       e.printStackTrace();
/* 171 */     }return -1;
/*     */   }
/*     */ 
/*     */   public void set(String string)
/*     */   {
/*     */     try
/*     */     {
/* 178 */       ByteBuffer bb = encode(string, true);
/* 179 */       this.bytes = bb.array();
/* 180 */       this.length = bb.limit();
/*     */     } catch (CharacterCodingException e) {
/* 182 */       throw new RuntimeException("Should not have happened " + e.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void set(byte[] utf8)
/*     */   {
/* 189 */     set(utf8, 0, utf8.length);
/*     */   }
/*     */ 
/*     */   public void set(Text other)
/*     */   {
/* 194 */     set(other.getBytes(), 0, other.getLength());
/*     */   }
/*     */ 
/*     */   public void set(byte[] utf8, int start, int len)
/*     */   {
/* 204 */     setCapacity(len, false);
/* 205 */     System.arraycopy(utf8, start, this.bytes, 0, len);
/* 206 */     this.length = len;
/*     */   }
/*     */ 
/*     */   public void append(byte[] utf8, int start, int len)
/*     */   {
/* 216 */     setCapacity(this.length + len, true);
/* 217 */     System.arraycopy(utf8, start, this.bytes, this.length, len);
/* 218 */     this.length += len;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 225 */     this.length = 0;
/*     */   }
/*     */ 
/*     */   private void setCapacity(int len, boolean keepData)
/*     */   {
/* 239 */     if ((this.bytes == null) || (this.bytes.length < len)) {
/* 240 */       byte[] newBytes = new byte[len];
/* 241 */       if ((this.bytes != null) && (keepData)) {
/* 242 */         System.arraycopy(this.bytes, 0, newBytes, 0, this.length);
/*     */       }
/* 244 */       this.bytes = newBytes;
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*     */     try
/*     */     {
/* 254 */       return decode(this.bytes, 0, this.length);
/*     */     } catch (CharacterCodingException e) {
/* 256 */       throw new RuntimeException("Should not have happened " + e.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in)
/*     */     throws IOException
/*     */   {
/* 263 */     int newLength = WritableUtils.readVInt(in);
/* 264 */     setCapacity(newLength, false);
/* 265 */     in.readFully(this.bytes, 0, newLength);
/* 266 */     this.length = newLength;
/*     */   }
/*     */ 
/*     */   public static void skip(DataInput in) throws IOException
/*     */   {
/* 271 */     int length = WritableUtils.readVInt(in);
/* 272 */     WritableUtils.skipFully(in, length);
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/* 281 */     WritableUtils.writeVInt(out, this.length);
/* 282 */     out.write(this.bytes, 0, this.length);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 287 */     if ((o instanceof Text))
/* 288 */       return super.equals(o);
/* 289 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 293 */     return super.hashCode();
/*     */   }
/*     */ 
/*     */   public static String decode(byte[] utf8)
/*     */     throws CharacterCodingException
/*     */   {
/* 322 */     return decode(ByteBuffer.wrap(utf8), true);
/*     */   }
/*     */ 
/*     */   public static String decode(byte[] utf8, int start, int length) throws CharacterCodingException
/*     */   {
/* 327 */     return decode(ByteBuffer.wrap(utf8, start, length), true);
/*     */   }
/*     */ 
/*     */   public static String decode(byte[] utf8, int start, int length, boolean replace)
/*     */     throws CharacterCodingException
/*     */   {
/* 339 */     return decode(ByteBuffer.wrap(utf8, start, length), replace);
/*     */   }
/*     */ 
/*     */   private static String decode(ByteBuffer utf8, boolean replace) throws CharacterCodingException
/*     */   {
/* 344 */     CharsetDecoder decoder = (CharsetDecoder)DECODER_FACTORY.get();
/* 345 */     if (replace) {
/* 346 */       decoder.onMalformedInput(CodingErrorAction.REPLACE);
/*     */ 
/* 348 */       decoder.onUnmappableCharacter(CodingErrorAction.REPLACE);
/*     */     }
/* 350 */     String str = decoder.decode(utf8).toString();
/*     */ 
/* 352 */     if (replace) {
/* 353 */       decoder.onMalformedInput(CodingErrorAction.REPORT);
/* 354 */       decoder.onUnmappableCharacter(CodingErrorAction.REPORT);
/*     */     }
/* 356 */     return str;
/*     */   }
/*     */ 
/*     */   public static ByteBuffer encode(String string)
/*     */     throws CharacterCodingException
/*     */   {
/* 369 */     return encode(string, true);
/*     */   }
/*     */ 
/*     */   public static ByteBuffer encode(String string, boolean replace)
/*     */     throws CharacterCodingException
/*     */   {
/* 383 */     CharsetEncoder encoder = (CharsetEncoder)ENCODER_FACTORY.get();
/* 384 */     if (replace) {
/* 385 */       encoder.onMalformedInput(CodingErrorAction.REPLACE);
/* 386 */       encoder.onUnmappableCharacter(CodingErrorAction.REPLACE);
/*     */     }
/* 388 */     ByteBuffer bytes = encoder.encode(CharBuffer.wrap(string.toCharArray()));
/*     */ 
/* 390 */     if (replace) {
/* 391 */       encoder.onMalformedInput(CodingErrorAction.REPORT);
/* 392 */       encoder.onUnmappableCharacter(CodingErrorAction.REPORT);
/*     */     }
/* 394 */     return bytes;
/*     */   }
/*     */ 
/*     */   public static String readString(DataInput in)
/*     */     throws IOException
/*     */   {
/* 400 */     int length = WritableUtils.readVInt(in);
/* 401 */     byte[] bytes = new byte[length];
/* 402 */     in.readFully(bytes, 0, length);
/* 403 */     return decode(bytes);
/*     */   }
/*     */ 
/*     */   public static int writeString(DataOutput out, String s)
/*     */     throws IOException
/*     */   {
/* 409 */     ByteBuffer bytes = encode(s);
/* 410 */     int length = bytes.limit();
/* 411 */     WritableUtils.writeVInt(out, length);
/* 412 */     out.write(bytes.array(), 0, length);
/* 413 */     return length;
/*     */   }
/*     */ 
/*     */   public static void validateUTF8(byte[] utf8)
/*     */     throws MalformedInputException
/*     */   {
/* 430 */     validateUTF8(utf8, 0, utf8.length);
/*     */   }
/*     */ 
/*     */   public static void validateUTF8(byte[] utf8, int start, int len)
/*     */     throws MalformedInputException
/*     */   {
/* 442 */     int count = start;
/* 443 */     int leadByte = 0;
/* 444 */     int length = 0;
/* 445 */     int state = 0;
/* 446 */     while (count < start + len) {
/* 447 */       int aByte = utf8[count] & 0xFF;
/*     */ 
/* 449 */       switch (state) {
/*     */       case 0:
/* 451 */         leadByte = aByte;
/* 452 */         length = bytesFromUTF8[aByte];
/*     */ 
/* 454 */         switch (length) {
/*     */         case 0:
/* 456 */           if (leadByte > 127)
/* 457 */             throw new MalformedInputException(count);
/*     */           break;
/*     */         case 1:
/* 460 */           if ((leadByte < 194) || (leadByte > 223))
/* 461 */             throw new MalformedInputException(count);
/* 462 */           state = 1;
/* 463 */           break;
/*     */         case 2:
/* 465 */           if ((leadByte < 224) || (leadByte > 239))
/* 466 */             throw new MalformedInputException(count);
/* 467 */           state = 1;
/* 468 */           break;
/*     */         case 3:
/* 470 */           if ((leadByte < 240) || (leadByte > 244))
/* 471 */             throw new MalformedInputException(count);
/* 472 */           state = 1;
/* 473 */           break;
/*     */         default:
/* 477 */           throw new MalformedInputException(count);
/*     */         }
/*     */ 
/*     */         break;
/*     */       case 1:
/* 482 */         if ((leadByte == 240) && (aByte < 144))
/* 483 */           throw new MalformedInputException(count);
/* 484 */         if ((leadByte == 244) && (aByte > 143))
/* 485 */           throw new MalformedInputException(count);
/* 486 */         if ((leadByte == 224) && (aByte < 160))
/* 487 */           throw new MalformedInputException(count);
/* 488 */         if ((leadByte == 237) && (aByte > 159)) {
/* 489 */           throw new MalformedInputException(count);
/*     */         }
/*     */       case 2:
/* 492 */         if ((aByte < 128) || (aByte > 191))
/* 493 */           throw new MalformedInputException(count);
/* 494 */         length--; if (length == 0)
/* 495 */           state = 0;
/*     */         else {
/* 497 */           state = 2;
/*     */         }
/*     */         break;
/*     */       }
/* 501 */       count++;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int bytesToCodePoint(ByteBuffer bytes)
/*     */   {
/* 535 */     bytes.mark();
/* 536 */     byte b = bytes.get();
/* 537 */     bytes.reset();
/* 538 */     int extraBytesToRead = bytesFromUTF8[(b & 0xFF)];
/* 539 */     if (extraBytesToRead < 0) return -1;
/* 540 */     int ch = 0;
/*     */ 
/* 542 */     switch (extraBytesToRead) { case 5:
/* 543 */       ch += (bytes.get() & 0xFF); ch <<= 6;
/*     */     case 4:
/* 544 */       ch += (bytes.get() & 0xFF); ch <<= 6;
/*     */     case 3:
/* 545 */       ch += (bytes.get() & 0xFF); ch <<= 6;
/*     */     case 2:
/* 546 */       ch += (bytes.get() & 0xFF); ch <<= 6;
/*     */     case 1:
/* 547 */       ch += (bytes.get() & 0xFF); ch <<= 6;
/*     */     case 0:
/* 548 */       ch += (bytes.get() & 0xFF);
/*     */     }
/* 550 */     ch -= offsetsFromUTF8[extraBytesToRead];
/*     */ 
/* 552 */     return ch;
/*     */   }
/*     */ 
/*     */   public static int utf8Length(String string)
/*     */   {
/* 567 */     CharacterIterator iter = new StringCharacterIterator(string);
/* 568 */     char ch = iter.first();
/* 569 */     int size = 0;
/* 570 */     while (ch != 65535) {
/* 571 */       if ((ch >= 55296) && (ch < 56320))
/*     */       {
/* 573 */         char trail = iter.next();
/* 574 */         if ((trail > 56319) && (trail < 57344))
/*     */         {
/* 576 */           size += 4;
/*     */         }
/*     */         else {
/* 579 */           size += 3;
/* 580 */           iter.previous();
/*     */         }
/* 582 */       } else if (ch < '') {
/* 583 */         size++;
/* 584 */       } else if (ch < 'ࠀ') {
/* 585 */         size += 2;
/*     */       }
/*     */       else {
/* 588 */         size += 3;
/*     */       }
/* 590 */       ch = iter.next();
/*     */     }
/* 592 */     return size;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 312 */     WritableComparator.define(Text.class, new Comparator());
/*     */   }
/*     */ 
/*     */   public static class Comparator extends WritableComparator
/*     */   {
/*     */     public Comparator()
/*     */     {
/* 299 */       super();
/*     */     }
/*     */ 
/*     */     public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2)
/*     */     {
/* 304 */       int n1 = WritableUtils.decodeVIntSize(b1[s1]);
/* 305 */       int n2 = WritableUtils.decodeVIntSize(b2[s2]);
/* 306 */       return compareBytes(b1, s1 + n1, l1 - n1, b2, s2 + n2, l2 - n2);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.Text
 * JD-Core Version:    0.6.1
 */
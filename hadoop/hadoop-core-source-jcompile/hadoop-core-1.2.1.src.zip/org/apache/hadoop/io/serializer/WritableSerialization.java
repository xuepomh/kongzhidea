/*     */ package org.apache.hadoop.io.serializer;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.conf.Configured;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.util.ReflectionUtils;
/*     */ 
/*     */ public class WritableSerialization extends Configured
/*     */   implements Serialization<Writable>
/*     */ {
/*     */   public boolean accept(Class<?> c)
/*     */   {
/* 100 */     return Writable.class.isAssignableFrom(c);
/*     */   }
/*     */ 
/*     */   public Deserializer<Writable> getDeserializer(Class<Writable> c) {
/* 104 */     return new WritableDeserializer(getConf(), c);
/*     */   }
/*     */ 
/*     */   public Serializer<Writable> getSerializer(Class<Writable> c) {
/* 108 */     return new WritableSerializer();
/*     */   }
/*     */ 
/*     */   static class WritableSerializer
/*     */     implements Serializer<Writable>
/*     */   {
/*     */     private DataOutputStream dataOut;
/*     */ 
/*     */     public void open(OutputStream out)
/*     */     {
/*  82 */       if ((out instanceof DataOutputStream))
/*  83 */         this.dataOut = ((DataOutputStream)out);
/*     */       else
/*  85 */         this.dataOut = new DataOutputStream(out);
/*     */     }
/*     */ 
/*     */     public void serialize(Writable w) throws IOException
/*     */     {
/*  90 */       w.write(this.dataOut);
/*     */     }
/*     */ 
/*     */     public void close() throws IOException {
/*  94 */       this.dataOut.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   static class WritableDeserializer extends Configured
/*     */     implements Deserializer<Writable>
/*     */   {
/*     */     private Class<?> writableClass;
/*     */     private DataInputStream dataIn;
/*     */ 
/*     */     public WritableDeserializer(Configuration conf, Class<?> c)
/*     */     {
/*  47 */       setConf(conf);
/*  48 */       this.writableClass = c;
/*     */     }
/*     */ 
/*     */     public void open(InputStream in) {
/*  52 */       if ((in instanceof DataInputStream))
/*  53 */         this.dataIn = ((DataInputStream)in);
/*     */       else
/*  55 */         this.dataIn = new DataInputStream(in);
/*     */     }
/*     */ 
/*     */     public Writable deserialize(Writable w)
/*     */       throws IOException
/*     */     {
/*     */       Writable writable;
/*     */       Writable writable;
/*  61 */       if (w == null) {
/*  62 */         writable = (Writable)ReflectionUtils.newInstance(this.writableClass, getConf());
/*     */       }
/*     */       else {
/*  65 */         writable = w;
/*     */       }
/*  67 */       writable.readFields(this.dataIn);
/*  68 */       return writable;
/*     */     }
/*     */ 
/*     */     public void close() throws IOException {
/*  72 */       this.dataIn.close();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.serializer.WritableSerialization
 * JD-Core Version:    0.6.1
 */
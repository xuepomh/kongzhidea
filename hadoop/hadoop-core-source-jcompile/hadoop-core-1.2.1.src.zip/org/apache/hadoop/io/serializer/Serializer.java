package org.apache.hadoop.io.serializer;

import java.io.IOException;
import java.io.OutputStream;

public abstract interface Serializer<T>
{
  public abstract void open(OutputStream paramOutputStream)
    throws IOException;

  public abstract void serialize(T paramT)
    throws IOException;

  public abstract void close()
    throws IOException;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.serializer.Serializer
 * JD-Core Version:    0.6.1
 */
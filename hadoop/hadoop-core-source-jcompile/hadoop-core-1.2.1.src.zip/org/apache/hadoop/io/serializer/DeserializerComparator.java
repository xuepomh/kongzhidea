/*    */ package org.apache.hadoop.io.serializer;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.hadoop.io.InputBuffer;
/*    */ import org.apache.hadoop.io.RawComparator;
/*    */ 
/*    */ public abstract class DeserializerComparator<T>
/*    */   implements RawComparator<T>
/*    */ {
/* 42 */   private InputBuffer buffer = new InputBuffer();
/*    */   private Deserializer<T> deserializer;
/*    */   private T key1;
/*    */   private T key2;
/*    */ 
/*    */   protected DeserializerComparator(Deserializer<T> deserializer)
/*    */     throws IOException
/*    */   {
/* 51 */     this.deserializer = deserializer;
/* 52 */     this.deserializer.open(this.buffer);
/*    */   }
/*    */ 
/*    */   public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2)
/*    */   {
/*    */     try {
/* 58 */       this.buffer.reset(b1, s1, l1);
/* 59 */       this.key1 = this.deserializer.deserialize(this.key1);
/*    */ 
/* 61 */       this.buffer.reset(b2, s2, l2);
/* 62 */       this.key2 = this.deserializer.deserialize(this.key2);
/*    */     }
/*    */     catch (IOException e) {
/* 65 */       throw new RuntimeException(e);
/*    */     }
/* 67 */     return compare(this.key1, this.key2);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.serializer.DeserializerComparator
 * JD-Core Version:    0.6.1
 */
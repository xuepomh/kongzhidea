package org.apache.hadoop.io.serializer;

import java.io.IOException;
import java.io.InputStream;

public abstract interface Deserializer<T>
{
  public abstract void open(InputStream paramInputStream)
    throws IOException;

  public abstract T deserialize(T paramT)
    throws IOException;

  public abstract void close()
    throws IOException;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.serializer.Deserializer
 * JD-Core Version:    0.6.1
 */
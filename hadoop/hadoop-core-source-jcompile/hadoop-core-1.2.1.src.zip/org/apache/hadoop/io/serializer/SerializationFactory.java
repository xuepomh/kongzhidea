/*    */ package org.apache.hadoop.io.serializer;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ import org.apache.hadoop.conf.Configured;
/*    */ import org.apache.hadoop.util.ReflectionUtils;
/*    */ import org.apache.hadoop.util.StringUtils;
/*    */ 
/*    */ public class SerializationFactory extends Configured
/*    */ {
/* 38 */   private static final Log LOG = LogFactory.getLog(SerializationFactory.class.getName());
/*    */ 
/* 41 */   private List<Serialization<?>> serializations = new ArrayList();
/*    */ 
/*    */   public SerializationFactory(Configuration conf)
/*    */   {
/* 51 */     super(conf);
/* 52 */     for (String serializerName : conf.getStrings("io.serializations", new String[] { "org.apache.hadoop.io.serializer.WritableSerialization" }))
/*    */     {
/* 54 */       add(conf, serializerName);
/*    */     }
/*    */   }
/*    */ 
/*    */   private void add(Configuration conf, String serializationName)
/*    */   {
/*    */     try
/*    */     {
/* 62 */       Class serializionClass = conf.getClassByName(serializationName);
/*    */ 
/* 64 */       this.serializations.add((Serialization)ReflectionUtils.newInstance(serializionClass, getConf()));
/*    */     }
/*    */     catch (ClassNotFoundException e) {
/* 67 */       LOG.warn("Serilization class not found: " + StringUtils.stringifyException(e));
/*    */     }
/*    */   }
/*    */ 
/*    */   public <T> Serializer<T> getSerializer(Class<T> c)
/*    */   {
/* 73 */     return getSerialization(c).getSerializer(c);
/*    */   }
/*    */ 
/*    */   public <T> Deserializer<T> getDeserializer(Class<T> c) {
/* 77 */     return getSerialization(c).getDeserializer(c);
/*    */   }
/*    */ 
/*    */   public <T> Serialization<T> getSerialization(Class<T> c)
/*    */   {
/* 82 */     for (Serialization serialization : this.serializations) {
/* 83 */       if (serialization.accept(c)) {
/* 84 */         return serialization;
/*    */       }
/*    */     }
/* 87 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.serializer.SerializationFactory
 * JD-Core Version:    0.6.1
 */
package org.apache.hadoop.io.serializer;

public abstract interface Serialization<T>
{
  public abstract boolean accept(Class<?> paramClass);

  public abstract Serializer<T> getSerializer(Class<T> paramClass);

  public abstract Deserializer<T> getDeserializer(Class<T> paramClass);
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.serializer.Serialization
 * JD-Core Version:    0.6.1
 */
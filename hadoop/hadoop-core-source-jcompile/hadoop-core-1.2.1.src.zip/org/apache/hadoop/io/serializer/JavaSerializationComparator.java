/*    */ package org.apache.hadoop.io.serializer;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class JavaSerializationComparator<T extends Serializable,  extends Comparable<T>> extends DeserializerComparator<T>
/*    */ {
/*    */   public JavaSerializationComparator()
/*    */     throws IOException
/*    */   {
/* 39 */     super(new JavaSerialization.JavaSerializationDeserializer());
/*    */   }
/*    */ 
/*    */   public int compare(T o1, T o2) {
/* 43 */     return ((Comparable)o1).compareTo(o2);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.serializer.JavaSerializationComparator
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.io.serializer;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class JavaSerialization
/*    */   implements Serialization<Serializable>
/*    */ {
/*    */   public boolean accept(Class<?> c)
/*    */   {
/* 90 */     return Serializable.class.isAssignableFrom(c);
/*    */   }
/*    */ 
/*    */   public Deserializer<Serializable> getDeserializer(Class<Serializable> c) {
/* 94 */     return new JavaSerializationDeserializer();
/*    */   }
/*    */ 
/*    */   public Serializer<Serializable> getSerializer(Class<Serializable> c) {
/* 98 */     return new JavaSerializationSerializer();
/*    */   }
/*    */ 
/*    */   static class JavaSerializationSerializer
/*    */     implements Serializer<Serializable>
/*    */   {
/*    */     private ObjectOutputStream oos;
/*    */ 
/*    */     public void open(OutputStream out)
/*    */       throws IOException
/*    */     {
/* 71 */       this.oos = new ObjectOutputStream(out)
/*    */       {
/*    */         protected void writeStreamHeader() {
/*    */         }
/*    */       };
/*    */     }
/*    */ 
/*    */     public void serialize(Serializable object) throws IOException {
/* 79 */       this.oos.reset();
/* 80 */       this.oos.writeObject(object);
/*    */     }
/*    */ 
/*    */     public void close() throws IOException {
/* 84 */       this.oos.close();
/*    */     }
/*    */   }
/*    */ 
/*    */   static class JavaSerializationDeserializer<T extends Serializable>
/*    */     implements Deserializer<T>
/*    */   {
/*    */     private ObjectInputStream ois;
/*    */ 
/*    */     public void open(InputStream in)
/*    */       throws IOException
/*    */     {
/* 42 */       this.ois = new ObjectInputStream(in)
/*    */       {
/*    */         protected void readStreamHeader()
/*    */         {
/*    */         }
/*    */       };
/*    */     }
/*    */ 
/*    */     public T deserialize(T object) throws IOException
/*    */     {
/*    */       try {
/* 53 */         return (Serializable)this.ois.readObject();
/*    */       } catch (ClassNotFoundException e) {
/* 55 */         throw new IOException(e.toString());
/*    */       }
/*    */     }
/*    */ 
/*    */     public void close() throws IOException {
/* 60 */       this.ois.close();
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.serializer.JavaSerialization
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.io;
/*    */ 
/*    */ public abstract class BinaryComparable
/*    */   implements Comparable<BinaryComparable>
/*    */ {
/*    */   public abstract int getLength();
/*    */ 
/*    */   public abstract byte[] getBytes();
/*    */ 
/*    */   public int compareTo(BinaryComparable other)
/*    */   {
/* 42 */     if (this == other)
/* 43 */       return 0;
/* 44 */     return WritableComparator.compareBytes(getBytes(), 0, getLength(), other.getBytes(), 0, other.getLength());
/*    */   }
/*    */ 
/*    */   public int compareTo(byte[] other, int off, int len)
/*    */   {
/* 52 */     return WritableComparator.compareBytes(getBytes(), 0, getLength(), other, off, len);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 60 */     if (!(other instanceof BinaryComparable))
/* 61 */       return false;
/* 62 */     BinaryComparable that = (BinaryComparable)other;
/* 63 */     if (getLength() != that.getLength())
/* 64 */       return false;
/* 65 */     return compareTo(that) == 0;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 73 */     return WritableComparator.hashBytes(getBytes(), getLength());
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.BinaryComparable
 * JD-Core Version:    0.6.1
 */
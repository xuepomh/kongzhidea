/*     */ package org.apache.hadoop.io;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.io.compress.CompressionCodec;
/*     */ import org.apache.hadoop.util.Progressable;
/*     */ import org.apache.hadoop.util.bloom.DynamicBloomFilter;
/*     */ import org.apache.hadoop.util.bloom.Filter;
/*     */ import org.apache.hadoop.util.bloom.Key;
/*     */ import org.apache.hadoop.util.hash.Hash;
/*     */ 
/*     */ public class BloomMapFile
/*     */ {
/*  46 */   private static final Log LOG = LogFactory.getLog(BloomMapFile.class);
/*     */   public static final String BLOOM_FILE_NAME = "bloom";
/*     */   public static final int HASH_COUNT = 5;
/*     */ 
/*     */   public static void delete(FileSystem fs, String name)
/*     */     throws IOException
/*     */   {
/*  51 */     Path dir = new Path(name);
/*  52 */     Path data = new Path(dir, "data");
/*  53 */     Path index = new Path(dir, "index");
/*  54 */     Path bloom = new Path(dir, "bloom");
/*     */ 
/*  56 */     fs.delete(data, true);
/*  57 */     fs.delete(index, true);
/*  58 */     fs.delete(bloom, true);
/*  59 */     fs.delete(dir, true);
/*     */   }
/*     */ 
/*     */   private static byte[] byteArrayForBloomKey(DataOutputBuffer buf) {
/*  63 */     int cleanLength = buf.getLength();
/*  64 */     byte[] ba = buf.getData();
/*  65 */     if (cleanLength != ba.length) {
/*  66 */       ba = new byte[cleanLength];
/*  67 */       System.arraycopy(buf.getData(), 0, ba, 0, cleanLength);
/*     */     }
/*  69 */     return ba;
/*     */   }
/*     */ 
/*     */   public static class Reader extends MapFile.Reader
/*     */   {
/*     */     private DynamicBloomFilter bloomFilter;
/* 193 */     private DataOutputBuffer buf = new DataOutputBuffer();
/* 194 */     private Key bloomKey = new Key();
/*     */ 
/*     */     public Reader(FileSystem fs, String dirName, Configuration conf) throws IOException
/*     */     {
/* 198 */       super(dirName, conf);
/* 199 */       initBloomFilter(fs, dirName, conf);
/*     */     }
/*     */ 
/*     */     public Reader(FileSystem fs, String dirName, WritableComparator comparator, Configuration conf, boolean open) throws IOException
/*     */     {
/* 204 */       super(dirName, comparator, conf, open);
/* 205 */       initBloomFilter(fs, dirName, conf);
/*     */     }
/*     */ 
/*     */     public Reader(FileSystem fs, String dirName, WritableComparator comparator, Configuration conf) throws IOException
/*     */     {
/* 210 */       super(dirName, comparator, conf);
/* 211 */       initBloomFilter(fs, dirName, conf);
/*     */     }
/*     */ 
/*     */     private void initBloomFilter(FileSystem fs, String dirName, Configuration conf)
/*     */     {
/*     */       try {
/* 217 */         DataInputStream in = fs.open(new Path(dirName, "bloom"));
/* 218 */         this.bloomFilter = new DynamicBloomFilter();
/* 219 */         this.bloomFilter.readFields(in);
/* 220 */         in.close();
/*     */       } catch (IOException ioe) {
/* 222 */         BloomMapFile.LOG.warn("Can't open BloomFilter: " + ioe + " - fallback to MapFile.");
/* 223 */         this.bloomFilter = null;
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean probablyHasKey(WritableComparable key)
/*     */       throws IOException
/*     */     {
/* 236 */       if (this.bloomFilter == null) {
/* 237 */         return true;
/*     */       }
/* 239 */       this.buf.reset();
/* 240 */       key.write(this.buf);
/* 241 */       this.bloomKey.set(BloomMapFile.byteArrayForBloomKey(this.buf), 1.0D);
/* 242 */       return this.bloomFilter.membershipTest(this.bloomKey);
/*     */     }
/*     */ 
/*     */     public synchronized Writable get(WritableComparable key, Writable val)
/*     */       throws IOException
/*     */     {
/* 255 */       if (!probablyHasKey(key)) {
/* 256 */         return null;
/*     */       }
/* 258 */       return super.get(key, val);
/*     */     }
/*     */ 
/*     */     public Filter getBloomFilter()
/*     */     {
/* 266 */       return this.bloomFilter;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Writer extends MapFile.Writer
/*     */   {
/*     */     private DynamicBloomFilter bloomFilter;
/*     */     private int numKeys;
/*     */     private int vectorSize;
/*  76 */     private Key bloomKey = new Key();
/*  77 */     private DataOutputBuffer buf = new DataOutputBuffer();
/*     */     private FileSystem fs;
/*     */     private Path dir;
/*     */ 
/*     */     public Writer(Configuration conf, FileSystem fs, String dirName, Class<? extends WritableComparable> keyClass, Class<? extends Writable> valClass, SequenceFile.CompressionType compress, CompressionCodec codec, Progressable progress)
/*     */       throws IOException
/*     */     {
/*  85 */       super(fs, dirName, keyClass, valClass, compress, codec, progress);
/*  86 */       this.fs = fs;
/*  87 */       this.dir = new Path(dirName);
/*  88 */       initBloomFilter(conf);
/*     */     }
/*     */ 
/*     */     public Writer(Configuration conf, FileSystem fs, String dirName, Class<? extends WritableComparable> keyClass, Class valClass, SequenceFile.CompressionType compress, Progressable progress)
/*     */       throws IOException
/*     */     {
/*  95 */       super(fs, dirName, keyClass, valClass, compress, progress);
/*  96 */       this.fs = fs;
/*  97 */       this.dir = new Path(dirName);
/*  98 */       initBloomFilter(conf);
/*     */     }
/*     */ 
/*     */     public Writer(Configuration conf, FileSystem fs, String dirName, Class<? extends WritableComparable> keyClass, Class valClass, SequenceFile.CompressionType compress)
/*     */       throws IOException
/*     */     {
/* 105 */       super(fs, dirName, keyClass, valClass, compress);
/* 106 */       this.fs = fs;
/* 107 */       this.dir = new Path(dirName);
/* 108 */       initBloomFilter(conf);
/*     */     }
/*     */ 
/*     */     public Writer(Configuration conf, FileSystem fs, String dirName, WritableComparator comparator, Class valClass, SequenceFile.CompressionType compress, CompressionCodec codec, Progressable progress)
/*     */       throws IOException
/*     */     {
/* 115 */       super(fs, dirName, comparator, valClass, compress, codec, progress);
/* 116 */       this.fs = fs;
/* 117 */       this.dir = new Path(dirName);
/* 118 */       initBloomFilter(conf);
/*     */     }
/*     */ 
/*     */     public Writer(Configuration conf, FileSystem fs, String dirName, WritableComparator comparator, Class valClass, SequenceFile.CompressionType compress, Progressable progress)
/*     */       throws IOException
/*     */     {
/* 124 */       super(fs, dirName, comparator, valClass, compress, progress);
/* 125 */       this.fs = fs;
/* 126 */       this.dir = new Path(dirName);
/* 127 */       initBloomFilter(conf);
/*     */     }
/*     */ 
/*     */     public Writer(Configuration conf, FileSystem fs, String dirName, WritableComparator comparator, Class valClass, SequenceFile.CompressionType compress)
/*     */       throws IOException
/*     */     {
/* 133 */       super(fs, dirName, comparator, valClass, compress);
/* 134 */       this.fs = fs;
/* 135 */       this.dir = new Path(dirName);
/* 136 */       initBloomFilter(conf);
/*     */     }
/*     */ 
/*     */     public Writer(Configuration conf, FileSystem fs, String dirName, WritableComparator comparator, Class valClass) throws IOException
/*     */     {
/* 141 */       super(fs, dirName, comparator, valClass);
/* 142 */       this.fs = fs;
/* 143 */       this.dir = new Path(dirName);
/* 144 */       initBloomFilter(conf);
/*     */     }
/*     */ 
/*     */     public Writer(Configuration conf, FileSystem fs, String dirName, Class<? extends WritableComparable> keyClass, Class valClass)
/*     */       throws IOException
/*     */     {
/* 150 */       super(fs, dirName, keyClass, valClass);
/* 151 */       this.fs = fs;
/* 152 */       this.dir = new Path(dirName);
/* 153 */       initBloomFilter(conf);
/*     */     }
/*     */ 
/*     */     private synchronized void initBloomFilter(Configuration conf) {
/* 157 */       this.numKeys = conf.getInt("io.mapfile.bloom.size", 1048576);
/*     */ 
/* 163 */       float errorRate = conf.getFloat("io.mapfile.bloom.error.rate", 0.005F);
/* 164 */       this.vectorSize = (int)Math.ceil(-5 * this.numKeys / Math.log(1.0D - Math.pow(errorRate, 0.2D)));
/*     */ 
/* 166 */       this.bloomFilter = new DynamicBloomFilter(this.vectorSize, 5, Hash.getHashType(conf), this.numKeys);
/*     */     }
/*     */ 
/*     */     public synchronized void append(WritableComparable key, Writable val)
/*     */       throws IOException
/*     */     {
/* 173 */       super.append(key, val);
/* 174 */       this.buf.reset();
/* 175 */       key.write(this.buf);
/* 176 */       this.bloomKey.set(BloomMapFile.byteArrayForBloomKey(this.buf), 1.0D);
/* 177 */       this.bloomFilter.add(this.bloomKey);
/*     */     }
/*     */ 
/*     */     public synchronized void close() throws IOException
/*     */     {
/* 182 */       super.close();
/* 183 */       DataOutputStream out = this.fs.create(new Path(this.dir, "bloom"), true);
/* 184 */       this.bloomFilter.write(out);
/* 185 */       out.flush();
/* 186 */       out.close();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.BloomMapFile
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.io;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.io.UTFDataFormatException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.classification.InterfaceAudience.LimitedPrivate;
/*     */ import org.apache.hadoop.classification.InterfaceStability.Stable;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ @Deprecated
/*     */ @InterfaceAudience.LimitedPrivate({"HDFS", "MapReduce"})
/*     */ @InterfaceStability.Stable
/*     */ public class UTF8
/*     */   implements WritableComparable<UTF8>
/*     */ {
/*  45 */   private static final Log LOG = LogFactory.getLog(UTF8.class);
/*  46 */   private static final DataInputBuffer IBUF = new DataInputBuffer();
/*     */ 
/*  48 */   private static final ThreadLocal<DataOutputBuffer> OBUF_FACTORY = new ThreadLocal()
/*     */   {
/*     */     protected DataOutputBuffer initialValue()
/*     */     {
/*  52 */       return new DataOutputBuffer();
/*     */     } } ;
/*     */ 
/*  56 */   private static final byte[] EMPTY_BYTES = new byte[0];
/*     */ 
/*  58 */   private byte[] bytes = EMPTY_BYTES;
/*     */   private int length;
/*     */ 
/*     */   public UTF8() {
/*     */   }
/*     */ 
/*     */   public UTF8(String string) {
/*  67 */     set(string);
/*     */   }
/*     */ 
/*     */   public UTF8(UTF8 utf8)
/*     */   {
/*  72 */     set(utf8);
/*     */   }
/*     */ 
/*     */   public byte[] getBytes()
/*     */   {
/*  77 */     return this.bytes;
/*     */   }
/*     */ 
/*     */   public int getLength()
/*     */   {
/*  82 */     return this.length;
/*     */   }
/*     */ 
/*     */   public void set(String string)
/*     */   {
/*  87 */     if (string.length() > 21845) {
/*  88 */       LOG.warn(new StringBuilder().append("truncating long string: ").append(string.length()).append(" chars, starting with ").append(string.substring(0, 20)).toString());
/*     */ 
/*  90 */       string = string.substring(0, 21845);
/*     */     }
/*     */ 
/*  93 */     this.length = utf8Length(string);
/*  94 */     if (this.length > 65535) {
/*  95 */       throw new RuntimeException("string too long!");
/*     */     }
/*  97 */     if ((this.bytes == null) || (this.length > this.bytes.length))
/*  98 */       this.bytes = new byte[this.length];
/*     */     try
/*     */     {
/* 101 */       DataOutputBuffer obuf = (DataOutputBuffer)OBUF_FACTORY.get();
/* 102 */       obuf.reset();
/* 103 */       writeChars(obuf, string, 0, string.length());
/* 104 */       System.arraycopy(obuf.getData(), 0, this.bytes, 0, this.length);
/*     */     } catch (IOException e) {
/* 106 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void set(UTF8 other)
/*     */   {
/* 112 */     this.length = other.length;
/* 113 */     if ((this.bytes == null) || (this.length > this.bytes.length))
/* 114 */       this.bytes = new byte[this.length];
/* 115 */     System.arraycopy(other.bytes, 0, this.bytes, 0, this.length);
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException
/*     */   {
/* 120 */     this.length = in.readUnsignedShort();
/* 121 */     if ((this.bytes == null) || (this.bytes.length < this.length))
/* 122 */       this.bytes = new byte[this.length];
/* 123 */     in.readFully(this.bytes, 0, this.length);
/*     */   }
/*     */ 
/*     */   public static void skip(DataInput in) throws IOException
/*     */   {
/* 128 */     int length = in.readUnsignedShort();
/* 129 */     WritableUtils.skipFully(in, length);
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out) throws IOException
/*     */   {
/* 134 */     out.writeShort(this.length);
/* 135 */     out.write(this.bytes, 0, this.length);
/*     */   }
/*     */ 
/*     */   public int compareTo(UTF8 o)
/*     */   {
/* 141 */     return WritableComparator.compareBytes(this.bytes, 0, this.length, o.bytes, 0, o.length);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 148 */     StringBuilder buffer = new StringBuilder(this.length);
/*     */     try {
/* 150 */       synchronized (IBUF) {
/* 151 */         IBUF.reset(this.bytes, this.length);
/* 152 */         readChars(IBUF, buffer, this.length);
/*     */       }
/*     */     } catch (IOException e) {
/* 155 */       throw new RuntimeException(e);
/*     */     }
/* 157 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public String toStringChecked()
/*     */     throws IOException
/*     */   {
/* 167 */     StringBuilder buffer = new StringBuilder(this.length);
/* 168 */     synchronized (IBUF) {
/* 169 */       IBUF.reset(this.bytes, this.length);
/* 170 */       readChars(IBUF, buffer, this.length);
/*     */     }
/* 172 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 178 */     if (!(o instanceof UTF8))
/* 179 */       return false;
/* 180 */     UTF8 that = (UTF8)o;
/* 181 */     if (this.length != that.length) {
/* 182 */       return false;
/*     */     }
/* 184 */     return WritableComparator.compareBytes(this.bytes, 0, this.length, that.bytes, 0, that.length) == 0;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 190 */     return WritableComparator.hashBytes(this.bytes, this.length);
/*     */   }
/*     */ 
/*     */   public static byte[] getBytes(String string)
/*     */   {
/* 220 */     byte[] result = new byte[utf8Length(string)];
/*     */     try {
/* 222 */       DataOutputBuffer obuf = (DataOutputBuffer)OBUF_FACTORY.get();
/* 223 */       obuf.reset();
/* 224 */       writeChars(obuf, string, 0, string.length());
/* 225 */       System.arraycopy(obuf.getData(), 0, result, 0, obuf.getLength());
/*     */     } catch (IOException e) {
/* 227 */       throw new RuntimeException(e);
/*     */     }
/* 229 */     return result;
/*     */   }
/*     */ 
/*     */   public static String fromBytes(byte[] bytes)
/*     */     throws IOException
/*     */   {
/* 238 */     DataInputBuffer dbuf = new DataInputBuffer();
/* 239 */     dbuf.reset(bytes, 0, bytes.length);
/* 240 */     StringBuilder buf = new StringBuilder(bytes.length);
/* 241 */     readChars(dbuf, buf, bytes.length);
/* 242 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   public static String readString(DataInput in)
/*     */     throws IOException
/*     */   {
/* 250 */     int bytes = in.readUnsignedShort();
/* 251 */     StringBuilder buffer = new StringBuilder(bytes);
/* 252 */     readChars(in, buffer, bytes);
/* 253 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   private static void readChars(DataInput in, StringBuilder buffer, int nBytes) throws UTFDataFormatException, IOException
/*     */   {
/* 258 */     DataOutputBuffer obuf = (DataOutputBuffer)OBUF_FACTORY.get();
/* 259 */     obuf.reset();
/* 260 */     obuf.write(in, nBytes);
/* 261 */     byte[] bytes = obuf.getData();
/* 262 */     int i = 0;
/* 263 */     while (i < nBytes) {
/* 264 */       byte b = bytes[(i++)];
/* 265 */       if ((b & 0x80) == 0)
/*     */       {
/* 267 */         buffer.append((char)(b & 0x7F));
/* 268 */       } else if ((b & 0xE0) == 192) {
/* 269 */         if (i >= nBytes) {
/* 270 */           throw new UTFDataFormatException(new StringBuilder().append("Truncated UTF8 at ").append(StringUtils.byteToHexString(bytes, i - 1, 1)).toString());
/*     */         }
/*     */ 
/* 274 */         buffer.append((char)((b & 0x1F) << 6 | bytes[(i++)] & 0x3F));
/*     */       }
/* 276 */       else if ((b & 0xF0) == 224)
/*     */       {
/* 278 */         if (i + 1 >= nBytes) {
/* 279 */           throw new UTFDataFormatException(new StringBuilder().append("Truncated UTF8 at ").append(StringUtils.byteToHexString(bytes, i - 1, 2)).toString());
/*     */         }
/*     */ 
/* 282 */         buffer.append((char)((b & 0xF) << 12 | (bytes[(i++)] & 0x3F) << 6 | bytes[(i++)] & 0x3F));
/*     */       }
/* 285 */       else if ((b & 0xF8) == 240) {
/* 286 */         if (i + 2 >= nBytes) {
/* 287 */           throw new UTFDataFormatException(new StringBuilder().append("Truncated UTF8 at ").append(StringUtils.byteToHexString(bytes, i - 1, 3)).toString());
/*     */         }
/*     */ 
/* 291 */         int codepoint = (b & 0x7) << 18 | (bytes[(i++)] & 0x3F) << 12 | (bytes[(i++)] & 0x3F) << 6 | bytes[(i++)] & 0x3F;
/*     */ 
/* 296 */         buffer.append(highSurrogate(codepoint)).append(lowSurrogate(codepoint));
/*     */       }
/*     */       else
/*     */       {
/* 304 */         int endForError = Math.min(i + 5, nBytes);
/* 305 */         throw new UTFDataFormatException(new StringBuilder().append("Invalid UTF8 at ").append(StringUtils.byteToHexString(bytes, i - 1, endForError)).toString());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static char highSurrogate(int codePoint)
/*     */   {
/* 312 */     return (char)((codePoint >>> 10) + 55232);
/*     */   }
/*     */ 
/*     */   private static char lowSurrogate(int codePoint)
/*     */   {
/* 317 */     return (char)((codePoint & 0x3FF) + 56320);
/*     */   }
/*     */ 
/*     */   public static int writeString(DataOutput out, String s)
/*     */     throws IOException
/*     */   {
/* 325 */     if (s.length() > 21845) {
/* 326 */       LOG.warn(new StringBuilder().append("truncating long string: ").append(s.length()).append(" chars, starting with ").append(s.substring(0, 20)).toString());
/*     */ 
/* 328 */       s = s.substring(0, 21845);
/*     */     }
/*     */ 
/* 331 */     int len = utf8Length(s);
/* 332 */     if (len > 65535) {
/* 333 */       throw new IOException("string too long!");
/*     */     }
/* 335 */     out.writeShort(len);
/* 336 */     writeChars(out, s, 0, s.length());
/* 337 */     return len;
/*     */   }
/*     */ 
/*     */   private static int utf8Length(String string)
/*     */   {
/* 342 */     int stringLength = string.length();
/* 343 */     int utf8Length = 0;
/* 344 */     for (int i = 0; i < stringLength; i++) {
/* 345 */       int c = string.charAt(i);
/* 346 */       if (c <= 127)
/* 347 */         utf8Length++;
/* 348 */       else if (c > 2047)
/* 349 */         utf8Length += 3;
/*     */       else {
/* 351 */         utf8Length += 2;
/*     */       }
/*     */     }
/* 354 */     return utf8Length;
/*     */   }
/*     */ 
/*     */   private static void writeChars(DataOutput out, String s, int start, int length)
/*     */     throws IOException
/*     */   {
/* 360 */     int end = start + length;
/* 361 */     for (int i = start; i < end; i++) {
/* 362 */       int code = s.charAt(i);
/* 363 */       if (code <= 127) {
/* 364 */         out.writeByte((byte)code);
/* 365 */       } else if (code <= 2047) {
/* 366 */         out.writeByte((byte)(0xC0 | code >> 6 & 0x1F));
/* 367 */         out.writeByte((byte)(0x80 | code & 0x3F));
/*     */       } else {
/* 369 */         out.writeByte((byte)(0xE0 | code >> 12 & 0xF));
/* 370 */         out.writeByte((byte)(0x80 | code >> 6 & 0x3F));
/* 371 */         out.writeByte((byte)(0x80 | code & 0x3F));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 209 */     WritableComparator.define(UTF8.class, new Comparator());
/*     */   }
/*     */ 
/*     */   public static class Comparator extends WritableComparator
/*     */   {
/*     */     public Comparator()
/*     */     {
/* 196 */       super();
/*     */     }
/*     */ 
/*     */     public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2)
/*     */     {
/* 202 */       int n1 = readUnsignedShort(b1, s1);
/* 203 */       int n2 = readUnsignedShort(b2, s2);
/* 204 */       return compareBytes(b1, s1 + 2, n1, b2, s2 + 2, n2);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.UTF8
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileDescriptor;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FileStatus;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.LocalFileSystem;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.io.nativeio.Errno;
/*     */ import org.apache.hadoop.io.nativeio.NativeIO;
/*     */ import org.apache.hadoop.io.nativeio.NativeIOException;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ 
/*     */ public class SecureIOUtils
/*     */ {
/*  86 */   private static final boolean skipSecurity = !canBeSecure;
/*     */   private static final FileSystem rawFilesystem;
/*     */ 
/*     */   public static FileInputStream openForRead(File f, String expectedOwner)
/*     */     throws IOException
/*     */   {
/* 102 */     FileInputStream fis = new FileInputStream(f);
/* 103 */     if (expectedOwner == null) {
/* 104 */       return fis;
/*     */     }
/* 106 */     if (skipSecurity)
/*     */     {
/* 108 */       FileStatus status = rawFilesystem.getFileStatus(new Path(f.getAbsolutePath()));
/*     */ 
/* 110 */       checkStat(f, status.getOwner(), expectedOwner);
/* 111 */       return fis;
/*     */     }
/*     */ 
/* 114 */     boolean success = false;
/*     */     try {
/* 116 */       String owner = NativeIO.getOwner(fis.getFD());
/* 117 */       checkStat(f, owner, expectedOwner);
/* 118 */       success = true;
/* 119 */       return fis;
/*     */     } finally {
/* 121 */       if (!success) fis.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static FileOutputStream insecureCreateForWrite(File f, int permissions)
/*     */     throws IOException
/*     */   {
/* 129 */     if (f.exists()) {
/* 130 */       throw new AlreadyExistsException("File " + f + " already exists");
/*     */     }
/* 132 */     FileOutputStream fos = new FileOutputStream(f);
/* 133 */     boolean success = false;
/*     */     try {
/* 135 */       rawFilesystem.setPermission(new Path(f.getAbsolutePath()), new FsPermission((short)permissions));
/*     */ 
/* 137 */       success = true;
/* 138 */       return fos;
/*     */     } finally {
/* 140 */       if (!success)
/* 141 */         fos.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static FileOutputStream createForWrite(File f, int permissions)
/*     */     throws IOException
/*     */   {
/* 156 */     if (skipSecurity) {
/* 157 */       return insecureCreateForWrite(f, permissions);
/*     */     }
/*     */     try
/*     */     {
/* 161 */       FileDescriptor fd = NativeIO.open(f.getAbsolutePath(), 193, permissions);
/*     */ 
/* 164 */       return new FileOutputStream(fd);
/*     */     } catch (NativeIOException nioe) {
/* 166 */       if (nioe.getErrno() == Errno.EEXIST) {
/* 167 */         throw new AlreadyExistsException(nioe);
/*     */       }
/* 169 */       throw nioe;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void checkStat(File f, String owner, String expectedOwner) throws IOException
/*     */   {
/* 175 */     if ((expectedOwner != null) && (!expectedOwner.equals(owner)))
/*     */     {
/* 177 */       throw new IOException("Owner '" + owner + "' for path " + f + " did not match " + "expected owner '" + expectedOwner + "'");
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  67 */     boolean shouldBeSecure = UserGroupInformation.isSecurityEnabled();
/*  68 */     boolean canBeSecure = NativeIO.isAvailable();
/*     */ 
/*  70 */     if ((!canBeSecure) && (shouldBeSecure)) {
/*  71 */       throw new RuntimeException("Secure IO is not possible without native code extensions.");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  78 */       rawFilesystem = FileSystem.getLocal(new Configuration()).getRaw();
/*     */     } catch (IOException ie) {
/*  80 */       throw new RuntimeException("Couldn't obtain an instance of RawLocalFileSystem.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class AlreadyExistsException extends IOException
/*     */   {
/*     */     private static final long serialVersionUID = -6615764817774423232L;
/*     */ 
/*     */     public AlreadyExistsException(String msg)
/*     */     {
/* 190 */       super();
/*     */     }
/*     */ 
/*     */     public AlreadyExistsException(Throwable cause) {
/* 194 */       super();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.SecureIOUtils
 * JD-Core Version:    0.6.1
 */
package org.apache.hadoop.io;

public abstract interface WritableComparable<T> extends Writable, Comparable<T>
{
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.WritableComparable
 * JD-Core Version:    0.6.1
 */
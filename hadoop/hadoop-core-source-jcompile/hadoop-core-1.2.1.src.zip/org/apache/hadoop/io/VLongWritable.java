/*    */ package org.apache.hadoop.io;
/*    */ 
/*    */ import java.io.DataInput;
/*    */ import java.io.DataOutput;
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class VLongWritable
/*    */   implements WritableComparable
/*    */ {
/*    */   private long value;
/*    */ 
/*    */   public VLongWritable()
/*    */   {
/*    */   }
/*    */ 
/*    */   public VLongWritable(long value)
/*    */   {
/* 33 */     set(value);
/*    */   }
/*    */   public void set(long value) {
/* 36 */     this.value = value;
/*    */   }
/*    */   public long get() {
/* 39 */     return this.value;
/*    */   }
/*    */   public void readFields(DataInput in) throws IOException {
/* 42 */     this.value = WritableUtils.readVLong(in);
/*    */   }
/*    */ 
/*    */   public void write(DataOutput out) throws IOException {
/* 46 */     WritableUtils.writeVLong(out, this.value);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 51 */     if (!(o instanceof VLongWritable))
/* 52 */       return false;
/* 53 */     VLongWritable other = (VLongWritable)o;
/* 54 */     return this.value == other.value;
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 58 */     return (int)this.value;
/*    */   }
/*    */ 
/*    */   public int compareTo(Object o)
/*    */   {
/* 63 */     long thisValue = this.value;
/* 64 */     long thatValue = ((VLongWritable)o).value;
/* 65 */     return thisValue == thatValue ? 0 : thisValue < thatValue ? -1 : 1;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 69 */     return Long.toString(this.value);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.VLongWritable
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.io;
/*    */ 
/*    */ import java.io.DataInput;
/*    */ import java.io.DataOutput;
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Array;
/*    */ 
/*    */ public class TwoDArrayWritable
/*    */   implements Writable
/*    */ {
/*    */   private Class valueClass;
/*    */   private Writable[][] values;
/*    */ 
/*    */   public TwoDArrayWritable(Class valueClass)
/*    */   {
/* 30 */     this.valueClass = valueClass;
/*    */   }
/*    */ 
/*    */   public TwoDArrayWritable(Class valueClass, Writable[][] values) {
/* 34 */     this(valueClass);
/* 35 */     this.values = values;
/*    */   }
/*    */ 
/*    */   public Object toArray() {
/* 39 */     int[] dimensions = { this.values.length, 0 };
/* 40 */     Object result = Array.newInstance(this.valueClass, dimensions);
/* 41 */     for (int i = 0; i < this.values.length; i++) {
/* 42 */       Object resultRow = Array.newInstance(this.valueClass, this.values[i].length);
/* 43 */       Array.set(result, i, resultRow);
/* 44 */       for (int j = 0; j < this.values[i].length; j++) {
/* 45 */         Array.set(resultRow, j, this.values[i][j]);
/*    */       }
/*    */     }
/* 48 */     return result;
/*    */   }
/*    */   public void set(Writable[][] values) {
/* 51 */     this.values = values;
/*    */   }
/* 53 */   public Writable[][] get() { return this.values; }
/*    */ 
/*    */   public void readFields(DataInput in) throws IOException
/*    */   {
/* 57 */     this.values = new Writable[in.readInt()][];
/* 58 */     for (int i = 0; i < this.values.length; i++) {
/* 59 */       this.values[i] = new Writable[in.readInt()];
/*    */     }
/*    */ 
/* 63 */     for (int i = 0; i < this.values.length; i++)
/* 64 */       for (int j = 0; j < this.values[i].length; j++) {
/*    */         Writable value;
/*    */         try {
/* 67 */           value = (Writable)this.valueClass.newInstance();
/*    */         } catch (InstantiationException e) {
/* 69 */           throw new RuntimeException(e.toString());
/*    */         } catch (IllegalAccessException e) {
/* 71 */           throw new RuntimeException(e.toString());
/*    */         }
/* 73 */         value.readFields(in);
/* 74 */         this.values[i][j] = value;
/*    */       }
/*    */   }
/*    */ 
/*    */   public void write(DataOutput out) throws IOException
/*    */   {
/* 80 */     out.writeInt(this.values.length);
/* 81 */     for (int i = 0; i < this.values.length; i++) {
/* 82 */       out.writeInt(this.values[i].length);
/*    */     }
/* 84 */     for (int i = 0; i < this.values.length; i++)
/* 85 */       for (int j = 0; j < this.values[i].length; j++)
/* 86 */         this.values[i][j].write(out);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.TwoDArrayWritable
 * JD-Core Version:    0.6.1
 */
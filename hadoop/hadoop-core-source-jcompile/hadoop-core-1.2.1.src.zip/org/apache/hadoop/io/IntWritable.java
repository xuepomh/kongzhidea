/*    */ package org.apache.hadoop.io;
/*    */ 
/*    */ import java.io.DataInput;
/*    */ import java.io.DataOutput;
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class IntWritable
/*    */   implements WritableComparable
/*    */ {
/*    */   private int value;
/*    */ 
/*    */   public IntWritable()
/*    */   {
/*    */   }
/*    */ 
/*    */   public IntWritable(int value)
/*    */   {
/* 29 */     set(value);
/*    */   }
/*    */   public void set(int value) {
/* 32 */     this.value = value;
/*    */   }
/*    */   public int get() {
/* 35 */     return this.value;
/*    */   }
/*    */   public void readFields(DataInput in) throws IOException {
/* 38 */     this.value = in.readInt();
/*    */   }
/*    */ 
/*    */   public void write(DataOutput out) throws IOException {
/* 42 */     out.writeInt(this.value);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 47 */     if (!(o instanceof IntWritable))
/* 48 */       return false;
/* 49 */     IntWritable other = (IntWritable)o;
/* 50 */     return this.value == other.value;
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 54 */     return this.value;
/*    */   }
/*    */ 
/*    */   public int compareTo(Object o)
/*    */   {
/* 59 */     int thisValue = this.value;
/* 60 */     int thatValue = ((IntWritable)o).value;
/* 61 */     return thisValue == thatValue ? 0 : thisValue < thatValue ? -1 : 1;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 65 */     return Integer.toString(this.value);
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 83 */     WritableComparator.define(IntWritable.class, new Comparator());
/*    */   }
/*    */ 
/*    */   public static class Comparator extends WritableComparator
/*    */   {
/*    */     public Comparator()
/*    */     {
/* 71 */       super();
/*    */     }
/*    */ 
/*    */     public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2)
/*    */     {
/* 76 */       int thisValue = readInt(b1, s1);
/* 77 */       int thatValue = readInt(b2, s2);
/* 78 */       return thisValue == thatValue ? 0 : thisValue < thatValue ? -1 : 1;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.IntWritable
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.io;
/*    */ 
/*    */ import java.io.DataInput;
/*    */ import java.io.DataOutput;
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class ByteWritable
/*    */   implements WritableComparable
/*    */ {
/*    */   private byte value;
/*    */ 
/*    */   public ByteWritable()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ByteWritable(byte value)
/*    */   {
/* 29 */     set(value);
/*    */   }
/*    */   public void set(byte value) {
/* 32 */     this.value = value;
/*    */   }
/*    */   public byte get() {
/* 35 */     return this.value;
/*    */   }
/*    */   public void readFields(DataInput in) throws IOException {
/* 38 */     this.value = in.readByte();
/*    */   }
/*    */ 
/*    */   public void write(DataOutput out) throws IOException {
/* 42 */     out.writeByte(this.value);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 47 */     if (!(o instanceof ByteWritable)) {
/* 48 */       return false;
/*    */     }
/* 50 */     ByteWritable other = (ByteWritable)o;
/* 51 */     return this.value == other.value;
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 55 */     return this.value;
/*    */   }
/*    */ 
/*    */   public int compareTo(Object o)
/*    */   {
/* 60 */     int thisValue = this.value;
/* 61 */     int thatValue = ((ByteWritable)o).value;
/* 62 */     return thisValue == thatValue ? 0 : thisValue < thatValue ? -1 : 1;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 66 */     return Byte.toString(this.value);
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 84 */     WritableComparator.define(ByteWritable.class, new Comparator());
/*    */   }
/*    */ 
/*    */   public static class Comparator extends WritableComparator
/*    */   {
/*    */     public Comparator()
/*    */     {
/* 72 */       super();
/*    */     }
/*    */ 
/*    */     public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2)
/*    */     {
/* 77 */       byte thisValue = b1[s1];
/* 78 */       byte thatValue = b2[s2];
/* 79 */       return thisValue == thatValue ? 0 : thisValue < thatValue ? -1 : 1;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.ByteWritable
 * JD-Core Version:    0.6.1
 */
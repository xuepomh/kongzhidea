/*    */ package org.apache.hadoop.io;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.FilterOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ public class OutputBuffer extends FilterOutputStream
/*    */ {
/*    */   private Buffer buffer;
/*    */ 
/*    */   public OutputBuffer()
/*    */   {
/* 66 */     this(new Buffer(null));
/*    */   }
/*    */ 
/*    */   private OutputBuffer(Buffer buffer) {
/* 70 */     super(buffer);
/* 71 */     this.buffer = buffer;
/*    */   }
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 77 */     return this.buffer.getData();
/*    */   }
/*    */   public int getLength() {
/* 80 */     return this.buffer.getLength();
/*    */   }
/*    */ 
/*    */   public OutputBuffer reset() {
/* 84 */     this.buffer.reset();
/* 85 */     return this;
/*    */   }
/*    */ 
/*    */   public void write(InputStream in, int length) throws IOException
/*    */   {
/* 90 */     this.buffer.write(in, length);
/*    */   }
/*    */ 
/*    */   private static class Buffer extends ByteArrayOutputStream
/*    */   {
/*    */     public byte[] getData()
/*    */     {
/* 46 */       return this.buf; } 
/* 47 */     public int getLength() { return this.count; } 
/* 48 */     public void reset() { this.count = 0; }
/*    */ 
/*    */     public void write(InputStream in, int len) throws IOException {
/* 51 */       int newcount = this.count + len;
/* 52 */       if (newcount > this.buf.length) {
/* 53 */         byte[] newbuf = new byte[Math.max(this.buf.length << 1, newcount)];
/* 54 */         System.arraycopy(this.buf, 0, newbuf, 0, this.count);
/* 55 */         this.buf = newbuf;
/*    */       }
/* 57 */       IOUtils.readFully(in, this.buf, this.count, len);
/* 58 */       this.count = newcount;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.OutputBuffer
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.io;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.conf.Configurable;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.util.ReflectionUtils;
/*     */ 
/*     */ public abstract class GenericWritable
/*     */   implements Writable, Configurable
/*     */ {
/*     */   private static final byte NOT_SET = -1;
/*  80 */   private byte type = -1;
/*     */   private Writable instance;
/*  84 */   private Configuration conf = null;
/*     */ 
/*     */   public void set(Writable obj)
/*     */   {
/*  92 */     this.instance = obj;
/*  93 */     Class instanceClazz = this.instance.getClass();
/*  94 */     Class[] clazzes = getTypes();
/*  95 */     for (int i = 0; i < clazzes.length; i++) {
/*  96 */       Class clazz = clazzes[i];
/*  97 */       if (clazz.equals(instanceClazz)) {
/*  98 */         this.type = (byte)i;
/*  99 */         return;
/*     */       }
/*     */     }
/* 102 */     throw new RuntimeException(new StringBuilder().append("The type of instance is: ").append(this.instance.getClass()).append(", which is NOT registered.").toString());
/*     */   }
/*     */ 
/*     */   public Writable get()
/*     */   {
/* 110 */     return this.instance;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 114 */     return new StringBuilder().append("GW[").append(this.instance != null ? new StringBuilder().append("class=").append(this.instance.getClass().getName()).append(",value=").append(this.instance.toString()).toString() : "(null)").append("]").toString();
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException
/*     */   {
/* 119 */     this.type = in.readByte();
/* 120 */     Class clazz = getTypes()[(this.type & 0xFF)];
/*     */     try {
/* 122 */       this.instance = ((Configurable)ReflectionUtils.newInstance(clazz, this.conf));
/*     */     } catch (Exception e) {
/* 124 */       e.printStackTrace();
/* 125 */       throw new IOException(new StringBuilder().append("Cannot initialize the class: ").append(clazz).toString());
/*     */     }
/* 127 */     this.instance.readFields(in);
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out) throws IOException {
/* 131 */     if ((this.type == -1) || (this.instance == null)) {
/* 132 */       throw new IOException(new StringBuilder().append("The GenericWritable has NOT been set correctly. type=").append(this.type).append(", instance=").append(this.instance).toString());
/*     */     }
/* 134 */     out.writeByte(this.type);
/* 135 */     this.instance.write(out);
/*     */   }
/*     */ 
/*     */   protected abstract Class<? extends Writable>[] getTypes();
/*     */ 
/*     */   public Configuration getConf()
/*     */   {
/* 145 */     return this.conf;
/*     */   }
/*     */ 
/*     */   public void setConf(Configuration conf) {
/* 149 */     this.conf = conf;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.GenericWritable
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.io;
/*    */ 
/*    */ import java.io.DataInput;
/*    */ import java.io.DataOutput;
/*    */ import java.io.IOException;
/*    */ 
/*    */ public abstract class VersionedWritable
/*    */   implements Writable
/*    */ {
/*    */   public abstract byte getVersion();
/*    */ 
/*    */   public void write(DataOutput out)
/*    */     throws IOException
/*    */   {
/* 39 */     out.writeByte(getVersion());
/*    */   }
/*    */ 
/*    */   public void readFields(DataInput in) throws IOException
/*    */   {
/* 44 */     byte version = in.readByte();
/* 45 */     if (version != getVersion())
/* 46 */       throw new VersionMismatchException(getVersion(), version);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.VersionedWritable
 * JD-Core Version:    0.6.1
 */
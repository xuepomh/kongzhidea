/*     */ package org.apache.hadoop.io;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ public class BooleanWritable
/*     */   implements WritableComparable
/*     */ {
/*     */   private boolean value;
/*     */ 
/*     */   public BooleanWritable()
/*     */   {
/*     */   }
/*     */ 
/*     */   public BooleanWritable(boolean value)
/*     */   {
/*  36 */     set(value);
/*     */   }
/*     */ 
/*     */   public void set(boolean value)
/*     */   {
/*  43 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public boolean get()
/*     */   {
/*  50 */     return this.value;
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in)
/*     */     throws IOException
/*     */   {
/*  56 */     this.value = in.readBoolean();
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/*  62 */     out.writeBoolean(this.value);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/*  68 */     if (!(o instanceof BooleanWritable)) {
/*  69 */       return false;
/*     */     }
/*  71 */     BooleanWritable other = (BooleanWritable)o;
/*  72 */     return this.value == other.value;
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/*  76 */     return this.value ? 0 : 1;
/*     */   }
/*     */ 
/*     */   public int compareTo(Object o)
/*     */   {
/*  84 */     boolean a = this.value;
/*  85 */     boolean b = ((BooleanWritable)o).value;
/*  86 */     return !a ? -1 : a == b ? 0 : 1;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  90 */     return Boolean.toString(get());
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 111 */     WritableComparator.define(BooleanWritable.class, new Comparator());
/*     */   }
/*     */ 
/*     */   public static class Comparator extends WritableComparator
/*     */   {
/*     */     public Comparator()
/*     */     {
/*  98 */       super();
/*     */     }
/*     */ 
/*     */     public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2)
/*     */     {
/* 103 */       boolean a = readInt(b1, s1) == 1;
/* 104 */       boolean b = readInt(b2, s2) == 1;
/* 105 */       return !a ? -1 : a == b ? 0 : 1;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.BooleanWritable
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.io;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.io.compress.CompressionCodec;
/*     */ import org.apache.hadoop.io.compress.DefaultCodec;
/*     */ import org.apache.hadoop.util.Progressable;
/*     */ import org.apache.hadoop.util.ReflectionUtils;
/*     */ 
/*     */ public class MapFile
/*     */ {
/*  50 */   private static final Log LOG = LogFactory.getLog(MapFile.class);
/*     */   public static final String INDEX_FILE_NAME = "index";
/*     */   public static final String DATA_FILE_NAME = "data";
/*     */ 
/*     */   public static void rename(FileSystem fs, String oldName, String newName)
/*     */     throws IOException
/*     */   {
/* 586 */     Path oldDir = new Path(oldName);
/* 587 */     Path newDir = new Path(newName);
/* 588 */     if (!fs.rename(oldDir, newDir))
/* 589 */       throw new IOException("Could not rename " + oldDir + " to " + newDir);
/*     */   }
/*     */ 
/*     */   public static void delete(FileSystem fs, String name)
/*     */     throws IOException
/*     */   {
/* 595 */     Path dir = new Path(name);
/* 596 */     Path data = new Path(dir, "data");
/* 597 */     Path index = new Path(dir, "index");
/*     */ 
/* 599 */     fs.delete(data, true);
/* 600 */     fs.delete(index, true);
/* 601 */     fs.delete(dir, true);
/*     */   }
/*     */ 
/*     */   public static long fix(FileSystem fs, Path dir, Class<? extends Writable> keyClass, Class<? extends Writable> valueClass, boolean dryrun, Configuration conf)
/*     */     throws Exception
/*     */   {
/* 618 */     String dr = dryrun ? "[DRY RUN ] " : "";
/* 619 */     Path data = new Path(dir, "data");
/* 620 */     Path index = new Path(dir, "index");
/* 621 */     int indexInterval = 128;
/* 622 */     if (!fs.exists(data))
/*     */     {
/* 624 */       throw new Exception(dr + "Missing data file in " + dir + ", impossible to fix this.");
/*     */     }
/* 626 */     if (fs.exists(index))
/*     */     {
/* 628 */       return -1L;
/*     */     }
/* 630 */     SequenceFile.Reader dataReader = new SequenceFile.Reader(fs, data, conf);
/* 631 */     if (!dataReader.getKeyClass().equals(keyClass)) {
/* 632 */       throw new Exception(dr + "Wrong key class in " + dir + ", expected" + keyClass.getName() + ", got " + dataReader.getKeyClass().getName());
/*     */     }
/*     */ 
/* 635 */     if (!dataReader.getValueClass().equals(valueClass)) {
/* 636 */       throw new Exception(dr + "Wrong value class in " + dir + ", expected" + valueClass.getName() + ", got " + dataReader.getValueClass().getName());
/*     */     }
/*     */ 
/* 639 */     long cnt = 0L;
/* 640 */     Writable key = (Writable)ReflectionUtils.newInstance(keyClass, conf);
/* 641 */     Writable value = (Writable)ReflectionUtils.newInstance(valueClass, conf);
/* 642 */     SequenceFile.Writer indexWriter = null;
/* 643 */     if (!dryrun) indexWriter = SequenceFile.createWriter(fs, conf, index, keyClass, LongWritable.class); try
/*     */     {
/* 645 */       long pos = 0L;
/* 646 */       LongWritable position = new LongWritable();
/* 647 */       while (dataReader.next(key, value)) {
/* 648 */         cnt += 1L;
/* 649 */         if (cnt % indexInterval == 0L) {
/* 650 */           position.set(pos);
/* 651 */           if (!dryrun) indexWriter.append(key, position);
/*     */         }
/* 653 */         pos = dataReader.getPosition();
/*     */       }
/*     */     }
/*     */     catch (Throwable t) {
/*     */     }
/* 658 */     dataReader.close();
/* 659 */     if (!dryrun) indexWriter.close();
/* 660 */     return cnt;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception
/*     */   {
/* 665 */     String usage = "Usage: MapFile inFile outFile";
/*     */ 
/* 667 */     if (args.length != 2) {
/* 668 */       System.err.println(usage);
/* 669 */       System.exit(-1);
/*     */     }
/*     */ 
/* 672 */     String in = args[0];
/* 673 */     String out = args[1];
/*     */ 
/* 675 */     Configuration conf = new Configuration();
/* 676 */     FileSystem fs = FileSystem.getLocal(conf);
/* 677 */     Reader reader = new Reader(fs, in, conf);
/* 678 */     Writer writer = new Writer(conf, fs, out, reader.getKeyClass().asSubclass(WritableComparable.class), reader.getValueClass());
/*     */ 
/* 683 */     WritableComparable key = (WritableComparable)ReflectionUtils.newInstance(reader.getKeyClass().asSubclass(WritableComparable.class), conf);
/*     */ 
/* 685 */     Writable value = (Writable)ReflectionUtils.newInstance(reader.getValueClass().asSubclass(Writable.class), conf);
/*     */ 
/* 688 */     while (reader.next(key, value)) {
/* 689 */       writer.append(key, value);
/*     */     }
/* 691 */     writer.close();
/*     */   }
/*     */ 
/*     */   public static class Reader
/*     */     implements Closeable
/*     */   {
/* 224 */     private int INDEX_SKIP = 0;
/*     */     private WritableComparator comparator;
/*     */     private WritableComparable nextKey;
/* 229 */     private long seekPosition = -1L;
/* 230 */     private int seekIndex = -1;
/*     */     private long firstPosition;
/*     */     private SequenceFile.Reader data;
/*     */     private SequenceFile.Reader index;
/* 238 */     private boolean indexClosed = false;
/*     */ 
/* 241 */     private int count = -1;
/*     */     private WritableComparable[] keys;
/*     */     private long[] positions;
/*     */ 
/*     */     public Class<?> getKeyClass()
/*     */     {
/* 246 */       return this.data.getKeyClass();
/*     */     }
/*     */     public Class<?> getValueClass() {
/* 249 */       return this.data.getValueClass();
/*     */     }
/*     */ 
/*     */     public Reader(FileSystem fs, String dirName, Configuration conf) throws IOException {
/* 253 */       this(fs, dirName, null, conf);
/* 254 */       this.INDEX_SKIP = conf.getInt("io.map.index.skip", 0);
/*     */     }
/*     */ 
/*     */     public Reader(FileSystem fs, String dirName, WritableComparator comparator, Configuration conf)
/*     */       throws IOException
/*     */     {
/* 260 */       this(fs, dirName, comparator, conf, true);
/*     */     }
/*     */ 
/*     */     protected Reader(FileSystem fs, String dirName, WritableComparator comparator, Configuration conf, boolean open)
/*     */       throws IOException
/*     */     {
/* 272 */       if (open)
/* 273 */         open(fs, dirName, comparator, conf);
/*     */     }
/*     */ 
/*     */     protected synchronized void open(FileSystem fs, String dirName, WritableComparator comparator, Configuration conf)
/*     */       throws IOException
/*     */     {
/* 279 */       Path dir = new Path(dirName);
/* 280 */       Path dataFile = new Path(dir, "data");
/* 281 */       Path indexFile = new Path(dir, "index");
/*     */ 
/* 284 */       this.data = createDataFileReader(fs, dataFile, conf);
/* 285 */       this.firstPosition = this.data.getPosition();
/*     */ 
/* 287 */       if (comparator == null)
/* 288 */         this.comparator = WritableComparator.get(this.data.getKeyClass().asSubclass(WritableComparable.class));
/*     */       else {
/* 290 */         this.comparator = comparator;
/*     */       }
/*     */ 
/* 293 */       this.index = new SequenceFile.Reader(fs, indexFile, conf);
/*     */     }
/*     */ 
/*     */     protected SequenceFile.Reader createDataFileReader(FileSystem fs, Path dataFile, Configuration conf)
/*     */       throws IOException
/*     */     {
/* 302 */       return new SequenceFile.Reader(fs, dataFile, conf);
/*     */     }
/*     */ 
/*     */     private void readIndex() throws IOException
/*     */     {
/* 307 */       if (this.keys != null)
/* 308 */         return;
/* 309 */       this.count = 0;
/* 310 */       this.keys = new WritableComparable[1024];
/* 311 */       this.positions = new long[1024];
/*     */       try {
/* 313 */         int skip = this.INDEX_SKIP;
/* 314 */         LongWritable position = new LongWritable();
/* 315 */         WritableComparable lastKey = null;
/*     */         while (true) {
/* 317 */           WritableComparable k = this.comparator.newKey();
/*     */ 
/* 319 */           if (!this.index.next(k, position))
/*     */           {
/*     */             break;
/*     */           }
/* 323 */           if ((lastKey != null) && (this.comparator.compare(lastKey, k) > 0))
/* 324 */             throw new IOException("key out of order: " + k + " after " + lastKey);
/* 325 */           lastKey = k;
/*     */ 
/* 327 */           if (skip > 0) {
/* 328 */             skip--;
/*     */           }
/*     */           else {
/* 331 */             skip = this.INDEX_SKIP;
/*     */ 
/* 334 */             if (this.count == this.keys.length) {
/* 335 */               int newLength = this.keys.length * 3 / 2;
/* 336 */               WritableComparable[] newKeys = new WritableComparable[newLength];
/* 337 */               long[] newPositions = new long[newLength];
/* 338 */               System.arraycopy(this.keys, 0, newKeys, 0, this.count);
/* 339 */               System.arraycopy(this.positions, 0, newPositions, 0, this.count);
/* 340 */               this.keys = newKeys;
/* 341 */               this.positions = newPositions;
/*     */             }
/*     */ 
/* 344 */             this.keys[this.count] = k;
/* 345 */             this.positions[this.count] = position.get();
/* 346 */             this.count += 1;
/*     */           }
/*     */         }
/*     */       } catch (EOFException e) { MapFile.LOG.warn("Unexpected EOF reading " + this.index + " at entry #" + this.count + ".  Ignoring.");
/*     */       } finally
/*     */       {
/* 352 */         this.indexClosed = true;
/* 353 */         this.index.close();
/*     */       }
/*     */     }
/*     */ 
/*     */     public synchronized void reset() throws IOException
/*     */     {
/* 359 */       this.data.seek(this.firstPosition);
/*     */     }
/*     */ 
/*     */     public synchronized WritableComparable midKey()
/*     */       throws IOException
/*     */     {
/* 368 */       readIndex();
/* 369 */       int pos = (this.count - 1) / 2;
/* 370 */       if (pos < 0) {
/* 371 */         throw new IOException("MapFile empty");
/*     */       }
/*     */ 
/* 374 */       return this.keys[pos];
/*     */     }
/*     */ 
/*     */     public synchronized void finalKey(WritableComparable key)
/*     */       throws IOException
/*     */     {
/* 384 */       long originalPosition = this.data.getPosition();
/*     */       try {
/* 386 */         readIndex();
/* 387 */         if (this.count > 0)
/* 388 */           this.data.seek(this.positions[(this.count - 1)]);
/*     */         else {
/* 390 */           reset();
/*     */         }
/* 392 */         while (this.data.next(key));
/*     */       }
/*     */       finally {
/* 395 */         this.data.seek(originalPosition);
/*     */       }
/*     */     }
/*     */ 
/*     */     public synchronized boolean seek(WritableComparable key)
/*     */       throws IOException
/*     */     {
/* 404 */       return seekInternal(key) == 0;
/*     */     }
/*     */ 
/*     */     private synchronized int seekInternal(WritableComparable key)
/*     */       throws IOException
/*     */     {
/* 417 */       return seekInternal(key, false);
/*     */     }
/*     */ 
/*     */     private synchronized int seekInternal(WritableComparable key, boolean before)
/*     */       throws IOException
/*     */     {
/* 435 */       readIndex();
/*     */ 
/* 437 */       if ((this.seekIndex == -1) || (this.seekIndex + 1 >= this.count) || (this.comparator.compare(key, this.keys[(this.seekIndex + 1)]) >= 0) || (this.comparator.compare(key, this.nextKey) < 0))
/*     */       {
/* 444 */         this.seekIndex = binarySearch(key);
/* 445 */         if (this.seekIndex < 0) {
/* 446 */           this.seekIndex = (-this.seekIndex - 2);
/*     */         }
/* 448 */         if (this.seekIndex == -1)
/* 449 */           this.seekPosition = this.firstPosition;
/*     */         else
/* 451 */           this.seekPosition = this.positions[this.seekIndex];
/*     */       }
/* 453 */       this.data.seek(this.seekPosition);
/*     */ 
/* 455 */       if (this.nextKey == null) {
/* 456 */         this.nextKey = this.comparator.newKey();
/*     */       }
/*     */ 
/* 461 */       long prevPosition = -1L;
/* 462 */       long curPosition = this.seekPosition;
/*     */ 
/* 464 */       while (this.data.next(this.nextKey)) {
/* 465 */         int c = this.comparator.compare(key, this.nextKey);
/* 466 */         if (c <= 0) {
/* 467 */           if ((before) && (c != 0)) {
/* 468 */             if (prevPosition == -1L)
/*     */             {
/* 473 */               this.data.seek(curPosition);
/*     */             }
/*     */             else {
/* 476 */               this.data.seek(prevPosition);
/* 477 */               this.data.next(this.nextKey);
/*     */ 
/* 479 */               return 1;
/*     */             }
/*     */           }
/* 482 */           return c;
/*     */         }
/* 484 */         if (before) {
/* 485 */           prevPosition = curPosition;
/* 486 */           curPosition = this.data.getPosition();
/*     */         }
/*     */       }
/*     */ 
/* 490 */       return 1;
/*     */     }
/*     */ 
/*     */     private int binarySearch(WritableComparable key) {
/* 494 */       int low = 0;
/* 495 */       int high = this.count - 1;
/*     */ 
/* 497 */       while (low <= high) {
/* 498 */         int mid = low + high >>> 1;
/* 499 */         WritableComparable midVal = this.keys[mid];
/* 500 */         int cmp = this.comparator.compare(midVal, key);
/*     */ 
/* 502 */         if (cmp < 0)
/* 503 */           low = mid + 1;
/* 504 */         else if (cmp > 0)
/* 505 */           high = mid - 1;
/*     */         else
/* 507 */           return mid;
/*     */       }
/* 509 */       return -(low + 1);
/*     */     }
/*     */ 
/*     */     public synchronized boolean next(WritableComparable key, Writable val)
/*     */       throws IOException
/*     */     {
/* 517 */       return this.data.next(key, val);
/*     */     }
/*     */ 
/*     */     public synchronized Writable get(WritableComparable key, Writable val)
/*     */       throws IOException
/*     */     {
/* 523 */       if (seek(key)) {
/* 524 */         this.data.getCurrentValue(val);
/* 525 */         return val;
/*     */       }
/* 527 */       return null;
/*     */     }
/*     */ 
/*     */     public synchronized WritableComparable getClosest(WritableComparable key, Writable val)
/*     */       throws IOException
/*     */     {
/* 542 */       return getClosest(key, val, false);
/*     */     }
/*     */ 
/*     */     public synchronized WritableComparable getClosest(WritableComparable key, Writable val, boolean before)
/*     */       throws IOException
/*     */     {
/* 559 */       int c = seekInternal(key, before);
/*     */ 
/* 564 */       if (((!before) && (c > 0)) || ((before) && (c < 0)))
/*     */       {
/* 566 */         return null;
/*     */       }
/*     */ 
/* 569 */       this.data.getCurrentValue(val);
/* 570 */       return this.nextKey;
/*     */     }
/*     */ 
/*     */     public synchronized void close() throws IOException
/*     */     {
/* 575 */       if (!this.indexClosed) {
/* 576 */         this.index.close();
/*     */       }
/* 578 */       this.data.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Writer
/*     */     implements Closeable
/*     */   {
/*     */     private SequenceFile.Writer data;
/*     */     private SequenceFile.Writer index;
/*     */     private static final String INDEX_INTERVAL = "io.map.index.interval";
/*  66 */     private int indexInterval = 128;
/*     */     private long size;
/*  69 */     private LongWritable position = new LongWritable();
/*     */     private WritableComparator comparator;
/*  73 */     private DataInputBuffer inBuf = new DataInputBuffer();
/*  74 */     private DataOutputBuffer outBuf = new DataOutputBuffer();
/*     */     private WritableComparable lastKey;
/*     */ 
/*     */     public Writer(Configuration conf, FileSystem fs, String dirName, Class<? extends WritableComparable> keyClass, Class valClass)
/*     */       throws IOException
/*     */     {
/*  82 */       this(conf, fs, dirName, WritableComparator.get(keyClass), valClass, SequenceFile.getCompressionType(conf));
/*     */     }
/*     */ 
/*     */     public Writer(Configuration conf, FileSystem fs, String dirName, Class<? extends WritableComparable> keyClass, Class valClass, SequenceFile.CompressionType compress, Progressable progress)
/*     */       throws IOException
/*     */     {
/*  92 */       this(conf, fs, dirName, WritableComparator.get(keyClass), valClass, compress, progress);
/*     */     }
/*     */ 
/*     */     public Writer(Configuration conf, FileSystem fs, String dirName, Class<? extends WritableComparable> keyClass, Class valClass, SequenceFile.CompressionType compress, CompressionCodec codec, Progressable progress)
/*     */       throws IOException
/*     */     {
/* 102 */       this(conf, fs, dirName, WritableComparator.get(keyClass), valClass, compress, codec, progress);
/*     */     }
/*     */ 
/*     */     public Writer(Configuration conf, FileSystem fs, String dirName, Class<? extends WritableComparable> keyClass, Class valClass, SequenceFile.CompressionType compress)
/*     */       throws IOException
/*     */     {
/* 111 */       this(conf, fs, dirName, WritableComparator.get(keyClass), valClass, compress);
/*     */     }
/*     */ 
/*     */     public Writer(Configuration conf, FileSystem fs, String dirName, WritableComparator comparator, Class valClass)
/*     */       throws IOException
/*     */     {
/* 118 */       this(conf, fs, dirName, comparator, valClass, SequenceFile.getCompressionType(conf));
/*     */     }
/*     */ 
/*     */     public Writer(Configuration conf, FileSystem fs, String dirName, WritableComparator comparator, Class valClass, SequenceFile.CompressionType compress)
/*     */       throws IOException
/*     */     {
/* 126 */       this(conf, fs, dirName, comparator, valClass, compress, null);
/*     */     }
/*     */ 
/*     */     public Writer(Configuration conf, FileSystem fs, String dirName, WritableComparator comparator, Class valClass, SequenceFile.CompressionType compress, Progressable progress)
/*     */       throws IOException
/*     */     {
/* 134 */       this(conf, fs, dirName, comparator, valClass, compress, new DefaultCodec(), progress);
/*     */     }
/*     */ 
/*     */     public Writer(Configuration conf, FileSystem fs, String dirName, WritableComparator comparator, Class valClass, SequenceFile.CompressionType compress, CompressionCodec codec, Progressable progress)
/*     */       throws IOException
/*     */     {
/* 144 */       this.indexInterval = conf.getInt("io.map.index.interval", this.indexInterval);
/*     */ 
/* 146 */       this.comparator = comparator;
/* 147 */       this.lastKey = comparator.newKey();
/*     */ 
/* 149 */       Path dir = new Path(dirName);
/* 150 */       if (!fs.mkdirs(dir)) {
/* 151 */         throw new IOException("Mkdirs failed to create directory " + dir.toString());
/*     */       }
/* 153 */       Path dataFile = new Path(dir, "data");
/* 154 */       Path indexFile = new Path(dir, "index");
/*     */ 
/* 156 */       Class keyClass = comparator.getKeyClass();
/* 157 */       this.data = SequenceFile.createWriter(fs, conf, dataFile, keyClass, valClass, compress, codec, progress);
/*     */ 
/* 160 */       this.index = SequenceFile.createWriter(fs, conf, indexFile, keyClass, LongWritable.class, SequenceFile.CompressionType.BLOCK, progress);
/*     */     }
/*     */ 
/*     */     public int getIndexInterval()
/*     */     {
/* 167 */       return this.indexInterval;
/*     */     }
/*     */ 
/*     */     public void setIndexInterval(int interval)
/*     */     {
/* 172 */       this.indexInterval = interval;
/*     */     }
/*     */ 
/*     */     public static void setIndexInterval(Configuration conf, int interval)
/*     */     {
/* 178 */       conf.setInt("io.map.index.interval", interval);
/*     */     }
/*     */ 
/*     */     public synchronized void close() throws IOException
/*     */     {
/* 183 */       this.data.close();
/* 184 */       this.index.close();
/*     */     }
/*     */ 
/*     */     public synchronized void append(WritableComparable key, Writable val)
/*     */       throws IOException
/*     */     {
/* 192 */       checkKey(key);
/*     */ 
/* 194 */       if (this.size % this.indexInterval == 0L) {
/* 195 */         this.position.set(this.data.getLength());
/* 196 */         this.index.append(key, this.position);
/*     */       }
/*     */ 
/* 199 */       this.data.append(key, val);
/* 200 */       this.size += 1L;
/*     */     }
/*     */ 
/*     */     private void checkKey(WritableComparable key) throws IOException
/*     */     {
/* 205 */       if ((this.size != 0L) && (this.comparator.compare(this.lastKey, key) > 0)) {
/* 206 */         throw new IOException("key out of order: " + key + " after " + this.lastKey);
/*     */       }
/*     */ 
/* 209 */       this.outBuf.reset();
/* 210 */       key.write(this.outBuf);
/*     */ 
/* 212 */       this.inBuf.reset(this.outBuf.getData(), this.outBuf.getLength());
/* 213 */       this.lastKey.readFields(this.inBuf);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.MapFile
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class VersionMismatchException extends IOException
/*    */ {
/*    */   private byte expectedVersion;
/*    */   private byte foundVersion;
/*    */ 
/*    */   public VersionMismatchException(byte expectedVersionIn, byte foundVersionIn)
/*    */   {
/* 32 */     this.expectedVersion = expectedVersionIn;
/* 33 */     this.foundVersion = foundVersionIn;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 38 */     return "A record version mismatch occured. Expecting v" + this.expectedVersion + ", found v" + this.foundVersion;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.VersionMismatchException
 * JD-Core Version:    0.6.1
 */
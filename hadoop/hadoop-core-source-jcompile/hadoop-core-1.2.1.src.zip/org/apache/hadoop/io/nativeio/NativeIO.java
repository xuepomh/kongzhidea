/*     */ package org.apache.hadoop.io.nativeio;
/*     */ 
/*     */ import java.io.FileDescriptor;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.util.NativeCodeLoader;
/*     */ 
/*     */ public class NativeIO
/*     */ {
/*     */   public static final int O_RDONLY = 0;
/*     */   public static final int O_WRONLY = 1;
/*     */   public static final int O_RDWR = 2;
/*     */   public static final int O_CREAT = 64;
/*     */   public static final int O_EXCL = 128;
/*     */   public static final int O_NOCTTY = 256;
/*     */   public static final int O_TRUNC = 512;
/*     */   public static final int O_APPEND = 1024;
/*     */   public static final int O_NONBLOCK = 2048;
/*     */   public static final int O_SYNC = 4096;
/*     */   public static final int O_ASYNC = 8192;
/*     */   public static final int O_FSYNC = 4096;
/*     */   public static final int O_NDELAY = 2048;
/*     */   public static final int POSIX_FADV_NORMAL = 0;
/*     */   public static final int POSIX_FADV_RANDOM = 1;
/*     */   public static final int POSIX_FADV_SEQUENTIAL = 2;
/*     */   public static final int POSIX_FADV_WILLNEED = 3;
/*     */   public static final int POSIX_FADV_DONTNEED = 4;
/*     */   public static final int POSIX_FADV_NOREUSE = 5;
/*     */   public static final int SYNC_FILE_RANGE_WAIT_BEFORE = 1;
/*     */   public static final int SYNC_FILE_RANGE_WRITE = 2;
/*     */   public static final int SYNC_FILE_RANGE_WAIT_AFTER = 4;
/*  80 */   private static final Log LOG = LogFactory.getLog(NativeIO.class);
/*     */ 
/*  82 */   private static boolean nativeLoaded = false;
/*  83 */   private static boolean fadvisePossible = true;
/*  84 */   private static boolean syncFileRangePossible = true;
/*     */ 
/* 181 */   private static final Map<Long, CachedUid> uidCache = new ConcurrentHashMap();
/*     */   private static long cacheTimeout;
/* 184 */   private static boolean initialized = false;
/*     */ 
/*     */   public static boolean isAvailable()
/*     */   {
/* 104 */     return (NativeCodeLoader.isNativeCodeLoaded()) && (nativeLoaded);
/*     */   }
/*     */ 
/*     */   public static native FileDescriptor open(String paramString, int paramInt1, int paramInt2)
/*     */     throws IOException;
/*     */ 
/*     */   public static native Stat fstat(FileDescriptor paramFileDescriptor)
/*     */     throws IOException;
/*     */ 
/*     */   private static native long getUIDforFDOwnerforOwner(FileDescriptor paramFileDescriptor)
/*     */     throws IOException;
/*     */ 
/*     */   private static native String getUserName(long paramLong)
/*     */     throws IOException;
/*     */ 
/*     */   private static native void initNative();
/*     */ 
/*     */   public static native void chmod(String paramString, int paramInt)
/*     */     throws IOException;
/*     */ 
/*     */   static native void posix_fadvise(FileDescriptor paramFileDescriptor, long paramLong1, long paramLong2, int paramInt)
/*     */     throws NativeIOException;
/*     */ 
/*     */   static native void sync_file_range(FileDescriptor paramFileDescriptor, long paramLong1, long paramLong2, int paramInt)
/*     */     throws NativeIOException;
/*     */ 
/*     */   public static void posixFadviseIfPossible(FileDescriptor fd, long offset, long len, int flags)
/*     */     throws NativeIOException
/*     */   {
/* 148 */     if ((nativeLoaded) && (fadvisePossible))
/*     */       try {
/* 150 */         posix_fadvise(fd, offset, len, flags);
/*     */       } catch (UnsupportedOperationException uoe) {
/* 152 */         fadvisePossible = false;
/*     */       } catch (UnsatisfiedLinkError ule) {
/* 154 */         fadvisePossible = false;
/*     */       }
/*     */   }
/*     */ 
/*     */   public static void syncFileRangeIfPossible(FileDescriptor fd, long offset, long nbytes, int flags)
/*     */     throws NativeIOException
/*     */   {
/* 170 */     if ((nativeLoaded) && (syncFileRangePossible))
/*     */       try {
/* 172 */         sync_file_range(fd, offset, nbytes, flags);
/*     */       } catch (UnsupportedOperationException uoe) {
/* 174 */         syncFileRangePossible = false;
/*     */       } catch (UnsatisfiedLinkError ule) {
/* 176 */         syncFileRangePossible = false;
/*     */       }
/*     */   }
/*     */ 
/*     */   public static String getOwner(FileDescriptor fd)
/*     */     throws IOException
/*     */   {
/* 187 */     ensureInitialized();
/* 188 */     long uid = getUIDforFDOwnerforOwner(fd);
/* 189 */     CachedUid cUid = (CachedUid)uidCache.get(Long.valueOf(uid));
/* 190 */     long now = System.currentTimeMillis();
/* 191 */     if ((cUid != null) && (cUid.timestamp + cacheTimeout > now)) {
/* 192 */       return cUid.username;
/*     */     }
/* 194 */     String user = getUserName(uid);
/* 195 */     LOG.info("Got UserName " + user + " for UID " + uid + " from the native implementation");
/*     */ 
/* 197 */     cUid = new CachedUid(user, now);
/* 198 */     uidCache.put(Long.valueOf(uid), cUid);
/* 199 */     return user;
/*     */   }
/*     */ 
/*     */   private static synchronized void ensureInitialized() {
/* 203 */     if (!initialized) {
/* 204 */       cacheTimeout = new Configuration().getLong("hadoop.security.uid.cache.secs", 14400L) * 1000L;
/*     */ 
/* 207 */       LOG.info("Initialized cache for UID to User mapping with a cache timeout of " + cacheTimeout / 1000L + " seconds.");
/*     */ 
/* 209 */       initialized = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  87 */     if (NativeCodeLoader.isNativeCodeLoaded())
/*     */       try {
/*  89 */         initNative();
/*  90 */         nativeLoaded = true;
/*     */       }
/*     */       catch (Throwable t)
/*     */       {
/*  95 */         LOG.error("Unable to initialize NativeIO libraries", t);
/*     */       }
/*     */   }
/*     */ 
/*     */   public static class Stat
/*     */   {
/*     */     private String owner;
/*     */     private int mode;
/*     */     public static final int S_IFMT = 61440;
/*     */     public static final int S_IFIFO = 4096;
/*     */     public static final int S_IFCHR = 8192;
/*     */     public static final int S_IFDIR = 16384;
/*     */     public static final int S_IFBLK = 24576;
/*     */     public static final int S_IFREG = 32768;
/*     */     public static final int S_IFLNK = 40960;
/*     */     public static final int S_IFSOCK = 49152;
/*     */     public static final int S_IFWHT = 57344;
/*     */     public static final int S_ISUID = 2048;
/*     */     public static final int S_ISGID = 1024;
/*     */     public static final int S_ISVTX = 512;
/*     */     public static final int S_IRUSR = 256;
/*     */     public static final int S_IWUSR = 128;
/*     */     public static final int S_IXUSR = 64;
/*     */ 
/*     */     Stat(String owner, int mode)
/*     */     {
/* 239 */       this.owner = owner;
/* 240 */       this.mode = mode;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 244 */       return "Stat(owner='" + this.owner + "'" + ", mode=" + this.mode + ")";
/*     */     }
/*     */ 
/*     */     public String getOwner()
/*     */     {
/* 249 */       return this.owner;
/*     */     }
/*     */     public int getMode() {
/* 252 */       return this.mode;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class CachedUid
/*     */   {
/*     */     final long timestamp;
/*     */     final String username;
/*     */ 
/*     */     public CachedUid(String username, long timestamp)
/*     */     {
/* 124 */       this.timestamp = timestamp;
/* 125 */       this.username = username;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.nativeio.NativeIO
 * JD-Core Version:    0.6.1
 */
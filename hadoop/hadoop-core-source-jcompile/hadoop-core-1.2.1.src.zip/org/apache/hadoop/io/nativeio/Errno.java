/*    */ package org.apache.hadoop.io.nativeio;
/*    */ 
/*    */ public enum Errno
/*    */ {
/* 24 */   EPERM, 
/* 25 */   ENOENT, 
/* 26 */   ESRCH, 
/* 27 */   EINTR, 
/* 28 */   EIO, 
/* 29 */   ENXIO, 
/* 30 */   E2BIG, 
/* 31 */   ENOEXEC, 
/* 32 */   EBADF, 
/* 33 */   ECHILD, 
/* 34 */   EAGAIN, 
/* 35 */   ENOMEM, 
/* 36 */   EACCES, 
/* 37 */   EFAULT, 
/* 38 */   ENOTBLK, 
/* 39 */   EBUSY, 
/* 40 */   EEXIST, 
/* 41 */   EXDEV, 
/* 42 */   ENODEV, 
/* 43 */   ENOTDIR, 
/* 44 */   EISDIR, 
/* 45 */   EINVAL, 
/* 46 */   ENFILE, 
/* 47 */   EMFILE, 
/* 48 */   ENOTTY, 
/* 49 */   ETXTBSY, 
/* 50 */   EFBIG, 
/* 51 */   ENOSPC, 
/* 52 */   ESPIPE, 
/* 53 */   EROFS, 
/* 54 */   EMLINK, 
/* 55 */   EPIPE, 
/* 56 */   EDOM, 
/* 57 */   ERANGE, 
/*    */ 
/* 59 */   UNKNOWN;
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.nativeio.Errno
 * JD-Core Version:    0.6.1
 */
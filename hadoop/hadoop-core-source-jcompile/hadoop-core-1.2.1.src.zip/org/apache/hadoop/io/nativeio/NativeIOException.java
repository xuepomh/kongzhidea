/*    */ package org.apache.hadoop.io.nativeio;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class NativeIOException extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = -6615764817732323232L;
/*    */   private Errno errno;
/*    */ 
/*    */   public NativeIOException(String msg, Errno errno)
/*    */   {
/* 32 */     super(msg);
/* 33 */     this.errno = errno;
/*    */   }
/*    */ 
/*    */   public Errno getErrno() {
/* 37 */     return this.errno;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 41 */     return this.errno.toString() + ": " + super.getMessage();
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.nativeio.NativeIOException
 * JD-Core Version:    0.6.1
 */
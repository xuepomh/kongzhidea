/*     */ package org.apache.hadoop.io;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import java.util.zip.GZIPOutputStream;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.util.ReflectionUtils;
/*     */ 
/*     */ public final class WritableUtils
/*     */ {
/*     */   public static byte[] readCompressedByteArray(DataInput in)
/*     */     throws IOException
/*     */   {
/*  32 */     int length = in.readInt();
/*  33 */     if (length == -1) return null;
/*  34 */     byte[] buffer = new byte[length];
/*  35 */     in.readFully(buffer);
/*  36 */     GZIPInputStream gzi = new GZIPInputStream(new ByteArrayInputStream(buffer, 0, buffer.length));
/*  37 */     byte[] outbuf = new byte[length];
/*  38 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*     */     int len;
/*  40 */     while ((len = gzi.read(outbuf, 0, outbuf.length)) != -1) {
/*  41 */       bos.write(outbuf, 0, len);
/*     */     }
/*  43 */     byte[] decompressed = bos.toByteArray();
/*  44 */     bos.close();
/*  45 */     gzi.close();
/*  46 */     return decompressed;
/*     */   }
/*     */ 
/*     */   public static void skipCompressedByteArray(DataInput in) throws IOException {
/*  50 */     int length = in.readInt();
/*  51 */     if (length != -1)
/*  52 */       skipFully(in, length);
/*     */   }
/*     */ 
/*     */   public static int writeCompressedByteArray(DataOutput out, byte[] bytes)
/*     */     throws IOException
/*     */   {
/*  58 */     if (bytes != null) {
/*  59 */       ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*  60 */       GZIPOutputStream gzout = new GZIPOutputStream(bos);
/*  61 */       gzout.write(bytes, 0, bytes.length);
/*  62 */       gzout.close();
/*  63 */       byte[] buffer = bos.toByteArray();
/*  64 */       int len = buffer.length;
/*  65 */       out.writeInt(len);
/*  66 */       out.write(buffer, 0, len);
/*     */ 
/*  68 */       return bytes.length != 0 ? 100 * buffer.length / bytes.length : 0;
/*     */     }
/*  70 */     out.writeInt(-1);
/*  71 */     return -1;
/*     */   }
/*     */ 
/*     */   public static String readCompressedString(DataInput in)
/*     */     throws IOException
/*     */   {
/*  78 */     byte[] bytes = readCompressedByteArray(in);
/*  79 */     if (bytes == null) return null;
/*  80 */     return new String(bytes, "UTF-8");
/*     */   }
/*     */ 
/*     */   public static int writeCompressedString(DataOutput out, String s) throws IOException
/*     */   {
/*  85 */     return writeCompressedByteArray(out, s != null ? s.getBytes("UTF-8") : null);
/*     */   }
/*     */ 
/*     */   public static void writeString(DataOutput out, String s)
/*     */     throws IOException
/*     */   {
/*  96 */     if (s != null) {
/*  97 */       byte[] buffer = s.getBytes("UTF-8");
/*  98 */       int len = buffer.length;
/*  99 */       out.writeInt(len);
/* 100 */       out.write(buffer, 0, len);
/*     */     } else {
/* 102 */       out.writeInt(-1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String readString(DataInput in)
/*     */     throws IOException
/*     */   {
/* 113 */     int length = in.readInt();
/* 114 */     if (length == -1) return null;
/* 115 */     byte[] buffer = new byte[length];
/* 116 */     in.readFully(buffer);
/* 117 */     return new String(buffer, "UTF-8");
/*     */   }
/*     */ 
/*     */   public static void writeStringArray(DataOutput out, String[] s)
/*     */     throws IOException
/*     */   {
/* 127 */     out.writeInt(s.length);
/* 128 */     for (int i = 0; i < s.length; i++)
/* 129 */       writeString(out, s[i]);
/*     */   }
/*     */ 
/*     */   public static void writeCompressedStringArray(DataOutput out, String[] s)
/*     */     throws IOException
/*     */   {
/* 140 */     if (s == null) {
/* 141 */       out.writeInt(-1);
/* 142 */       return;
/*     */     }
/* 144 */     out.writeInt(s.length);
/* 145 */     for (int i = 0; i < s.length; i++)
/* 146 */       writeCompressedString(out, s[i]);
/*     */   }
/*     */ 
/*     */   public static String[] readStringArray(DataInput in)
/*     */     throws IOException
/*     */   {
/* 156 */     int len = in.readInt();
/* 157 */     if (len == -1) return null;
/* 158 */     String[] s = new String[len];
/* 159 */     for (int i = 0; i < len; i++) {
/* 160 */       s[i] = readString(in);
/*     */     }
/* 162 */     return s;
/*     */   }
/*     */ 
/*     */   public static String[] readCompressedStringArray(DataInput in)
/*     */     throws IOException
/*     */   {
/* 172 */     int len = in.readInt();
/* 173 */     if (len == -1) return null;
/* 174 */     String[] s = new String[len];
/* 175 */     for (int i = 0; i < len; i++) {
/* 176 */       s[i] = readCompressedString(in);
/*     */     }
/* 178 */     return s;
/*     */   }
/*     */ 
/*     */   public static void displayByteArray(byte[] record)
/*     */   {
/* 189 */     for (int i = 0; i < record.length - 1; i++) {
/* 190 */       if (i % 16 == 0) System.out.println();
/* 191 */       System.out.print(Integer.toHexString(record[i] >> 4 & 0xF));
/* 192 */       System.out.print(Integer.toHexString(record[i] & 0xF));
/* 193 */       System.out.print(",");
/*     */     }
/* 195 */     System.out.print(Integer.toHexString(record[i] >> 4 & 0xF));
/* 196 */     System.out.print(Integer.toHexString(record[i] & 0xF));
/* 197 */     System.out.println();
/*     */   }
/*     */ 
/*     */   public static <T extends Writable> T clone(T orig, Configuration conf)
/*     */   {
/*     */     try
/*     */     {
/* 208 */       Writable newInst = (Writable)ReflectionUtils.newInstance(orig.getClass(), conf);
/* 209 */       ReflectionUtils.copy(conf, orig, newInst);
/* 210 */       return newInst;
/*     */     } catch (IOException e) {
/* 212 */       throw new RuntimeException("Error writing/reading clone buffer", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static void cloneInto(Writable dst, Writable src)
/*     */     throws IOException
/*     */   {
/* 225 */     ReflectionUtils.cloneWritableInto(dst, src);
/*     */   }
/*     */ 
/*     */   public static void writeVInt(DataOutput stream, int i)
/*     */     throws IOException
/*     */   {
/* 244 */     writeVLong(stream, i);
/*     */   }
/*     */ 
/*     */   public static void writeVLong(DataOutput stream, long i)
/*     */     throws IOException
/*     */   {
/* 263 */     if ((i >= -112L) && (i <= 127L)) {
/* 264 */       stream.writeByte((byte)(int)i);
/* 265 */       return;
/*     */     }
/*     */ 
/* 268 */     int len = -112;
/* 269 */     if (i < 0L) {
/* 270 */       i ^= -1L;
/* 271 */       len = -120;
/*     */     }
/*     */ 
/* 274 */     long tmp = i;
/* 275 */     while (tmp != 0L) {
/* 276 */       tmp >>= 8;
/* 277 */       len--;
/*     */     }
/*     */ 
/* 280 */     stream.writeByte((byte)len);
/*     */ 
/* 282 */     len = len < -120 ? -(len + 120) : -(len + 112);
/*     */ 
/* 284 */     for (int idx = len; idx != 0; idx--) {
/* 285 */       int shiftbits = (idx - 1) * 8;
/* 286 */       long mask = 255L << shiftbits;
/* 287 */       stream.writeByte((byte)(int)((i & mask) >> shiftbits));
/*     */     }
/*     */   }
/*     */ 
/*     */   public static long readVLong(DataInput stream)
/*     */     throws IOException
/*     */   {
/* 299 */     byte firstByte = stream.readByte();
/* 300 */     int len = decodeVIntSize(firstByte);
/* 301 */     if (len == 1) {
/* 302 */       return firstByte;
/*     */     }
/* 304 */     long i = 0L;
/* 305 */     for (int idx = 0; idx < len - 1; idx++) {
/* 306 */       byte b = stream.readByte();
/* 307 */       i <<= 8;
/* 308 */       i |= b & 0xFF;
/*     */     }
/* 310 */     return isNegativeVInt(firstByte) ? i ^ 0xFFFFFFFF : i;
/*     */   }
/*     */ 
/*     */   public static int readVInt(DataInput stream)
/*     */     throws IOException
/*     */   {
/* 320 */     return (int)readVLong(stream);
/*     */   }
/*     */ 
/*     */   public static boolean isNegativeVInt(byte value)
/*     */   {
/* 329 */     return (value < -120) || ((value >= -112) && (value < 0));
/*     */   }
/*     */ 
/*     */   public static int decodeVIntSize(byte value)
/*     */   {
/* 338 */     if (value >= -112)
/* 339 */       return 1;
/* 340 */     if (value < -120) {
/* 341 */       return -119 - value;
/*     */     }
/* 343 */     return -111 - value;
/*     */   }
/*     */ 
/*     */   public static int getVIntSize(long i)
/*     */   {
/* 351 */     if ((i >= -112L) && (i <= 127L)) {
/* 352 */       return 1;
/*     */     }
/*     */ 
/* 355 */     if (i < 0L) {
/* 356 */       i ^= -1L;
/*     */     }
/*     */ 
/* 359 */     int dataBits = 64 - Long.numberOfLeadingZeros(i);
/*     */ 
/* 361 */     return (dataBits + 7) / 8 + 1;
/*     */   }
/*     */ 
/*     */   public static <T extends Enum<T>> T readEnum(DataInput in, Class<T> enumType)
/*     */     throws IOException
/*     */   {
/* 374 */     return Enum.valueOf(enumType, Text.readString(in));
/*     */   }
/*     */ 
/*     */   public static void writeEnum(DataOutput out, Enum<?> enumVal)
/*     */     throws IOException
/*     */   {
/* 384 */     Text.writeString(out, enumVal.name());
/*     */   }
/*     */ 
/*     */   public static void skipFully(DataInput in, int len)
/*     */     throws IOException
/*     */   {
/* 393 */     int total = 0;
/* 394 */     int cur = 0;
/*     */ 
/* 396 */     while ((total < len) && ((cur = in.skipBytes(len - total)) > 0)) {
/* 397 */       total += cur;
/*     */     }
/*     */ 
/* 400 */     if (total < len)
/* 401 */       throw new IOException("Not able to skip " + len + " bytes, possibly " + "due to end of input.");
/*     */   }
/*     */ 
/*     */   public static byte[] toByteArray(Writable[] writables)
/*     */   {
/* 408 */     DataOutputBuffer out = new DataOutputBuffer();
/*     */     try {
/* 410 */       for (Writable w : writables) {
/* 411 */         w.write(out);
/*     */       }
/* 413 */       out.close();
/*     */     } catch (IOException e) {
/* 415 */       throw new RuntimeException("Fail to convert writables to a byte array", e);
/*     */     }
/* 417 */     return out.getData();
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.WritableUtils
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.io.file.tfile;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FSDataInputStream;
/*     */ import org.apache.hadoop.fs.FileStatus;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.io.IOUtils;
/*     */ 
/*     */ class TFileDumper
/*     */ {
/*  43 */   static final Log LOG = LogFactory.getLog(TFileDumper.class);
/*     */ 
/*     */   public static void dumpInfo(String file, PrintStream out, Configuration conf)
/*     */     throws IOException
/*     */   {
/*  97 */     int maxKeySampleLen = 16;
/*  98 */     Path path = new Path(file);
/*  99 */     FileSystem fs = path.getFileSystem(conf);
/* 100 */     long length = fs.getFileStatus(path).getLen();
/* 101 */     FSDataInputStream fsdis = fs.open(path);
/* 102 */     TFile.Reader reader = new TFile.Reader(fsdis, length, conf);
/*     */     try {
/* 104 */       LinkedHashMap properties = new LinkedHashMap();
/*     */ 
/* 106 */       int blockCnt = reader.readerBCF.getBlockCount();
/* 107 */       int metaBlkCnt = reader.readerBCF.metaIndex.index.size();
/* 108 */       properties.put("BCFile Version", reader.readerBCF.version.toString());
/* 109 */       properties.put("TFile Version", reader.tfileMeta.version.toString());
/* 110 */       properties.put("File Length", Long.toString(length));
/* 111 */       properties.put("Data Compression", reader.readerBCF.getDefaultCompressionName());
/*     */ 
/* 113 */       properties.put("Record Count", Long.toString(reader.getEntryCount()));
/* 114 */       properties.put("Sorted", Boolean.toString(reader.isSorted()));
/* 115 */       if (reader.isSorted()) {
/* 116 */         properties.put("Comparator", reader.getComparatorName());
/*     */       }
/* 118 */       properties.put("Data Block Count", Integer.toString(blockCnt));
/* 119 */       long dataSize = 0L; long dataSizeUncompressed = 0L;
/* 120 */       if (blockCnt > 0) {
/* 121 */         for (int i = 0; i < blockCnt; i++) {
/* 122 */           BCFile.BlockRegion region = (BCFile.BlockRegion)reader.readerBCF.dataIndex.getBlockRegionList().get(i);
/*     */ 
/* 124 */           dataSize += region.getCompressedSize();
/* 125 */           dataSizeUncompressed += region.getRawSize();
/*     */         }
/* 127 */         properties.put("Data Block Bytes", Long.toString(dataSize));
/* 128 */         if (reader.readerBCF.getDefaultCompressionName() != "none") {
/* 129 */           properties.put("Data Block Uncompressed Bytes", Long.toString(dataSizeUncompressed));
/*     */ 
/* 131 */           properties.put("Data Block Compression Ratio", String.format("1:%.1f", new Object[] { Double.valueOf(dataSizeUncompressed / dataSize) }));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 136 */       properties.put("Meta Block Count", Integer.toString(metaBlkCnt));
/* 137 */       long metaSize = 0L; long metaSizeUncompressed = 0L;
/* 138 */       if (metaBlkCnt > 0) {
/* 139 */         Collection metaBlks = reader.readerBCF.metaIndex.index.values();
/*     */ 
/* 141 */         boolean calculateCompression = false;
/* 142 */         for (Iterator it = metaBlks.iterator(); it.hasNext(); ) {
/* 143 */           BCFile.MetaIndexEntry e = (BCFile.MetaIndexEntry)it.next();
/* 144 */           metaSize += e.getRegion().getCompressedSize();
/* 145 */           metaSizeUncompressed += e.getRegion().getRawSize();
/* 146 */           if (e.getCompressionAlgorithm() != Compression.Algorithm.NONE) {
/* 147 */             calculateCompression = true;
/*     */           }
/*     */         }
/* 150 */         properties.put("Meta Block Bytes", Long.toString(metaSize));
/* 151 */         if (calculateCompression) {
/* 152 */           properties.put("Meta Block Uncompressed Bytes", Long.toString(metaSizeUncompressed));
/*     */ 
/* 154 */           properties.put("Meta Block Compression Ratio", String.format("1:%.1f", new Object[] { Double.valueOf(metaSizeUncompressed / metaSize) }));
/*     */         }
/*     */       }
/*     */ 
/* 158 */       properties.put("Meta-Data Size Ratio", String.format("1:%.1f", new Object[] { Double.valueOf(dataSize / metaSize) }));
/*     */ 
/* 160 */       long leftOverBytes = length - dataSize - metaSize;
/* 161 */       long miscSize = BCFile.Magic.size() * 2 + 8 + Utils.Version.size();
/*     */ 
/* 163 */       long metaIndexSize = leftOverBytes - miscSize;
/* 164 */       properties.put("Meta Block Index Bytes", Long.toString(metaIndexSize));
/* 165 */       properties.put("Headers Etc Bytes", Long.toString(miscSize));
/*     */ 
/* 167 */       int maxKeyLength = 0;
/* 168 */       Set entrySet = properties.entrySet();
/* 169 */       Iterator it = entrySet.iterator();
/* 170 */       while (it.hasNext()) {
/* 171 */         Map.Entry e = (Map.Entry)it.next();
/* 172 */         if (((String)e.getKey()).length() > maxKeyLength) {
/* 173 */           maxKeyLength = ((String)e.getKey()).length();
/*     */         }
/*     */       }
/* 176 */       Iterator it = entrySet.iterator();
/* 177 */       while (it.hasNext()) {
/* 178 */         Map.Entry e = (Map.Entry)it.next();
/* 179 */         out.printf("%s : %s\n", new Object[] { Align.format((String)e.getKey(), maxKeyLength, Align.LEFT), e.getValue() });
/*     */       }
/*     */ 
/* 182 */       out.println();
/* 183 */       reader.checkTFileDataIndex();
/* 184 */       if (blockCnt > 0) {
/* 185 */         String blkID = "Data-Block";
/* 186 */         int blkIDWidth = Align.calculateWidth(blkID, blockCnt);
/* 187 */         int blkIDWidth2 = Align.calculateWidth("", blockCnt);
/* 188 */         String offset = "Offset";
/* 189 */         int offsetWidth = Align.calculateWidth(offset, length);
/* 190 */         String blkLen = "Length";
/* 191 */         int blkLenWidth = Align.calculateWidth(blkLen, dataSize / blockCnt * 10L);
/*     */ 
/* 193 */         String rawSize = "Raw-Size";
/* 194 */         int rawSizeWidth = Align.calculateWidth(rawSize, dataSizeUncompressed / blockCnt * 10L);
/*     */ 
/* 196 */         String records = "Records";
/* 197 */         int recordsWidth = Align.calculateWidth(records, reader.getEntryCount() / blockCnt * 10L);
/*     */ 
/* 200 */         String endKey = "End-Key";
/* 201 */         int endKeyWidth = Math.max(endKey.length(), 37);
/*     */ 
/* 203 */         out.printf("%s %s %s %s %s %s\n", new Object[] { Align.format(blkID, blkIDWidth, Align.CENTER), Align.format(offset, offsetWidth, Align.CENTER), Align.format(blkLen, blkLenWidth, Align.CENTER), Align.format(rawSize, rawSizeWidth, Align.CENTER), Align.format(records, recordsWidth, Align.CENTER), Align.format(endKey, endKeyWidth, Align.LEFT) });
/*     */ 
/* 210 */         for (int i = 0; i < blockCnt; i++) {
/* 211 */           BCFile.BlockRegion region = (BCFile.BlockRegion)reader.readerBCF.dataIndex.getBlockRegionList().get(i);
/*     */ 
/* 213 */           TFile.TFileIndexEntry indexEntry = reader.tfileIndex.getEntry(i);
/* 214 */           out.printf("%s %s %s %s %s ", new Object[] { Align.format(Align.format(i, blkIDWidth2, Align.ZERO_PADDED), blkIDWidth, Align.LEFT), Align.format(region.getOffset(), offsetWidth, Align.LEFT), Align.format(region.getCompressedSize(), blkLenWidth, Align.LEFT), Align.format(region.getRawSize(), rawSizeWidth, Align.LEFT), Align.format(indexEntry.kvEntries, recordsWidth, Align.LEFT) });
/*     */ 
/* 220 */           byte[] key = indexEntry.key;
/* 221 */           boolean asAscii = true;
/* 222 */           int sampleLen = Math.min(16, key.length);
/* 223 */           for (int j = 0; j < sampleLen; j++) {
/* 224 */             byte b = key[j];
/* 225 */             if (((b < 32) && (b != 9)) || (b == 127)) {
/* 226 */               asAscii = false;
/*     */             }
/*     */           }
/* 229 */           if (!asAscii) {
/* 230 */             out.print("0X");
/* 231 */             for (int j = 0; j < sampleLen; j++) {
/* 232 */               byte b = key[i];
/* 233 */               out.printf("%X", new Object[] { Byte.valueOf(b) });
/*     */             }
/*     */           } else {
/* 236 */             out.print(new String(key, 0, sampleLen));
/*     */           }
/* 238 */           if (sampleLen < key.length) {
/* 239 */             out.print("...");
/*     */           }
/* 241 */           out.println();
/*     */         }
/*     */       }
/*     */ 
/* 245 */       out.println();
/* 246 */       if (metaBlkCnt > 0) {
/* 247 */         String name = "Meta-Block";
/* 248 */         int maxNameLen = 0;
/* 249 */         Set metaBlkEntrySet = reader.readerBCF.metaIndex.index.entrySet();
/*     */ 
/* 251 */         Iterator it = metaBlkEntrySet.iterator();
/* 252 */         while (it.hasNext()) {
/* 253 */           Map.Entry e = (Map.Entry)it.next();
/* 254 */           if (((String)e.getKey()).length() > maxNameLen) {
/* 255 */             maxNameLen = ((String)e.getKey()).length();
/*     */           }
/*     */         }
/* 258 */         int nameWidth = Math.max(name.length(), maxNameLen);
/* 259 */         String offset = "Offset";
/* 260 */         int offsetWidth = Align.calculateWidth(offset, length);
/* 261 */         String blkLen = "Length";
/* 262 */         int blkLenWidth = Align.calculateWidth(blkLen, metaSize / metaBlkCnt * 10L);
/*     */ 
/* 264 */         String rawSize = "Raw-Size";
/* 265 */         int rawSizeWidth = Align.calculateWidth(rawSize, metaSizeUncompressed / metaBlkCnt * 10L);
/*     */ 
/* 268 */         String compression = "Compression";
/* 269 */         int compressionWidth = compression.length();
/* 270 */         out.printf("%s %s %s %s %s\n", new Object[] { Align.format(name, nameWidth, Align.CENTER), Align.format(offset, offsetWidth, Align.CENTER), Align.format(blkLen, blkLenWidth, Align.CENTER), Align.format(rawSize, rawSizeWidth, Align.CENTER), Align.format(compression, compressionWidth, Align.LEFT) });
/*     */ 
/* 276 */         Iterator it = metaBlkEntrySet.iterator();
/* 277 */         while (it.hasNext()) {
/* 278 */           Map.Entry e = (Map.Entry)it.next();
/* 279 */           String blkName = ((BCFile.MetaIndexEntry)e.getValue()).getMetaName();
/* 280 */           BCFile.BlockRegion region = ((BCFile.MetaIndexEntry)e.getValue()).getRegion();
/* 281 */           String blkCompression = ((BCFile.MetaIndexEntry)e.getValue()).getCompressionAlgorithm().getName();
/*     */ 
/* 283 */           out.printf("%s %s %s %s %s\n", new Object[] { Align.format(blkName, nameWidth, Align.LEFT), Align.format(region.getOffset(), offsetWidth, Align.LEFT), Align.format(region.getCompressedSize(), blkLenWidth, Align.LEFT), Align.format(region.getRawSize(), rawSizeWidth, Align.LEFT), Align.format(blkCompression, compressionWidth, Align.LEFT) });
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 292 */       IOUtils.cleanup(LOG, new Closeable[] { reader, fsdis });
/*     */     }
/*     */   }
/*     */ 
/*     */   private static enum Align
/*     */   {
/*  50 */     LEFT, CENTER, RIGHT, ZERO_PADDED;
/*     */ 
/*  52 */     static String format(String s, int width, Align align) { if (s.length() >= width) return s;
/*  53 */       int room = width - s.length();
/*  54 */       Align alignAdjusted = align;
/*  55 */       if (room == 1) {
/*  56 */         alignAdjusted = LEFT;
/*     */       }
/*  58 */       if (alignAdjusted == LEFT) {
/*  59 */         return s + String.format(new StringBuilder().append("%").append(room).append("s").toString(), new Object[] { "" });
/*     */       }
/*  61 */       if (alignAdjusted == RIGHT) {
/*  62 */         return String.format(new StringBuilder().append("%").append(room).append("s").toString(), new Object[] { "" }) + s;
/*     */       }
/*  64 */       if (alignAdjusted == CENTER) {
/*  65 */         int half = room / 2;
/*  66 */         return String.format(new StringBuilder().append("%").append(half).append("s").toString(), new Object[] { "" }) + s + String.format(new StringBuilder().append("%").append(room - half).append("s").toString(), new Object[] { "" });
/*     */       }
/*     */ 
/*  69 */       throw new IllegalArgumentException("Unsupported alignment"); }
/*     */ 
/*     */     static String format(long l, int width, Align align)
/*     */     {
/*  73 */       if (align == ZERO_PADDED) {
/*  74 */         return String.format("%0" + width + "d", new Object[] { Long.valueOf(l) });
/*     */       }
/*  76 */       return format(Long.toString(l), width, align);
/*     */     }
/*     */ 
/*     */     static int calculateWidth(String caption, long max) {
/*  80 */       return Math.max(caption.length(), Long.toString(max).length());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.file.tfile.TFileDumper
 * JD-Core Version:    0.6.1
 */
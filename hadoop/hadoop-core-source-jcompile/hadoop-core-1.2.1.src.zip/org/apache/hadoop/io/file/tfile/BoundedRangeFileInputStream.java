/*     */ package org.apache.hadoop.io.file.tfile;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.apache.hadoop.fs.FSDataInputStream;
/*     */ 
/*     */ class BoundedRangeFileInputStream extends InputStream
/*     */ {
/*     */   private FSDataInputStream in;
/*     */   private long pos;
/*     */   private long end;
/*     */   private long mark;
/*  37 */   private final byte[] oneByte = new byte[1];
/*     */ 
/*     */   public BoundedRangeFileInputStream(FSDataInputStream in, long offset, long length)
/*     */   {
/*  54 */     if ((offset < 0L) || (length < 0L)) {
/*  55 */       throw new IndexOutOfBoundsException("Invalid offset/length: " + offset + "/" + length);
/*     */     }
/*     */ 
/*  59 */     this.in = in;
/*  60 */     this.pos = offset;
/*  61 */     this.end = (offset + length);
/*  62 */     this.mark = -1L;
/*     */   }
/*     */ 
/*     */   public int available() throws IOException
/*     */   {
/*  67 */     int avail = this.in.available();
/*  68 */     if (this.pos + avail > this.end) {
/*  69 */       avail = (int)(this.end - this.pos);
/*     */     }
/*     */ 
/*  72 */     return avail;
/*     */   }
/*     */ 
/*     */   public int read() throws IOException
/*     */   {
/*  77 */     int ret = read(this.oneByte);
/*  78 */     if (ret == 1) return this.oneByte[0] & 0xFF;
/*  79 */     return -1;
/*     */   }
/*     */ 
/*     */   public int read(byte[] b) throws IOException
/*     */   {
/*  84 */     return read(b, 0, b.length);
/*     */   }
/*     */ 
/*     */   public int read(byte[] b, int off, int len) throws IOException
/*     */   {
/*  89 */     if ((off | len | off + len | b.length - (off + len)) < 0) {
/*  90 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */ 
/*  93 */     int n = (int)Math.min(2147483647L, Math.min(len, this.end - this.pos));
/*  94 */     if (n == 0) return -1;
/*  95 */     int ret = 0;
/*  96 */     synchronized (this.in) {
/*  97 */       this.in.seek(this.pos);
/*  98 */       ret = this.in.read(b, off, n);
/*     */     }
/* 100 */     if (ret < 0) {
/* 101 */       this.end = this.pos;
/* 102 */       return -1;
/*     */     }
/* 104 */     this.pos += ret;
/* 105 */     return ret;
/*     */   }
/*     */ 
/*     */   public long skip(long n)
/*     */     throws IOException
/*     */   {
/* 113 */     long len = Math.min(n, this.end - this.pos);
/* 114 */     this.pos += len;
/* 115 */     return len;
/*     */   }
/*     */ 
/*     */   public void mark(int readlimit)
/*     */   {
/* 120 */     this.mark = this.pos;
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 125 */     if (this.mark < 0L) throw new IOException("Resetting to invalid mark");
/* 126 */     this.pos = this.mark;
/*     */   }
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/* 131 */     return true;
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/* 137 */     this.in = null;
/* 138 */     this.pos = this.end;
/* 139 */     this.mark = -1L;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.file.tfile.BoundedRangeFileInputStream
 * JD-Core Version:    0.6.1
 */
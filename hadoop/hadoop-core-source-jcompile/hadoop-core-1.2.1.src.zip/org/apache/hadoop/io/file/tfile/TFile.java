/*      */ package org.apache.hadoop.io.file.tfile;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.Closeable;
/*      */ import java.io.DataInput;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutput;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.EOFException;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Comparator;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.apache.hadoop.conf.Configuration;
/*      */ import org.apache.hadoop.fs.FSDataInputStream;
/*      */ import org.apache.hadoop.fs.FSDataOutputStream;
/*      */ import org.apache.hadoop.io.BytesWritable;
/*      */ import org.apache.hadoop.io.DataInputBuffer;
/*      */ import org.apache.hadoop.io.DataOutputBuffer;
/*      */ import org.apache.hadoop.io.IOUtils;
/*      */ import org.apache.hadoop.io.RawComparator;
/*      */ import org.apache.hadoop.io.WritableComparator;
/*      */ 
/*      */ public class TFile
/*      */ {
/*  129 */   static final Log LOG = LogFactory.getLog(TFile.class);
/*      */   private static final String CHUNK_BUF_SIZE_ATTR = "tfile.io.chunk.size";
/*      */   private static final String FS_INPUT_BUF_SIZE_ATTR = "tfile.fs.input.buffer.size";
/*      */   private static final String FS_OUTPUT_BUF_SIZE_ATTR = "tfile.fs.output.buffer.size";
/*      */   private static final int MAX_KEY_SIZE = 65536;
/*  151 */   static final Utils.Version API_VERSION = new Utils.Version((short)1, (short)0);
/*      */   public static final String COMPRESSION_GZ = "gz";
/*      */   public static final String COMPRESSION_LZO = "lzo";
/*      */   public static final String COMPRESSION_NONE = "none";
/*      */   public static final String COMPARATOR_MEMCMP = "memcmp";
/*      */   public static final String COMPARATOR_JCLASS = "jclass:";
/*      */ 
/*      */   static int getChunkBufferSize(Configuration conf)
/*      */   {
/*  138 */     int ret = conf.getInt("tfile.io.chunk.size", 1048576);
/*  139 */     return ret > 0 ? ret : 1048576;
/*      */   }
/*      */ 
/*      */   static int getFSInputBufferSize(Configuration conf) {
/*  143 */     return conf.getInt("tfile.fs.input.buffer.size", 262144);
/*      */   }
/*      */ 
/*      */   static int getFSOutputBufferSize(Configuration conf) {
/*  147 */     return conf.getInt("tfile.fs.output.buffer.size", 262144);
/*      */   }
/*      */ 
/*      */   public static Comparator<RawComparable> makeComparator(String name)
/*      */   {
/*  172 */     return TFileMeta.makeComparator(name);
/*      */   }
/*      */ 
/*      */   public static String[] getSupportedCompressionAlgorithms()
/*      */   {
/*  194 */     return Compression.getSupportedAlgorithms();
/*      */   }
/*      */ 
/*      */   public static void main(String[] args)
/*      */   {
/* 2334 */     System.out.printf("TFile Dumper (TFile %s, BCFile %s)\n", new Object[] { API_VERSION.toString(), BCFile.API_VERSION.toString() });
/*      */ 
/* 2336 */     if (args.length == 0) {
/* 2337 */       System.out.println("Usage: java ... org.apache.hadoop.io.file.tfile.TFile tfile-path [tfile-path ...]");
/*      */ 
/* 2339 */       System.exit(0);
/*      */     }
/* 2341 */     Configuration conf = new Configuration();
/*      */ 
/* 2343 */     for (String file : args) {
/* 2344 */       System.out.println("===" + file + "===");
/*      */       try {
/* 2346 */         TFileDumper.dumpInfo(file, System.out, conf);
/*      */       } catch (IOException e) {
/* 2348 */         e.printStackTrace(System.err);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static final class TFileIndexEntry
/*      */     implements RawComparable
/*      */   {
/*      */     final byte[] key;
/*      */     final long kvEntries;
/*      */ 
/*      */     public TFileIndexEntry(DataInput in)
/*      */       throws IOException
/*      */     {
/* 2288 */       int len = Utils.readVInt(in);
/* 2289 */       this.key = new byte[len];
/* 2290 */       in.readFully(this.key, 0, len);
/* 2291 */       this.kvEntries = Utils.readVLong(in);
/*      */     }
/*      */ 
/*      */     public TFileIndexEntry(byte[] newkey, int offset, int len, long entries)
/*      */     {
/* 2296 */       this.key = new byte[len];
/* 2297 */       System.arraycopy(newkey, offset, this.key, 0, len);
/* 2298 */       this.kvEntries = entries;
/*      */     }
/*      */ 
/*      */     public byte[] buffer()
/*      */     {
/* 2303 */       return this.key;
/*      */     }
/*      */ 
/*      */     public int offset()
/*      */     {
/* 2308 */       return 0;
/*      */     }
/*      */ 
/*      */     public int size()
/*      */     {
/* 2313 */       return this.key.length;
/*      */     }
/*      */ 
/*      */     long entries() {
/* 2317 */       return this.kvEntries;
/*      */     }
/*      */ 
/*      */     public void write(DataOutput out) throws IOException {
/* 2321 */       Utils.writeVInt(out, this.key.length);
/* 2322 */       out.write(this.key, 0, this.key.length);
/* 2323 */       Utils.writeVLong(out, this.kvEntries);
/*      */     }
/*      */   }
/*      */ 
/*      */   static class TFileIndex
/*      */   {
/*      */     static final String BLOCK_NAME = "TFile.index";
/*      */     private ByteArray firstKey;
/*      */     private final ArrayList<TFile.TFileIndexEntry> index;
/*      */     private final ArrayList<Long> recordNumIndex;
/*      */     private final CompareUtils.BytesComparator comparator;
/* 2123 */     private long sum = 0L;
/*      */ 
/*      */     public TFileIndex(int entryCount, DataInput in, CompareUtils.BytesComparator comparator)
/*      */       throws IOException
/*      */     {
/* 2132 */       this.index = new ArrayList(entryCount);
/* 2133 */       this.recordNumIndex = new ArrayList(entryCount);
/* 2134 */       int size = Utils.readVInt(in);
/* 2135 */       if (size > 0) {
/* 2136 */         byte[] buffer = new byte[size];
/* 2137 */         in.readFully(buffer);
/* 2138 */         DataInputStream firstKeyInputStream = new DataInputStream(new ByteArrayInputStream(buffer, 0, size));
/*      */ 
/* 2141 */         int firstKeyLength = Utils.readVInt(firstKeyInputStream);
/* 2142 */         this.firstKey = new ByteArray(new byte[firstKeyLength]);
/* 2143 */         firstKeyInputStream.readFully(this.firstKey.buffer());
/*      */ 
/* 2145 */         for (int i = 0; i < entryCount; i++) {
/* 2146 */           size = Utils.readVInt(in);
/* 2147 */           if (buffer.length < size) {
/* 2148 */             buffer = new byte[size];
/*      */           }
/* 2150 */           in.readFully(buffer, 0, size);
/* 2151 */           TFile.TFileIndexEntry idx = new TFile.TFileIndexEntry(new DataInputStream(new ByteArrayInputStream(buffer, 0, size)));
/*      */ 
/* 2154 */           this.index.add(idx);
/* 2155 */           this.sum += idx.entries();
/* 2156 */           this.recordNumIndex.add(Long.valueOf(this.sum));
/*      */         }
/*      */       }
/* 2159 */       else if (entryCount != 0) {
/* 2160 */         throw new RuntimeException("Internal error");
/*      */       }
/*      */ 
/* 2163 */       this.comparator = comparator;
/*      */     }
/*      */ 
/*      */     public int lowerBound(RawComparable key)
/*      */     {
/* 2173 */       if (this.comparator == null) {
/* 2174 */         throw new RuntimeException("Cannot search in unsorted TFile");
/*      */       }
/*      */ 
/* 2177 */       if (this.firstKey == null) {
/* 2178 */         return -1;
/*      */       }
/*      */ 
/* 2181 */       int ret = Utils.lowerBound(this.index, key, this.comparator);
/* 2182 */       if (ret == this.index.size()) {
/* 2183 */         return -1;
/*      */       }
/* 2185 */       return ret;
/*      */     }
/*      */ 
/*      */     public int upperBound(RawComparable key)
/*      */     {
/* 2195 */       if (this.comparator == null) {
/* 2196 */         throw new RuntimeException("Cannot search in unsorted TFile");
/*      */       }
/*      */ 
/* 2199 */       if (this.firstKey == null) {
/* 2200 */         return -1;
/*      */       }
/*      */ 
/* 2203 */       int ret = Utils.upperBound(this.index, key, this.comparator);
/* 2204 */       if (ret == this.index.size()) {
/* 2205 */         return -1;
/*      */       }
/* 2207 */       return ret;
/*      */     }
/*      */ 
/*      */     public TFileIndex(CompareUtils.BytesComparator comparator)
/*      */     {
/* 2214 */       this.index = new ArrayList();
/* 2215 */       this.recordNumIndex = new ArrayList();
/* 2216 */       this.comparator = comparator;
/*      */     }
/*      */ 
/*      */     public RawComparable getFirstKey() {
/* 2220 */       return this.firstKey;
/*      */     }
/*      */ 
/*      */     public TFile.Reader.Location getLocationByRecordNum(long recNum) {
/* 2224 */       int idx = Utils.upperBound(this.recordNumIndex, Long.valueOf(recNum));
/* 2225 */       long lastRecNum = idx == 0 ? 0L : ((Long)this.recordNumIndex.get(idx - 1)).longValue();
/* 2226 */       return new TFile.Reader.Location(idx, recNum - lastRecNum);
/*      */     }
/*      */ 
/*      */     public long getRecordNumByLocation(TFile.Reader.Location location) {
/* 2230 */       int blkIndex = location.getBlockIndex();
/* 2231 */       long lastRecNum = blkIndex == 0 ? 0L : ((Long)this.recordNumIndex.get(blkIndex - 1)).longValue();
/* 2232 */       return lastRecNum + location.getRecordIndex();
/*      */     }
/*      */ 
/*      */     public void setFirstKey(byte[] key, int offset, int length) {
/* 2236 */       this.firstKey = new ByteArray(new byte[length]);
/* 2237 */       System.arraycopy(key, offset, this.firstKey.buffer(), 0, length);
/*      */     }
/*      */ 
/*      */     public RawComparable getLastKey() {
/* 2241 */       if (this.index.size() == 0) {
/* 2242 */         return null;
/*      */       }
/* 2244 */       return new ByteArray(((TFile.TFileIndexEntry)this.index.get(this.index.size() - 1)).buffer());
/*      */     }
/*      */ 
/*      */     public void addEntry(TFile.TFileIndexEntry keyEntry) {
/* 2248 */       this.index.add(keyEntry);
/* 2249 */       this.sum += keyEntry.entries();
/* 2250 */       this.recordNumIndex.add(Long.valueOf(this.sum));
/*      */     }
/*      */ 
/*      */     public TFile.TFileIndexEntry getEntry(int bid) {
/* 2254 */       return (TFile.TFileIndexEntry)this.index.get(bid);
/*      */     }
/*      */ 
/*      */     public void write(DataOutput out) throws IOException {
/* 2258 */       if (this.firstKey == null) {
/* 2259 */         Utils.writeVInt(out, 0);
/* 2260 */         return;
/*      */       }
/*      */ 
/* 2263 */       DataOutputBuffer dob = new DataOutputBuffer();
/* 2264 */       Utils.writeVInt(dob, this.firstKey.size());
/* 2265 */       dob.write(this.firstKey.buffer());
/* 2266 */       Utils.writeVInt(out, dob.size());
/* 2267 */       out.write(dob.getData(), 0, dob.getLength());
/*      */ 
/* 2269 */       for (TFile.TFileIndexEntry entry : this.index) {
/* 2270 */         dob.reset();
/* 2271 */         entry.write(dob);
/* 2272 */         Utils.writeVInt(out, dob.getLength());
/* 2273 */         out.write(dob.getData(), 0, dob.getLength());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static final class TFileMeta
/*      */   {
/*      */     static final String BLOCK_NAME = "TFile.meta";
/*      */     final Utils.Version version;
/*      */     private long recordCount;
/*      */     private final String strComparator;
/*      */     private final CompareUtils.BytesComparator comparator;
/*      */ 
/*      */     public TFileMeta(String comparator)
/*      */     {
/* 2038 */       this.version = TFile.API_VERSION;
/* 2039 */       this.recordCount = 0L;
/* 2040 */       this.strComparator = (comparator == null ? "" : comparator);
/* 2041 */       this.comparator = makeComparator(this.strComparator);
/*      */     }
/*      */ 
/*      */     public TFileMeta(DataInput in) throws IOException
/*      */     {
/* 2046 */       this.version = new Utils.Version(in);
/* 2047 */       if (!this.version.compatibleWith(TFile.API_VERSION)) {
/* 2048 */         throw new RuntimeException("Incompatible TFile fileVersion.");
/*      */       }
/* 2050 */       this.recordCount = Utils.readVLong(in);
/* 2051 */       this.strComparator = Utils.readString(in);
/* 2052 */       this.comparator = makeComparator(this.strComparator);
/*      */     }
/*      */ 
/*      */     static CompareUtils.BytesComparator makeComparator(String comparator)
/*      */     {
/* 2057 */       if (comparator.length() == 0)
/*      */       {
/* 2059 */         return null;
/*      */       }
/* 2061 */       if (comparator.equals("memcmp"))
/*      */       {
/* 2063 */         return new CompareUtils.BytesComparator(new CompareUtils.MemcmpRawComparator());
/* 2064 */       }if (comparator.startsWith("jclass:")) {
/* 2065 */         String compClassName = comparator.substring("jclass:".length()).trim();
/*      */         try
/*      */         {
/* 2068 */           Class compClass = Class.forName(compClassName);
/*      */ 
/* 2070 */           return new CompareUtils.BytesComparator((RawComparator)compClass.newInstance());
/*      */         }
/*      */         catch (Exception e) {
/* 2073 */           throw new IllegalArgumentException("Failed to instantiate comparator: " + comparator + "(" + e.toString() + ")");
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2078 */       throw new IllegalArgumentException("Unsupported comparator: " + comparator);
/*      */     }
/*      */ 
/*      */     public void write(DataOutput out)
/*      */       throws IOException
/*      */     {
/* 2084 */       TFile.API_VERSION.write(out);
/* 2085 */       Utils.writeVLong(out, this.recordCount);
/* 2086 */       Utils.writeString(out, this.strComparator);
/*      */     }
/*      */ 
/*      */     public long getRecordCount() {
/* 2090 */       return this.recordCount;
/*      */     }
/*      */ 
/*      */     public void incRecordCount() {
/* 2094 */       this.recordCount += 1L;
/*      */     }
/*      */ 
/*      */     public boolean isSorted() {
/* 2098 */       return !this.strComparator.equals("");
/*      */     }
/*      */ 
/*      */     public String getComparatorString() {
/* 2102 */       return this.strComparator;
/*      */     }
/*      */ 
/*      */     public CompareUtils.BytesComparator getComparator() {
/* 2106 */       return this.comparator;
/*      */     }
/*      */ 
/*      */     public Utils.Version getVersion() {
/* 2110 */       return this.version;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class Reader
/*      */     implements Closeable
/*      */   {
/*      */     final BCFile.Reader readerBCF;
/*  681 */     TFile.TFileIndex tfileIndex = null;
/*      */     final TFile.TFileMeta tfileMeta;
/*      */     final CompareUtils.BytesComparator comparator;
/*      */     private final Location begin;
/*      */     private final Location end;
/*      */ 
/*      */     public Reader(FSDataInputStream fsdis, long fileLength, Configuration conf)
/*      */       throws IOException
/*      */     {
/*  796 */       this.readerBCF = new BCFile.Reader(fsdis, fileLength, conf);
/*      */ 
/*  799 */       BCFile.Reader.BlockReader brMeta = this.readerBCF.getMetaBlock("TFile.meta");
/*      */       try {
/*  801 */         this.tfileMeta = new TFile.TFileMeta(brMeta);
/*      */       } finally {
/*  803 */         brMeta.close();
/*      */       }
/*      */ 
/*  806 */       this.comparator = this.tfileMeta.getComparator();
/*      */ 
/*  808 */       this.begin = new Location(0, 0L);
/*  809 */       this.end = new Location(this.readerBCF.getBlockCount(), 0L);
/*      */     }
/*      */ 
/*      */     public void close()
/*      */       throws IOException
/*      */     {
/*  817 */       this.readerBCF.close();
/*      */     }
/*      */ 
/*      */     Location begin()
/*      */     {
/*  827 */       return this.begin;
/*      */     }
/*      */ 
/*      */     Location end()
/*      */     {
/*  836 */       return this.end;
/*      */     }
/*      */ 
/*      */     public String getComparatorName()
/*      */     {
/*  847 */       return this.tfileMeta.getComparatorString();
/*      */     }
/*      */ 
/*      */     public boolean isSorted()
/*      */     {
/*  856 */       return this.tfileMeta.isSorted();
/*      */     }
/*      */ 
/*      */     public long getEntryCount()
/*      */     {
/*  865 */       return this.tfileMeta.getRecordCount();
/*      */     }
/*      */ 
/*      */     synchronized void checkTFileDataIndex()
/*      */       throws IOException
/*      */     {
/*  874 */       if (this.tfileIndex == null) {
/*  875 */         BCFile.Reader.BlockReader brIndex = this.readerBCF.getMetaBlock("TFile.index");
/*      */         try {
/*  877 */           this.tfileIndex = new TFile.TFileIndex(this.readerBCF.getBlockCount(), brIndex, this.tfileMeta.getComparator());
/*      */         }
/*      */         finally
/*      */         {
/*  881 */           brIndex.close();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public RawComparable getFirstKey()
/*      */       throws IOException
/*      */     {
/*  893 */       checkTFileDataIndex();
/*  894 */       return this.tfileIndex.getFirstKey();
/*      */     }
/*      */ 
/*      */     public RawComparable getLastKey()
/*      */       throws IOException
/*      */     {
/*  904 */       checkTFileDataIndex();
/*  905 */       return this.tfileIndex.getLastKey();
/*      */     }
/*      */ 
/*      */     public Comparator<TFile.Reader.Scanner.Entry> getEntryComparator()
/*      */     {
/*  917 */       if (!isSorted()) {
/*  918 */         throw new RuntimeException("Entries are not comparable for unsorted TFiles");
/*      */       }
/*      */ 
/*  922 */       return new Comparator()
/*      */       {
/*      */         public int compare(TFile.Reader.Scanner.Entry o1, TFile.Reader.Scanner.Entry o2)
/*      */         {
/*  931 */           return TFile.Reader.this.comparator.compare(o1.getKeyBuffer(), 0, o1.getKeyLength(), o2.getKeyBuffer(), 0, o2.getKeyLength());
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public Comparator<RawComparable> getComparator()
/*      */     {
/*  944 */       return this.comparator;
/*      */     }
/*      */ 
/*      */     public DataInputStream getMetaBlock(String name)
/*      */       throws IOException, MetaBlockDoesNotExist
/*      */     {
/*  960 */       return this.readerBCF.getMetaBlock(name);
/*      */     }
/*      */ 
/*      */     Location getBlockContainsKey(RawComparable key, boolean greater)
/*      */       throws IOException
/*      */     {
/*  978 */       if (!isSorted()) {
/*  979 */         throw new RuntimeException("Seeking in unsorted TFile");
/*      */       }
/*  981 */       checkTFileDataIndex();
/*  982 */       int blkIndex = greater ? this.tfileIndex.upperBound(key) : this.tfileIndex.lowerBound(key);
/*      */ 
/*  984 */       if (blkIndex < 0) return this.end;
/*  985 */       return new Location(blkIndex, 0L);
/*      */     }
/*      */ 
/*      */     Location getLocationByRecordNum(long recNum) throws IOException {
/*  989 */       checkTFileDataIndex();
/*  990 */       return this.tfileIndex.getLocationByRecordNum(recNum);
/*      */     }
/*      */ 
/*      */     long getRecordNumByLocation(Location location) throws IOException {
/*  994 */       checkTFileDataIndex();
/*  995 */       return this.tfileIndex.getRecordNumByLocation(location);
/*      */     }
/*      */ 
/*      */     int compareKeys(byte[] a, int o1, int l1, byte[] b, int o2, int l2) {
/*  999 */       if (!isSorted()) {
/* 1000 */         throw new RuntimeException("Cannot compare keys for unsorted TFiles.");
/*      */       }
/* 1002 */       return this.comparator.compare(a, o1, l1, b, o2, l2);
/*      */     }
/*      */ 
/*      */     int compareKeys(RawComparable a, RawComparable b) {
/* 1006 */       if (!isSorted()) {
/* 1007 */         throw new RuntimeException("Cannot compare keys for unsorted TFiles.");
/*      */       }
/* 1009 */       return this.comparator.compare(a, b);
/*      */     }
/*      */ 
/*      */     Location getLocationNear(long offset)
/*      */     {
/* 1023 */       int blockIndex = this.readerBCF.getBlockIndexNear(offset);
/* 1024 */       if (blockIndex == -1) return this.end;
/* 1025 */       return new Location(blockIndex, 0L);
/*      */     }
/*      */ 
/*      */     public long getRecordNumNear(long offset)
/*      */       throws IOException
/*      */     {
/* 1040 */       return getRecordNumByLocation(getLocationNear(offset));
/*      */     }
/*      */ 
/*      */     public RawComparable getKeyNear(long offset)
/*      */       throws IOException
/*      */     {
/* 1055 */       int blockIndex = this.readerBCF.getBlockIndexNear(offset);
/* 1056 */       if (blockIndex == -1) return null;
/* 1057 */       checkTFileDataIndex();
/* 1058 */       return new ByteArray(this.tfileIndex.getEntry(blockIndex).key);
/*      */     }
/*      */ 
/*      */     public Scanner createScanner()
/*      */       throws IOException
/*      */     {
/* 1069 */       return new Scanner(this, this.begin, this.end);
/*      */     }
/*      */ 
/*      */     public Scanner createScannerByByteRange(long offset, long length)
/*      */       throws IOException
/*      */     {
/* 1086 */       return new Scanner(this, offset, offset + length);
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public Scanner createScanner(byte[] beginKey, byte[] endKey)
/*      */       throws IOException
/*      */     {
/* 1107 */       return createScannerByKey(beginKey, endKey);
/*      */     }
/*      */ 
/*      */     public Scanner createScannerByKey(byte[] beginKey, byte[] endKey)
/*      */       throws IOException
/*      */     {
/* 1125 */       return createScannerByKey(beginKey == null ? null : new ByteArray(beginKey, 0, beginKey.length), endKey == null ? null : new ByteArray(endKey, 0, endKey.length));
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public Scanner createScanner(RawComparable beginKey, RawComparable endKey)
/*      */       throws IOException
/*      */     {
/* 1149 */       return createScannerByKey(beginKey, endKey);
/*      */     }
/*      */ 
/*      */     public Scanner createScannerByKey(RawComparable beginKey, RawComparable endKey)
/*      */       throws IOException
/*      */     {
/* 1167 */       if ((beginKey != null) && (endKey != null) && (compareKeys(beginKey, endKey) >= 0))
/*      */       {
/* 1169 */         return new Scanner(this, beginKey, beginKey);
/*      */       }
/* 1171 */       return new Scanner(this, beginKey, endKey);
/*      */     }
/*      */ 
/*      */     public Scanner createScannerByRecordNum(long beginRecNum, long endRecNum)
/*      */       throws IOException
/*      */     {
/* 1187 */       if (beginRecNum < 0L) beginRecNum = 0L;
/* 1188 */       if ((endRecNum < 0L) || (endRecNum > getEntryCount())) {
/* 1189 */         endRecNum = getEntryCount();
/*      */       }
/* 1191 */       return new Scanner(this, getLocationByRecordNum(beginRecNum), getLocationByRecordNum(endRecNum));
/*      */     }
/*      */ 
/*      */     long getBlockEntryCount(int curBid)
/*      */     {
/* 2017 */       return this.tfileIndex.getEntry(curBid).entries();
/*      */     }
/*      */ 
/*      */     BCFile.Reader.BlockReader getBlockReader(int blockIndex) throws IOException {
/* 2021 */       return this.readerBCF.getDataBlock(blockIndex);
/*      */     }
/*      */ 
/*      */     public static class Scanner
/*      */       implements Closeable
/*      */     {
/*      */       final TFile.Reader reader;
/*      */       private BCFile.Reader.BlockReader blkReader;
/*      */       TFile.Reader.Location beginLocation;
/*      */       TFile.Reader.Location endLocation;
/*      */       TFile.Reader.Location currentLocation;
/* 1225 */       boolean valueChecked = false;
/*      */       final byte[] keyBuffer;
/* 1229 */       int klen = -1;
/*      */       static final int MAX_VAL_TRANSFER_BUF_SIZE = 131072;
/*      */       BytesWritable valTransferBuffer;
/*      */       DataInputBuffer keyDataInputStream;
/*      */       Chunk.ChunkDecoder valueBufferInputStream;
/*      */       DataInputStream valueDataInputStream;
/*      */       int vlen;
/*      */ 
/*      */       protected Scanner(TFile.Reader reader, long offBegin, long offEnd)
/*      */         throws IOException
/*      */       {
/* 1257 */         this(reader, reader.getLocationNear(offBegin), reader.getLocationNear(offEnd));
/*      */       }
/*      */ 
/*      */       Scanner(TFile.Reader reader, TFile.Reader.Location begin, TFile.Reader.Location end)
/*      */         throws IOException
/*      */       {
/* 1273 */         this.reader = reader;
/*      */ 
/* 1275 */         reader.checkTFileDataIndex();
/* 1276 */         this.beginLocation = begin;
/* 1277 */         this.endLocation = end;
/*      */ 
/* 1279 */         this.valTransferBuffer = new BytesWritable();
/*      */ 
/* 1282 */         this.keyBuffer = new byte[65536];
/* 1283 */         this.keyDataInputStream = new DataInputBuffer();
/* 1284 */         this.valueBufferInputStream = new Chunk.ChunkDecoder();
/* 1285 */         this.valueDataInputStream = new DataInputStream(this.valueBufferInputStream);
/*      */ 
/* 1287 */         if (this.beginLocation.compareTo(this.endLocation) >= 0) {
/* 1288 */           this.currentLocation = new TFile.Reader.Location(this.endLocation);
/*      */         } else {
/* 1290 */           this.currentLocation = new TFile.Reader.Location(0, 0L);
/* 1291 */           initBlock(this.beginLocation.getBlockIndex());
/* 1292 */           inBlockAdvance(this.beginLocation.getRecordIndex());
/*      */         }
/*      */       }
/*      */ 
/*      */       protected Scanner(TFile.Reader reader, RawComparable beginKey, RawComparable endKey)
/*      */         throws IOException
/*      */       {
/* 1311 */         this(reader, beginKey == null ? reader.begin() : reader.getBlockContainsKey(beginKey, false), reader.end());
/*      */ 
/* 1313 */         if (beginKey != null) {
/* 1314 */           inBlockAdvance(beginKey, false);
/* 1315 */           this.beginLocation.set(this.currentLocation);
/*      */         }
/* 1317 */         if (endKey != null) {
/* 1318 */           seekTo(endKey, false);
/* 1319 */           this.endLocation.set(this.currentLocation);
/* 1320 */           seekTo(this.beginLocation);
/*      */         }
/*      */       }
/*      */ 
/*      */       public boolean seekTo(byte[] key)
/*      */         throws IOException
/*      */       {
/* 1335 */         return seekTo(key, 0, key.length);
/*      */       }
/*      */ 
/*      */       public boolean seekTo(byte[] key, int keyOffset, int keyLen)
/*      */         throws IOException
/*      */       {
/* 1354 */         return seekTo(new ByteArray(key, keyOffset, keyLen), false);
/*      */       }
/*      */ 
/*      */       private boolean seekTo(RawComparable key, boolean beyond) throws IOException
/*      */       {
/* 1359 */         TFile.Reader.Location l = this.reader.getBlockContainsKey(key, beyond);
/* 1360 */         if (l.compareTo(this.beginLocation) < 0) {
/* 1361 */           l = this.beginLocation;
/* 1362 */         } else if (l.compareTo(this.endLocation) >= 0) {
/* 1363 */           seekTo(this.endLocation);
/* 1364 */           return false;
/*      */         }
/*      */ 
/* 1369 */         if ((atEnd()) || (l.getBlockIndex() != this.currentLocation.getBlockIndex()) || (compareCursorKeyTo(key) >= 0))
/*      */         {
/* 1372 */           seekTo(l);
/*      */         }
/*      */ 
/* 1375 */         return inBlockAdvance(key, beyond);
/*      */       }
/*      */ 
/*      */       private void seekTo(TFile.Reader.Location l)
/*      */         throws IOException
/*      */       {
/* 1388 */         if (l.compareTo(this.beginLocation) < 0) {
/* 1389 */           throw new IllegalArgumentException("Attempt to seek before the begin location.");
/*      */         }
/*      */ 
/* 1393 */         if (l.compareTo(this.endLocation) > 0) {
/* 1394 */           throw new IllegalArgumentException("Attempt to seek after the end location.");
/*      */         }
/*      */ 
/* 1398 */         if (l.compareTo(this.endLocation) == 0) {
/* 1399 */           parkCursorAtEnd();
/* 1400 */           return;
/*      */         }
/*      */ 
/* 1403 */         if (l.getBlockIndex() != this.currentLocation.getBlockIndex())
/*      */         {
/* 1405 */           initBlock(l.getBlockIndex());
/*      */         } else {
/* 1407 */           if (this.valueChecked)
/*      */           {
/* 1410 */             inBlockAdvance(1L);
/*      */           }
/* 1412 */           if (l.getRecordIndex() < this.currentLocation.getRecordIndex()) {
/* 1413 */             initBlock(l.getBlockIndex());
/*      */           }
/*      */         }
/*      */ 
/* 1417 */         inBlockAdvance(l.getRecordIndex() - this.currentLocation.getRecordIndex());
/*      */       }
/*      */ 
/*      */       public void rewind()
/*      */         throws IOException
/*      */       {
/* 1429 */         seekTo(this.beginLocation);
/*      */       }
/*      */ 
/*      */       public void seekToEnd()
/*      */         throws IOException
/*      */       {
/* 1439 */         parkCursorAtEnd();
/*      */       }
/*      */ 
/*      */       public void lowerBound(byte[] key)
/*      */         throws IOException
/*      */       {
/* 1452 */         lowerBound(key, 0, key.length);
/*      */       }
/*      */ 
/*      */       public void lowerBound(byte[] key, int keyOffset, int keyLen)
/*      */         throws IOException
/*      */       {
/* 1470 */         seekTo(new ByteArray(key, keyOffset, keyLen), false);
/*      */       }
/*      */ 
/*      */       public void upperBound(byte[] key)
/*      */         throws IOException
/*      */       {
/* 1483 */         upperBound(key, 0, key.length);
/*      */       }
/*      */ 
/*      */       public void upperBound(byte[] key, int keyOffset, int keyLen)
/*      */         throws IOException
/*      */       {
/* 1501 */         seekTo(new ByteArray(key, keyOffset, keyLen), true);
/*      */       }
/*      */ 
/*      */       public boolean advance()
/*      */         throws IOException
/*      */       {
/* 1513 */         if (atEnd()) {
/* 1514 */           return false;
/*      */         }
/*      */ 
/* 1517 */         int curBid = this.currentLocation.getBlockIndex();
/* 1518 */         long curRid = this.currentLocation.getRecordIndex();
/* 1519 */         long entriesInBlock = this.reader.getBlockEntryCount(curBid);
/* 1520 */         if (curRid + 1L >= entriesInBlock) {
/* 1521 */           if (this.endLocation.compareTo(curBid + 1, 0L) <= 0)
/*      */           {
/* 1523 */             parkCursorAtEnd();
/*      */           }
/*      */           else
/* 1526 */             initBlock(curBid + 1);
/*      */         }
/*      */         else {
/* 1529 */           inBlockAdvance(1L);
/*      */         }
/* 1531 */         return true;
/*      */       }
/*      */ 
/*      */       private void initBlock(int blockIndex)
/*      */         throws IOException
/*      */       {
/* 1540 */         this.klen = -1;
/* 1541 */         if (this.blkReader != null) {
/*      */           try {
/* 1543 */             this.blkReader.close();
/*      */           } finally {
/* 1545 */             this.blkReader = null;
/*      */           }
/*      */         }
/* 1548 */         this.blkReader = this.reader.getBlockReader(blockIndex);
/* 1549 */         this.currentLocation.set(blockIndex, 0L);
/*      */       }
/*      */ 
/*      */       private void parkCursorAtEnd() throws IOException {
/* 1553 */         this.klen = -1;
/* 1554 */         this.currentLocation.set(this.endLocation);
/* 1555 */         if (this.blkReader != null)
/*      */           try {
/* 1557 */             this.blkReader.close();
/*      */           } finally {
/* 1559 */             this.blkReader = null;
/*      */           }
/*      */       }
/*      */ 
/*      */       public void close()
/*      */         throws IOException
/*      */       {
/* 1570 */         parkCursorAtEnd();
/*      */       }
/*      */ 
/*      */       public boolean atEnd()
/*      */       {
/* 1579 */         return this.currentLocation.compareTo(this.endLocation) >= 0;
/*      */       }
/*      */ 
/*      */       void checkKey()
/*      */         throws IOException
/*      */       {
/* 1587 */         if (this.klen >= 0) return;
/* 1588 */         if (atEnd()) {
/* 1589 */           throw new EOFException("No key-value to read");
/*      */         }
/* 1591 */         this.klen = -1;
/* 1592 */         this.vlen = -1;
/* 1593 */         this.valueChecked = false;
/*      */ 
/* 1595 */         this.klen = Utils.readVInt(this.blkReader);
/* 1596 */         this.blkReader.readFully(this.keyBuffer, 0, this.klen);
/* 1597 */         this.valueBufferInputStream.reset(this.blkReader);
/* 1598 */         if (this.valueBufferInputStream.isLastChunk())
/* 1599 */           this.vlen = this.valueBufferInputStream.getRemain();
/*      */       }
/*      */ 
/*      */       public Entry entry()
/*      */         throws IOException
/*      */       {
/* 1610 */         checkKey();
/* 1611 */         return new Entry();
/*      */       }
/*      */ 
/*      */       public long getRecordNum()
/*      */         throws IOException
/*      */       {
/* 1620 */         return this.reader.getRecordNumByLocation(this.currentLocation);
/*      */       }
/*      */ 
/*      */       int compareCursorKeyTo(RawComparable other)
/*      */         throws IOException
/*      */       {
/* 1633 */         checkKey();
/* 1634 */         return this.reader.compareKeys(this.keyBuffer, 0, this.klen, other.buffer(), other.offset(), other.size());
/*      */       }
/*      */ 
/*      */       private void inBlockAdvance(long n)
/*      */         throws IOException
/*      */       {
/* 1972 */         for (long i = 0L; i < n; i += 1L) {
/* 1973 */           checkKey();
/* 1974 */           if (!this.valueBufferInputStream.isClosed()) {
/* 1975 */             this.valueBufferInputStream.close();
/*      */           }
/* 1977 */           this.klen = -1;
/* 1978 */           this.currentLocation.incRecordIndex();
/*      */         }
/*      */       }
/*      */ 
/*      */       private boolean inBlockAdvance(RawComparable key, boolean greater)
/*      */         throws IOException
/*      */       {
/* 1995 */         int curBid = this.currentLocation.getBlockIndex();
/* 1996 */         long entryInBlock = this.reader.getBlockEntryCount(curBid);
/* 1997 */         if (curBid == this.endLocation.getBlockIndex()) {
/* 1998 */           entryInBlock = this.endLocation.getRecordIndex();
/*      */         }
/*      */ 
/* 2001 */         while (this.currentLocation.getRecordIndex() < entryInBlock) {
/* 2002 */           int cmp = compareCursorKeyTo(key);
/* 2003 */           if (cmp > 0) return false;
/* 2004 */           if ((cmp == 0) && (!greater)) return true;
/* 2005 */           if (!this.valueBufferInputStream.isClosed()) {
/* 2006 */             this.valueBufferInputStream.close();
/*      */           }
/* 2008 */           this.klen = -1;
/* 2009 */           this.currentLocation.incRecordIndex();
/*      */         }
/*      */ 
/* 2012 */         throw new RuntimeException("Cannot find matching key in block.");
/*      */       }
/*      */ 
/*      */       public class Entry
/*      */         implements Comparable<RawComparable>
/*      */       {
/*      */         public Entry()
/*      */         {
/*      */         }
/*      */ 
/*      */         public int getKeyLength()
/*      */         {
/* 1648 */           return TFile.Reader.Scanner.this.klen;
/*      */         }
/*      */ 
/*      */         byte[] getKeyBuffer() {
/* 1652 */           return TFile.Reader.Scanner.this.keyBuffer;
/*      */         }
/*      */ 
/*      */         public void get(BytesWritable key, BytesWritable value)
/*      */           throws IOException
/*      */         {
/* 1667 */           getKey(key);
/* 1668 */           getValue(value);
/*      */         }
/*      */ 
/*      */         public int getKey(BytesWritable key)
/*      */           throws IOException
/*      */         {
/* 1680 */           key.setSize(getKeyLength());
/* 1681 */           getKey(key.get());
/* 1682 */           return key.getSize();
/*      */         }
/*      */ 
/*      */         public long getValue(BytesWritable value)
/*      */           throws IOException
/*      */         {
/* 1695 */           DataInputStream dis = getValueStream();
/* 1696 */           int size = 0;
/*      */           try
/*      */           {
/*      */             int remain;
/* 1699 */             while ((remain = TFile.Reader.Scanner.this.valueBufferInputStream.getRemain()) > 0) {
/* 1700 */               value.setSize(size + remain);
/* 1701 */               dis.readFully(value.get(), size, remain);
/* 1702 */               size += remain;
/*      */             }
/* 1704 */             return value.getSize();
/*      */           } finally {
/* 1706 */             dis.close();
/*      */           }
/*      */         }
/*      */ 
/*      */         public int writeKey(OutputStream out)
/*      */           throws IOException
/*      */         {
/* 1721 */           out.write(TFile.Reader.Scanner.this.keyBuffer, 0, TFile.Reader.Scanner.this.klen);
/* 1722 */           return TFile.Reader.Scanner.this.klen;
/*      */         }
/*      */ 
/*      */         public long writeValue(OutputStream out)
/*      */           throws IOException
/*      */         {
/* 1736 */           DataInputStream dis = getValueStream();
/* 1737 */           long size = 0L;
/*      */           try
/*      */           {
/*      */             int chunkSize;
/* 1740 */             while ((chunkSize = TFile.Reader.Scanner.this.valueBufferInputStream.getRemain()) > 0) {
/* 1741 */               chunkSize = Math.min(chunkSize, 131072);
/* 1742 */               TFile.Reader.Scanner.this.valTransferBuffer.setSize(chunkSize);
/* 1743 */               dis.readFully(TFile.Reader.Scanner.this.valTransferBuffer.get(), 0, chunkSize);
/* 1744 */               out.write(TFile.Reader.Scanner.this.valTransferBuffer.get(), 0, chunkSize);
/* 1745 */               size += chunkSize;
/*      */             }
/* 1747 */             return size;
/*      */           } finally {
/* 1749 */             dis.close();
/*      */           }
/*      */         }
/*      */ 
/*      */         public int getKey(byte[] buf)
/*      */           throws IOException
/*      */         {
/* 1764 */           return getKey(buf, 0);
/*      */         }
/*      */ 
/*      */         public int getKey(byte[] buf, int offset)
/*      */           throws IOException
/*      */         {
/* 1780 */           if ((offset | buf.length - offset - TFile.Reader.Scanner.this.klen) < 0) {
/* 1781 */             throw new IndexOutOfBoundsException("Bufer not enough to store the key");
/*      */           }
/*      */ 
/* 1784 */           System.arraycopy(TFile.Reader.Scanner.this.keyBuffer, 0, buf, offset, TFile.Reader.Scanner.this.klen);
/* 1785 */           return TFile.Reader.Scanner.this.klen;
/*      */         }
/*      */ 
/*      */         public DataInputStream getKeyStream()
/*      */         {
/* 1795 */           TFile.Reader.Scanner.this.keyDataInputStream.reset(TFile.Reader.Scanner.this.keyBuffer, TFile.Reader.Scanner.this.klen);
/* 1796 */           return TFile.Reader.Scanner.this.keyDataInputStream;
/*      */         }
/*      */ 
/*      */         public int getValueLength()
/*      */         {
/* 1806 */           if (TFile.Reader.Scanner.this.vlen >= 0) {
/* 1807 */             return TFile.Reader.Scanner.this.vlen;
/*      */           }
/*      */ 
/* 1810 */           throw new RuntimeException("Value length unknown.");
/*      */         }
/*      */ 
/*      */         public int getValue(byte[] buf)
/*      */           throws IOException
/*      */         {
/* 1828 */           return getValue(buf, 0);
/*      */         }
/*      */ 
/*      */         public int getValue(byte[] buf, int offset)
/*      */           throws IOException
/*      */         {
/* 1845 */           DataInputStream dis = getValueStream();
/*      */           try {
/* 1847 */             if (isValueLengthKnown()) {
/* 1848 */               if ((offset | buf.length - offset - TFile.Reader.Scanner.this.vlen) < 0) {
/* 1849 */                 throw new IndexOutOfBoundsException("Buffer too small to hold value");
/*      */               }
/*      */ 
/* 1852 */               dis.readFully(buf, offset, TFile.Reader.Scanner.this.vlen);
/* 1853 */               return TFile.Reader.Scanner.this.vlen;
/*      */             }
/*      */ 
/* 1856 */             int nextOffset = offset;
/*      */             int n;
/* 1857 */             while (nextOffset < buf.length) {
/* 1858 */               n = dis.read(buf, nextOffset, buf.length - nextOffset);
/* 1859 */               if (n < 0) {
/*      */                 break;
/*      */               }
/* 1862 */               nextOffset += n;
/*      */             }
/* 1864 */             if (dis.read() >= 0)
/*      */             {
/* 1868 */               throw new IndexOutOfBoundsException("Buffer too small to hold value");
/*      */             }
/*      */ 
/* 1871 */             return nextOffset - offset;
/*      */           } finally {
/* 1873 */             dis.close();
/*      */           }
/*      */         }
/*      */ 
/*      */         public DataInputStream getValueStream()
/*      */           throws IOException
/*      */         {
/* 1888 */           if (TFile.Reader.Scanner.this.valueChecked == true) {
/* 1889 */             throw new IllegalStateException("Attempt to examine value multiple times.");
/*      */           }
/*      */ 
/* 1892 */           TFile.Reader.Scanner.this.valueChecked = true;
/* 1893 */           return TFile.Reader.Scanner.this.valueDataInputStream;
/*      */         }
/*      */ 
/*      */         public boolean isValueLengthKnown()
/*      */         {
/* 1906 */           return TFile.Reader.Scanner.this.vlen >= 0;
/*      */         }
/*      */ 
/*      */         public int compareTo(byte[] buf)
/*      */         {
/* 1918 */           return compareTo(buf, 0, buf.length);
/*      */         }
/*      */ 
/*      */         public int compareTo(byte[] buf, int offset, int length)
/*      */         {
/* 1934 */           return compareTo(new ByteArray(buf, offset, length));
/*      */         }
/*      */ 
/*      */         public int compareTo(RawComparable key)
/*      */         {
/* 1944 */           return TFile.Reader.Scanner.this.reader.compareKeys(TFile.Reader.Scanner.this.keyBuffer, 0, getKeyLength(), key.buffer(), key.offset(), key.size());
/*      */         }
/*      */ 
/*      */         public boolean equals(Object other)
/*      */         {
/* 1953 */           if (this == other) return true;
/* 1954 */           if (!(other instanceof Entry)) return false;
/* 1955 */           return ((Entry)other).compareTo(TFile.Reader.Scanner.this.keyBuffer, 0, getKeyLength()) == 0;
/*      */         }
/*      */ 
/*      */         public int hashCode()
/*      */         {
/* 1960 */           return WritableComparator.hashBytes(TFile.Reader.Scanner.this.keyBuffer, getKeyLength());
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     static final class Location
/*      */       implements Comparable<Location>, Cloneable
/*      */     {
/*      */       private int blockIndex;
/*      */       private long recordIndex;
/*      */ 
/*      */       Location(int blockIndex, long recordIndex)
/*      */       {
/*  698 */         set(blockIndex, recordIndex);
/*      */       }
/*      */ 
/*      */       void incRecordIndex() {
/*  702 */         this.recordIndex += 1L;
/*      */       }
/*      */ 
/*      */       Location(Location other) {
/*  706 */         set(other);
/*      */       }
/*      */ 
/*      */       int getBlockIndex() {
/*  710 */         return this.blockIndex;
/*      */       }
/*      */ 
/*      */       long getRecordIndex() {
/*  714 */         return this.recordIndex;
/*      */       }
/*      */ 
/*      */       void set(int blockIndex, long recordIndex) {
/*  718 */         if ((blockIndex | recordIndex) < 0L) {
/*  719 */           throw new IllegalArgumentException("Illegal parameter for BlockLocation.");
/*      */         }
/*      */ 
/*  722 */         this.blockIndex = blockIndex;
/*  723 */         this.recordIndex = recordIndex;
/*      */       }
/*      */ 
/*      */       void set(Location other) {
/*  727 */         set(other.blockIndex, other.recordIndex);
/*      */       }
/*      */ 
/*      */       public int compareTo(Location other)
/*      */       {
/*  735 */         return compareTo(other.blockIndex, other.recordIndex);
/*      */       }
/*      */ 
/*      */       int compareTo(int bid, long rid) {
/*  739 */         if (this.blockIndex == bid) {
/*  740 */           long ret = this.recordIndex - rid;
/*  741 */           if (ret > 0L) return 1;
/*  742 */           if (ret < 0L) return -1;
/*  743 */           return 0;
/*      */         }
/*  745 */         return this.blockIndex - bid;
/*      */       }
/*      */ 
/*      */       protected Location clone()
/*      */       {
/*  753 */         return new Location(this.blockIndex, this.recordIndex);
/*      */       }
/*      */ 
/*      */       public int hashCode()
/*      */       {
/*  761 */         int prime = 31;
/*  762 */         int result = 31 + this.blockIndex;
/*  763 */         result = (int)(31 * result + this.recordIndex);
/*  764 */         return result;
/*      */       }
/*      */ 
/*      */       public boolean equals(Object obj)
/*      */       {
/*  772 */         if (this == obj) return true;
/*  773 */         if (obj == null) return false;
/*  774 */         if (getClass() != obj.getClass()) return false;
/*  775 */         Location other = (Location)obj;
/*  776 */         if (this.blockIndex != other.blockIndex) return false;
/*  777 */         if (this.recordIndex != other.recordIndex) return false;
/*  778 */         return true;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class Writer
/*      */     implements Closeable
/*      */   {
/*      */     private final int sizeMinBlock;
/*      */     final TFile.TFileIndex tfileIndex;
/*      */     final TFile.TFileMeta tfileMeta;
/*      */     private BCFile.Writer writerBCF;
/*      */     BCFile.Writer.BlockAppender blkAppender;
/*      */     long blkRecordCount;
/*      */     BoundedByteArrayOutputStream currentKeyBufferOS;
/*      */     BoundedByteArrayOutputStream lastKeyBufferOS;
/*      */     private byte[] valueBuffer;
/*  236 */     State state = State.READY;
/*      */     Configuration conf;
/*  238 */     long errorCount = 0L;
/*      */ 
/*      */     public Writer(FSDataOutputStream fsdos, int minBlockSize, String compressName, String comparator, Configuration conf)
/*      */       throws IOException
/*      */     {
/*  278 */       this.sizeMinBlock = minBlockSize;
/*  279 */       this.tfileMeta = new TFile.TFileMeta(comparator);
/*  280 */       this.tfileIndex = new TFile.TFileIndex(this.tfileMeta.getComparator());
/*      */ 
/*  282 */       this.writerBCF = new BCFile.Writer(fsdos, compressName, conf);
/*  283 */       this.currentKeyBufferOS = new BoundedByteArrayOutputStream(65536);
/*  284 */       this.lastKeyBufferOS = new BoundedByteArrayOutputStream(65536);
/*  285 */       this.conf = conf;
/*      */     }
/*      */ 
/*      */     public void close()
/*      */       throws IOException
/*      */     {
/*  295 */       if (this.state == State.CLOSED) {
/*  296 */         return;
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/*  301 */         if (this.errorCount == 0L) {
/*  302 */           if (this.state != State.READY) {
/*  303 */             throw new IllegalStateException("Cannot close TFile in the middle of key-value insertion.");
/*      */           }
/*      */ 
/*  307 */           finishDataBlock(true);
/*      */ 
/*  310 */           BCFile.Writer.BlockAppender outMeta = this.writerBCF.prepareMetaBlock("TFile.meta", "none");
/*      */           try
/*      */           {
/*  314 */             this.tfileMeta.write(outMeta);
/*      */           } finally {
/*  316 */             outMeta.close();
/*      */           }
/*      */ 
/*  320 */           BCFile.Writer.BlockAppender outIndex = this.writerBCF.prepareMetaBlock("TFile.index");
/*      */           try
/*      */           {
/*  323 */             this.tfileIndex.write(outIndex);
/*      */           } finally {
/*  325 */             outIndex.close();
/*      */           }
/*      */ 
/*  328 */           this.writerBCF.close();
/*      */         }
/*      */       } finally {
/*  331 */         IOUtils.cleanup(TFile.LOG, new Closeable[] { this.blkAppender, this.writerBCF });
/*  332 */         this.blkAppender = null;
/*  333 */         this.writerBCF = null;
/*  334 */         this.state = State.CLOSED;
/*      */       }
/*      */     }
/*      */ 
/*      */     public void append(byte[] key, byte[] value)
/*      */       throws IOException
/*      */     {
/*  349 */       append(key, 0, key.length, value, 0, value.length);
/*      */     }
/*      */ 
/*      */     public void append(byte[] key, int koff, int klen, byte[] value, int voff, int vlen)
/*      */       throws IOException
/*      */     {
/*  375 */       if ((koff | klen | koff + klen | key.length - (koff + klen)) < 0) {
/*  376 */         throw new IndexOutOfBoundsException("Bad key buffer offset-length combination.");
/*      */       }
/*      */ 
/*  380 */       if ((voff | vlen | voff + vlen | value.length - (voff + vlen)) < 0) {
/*  381 */         throw new IndexOutOfBoundsException("Bad value buffer offset-length combination.");
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/*  386 */         DataOutputStream dosKey = prepareAppendKey(klen);
/*      */         try {
/*  388 */           this.errorCount += 1L;
/*  389 */           dosKey.write(key, koff, klen);
/*  390 */           this.errorCount -= 1L;
/*      */         } finally {
/*  392 */           dosKey.close();
/*      */         }
/*      */ 
/*  395 */         DataOutputStream dosValue = prepareAppendValue(vlen);
/*      */         try {
/*  397 */           this.errorCount += 1L;
/*  398 */           dosValue.write(value, voff, vlen);
/*  399 */           this.errorCount -= 1L;
/*      */         } finally {
/*  401 */           dosValue.close();
/*      */         }
/*      */       } finally {
/*  404 */         this.state = State.READY;
/*      */       }
/*      */     }
/*      */ 
/*      */     public DataOutputStream prepareAppendKey(int length)
/*      */       throws IOException
/*      */     {
/*  521 */       if (this.state != State.READY) {
/*  522 */         throw new IllegalStateException("Incorrect state to start a new key: " + this.state.name());
/*      */       }
/*      */ 
/*  526 */       initDataBlock();
/*  527 */       DataOutputStream ret = new KeyRegister(length);
/*  528 */       this.state = State.IN_KEY;
/*  529 */       return ret;
/*      */     }
/*      */ 
/*      */     public DataOutputStream prepareAppendValue(int length)
/*      */       throws IOException
/*      */     {
/*  548 */       if (this.state != State.END_KEY)
/*  549 */         throw new IllegalStateException("Incorrect state to start a new value: " + this.state.name());
/*      */       DataOutputStream ret;
/*      */       DataOutputStream ret;
/*  556 */       if (length < 0) {
/*  557 */         if (this.valueBuffer == null) {
/*  558 */           this.valueBuffer = new byte[TFile.getChunkBufferSize(this.conf)];
/*      */         }
/*  560 */         ret = new ValueRegister(new Chunk.ChunkEncoder(this.blkAppender, this.valueBuffer));
/*      */       } else {
/*  562 */         ret = new ValueRegister(new Chunk.SingleChunkEncoder(this.blkAppender, length));
/*      */       }
/*      */ 
/*  566 */       this.state = State.IN_VALUE;
/*  567 */       return ret;
/*      */     }
/*      */ 
/*      */     public DataOutputStream prepareMetaBlock(String name, String compressName)
/*      */       throws IOException, MetaBlockAlreadyExists
/*      */     {
/*  590 */       if (this.state != State.READY) {
/*  591 */         throw new IllegalStateException("Incorrect state to start a Meta Block: " + this.state.name());
/*      */       }
/*      */ 
/*  595 */       finishDataBlock(true);
/*  596 */       DataOutputStream outputStream = this.writerBCF.prepareMetaBlock(name, compressName);
/*      */ 
/*  598 */       return outputStream;
/*      */     }
/*      */ 
/*      */     public DataOutputStream prepareMetaBlock(String name)
/*      */       throws IOException, MetaBlockAlreadyExists
/*      */     {
/*  618 */       if (this.state != State.READY) {
/*  619 */         throw new IllegalStateException("Incorrect state to start a Meta Block: " + this.state.name());
/*      */       }
/*      */ 
/*  623 */       finishDataBlock(true);
/*  624 */       return this.writerBCF.prepareMetaBlock(name);
/*      */     }
/*      */ 
/*      */     private void initDataBlock()
/*      */       throws IOException
/*      */     {
/*  634 */       if (this.blkAppender == null)
/*  635 */         this.blkAppender = this.writerBCF.prepareDataBlock();
/*      */     }
/*      */ 
/*      */     void finishDataBlock(boolean bForceFinish)
/*      */       throws IOException
/*      */     {
/*  647 */       if (this.blkAppender == null) {
/*  648 */         return;
/*      */       }
/*      */ 
/*  652 */       if ((bForceFinish) || (this.blkAppender.getCompressedSize() >= this.sizeMinBlock))
/*      */       {
/*  655 */         TFile.TFileIndexEntry keyLast = new TFile.TFileIndexEntry(this.lastKeyBufferOS.getBuffer(), 0, this.lastKeyBufferOS.size(), this.blkRecordCount);
/*      */ 
/*  658 */         this.tfileIndex.addEntry(keyLast);
/*      */ 
/*  660 */         this.blkAppender.close();
/*  661 */         this.blkAppender = null;
/*  662 */         this.blkRecordCount = 0L;
/*      */       }
/*      */     }
/*      */ 
/*      */     private class ValueRegister extends DataOutputStream
/*      */     {
/*  473 */       private boolean closed = false;
/*      */ 
/*      */       public ValueRegister(OutputStream os) {
/*  476 */         super();
/*      */       }
/*      */ 
/*      */       public void flush()
/*      */       {
/*      */       }
/*      */ 
/*      */       public void close()
/*      */         throws IOException
/*      */       {
/*  487 */         if (this.closed == true) {
/*  488 */           return;
/*      */         }
/*      */         try
/*      */         {
/*  492 */           TFile.Writer.this.errorCount += 1L;
/*  493 */           super.close();
/*  494 */           TFile.Writer.this.blkRecordCount += 1L;
/*      */ 
/*  496 */           TFile.Writer.this.tfileMeta.incRecordCount();
/*  497 */           TFile.Writer.this.finishDataBlock(false);
/*  498 */           TFile.Writer.this.errorCount -= 1L;
/*      */         } finally {
/*  500 */           this.closed = true;
/*  501 */           TFile.Writer.this.state = TFile.Writer.State.READY;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     private class KeyRegister extends DataOutputStream
/*      */     {
/*      */       private final int expectedLength;
/*  413 */       private boolean closed = false;
/*      */ 
/*      */       public KeyRegister(int len) {
/*  416 */         super();
/*  417 */         if (len >= 0)
/*  418 */           TFile.Writer.this.currentKeyBufferOS.reset(len);
/*      */         else {
/*  420 */           TFile.Writer.this.currentKeyBufferOS.reset();
/*      */         }
/*  422 */         this.expectedLength = len;
/*      */       }
/*      */ 
/*      */       public void close() throws IOException
/*      */       {
/*  427 */         if (this.closed == true) {
/*  428 */           return;
/*      */         }
/*      */         try
/*      */         {
/*  432 */           TFile.Writer.this.errorCount += 1L;
/*  433 */           byte[] key = TFile.Writer.this.currentKeyBufferOS.getBuffer();
/*  434 */           int len = TFile.Writer.this.currentKeyBufferOS.size();
/*      */ 
/*  438 */           if ((this.expectedLength >= 0) && (this.expectedLength != len)) {
/*  439 */             throw new IOException("Incorrect key length: expected=" + this.expectedLength + " actual=" + len);
/*      */           }
/*      */ 
/*  443 */           Utils.writeVInt(TFile.Writer.this.blkAppender, len);
/*  444 */           TFile.Writer.this.blkAppender.write(key, 0, len);
/*  445 */           if (TFile.Writer.this.tfileIndex.getFirstKey() == null) {
/*  446 */             TFile.Writer.this.tfileIndex.setFirstKey(key, 0, len);
/*      */           }
/*      */ 
/*  449 */           if (TFile.Writer.this.tfileMeta.isSorted()) {
/*  450 */             byte[] lastKey = TFile.Writer.this.lastKeyBufferOS.getBuffer();
/*  451 */             int lastLen = TFile.Writer.this.lastKeyBufferOS.size();
/*  452 */             if (TFile.Writer.this.tfileMeta.getComparator().compare(key, 0, len, lastKey, 0, lastLen) < 0)
/*      */             {
/*  454 */               throw new IOException("Keys are not added in sorted order");
/*      */             }
/*      */           }
/*      */ 
/*  458 */           BoundedByteArrayOutputStream tmp = TFile.Writer.this.currentKeyBufferOS;
/*  459 */           TFile.Writer.this.currentKeyBufferOS = TFile.Writer.this.lastKeyBufferOS;
/*  460 */           TFile.Writer.this.lastKeyBufferOS = tmp;
/*  461 */           TFile.Writer.this.errorCount -= 1L;
/*      */         } finally {
/*  463 */           this.closed = true;
/*  464 */           TFile.Writer.this.state = TFile.Writer.State.END_KEY;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     private static enum State
/*      */     {
/*  227 */       READY, 
/*  228 */       IN_KEY, 
/*  229 */       END_KEY, 
/*  230 */       IN_VALUE, 
/*      */ 
/*  232 */       CLOSED;
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.file.tfile.TFile
 * JD-Core Version:    0.6.1
 */
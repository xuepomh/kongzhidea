/*    */ package org.apache.hadoop.io.file.tfile;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class MetaBlockDoesNotExist extends IOException
/*    */ {
/*    */   MetaBlockDoesNotExist(String s)
/*    */   {
/* 34 */     super(s);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.file.tfile.MetaBlockDoesNotExist
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.io.file.tfile;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import org.apache.hadoop.io.RawComparator;
/*    */ import org.apache.hadoop.io.WritableComparator;
/*    */ 
/*    */ class CompareUtils
/*    */ {
/*    */   public static final class MemcmpRawComparator
/*    */     implements RawComparator<Object>
/*    */   {
/*    */     public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2)
/*    */     {
/* 89 */       return WritableComparator.compareBytes(b1, s1, l1, b2, s2, l2);
/*    */     }
/*    */ 
/*    */     public int compare(Object o1, Object o2)
/*    */     {
/* 94 */       throw new RuntimeException("Object comparison not supported");
/*    */     }
/*    */   }
/*    */ 
/*    */   public static final class ScalarComparator
/*    */     implements Comparator<CompareUtils.Scalar>
/*    */   {
/*    */     public int compare(CompareUtils.Scalar o1, CompareUtils.Scalar o2)
/*    */     {
/* 78 */       long diff = o1.magnitude() - o2.magnitude();
/* 79 */       if (diff < 0L) return -1;
/* 80 */       if (diff > 0L) return 1;
/* 81 */       return 0;
/*    */     }
/*    */   }
/*    */ 
/*    */   static final class ScalarLong
/*    */     implements CompareUtils.Scalar
/*    */   {
/*    */     private long magnitude;
/*    */ 
/*    */     public ScalarLong(long m)
/*    */     {
/* 67 */       this.magnitude = m;
/*    */     }
/*    */ 
/*    */     public long magnitude() {
/* 71 */       return this.magnitude;
/*    */     }
/*    */   }
/*    */ 
/*    */   static abstract interface Scalar
/*    */   {
/*    */     public abstract long magnitude();
/*    */   }
/*    */ 
/*    */   public static final class BytesComparator
/*    */     implements Comparator<RawComparable>
/*    */   {
/*    */     private RawComparator<Object> cmp;
/*    */ 
/*    */     public BytesComparator(RawComparator<Object> cmp)
/*    */     {
/* 41 */       this.cmp = cmp;
/*    */     }
/*    */ 
/*    */     public int compare(RawComparable o1, RawComparable o2)
/*    */     {
/* 46 */       return compare(o1.buffer(), o1.offset(), o1.size(), o2.buffer(), o2.offset(), o2.size());
/*    */     }
/*    */ 
/*    */     public int compare(byte[] a, int off1, int len1, byte[] b, int off2, int len2)
/*    */     {
/* 52 */       return this.cmp.compare(a, off1, len1, b, off2, len2);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.file.tfile.CompareUtils
 * JD-Core Version:    0.6.1
 */
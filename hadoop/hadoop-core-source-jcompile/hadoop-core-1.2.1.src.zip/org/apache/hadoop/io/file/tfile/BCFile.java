/*     */ package org.apache.hadoop.io.file.tfile;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutput;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FSDataInputStream;
/*     */ import org.apache.hadoop.fs.FSDataOutputStream;
/*     */ import org.apache.hadoop.io.BytesWritable;
/*     */ import org.apache.hadoop.io.compress.Compressor;
/*     */ import org.apache.hadoop.io.compress.Decompressor;
/*     */ 
/*     */ final class BCFile
/*     */ {
/*  56 */   static final Utils.Version API_VERSION = new Utils.Version((short)1, (short)0);
/*  57 */   static final Log LOG = LogFactory.getLog(BCFile.class);
/*     */ 
/*     */   static final class BlockRegion
/*     */     implements CompareUtils.Scalar
/*     */   {
/*     */     private final long offset;
/*     */     private final long compressedSize;
/*     */     private final long rawSize;
/*     */ 
/*     */     public BlockRegion(DataInput in)
/*     */       throws IOException
/*     */     {
/* 945 */       this.offset = Utils.readVLong(in);
/* 946 */       this.compressedSize = Utils.readVLong(in);
/* 947 */       this.rawSize = Utils.readVLong(in);
/*     */     }
/*     */ 
/*     */     public BlockRegion(long offset, long compressedSize, long rawSize) {
/* 951 */       this.offset = offset;
/* 952 */       this.compressedSize = compressedSize;
/* 953 */       this.rawSize = rawSize;
/*     */     }
/*     */ 
/*     */     public void write(DataOutput out) throws IOException {
/* 957 */       Utils.writeVLong(out, this.offset);
/* 958 */       Utils.writeVLong(out, this.compressedSize);
/* 959 */       Utils.writeVLong(out, this.rawSize);
/*     */     }
/*     */ 
/*     */     public long getOffset() {
/* 963 */       return this.offset;
/*     */     }
/*     */ 
/*     */     public long getCompressedSize() {
/* 967 */       return this.compressedSize;
/*     */     }
/*     */ 
/*     */     public long getRawSize() {
/* 971 */       return this.rawSize;
/*     */     }
/*     */ 
/*     */     public long magnitude()
/*     */     {
/* 976 */       return this.offset;
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class Magic
/*     */   {
/* 908 */     private static final byte[] AB_MAGIC_BCFILE = { -47, 17, -45, 104, -111, -75, -41, -74, 57, -33, 65, 64, -110, -70, -31, 80 };
/*     */ 
/*     */     public static void readAndVerify(DataInput in)
/*     */       throws IOException
/*     */     {
/* 917 */       byte[] abMagic = new byte[size()];
/* 918 */       in.readFully(abMagic);
/*     */ 
/* 922 */       if (!Arrays.equals(abMagic, AB_MAGIC_BCFILE))
/* 923 */         throw new IOException("Not a valid BCFile.");
/*     */     }
/*     */ 
/*     */     public static void write(DataOutput out) throws IOException
/*     */     {
/* 928 */       out.write(AB_MAGIC_BCFILE);
/*     */     }
/*     */ 
/*     */     public static int size() {
/* 932 */       return AB_MAGIC_BCFILE.length;
/*     */     }
/*     */   }
/*     */ 
/*     */   static class DataIndex
/*     */   {
/*     */     static final String BLOCK_NAME = "BCFile.index";
/*     */     private final Compression.Algorithm defaultCompressionAlgorithm;
/*     */     private final ArrayList<BCFile.BlockRegion> listRegions;
/*     */ 
/*     */     public DataIndex(DataInput in)
/*     */       throws IOException
/*     */     {
/* 861 */       this.defaultCompressionAlgorithm = Compression.getCompressionAlgorithmByName(Utils.readString(in));
/*     */ 
/* 864 */       int n = Utils.readVInt(in);
/* 865 */       this.listRegions = new ArrayList(n);
/*     */ 
/* 867 */       for (int i = 0; i < n; i++) {
/* 868 */         BCFile.BlockRegion region = new BCFile.BlockRegion(in);
/* 869 */         this.listRegions.add(region);
/*     */       }
/*     */     }
/*     */ 
/*     */     public DataIndex(String defaultCompressionAlgorithmName)
/*     */     {
/* 875 */       this.defaultCompressionAlgorithm = Compression.getCompressionAlgorithmByName(defaultCompressionAlgorithmName);
/*     */ 
/* 878 */       this.listRegions = new ArrayList();
/*     */     }
/*     */ 
/*     */     public Compression.Algorithm getDefaultCompressionAlgorithm() {
/* 882 */       return this.defaultCompressionAlgorithm;
/*     */     }
/*     */ 
/*     */     public ArrayList<BCFile.BlockRegion> getBlockRegionList() {
/* 886 */       return this.listRegions;
/*     */     }
/*     */ 
/*     */     public void addBlockRegion(BCFile.BlockRegion region) {
/* 890 */       this.listRegions.add(region);
/*     */     }
/*     */ 
/*     */     public void write(DataOutput out) throws IOException {
/* 894 */       Utils.writeString(out, this.defaultCompressionAlgorithm.getName());
/*     */ 
/* 896 */       Utils.writeVInt(out, this.listRegions.size());
/*     */ 
/* 898 */       for (BCFile.BlockRegion region : this.listRegions)
/* 899 */         region.write(out);
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class MetaIndexEntry
/*     */   {
/*     */     private final String metaName;
/*     */     private final Compression.Algorithm compressionAlgorithm;
/*     */     private static final String defaultPrefix = "data:";
/*     */     private final BCFile.BlockRegion region;
/*     */ 
/*     */     public MetaIndexEntry(DataInput in)
/*     */       throws IOException
/*     */     {
/* 806 */       String fullMetaName = Utils.readString(in);
/* 807 */       if (fullMetaName.startsWith("data:")) {
/* 808 */         this.metaName = fullMetaName.substring("data:".length(), fullMetaName.length());
/*     */       }
/*     */       else
/*     */       {
/* 812 */         throw new IOException("Corrupted Meta region Index");
/*     */       }
/*     */ 
/* 815 */       this.compressionAlgorithm = Compression.getCompressionAlgorithmByName(Utils.readString(in));
/*     */ 
/* 817 */       this.region = new BCFile.BlockRegion(in);
/*     */     }
/*     */ 
/*     */     public MetaIndexEntry(String metaName, Compression.Algorithm compressionAlgorithm, BCFile.BlockRegion region)
/*     */     {
/* 822 */       this.metaName = metaName;
/* 823 */       this.compressionAlgorithm = compressionAlgorithm;
/* 824 */       this.region = region;
/*     */     }
/*     */ 
/*     */     public String getMetaName() {
/* 828 */       return this.metaName;
/*     */     }
/*     */ 
/*     */     public Compression.Algorithm getCompressionAlgorithm() {
/* 832 */       return this.compressionAlgorithm;
/*     */     }
/*     */ 
/*     */     public BCFile.BlockRegion getRegion() {
/* 836 */       return this.region;
/*     */     }
/*     */ 
/*     */     public void write(DataOutput out) throws IOException {
/* 840 */       Utils.writeString(out, "data:" + this.metaName);
/* 841 */       Utils.writeString(out, this.compressionAlgorithm.getName());
/*     */ 
/* 843 */       this.region.write(out);
/*     */     }
/*     */   }
/*     */ 
/*     */   static class MetaIndex
/*     */   {
/*     */     final Map<String, BCFile.MetaIndexEntry> index;
/*     */ 
/*     */     public MetaIndex()
/*     */     {
/* 764 */       this.index = new TreeMap();
/*     */     }
/*     */ 
/*     */     public MetaIndex(DataInput in) throws IOException
/*     */     {
/* 769 */       int count = Utils.readVInt(in);
/* 770 */       this.index = new TreeMap();
/*     */ 
/* 772 */       for (int nx = 0; nx < count; nx++) {
/* 773 */         BCFile.MetaIndexEntry indexEntry = new BCFile.MetaIndexEntry(in);
/* 774 */         this.index.put(indexEntry.getMetaName(), indexEntry);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void addEntry(BCFile.MetaIndexEntry indexEntry) {
/* 779 */       this.index.put(indexEntry.getMetaName(), indexEntry);
/*     */     }
/*     */ 
/*     */     public BCFile.MetaIndexEntry getMetaByName(String name) {
/* 783 */       return (BCFile.MetaIndexEntry)this.index.get(name);
/*     */     }
/*     */ 
/*     */     public void write(DataOutput out) throws IOException {
/* 787 */       Utils.writeVInt(out, this.index.size());
/*     */ 
/* 789 */       for (BCFile.MetaIndexEntry indexEntry : this.index.values())
/* 790 */         indexEntry.write(out);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Reader
/*     */     implements Closeable
/*     */   {
/*     */     private final FSDataInputStream in;
/*     */     private final Configuration conf;
/*     */     final BCFile.DataIndex dataIndex;
/*     */     final BCFile.MetaIndex metaIndex;
/*     */     final Utils.Version version;
/*     */ 
/*     */     public Reader(FSDataInputStream fin, long fileLength, Configuration conf)
/*     */       throws IOException
/*     */     {
/* 616 */       this.in = fin;
/* 617 */       this.conf = conf;
/*     */ 
/* 621 */       fin.seek(fileLength - BCFile.Magic.size() - Utils.Version.size() - 8L);
/*     */ 
/* 623 */       long offsetIndexMeta = fin.readLong();
/* 624 */       this.version = new Utils.Version(fin);
/* 625 */       BCFile.Magic.readAndVerify(fin);
/*     */ 
/* 627 */       if (!this.version.compatibleWith(BCFile.API_VERSION)) {
/* 628 */         throw new RuntimeException("Incompatible BCFile fileBCFileVersion.");
/*     */       }
/*     */ 
/* 632 */       fin.seek(offsetIndexMeta);
/* 633 */       this.metaIndex = new BCFile.MetaIndex(fin);
/*     */ 
/* 636 */       BlockReader blockR = getMetaBlock("BCFile.index");
/*     */       try {
/* 638 */         this.dataIndex = new BCFile.DataIndex(blockR);
/*     */       } finally {
/* 640 */         blockR.close();
/*     */       }
/*     */     }
/*     */ 
/*     */     public String getDefaultCompressionName()
/*     */     {
/* 650 */       return this.dataIndex.getDefaultCompressionAlgorithm().getName();
/*     */     }
/*     */ 
/*     */     public Utils.Version getBCFileVersion()
/*     */     {
/* 659 */       return this.version;
/*     */     }
/*     */ 
/*     */     public Utils.Version getAPIVersion()
/*     */     {
/* 668 */       return BCFile.API_VERSION;
/*     */     }
/*     */ 
/*     */     public void close()
/*     */     {
/*     */     }
/*     */ 
/*     */     public int getBlockCount()
/*     */     {
/* 684 */       return this.dataIndex.getBlockRegionList().size();
/*     */     }
/*     */ 
/*     */     public BlockReader getMetaBlock(String name)
/*     */       throws IOException, MetaBlockDoesNotExist
/*     */     {
/* 699 */       BCFile.MetaIndexEntry imeBCIndex = this.metaIndex.getMetaByName(name);
/* 700 */       if (imeBCIndex == null) {
/* 701 */         throw new MetaBlockDoesNotExist("name=" + name);
/*     */       }
/*     */ 
/* 704 */       BCFile.BlockRegion region = imeBCIndex.getRegion();
/* 705 */       return createReader(imeBCIndex.getCompressionAlgorithm(), region);
/*     */     }
/*     */ 
/*     */     public BlockReader getDataBlock(int blockIndex)
/*     */       throws IOException
/*     */     {
/* 717 */       if ((blockIndex < 0) || (blockIndex >= getBlockCount())) {
/* 718 */         throw new IndexOutOfBoundsException(String.format("blockIndex=%d, numBlocks=%d", new Object[] { Integer.valueOf(blockIndex), Integer.valueOf(getBlockCount()) }));
/*     */       }
/*     */ 
/* 722 */       BCFile.BlockRegion region = (BCFile.BlockRegion)this.dataIndex.getBlockRegionList().get(blockIndex);
/* 723 */       return createReader(this.dataIndex.getDefaultCompressionAlgorithm(), region);
/*     */     }
/*     */ 
/*     */     private BlockReader createReader(Compression.Algorithm compressAlgo, BCFile.BlockRegion region) throws IOException
/*     */     {
/* 728 */       RBlockState rbs = new RBlockState(compressAlgo, this.in, region, this.conf);
/* 729 */       return new BlockReader(rbs);
/*     */     }
/*     */ 
/*     */     public int getBlockIndexNear(long offset)
/*     */     {
/* 742 */       ArrayList list = this.dataIndex.getBlockRegionList();
/* 743 */       int idx = Utils.lowerBound(list, new CompareUtils.ScalarLong(offset), new CompareUtils.ScalarComparator());
/*     */ 
/* 747 */       if (idx == list.size()) {
/* 748 */         return -1;
/*     */       }
/*     */ 
/* 751 */       return idx;
/*     */     }
/*     */ 
/*     */     public static class BlockReader extends DataInputStream
/*     */     {
/*     */       private final BCFile.Reader.RBlockState rBlkState;
/* 544 */       private boolean closed = false;
/*     */ 
/*     */       BlockReader(BCFile.Reader.RBlockState rbs) {
/* 547 */         super();
/* 548 */         this.rBlkState = rbs;
/*     */       }
/*     */ 
/*     */       public void close()
/*     */         throws IOException
/*     */       {
/* 556 */         if (this.closed == true) {
/* 557 */           return;
/*     */         }
/*     */ 
/*     */         try
/*     */         {
/* 562 */           this.rBlkState.finish();
/*     */         } finally {
/* 564 */           this.closed = true;
/*     */         }
/*     */       }
/*     */ 
/*     */       public String getCompressionName()
/*     */       {
/* 574 */         return this.rBlkState.getCompressionName();
/*     */       }
/*     */ 
/*     */       public long getRawSize()
/*     */       {
/* 583 */         return this.rBlkState.getBlockRegion().getRawSize();
/*     */       }
/*     */ 
/*     */       public long getCompressedSize()
/*     */       {
/* 592 */         return this.rBlkState.getBlockRegion().getCompressedSize();
/*     */       }
/*     */ 
/*     */       public long getStartPos()
/*     */       {
/* 601 */         return this.rBlkState.getBlockRegion().getOffset();
/*     */       }
/*     */     }
/*     */ 
/*     */     private static final class RBlockState
/*     */     {
/*     */       private final Compression.Algorithm compressAlgo;
/*     */       private Decompressor decompressor;
/*     */       private final BCFile.BlockRegion region;
/*     */       private final InputStream in;
/*     */ 
/*     */       public RBlockState(Compression.Algorithm compressionAlgo, FSDataInputStream fsin, BCFile.BlockRegion region, Configuration conf)
/*     */         throws IOException
/*     */       {
/* 495 */         this.compressAlgo = compressionAlgo;
/* 496 */         this.region = region;
/* 497 */         this.decompressor = compressionAlgo.getDecompressor();
/*     */         try
/*     */         {
/* 500 */           this.in = this.compressAlgo.createDecompressionStream(new BoundedRangeFileInputStream(fsin, this.region.getOffset(), this.region.getCompressedSize()), this.decompressor, TFile.getFSInputBufferSize(conf));
/*     */         }
/*     */         catch (IOException e)
/*     */         {
/* 507 */           this.compressAlgo.returnDecompressor(this.decompressor);
/* 508 */           throw e;
/*     */         }
/*     */       }
/*     */ 
/*     */       public InputStream getInputStream()
/*     */       {
/* 518 */         return this.in;
/*     */       }
/*     */ 
/*     */       public String getCompressionName() {
/* 522 */         return this.compressAlgo.getName();
/*     */       }
/*     */ 
/*     */       public BCFile.BlockRegion getBlockRegion() {
/* 526 */         return this.region;
/*     */       }
/*     */ 
/*     */       public void finish() throws IOException {
/*     */         try {
/* 531 */           this.in.close();
/*     */         } finally {
/* 533 */           this.compressAlgo.returnDecompressor(this.decompressor);
/* 534 */           this.decompressor = null;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Writer
/*     */     implements Closeable
/*     */   {
/*     */     private final FSDataOutputStream out;
/*     */     private final Configuration conf;
/*     */     final BCFile.DataIndex dataIndex;
/*     */     final BCFile.MetaIndex metaIndex;
/*  76 */     boolean blkInProgress = false;
/*  77 */     private boolean metaBlkSeen = false;
/*  78 */     private boolean closed = false;
/*  79 */     long errorCount = 0L;
/*     */     private BytesWritable fsOutputBuffer;
/*     */ 
/*     */     public Writer(FSDataOutputStream fout, String compressionName, Configuration conf)
/*     */       throws IOException
/*     */     {
/* 287 */       if (fout.getPos() != 0L) {
/* 288 */         throw new IOException("Output file not at zero offset.");
/*     */       }
/*     */ 
/* 291 */       this.out = fout;
/* 292 */       this.conf = conf;
/* 293 */       this.dataIndex = new BCFile.DataIndex(compressionName);
/* 294 */       this.metaIndex = new BCFile.MetaIndex();
/* 295 */       this.fsOutputBuffer = new BytesWritable();
/* 296 */       BCFile.Magic.write(fout);
/*     */     }
/*     */ 
/*     */     public void close()
/*     */       throws IOException
/*     */     {
/* 304 */       if (this.closed == true) {
/* 305 */         return;
/*     */       }
/*     */       try
/*     */       {
/* 309 */         if (this.errorCount == 0L) {
/* 310 */           if (this.blkInProgress == true) {
/* 311 */             throw new IllegalStateException("Close() called with active block appender.");
/*     */           }
/*     */ 
/* 316 */           BlockAppender appender = prepareMetaBlock("BCFile.index", getDefaultCompressionAlgorithm());
/*     */           try
/*     */           {
/* 320 */             this.dataIndex.write(appender);
/*     */           } finally {
/* 322 */             appender.close();
/*     */           }
/*     */ 
/* 325 */           long offsetIndexMeta = this.out.getPos();
/* 326 */           this.metaIndex.write(this.out);
/*     */ 
/* 329 */           this.out.writeLong(offsetIndexMeta);
/*     */ 
/* 331 */           BCFile.API_VERSION.write(this.out);
/* 332 */           BCFile.Magic.write(this.out);
/* 333 */           this.out.flush();
/*     */         }
/*     */       } finally {
/* 336 */         this.closed = true;
/*     */       }
/*     */     }
/*     */ 
/*     */     private Compression.Algorithm getDefaultCompressionAlgorithm() {
/* 341 */       return this.dataIndex.getDefaultCompressionAlgorithm();
/*     */     }
/*     */ 
/*     */     private BlockAppender prepareMetaBlock(String name, Compression.Algorithm compressAlgo) throws IOException, MetaBlockAlreadyExists
/*     */     {
/* 346 */       if (this.blkInProgress == true) {
/* 347 */         throw new IllegalStateException("Cannot create Meta Block until previous block is closed.");
/*     */       }
/*     */ 
/* 351 */       if (this.metaIndex.getMetaByName(name) != null) {
/* 352 */         throw new MetaBlockAlreadyExists("name=" + name);
/*     */       }
/*     */ 
/* 355 */       MetaBlockRegister mbr = new MetaBlockRegister(name, compressAlgo);
/* 356 */       WBlockState wbs = new WBlockState(compressAlgo, this.out, this.fsOutputBuffer, this.conf);
/*     */ 
/* 358 */       BlockAppender ba = new BlockAppender(mbr, wbs);
/* 359 */       this.blkInProgress = true;
/* 360 */       this.metaBlkSeen = true;
/* 361 */       return ba;
/*     */     }
/*     */ 
/*     */     public BlockAppender prepareMetaBlock(String name, String compressionName)
/*     */       throws IOException, MetaBlockAlreadyExists
/*     */     {
/* 382 */       return prepareMetaBlock(name, Compression.getCompressionAlgorithmByName(compressionName));
/*     */     }
/*     */ 
/*     */     public BlockAppender prepareMetaBlock(String name)
/*     */       throws IOException, MetaBlockAlreadyExists
/*     */     {
/* 404 */       return prepareMetaBlock(name, getDefaultCompressionAlgorithm());
/*     */     }
/*     */ 
/*     */     public BlockAppender prepareDataBlock()
/*     */       throws IOException
/*     */     {
/* 417 */       if (this.blkInProgress == true) {
/* 418 */         throw new IllegalStateException("Cannot create Data Block until previous block is closed.");
/*     */       }
/*     */ 
/* 422 */       if (this.metaBlkSeen == true) {
/* 423 */         throw new IllegalStateException("Cannot create Data Block after Meta Blocks.");
/*     */       }
/*     */ 
/* 427 */       DataBlockRegister dbr = new DataBlockRegister();
/*     */ 
/* 429 */       WBlockState wbs = new WBlockState(getDefaultCompressionAlgorithm(), this.out, this.fsOutputBuffer, this.conf);
/*     */ 
/* 432 */       BlockAppender ba = new BlockAppender(dbr, wbs);
/* 433 */       this.blkInProgress = true;
/* 434 */       return ba;
/*     */     }
/*     */ 
/*     */     private class DataBlockRegister
/*     */       implements BCFile.Writer.BlockRegister
/*     */     {
/*     */       DataBlockRegister()
/*     */       {
/*     */       }
/*     */ 
/*     */       public void register(long raw, long begin, long end)
/*     */       {
/* 467 */         BCFile.Writer.this.dataIndex.addBlockRegion(new BCFile.BlockRegion(begin, end - begin, raw));
/*     */       }
/*     */     }
/*     */ 
/*     */     private class MetaBlockRegister
/*     */       implements BCFile.Writer.BlockRegister
/*     */     {
/*     */       private final String name;
/*     */       private final Compression.Algorithm compressAlgo;
/*     */ 
/*     */       MetaBlockRegister(String name, Compression.Algorithm compressAlgo)
/*     */       {
/* 446 */         this.name = name;
/* 447 */         this.compressAlgo = compressAlgo;
/*     */       }
/*     */ 
/*     */       public void register(long raw, long begin, long end) {
/* 451 */         BCFile.Writer.this.metaIndex.addEntry(new BCFile.MetaIndexEntry(this.name, this.compressAlgo, new BCFile.BlockRegion(begin, end - begin, raw)));
/*     */       }
/*     */     }
/*     */ 
/*     */     public class BlockAppender extends DataOutputStream
/*     */     {
/*     */       private final BCFile.Writer.BlockRegister blockRegister;
/*     */       private final BCFile.Writer.WBlockState wBlkState;
/* 201 */       private boolean closed = false;
/*     */ 
/*     */       BlockAppender(BCFile.Writer.BlockRegister register, BCFile.Writer.WBlockState wbs)
/*     */       {
/* 213 */         super();
/* 214 */         this.blockRegister = register;
/* 215 */         this.wBlkState = wbs;
/*     */       }
/*     */ 
/*     */       public long getRawSize()
/*     */         throws IOException
/*     */       {
/* 230 */         return size() & 0xFFFFFFFF;
/*     */       }
/*     */ 
/*     */       public long getCompressedSize()
/*     */         throws IOException
/*     */       {
/* 243 */         return this.wBlkState.getCompressedSize();
/*     */       }
/*     */ 
/*     */       public void flush()
/*     */       {
/*     */       }
/*     */ 
/*     */       public void close()
/*     */         throws IOException
/*     */       {
/* 258 */         if (this.closed == true)
/* 259 */           return;
/*     */         try
/*     */         {
/* 262 */           BCFile.Writer.this.errorCount += 1L;
/* 263 */           this.wBlkState.finish();
/* 264 */           this.blockRegister.register(getRawSize(), this.wBlkState.getStartPos(), this.wBlkState.getCurrentPos());
/*     */ 
/* 266 */           BCFile.Writer.this.errorCount -= 1L;
/*     */         } finally {
/* 268 */           this.closed = true;
/* 269 */           BCFile.Writer.this.blkInProgress = false;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     private static final class WBlockState
/*     */     {
/*     */       private final Compression.Algorithm compressAlgo;
/*     */       private Compressor compressor;
/*     */       private final FSDataOutputStream fsOut;
/*     */       private final long posStart;
/*     */       private final SimpleBufferedOutputStream fsBufferedOutput;
/*     */       private OutputStream out;
/*     */ 
/*     */       public WBlockState(Compression.Algorithm compressionAlgo, FSDataOutputStream fsOut, BytesWritable fsOutputBuffer, Configuration conf)
/*     */         throws IOException
/*     */       {
/* 121 */         this.compressAlgo = compressionAlgo;
/* 122 */         this.fsOut = fsOut;
/* 123 */         this.posStart = fsOut.getPos();
/*     */ 
/* 125 */         fsOutputBuffer.setCapacity(TFile.getFSOutputBufferSize(conf));
/*     */ 
/* 127 */         this.fsBufferedOutput = new SimpleBufferedOutputStream(this.fsOut, fsOutputBuffer.get());
/*     */ 
/* 129 */         this.compressor = this.compressAlgo.getCompressor();
/*     */         try
/*     */         {
/* 132 */           this.out = compressionAlgo.createCompressionStream(this.fsBufferedOutput, this.compressor, 0);
/*     */         }
/*     */         catch (IOException e)
/*     */         {
/* 136 */           this.compressAlgo.returnCompressor(this.compressor);
/* 137 */           throw e;
/*     */         }
/*     */       }
/*     */ 
/*     */       OutputStream getOutputStream()
/*     */       {
/* 147 */         return this.out;
/*     */       }
/*     */ 
/*     */       long getCurrentPos()
/*     */         throws IOException
/*     */       {
/* 157 */         return this.fsOut.getPos() + this.fsBufferedOutput.size();
/*     */       }
/*     */ 
/*     */       long getStartPos() {
/* 161 */         return this.posStart;
/*     */       }
/*     */ 
/*     */       long getCompressedSize()
/*     */         throws IOException
/*     */       {
/* 171 */         long ret = getCurrentPos() - this.posStart;
/* 172 */         return ret;
/*     */       }
/*     */ 
/*     */       public void finish()
/*     */         throws IOException
/*     */       {
/*     */         try
/*     */         {
/* 180 */           if (this.out != null) {
/* 181 */             this.out.flush();
/* 182 */             this.out = null;
/*     */           }
/*     */         } finally {
/* 185 */           this.compressAlgo.returnCompressor(this.compressor);
/* 186 */           this.compressor = null;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     private static abstract interface BlockRegister
/*     */     {
/*     */       public abstract void register(long paramLong1, long paramLong2, long paramLong3);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.file.tfile.BCFile
 * JD-Core Version:    0.6.1
 */
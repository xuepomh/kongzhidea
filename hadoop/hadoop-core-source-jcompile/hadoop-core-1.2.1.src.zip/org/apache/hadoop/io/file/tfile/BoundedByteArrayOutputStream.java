/*    */ package org.apache.hadoop.io.file.tfile;
/*    */ 
/*    */ import java.io.EOFException;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ class BoundedByteArrayOutputStream extends OutputStream
/*    */ {
/*    */   private final byte[] buffer;
/*    */   private int limit;
/*    */   private int count;
/*    */ 
/*    */   public BoundedByteArrayOutputStream(int capacity)
/*    */   {
/* 35 */     this(capacity, capacity);
/*    */   }
/*    */ 
/*    */   public BoundedByteArrayOutputStream(int capacity, int limit) {
/* 39 */     if ((capacity < limit) || ((capacity | limit) < 0)) {
/* 40 */       throw new IllegalArgumentException("Invalid capacity/limit");
/*    */     }
/* 42 */     this.buffer = new byte[capacity];
/* 43 */     this.limit = limit;
/* 44 */     this.count = 0;
/*    */   }
/*    */ 
/*    */   public void write(int b) throws IOException
/*    */   {
/* 49 */     if (this.count >= this.limit) {
/* 50 */       throw new EOFException("Reaching the limit of the buffer.");
/*    */     }
/* 52 */     this.buffer[(this.count++)] = (byte)b;
/*    */   }
/*    */ 
/*    */   public void write(byte[] b, int off, int len) throws IOException
/*    */   {
/* 57 */     if ((off < 0) || (off > b.length) || (len < 0) || (off + len > b.length) || (off + len < 0))
/*    */     {
/* 59 */       throw new IndexOutOfBoundsException();
/* 60 */     }if (len == 0) {
/* 61 */       return;
/*    */     }
/*    */ 
/* 64 */     if (this.count + len > this.limit) {
/* 65 */       throw new EOFException("Reach the limit of the buffer");
/*    */     }
/*    */ 
/* 68 */     System.arraycopy(b, off, this.buffer, this.count, len);
/* 69 */     this.count += len;
/*    */   }
/*    */ 
/*    */   public void reset(int newlim) {
/* 73 */     if (newlim > this.buffer.length) {
/* 74 */       throw new IndexOutOfBoundsException("Limit exceeds buffer size");
/*    */     }
/* 76 */     this.limit = newlim;
/* 77 */     this.count = 0;
/*    */   }
/*    */ 
/*    */   public void reset() {
/* 81 */     this.limit = this.buffer.length;
/* 82 */     this.count = 0;
/*    */   }
/*    */ 
/*    */   public int getLimit() {
/* 86 */     return this.limit;
/*    */   }
/*    */ 
/*    */   public byte[] getBuffer() {
/* 90 */     return this.buffer;
/*    */   }
/*    */ 
/*    */   public int size() {
/* 94 */     return this.count;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.file.tfile.BoundedByteArrayOutputStream
 * JD-Core Version:    0.6.1
 */
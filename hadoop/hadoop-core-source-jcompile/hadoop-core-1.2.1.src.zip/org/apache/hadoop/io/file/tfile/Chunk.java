/*     */ package org.apache.hadoop.io.file.tfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ final class Chunk
/*     */ {
/*     */   public static class SingleChunkEncoder extends OutputStream
/*     */   {
/*     */     private final DataOutputStream out;
/*     */     private int remain;
/* 365 */     private boolean closed = false;
/*     */ 
/*     */     public SingleChunkEncoder(DataOutputStream out, int size)
/*     */       throws IOException
/*     */     {
/* 379 */       this.out = out;
/* 380 */       this.remain = size;
/* 381 */       Utils.writeVInt(out, size);
/*     */     }
/*     */ 
/*     */     public void write(int b) throws IOException
/*     */     {
/* 386 */       if (this.remain > 0) {
/* 387 */         this.out.write(b);
/* 388 */         this.remain -= 1;
/*     */       } else {
/* 390 */         throw new IOException("Writing more bytes than advertised size.");
/*     */       }
/*     */     }
/*     */ 
/*     */     public void write(byte[] b) throws IOException
/*     */     {
/* 396 */       write(b, 0, b.length);
/*     */     }
/*     */ 
/*     */     public void write(byte[] b, int off, int len) throws IOException
/*     */     {
/* 401 */       if (this.remain >= len) {
/* 402 */         this.out.write(b, off, len);
/* 403 */         this.remain -= len;
/*     */       } else {
/* 405 */         throw new IOException("Writing more bytes than advertised size.");
/*     */       }
/*     */     }
/*     */ 
/*     */     public void flush() throws IOException
/*     */     {
/* 411 */       this.out.flush();
/*     */     }
/*     */ 
/*     */     public void close() throws IOException
/*     */     {
/* 416 */       if (this.closed == true) {
/* 417 */         return;
/*     */       }
/*     */       try
/*     */       {
/* 421 */         if (this.remain > 0)
/* 422 */           throw new IOException("Writing less bytes than advertised size.");
/*     */       }
/*     */       finally {
/* 425 */         this.closed = true;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class ChunkEncoder extends OutputStream
/*     */   {
/*     */     private DataOutputStream out;
/*     */     private byte[] buf;
/*     */     private int count;
/*     */ 
/*     */     public ChunkEncoder(DataOutputStream out, byte[] buf)
/*     */     {
/* 237 */       this.out = out;
/* 238 */       this.buf = buf;
/* 239 */       this.count = 0;
/*     */     }
/*     */ 
/*     */     private void writeChunk(byte[] chunk, int offset, int len, boolean last)
/*     */       throws IOException
/*     */     {
/* 255 */       if (last) {
/* 256 */         Utils.writeVInt(this.out, len);
/* 257 */         if (len > 0) {
/* 258 */           this.out.write(chunk, offset, len);
/*     */         }
/*     */       }
/* 261 */       else if (len > 0) {
/* 262 */         Utils.writeVInt(this.out, -len);
/* 263 */         this.out.write(chunk, offset, len);
/*     */       }
/*     */     }
/*     */ 
/*     */     private void writeBufData(byte[] data, int offset, int len)
/*     */       throws IOException
/*     */     {
/* 281 */       if (this.count + len > 0) {
/* 282 */         Utils.writeVInt(this.out, -(this.count + len));
/* 283 */         this.out.write(this.buf, 0, this.count);
/* 284 */         this.count = 0;
/* 285 */         this.out.write(data, offset, len);
/*     */       }
/*     */     }
/*     */ 
/*     */     private void flushBuffer()
/*     */       throws IOException
/*     */     {
/* 297 */       if (this.count > 0) {
/* 298 */         writeChunk(this.buf, 0, this.count, false);
/* 299 */         this.count = 0;
/*     */       }
/*     */     }
/*     */ 
/*     */     public void write(int b) throws IOException
/*     */     {
/* 305 */       if (this.count >= this.buf.length) {
/* 306 */         flushBuffer();
/*     */       }
/* 308 */       this.buf[(this.count++)] = (byte)b;
/*     */     }
/*     */ 
/*     */     public void write(byte[] b) throws IOException
/*     */     {
/* 313 */       write(b, 0, b.length);
/*     */     }
/*     */ 
/*     */     public void write(byte[] b, int off, int len) throws IOException
/*     */     {
/* 318 */       if (len + this.count >= this.buf.length)
/*     */       {
/* 324 */         writeBufData(b, off, len);
/* 325 */         return;
/*     */       }
/*     */ 
/* 328 */       System.arraycopy(b, off, this.buf, this.count, len);
/* 329 */       this.count += len;
/*     */     }
/*     */ 
/*     */     public void flush() throws IOException
/*     */     {
/* 334 */       flushBuffer();
/* 335 */       this.out.flush();
/*     */     }
/*     */ 
/*     */     public void close() throws IOException
/*     */     {
/* 340 */       if (this.buf != null)
/*     */         try {
/* 342 */           writeChunk(this.buf, 0, this.count, true);
/*     */         } finally {
/* 344 */           this.buf = null;
/* 345 */           this.out = null;
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class ChunkDecoder extends InputStream
/*     */   {
/*  43 */     private DataInputStream in = null;
/*     */     private boolean lastChunk;
/*  45 */     private int remain = 0;
/*     */     private boolean closed;
/*     */ 
/*     */     public ChunkDecoder()
/*     */     {
/*  49 */       this.lastChunk = true;
/*  50 */       this.closed = true;
/*     */     }
/*     */ 
/*     */     public void reset(DataInputStream downStream)
/*     */     {
/*  55 */       this.in = downStream;
/*  56 */       this.lastChunk = false;
/*  57 */       this.remain = 0;
/*  58 */       this.closed = false;
/*     */     }
/*     */ 
/*     */     public ChunkDecoder(DataInputStream in)
/*     */     {
/*  69 */       this.in = in;
/*  70 */       this.lastChunk = false;
/*  71 */       this.closed = false;
/*     */     }
/*     */ 
/*     */     public boolean isLastChunk()
/*     */       throws IOException
/*     */     {
/*  81 */       checkEOF();
/*  82 */       return this.lastChunk;
/*     */     }
/*     */ 
/*     */     public int getRemain()
/*     */       throws IOException
/*     */     {
/*  92 */       checkEOF();
/*  93 */       return this.remain;
/*     */     }
/*     */ 
/*     */     private void readLength()
/*     */       throws IOException
/*     */     {
/* 103 */       this.remain = Utils.readVInt(this.in);
/* 104 */       if (this.remain >= 0)
/* 105 */         this.lastChunk = true;
/*     */       else
/* 107 */         this.remain = (-this.remain);
/*     */     }
/*     */ 
/*     */     private boolean checkEOF()
/*     */       throws IOException
/*     */     {
/* 120 */       if (isClosed()) return true; while (true)
/*     */       {
/* 122 */         if (this.remain > 0) return false;
/* 123 */         if (this.lastChunk) return true;
/* 124 */         readLength();
/*     */       }
/*     */     }
/*     */ 
/*     */     public int available()
/*     */     {
/* 134 */       return this.remain;
/*     */     }
/*     */ 
/*     */     public int read() throws IOException
/*     */     {
/* 139 */       if (checkEOF()) return -1;
/* 140 */       int ret = this.in.read();
/* 141 */       if (ret < 0) throw new IOException("Corrupted chunk encoding stream");
/* 142 */       this.remain -= 1;
/* 143 */       return ret;
/*     */     }
/*     */ 
/*     */     public int read(byte[] b) throws IOException
/*     */     {
/* 148 */       return read(b, 0, b.length);
/*     */     }
/*     */ 
/*     */     public int read(byte[] b, int off, int len) throws IOException
/*     */     {
/* 153 */       if ((off | len | off + len | b.length - (off + len)) < 0) {
/* 154 */         throw new IndexOutOfBoundsException();
/*     */       }
/*     */ 
/* 157 */       if (!checkEOF()) {
/* 158 */         int n = Math.min(this.remain, len);
/* 159 */         int ret = this.in.read(b, off, n);
/* 160 */         if (ret < 0) throw new IOException("Corrupted chunk encoding stream");
/* 161 */         this.remain -= ret;
/* 162 */         return ret;
/*     */       }
/* 164 */       return -1;
/*     */     }
/*     */ 
/*     */     public long skip(long n) throws IOException
/*     */     {
/* 169 */       if (!checkEOF()) {
/* 170 */         long ret = this.in.skip(Math.min(this.remain, n));
/* 171 */         this.remain = (int)(this.remain - ret);
/* 172 */         return ret;
/*     */       }
/* 174 */       return 0L;
/*     */     }
/*     */ 
/*     */     public boolean markSupported()
/*     */     {
/* 179 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean isClosed() {
/* 183 */       return this.closed;
/*     */     }
/*     */ 
/*     */     public void close() throws IOException
/*     */     {
/* 188 */       if (!this.closed)
/*     */         try {
/* 190 */           while (!checkEOF())
/* 191 */             skip(2147483647L);
/*     */         }
/*     */         finally {
/* 194 */           this.closed = true;
/*     */         }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.file.tfile.Chunk
 * JD-Core Version:    0.6.1
 */
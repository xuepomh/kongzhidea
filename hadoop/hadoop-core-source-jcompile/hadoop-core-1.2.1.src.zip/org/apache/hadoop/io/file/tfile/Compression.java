/*     */ package org.apache.hadoop.io.file.tfile;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.io.compress.CodecPool;
/*     */ import org.apache.hadoop.io.compress.CompressionCodec;
/*     */ import org.apache.hadoop.io.compress.CompressionInputStream;
/*     */ import org.apache.hadoop.io.compress.CompressionOutputStream;
/*     */ import org.apache.hadoop.io.compress.Compressor;
/*     */ import org.apache.hadoop.io.compress.Decompressor;
/*     */ import org.apache.hadoop.io.compress.DefaultCodec;
/*     */ import org.apache.hadoop.util.ReflectionUtils;
/*     */ 
/*     */ final class Compression
/*     */ {
/*  43 */   static final Log LOG = LogFactory.getLog(Compression.class);
/*     */ 
/*     */   static Algorithm getCompressionAlgorithmByName(String compressName)
/*     */   {
/* 338 */     Algorithm[] algos = (Algorithm[])Algorithm.class.getEnumConstants();
/*     */ 
/* 340 */     for (Algorithm a : algos) {
/* 341 */       if (a.getName().equals(compressName)) {
/* 342 */         return a;
/*     */       }
/*     */     }
/*     */ 
/* 346 */     throw new IllegalArgumentException("Unsupported compression algorithm name: " + compressName);
/*     */   }
/*     */ 
/*     */   static String[] getSupportedAlgorithms()
/*     */   {
/* 351 */     Algorithm[] algos = (Algorithm[])Algorithm.class.getEnumConstants();
/*     */ 
/* 353 */     ArrayList ret = new ArrayList();
/* 354 */     for (Algorithm a : algos) {
/* 355 */       if (a.isSupported()) {
/* 356 */         ret.add(a.getName());
/*     */       }
/*     */     }
/* 359 */     return (String[])ret.toArray(new String[ret.size()]);
/*     */   }
/*     */ 
/*     */   static abstract enum Algorithm
/*     */   {
/*  75 */     LZO("lzo"), 
/*     */ 
/* 159 */     GZ("gz"), 
/*     */ 
/* 211 */     NONE("none");
/*     */ 
/* 246 */     protected static final Configuration conf = new Configuration();
/*     */     private final String compressName;
/*     */     private static final int DATA_IBUF_SIZE = 1024;
/*     */     private static final int DATA_OBUF_SIZE = 4096;
/*     */     public static final String CONF_LZO_CLASS = "io.compression.codec.lzo.class";
/*     */ 
/*     */     private Algorithm(String name)
/*     */     {
/* 256 */       this.compressName = name;
/*     */     }
/*     */ 
/*     */     abstract CompressionCodec getCodec()
/*     */       throws IOException;
/*     */ 
/*     */     public abstract InputStream createDecompressionStream(InputStream paramInputStream, Decompressor paramDecompressor, int paramInt)
/*     */       throws IOException;
/*     */ 
/*     */     public abstract OutputStream createCompressionStream(OutputStream paramOutputStream, Compressor paramCompressor, int paramInt)
/*     */       throws IOException;
/*     */ 
/*     */     public abstract boolean isSupported();
/*     */ 
/*     */     public Compressor getCompressor() throws IOException
/*     */     {
/* 272 */       CompressionCodec codec = getCodec();
/* 273 */       if (codec != null) {
/* 274 */         Compressor compressor = CodecPool.getCompressor(codec);
/* 275 */         if (compressor != null) {
/* 276 */           if (compressor.finished())
/*     */           {
/* 279 */             Compression.LOG.warn("Compressor obtained from CodecPool already finished()");
/*     */           }
/* 281 */           else Compression.LOG.debug("Got a compressor: " + compressor.hashCode());
/*     */ 
/* 287 */           compressor.reset();
/*     */         }
/* 289 */         return compressor;
/*     */       }
/* 291 */       return null;
/*     */     }
/*     */ 
/*     */     public void returnCompressor(Compressor compressor) {
/* 295 */       if (compressor != null) {
/* 296 */         Compression.LOG.debug("Return a compressor: " + compressor.hashCode());
/* 297 */         CodecPool.returnCompressor(compressor);
/*     */       }
/*     */     }
/*     */ 
/*     */     public Decompressor getDecompressor() throws IOException {
/* 302 */       CompressionCodec codec = getCodec();
/* 303 */       if (codec != null) {
/* 304 */         Decompressor decompressor = CodecPool.getDecompressor(codec);
/* 305 */         if (decompressor != null) {
/* 306 */           if (decompressor.finished())
/*     */           {
/* 309 */             Compression.LOG.warn("Deompressor obtained from CodecPool already finished()");
/*     */           }
/* 311 */           else Compression.LOG.debug("Got a decompressor: " + decompressor.hashCode());
/*     */ 
/* 317 */           decompressor.reset();
/*     */         }
/* 319 */         return decompressor;
/*     */       }
/*     */ 
/* 322 */       return null;
/*     */     }
/*     */ 
/*     */     public void returnDecompressor(Decompressor decompressor) {
/* 326 */       if (decompressor != null) {
/* 327 */         Compression.LOG.debug("Returned a decompressor: " + decompressor.hashCode());
/* 328 */         CodecPool.returnDecompressor(decompressor);
/*     */       }
/*     */     }
/*     */ 
/*     */     public String getName() {
/* 333 */       return this.compressName;
/*     */     }
/*     */   }
/*     */ 
/*     */   static class FinishOnFlushCompressionStream extends FilterOutputStream
/*     */   {
/*     */     public FinishOnFlushCompressionStream(CompressionOutputStream cout)
/*     */     {
/*  54 */       super();
/*     */     }
/*     */ 
/*     */     public void write(byte[] b, int off, int len) throws IOException
/*     */     {
/*  59 */       this.out.write(b, off, len);
/*     */     }
/*     */ 
/*     */     public void flush() throws IOException
/*     */     {
/*  64 */       CompressionOutputStream cout = (CompressionOutputStream)this.out;
/*  65 */       cout.finish();
/*  66 */       cout.flush();
/*  67 */       cout.resetState();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.file.tfile.Compression
 * JD-Core Version:    0.6.1
 */
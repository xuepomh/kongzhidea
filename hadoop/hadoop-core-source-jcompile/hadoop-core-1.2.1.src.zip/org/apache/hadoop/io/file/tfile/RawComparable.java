package org.apache.hadoop.io.file.tfile;

public abstract interface RawComparable
{
  public abstract byte[] buffer();

  public abstract int offset();

  public abstract int size();
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.file.tfile.RawComparable
 * JD-Core Version:    0.6.1
 */
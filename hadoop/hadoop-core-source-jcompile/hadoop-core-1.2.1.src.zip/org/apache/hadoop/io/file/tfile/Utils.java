/*     */ package org.apache.hadoop.io.file.tfile;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.apache.hadoop.io.Text;
/*     */ 
/*     */ public final class Utils
/*     */ {
/*     */   public static void writeVInt(DataOutput out, int n)
/*     */     throws IOException
/*     */   {
/*  52 */     writeVLong(out, n);
/*     */   }
/*     */ 
/*     */   public static void writeVLong(DataOutput out, long n)
/*     */     throws IOException
/*     */   {
/*  92 */     if ((n < 128L) && (n >= -32L)) {
/*  93 */       out.writeByte((int)n);
/*  94 */       return;
/*     */     }
/*     */ 
/*  97 */     long un = n < 0L ? n ^ 0xFFFFFFFF : n;
/*     */ 
/*  99 */     int len = (64 - Long.numberOfLeadingZeros(un)) / 8 + 1;
/* 100 */     int firstByte = (int)(n >> (len - 1) * 8);
/* 101 */     switch (len)
/*     */     {
/*     */     case 1:
/* 104 */       firstByte >>= 8;
/*     */     case 2:
/* 106 */       if ((firstByte < 20) && (firstByte >= -20)) {
/* 107 */         out.writeByte(firstByte - 52);
/* 108 */         out.writeByte((int)n);
/* 109 */         return;
/*     */       }
/*     */ 
/* 112 */       firstByte >>= 8;
/*     */     case 3:
/* 114 */       if ((firstByte < 16) && (firstByte >= -16)) {
/* 115 */         out.writeByte(firstByte - 88);
/* 116 */         out.writeShort((int)n);
/* 117 */         return;
/*     */       }
/*     */ 
/* 120 */       firstByte >>= 8;
/*     */     case 4:
/* 122 */       if ((firstByte < 8) && (firstByte >= -8)) {
/* 123 */         out.writeByte(firstByte - 112);
/* 124 */         out.writeShort((int)n >>> 8);
/* 125 */         out.writeByte((int)n);
/* 126 */         return;
/*     */       }
/* 128 */       out.writeByte(len - 129);
/* 129 */       out.writeInt((int)n);
/* 130 */       return;
/*     */     case 5:
/* 132 */       out.writeByte(len - 129);
/* 133 */       out.writeInt((int)(n >>> 8));
/* 134 */       out.writeByte((int)n);
/* 135 */       return;
/*     */     case 6:
/* 137 */       out.writeByte(len - 129);
/* 138 */       out.writeInt((int)(n >>> 16));
/* 139 */       out.writeShort((int)n);
/* 140 */       return;
/*     */     case 7:
/* 142 */       out.writeByte(len - 129);
/* 143 */       out.writeInt((int)(n >>> 24));
/* 144 */       out.writeShort((int)(n >>> 8));
/* 145 */       out.writeByte((int)n);
/* 146 */       return;
/*     */     case 8:
/* 148 */       out.writeByte(len - 129);
/* 149 */       out.writeLong(n);
/* 150 */       return;
/*     */     }
/* 152 */     throw new RuntimeException("Internel error");
/*     */   }
/*     */ 
/*     */   public static int readVInt(DataInput in)
/*     */     throws IOException
/*     */   {
/* 168 */     long ret = readVLong(in);
/* 169 */     if ((ret > 2147483647L) || (ret < -2147483648L)) {
/* 170 */       throw new RuntimeException("Number too large to be represented as Integer");
/*     */     }
/*     */ 
/* 173 */     return (int)ret;
/*     */   }
/*     */ 
/*     */   public static long readVLong(DataInput in)
/*     */     throws IOException
/*     */   {
/* 196 */     int firstByte = in.readByte();
/* 197 */     if (firstByte >= -32) {
/* 198 */       return firstByte;
/*     */     }
/*     */ 
/* 201 */     switch ((firstByte + 128) / 8) {
/*     */     case 7:
/*     */     case 8:
/*     */     case 9:
/*     */     case 10:
/*     */     case 11:
/* 207 */       return firstByte + 52 << 8 | in.readUnsignedByte();
/*     */     case 3:
/*     */     case 4:
/*     */     case 5:
/*     */     case 6:
/* 212 */       return firstByte + 88 << 16 | in.readUnsignedShort();
/*     */     case 1:
/*     */     case 2:
/* 215 */       return firstByte + 112 << 24 | in.readUnsignedShort() << 8 | in.readUnsignedByte();
/*     */     case 0:
/* 218 */       int len = firstByte + 129;
/* 219 */       switch (len) {
/*     */       case 4:
/* 221 */         return in.readInt();
/*     */       case 5:
/* 223 */         return in.readInt() << 8 | in.readUnsignedByte();
/*     */       case 6:
/* 225 */         return in.readInt() << 16 | in.readUnsignedShort();
/*     */       case 7:
/* 227 */         return in.readInt() << 24 | in.readUnsignedShort() << 8 | in.readUnsignedByte();
/*     */       case 8:
/* 230 */         return in.readLong();
/*     */       }
/* 232 */       throw new IOException("Corrupted VLong encoding");
/*     */     }
/*     */ 
/* 235 */     throw new RuntimeException("Internal error");
/*     */   }
/*     */ 
/*     */   public static void writeString(DataOutput out, String s)
/*     */     throws IOException
/*     */   {
/* 247 */     if (s != null) {
/* 248 */       Text text = new Text(s);
/* 249 */       byte[] buffer = text.getBytes();
/* 250 */       int len = text.getLength();
/* 251 */       writeVInt(out, len);
/* 252 */       out.write(buffer, 0, len);
/*     */     } else {
/* 254 */       writeVInt(out, -1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String readString(DataInput in)
/*     */     throws IOException
/*     */   {
/* 267 */     int length = readVInt(in);
/* 268 */     if (length == -1) return null;
/* 269 */     byte[] buffer = new byte[length];
/* 270 */     in.readFully(buffer);
/* 271 */     return Text.decode(buffer);
/*     */   }
/*     */ 
/*     */   public static <T> int lowerBound(List<? extends T> list, T key, Comparator<? super T> cmp)
/*     */   {
/* 414 */     int low = 0;
/* 415 */     int high = list.size();
/*     */ 
/* 417 */     while (low < high) {
/* 418 */       int mid = low + high >>> 1;
/* 419 */       Object midVal = list.get(mid);
/* 420 */       int ret = cmp.compare(midVal, key);
/* 421 */       if (ret < 0)
/* 422 */         low = mid + 1;
/* 423 */       else high = mid;
/*     */     }
/* 425 */     return low;
/*     */   }
/*     */ 
/*     */   public static <T> int upperBound(List<? extends T> list, T key, Comparator<? super T> cmp)
/*     */   {
/* 445 */     int low = 0;
/* 446 */     int high = list.size();
/*     */ 
/* 448 */     while (low < high) {
/* 449 */       int mid = low + high >>> 1;
/* 450 */       Object midVal = list.get(mid);
/* 451 */       int ret = cmp.compare(midVal, key);
/* 452 */       if (ret <= 0)
/* 453 */         low = mid + 1;
/* 454 */       else high = mid;
/*     */     }
/* 456 */     return low;
/*     */   }
/*     */ 
/*     */   public static <T> int lowerBound(List<? extends Comparable<? super T>> list, T key)
/*     */   {
/* 474 */     int low = 0;
/* 475 */     int high = list.size();
/*     */ 
/* 477 */     while (low < high) {
/* 478 */       int mid = low + high >>> 1;
/* 479 */       Comparable midVal = (Comparable)list.get(mid);
/* 480 */       int ret = midVal.compareTo(key);
/* 481 */       if (ret < 0)
/* 482 */         low = mid + 1;
/* 483 */       else high = mid;
/*     */     }
/* 485 */     return low;
/*     */   }
/*     */ 
/*     */   public static <T> int upperBound(List<? extends Comparable<? super T>> list, T key)
/*     */   {
/* 503 */     int low = 0;
/* 504 */     int high = list.size();
/*     */ 
/* 506 */     while (low < high) {
/* 507 */       int mid = low + high >>> 1;
/* 508 */       Comparable midVal = (Comparable)list.get(mid);
/* 509 */       int ret = midVal.compareTo(key);
/* 510 */       if (ret <= 0)
/* 511 */         low = mid + 1;
/* 512 */       else high = mid;
/*     */     }
/* 514 */     return low;
/*     */   }
/*     */ 
/*     */   public static final class Version
/*     */     implements Comparable<Version>
/*     */   {
/*     */     private final short major;
/*     */     private final short minor;
/*     */ 
/*     */     public Version(DataInput in)
/*     */       throws IOException
/*     */     {
/* 295 */       this.major = in.readShort();
/* 296 */       this.minor = in.readShort();
/*     */     }
/*     */ 
/*     */     public Version(short major, short minor)
/*     */     {
/* 308 */       this.major = major;
/* 309 */       this.minor = minor;
/*     */     }
/*     */ 
/*     */     public void write(DataOutput out)
/*     */       throws IOException
/*     */     {
/* 322 */       out.writeShort(this.major);
/* 323 */       out.writeShort(this.minor);
/*     */     }
/*     */ 
/*     */     public int getMajor()
/*     */     {
/* 332 */       return this.major;
/*     */     }
/*     */ 
/*     */     public int getMinor()
/*     */     {
/* 341 */       return this.minor;
/*     */     }
/*     */ 
/*     */     public static int size()
/*     */     {
/* 350 */       return 4;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 357 */       return "v" + this.major + "." + this.minor;
/*     */     }
/*     */ 
/*     */     public boolean compatibleWith(Version other)
/*     */     {
/* 370 */       return this.major == other.major;
/*     */     }
/*     */ 
/*     */     public int compareTo(Version that)
/*     */     {
/* 378 */       if (this.major != that.major) {
/* 379 */         return this.major - that.major;
/*     */       }
/* 381 */       return this.minor - that.minor;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 386 */       if (this == other) return true;
/* 387 */       if (!(other instanceof Version)) return false;
/* 388 */       return compareTo((Version)other) == 0;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 393 */       return this.major << 16 + this.minor;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.file.tfile.Utils
 * JD-Core Version:    0.6.1
 */
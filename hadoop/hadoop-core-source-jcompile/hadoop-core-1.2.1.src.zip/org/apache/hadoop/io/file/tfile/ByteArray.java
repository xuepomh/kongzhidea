/*    */ package org.apache.hadoop.io.file.tfile;
/*    */ 
/*    */ import org.apache.hadoop.io.BytesWritable;
/*    */ 
/*    */ public final class ByteArray
/*    */   implements RawComparable
/*    */ {
/*    */   private final byte[] buffer;
/*    */   private final int offset;
/*    */   private final int len;
/*    */ 
/*    */   public ByteArray(BytesWritable other)
/*    */   {
/* 37 */     this(other.get(), 0, other.getSize());
/*    */   }
/*    */ 
/*    */   public ByteArray(byte[] buffer)
/*    */   {
/* 47 */     this(buffer, 0, buffer.length);
/*    */   }
/*    */ 
/*    */   public ByteArray(byte[] buffer, int offset, int len)
/*    */   {
/* 61 */     if ((offset | len | buffer.length - offset - len) < 0) {
/* 62 */       throw new IndexOutOfBoundsException();
/*    */     }
/* 64 */     this.buffer = buffer;
/* 65 */     this.offset = offset;
/* 66 */     this.len = len;
/*    */   }
/*    */ 
/*    */   public byte[] buffer()
/*    */   {
/* 74 */     return this.buffer;
/*    */   }
/*    */ 
/*    */   public int offset()
/*    */   {
/* 82 */     return this.offset;
/*    */   }
/*    */ 
/*    */   public int size()
/*    */   {
/* 90 */     return this.len;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.file.tfile.ByteArray
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.io.file.tfile;
/*    */ 
/*    */ import java.io.FilterOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ class SimpleBufferedOutputStream extends FilterOutputStream
/*    */ {
/*    */   protected byte[] buf;
/* 30 */   protected int count = 0;
/*    */ 
/*    */   public SimpleBufferedOutputStream(OutputStream out, byte[] buf)
/*    */   {
/* 34 */     super(out);
/* 35 */     this.buf = buf;
/*    */   }
/*    */ 
/*    */   private void flushBuffer() throws IOException {
/* 39 */     if (this.count > 0) {
/* 40 */       this.out.write(this.buf, 0, this.count);
/* 41 */       this.count = 0;
/*    */     }
/*    */   }
/*    */ 
/*    */   public void write(int b) throws IOException
/*    */   {
/* 47 */     if (this.count >= this.buf.length) {
/* 48 */       flushBuffer();
/*    */     }
/* 50 */     this.buf[(this.count++)] = (byte)b;
/*    */   }
/*    */ 
/*    */   public void write(byte[] b, int off, int len) throws IOException
/*    */   {
/* 55 */     if (len >= this.buf.length) {
/* 56 */       flushBuffer();
/* 57 */       this.out.write(b, off, len);
/* 58 */       return;
/*    */     }
/* 60 */     if (len > this.buf.length - this.count) {
/* 61 */       flushBuffer();
/*    */     }
/* 63 */     System.arraycopy(b, off, this.buf, this.count, len);
/* 64 */     this.count += len;
/*    */   }
/*    */ 
/*    */   public synchronized void flush() throws IOException
/*    */   {
/* 69 */     flushBuffer();
/* 70 */     this.out.flush();
/*    */   }
/*    */ 
/*    */   public int size()
/*    */   {
/* 75 */     return this.count;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.file.tfile.SimpleBufferedOutputStream
 * JD-Core Version:    0.6.1
 */
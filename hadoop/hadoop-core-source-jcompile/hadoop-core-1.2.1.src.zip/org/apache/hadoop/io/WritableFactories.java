/*    */ package org.apache.hadoop.io;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import org.apache.hadoop.conf.Configurable;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ import org.apache.hadoop.util.ReflectionUtils;
/*    */ 
/*    */ public class WritableFactories
/*    */ {
/* 28 */   private static final HashMap<Class, WritableFactory> CLASS_TO_FACTORY = new HashMap();
/*    */ 
/*    */   public static synchronized void setFactory(Class c, WritableFactory factory)
/*    */   {
/* 35 */     CLASS_TO_FACTORY.put(c, factory);
/*    */   }
/*    */ 
/*    */   public static synchronized WritableFactory getFactory(Class c)
/*    */   {
/* 40 */     return (WritableFactory)CLASS_TO_FACTORY.get(c);
/*    */   }
/*    */ 
/*    */   public static Writable newInstance(Class<? extends Writable> c, Configuration conf)
/*    */   {
/* 45 */     WritableFactory factory = getFactory(c);
/* 46 */     if (factory != null) {
/* 47 */       Writable result = factory.newInstance();
/* 48 */       if ((result instanceof Configurable)) {
/* 49 */         ((Configurable)result).setConf(conf);
/*    */       }
/* 51 */       return result;
/*    */     }
/* 53 */     return (Writable)ReflectionUtils.newInstance(c, conf);
/*    */   }
/*    */ 
/*    */   public static Writable newInstance(Class<? extends Writable> c)
/*    */   {
/* 59 */     return newInstance(c, null);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.WritableFactories
 * JD-Core Version:    0.6.1
 */
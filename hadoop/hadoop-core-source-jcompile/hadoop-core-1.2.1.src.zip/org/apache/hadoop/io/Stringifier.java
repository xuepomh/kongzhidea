package org.apache.hadoop.io;

import java.io.Closeable;
import java.io.IOException;

public abstract interface Stringifier<T> extends Closeable
{
  public abstract String toString(T paramT)
    throws IOException;

  public abstract T fromString(String paramString)
    throws IOException;

  public abstract void close()
    throws IOException;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.Stringifier
 * JD-Core Version:    0.6.1
 */
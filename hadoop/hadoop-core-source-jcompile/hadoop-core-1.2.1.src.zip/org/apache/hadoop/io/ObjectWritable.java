/*     */ package org.apache.hadoop.io;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.hadoop.conf.Configurable;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.conf.Configured;
/*     */ 
/*     */ public class ObjectWritable
/*     */   implements Writable, Configurable
/*     */ {
/*     */   private Class declaredClass;
/*     */   private Object instance;
/*     */   private Configuration conf;
/*  73 */   private static final Map<String, Class<?>> PRIMITIVE_NAMES = new HashMap();
/*     */ 
/*     */   public ObjectWritable()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ObjectWritable(Object instance)
/*     */   {
/*  40 */     set(instance);
/*     */   }
/*     */ 
/*     */   public ObjectWritable(Class declaredClass, Object instance) {
/*  44 */     this.declaredClass = declaredClass;
/*  45 */     this.instance = instance;
/*     */   }
/*     */ 
/*     */   public Object get() {
/*  49 */     return this.instance;
/*     */   }
/*     */   public Class getDeclaredClass() {
/*  52 */     return this.declaredClass;
/*     */   }
/*     */ 
/*     */   public void set(Object instance) {
/*  56 */     this.declaredClass = instance.getClass();
/*  57 */     this.instance = instance;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  61 */     return "OW[class=" + this.declaredClass + ",value=" + this.instance + "]";
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException
/*     */   {
/*  66 */     readObject(in, this, this.conf);
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out) throws IOException {
/*  70 */     writeObject(out, this.instance, this.declaredClass, this.conf);
/*     */   }
/*     */ 
/*     */   public static void writeObject(DataOutput out, Object instance, Class declaredClass, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 115 */     if (instance == null) {
/* 116 */       instance = new NullInstance(declaredClass, conf);
/* 117 */       declaredClass = Configurable.class;
/*     */     }
/*     */ 
/* 120 */     UTF8.writeString(out, declaredClass.getName());
/*     */ 
/* 122 */     if (declaredClass.isArray()) {
/* 123 */       int length = Array.getLength(instance);
/* 124 */       out.writeInt(length);
/* 125 */       for (int i = 0; i < length; i++) {
/* 126 */         writeObject(out, Array.get(instance, i), declaredClass.getComponentType(), conf);
/*     */       }
/*     */ 
/*     */     }
/* 130 */     else if (declaredClass == String.class) {
/* 131 */       UTF8.writeString(out, (String)instance);
/*     */     }
/* 133 */     else if (declaredClass.isPrimitive())
/*     */     {
/* 135 */       if (declaredClass == Boolean.TYPE)
/* 136 */         out.writeBoolean(((Boolean)instance).booleanValue());
/* 137 */       else if (declaredClass == Character.TYPE)
/* 138 */         out.writeChar(((Character)instance).charValue());
/* 139 */       else if (declaredClass == Byte.TYPE)
/* 140 */         out.writeByte(((Byte)instance).byteValue());
/* 141 */       else if (declaredClass == Short.TYPE)
/* 142 */         out.writeShort(((Short)instance).shortValue());
/* 143 */       else if (declaredClass == Integer.TYPE)
/* 144 */         out.writeInt(((Integer)instance).intValue());
/* 145 */       else if (declaredClass == Long.TYPE)
/* 146 */         out.writeLong(((Long)instance).longValue());
/* 147 */       else if (declaredClass == Float.TYPE)
/* 148 */         out.writeFloat(((Float)instance).floatValue());
/* 149 */       else if (declaredClass == Double.TYPE)
/* 150 */         out.writeDouble(((Double)instance).doubleValue());
/* 151 */       else if (declaredClass != Void.TYPE)
/*     */       {
/* 153 */         throw new IllegalArgumentException("Not a primitive: " + declaredClass);
/*     */       }
/* 155 */     } else if (declaredClass.isEnum()) {
/* 156 */       UTF8.writeString(out, ((Enum)instance).name());
/* 157 */     } else if (Configurable.class.isAssignableFrom(declaredClass)) {
/* 158 */       UTF8.writeString(out, instance.getClass().getName());
/* 159 */       ((Configurable)instance).write(out);
/*     */     }
/*     */     else {
/* 162 */       throw new IOException("Can't write: " + instance + " as " + declaredClass);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Object readObject(DataInput in, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 171 */     return readObject(in, null, conf);
/*     */   }
/*     */ 
/*     */   public static Object readObject(DataInput in, ObjectWritable objectWritable, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 179 */     String className = UTF8.readString(in);
/* 180 */     Class declaredClass = (Class)PRIMITIVE_NAMES.get(className);
/* 181 */     if (declaredClass == null)
/*     */       try {
/* 183 */         declaredClass = conf.getClassByName(className);
/*     */       } catch (ClassNotFoundException e) {
/* 185 */         throw new RuntimeException("readObject can't find class " + className, e);
/*     */       }
/*     */     Object instance;
/* 191 */     if (declaredClass.isPrimitive())
/*     */     {
/*     */       Object instance;
/* 193 */       if (declaredClass == Boolean.TYPE) {
/* 194 */         instance = Boolean.valueOf(in.readBoolean());
/*     */       }
/*     */       else
/*     */       {
/*     */         Object instance;
/* 195 */         if (declaredClass == Character.TYPE) {
/* 196 */           instance = Character.valueOf(in.readChar());
/*     */         }
/*     */         else
/*     */         {
/*     */           Object instance;
/* 197 */           if (declaredClass == Byte.TYPE) {
/* 198 */             instance = Byte.valueOf(in.readByte());
/*     */           }
/*     */           else
/*     */           {
/*     */             Object instance;
/* 199 */             if (declaredClass == Short.TYPE) {
/* 200 */               instance = Short.valueOf(in.readShort());
/*     */             }
/*     */             else
/*     */             {
/*     */               Object instance;
/* 201 */               if (declaredClass == Integer.TYPE) {
/* 202 */                 instance = Integer.valueOf(in.readInt());
/*     */               }
/*     */               else
/*     */               {
/*     */                 Object instance;
/* 203 */                 if (declaredClass == Long.TYPE) {
/* 204 */                   instance = Long.valueOf(in.readLong());
/*     */                 }
/*     */                 else
/*     */                 {
/*     */                   Object instance;
/* 205 */                   if (declaredClass == Float.TYPE) {
/* 206 */                     instance = Float.valueOf(in.readFloat());
/*     */                   }
/*     */                   else
/*     */                   {
/*     */                     Object instance;
/* 207 */                     if (declaredClass == Double.TYPE) {
/* 208 */                       instance = Double.valueOf(in.readDouble());
/*     */                     }
/*     */                     else
/*     */                     {
/*     */                       Object instance;
/* 209 */                       if (declaredClass == Void.TYPE)
/* 210 */                         instance = null;
/*     */                       else
/* 212 */                         throw new IllegalArgumentException("Not a primitive: " + declaredClass);  }  }  }  }  } 
/*     */           }
/*     */         }
/*     */       } } else if (declaredClass.isArray()) {
/* 216 */       int length = in.readInt();
/* 217 */       Object instance = Array.newInstance(declaredClass.getComponentType(), length);
/* 218 */       for (int i = 0; i < length; i++)
/* 219 */         Array.set(instance, i, readObject(in, conf));
/*     */     }
/*     */     else
/*     */     {
/*     */       Object instance;
/* 222 */       if (declaredClass == String.class) {
/* 223 */         instance = UTF8.readString(in);
/*     */       }
/*     */       else
/*     */       {
/*     */         Object instance;
/* 224 */         if (declaredClass.isEnum()) {
/* 225 */           instance = Enum.valueOf(declaredClass, UTF8.readString(in));
/*     */         } else {
/* 227 */           Class instanceClass = null;
/* 228 */           String str = "";
/*     */           try {
/* 230 */             str = UTF8.readString(in);
/* 231 */             instanceClass = conf.getClassByName(str);
/*     */           } catch (ClassNotFoundException e) {
/* 233 */             throw new RuntimeException("readObject can't find class " + str, e);
/*     */           }
/*     */ 
/* 236 */           Writable writable = WritableFactories.newInstance(instanceClass, conf);
/* 237 */           writable.readFields(in);
/* 238 */           instance = writable;
/*     */ 
/* 240 */           if (instanceClass == NullInstance.class) {
/* 241 */             declaredClass = ((NullInstance)instance).declaredClass;
/* 242 */             instance = null;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 246 */     if (objectWritable != null) {
/* 247 */       objectWritable.declaredClass = declaredClass;
/* 248 */       objectWritable.instance = instance;
/*     */     }
/*     */ 
/* 251 */     return instance;
/*     */   }
/*     */ 
/*     */   public void setConf(Configuration conf)
/*     */   {
/* 256 */     this.conf = conf;
/*     */   }
/*     */ 
/*     */   public Configuration getConf() {
/* 260 */     return this.conf;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  75 */     PRIMITIVE_NAMES.put("boolean", Boolean.TYPE);
/*  76 */     PRIMITIVE_NAMES.put("byte", Byte.TYPE);
/*  77 */     PRIMITIVE_NAMES.put("char", Character.TYPE);
/*  78 */     PRIMITIVE_NAMES.put("short", Short.TYPE);
/*  79 */     PRIMITIVE_NAMES.put("int", Integer.TYPE);
/*  80 */     PRIMITIVE_NAMES.put("long", Long.TYPE);
/*  81 */     PRIMITIVE_NAMES.put("float", Float.TYPE);
/*  82 */     PRIMITIVE_NAMES.put("double", Double.TYPE);
/*  83 */     PRIMITIVE_NAMES.put("void", Void.TYPE);
/*     */   }
/*     */   private static class NullInstance extends Configured implements Writable {
/*     */     private Class<?> declaredClass;
/*     */ 
/*  88 */     public NullInstance() { super(); } 
/*     */     public NullInstance(Class declaredClass, Configuration conf) {
/*  90 */       super();
/*  91 */       this.declaredClass = declaredClass;
/*     */     }
/*     */     public void readFields(DataInput in) throws IOException {
/*  94 */       String className = UTF8.readString(in);
/*  95 */       this.declaredClass = ((Class)ObjectWritable.PRIMITIVE_NAMES.get(className));
/*  96 */       if (this.declaredClass == null)
/*     */         try {
/*  98 */           this.declaredClass = getConf().getClassByName(className);
/*     */         } catch (ClassNotFoundException e) {
/* 100 */           throw new RuntimeException(e.toString());
/*     */         }
/*     */     }
/*     */ 
/*     */     public void write(DataOutput out) throws IOException {
/* 105 */       UTF8.writeString(out, this.declaredClass.getName());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.ObjectWritable
 * JD-Core Version:    0.6.1
 */
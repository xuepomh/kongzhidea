/*     */ package org.apache.hadoop.io;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.net.Socket;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ 
/*     */ public class IOUtils
/*     */ {
/*     */   public static void copyBytes(InputStream in, OutputStream out, int buffSize, boolean close)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/*  47 */       copyBytes(in, out, buffSize);
/*     */     } finally {
/*  49 */       if (close) {
/*  50 */         out.close();
/*  51 */         in.close();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void copyBytes(InputStream in, OutputStream out, int buffSize)
/*     */     throws IOException
/*     */   {
/*  66 */     PrintStream ps = (out instanceof PrintStream) ? (PrintStream)out : null;
/*  67 */     byte[] buf = new byte[buffSize];
/*  68 */     int bytesRead = in.read(buf);
/*  69 */     while (bytesRead >= 0) {
/*  70 */       out.write(buf, 0, bytesRead);
/*  71 */       if ((ps != null) && (ps.checkError())) {
/*  72 */         throw new IOException("Unable to write to output stream.");
/*     */       }
/*  74 */       bytesRead = in.read(buf);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void copyBytes(InputStream in, OutputStream out, Configuration conf)
/*     */     throws IOException
/*     */   {
/*  87 */     copyBytes(in, out, conf.getInt("io.file.buffer.size", 4096), true);
/*     */   }
/*     */ 
/*     */   public static void copyBytes(InputStream in, OutputStream out, Configuration conf, boolean close)
/*     */     throws IOException
/*     */   {
/* 100 */     copyBytes(in, out, conf.getInt("io.file.buffer.size", 4096), close);
/*     */   }
/*     */ 
/*     */   public static void copyBytes(InputStream in, OutputStream out, long length, int bufferSize, boolean close)
/*     */     throws IOException
/*     */   {
/* 116 */     byte[] buf = new byte[bufferSize];
/*     */     try {
/* 118 */       int n = 0;
/* 119 */       for (long remaining = length; (remaining > 0L) && (n != -1); remaining -= n) {
/* 120 */         int toRead = remaining < buf.length ? (int)remaining : buf.length;
/* 121 */         n = in.read(buf, 0, toRead);
/* 122 */         if (n > 0) {
/* 123 */           out.write(buf, 0, n);
/*     */         }
/*     */       }
/*     */ 
/* 127 */       if (close) {
/* 128 */         out.close();
/* 129 */         out = null;
/* 130 */         in.close();
/* 131 */         in = null;
/*     */       }
/*     */     } finally {
/* 134 */       if (close) {
/* 135 */         closeStream(out);
/* 136 */         closeStream(in);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int wrappedReadForCompressedData(InputStream is, byte[] buf, int off, int len)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 155 */       return is.read(buf, off, len);
/*     */     } catch (IOException ie) {
/* 157 */       throw ie;
/*     */     } catch (Throwable t) {
/* 159 */       throw new IOException("Error while reading compressed data", t);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void readFully(InputStream in, byte[] buf, int off, int len)
/*     */     throws IOException
/*     */   {
/* 173 */     int toRead = len;
/* 174 */     while (toRead > 0) {
/* 175 */       int ret = in.read(buf, off, toRead);
/* 176 */       if (ret < 0) {
/* 177 */         throw new IOException("Premature EOF from inputStream");
/*     */       }
/* 179 */       toRead -= ret;
/* 180 */       off += ret;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void readFileChannelFully(FileChannel fileChannel, byte[] buf, int off, int len)
/*     */     throws IOException
/*     */   {
/* 194 */     int toRead = len;
/* 195 */     ByteBuffer byteBuffer = ByteBuffer.wrap(buf, off, len);
/* 196 */     while (toRead > 0) {
/* 197 */       int ret = fileChannel.read(byteBuffer);
/* 198 */       if (ret < 0) {
/* 199 */         throw new IOException("Premeture EOF from inputStream");
/*     */       }
/* 201 */       toRead -= ret;
/* 202 */       off += ret;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void skipFully(InputStream in, long len)
/*     */     throws IOException
/*     */   {
/* 213 */     while (len > 0L) {
/* 214 */       long ret = in.skip(len);
/* 215 */       if (ret < 0L) {
/* 216 */         throw new IOException("Premature EOF from inputStream");
/*     */       }
/* 218 */       len -= ret;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void cleanup(Log log, Closeable[] closeables)
/*     */   {
/* 229 */     for (Closeable c : closeables)
/* 230 */       if (c != null)
/*     */         try {
/* 232 */           c.close();
/*     */         } catch (IOException e) {
/* 234 */           if ((log != null) && (log.isDebugEnabled()))
/* 235 */             log.debug("Exception in closing " + c, e);
/*     */         }
/*     */   }
/*     */ 
/*     */   public static void closeStream(Closeable stream)
/*     */   {
/* 248 */     cleanup(null, new Closeable[] { stream });
/*     */   }
/*     */ 
/*     */   public static void closeSocket(Socket sock)
/*     */   {
/* 257 */     if (sock != null)
/*     */       try {
/* 259 */         sock.close();
/*     */       }
/*     */       catch (IOException ignored)
/*     */       {
/*     */       }
/*     */   }
/*     */ 
/*     */   public static class NullOutputStream extends OutputStream
/*     */   {
/*     */     public void write(byte[] b, int off, int len)
/*     */       throws IOException
/*     */     {
/*     */     }
/*     */ 
/*     */     public void write(int b)
/*     */       throws IOException
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.IOUtils
 * JD-Core Version:    0.6.1
 */
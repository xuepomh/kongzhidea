package org.apache.hadoop.io;

import java.util.Comparator;

public abstract interface RawComparator<T> extends Comparator<T>
{
  public abstract int compare(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, int paramInt4);
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.RawComparator
 * JD-Core Version:    0.6.1
 */
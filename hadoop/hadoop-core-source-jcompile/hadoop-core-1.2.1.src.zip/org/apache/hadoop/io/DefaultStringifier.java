/*     */ package org.apache.hadoop.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ import java.util.ArrayList;
/*     */ import org.apache.commons.codec.binary.Base64;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.io.serializer.Deserializer;
/*     */ import org.apache.hadoop.io.serializer.SerializationFactory;
/*     */ import org.apache.hadoop.io.serializer.Serializer;
/*     */ import org.apache.hadoop.util.GenericsUtil;
/*     */ 
/*     */ public class DefaultStringifier<T>
/*     */   implements Stringifier<T>
/*     */ {
/*     */   private static final String SEPARATOR = ",";
/*     */   private Serializer<T> serializer;
/*     */   private Deserializer<T> deserializer;
/*     */   private DataInputBuffer inBuf;
/*     */   private DataOutputBuffer outBuf;
/*     */ 
/*     */   public DefaultStringifier(Configuration conf, Class<T> c)
/*     */   {
/*  58 */     SerializationFactory factory = new SerializationFactory(conf);
/*  59 */     this.serializer = factory.getSerializer(c);
/*  60 */     this.deserializer = factory.getDeserializer(c);
/*  61 */     this.inBuf = new DataInputBuffer();
/*  62 */     this.outBuf = new DataOutputBuffer();
/*     */     try {
/*  64 */       this.serializer.open(this.outBuf);
/*  65 */       this.deserializer.open(this.inBuf);
/*     */     } catch (IOException ex) {
/*  67 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public T fromString(String str) throws IOException {
/*     */     try {
/*  73 */       byte[] bytes = Base64.decodeBase64(str.getBytes("UTF-8"));
/*  74 */       this.inBuf.reset(bytes, bytes.length);
/*  75 */       return this.deserializer.deserialize(null);
/*     */     }
/*     */     catch (UnsupportedCharsetException ex) {
/*  78 */       throw new IOException(ex.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString(T obj) throws IOException {
/*  83 */     this.outBuf.reset();
/*  84 */     this.serializer.serialize(obj);
/*  85 */     byte[] buf = new byte[this.outBuf.getLength()];
/*  86 */     System.arraycopy(this.outBuf.getData(), 0, buf, 0, buf.length);
/*  87 */     return new String(Base64.encodeBase64(buf));
/*     */   }
/*     */ 
/*     */   public void close() throws IOException {
/*  91 */     this.inBuf.close();
/*  92 */     this.outBuf.close();
/*  93 */     this.deserializer.close();
/*  94 */     this.serializer.close();
/*     */   }
/*     */ 
/*     */   public static <K> void store(Configuration conf, K item, String keyName)
/*     */     throws IOException
/*     */   {
/* 110 */     DefaultStringifier stringifier = new DefaultStringifier(conf, GenericsUtil.getClass(item));
/*     */ 
/* 112 */     conf.set(keyName, stringifier.toString(item));
/* 113 */     stringifier.close();
/*     */   }
/*     */ 
/*     */   public static <K> K load(Configuration conf, String keyName, Class<K> itemClass)
/*     */     throws IOException
/*     */   {
/* 129 */     DefaultStringifier stringifier = new DefaultStringifier(conf, itemClass);
/*     */     try
/*     */     {
/* 132 */       String itemStr = conf.get(keyName);
/* 133 */       return stringifier.fromString(itemStr);
/*     */     } finally {
/* 135 */       stringifier.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static <K> void storeArray(Configuration conf, K[] items, String keyName)
/*     */     throws IOException
/*     */   {
/* 153 */     DefaultStringifier stringifier = new DefaultStringifier(conf, GenericsUtil.getClass(items[0]));
/*     */     try
/*     */     {
/* 156 */       StringBuilder builder = new StringBuilder();
/* 157 */       for (Object item : items) {
/* 158 */         builder.append(stringifier.toString(item)).append(",");
/*     */       }
/* 160 */       conf.set(keyName, builder.toString());
/*     */     }
/*     */     finally {
/* 163 */       stringifier.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static <K> K[] loadArray(Configuration conf, String keyName, Class<K> itemClass)
/*     */     throws IOException
/*     */   {
/* 180 */     DefaultStringifier stringifier = new DefaultStringifier(conf, itemClass);
/*     */     try
/*     */     {
/* 183 */       String itemStr = conf.get(keyName);
/* 184 */       ArrayList list = new ArrayList();
/* 185 */       String[] parts = itemStr.split(",");
/*     */ 
/* 187 */       for (String part : parts) {
/* 188 */         if (!part.equals("")) {
/* 189 */           list.add(stringifier.fromString(part));
/*     */         }
/*     */       }
/* 192 */       return GenericsUtil.toArray(itemClass, list);
/*     */     }
/*     */     finally {
/* 195 */       stringifier.close();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.DefaultStringifier
 * JD-Core Version:    0.6.1
 */
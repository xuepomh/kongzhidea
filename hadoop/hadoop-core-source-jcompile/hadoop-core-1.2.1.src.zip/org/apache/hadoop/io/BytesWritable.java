/*     */ package org.apache.hadoop.io;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class BytesWritable extends BinaryComparable
/*     */   implements WritableComparable<BinaryComparable>
/*     */ {
/*  36 */   private static final Log LOG = LogFactory.getLog(BytesWritable.class);
/*     */   private static final int LENGTH_BYTES = 4;
/*  38 */   private static final byte[] EMPTY_BYTES = new byte[0];
/*     */   private int size;
/*     */   private byte[] bytes;
/*     */ 
/*     */   public BytesWritable()
/*     */   {
/*  46 */     this(EMPTY_BYTES);
/*     */   }
/*     */ 
/*     */   public BytesWritable(byte[] bytes)
/*     */   {
/*  53 */     this.bytes = bytes;
/*  54 */     this.size = bytes.length;
/*     */   }
/*     */ 
/*     */   public byte[] getBytes()
/*     */   {
/*  62 */     return this.bytes;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public byte[] get()
/*     */   {
/*  71 */     return getBytes();
/*     */   }
/*     */ 
/*     */   public int getLength()
/*     */   {
/*  78 */     return this.size;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public int getSize()
/*     */   {
/*  87 */     return getLength();
/*     */   }
/*     */ 
/*     */   public void setSize(int size)
/*     */   {
/*  97 */     if (size > getCapacity()) {
/*  98 */       setCapacity(size * 3 / 2);
/*     */     }
/* 100 */     this.size = size;
/*     */   }
/*     */ 
/*     */   public int getCapacity()
/*     */   {
/* 109 */     return this.bytes.length;
/*     */   }
/*     */ 
/*     */   public void setCapacity(int new_cap)
/*     */   {
/* 118 */     if (new_cap != getCapacity()) {
/* 119 */       byte[] new_data = new byte[new_cap];
/* 120 */       if (new_cap < this.size) {
/* 121 */         this.size = new_cap;
/*     */       }
/* 123 */       if (this.size != 0) {
/* 124 */         System.arraycopy(this.bytes, 0, new_data, 0, this.size);
/*     */       }
/* 126 */       this.bytes = new_data;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void set(BytesWritable newData)
/*     */   {
/* 135 */     set(newData.bytes, 0, newData.size);
/*     */   }
/*     */ 
/*     */   public void set(byte[] newData, int offset, int length)
/*     */   {
/* 145 */     setSize(0);
/* 146 */     setSize(length);
/* 147 */     System.arraycopy(newData, offset, this.bytes, 0, this.size);
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException
/*     */   {
/* 152 */     setSize(0);
/* 153 */     setSize(in.readInt());
/* 154 */     in.readFully(this.bytes, 0, this.size);
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out) throws IOException
/*     */   {
/* 159 */     out.writeInt(this.size);
/* 160 */     out.write(this.bytes, 0, this.size);
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 164 */     return super.hashCode();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object right_obj)
/*     */   {
/* 171 */     if ((right_obj instanceof BytesWritable))
/* 172 */       return super.equals(right_obj);
/* 173 */     return false;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 180 */     StringBuffer sb = new StringBuffer(3 * this.size);
/* 181 */     for (int idx = 0; idx < this.size; idx++)
/*     */     {
/* 183 */       if (idx != 0) {
/* 184 */         sb.append(' ');
/*     */       }
/* 186 */       String num = Integer.toHexString(0xFF & this.bytes[idx]);
/*     */ 
/* 188 */       if (num.length() < 2) {
/* 189 */         sb.append('0');
/*     */       }
/* 191 */       sb.append(num);
/*     */     }
/* 193 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 213 */     WritableComparator.define(BytesWritable.class, new Comparator());
/*     */   }
/*     */ 
/*     */   public static class Comparator extends WritableComparator
/*     */   {
/*     */     public Comparator()
/*     */     {
/* 199 */       super();
/*     */     }
/*     */ 
/*     */     public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2)
/*     */     {
/* 207 */       return compareBytes(b1, s1 + 4, l1 - 4, b2, s2 + 4, l2 - 4);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.BytesWritable
 * JD-Core Version:    0.6.1
 */
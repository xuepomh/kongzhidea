/*    */ package org.apache.hadoop.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ import org.apache.hadoop.fs.FileSystem;
/*    */ import org.apache.hadoop.util.Progressable;
/*    */ 
/*    */ public class ArrayFile extends MapFile
/*    */ {
/*    */   public static class Reader extends MapFile.Reader
/*    */   {
/* 61 */     private LongWritable key = new LongWritable();
/*    */ 
/*    */     public Reader(FileSystem fs, String file, Configuration conf) throws IOException
/*    */     {
/* 65 */       super(file, conf);
/*    */     }
/*    */ 
/*    */     public synchronized void seek(long n) throws IOException
/*    */     {
/* 70 */       this.key.set(n);
/* 71 */       seek(this.key);
/*    */     }
/*    */ 
/*    */     public synchronized Writable next(Writable value) throws IOException
/*    */     {
/* 76 */       return next(this.key, value) ? value : null;
/*    */     }
/*    */ 
/*    */     public synchronized long key()
/*    */       throws IOException
/*    */     {
/* 83 */       return this.key.get();
/*    */     }
/*    */ 
/*    */     public synchronized Writable get(long n, Writable value)
/*    */       throws IOException
/*    */     {
/* 89 */       this.key.set(n);
/* 90 */       return get(this.key, value);
/*    */     }
/*    */   }
/*    */ 
/*    */   public static class Writer extends MapFile.Writer
/*    */   {
/* 35 */     private LongWritable count = new LongWritable(0L);
/*    */ 
/*    */     public Writer(Configuration conf, FileSystem fs, String file, Class<? extends Writable> valClass)
/*    */       throws IOException
/*    */     {
/* 41 */       super(fs, file, LongWritable.class, valClass);
/*    */     }
/*    */ 
/*    */     public Writer(Configuration conf, FileSystem fs, String file, Class<? extends Writable> valClass, SequenceFile.CompressionType compress, Progressable progress)
/*    */       throws IOException
/*    */     {
/* 49 */       super(fs, file, LongWritable.class, valClass, compress, progress);
/*    */     }
/*    */ 
/*    */     public synchronized void append(Writable value) throws IOException
/*    */     {
/* 54 */       super.append(this.count, value);
/* 55 */       this.count.set(this.count.get() + 1L);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.ArrayFile
 * JD-Core Version:    0.6.1
 */
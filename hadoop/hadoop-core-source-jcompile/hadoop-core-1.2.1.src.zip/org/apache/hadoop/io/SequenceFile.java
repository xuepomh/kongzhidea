/*      */ package org.apache.hadoop.io;
/*      */ 
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.Closeable;
/*      */ import java.io.DataInput;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutput;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.EOFException;
/*      */ import java.io.IOException;
/*      */ import java.net.URI;
/*      */ import java.rmi.server.UID;
/*      */ import java.security.MessageDigest;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Comparator;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.apache.hadoop.conf.Configurable;
/*      */ import org.apache.hadoop.conf.Configuration;
/*      */ import org.apache.hadoop.fs.ChecksumException;
/*      */ import org.apache.hadoop.fs.ChecksumFileSystem;
/*      */ import org.apache.hadoop.fs.FSDataInputStream;
/*      */ import org.apache.hadoop.fs.FSDataOutputStream;
/*      */ import org.apache.hadoop.fs.FileSystem;
/*      */ import org.apache.hadoop.fs.LocalDirAllocator;
/*      */ import org.apache.hadoop.fs.Path;
/*      */ import org.apache.hadoop.io.compress.CodecPool;
/*      */ import org.apache.hadoop.io.compress.CompressionCodec;
/*      */ import org.apache.hadoop.io.compress.CompressionInputStream;
/*      */ import org.apache.hadoop.io.compress.CompressionOutputStream;
/*      */ import org.apache.hadoop.io.compress.Compressor;
/*      */ import org.apache.hadoop.io.compress.Decompressor;
/*      */ import org.apache.hadoop.io.compress.DefaultCodec;
/*      */ import org.apache.hadoop.io.compress.GzipCodec;
/*      */ import org.apache.hadoop.io.compress.zlib.ZlibFactory;
/*      */ import org.apache.hadoop.io.serializer.Deserializer;
/*      */ import org.apache.hadoop.io.serializer.SerializationFactory;
/*      */ import org.apache.hadoop.io.serializer.Serializer;
/*      */ import org.apache.hadoop.util.MergeSort;
/*      */ import org.apache.hadoop.util.NativeCodeLoader;
/*      */ import org.apache.hadoop.util.PriorityQueue;
/*      */ import org.apache.hadoop.util.Progress;
/*      */ import org.apache.hadoop.util.Progressable;
/*      */ import org.apache.hadoop.util.ReflectionUtils;
/*      */ 
/*      */ public class SequenceFile
/*      */ {
/*  187 */   private static final Log LOG = LogFactory.getLog(SequenceFile.class);
/*      */   private static final byte BLOCK_COMPRESS_VERSION = 4;
/*      */   private static final byte CUSTOM_COMPRESS_VERSION = 5;
/*      */   private static final byte VERSION_WITH_METADATA = 6;
/*  194 */   private static byte[] VERSION = { 83, 69, 81, 6 };
/*      */   private static final int SYNC_ESCAPE = -1;
/*      */   private static final int SYNC_HASH_SIZE = 16;
/*      */   private static final int SYNC_SIZE = 20;
/*      */   public static final int SYNC_INTERVAL = 2000;
/*      */ 
/*      */   @Deprecated
/*      */   public static CompressionType getCompressionType(Configuration job)
/*      */   {
/*  230 */     String name = job.get("io.seqfile.compression.type");
/*  231 */     return name == null ? CompressionType.RECORD : CompressionType.valueOf(name);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static void setCompressionType(Configuration job, CompressionType val)
/*      */   {
/*  248 */     job.set("io.seqfile.compression.type", val.toString());
/*      */   }
/*      */ 
/*      */   public static Writer createWriter(FileSystem fs, Configuration conf, Path name, Class keyClass, Class valClass)
/*      */     throws IOException
/*      */   {
/*  265 */     return createWriter(fs, conf, name, keyClass, valClass, getCompressionType(conf));
/*      */   }
/*      */ 
/*      */   public static Writer createWriter(FileSystem fs, Configuration conf, Path name, Class keyClass, Class valClass, CompressionType compressionType)
/*      */     throws IOException
/*      */   {
/*  284 */     return createWriter(fs, conf, name, keyClass, valClass, fs.getConf().getInt("io.file.buffer.size", 4096), fs.getDefaultReplication(), fs.getDefaultBlockSize(), compressionType, new DefaultCodec(), null, new Metadata());
/*      */   }
/*      */ 
/*      */   public static Writer createWriter(FileSystem fs, Configuration conf, Path name, Class keyClass, Class valClass, CompressionType compressionType, Progressable progress)
/*      */     throws IOException
/*      */   {
/*  306 */     return createWriter(fs, conf, name, keyClass, valClass, fs.getConf().getInt("io.file.buffer.size", 4096), fs.getDefaultReplication(), fs.getDefaultBlockSize(), compressionType, new DefaultCodec(), progress, new Metadata());
/*      */   }
/*      */ 
/*      */   public static Writer createWriter(FileSystem fs, Configuration conf, Path name, Class keyClass, Class valClass, CompressionType compressionType, CompressionCodec codec)
/*      */     throws IOException
/*      */   {
/*  329 */     return createWriter(fs, conf, name, keyClass, valClass, fs.getConf().getInt("io.file.buffer.size", 4096), fs.getDefaultReplication(), fs.getDefaultBlockSize(), compressionType, codec, null, new Metadata());
/*      */   }
/*      */ 
/*      */   public static Writer createWriter(FileSystem fs, Configuration conf, Path name, Class keyClass, Class valClass, CompressionType compressionType, CompressionCodec codec, Progressable progress, Metadata metadata)
/*      */     throws IOException
/*      */   {
/*  354 */     return createWriter(fs, conf, name, keyClass, valClass, fs.getConf().getInt("io.file.buffer.size", 4096), fs.getDefaultReplication(), fs.getDefaultBlockSize(), compressionType, codec, progress, metadata);
/*      */   }
/*      */ 
/*      */   public static Writer createWriter(FileSystem fs, Configuration conf, Path name, Class keyClass, Class valClass, int bufferSize, short replication, long blockSize, CompressionType compressionType, CompressionCodec codec, Progressable progress, Metadata metadata)
/*      */     throws IOException
/*      */   {
/*  383 */     if (((codec instanceof GzipCodec)) && (!NativeCodeLoader.isNativeCodeLoaded()) && (!ZlibFactory.isNativeZlibLoaded(conf)))
/*      */     {
/*  386 */       throw new IllegalArgumentException("SequenceFile doesn't work with GzipCodec without native-hadoop code!");
/*      */     }
/*      */ 
/*  390 */     Writer writer = null;
/*      */ 
/*  392 */     if (compressionType == CompressionType.NONE) {
/*  393 */       writer = new Writer(fs, conf, name, keyClass, valClass, bufferSize, replication, blockSize, progress, metadata);
/*      */     }
/*  396 */     else if (compressionType == CompressionType.RECORD) {
/*  397 */       writer = new RecordCompressWriter(fs, conf, name, keyClass, valClass, bufferSize, replication, blockSize, codec, progress, metadata);
/*      */     }
/*  400 */     else if (compressionType == CompressionType.BLOCK) {
/*  401 */       writer = new BlockCompressWriter(fs, conf, name, keyClass, valClass, bufferSize, replication, blockSize, codec, progress, metadata);
/*      */     }
/*      */ 
/*  406 */     return writer;
/*      */   }
/*      */ 
/*      */   public static Writer createWriter(FileSystem fs, Configuration conf, Path name, Class keyClass, Class valClass, int bufferSize, short replication, long blockSize, boolean createParent, CompressionType compressionType, CompressionCodec codec, Metadata metadata)
/*      */     throws IOException
/*      */   {
/*  432 */     if (((codec instanceof GzipCodec)) && (!NativeCodeLoader.isNativeCodeLoaded()) && (!ZlibFactory.isNativeZlibLoaded(conf)))
/*      */     {
/*  435 */       throw new IllegalArgumentException("SequenceFile doesn't work with GzipCodec without native-hadoop code!");
/*      */     }
/*      */     FSDataOutputStream fsos;
/*      */     FSDataOutputStream fsos;
/*  441 */     if (createParent)
/*  442 */       fsos = fs.create(name, true, bufferSize, replication, blockSize);
/*      */     else {
/*  444 */       fsos = fs.createNonRecursive(name, true, bufferSize, replication, blockSize, null);
/*      */     }
/*      */ 
/*  448 */     switch (1.$SwitchMap$org$apache$hadoop$io$SequenceFile$CompressionType[compressionType.ordinal()]) {
/*      */     case 1:
/*  450 */       return new Writer(conf, fsos, keyClass, valClass, metadata).ownStream();
/*      */     case 2:
/*  452 */       return new RecordCompressWriter(conf, fsos, keyClass, valClass, codec, metadata).ownStream();
/*      */     case 3:
/*  455 */       return new BlockCompressWriter(conf, fsos, keyClass, valClass, codec, metadata).ownStream();
/*      */     }
/*      */ 
/*  458 */     return null;
/*      */   }
/*      */ 
/*      */   public static Writer createWriter(FileSystem fs, Configuration conf, Path name, Class keyClass, Class valClass, CompressionType compressionType, CompressionCodec codec, Progressable progress)
/*      */     throws IOException
/*      */   {
/*  480 */     Writer writer = createWriter(fs, conf, name, keyClass, valClass, compressionType, codec, progress, new Metadata());
/*      */ 
/*  482 */     return writer;
/*      */   }
/*      */ 
/*      */   private static Writer createWriter(Configuration conf, FSDataOutputStream out, Class keyClass, Class valClass, boolean compress, boolean blockCompress, CompressionCodec codec, Metadata metadata)
/*      */     throws IOException
/*      */   {
/*  501 */     if ((codec != null) && ((codec instanceof GzipCodec)) && (!NativeCodeLoader.isNativeCodeLoaded()) && (!ZlibFactory.isNativeZlibLoaded(conf)))
/*      */     {
/*  504 */       throw new IllegalArgumentException("SequenceFile doesn't work with GzipCodec without native-hadoop code!");
/*      */     }
/*      */ 
/*  508 */     Writer writer = null;
/*      */ 
/*  510 */     if (!compress)
/*  511 */       writer = new Writer(conf, out, keyClass, valClass, metadata);
/*  512 */     else if ((compress) && (!blockCompress))
/*  513 */       writer = new RecordCompressWriter(conf, out, keyClass, valClass, codec, metadata);
/*      */     else {
/*  515 */       writer = new BlockCompressWriter(conf, out, keyClass, valClass, codec, metadata);
/*      */     }
/*      */ 
/*  518 */     return writer;
/*      */   }
/*      */ 
/*      */   private static Writer createWriter(FileSystem fs, Configuration conf, Path file, Class keyClass, Class valClass, boolean compress, boolean blockCompress, CompressionCodec codec, Progressable progress, Metadata metadata)
/*      */     throws IOException
/*      */   {
/*  542 */     if ((codec != null) && ((codec instanceof GzipCodec)) && (!NativeCodeLoader.isNativeCodeLoaded()) && (!ZlibFactory.isNativeZlibLoaded(conf)))
/*      */     {
/*  545 */       throw new IllegalArgumentException("SequenceFile doesn't work with GzipCodec without native-hadoop code!");
/*      */     }
/*      */ 
/*  549 */     Writer writer = null;
/*      */ 
/*  551 */     if (!compress)
/*  552 */       writer = new Writer(fs, conf, file, keyClass, valClass, progress, metadata);
/*  553 */     else if ((compress) && (!blockCompress)) {
/*  554 */       writer = new RecordCompressWriter(fs, conf, file, keyClass, valClass, codec, progress, metadata);
/*      */     }
/*      */     else {
/*  557 */       writer = new BlockCompressWriter(fs, conf, file, keyClass, valClass, codec, progress, metadata);
/*      */     }
/*      */ 
/*  561 */     return writer;
/*      */   }
/*      */ 
/*      */   public static Writer createWriter(Configuration conf, FSDataOutputStream out, Class keyClass, Class valClass, CompressionType compressionType, CompressionCodec codec, Metadata metadata)
/*      */     throws IOException
/*      */   {
/*  581 */     if (((codec instanceof GzipCodec)) && (!NativeCodeLoader.isNativeCodeLoaded()) && (!ZlibFactory.isNativeZlibLoaded(conf)))
/*      */     {
/*  584 */       throw new IllegalArgumentException("SequenceFile doesn't work with GzipCodec without native-hadoop code!");
/*      */     }
/*      */ 
/*  588 */     Writer writer = null;
/*      */ 
/*  590 */     if (compressionType == CompressionType.NONE)
/*  591 */       writer = new Writer(conf, out, keyClass, valClass, metadata);
/*  592 */     else if (compressionType == CompressionType.RECORD)
/*  593 */       writer = new RecordCompressWriter(conf, out, keyClass, valClass, codec, metadata);
/*  594 */     else if (compressionType == CompressionType.BLOCK) {
/*  595 */       writer = new BlockCompressWriter(conf, out, keyClass, valClass, codec, metadata);
/*      */     }
/*      */ 
/*  598 */     return writer;
/*      */   }
/*      */ 
/*      */   public static Writer createWriter(Configuration conf, FSDataOutputStream out, Class keyClass, Class valClass, CompressionType compressionType, CompressionCodec codec)
/*      */     throws IOException
/*      */   {
/*  617 */     Writer writer = createWriter(conf, out, keyClass, valClass, compressionType, codec, new Metadata());
/*      */ 
/*  619 */     return writer;
/*      */   }
/*      */ 
/*      */   public static class Sorter
/*      */   {
/*      */     private RawComparator comparator;
/*      */     private MergeSort mergeSort;
/*      */     private Path[] inFiles;
/*      */     private Path outFile;
/*      */     private int memory;
/*      */     private int factor;
/* 2286 */     private FileSystem fs = null;
/*      */     private Class keyClass;
/*      */     private Class valClass;
/*      */     private Configuration conf;
/* 2293 */     private Progressable progressable = null;
/*      */ 
/*      */     public Sorter(FileSystem fs, Class<? extends WritableComparable> keyClass, Class valClass, Configuration conf)
/*      */     {
/* 2298 */       this(fs, WritableComparator.get(keyClass), keyClass, valClass, conf);
/*      */     }
/*      */ 
/*      */     public Sorter(FileSystem fs, RawComparator comparator, Class keyClass, Class valClass, Configuration conf)
/*      */     {
/* 2304 */       this.fs = fs;
/* 2305 */       this.comparator = comparator;
/* 2306 */       this.keyClass = keyClass;
/* 2307 */       this.valClass = valClass;
/* 2308 */       this.memory = (conf.getInt("io.sort.mb", 100) * 1024 * 1024);
/* 2309 */       this.factor = conf.getInt("io.sort.factor", 100);
/* 2310 */       this.conf = conf;
/*      */     }
/*      */ 
/*      */     public void setFactor(int factor) {
/* 2314 */       this.factor = factor;
/*      */     }
/*      */     public int getFactor() {
/* 2317 */       return this.factor;
/*      */     }
/*      */     public void setMemory(int memory) {
/* 2320 */       this.memory = memory;
/*      */     }
/*      */     public int getMemory() {
/* 2323 */       return this.memory;
/*      */     }
/*      */ 
/*      */     public void setProgressable(Progressable progressable) {
/* 2327 */       this.progressable = progressable;
/*      */     }
/*      */ 
/*      */     public void sort(Path[] inFiles, Path outFile, boolean deleteInput)
/*      */       throws IOException
/*      */     {
/* 2338 */       if (this.fs.exists(outFile)) {
/* 2339 */         throw new IOException("already exists: " + outFile);
/*      */       }
/*      */ 
/* 2342 */       this.inFiles = inFiles;
/* 2343 */       this.outFile = outFile;
/*      */ 
/* 2345 */       int segments = sortPass(deleteInput);
/* 2346 */       if (segments > 1)
/* 2347 */         mergePass(outFile.getParent());
/*      */     }
/*      */ 
/*      */     public RawKeyValueIterator sortAndIterate(Path[] inFiles, Path tempDir, boolean deleteInput)
/*      */       throws IOException
/*      */     {
/* 2360 */       Path outFile = new Path(tempDir + "/" + "all.2");
/* 2361 */       if (this.fs.exists(outFile)) {
/* 2362 */         throw new IOException("already exists: " + outFile);
/*      */       }
/* 2364 */       this.inFiles = inFiles;
/*      */ 
/* 2369 */       this.outFile = outFile;
/*      */ 
/* 2371 */       int segments = sortPass(deleteInput);
/* 2372 */       if (segments > 1) {
/* 2373 */         return merge(outFile.suffix(".0"), outFile.suffix(".0.index"), tempDir);
/*      */       }
/* 2375 */       if (segments == 1)
/* 2376 */         return merge(new Path[] { outFile }, true, tempDir);
/* 2377 */       return null;
/*      */     }
/*      */ 
/*      */     public void sort(Path inFile, Path outFile)
/*      */       throws IOException
/*      */     {
/* 2386 */       sort(new Path[] { inFile }, outFile, false);
/*      */     }
/*      */ 
/*      */     private int sortPass(boolean deleteInput) throws IOException {
/* 2390 */       SequenceFile.LOG.debug("running sort pass");
/* 2391 */       SortPass sortPass = new SortPass(null);
/* 2392 */       sortPass.setProgressable(this.progressable);
/*      */       SortPass tmp38_37 = sortPass; tmp38_37.getClass(); this.mergeSort = new MergeSort(new SequenceFile.Sorter.SortPass.SeqFileComparator(tmp38_37));
/*      */       try {
/* 2395 */         return sortPass.run(deleteInput);
/*      */       } finally {
/* 2397 */         sortPass.close();
/*      */       }
/*      */     }
/*      */ 
/*      */     public RawKeyValueIterator merge(List<SegmentDescriptor> segments, Path tmpDir)
/*      */       throws IOException
/*      */     {
/* 2632 */       MergeQueue mQueue = new MergeQueue(segments, tmpDir, this.progressable);
/* 2633 */       return mQueue.merge();
/*      */     }
/*      */ 
/*      */     public RawKeyValueIterator merge(Path[] inNames, boolean deleteInputs, Path tmpDir)
/*      */       throws IOException
/*      */     {
/* 2649 */       return merge(inNames, deleteInputs, inNames.length < this.factor ? inNames.length : this.factor, tmpDir);
/*      */     }
/*      */ 
/*      */     public RawKeyValueIterator merge(Path[] inNames, boolean deleteInputs, int factor, Path tmpDir)
/*      */       throws IOException
/*      */     {
/* 2668 */       ArrayList a = new ArrayList();
/* 2669 */       for (int i = 0; i < inNames.length; i++) {
/* 2670 */         SegmentDescriptor s = new SegmentDescriptor(0L, this.fs.getLength(inNames[i]), inNames[i]);
/*      */ 
/* 2672 */         s.preserveInput(!deleteInputs);
/* 2673 */         s.doSync();
/* 2674 */         a.add(s);
/*      */       }
/* 2676 */       this.factor = factor;
/* 2677 */       MergeQueue mQueue = new MergeQueue(a, tmpDir, this.progressable);
/* 2678 */       return mQueue.merge();
/*      */     }
/*      */ 
/*      */     public RawKeyValueIterator merge(Path[] inNames, Path tempDir, boolean deleteInputs)
/*      */       throws IOException
/*      */     {
/* 2695 */       this.outFile = new Path(tempDir + "/" + "merged");
/*      */ 
/* 2697 */       ArrayList a = new ArrayList();
/* 2698 */       for (int i = 0; i < inNames.length; i++) {
/* 2699 */         SegmentDescriptor s = new SegmentDescriptor(0L, this.fs.getLength(inNames[i]), inNames[i]);
/*      */ 
/* 2701 */         s.preserveInput(!deleteInputs);
/* 2702 */         s.doSync();
/* 2703 */         a.add(s);
/*      */       }
/* 2705 */       this.factor = (inNames.length < this.factor ? inNames.length : this.factor);
/*      */ 
/* 2707 */       MergeQueue mQueue = new MergeQueue(a, tempDir, this.progressable);
/* 2708 */       return mQueue.merge();
/*      */     }
/*      */ 
/*      */     public SequenceFile.Writer cloneFileAttributes(Path inputFile, Path outputFile, Progressable prog)
/*      */       throws IOException
/*      */     {
/* 2724 */       FileSystem srcFileSys = inputFile.getFileSystem(this.conf);
/* 2725 */       SequenceFile.Reader reader = new SequenceFile.Reader(srcFileSys, inputFile, 4096, this.conf, true, null);
/* 2726 */       boolean compress = reader.isCompressed();
/* 2727 */       boolean blockCompress = reader.isBlockCompressed();
/* 2728 */       CompressionCodec codec = reader.getCompressionCodec();
/* 2729 */       reader.close();
/*      */ 
/* 2731 */       SequenceFile.Writer writer = SequenceFile.createWriter(outputFile.getFileSystem(this.conf), this.conf, outputFile, this.keyClass, this.valClass, compress, blockCompress, codec, prog, new SequenceFile.Metadata());
/*      */ 
/* 2735 */       return writer;
/*      */     }
/*      */ 
/*      */     public void writeFile(RawKeyValueIterator records, SequenceFile.Writer writer)
/*      */       throws IOException
/*      */     {
/* 2747 */       while (records.next()) {
/* 2748 */         writer.appendRaw(records.getKey().getData(), 0, records.getKey().getLength(), records.getValue());
/*      */       }
/*      */ 
/* 2751 */       writer.sync();
/*      */     }
/*      */ 
/*      */     public void merge(Path[] inFiles, Path outFile)
/*      */       throws IOException
/*      */     {
/* 2760 */       if (this.fs.exists(outFile)) {
/* 2761 */         throw new IOException("already exists: " + outFile);
/*      */       }
/* 2763 */       RawKeyValueIterator r = merge(inFiles, false, outFile.getParent());
/* 2764 */       SequenceFile.Writer writer = cloneFileAttributes(inFiles[0], outFile, null);
/*      */ 
/* 2766 */       writeFile(r, writer);
/*      */ 
/* 2768 */       writer.close();
/*      */     }
/*      */ 
/*      */     private int mergePass(Path tmpDir) throws IOException
/*      */     {
/* 2773 */       SequenceFile.LOG.debug("running merge pass");
/* 2774 */       SequenceFile.Writer writer = cloneFileAttributes(this.outFile.suffix(".0"), this.outFile, null);
/*      */ 
/* 2776 */       RawKeyValueIterator r = merge(this.outFile.suffix(".0"), this.outFile.suffix(".0.index"), tmpDir);
/*      */ 
/* 2778 */       writeFile(r, writer);
/*      */ 
/* 2780 */       writer.close();
/* 2781 */       return 0;
/*      */     }
/*      */ 
/*      */     private RawKeyValueIterator merge(Path inName, Path indexIn, Path tmpDir)
/*      */       throws IOException
/*      */     {
/* 2798 */       SegmentContainer container = new SegmentContainer(inName, indexIn);
/* 2799 */       MergeQueue mQueue = new MergeQueue(container.getSegmentList(), tmpDir, this.progressable);
/* 2800 */       return mQueue.merge();
/*      */     }
/*      */ 
/*      */     private class SegmentContainer
/*      */     {
/* 3221 */       private int numSegmentsCleanedUp = 0;
/*      */       private int numSegmentsContained;
/*      */       private Path inName;
/* 3226 */       private ArrayList<SequenceFile.Sorter.SegmentDescriptor> segments = new ArrayList();
/*      */ 
/*      */       public SegmentContainer(Path inName, Path indexIn)
/*      */         throws IOException
/*      */       {
/* 3232 */         FSDataInputStream fsIndexIn = SequenceFile.Sorter.this.fs.open(indexIn);
/* 3233 */         long end = SequenceFile.Sorter.this.fs.getLength(indexIn);
/* 3234 */         while (fsIndexIn.getPos() < end) {
/* 3235 */           long segmentOffset = WritableUtils.readVLong(fsIndexIn);
/* 3236 */           long segmentLength = WritableUtils.readVLong(fsIndexIn);
/* 3237 */           Path segmentName = inName;
/* 3238 */           this.segments.add(new SequenceFile.Sorter.LinkedSegmentsDescriptor(SequenceFile.Sorter.this, segmentOffset, segmentLength, segmentName, this));
/*      */         }
/*      */ 
/* 3241 */         fsIndexIn.close();
/* 3242 */         SequenceFile.Sorter.this.fs.delete(indexIn, true);
/* 3243 */         this.numSegmentsContained = this.segments.size();
/* 3244 */         this.inName = inName;
/*      */       }
/*      */ 
/*      */       public List<SequenceFile.Sorter.SegmentDescriptor> getSegmentList() {
/* 3248 */         return this.segments;
/*      */       }
/*      */       public void cleanup() throws IOException {
/* 3251 */         this.numSegmentsCleanedUp += 1;
/* 3252 */         if (this.numSegmentsCleanedUp == this.numSegmentsContained)
/* 3253 */           SequenceFile.Sorter.this.fs.delete(this.inName, true);
/*      */       }
/*      */     }
/*      */ 
/*      */     private class LinkedSegmentsDescriptor extends SequenceFile.Sorter.SegmentDescriptor
/*      */     {
/* 3194 */       SequenceFile.Sorter.SegmentContainer parentContainer = null;
/*      */ 
/*      */       public LinkedSegmentsDescriptor(long segmentOffset, long segmentLength, Path segmentPathName, SequenceFile.Sorter.SegmentContainer parent)
/*      */       {
/* 3204 */         super(segmentOffset, segmentLength, segmentPathName);
/* 3205 */         this.parentContainer = parent;
/*      */       }
/*      */ 
/*      */       public void cleanup()
/*      */         throws IOException
/*      */       {
/* 3211 */         SequenceFile.Sorter.SegmentDescriptor.access$2600(this);
/* 3212 */         if (super.shouldPreserveInput()) return;
/* 3213 */         this.parentContainer.cleanup();
/*      */       }
/*      */     }
/*      */ 
/*      */     public class SegmentDescriptor
/*      */       implements Comparable
/*      */     {
/*      */       long segmentOffset;
/*      */       long segmentLength;
/*      */       Path segmentPathName;
/* 3065 */       boolean ignoreSync = true;
/* 3066 */       private SequenceFile.Reader in = null;
/* 3067 */       private DataOutputBuffer rawKey = null;
/* 3068 */       private boolean preserveInput = false;
/*      */ 
/*      */       public SegmentDescriptor(long segmentOffset, long segmentLength, Path segmentPathName)
/*      */       {
/* 3077 */         this.segmentOffset = segmentOffset;
/* 3078 */         this.segmentLength = segmentLength;
/* 3079 */         this.segmentPathName = segmentPathName;
/*      */       }
/*      */ 
/*      */       public void doSync() {
/* 3083 */         this.ignoreSync = false;
/*      */       }
/*      */ 
/*      */       public void preserveInput(boolean preserve) {
/* 3087 */         this.preserveInput = preserve;
/*      */       }
/*      */ 
/*      */       public boolean shouldPreserveInput() {
/* 3091 */         return this.preserveInput;
/*      */       }
/*      */ 
/*      */       public int compareTo(Object o) {
/* 3095 */         SegmentDescriptor that = (SegmentDescriptor)o;
/* 3096 */         if (this.segmentLength != that.segmentLength) {
/* 3097 */           return this.segmentLength < that.segmentLength ? -1 : 1;
/*      */         }
/* 3099 */         if (this.segmentOffset != that.segmentOffset) {
/* 3100 */           return this.segmentOffset < that.segmentOffset ? -1 : 1;
/*      */         }
/* 3102 */         return this.segmentPathName.toString().compareTo(that.segmentPathName.toString());
/*      */       }
/*      */ 
/*      */       public boolean equals(Object o)
/*      */       {
/* 3107 */         if (!(o instanceof SegmentDescriptor)) {
/* 3108 */           return false;
/*      */         }
/* 3110 */         SegmentDescriptor that = (SegmentDescriptor)o;
/* 3111 */         if ((this.segmentLength == that.segmentLength) && (this.segmentOffset == that.segmentOffset) && (this.segmentPathName.toString().equals(that.segmentPathName.toString())))
/*      */         {
/* 3115 */           return true;
/*      */         }
/* 3117 */         return false;
/*      */       }
/*      */ 
/*      */       public int hashCode() {
/* 3121 */         return 629 + (int)(this.segmentOffset ^ this.segmentOffset >>> 32);
/*      */       }
/*      */ 
/*      */       public boolean nextRawKey()
/*      */         throws IOException
/*      */       {
/* 3129 */         if (this.in == null) {
/* 3130 */           int bufferSize = SequenceFile.Sorter.this.conf.getInt("io.file.buffer.size", 4096);
/* 3131 */           if (SequenceFile.Sorter.this.fs.getUri().getScheme().startsWith("ramfs")) {
/* 3132 */             bufferSize = SequenceFile.Sorter.this.conf.getInt("io.bytes.per.checksum", 512);
/*      */           }
/* 3134 */           SequenceFile.Reader reader = new SequenceFile.Reader(SequenceFile.Sorter.this.fs, this.segmentPathName, bufferSize, this.segmentOffset, this.segmentLength, SequenceFile.Sorter.this.conf, false, null);
/*      */ 
/* 3139 */           if (this.ignoreSync) SequenceFile.Reader.access$2502(reader, null);
/*      */ 
/* 3141 */           if (reader.getKeyClass() != SequenceFile.Sorter.this.keyClass) {
/* 3142 */             throw new IOException("wrong key class: " + reader.getKeyClass() + " is not " + SequenceFile.Sorter.this.keyClass);
/*      */           }
/* 3144 */           if (reader.getValueClass() != SequenceFile.Sorter.this.valClass) {
/* 3145 */             throw new IOException("wrong value class: " + reader.getValueClass() + " is not " + SequenceFile.Sorter.this.valClass);
/*      */           }
/* 3147 */           this.in = reader;
/* 3148 */           this.rawKey = new DataOutputBuffer();
/*      */         }
/* 3150 */         this.rawKey.reset();
/* 3151 */         int keyLength = this.in.nextRawKey(this.rawKey);
/*      */ 
/* 3153 */         return keyLength >= 0;
/*      */       }
/*      */ 
/*      */       public int nextRawValue(SequenceFile.ValueBytes rawValue)
/*      */         throws IOException
/*      */       {
/* 3163 */         int valLength = this.in.nextRawValue(rawValue);
/* 3164 */         return valLength;
/*      */       }
/*      */ 
/*      */       public DataOutputBuffer getKey()
/*      */       {
/* 3169 */         return this.rawKey;
/*      */       }
/*      */ 
/*      */       private void close() throws IOException
/*      */       {
/* 3174 */         this.in.close();
/* 3175 */         this.in = null;
/*      */       }
/*      */ 
/*      */       public void cleanup()
/*      */         throws IOException
/*      */       {
/* 3182 */         close();
/* 3183 */         if (!this.preserveInput)
/* 3184 */           SequenceFile.Sorter.this.fs.delete(this.segmentPathName, true);
/*      */       }
/*      */     }
/*      */ 
/*      */     private class MergeQueue extends PriorityQueue
/*      */       implements SequenceFile.Sorter.RawKeyValueIterator
/*      */     {
/*      */       private boolean compress;
/*      */       private boolean blockCompress;
/* 2808 */       private DataOutputBuffer rawKey = new DataOutputBuffer();
/*      */       private SequenceFile.ValueBytes rawValue;
/*      */       private long totalBytesProcessed;
/*      */       private float progPerByte;
/* 2812 */       private Progress mergeProgress = new Progress();
/*      */       private Path tmpDir;
/* 2814 */       private Progressable progress = null;
/*      */       private SequenceFile.Sorter.SegmentDescriptor minSegment;
/* 2819 */       private Map<SequenceFile.Sorter.SegmentDescriptor, Void> sortedSegmentSizes = new TreeMap();
/*      */ 
/*      */       public void put(SequenceFile.Sorter.SegmentDescriptor stream)
/*      */         throws IOException
/*      */       {
/* 2824 */         if (size() == 0) {
/* 2825 */           this.compress = stream.in.isCompressed();
/* 2826 */           this.blockCompress = stream.in.isBlockCompressed();
/* 2827 */         } else if ((this.compress != stream.in.isCompressed()) || (this.blockCompress != stream.in.isBlockCompressed()))
/*      */         {
/* 2829 */           throw new IOException("All merged files must be compressed or not.");
/*      */         }
/* 2831 */         super.put(stream);
/*      */       }
/*      */ 
/*      */       public MergeQueue(Path segments, Progressable tmpDir)
/*      */       {
/* 2842 */         int size = segments.size();
/* 2843 */         for (int i = 0; i < size; i++) {
/* 2844 */           this.sortedSegmentSizes.put(segments.get(i), null);
/*      */         }
/* 2846 */         this.tmpDir = tmpDir;
/* 2847 */         this.progress = progress;
/*      */       }
/*      */ 
/*      */       protected boolean lessThan(Object a, Object b) {
/* 2851 */         if (this.progress != null) {
/* 2852 */           this.progress.progress();
/*      */         }
/* 2854 */         SequenceFile.Sorter.SegmentDescriptor msa = (SequenceFile.Sorter.SegmentDescriptor)a;
/* 2855 */         SequenceFile.Sorter.SegmentDescriptor msb = (SequenceFile.Sorter.SegmentDescriptor)b;
/* 2856 */         return SequenceFile.Sorter.this.comparator.compare(msa.getKey().getData(), 0, msa.getKey().getLength(), msb.getKey().getData(), 0, msb.getKey().getLength()) < 0;
/*      */       }
/*      */ 
/*      */       public void close()
/*      */         throws IOException
/*      */       {
/*      */         SequenceFile.Sorter.SegmentDescriptor ms;
/* 2862 */         while ((ms = (SequenceFile.Sorter.SegmentDescriptor)pop()) != null) {
/* 2863 */           ms.cleanup();
/*      */         }
/* 2865 */         this.minSegment = null;
/*      */       }
/*      */       public DataOutputBuffer getKey() throws IOException {
/* 2868 */         return this.rawKey;
/*      */       }
/*      */       public SequenceFile.ValueBytes getValue() throws IOException {
/* 2871 */         return this.rawValue;
/*      */       }
/*      */       public boolean next() throws IOException {
/* 2874 */         if (size() == 0)
/* 2875 */           return false;
/* 2876 */         if (this.minSegment != null)
/*      */         {
/* 2880 */           adjustPriorityQueue(this.minSegment);
/* 2881 */           if (size() == 0) {
/* 2882 */             this.minSegment = null;
/* 2883 */             return false;
/*      */           }
/*      */         }
/* 2886 */         this.minSegment = ((SequenceFile.Sorter.SegmentDescriptor)top());
/* 2887 */         long startPos = this.minSegment.in.getPosition();
/*      */ 
/* 2889 */         this.rawKey = this.minSegment.getKey();
/*      */ 
/* 2891 */         if (this.rawValue == null) {
/* 2892 */           this.rawValue = this.minSegment.in.createValueBytes();
/*      */         }
/* 2894 */         this.minSegment.nextRawValue(this.rawValue);
/* 2895 */         long endPos = this.minSegment.in.getPosition();
/* 2896 */         updateProgress(endPos - startPos);
/* 2897 */         return true;
/*      */       }
/*      */ 
/*      */       public Progress getProgress() {
/* 2901 */         return this.mergeProgress;
/*      */       }
/*      */ 
/*      */       private void adjustPriorityQueue(SequenceFile.Sorter.SegmentDescriptor ms) throws IOException {
/* 2905 */         long startPos = ms.in.getPosition();
/* 2906 */         boolean hasNext = ms.nextRawKey();
/* 2907 */         long endPos = ms.in.getPosition();
/* 2908 */         updateProgress(endPos - startPos);
/* 2909 */         if (hasNext) {
/* 2910 */           adjustTop();
/*      */         } else {
/* 2912 */           pop();
/* 2913 */           ms.cleanup();
/*      */         }
/*      */       }
/*      */ 
/*      */       private void updateProgress(long bytesProcessed) {
/* 2918 */         this.totalBytesProcessed += bytesProcessed;
/* 2919 */         if (this.progPerByte > 0.0F)
/* 2920 */           this.mergeProgress.set((float)this.totalBytesProcessed * this.progPerByte);
/*      */       }
/*      */ 
/*      */       public SequenceFile.Sorter.RawKeyValueIterator merge()
/*      */         throws IOException
/*      */       {
/* 2932 */         int numSegments = this.sortedSegmentSizes.size();
/* 2933 */         int origFactor = SequenceFile.Sorter.this.factor;
/* 2934 */         int passNo = 1;
/* 2935 */         LocalDirAllocator lDirAlloc = new LocalDirAllocator("mapred.local.dir");
/*      */         while (true)
/*      */         {
/* 2938 */           SequenceFile.Sorter.this.factor = getPassFactor(passNo, numSegments);
/* 2939 */           List segmentsToMerge = new ArrayList();
/*      */ 
/* 2941 */           int segmentsConsidered = 0;
/* 2942 */           int numSegmentsToConsider = SequenceFile.Sorter.this.factor;
/*      */           while (true)
/*      */           {
/* 2946 */             SequenceFile.Sorter.SegmentDescriptor[] mStream = getSegmentDescriptors(numSegmentsToConsider);
/*      */ 
/* 2948 */             for (int i = 0; i < mStream.length; i++) {
/* 2949 */               if (mStream[i].nextRawKey()) {
/* 2950 */                 segmentsToMerge.add(mStream[i]);
/* 2951 */                 segmentsConsidered++;
/*      */ 
/* 2953 */                 updateProgress(mStream[i].in.getPosition());
/*      */               }
/*      */               else {
/* 2956 */                 mStream[i].cleanup();
/* 2957 */                 numSegments--;
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/* 2962 */             if ((segmentsConsidered == SequenceFile.Sorter.this.factor) || (this.sortedSegmentSizes.size() == 0))
/*      */             {
/*      */               break;
/*      */             }
/*      */ 
/* 2967 */             numSegmentsToConsider = SequenceFile.Sorter.this.factor - segmentsConsidered;
/*      */           }
/*      */ 
/* 2970 */           initialize(segmentsToMerge.size()); clear();
/* 2971 */           for (int i = 0; i < segmentsToMerge.size(); i++) {
/* 2972 */             put((SequenceFile.Sorter.SegmentDescriptor)segmentsToMerge.get(i));
/*      */           }
/*      */ 
/* 2976 */           if (numSegments <= SequenceFile.Sorter.this.factor)
/*      */           {
/* 2979 */             long totalBytes = 0L;
/* 2980 */             for (int i = 0; i < segmentsToMerge.size(); i++) {
/* 2981 */               totalBytes += ((SequenceFile.Sorter.SegmentDescriptor)segmentsToMerge.get(i)).segmentLength;
/*      */             }
/* 2983 */             if (totalBytes != 0L) {
/* 2984 */               this.progPerByte = (1.0F / (float)totalBytes);
/*      */             }
/* 2986 */             SequenceFile.Sorter.this.factor = origFactor;
/* 2987 */             return this;
/*      */           }
/*      */ 
/* 2991 */           long approxOutputSize = 0L;
/* 2992 */           for (SequenceFile.Sorter.SegmentDescriptor s : segmentsToMerge) {
/* 2993 */             approxOutputSize = ()(approxOutputSize + (s.segmentLength + ChecksumFileSystem.getApproxChkSumLength(s.segmentLength)));
/*      */           }
/*      */ 
/* 2997 */           Path tmpFilename = new Path(this.tmpDir, "intermediate").suffix("." + passNo);
/*      */ 
/* 3000 */           Path outputFile = lDirAlloc.getLocalPathForWrite(tmpFilename.toString(), approxOutputSize, SequenceFile.Sorter.this.conf);
/*      */ 
/* 3003 */           SequenceFile.LOG.debug("writing intermediate results to " + outputFile);
/* 3004 */           SequenceFile.Writer writer = SequenceFile.Sorter.this.cloneFileAttributes(SequenceFile.Sorter.this.fs.makeQualified(((SequenceFile.Sorter.SegmentDescriptor)segmentsToMerge.get(0)).segmentPathName), SequenceFile.Sorter.this.fs.makeQualified(outputFile), null);
/*      */ 
/* 3007 */           writer.sync = null;
/* 3008 */           SequenceFile.Sorter.this.writeFile(this, writer);
/* 3009 */           writer.close();
/*      */ 
/* 3013 */           close();
/*      */ 
/* 3015 */           SequenceFile.Sorter.SegmentDescriptor tempSegment = new SequenceFile.Sorter.SegmentDescriptor(SequenceFile.Sorter.this, 0L, SequenceFile.Sorter.this.fs.getLength(outputFile), outputFile);
/*      */ 
/* 3018 */           this.sortedSegmentSizes.put(tempSegment, null);
/* 3019 */           numSegments = this.sortedSegmentSizes.size();
/* 3020 */           passNo++;
/*      */ 
/* 3024 */           SequenceFile.Sorter.this.factor = origFactor;
/*      */         }
/*      */       }
/*      */ 
/*      */       public int getPassFactor(int passNo, int numSegments)
/*      */       {
/* 3030 */         if ((passNo > 1) || (numSegments <= SequenceFile.Sorter.this.factor) || (SequenceFile.Sorter.this.factor == 1))
/* 3031 */           return SequenceFile.Sorter.this.factor;
/* 3032 */         int mod = (numSegments - 1) % (SequenceFile.Sorter.this.factor - 1);
/* 3033 */         if (mod == 0)
/* 3034 */           return SequenceFile.Sorter.this.factor;
/* 3035 */         return mod + 1;
/*      */       }
/*      */ 
/*      */       public SequenceFile.Sorter.SegmentDescriptor[] getSegmentDescriptors(int numDescriptors)
/*      */       {
/* 3042 */         if (numDescriptors > this.sortedSegmentSizes.size())
/* 3043 */           numDescriptors = this.sortedSegmentSizes.size();
/* 3044 */         SequenceFile.Sorter.SegmentDescriptor[] SegmentDescriptors = new SequenceFile.Sorter.SegmentDescriptor[numDescriptors];
/*      */ 
/* 3046 */         Iterator iter = this.sortedSegmentSizes.keySet().iterator();
/* 3047 */         int i = 0;
/* 3048 */         while (i < numDescriptors) {
/* 3049 */           SegmentDescriptors[(i++)] = ((SequenceFile.Sorter.SegmentDescriptor)iter.next());
/* 3050 */           iter.remove();
/*      */         }
/* 3052 */         return SegmentDescriptors;
/*      */       }
/*      */     }
/*      */ 
/*      */     public static abstract interface RawKeyValueIterator
/*      */     {
/*      */       public abstract DataOutputBuffer getKey()
/*      */         throws IOException;
/*      */ 
/*      */       public abstract SequenceFile.ValueBytes getValue()
/*      */         throws IOException;
/*      */ 
/*      */       public abstract boolean next()
/*      */         throws IOException;
/*      */ 
/*      */       public abstract void close()
/*      */         throws IOException;
/*      */ 
/*      */       public abstract Progress getProgress();
/*      */     }
/*      */ 
/*      */     private class SortPass
/*      */     {
/*      */       private int memoryLimit;
/*      */       private int recordLimit;
/*      */       private DataOutputBuffer rawKeys;
/*      */       private byte[] rawBuffer;
/*      */       private int[] keyOffsets;
/*      */       private int[] pointers;
/*      */       private int[] pointersCopy;
/*      */       private int[] keyLengths;
/*      */       private SequenceFile.ValueBytes[] rawValues;
/*      */       private ArrayList segmentLengths;
/*      */       private SequenceFile.Reader in;
/*      */       private FSDataOutputStream out;
/*      */       private FSDataOutputStream indexOut;
/*      */       private Path outName;
/*      */       private Progressable progressable;
/*      */ 
/*      */       private SortPass()
/*      */       {
/* 2402 */         this.memoryLimit = (SequenceFile.Sorter.this.memory / 4);
/* 2403 */         this.recordLimit = 1000000;
/*      */ 
/* 2405 */         this.rawKeys = new DataOutputBuffer();
/*      */ 
/* 2408 */         this.keyOffsets = new int[1024];
/* 2409 */         this.pointers = new int[this.keyOffsets.length];
/* 2410 */         this.pointersCopy = new int[this.keyOffsets.length];
/* 2411 */         this.keyLengths = new int[this.keyOffsets.length];
/* 2412 */         this.rawValues = new SequenceFile.ValueBytes[this.keyOffsets.length];
/*      */ 
/* 2414 */         this.segmentLengths = new ArrayList();
/*      */ 
/* 2416 */         this.in = null;
/* 2417 */         this.out = null;
/* 2418 */         this.indexOut = null;
/*      */ 
/* 2421 */         this.progressable = null;
/*      */       }
/*      */       public int run(boolean deleteInput) throws IOException {
/* 2424 */         int segments = 0;
/* 2425 */         int currentFile = 0;
/* 2426 */         boolean atEof = currentFile >= SequenceFile.Sorter.this.inFiles.length;
/* 2427 */         boolean isCompressed = false;
/* 2428 */         boolean isBlockCompressed = false;
/* 2429 */         CompressionCodec codec = null;
/* 2430 */         this.segmentLengths.clear();
/* 2431 */         if (atEof) {
/* 2432 */           return 0;
/*      */         }
/*      */ 
/* 2436 */         this.in = new SequenceFile.Reader(SequenceFile.Sorter.this.fs, SequenceFile.Sorter.this.inFiles[currentFile], SequenceFile.Sorter.this.conf);
/* 2437 */         isCompressed = this.in.isCompressed();
/* 2438 */         isBlockCompressed = this.in.isBlockCompressed();
/* 2439 */         codec = this.in.getCompressionCodec();
/*      */ 
/* 2441 */         for (int i = 0; i < this.rawValues.length; i++) {
/* 2442 */           this.rawValues[i] = null;
/*      */         }
/*      */ 
/* 2445 */         while (!atEof) {
/* 2446 */           int count = 0;
/* 2447 */           int bytesProcessed = 0;
/* 2448 */           this.rawKeys.reset();
/*      */ 
/* 2450 */           while ((!atEof) && (bytesProcessed < this.memoryLimit) && (count < this.recordLimit))
/*      */           {
/* 2454 */             int keyOffset = this.rawKeys.getLength();
/* 2455 */             SequenceFile.ValueBytes rawValue = (count == this.keyOffsets.length) || (this.rawValues[count] == null) ? this.in.createValueBytes() : this.rawValues[count];
/*      */ 
/* 2459 */             int recordLength = this.in.nextRaw(this.rawKeys, rawValue);
/* 2460 */             if (recordLength == -1) {
/* 2461 */               this.in.close();
/* 2462 */               if (deleteInput) {
/* 2463 */                 SequenceFile.Sorter.this.fs.delete(SequenceFile.Sorter.this.inFiles[currentFile], true);
/*      */               }
/* 2465 */               currentFile++;
/* 2466 */               atEof = currentFile >= SequenceFile.Sorter.this.inFiles.length;
/* 2467 */               if (!atEof)
/* 2468 */                 this.in = new SequenceFile.Reader(SequenceFile.Sorter.this.fs, SequenceFile.Sorter.this.inFiles[currentFile], SequenceFile.Sorter.this.conf);
/*      */               else {
/* 2470 */                 this.in = null;
/*      */               }
/*      */             }
/*      */             else
/*      */             {
/* 2475 */               int keyLength = this.rawKeys.getLength() - keyOffset;
/*      */ 
/* 2477 */               if (count == this.keyOffsets.length) {
/* 2478 */                 grow();
/*      */               }
/* 2480 */               this.keyOffsets[count] = keyOffset;
/* 2481 */               this.pointers[count] = count;
/* 2482 */               this.keyLengths[count] = keyLength;
/* 2483 */               this.rawValues[count] = rawValue;
/*      */ 
/* 2485 */               bytesProcessed += recordLength;
/* 2486 */               count++;
/*      */             }
/*      */           }
/*      */ 
/* 2490 */           SequenceFile.LOG.debug("flushing segment " + segments);
/* 2491 */           this.rawBuffer = this.rawKeys.getData();
/* 2492 */           sort(count);
/*      */ 
/* 2494 */           if (this.progressable != null) {
/* 2495 */             this.progressable.progress();
/*      */           }
/* 2497 */           flush(count, bytesProcessed, isCompressed, isBlockCompressed, codec, (segments == 0) && (atEof));
/*      */ 
/* 2499 */           segments++;
/*      */         }
/* 2501 */         return segments;
/*      */       }
/*      */ 
/*      */       public void close() throws IOException {
/* 2505 */         if (this.in != null) {
/* 2506 */           this.in.close();
/*      */         }
/* 2508 */         if (this.out != null) {
/* 2509 */           this.out.close();
/*      */         }
/* 2511 */         if (this.indexOut != null)
/* 2512 */           this.indexOut.close();
/*      */       }
/*      */ 
/*      */       private void grow()
/*      */       {
/* 2517 */         int newLength = this.keyOffsets.length * 3 / 2;
/* 2518 */         this.keyOffsets = grow(this.keyOffsets, newLength);
/* 2519 */         this.pointers = grow(this.pointers, newLength);
/* 2520 */         this.pointersCopy = new int[newLength];
/* 2521 */         this.keyLengths = grow(this.keyLengths, newLength);
/* 2522 */         this.rawValues = grow(this.rawValues, newLength);
/*      */       }
/*      */ 
/*      */       private int[] grow(int[] old, int newLength) {
/* 2526 */         int[] result = new int[newLength];
/* 2527 */         System.arraycopy(old, 0, result, 0, old.length);
/* 2528 */         return result;
/*      */       }
/*      */ 
/*      */       private SequenceFile.ValueBytes[] grow(SequenceFile.ValueBytes[] old, int newLength) {
/* 2532 */         SequenceFile.ValueBytes[] result = new SequenceFile.ValueBytes[newLength];
/* 2533 */         System.arraycopy(old, 0, result, 0, old.length);
/* 2534 */         for (int i = old.length; i < newLength; i++) {
/* 2535 */           result[i] = null;
/*      */         }
/* 2537 */         return result;
/*      */       }
/*      */ 
/*      */       private void flush(int count, int bytesProcessed, boolean isCompressed, boolean isBlockCompressed, CompressionCodec codec, boolean done)
/*      */         throws IOException
/*      */       {
/* 2543 */         if (this.out == null) {
/* 2544 */           this.outName = (done ? SequenceFile.Sorter.this.outFile : SequenceFile.Sorter.this.outFile.suffix(".0"));
/* 2545 */           this.out = SequenceFile.Sorter.this.fs.create(this.outName);
/* 2546 */           if (!done) {
/* 2547 */             this.indexOut = SequenceFile.Sorter.this.fs.create(this.outName.suffix(".index"));
/*      */           }
/*      */         }
/*      */ 
/* 2551 */         long segmentStart = this.out.getPos();
/* 2552 */         SequenceFile.Writer writer = SequenceFile.createWriter(SequenceFile.Sorter.this.conf, this.out, SequenceFile.Sorter.this.keyClass, SequenceFile.Sorter.this.valClass, isCompressed, isBlockCompressed, codec, new SequenceFile.Metadata());
/*      */ 
/* 2556 */         if (!done) {
/* 2557 */           writer.sync = null;
/*      */         }
/*      */ 
/* 2560 */         for (int i = 0; i < count; i++) {
/* 2561 */           int p = this.pointers[i];
/* 2562 */           writer.appendRaw(this.rawBuffer, this.keyOffsets[p], this.keyLengths[p], this.rawValues[p]);
/*      */         }
/* 2564 */         writer.close();
/*      */ 
/* 2566 */         if (!done)
/*      */         {
/* 2568 */           WritableUtils.writeVLong(this.indexOut, segmentStart);
/* 2569 */           WritableUtils.writeVLong(this.indexOut, this.out.getPos() - segmentStart);
/* 2570 */           this.indexOut.flush();
/*      */         }
/*      */       }
/*      */ 
/*      */       private void sort(int count) {
/* 2575 */         System.arraycopy(this.pointers, 0, this.pointersCopy, 0, count);
/* 2576 */         SequenceFile.Sorter.this.mergeSort.mergeSort(this.pointersCopy, this.pointers, 0, count);
/*      */       }
/*      */ 
/*      */       public void setProgressable(Progressable progressable)
/*      */       {
/* 2589 */         this.progressable = progressable;
/*      */       }
/*      */ 
/*      */       class SeqFileComparator
/*      */         implements Comparator<IntWritable>
/*      */       {
/*      */         SeqFileComparator()
/*      */         {
/*      */         }
/*      */ 
/*      */         public int compare(IntWritable I, IntWritable J)
/*      */         {
/* 2580 */           return SequenceFile.Sorter.this.comparator.compare(SequenceFile.Sorter.SortPass.this.rawBuffer, SequenceFile.Sorter.SortPass.this.keyOffsets[I.get()], SequenceFile.Sorter.SortPass.this.keyLengths[I.get()], SequenceFile.Sorter.SortPass.this.rawBuffer, SequenceFile.Sorter.SortPass.this.keyOffsets[J.get()], SequenceFile.Sorter.SortPass.this.keyLengths[J.get()]);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class Reader
/*      */     implements Closeable
/*      */   {
/*      */     private Path file;
/*      */     private FSDataInputStream in;
/* 1418 */     private DataOutputBuffer outBuf = new DataOutputBuffer();
/*      */     private byte version;
/*      */     private String keyClassName;
/*      */     private String valClassName;
/*      */     private Class keyClass;
/*      */     private Class valClass;
/* 1427 */     private CompressionCodec codec = null;
/* 1428 */     private SequenceFile.Metadata metadata = null;
/*      */ 
/* 1430 */     private byte[] sync = new byte[16];
/* 1431 */     private byte[] syncCheck = new byte[16];
/*      */     private boolean syncSeen;
/*      */     private long end;
/*      */     private int keyLength;
/*      */     private int recordLength;
/*      */     private boolean decompress;
/*      */     private boolean blockCompressed;
/*      */     private Configuration conf;
/* 1443 */     private int noBufferedRecords = 0;
/* 1444 */     private boolean lazyDecompress = true;
/* 1445 */     private boolean valuesDecompressed = true;
/*      */ 
/* 1447 */     private int noBufferedKeys = 0;
/* 1448 */     private int noBufferedValues = 0;
/*      */ 
/* 1450 */     private DataInputBuffer keyLenBuffer = null;
/* 1451 */     private CompressionInputStream keyLenInFilter = null;
/* 1452 */     private DataInputStream keyLenIn = null;
/* 1453 */     private Decompressor keyLenDecompressor = null;
/* 1454 */     private DataInputBuffer keyBuffer = null;
/* 1455 */     private CompressionInputStream keyInFilter = null;
/* 1456 */     private DataInputStream keyIn = null;
/* 1457 */     private Decompressor keyDecompressor = null;
/*      */ 
/* 1459 */     private DataInputBuffer valLenBuffer = null;
/* 1460 */     private CompressionInputStream valLenInFilter = null;
/* 1461 */     private DataInputStream valLenIn = null;
/* 1462 */     private Decompressor valLenDecompressor = null;
/* 1463 */     private DataInputBuffer valBuffer = null;
/* 1464 */     private CompressionInputStream valInFilter = null;
/* 1465 */     private DataInputStream valIn = null;
/* 1466 */     private Decompressor valDecompressor = null;
/*      */     private Deserializer keyDeserializer;
/*      */     private Deserializer valDeserializer;
/*      */ 
/*      */     public Reader(FileSystem fs, Path file, Configuration conf)
/*      */       throws IOException
/*      */     {
/* 1474 */       this(fs, file, conf.getInt("io.file.buffer.size", 4096), conf, false);
/*      */     }
/*      */ 
/*      */     private Reader(FileSystem fs, Path file, int bufferSize, Configuration conf, boolean tempReader) throws IOException
/*      */     {
/* 1479 */       this(fs, file, bufferSize, 0L, fs.getLength(file), conf, tempReader);
/*      */     }
/*      */ 
/*      */     private Reader(FileSystem fs, Path file, int bufferSize, long start, long length, Configuration conf, boolean tempReader)
/*      */       throws IOException
/*      */     {
/* 1485 */       this.file = file;
/* 1486 */       this.in = openFile(fs, file, bufferSize, length);
/* 1487 */       this.conf = conf;
/* 1488 */       seek(start);
/* 1489 */       this.end = (this.in.getPos() + length);
/* 1490 */       init(tempReader);
/*      */     }
/*      */ 
/*      */     protected FSDataInputStream openFile(FileSystem fs, Path file, int bufferSize, long length)
/*      */       throws IOException
/*      */     {
/* 1499 */       return fs.open(file, bufferSize);
/*      */     }
/*      */ 
/*      */     private void init(boolean tempReader)
/*      */       throws IOException
/*      */     {
/* 1511 */       byte[] versionBlock = new byte[SequenceFile.VERSION.length];
/* 1512 */       this.in.readFully(versionBlock);
/*      */ 
/* 1514 */       if ((versionBlock[0] != SequenceFile.VERSION[0]) || (versionBlock[1] != SequenceFile.VERSION[1]) || (versionBlock[2] != SequenceFile.VERSION[2]))
/*      */       {
/* 1517 */         throw new IOException(this.file + " not a SequenceFile");
/*      */       }
/*      */ 
/* 1520 */       this.version = versionBlock[3];
/* 1521 */       if (this.version > SequenceFile.VERSION[3]) {
/* 1522 */         throw new VersionMismatchException(SequenceFile.VERSION[3], this.version);
/*      */       }
/* 1524 */       if (this.version < 4) {
/* 1525 */         UTF8 className = new UTF8();
/*      */ 
/* 1527 */         className.readFields(this.in);
/* 1528 */         this.keyClassName = className.toStringChecked();
/*      */ 
/* 1530 */         className.readFields(this.in);
/* 1531 */         this.valClassName = className.toStringChecked();
/*      */       } else {
/* 1533 */         this.keyClassName = Text.readString(this.in);
/* 1534 */         this.valClassName = Text.readString(this.in);
/*      */       }
/*      */ 
/* 1537 */       if (this.version > 2)
/* 1538 */         this.decompress = this.in.readBoolean();
/*      */       else {
/* 1540 */         this.decompress = false;
/*      */       }
/*      */ 
/* 1543 */       if (this.version >= 4)
/* 1544 */         this.blockCompressed = this.in.readBoolean();
/*      */       else {
/* 1546 */         this.blockCompressed = false;
/*      */       }
/*      */ 
/* 1551 */       if (this.decompress) {
/* 1552 */         if (this.version >= 5) {
/* 1553 */           String codecClassname = Text.readString(this.in);
/*      */           try {
/* 1555 */             Class codecClass = this.conf.getClassByName(codecClassname).asSubclass(CompressionCodec.class);
/*      */ 
/* 1557 */             this.codec = ((CompressionCodec)ReflectionUtils.newInstance(codecClass, this.conf));
/*      */           } catch (ClassNotFoundException cnfe) {
/* 1559 */             throw new IllegalArgumentException("Unknown codec: " + codecClassname, cnfe);
/*      */           }
/*      */         }
/*      */         else {
/* 1563 */           this.codec = new DefaultCodec();
/* 1564 */           ((Configurable)this.codec).setConf(this.conf);
/*      */         }
/*      */       }
/*      */ 
/* 1568 */       this.metadata = new SequenceFile.Metadata();
/* 1569 */       if (this.version >= 6) {
/* 1570 */         this.metadata.readFields(this.in);
/*      */       }
/*      */ 
/* 1573 */       if (this.version > 1) {
/* 1574 */         this.in.readFully(this.sync);
/*      */       }
/*      */ 
/* 1578 */       if (!tempReader) {
/* 1579 */         this.valBuffer = new DataInputBuffer();
/* 1580 */         if (this.decompress) {
/* 1581 */           this.valDecompressor = CodecPool.getDecompressor(this.codec);
/* 1582 */           this.valInFilter = this.codec.createInputStream(this.valBuffer, this.valDecompressor);
/* 1583 */           this.valIn = new DataInputStream(this.valInFilter);
/*      */         } else {
/* 1585 */           this.valIn = this.valBuffer;
/*      */         }
/*      */ 
/* 1588 */         if (this.blockCompressed) {
/* 1589 */           this.keyLenBuffer = new DataInputBuffer();
/* 1590 */           this.keyBuffer = new DataInputBuffer();
/* 1591 */           this.valLenBuffer = new DataInputBuffer();
/*      */ 
/* 1593 */           this.keyLenDecompressor = CodecPool.getDecompressor(this.codec);
/* 1594 */           this.keyLenInFilter = this.codec.createInputStream(this.keyLenBuffer, this.keyLenDecompressor);
/*      */ 
/* 1596 */           this.keyLenIn = new DataInputStream(this.keyLenInFilter);
/*      */ 
/* 1598 */           this.keyDecompressor = CodecPool.getDecompressor(this.codec);
/* 1599 */           this.keyInFilter = this.codec.createInputStream(this.keyBuffer, this.keyDecompressor);
/* 1600 */           this.keyIn = new DataInputStream(this.keyInFilter);
/*      */ 
/* 1602 */           this.valLenDecompressor = CodecPool.getDecompressor(this.codec);
/* 1603 */           this.valLenInFilter = this.codec.createInputStream(this.valLenBuffer, this.valLenDecompressor);
/*      */ 
/* 1605 */           this.valLenIn = new DataInputStream(this.valLenInFilter);
/*      */         }
/*      */ 
/* 1608 */         SerializationFactory serializationFactory = new SerializationFactory(this.conf);
/*      */ 
/* 1610 */         this.keyDeserializer = getDeserializer(serializationFactory, getKeyClass());
/*      */ 
/* 1612 */         if (!this.blockCompressed)
/* 1613 */           this.keyDeserializer.open(this.valBuffer);
/*      */         else {
/* 1615 */           this.keyDeserializer.open(this.keyIn);
/*      */         }
/* 1617 */         this.valDeserializer = getDeserializer(serializationFactory, getValueClass());
/*      */ 
/* 1619 */         this.valDeserializer.open(this.valIn);
/*      */       }
/*      */     }
/*      */ 
/*      */     private Deserializer getDeserializer(SerializationFactory sf, Class c)
/*      */     {
/* 1625 */       return sf.getDeserializer(c);
/*      */     }
/*      */ 
/*      */     public synchronized void close()
/*      */       throws IOException
/*      */     {
/* 1631 */       CodecPool.returnDecompressor(this.keyLenDecompressor);
/* 1632 */       CodecPool.returnDecompressor(this.keyDecompressor);
/* 1633 */       CodecPool.returnDecompressor(this.valLenDecompressor);
/* 1634 */       CodecPool.returnDecompressor(this.valDecompressor);
/* 1635 */       this.keyLenDecompressor = (this.keyDecompressor = null);
/* 1636 */       this.valLenDecompressor = (this.valDecompressor = null);
/*      */ 
/* 1638 */       if (this.keyDeserializer != null) {
/* 1639 */         this.keyDeserializer.close();
/*      */       }
/* 1641 */       if (this.valDeserializer != null) {
/* 1642 */         this.valDeserializer.close();
/*      */       }
/*      */ 
/* 1646 */       this.in.close();
/*      */     }
/*      */ 
/*      */     public String getKeyClassName()
/*      */     {
/* 1651 */       return this.keyClassName;
/*      */     }
/*      */ 
/*      */     public synchronized Class<?> getKeyClass()
/*      */     {
/* 1656 */       if (null == this.keyClass) {
/*      */         try {
/* 1658 */           this.keyClass = WritableName.getClass(getKeyClassName(), this.conf);
/*      */         } catch (IOException e) {
/* 1660 */           throw new RuntimeException(e);
/*      */         }
/*      */       }
/* 1663 */       return this.keyClass;
/*      */     }
/*      */ 
/*      */     public String getValueClassName()
/*      */     {
/* 1668 */       return this.valClassName;
/*      */     }
/*      */ 
/*      */     public synchronized Class<?> getValueClass()
/*      */     {
/* 1673 */       if (null == this.valClass) {
/*      */         try {
/* 1675 */           this.valClass = WritableName.getClass(getValueClassName(), this.conf);
/*      */         } catch (IOException e) {
/* 1677 */           throw new RuntimeException(e);
/*      */         }
/*      */       }
/* 1680 */       return this.valClass;
/*      */     }
/*      */ 
/*      */     public boolean isCompressed() {
/* 1684 */       return this.decompress;
/*      */     }
/*      */     public boolean isBlockCompressed() {
/* 1687 */       return this.blockCompressed;
/*      */     }
/*      */     public CompressionCodec getCompressionCodec() {
/* 1690 */       return this.codec;
/*      */     }
/*      */ 
/*      */     public SequenceFile.Metadata getMetadata() {
/* 1694 */       return this.metadata;
/*      */     }
/*      */ 
/*      */     Configuration getConf() {
/* 1698 */       return this.conf;
/*      */     }
/*      */ 
/*      */     private synchronized void readBuffer(DataInputBuffer buffer, CompressionInputStream filter)
/*      */       throws IOException
/*      */     {
/* 1704 */       DataOutputBuffer dataBuffer = new DataOutputBuffer();
/*      */       try
/*      */       {
/* 1707 */         int dataBufferLength = WritableUtils.readVInt(this.in);
/* 1708 */         dataBuffer.write(this.in, dataBufferLength);
/*      */ 
/* 1711 */         buffer.reset(dataBuffer.getData(), 0, dataBuffer.getLength());
/*      */       } finally {
/* 1713 */         dataBuffer.close();
/*      */       }
/*      */ 
/* 1717 */       filter.resetState();
/*      */     }
/*      */ 
/*      */     private synchronized void readBlock()
/*      */       throws IOException
/*      */     {
/* 1724 */       if ((this.lazyDecompress) && (!this.valuesDecompressed)) {
/* 1725 */         this.in.seek(WritableUtils.readVInt(this.in) + this.in.getPos());
/* 1726 */         this.in.seek(WritableUtils.readVInt(this.in) + this.in.getPos());
/*      */       }
/*      */ 
/* 1730 */       this.noBufferedKeys = 0; this.noBufferedValues = 0; this.noBufferedRecords = 0;
/* 1731 */       this.valuesDecompressed = false;
/*      */ 
/* 1734 */       if (this.sync != null) {
/* 1735 */         this.in.readInt();
/* 1736 */         this.in.readFully(this.syncCheck);
/* 1737 */         if (!Arrays.equals(this.sync, this.syncCheck))
/* 1738 */           throw new IOException("File is corrupt!");
/*      */       }
/* 1740 */       this.syncSeen = true;
/*      */ 
/* 1743 */       this.noBufferedRecords = WritableUtils.readVInt(this.in);
/*      */ 
/* 1746 */       readBuffer(this.keyLenBuffer, this.keyLenInFilter);
/* 1747 */       readBuffer(this.keyBuffer, this.keyInFilter);
/* 1748 */       this.noBufferedKeys = this.noBufferedRecords;
/*      */ 
/* 1751 */       if (!this.lazyDecompress) {
/* 1752 */         readBuffer(this.valLenBuffer, this.valLenInFilter);
/* 1753 */         readBuffer(this.valBuffer, this.valInFilter);
/* 1754 */         this.noBufferedValues = this.noBufferedRecords;
/* 1755 */         this.valuesDecompressed = true;
/*      */       }
/*      */     }
/*      */ 
/*      */     private synchronized void seekToCurrentValue()
/*      */       throws IOException
/*      */     {
/* 1764 */       if (!this.blockCompressed) {
/* 1765 */         if (this.decompress) {
/* 1766 */           this.valInFilter.resetState();
/*      */         }
/* 1768 */         this.valBuffer.reset();
/*      */       }
/*      */       else {
/* 1771 */         if ((this.lazyDecompress) && (!this.valuesDecompressed))
/*      */         {
/* 1773 */           readBuffer(this.valLenBuffer, this.valLenInFilter);
/* 1774 */           readBuffer(this.valBuffer, this.valInFilter);
/* 1775 */           this.noBufferedValues = this.noBufferedRecords;
/* 1776 */           this.valuesDecompressed = true;
/*      */         }
/*      */ 
/* 1781 */         int skipValBytes = 0;
/* 1782 */         int currentKey = this.noBufferedKeys + 1;
/* 1783 */         for (int i = this.noBufferedValues; i > currentKey; i--) {
/* 1784 */           skipValBytes += WritableUtils.readVInt(this.valLenIn);
/* 1785 */           this.noBufferedValues -= 1;
/*      */         }
/*      */ 
/* 1789 */         if ((skipValBytes > 0) && 
/* 1790 */           (this.valIn.skipBytes(skipValBytes) != skipValBytes))
/* 1791 */           throw new IOException("Failed to seek to " + currentKey + "(th) value!");
/*      */       }
/*      */     }
/*      */ 
/*      */     public synchronized void getCurrentValue(Writable val)
/*      */       throws IOException
/*      */     {
/* 1805 */       if ((val instanceof Configurable)) {
/* 1806 */         ((Configurable)val).setConf(this.conf);
/*      */       }
/*      */ 
/* 1810 */       seekToCurrentValue();
/*      */ 
/* 1812 */       if (!this.blockCompressed) {
/* 1813 */         val.readFields(this.valIn);
/*      */ 
/* 1815 */         if (this.valIn.read() > 0) {
/* 1816 */           SequenceFile.LOG.info("available bytes: " + this.valIn.available());
/* 1817 */           throw new IOException(val + " read " + (this.valBuffer.getPosition() - this.keyLength) + " bytes, should read " + (this.valBuffer.getLength() - this.keyLength));
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1823 */         int valLength = WritableUtils.readVInt(this.valLenIn);
/* 1824 */         val.readFields(this.valIn);
/*      */ 
/* 1827 */         this.noBufferedValues -= 1;
/*      */ 
/* 1830 */         if (valLength < 0)
/* 1831 */           SequenceFile.LOG.debug(val + " is a zero-length value");
/*      */       }
/*      */     }
/*      */ 
/*      */     public synchronized Object getCurrentValue(Object val)
/*      */       throws IOException
/*      */     {
/* 1844 */       if ((val instanceof Configurable)) {
/* 1845 */         ((Configurable)val).setConf(this.conf);
/*      */       }
/*      */ 
/* 1849 */       seekToCurrentValue();
/*      */ 
/* 1851 */       if (!this.blockCompressed) {
/* 1852 */         val = deserializeValue(val);
/*      */ 
/* 1854 */         if (this.valIn.read() > 0) {
/* 1855 */           SequenceFile.LOG.info("available bytes: " + this.valIn.available());
/* 1856 */           throw new IOException(val + " read " + (this.valBuffer.getPosition() - this.keyLength) + " bytes, should read " + (this.valBuffer.getLength() - this.keyLength));
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1862 */         int valLength = WritableUtils.readVInt(this.valLenIn);
/* 1863 */         val = deserializeValue(val);
/*      */ 
/* 1866 */         this.noBufferedValues -= 1;
/*      */ 
/* 1869 */         if (valLength < 0) {
/* 1870 */           SequenceFile.LOG.debug(val + " is a zero-length value");
/*      */         }
/*      */       }
/* 1873 */       return val;
/*      */     }
/*      */ 
/*      */     private Object deserializeValue(Object val)
/*      */       throws IOException
/*      */     {
/* 1879 */       return this.valDeserializer.deserialize(val);
/*      */     }
/*      */ 
/*      */     public synchronized boolean next(Writable key)
/*      */       throws IOException
/*      */     {
/* 1885 */       if (key.getClass() != getKeyClass()) {
/* 1886 */         throw new IOException("wrong key class: " + key.getClass().getName() + " is not " + this.keyClass);
/*      */       }
/*      */ 
/* 1889 */       if (!this.blockCompressed) {
/* 1890 */         this.outBuf.reset();
/*      */ 
/* 1892 */         this.keyLength = next(this.outBuf);
/* 1893 */         if (this.keyLength < 0) {
/* 1894 */           return false;
/*      */         }
/* 1896 */         this.valBuffer.reset(this.outBuf.getData(), this.outBuf.getLength());
/*      */ 
/* 1898 */         key.readFields(this.valBuffer);
/* 1899 */         this.valBuffer.mark(0);
/* 1900 */         if (this.valBuffer.getPosition() != this.keyLength)
/* 1901 */           throw new IOException(key + " read " + this.valBuffer.getPosition() + " bytes, should read " + this.keyLength);
/*      */       }
/*      */       else
/*      */       {
/* 1905 */         this.syncSeen = false;
/*      */ 
/* 1907 */         if (this.noBufferedKeys == 0) {
/*      */           try {
/* 1909 */             readBlock();
/*      */           } catch (EOFException eof) {
/* 1911 */             return false;
/*      */           }
/*      */         }
/*      */ 
/* 1915 */         int keyLength = WritableUtils.readVInt(this.keyLenIn);
/*      */ 
/* 1918 */         if (keyLength < 0) {
/* 1919 */           return false;
/*      */         }
/*      */ 
/* 1923 */         key.readFields(this.keyIn);
/* 1924 */         this.noBufferedKeys -= 1;
/*      */       }
/*      */ 
/* 1927 */       return true;
/*      */     }
/*      */ 
/*      */     public synchronized boolean next(Writable key, Writable val)
/*      */       throws IOException
/*      */     {
/* 1935 */       if (val.getClass() != getValueClass()) {
/* 1936 */         throw new IOException("wrong value class: " + val + " is not " + this.valClass);
/*      */       }
/* 1938 */       boolean more = next(key);
/*      */ 
/* 1940 */       if (more) {
/* 1941 */         getCurrentValue(val);
/*      */       }
/*      */ 
/* 1944 */       return more;
/*      */     }
/*      */ 
/*      */     private synchronized int readRecordLength()
/*      */       throws IOException
/*      */     {
/* 1954 */       if (this.in.getPos() >= this.end) {
/* 1955 */         return -1;
/*      */       }
/* 1957 */       int length = this.in.readInt();
/* 1958 */       if ((this.version > 1) && (this.sync != null) && (length == -1))
/*      */       {
/* 1960 */         this.in.readFully(this.syncCheck);
/* 1961 */         if (!Arrays.equals(this.sync, this.syncCheck))
/* 1962 */           throw new IOException("File is corrupt!");
/* 1963 */         this.syncSeen = true;
/* 1964 */         if (this.in.getPos() >= this.end) {
/* 1965 */           return -1;
/*      */         }
/* 1967 */         length = this.in.readInt();
/*      */       } else {
/* 1969 */         this.syncSeen = false;
/*      */       }
/*      */ 
/* 1972 */       return length;
/*      */     }
/*      */ 
/*      */     /** @deprecated */
/*      */     public synchronized int next(DataOutputBuffer buffer)
/*      */       throws IOException
/*      */     {
/* 1982 */       if (this.blockCompressed) {
/* 1983 */         throw new IOException("Unsupported call for block-compressed SequenceFiles - use SequenceFile.Reader.next(DataOutputStream, ValueBytes)");
/*      */       }
/*      */       try
/*      */       {
/* 1987 */         int length = readRecordLength();
/* 1988 */         if (length == -1) {
/* 1989 */           return -1;
/*      */         }
/* 1991 */         int keyLength = this.in.readInt();
/* 1992 */         buffer.write(this.in, length);
/* 1993 */         return keyLength;
/*      */       } catch (ChecksumException e) {
/* 1995 */         handleChecksumException(e);
/* 1996 */       }return next(buffer);
/*      */     }
/*      */ 
/*      */     public SequenceFile.ValueBytes createValueBytes()
/*      */     {
/* 2001 */       SequenceFile.ValueBytes val = null;
/* 2002 */       if ((!this.decompress) || (this.blockCompressed))
/* 2003 */         val = new SequenceFile.UncompressedBytes(null);
/*      */       else {
/* 2005 */         val = new SequenceFile.CompressedBytes(this.codec, null);
/*      */       }
/* 2007 */       return val;
/*      */     }
/*      */ 
/*      */     public synchronized int nextRaw(DataOutputBuffer key, SequenceFile.ValueBytes val)
/*      */       throws IOException
/*      */     {
/* 2019 */       if (!this.blockCompressed) {
/* 2020 */         int length = readRecordLength();
/* 2021 */         if (length == -1) {
/* 2022 */           return -1;
/*      */         }
/* 2024 */         int keyLength = this.in.readInt();
/* 2025 */         int valLength = length - keyLength;
/* 2026 */         key.write(this.in, keyLength);
/* 2027 */         if (this.decompress) {
/* 2028 */           SequenceFile.CompressedBytes value = (SequenceFile.CompressedBytes)val;
/* 2029 */           SequenceFile.CompressedBytes.access$400(value, this.in, valLength);
/*      */         } else {
/* 2031 */           SequenceFile.UncompressedBytes value = (SequenceFile.UncompressedBytes)val;
/* 2032 */           SequenceFile.UncompressedBytes.access$500(value, this.in, valLength);
/*      */         }
/*      */ 
/* 2035 */         return length;
/*      */       }
/*      */ 
/* 2038 */       this.syncSeen = false;
/*      */ 
/* 2041 */       if (this.noBufferedKeys == 0) {
/* 2042 */         if (this.in.getPos() >= this.end)
/* 2043 */           return -1;
/*      */         try
/*      */         {
/* 2046 */           readBlock();
/*      */         } catch (EOFException eof) {
/* 2048 */           return -1;
/*      */         }
/*      */       }
/* 2051 */       int keyLength = WritableUtils.readVInt(this.keyLenIn);
/* 2052 */       if (keyLength < 0) {
/* 2053 */         throw new IOException("zero length key found!");
/*      */       }
/* 2055 */       key.write(this.keyIn, keyLength);
/* 2056 */       this.noBufferedKeys -= 1;
/*      */ 
/* 2059 */       seekToCurrentValue();
/* 2060 */       int valLength = WritableUtils.readVInt(this.valLenIn);
/* 2061 */       SequenceFile.UncompressedBytes rawValue = (SequenceFile.UncompressedBytes)val;
/* 2062 */       SequenceFile.UncompressedBytes.access$500(rawValue, this.valIn, valLength);
/* 2063 */       this.noBufferedValues -= 1;
/*      */ 
/* 2065 */       return keyLength + valLength;
/*      */     }
/*      */ 
/*      */     public int nextRawKey(DataOutputBuffer key)
/*      */       throws IOException
/*      */     {
/* 2078 */       if (!this.blockCompressed) {
/* 2079 */         this.recordLength = readRecordLength();
/* 2080 */         if (this.recordLength == -1) {
/* 2081 */           return -1;
/*      */         }
/* 2083 */         this.keyLength = this.in.readInt();
/* 2084 */         key.write(this.in, this.keyLength);
/* 2085 */         return this.keyLength;
/*      */       }
/*      */ 
/* 2088 */       this.syncSeen = false;
/*      */ 
/* 2091 */       if (this.noBufferedKeys == 0) {
/* 2092 */         if (this.in.getPos() >= this.end)
/* 2093 */           return -1;
/*      */         try
/*      */         {
/* 2096 */           readBlock();
/*      */         } catch (EOFException eof) {
/* 2098 */           return -1;
/*      */         }
/*      */       }
/* 2101 */       int keyLength = WritableUtils.readVInt(this.keyLenIn);
/* 2102 */       if (keyLength < 0) {
/* 2103 */         throw new IOException("zero length key found!");
/*      */       }
/* 2105 */       key.write(this.keyIn, keyLength);
/* 2106 */       this.noBufferedKeys -= 1;
/*      */ 
/* 2108 */       return keyLength;
/*      */     }
/*      */ 
/*      */     public synchronized Object next(Object key)
/*      */       throws IOException
/*      */     {
/* 2116 */       if ((key != null) && (key.getClass() != getKeyClass())) {
/* 2117 */         throw new IOException("wrong key class: " + key.getClass().getName() + " is not " + this.keyClass);
/*      */       }
/*      */ 
/* 2121 */       if (!this.blockCompressed) {
/* 2122 */         this.outBuf.reset();
/*      */ 
/* 2124 */         this.keyLength = next(this.outBuf);
/* 2125 */         if (this.keyLength < 0) {
/* 2126 */           return null;
/*      */         }
/* 2128 */         this.valBuffer.reset(this.outBuf.getData(), this.outBuf.getLength());
/*      */ 
/* 2130 */         key = deserializeKey(key);
/* 2131 */         this.valBuffer.mark(0);
/* 2132 */         if (this.valBuffer.getPosition() != this.keyLength)
/* 2133 */           throw new IOException(key + " read " + this.valBuffer.getPosition() + " bytes, should read " + this.keyLength);
/*      */       }
/*      */       else
/*      */       {
/* 2137 */         this.syncSeen = false;
/*      */ 
/* 2139 */         if (this.noBufferedKeys == 0) {
/*      */           try {
/* 2141 */             readBlock();
/*      */           } catch (EOFException eof) {
/* 2143 */             return null;
/*      */           }
/*      */         }
/*      */ 
/* 2147 */         int keyLength = WritableUtils.readVInt(this.keyLenIn);
/*      */ 
/* 2150 */         if (keyLength < 0) {
/* 2151 */           return null;
/*      */         }
/*      */ 
/* 2155 */         key = deserializeKey(key);
/* 2156 */         this.noBufferedKeys -= 1;
/*      */       }
/*      */ 
/* 2159 */       return key;
/*      */     }
/*      */ 
/*      */     private Object deserializeKey(Object key) throws IOException
/*      */     {
/* 2164 */       return this.keyDeserializer.deserialize(key);
/*      */     }
/*      */ 
/*      */     public synchronized int nextRawValue(SequenceFile.ValueBytes val)
/*      */       throws IOException
/*      */     {
/* 2177 */       seekToCurrentValue();
/*      */ 
/* 2179 */       if (!this.blockCompressed) {
/* 2180 */         int valLength = this.recordLength - this.keyLength;
/* 2181 */         if (this.decompress) {
/* 2182 */           SequenceFile.CompressedBytes value = (SequenceFile.CompressedBytes)val;
/* 2183 */           SequenceFile.CompressedBytes.access$400(value, this.in, valLength);
/*      */         } else {
/* 2185 */           SequenceFile.UncompressedBytes value = (SequenceFile.UncompressedBytes)val;
/* 2186 */           SequenceFile.UncompressedBytes.access$500(value, this.in, valLength);
/*      */         }
/*      */ 
/* 2189 */         return valLength;
/*      */       }
/* 2191 */       int valLength = WritableUtils.readVInt(this.valLenIn);
/* 2192 */       SequenceFile.UncompressedBytes rawValue = (SequenceFile.UncompressedBytes)val;
/* 2193 */       SequenceFile.UncompressedBytes.access$500(rawValue, this.valIn, valLength);
/* 2194 */       this.noBufferedValues -= 1;
/* 2195 */       return valLength;
/*      */     }
/*      */ 
/*      */     private void handleChecksumException(ChecksumException e)
/*      */       throws IOException
/*      */     {
/* 2202 */       if (this.conf.getBoolean("io.skip.checksum.errors", false)) {
/* 2203 */         SequenceFile.LOG.warn("Bad checksum at " + getPosition() + ". Skipping entries.");
/* 2204 */         sync(getPosition() + this.conf.getInt("io.bytes.per.checksum", 512));
/*      */       } else {
/* 2206 */         throw e;
/*      */       }
/*      */     }
/*      */ 
/*      */     public synchronized void seek(long position)
/*      */       throws IOException
/*      */     {
/* 2217 */       this.in.seek(position);
/* 2218 */       if (this.blockCompressed) {
/* 2219 */         this.noBufferedKeys = 0;
/* 2220 */         this.valuesDecompressed = true;
/*      */       }
/*      */     }
/*      */ 
/*      */     public synchronized void sync(long position) throws IOException
/*      */     {
/* 2226 */       if (position + 20L >= this.end) {
/* 2227 */         seek(this.end);
/* 2228 */         return;
/*      */       }
/*      */       try
/*      */       {
/* 2232 */         seek(position + 4L);
/* 2233 */         this.in.readFully(this.syncCheck);
/* 2234 */         int syncLen = this.sync.length;
/* 2235 */         for (int i = 0; this.in.getPos() < this.end; i++) {
/* 2236 */           int j = 0;
/* 2237 */           while ((j < syncLen) && 
/* 2238 */             (this.sync[j] == this.syncCheck[((i + j) % syncLen)])) {
/* 2237 */             j++;
/*      */           }
/*      */ 
/* 2241 */           if (j == syncLen) {
/* 2242 */             this.in.seek(this.in.getPos() - 20L);
/* 2243 */             return;
/*      */           }
/* 2245 */           this.syncCheck[(i % syncLen)] = this.in.readByte();
/*      */         }
/*      */       } catch (ChecksumException e) {
/* 2248 */         handleChecksumException(e);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean syncSeen() {
/* 2253 */       return this.syncSeen;
/*      */     }
/*      */ 
/*      */     public synchronized long getPosition() throws IOException {
/* 2257 */       return this.in.getPos();
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 2262 */       return this.file.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   static class BlockCompressWriter extends SequenceFile.Writer
/*      */   {
/* 1222 */     private int noBufferedRecords = 0;
/*      */ 
/* 1224 */     private DataOutputBuffer keyLenBuffer = new DataOutputBuffer();
/* 1225 */     private DataOutputBuffer keyBuffer = new DataOutputBuffer();
/*      */ 
/* 1227 */     private DataOutputBuffer valLenBuffer = new DataOutputBuffer();
/* 1228 */     private DataOutputBuffer valBuffer = new DataOutputBuffer();
/*      */     private int compressionBlockSize;
/*      */ 
/*      */     public BlockCompressWriter(FileSystem fs, Configuration conf, Path name, Class keyClass, Class valClass, CompressionCodec codec)
/*      */       throws IOException
/*      */     {
/* 1236 */       this(fs, conf, name, keyClass, valClass, fs.getConf().getInt("io.file.buffer.size", 4096), fs.getDefaultReplication(), fs.getDefaultBlockSize(), codec, null, new SequenceFile.Metadata());
/*      */     }
/*      */ 
/*      */     public BlockCompressWriter(FileSystem fs, Configuration conf, Path name, Class keyClass, Class valClass, CompressionCodec codec, Progressable progress, SequenceFile.Metadata metadata)
/*      */       throws IOException
/*      */     {
/* 1247 */       this(fs, conf, name, keyClass, valClass, fs.getConf().getInt("io.file.buffer.size", 4096), fs.getDefaultReplication(), fs.getDefaultBlockSize(), codec, progress, metadata);
/*      */     }
/*      */ 
/*      */     public BlockCompressWriter(FileSystem fs, Configuration conf, Path name, Class keyClass, Class valClass, int bufferSize, short replication, long blockSize, CompressionCodec codec, Progressable progress, SequenceFile.Metadata metadata)
/*      */       throws IOException
/*      */     {
/* 1260 */       super.init(name, conf, fs.create(name, true, bufferSize, replication, blockSize, progress), keyClass, valClass, true, codec, metadata);
/*      */ 
/* 1263 */       init(conf.getInt("io.seqfile.compress.blocksize", 1000000));
/*      */ 
/* 1265 */       initializeFileHeader();
/* 1266 */       writeFileHeader();
/* 1267 */       finalizeFileHeader();
/*      */     }
/*      */ 
/*      */     public BlockCompressWriter(FileSystem fs, Configuration conf, Path name, Class keyClass, Class valClass, CompressionCodec codec, Progressable progress)
/*      */       throws IOException
/*      */     {
/* 1275 */       this(fs, conf, name, keyClass, valClass, codec, progress, new SequenceFile.Metadata());
/*      */     }
/*      */ 
/*      */     BlockCompressWriter(Configuration conf, FSDataOutputStream out, Class keyClass, Class valClass, CompressionCodec codec, SequenceFile.Metadata metadata)
/*      */       throws IOException
/*      */     {
/* 1282 */       this.ownOutputStream = false;
/* 1283 */       super.init(null, conf, out, keyClass, valClass, true, codec, metadata);
/* 1284 */       init(conf.getInt("io.seqfile.compress.blocksize", 1000000));
/*      */ 
/* 1286 */       initializeFileHeader();
/* 1287 */       writeFileHeader();
/* 1288 */       finalizeFileHeader();
/*      */     }
/*      */     boolean isCompressed() {
/* 1291 */       return true; } 
/* 1292 */     boolean isBlockCompressed() { return true; }
/*      */ 
/*      */     void init(int compressionBlockSize) throws IOException
/*      */     {
/* 1296 */       this.compressionBlockSize = compressionBlockSize;
/* 1297 */       this.keySerializer.close();
/* 1298 */       this.keySerializer.open(this.keyBuffer);
/* 1299 */       this.uncompressedValSerializer.close();
/* 1300 */       this.uncompressedValSerializer.open(this.valBuffer);
/*      */     }
/*      */ 
/*      */     private synchronized void writeBuffer(DataOutputBuffer uncompressedDataBuffer)
/*      */       throws IOException
/*      */     {
/* 1307 */       this.deflateFilter.resetState();
/* 1308 */       this.buffer.reset();
/* 1309 */       this.deflateOut.write(uncompressedDataBuffer.getData(), 0, uncompressedDataBuffer.getLength());
/*      */ 
/* 1311 */       this.deflateOut.flush();
/* 1312 */       this.deflateFilter.finish();
/*      */ 
/* 1314 */       WritableUtils.writeVInt(this.out, this.buffer.getLength());
/* 1315 */       this.out.write(this.buffer.getData(), 0, this.buffer.getLength());
/*      */     }
/*      */ 
/*      */     public synchronized void sync() throws IOException
/*      */     {
/* 1320 */       if (this.noBufferedRecords > 0) {
/* 1321 */         super.sync();
/*      */ 
/* 1324 */         WritableUtils.writeVInt(this.out, this.noBufferedRecords);
/*      */ 
/* 1327 */         writeBuffer(this.keyLenBuffer);
/* 1328 */         writeBuffer(this.keyBuffer);
/*      */ 
/* 1331 */         writeBuffer(this.valLenBuffer);
/* 1332 */         writeBuffer(this.valBuffer);
/*      */ 
/* 1335 */         this.out.flush();
/*      */ 
/* 1338 */         this.keyLenBuffer.reset();
/* 1339 */         this.keyBuffer.reset();
/* 1340 */         this.valLenBuffer.reset();
/* 1341 */         this.valBuffer.reset();
/* 1342 */         this.noBufferedRecords = 0;
/*      */       }
/*      */     }
/*      */ 
/*      */     public synchronized void close()
/*      */       throws IOException
/*      */     {
/* 1349 */       if (this.out != null) {
/* 1350 */         sync();
/*      */       }
/* 1352 */       super.close();
/*      */     }
/*      */ 
/*      */     public synchronized void append(Object key, Object val)
/*      */       throws IOException
/*      */     {
/* 1359 */       if (key.getClass() != this.keyClass)
/* 1360 */         throw new IOException("wrong key class: " + key + " is not " + this.keyClass);
/* 1361 */       if (val.getClass() != this.valClass) {
/* 1362 */         throw new IOException("wrong value class: " + val + " is not " + this.valClass);
/*      */       }
/*      */ 
/* 1365 */       int oldKeyLength = this.keyBuffer.getLength();
/* 1366 */       this.keySerializer.serialize(key);
/* 1367 */       int keyLength = this.keyBuffer.getLength() - oldKeyLength;
/* 1368 */       if (keyLength < 0)
/* 1369 */         throw new IOException("negative length keys not allowed: " + key);
/* 1370 */       WritableUtils.writeVInt(this.keyLenBuffer, keyLength);
/*      */ 
/* 1372 */       int oldValLength = this.valBuffer.getLength();
/* 1373 */       this.uncompressedValSerializer.serialize(val);
/* 1374 */       int valLength = this.valBuffer.getLength() - oldValLength;
/* 1375 */       WritableUtils.writeVInt(this.valLenBuffer, valLength);
/*      */ 
/* 1378 */       this.noBufferedRecords += 1;
/*      */ 
/* 1381 */       int currentBlockSize = this.keyBuffer.getLength() + this.valBuffer.getLength();
/* 1382 */       if (currentBlockSize >= this.compressionBlockSize)
/* 1383 */         sync();
/*      */     }
/*      */ 
/*      */     public synchronized void appendRaw(byte[] keyData, int keyOffset, int keyLength, SequenceFile.ValueBytes val)
/*      */       throws IOException
/*      */     {
/* 1391 */       if (keyLength < 0) {
/* 1392 */         throw new IOException("negative length keys not allowed");
/*      */       }
/* 1394 */       int valLength = val.getSize();
/*      */ 
/* 1397 */       WritableUtils.writeVInt(this.keyLenBuffer, keyLength);
/* 1398 */       this.keyBuffer.write(keyData, keyOffset, keyLength);
/* 1399 */       WritableUtils.writeVInt(this.valLenBuffer, valLength);
/* 1400 */       val.writeUncompressedBytes(this.valBuffer);
/*      */ 
/* 1403 */       this.noBufferedRecords += 1;
/*      */ 
/* 1406 */       int currentBlockSize = this.keyBuffer.getLength() + this.valBuffer.getLength();
/* 1407 */       if (currentBlockSize >= this.compressionBlockSize)
/* 1408 */         sync();
/*      */     }
/*      */   }
/*      */ 
/*      */   static class RecordCompressWriter extends SequenceFile.Writer
/*      */   {
/*      */     public RecordCompressWriter(FileSystem fs, Configuration conf, Path name, Class keyClass, Class valClass, CompressionCodec codec)
/*      */       throws IOException
/*      */     {
/* 1115 */       this(conf, fs.create(name), keyClass, valClass, codec, new SequenceFile.Metadata());
/*      */     }
/*      */ 
/*      */     public RecordCompressWriter(FileSystem fs, Configuration conf, Path name, Class keyClass, Class valClass, CompressionCodec codec, Progressable progress, SequenceFile.Metadata metadata)
/*      */       throws IOException
/*      */     {
/* 1123 */       this(fs, conf, name, keyClass, valClass, fs.getConf().getInt("io.file.buffer.size", 4096), fs.getDefaultReplication(), fs.getDefaultBlockSize(), codec, progress, metadata);
/*      */     }
/*      */ 
/*      */     public RecordCompressWriter(FileSystem fs, Configuration conf, Path name, Class keyClass, Class valClass, int bufferSize, short replication, long blockSize, CompressionCodec codec, Progressable progress, SequenceFile.Metadata metadata)
/*      */       throws IOException
/*      */     {
/* 1136 */       super.init(name, conf, fs.create(name, true, bufferSize, replication, blockSize, progress), keyClass, valClass, true, codec, metadata);
/*      */ 
/* 1140 */       initializeFileHeader();
/* 1141 */       writeFileHeader();
/* 1142 */       finalizeFileHeader();
/*      */     }
/*      */ 
/*      */     public RecordCompressWriter(FileSystem fs, Configuration conf, Path name, Class keyClass, Class valClass, CompressionCodec codec, Progressable progress)
/*      */       throws IOException
/*      */     {
/* 1150 */       this(fs, conf, name, keyClass, valClass, codec, progress, new SequenceFile.Metadata());
/*      */     }
/*      */ 
/*      */     RecordCompressWriter(Configuration conf, FSDataOutputStream out, Class keyClass, Class valClass, CompressionCodec codec, SequenceFile.Metadata metadata)
/*      */       throws IOException
/*      */     {
/* 1157 */       this.ownOutputStream = false;
/* 1158 */       super.init(null, conf, out, keyClass, valClass, true, codec, metadata);
/*      */ 
/* 1160 */       initializeFileHeader();
/* 1161 */       writeFileHeader();
/* 1162 */       finalizeFileHeader();
/*      */     }
/*      */ 
/*      */     boolean isCompressed() {
/* 1166 */       return true; } 
/* 1167 */     boolean isBlockCompressed() { return false; }
/*      */ 
/*      */ 
/*      */     public synchronized void append(Object key, Object val)
/*      */       throws IOException
/*      */     {
/* 1173 */       if (key.getClass() != this.keyClass) {
/* 1174 */         throw new IOException("wrong key class: " + key.getClass().getName() + " is not " + this.keyClass);
/*      */       }
/* 1176 */       if (val.getClass() != this.valClass) {
/* 1177 */         throw new IOException("wrong value class: " + val.getClass().getName() + " is not " + this.valClass);
/*      */       }
/*      */ 
/* 1180 */       this.buffer.reset();
/*      */ 
/* 1183 */       this.keySerializer.serialize(key);
/* 1184 */       int keyLength = this.buffer.getLength();
/* 1185 */       if (keyLength < 0) {
/* 1186 */         throw new IOException("negative length keys not allowed: " + key);
/*      */       }
/*      */ 
/* 1189 */       this.deflateFilter.resetState();
/* 1190 */       this.compressedValSerializer.serialize(val);
/* 1191 */       this.deflateOut.flush();
/* 1192 */       this.deflateFilter.finish();
/*      */ 
/* 1195 */       checkAndWriteSync();
/* 1196 */       this.out.writeInt(this.buffer.getLength());
/* 1197 */       this.out.writeInt(keyLength);
/* 1198 */       this.out.write(this.buffer.getData(), 0, this.buffer.getLength());
/*      */     }
/*      */ 
/*      */     public synchronized void appendRaw(byte[] keyData, int keyOffset, int keyLength, SequenceFile.ValueBytes val)
/*      */       throws IOException
/*      */     {
/* 1205 */       if (keyLength < 0) {
/* 1206 */         throw new IOException("negative length keys not allowed: " + keyLength);
/*      */       }
/* 1208 */       int valLength = val.getSize();
/*      */ 
/* 1210 */       checkAndWriteSync();
/* 1211 */       this.out.writeInt(keyLength + valLength);
/* 1212 */       this.out.writeInt(keyLength);
/* 1213 */       this.out.write(keyData, keyOffset, keyLength);
/* 1214 */       val.writeCompressedBytes(this.out);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class Writer
/*      */     implements Closeable
/*      */   {
/*      */     Configuration conf;
/*      */     FSDataOutputStream out;
/*  835 */     boolean ownOutputStream = true;
/*  836 */     DataOutputBuffer buffer = new DataOutputBuffer();
/*      */     Class keyClass;
/*      */     Class valClass;
/*      */     private boolean compress;
/*  842 */     CompressionCodec codec = null;
/*  843 */     CompressionOutputStream deflateFilter = null;
/*  844 */     DataOutputStream deflateOut = null;
/*  845 */     SequenceFile.Metadata metadata = null;
/*  846 */     Compressor compressor = null;
/*      */     protected Serializer keySerializer;
/*      */     protected Serializer uncompressedValSerializer;
/*      */     protected Serializer compressedValSerializer;
/*      */     long lastSyncPos;
/*      */     byte[] sync;
/*      */ 
/*      */     Writer()
/*      */     {
/*      */       try
/*      */       {
/*  859 */         MessageDigest digester = MessageDigest.getInstance("MD5");
/*  860 */         long time = System.currentTimeMillis();
/*  861 */         digester.update((new UID() + "@" + time).getBytes());
/*  862 */         this.sync = digester.digest();
/*      */       } catch (Exception e) {
/*  864 */         throw new RuntimeException(e);
/*      */       }
/*      */     }
/*      */ 
/*      */     public Writer(FileSystem fs, Configuration conf, Path name, Class keyClass, Class valClass)
/*      */       throws IOException
/*      */     {
/*  876 */       this(fs, conf, name, keyClass, valClass, null, new SequenceFile.Metadata());
/*      */     }
/*      */ 
/*      */     public Writer(FileSystem fs, Configuration conf, Path name, Class keyClass, Class valClass, Progressable progress, SequenceFile.Metadata metadata)
/*      */       throws IOException
/*      */     {
/*  884 */       this(fs, conf, name, keyClass, valClass, fs.getConf().getInt("io.file.buffer.size", 4096), fs.getDefaultReplication(), fs.getDefaultBlockSize(), progress, metadata);
/*      */     }
/*      */ 
/*      */     public Writer(FileSystem fs, Configuration conf, Path name, Class keyClass, Class valClass, int bufferSize, short replication, long blockSize, Progressable progress, SequenceFile.Metadata metadata)
/*      */       throws IOException
/*      */     {
/*      */       try
/*      */       {
/*  859 */         MessageDigest digester = MessageDigest.getInstance("MD5");
/*  860 */         long time = System.currentTimeMillis();
/*  861 */         digester.update((new UID() + "@" + time).getBytes());
/*  862 */         this.sync = digester.digest();
/*      */       } catch (Exception e) {
/*  864 */         throw new RuntimeException(e);
/*      */       }
/*      */ 
/*  896 */       init(name, conf, fs.create(name, true, bufferSize, replication, blockSize, progress), keyClass, valClass, false, null, metadata);
/*      */ 
/*  899 */       initializeFileHeader();
/*  900 */       writeFileHeader();
/*  901 */       finalizeFileHeader();
/*      */     }
/*      */ 
/*      */     Writer(Configuration conf, FSDataOutputStream out, Class keyClass, Class valClass, SequenceFile.Metadata metadata)
/*      */       throws IOException
/*      */     {
/*      */       try
/*      */       {
/*  859 */         MessageDigest digester = MessageDigest.getInstance("MD5");
/*  860 */         long time = System.currentTimeMillis();
/*  861 */         digester.update((new UID() + "@" + time).getBytes());
/*  862 */         this.sync = digester.digest();
/*      */       } catch (Exception e) {
/*  864 */         throw new RuntimeException(e);
/*      */       }
/*      */ 
/*  908 */       this.ownOutputStream = false;
/*  909 */       init(null, conf, out, keyClass, valClass, false, null, metadata);
/*      */ 
/*  911 */       initializeFileHeader();
/*  912 */       writeFileHeader();
/*  913 */       finalizeFileHeader();
/*      */     }
/*      */ 
/*      */     void initializeFileHeader()
/*      */       throws IOException
/*      */     {
/*  919 */       this.out.write(SequenceFile.VERSION);
/*      */     }
/*      */ 
/*      */     void finalizeFileHeader()
/*      */       throws IOException
/*      */     {
/*  925 */       this.out.write(this.sync);
/*  926 */       this.out.flush();
/*      */     }
/*      */     boolean isCompressed() {
/*  929 */       return this.compress; } 
/*  930 */     boolean isBlockCompressed() { return false; } 
/*      */     Writer ownStream() {
/*  932 */       this.ownOutputStream = true; return this;
/*      */     }
/*      */ 
/*      */     void writeFileHeader() throws IOException
/*      */     {
/*  937 */       Text.writeString(this.out, this.keyClass.getName());
/*  938 */       Text.writeString(this.out, this.valClass.getName());
/*      */ 
/*  940 */       this.out.writeBoolean(isCompressed());
/*  941 */       this.out.writeBoolean(isBlockCompressed());
/*      */ 
/*  943 */       if (isCompressed()) {
/*  944 */         Text.writeString(this.out, this.codec.getClass().getName());
/*      */       }
/*  946 */       this.metadata.write(this.out);
/*      */     }
/*      */ 
/*      */     void init(Path name, Configuration conf, FSDataOutputStream out, Class keyClass, Class valClass, boolean compress, CompressionCodec codec, SequenceFile.Metadata metadata)
/*      */       throws IOException
/*      */     {
/*  955 */       this.conf = conf;
/*  956 */       this.out = out;
/*  957 */       this.keyClass = keyClass;
/*  958 */       this.valClass = valClass;
/*  959 */       this.compress = compress;
/*  960 */       this.codec = codec;
/*  961 */       this.metadata = metadata;
/*  962 */       SerializationFactory serializationFactory = new SerializationFactory(conf);
/*  963 */       this.keySerializer = serializationFactory.getSerializer(keyClass);
/*  964 */       this.keySerializer.open(this.buffer);
/*  965 */       this.uncompressedValSerializer = serializationFactory.getSerializer(valClass);
/*  966 */       this.uncompressedValSerializer.open(this.buffer);
/*  967 */       if (this.codec != null) {
/*  968 */         ReflectionUtils.setConf(this.codec, this.conf);
/*  969 */         this.compressor = CodecPool.getCompressor(this.codec);
/*  970 */         this.deflateFilter = this.codec.createOutputStream(this.buffer, this.compressor);
/*  971 */         this.deflateOut = new DataOutputStream(new BufferedOutputStream(this.deflateFilter));
/*      */ 
/*  973 */         this.compressedValSerializer = serializationFactory.getSerializer(valClass);
/*  974 */         this.compressedValSerializer.open(this.deflateOut);
/*      */       }
/*      */     }
/*      */ 
/*      */     public Class getKeyClass() {
/*  979 */       return this.keyClass;
/*      */     }
/*      */     public Class getValueClass() {
/*  982 */       return this.valClass;
/*      */     }
/*      */     public CompressionCodec getCompressionCodec() {
/*  985 */       return this.codec;
/*      */     }
/*      */ 
/*      */     public void sync() throws IOException {
/*  989 */       if ((this.sync != null) && (this.lastSyncPos != this.out.getPos())) {
/*  990 */         this.out.writeInt(-1);
/*  991 */         this.out.write(this.sync);
/*  992 */         this.lastSyncPos = this.out.getPos();
/*      */       }
/*      */     }
/*      */ 
/*      */     public void syncFs() throws IOException
/*      */     {
/*  998 */       if (this.out != null)
/*  999 */         this.out.sync();
/*      */     }
/*      */ 
/*      */     Configuration getConf()
/*      */     {
/* 1004 */       return this.conf;
/*      */     }
/*      */ 
/*      */     public synchronized void close() throws IOException {
/* 1008 */       this.keySerializer.close();
/* 1009 */       this.uncompressedValSerializer.close();
/* 1010 */       if (this.compressedValSerializer != null) {
/* 1011 */         this.compressedValSerializer.close();
/*      */       }
/*      */ 
/* 1014 */       CodecPool.returnCompressor(this.compressor);
/* 1015 */       this.compressor = null;
/*      */ 
/* 1017 */       if (this.out != null)
/*      */       {
/* 1020 */         if (this.ownOutputStream)
/* 1021 */           this.out.close();
/*      */         else {
/* 1023 */           this.out.flush();
/*      */         }
/* 1025 */         this.out = null;
/*      */       }
/*      */     }
/*      */ 
/*      */     synchronized void checkAndWriteSync() throws IOException {
/* 1030 */       if ((this.sync != null) && (this.out.getPos() >= this.lastSyncPos + 2000L))
/*      */       {
/* 1032 */         sync();
/*      */       }
/*      */     }
/*      */ 
/*      */     public synchronized void append(Writable key, Writable val)
/*      */       throws IOException
/*      */     {
/* 1039 */       append(key, val);
/*      */     }
/*      */ 
/*      */     public synchronized void append(Object key, Object val)
/*      */       throws IOException
/*      */     {
/* 1046 */       if (key.getClass() != this.keyClass) {
/* 1047 */         throw new IOException("wrong key class: " + key.getClass().getName() + " is not " + this.keyClass);
/*      */       }
/* 1049 */       if (val.getClass() != this.valClass) {
/* 1050 */         throw new IOException("wrong value class: " + val.getClass().getName() + " is not " + this.valClass);
/*      */       }
/*      */ 
/* 1053 */       this.buffer.reset();
/*      */ 
/* 1056 */       this.keySerializer.serialize(key);
/* 1057 */       int keyLength = this.buffer.getLength();
/* 1058 */       if (keyLength < 0) {
/* 1059 */         throw new IOException("negative length keys not allowed: " + key);
/*      */       }
/*      */ 
/* 1062 */       if (this.compress) {
/* 1063 */         this.deflateFilter.resetState();
/* 1064 */         this.compressedValSerializer.serialize(val);
/* 1065 */         this.deflateOut.flush();
/* 1066 */         this.deflateFilter.finish();
/*      */       } else {
/* 1068 */         this.uncompressedValSerializer.serialize(val);
/*      */       }
/*      */ 
/* 1072 */       checkAndWriteSync();
/* 1073 */       this.out.writeInt(this.buffer.getLength());
/* 1074 */       this.out.writeInt(keyLength);
/* 1075 */       this.out.write(this.buffer.getData(), 0, this.buffer.getLength());
/*      */     }
/*      */ 
/*      */     public synchronized void appendRaw(byte[] keyData, int keyOffset, int keyLength, SequenceFile.ValueBytes val) throws IOException
/*      */     {
/* 1080 */       if (keyLength < 0) {
/* 1081 */         throw new IOException("negative length keys not allowed: " + keyLength);
/*      */       }
/* 1083 */       int valLength = val.getSize();
/*      */ 
/* 1085 */       checkAndWriteSync();
/*      */ 
/* 1087 */       this.out.writeInt(keyLength + valLength);
/* 1088 */       this.out.writeInt(keyLength);
/* 1089 */       this.out.write(keyData, keyOffset, keyLength);
/* 1090 */       val.writeUncompressedBytes(this.out);
/*      */     }
/*      */ 
/*      */     public synchronized long getLength()
/*      */       throws IOException
/*      */     {
/* 1103 */       return this.out.getPos();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class Metadata
/*      */     implements Writable
/*      */   {
/*      */     private TreeMap<Text, Text> theMetadata;
/*      */ 
/*      */     public Metadata()
/*      */     {
/*  740 */       this(new TreeMap());
/*      */     }
/*      */ 
/*      */     public Metadata(TreeMap<Text, Text> arg) {
/*  744 */       if (arg == null)
/*  745 */         this.theMetadata = new TreeMap();
/*      */       else
/*  747 */         this.theMetadata = arg;
/*      */     }
/*      */ 
/*      */     public Text get(Text name)
/*      */     {
/*  752 */       return (Text)this.theMetadata.get(name);
/*      */     }
/*      */ 
/*      */     public void set(Text name, Text value) {
/*  756 */       this.theMetadata.put(name, value);
/*      */     }
/*      */ 
/*      */     public TreeMap<Text, Text> getMetadata() {
/*  760 */       return new TreeMap(this.theMetadata);
/*      */     }
/*      */ 
/*      */     public void write(DataOutput out) throws IOException {
/*  764 */       out.writeInt(this.theMetadata.size());
/*  765 */       Iterator iter = this.theMetadata.entrySet().iterator();
/*      */ 
/*  767 */       while (iter.hasNext()) {
/*  768 */         Map.Entry en = (Map.Entry)iter.next();
/*  769 */         ((Text)en.getKey()).write(out);
/*  770 */         ((Text)en.getValue()).write(out);
/*      */       }
/*      */     }
/*      */ 
/*      */     public void readFields(DataInput in) throws IOException {
/*  775 */       int sz = in.readInt();
/*  776 */       if (sz < 0) throw new IOException("Invalid size: " + sz + " for file metadata object");
/*  777 */       this.theMetadata = new TreeMap();
/*  778 */       for (int i = 0; i < sz; i++) {
/*  779 */         Text key = new Text();
/*  780 */         Text val = new Text();
/*  781 */         key.readFields(in);
/*  782 */         val.readFields(in);
/*  783 */         this.theMetadata.put(key, val);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean equals(Metadata other) {
/*  788 */       if (other == null) return false;
/*  789 */       if (this.theMetadata.size() != other.theMetadata.size()) {
/*  790 */         return false;
/*      */       }
/*  792 */       Iterator iter1 = this.theMetadata.entrySet().iterator();
/*      */ 
/*  794 */       Iterator iter2 = other.theMetadata.entrySet().iterator();
/*      */ 
/*  796 */       while ((iter1.hasNext()) && (iter2.hasNext())) {
/*  797 */         Map.Entry en1 = (Map.Entry)iter1.next();
/*  798 */         Map.Entry en2 = (Map.Entry)iter2.next();
/*  799 */         if (!((Text)en1.getKey()).equals(en2.getKey())) {
/*  800 */           return false;
/*      */         }
/*  802 */         if (!((Text)en1.getValue()).equals(en2.getValue())) {
/*  803 */           return false;
/*      */         }
/*      */       }
/*  806 */       if ((iter1.hasNext()) || (iter2.hasNext())) {
/*  807 */         return false;
/*      */       }
/*  809 */       return true;
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  813 */       if (!$assertionsDisabled) throw new AssertionError("hashCode not designed");
/*  814 */       return 42;
/*      */     }
/*      */ 
/*      */     public String toString() {
/*  818 */       StringBuffer sb = new StringBuffer();
/*  819 */       sb.append("size: ").append(this.theMetadata.size()).append("\n");
/*  820 */       Iterator iter = this.theMetadata.entrySet().iterator();
/*      */ 
/*  822 */       while (iter.hasNext()) {
/*  823 */         Map.Entry en = (Map.Entry)iter.next();
/*  824 */         sb.append("\t").append(((Text)en.getKey()).toString()).append("\t").append(((Text)en.getValue()).toString());
/*  825 */         sb.append("\n");
/*      */       }
/*  827 */       return sb.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class CompressedBytes
/*      */     implements SequenceFile.ValueBytes
/*      */   {
/*      */     private int dataSize;
/*      */     private byte[] data;
/*  683 */     DataInputBuffer rawData = null;
/*  684 */     CompressionCodec codec = null;
/*  685 */     CompressionInputStream decompressedStream = null;
/*      */ 
/*      */     private CompressedBytes(CompressionCodec codec) {
/*  688 */       this.data = null;
/*  689 */       this.dataSize = 0;
/*  690 */       this.codec = codec;
/*      */     }
/*      */ 
/*      */     private void reset(DataInputStream in, int length) throws IOException {
/*  694 */       this.data = new byte[length];
/*  695 */       this.dataSize = -1;
/*      */ 
/*  697 */       in.readFully(this.data);
/*  698 */       this.dataSize = this.data.length;
/*      */     }
/*      */ 
/*      */     public int getSize() {
/*  702 */       return this.dataSize;
/*      */     }
/*      */ 
/*      */     public void writeUncompressedBytes(DataOutputStream outStream) throws IOException
/*      */     {
/*  707 */       if (this.decompressedStream == null) {
/*  708 */         this.rawData = new DataInputBuffer();
/*  709 */         this.decompressedStream = this.codec.createInputStream(this.rawData);
/*      */       } else {
/*  711 */         this.decompressedStream.resetState();
/*      */       }
/*  713 */       this.rawData.reset(this.data, 0, this.dataSize);
/*      */ 
/*  715 */       byte[] buffer = new byte[8192];
/*  716 */       int bytesRead = 0;
/*  717 */       while ((bytesRead = this.decompressedStream.read(buffer, 0, 8192)) != -1)
/*  718 */         outStream.write(buffer, 0, bytesRead);
/*      */     }
/*      */ 
/*      */     public void writeCompressedBytes(DataOutputStream outStream)
/*      */       throws IllegalArgumentException, IOException
/*      */     {
/*  724 */       outStream.write(this.data, 0, this.dataSize);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class UncompressedBytes
/*      */     implements SequenceFile.ValueBytes
/*      */   {
/*      */     private int dataSize;
/*      */     private byte[] data;
/*      */ 
/*      */     private UncompressedBytes()
/*      */     {
/*  651 */       this.data = null;
/*  652 */       this.dataSize = 0;
/*      */     }
/*      */ 
/*      */     private void reset(DataInputStream in, int length) throws IOException {
/*  656 */       this.data = new byte[length];
/*  657 */       this.dataSize = -1;
/*      */ 
/*  659 */       in.readFully(this.data);
/*  660 */       this.dataSize = this.data.length;
/*      */     }
/*      */ 
/*      */     public int getSize() {
/*  664 */       return this.dataSize;
/*      */     }
/*      */ 
/*      */     public void writeUncompressedBytes(DataOutputStream outStream) throws IOException
/*      */     {
/*  669 */       outStream.write(this.data, 0, this.dataSize);
/*      */     }
/*      */ 
/*      */     public void writeCompressedBytes(DataOutputStream outStream) throws IllegalArgumentException, IOException
/*      */     {
/*  674 */       throw new IllegalArgumentException("UncompressedBytes cannot be compressed!");
/*      */     }
/*      */   }
/*      */ 
/*      */   public static abstract interface ValueBytes
/*      */   {
/*      */     public abstract void writeUncompressedBytes(DataOutputStream paramDataOutputStream)
/*      */       throws IOException;
/*      */ 
/*      */     public abstract void writeCompressedBytes(DataOutputStream paramDataOutputStream)
/*      */       throws IllegalArgumentException, IOException;
/*      */ 
/*      */     public abstract int getSize();
/*      */   }
/*      */ 
/*      */   public static enum CompressionType
/*      */   {
/*  213 */     NONE, 
/*      */ 
/*  215 */     RECORD, 
/*      */ 
/*  217 */     BLOCK;
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.SequenceFile
 * JD-Core Version:    0.6.1
 */
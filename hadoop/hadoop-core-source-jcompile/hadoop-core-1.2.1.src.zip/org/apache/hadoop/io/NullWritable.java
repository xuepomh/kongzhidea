/*    */ package org.apache.hadoop.io;
/*    */ 
/*    */ import java.io.DataInput;
/*    */ import java.io.DataOutput;
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class NullWritable
/*    */   implements WritableComparable
/*    */ {
/* 26 */   private static final NullWritable THIS = new NullWritable();
/*    */ 
/*    */   public static NullWritable get()
/*    */   {
/* 31 */     return THIS;
/*    */   }
/*    */   public String toString() {
/* 34 */     return "(null)";
/*    */   }
/*    */   public int hashCode() {
/* 37 */     return 0;
/*    */   }
/* 39 */   public int compareTo(Object other) { if (!(other instanceof NullWritable)) {
/* 40 */       throw new ClassCastException("can't compare " + other.getClass().getName() + " to NullWritable");
/*    */     }
/*    */ 
/* 43 */     return 0; } 
/*    */   public boolean equals(Object other) {
/* 45 */     return other instanceof NullWritable;
/*    */   }
/*    */ 
/*    */   public void readFields(DataInput in)
/*    */     throws IOException
/*    */   {
/*    */   }
/*    */ 
/*    */   public void write(DataOutput out)
/*    */     throws IOException
/*    */   {
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 67 */     WritableComparator.define(NullWritable.class, new Comparator());
/*    */   }
/*    */ 
/*    */   public static class Comparator extends WritableComparator
/*    */   {
/*    */     public Comparator()
/*    */     {
/* 52 */       super();
/*    */     }
/*    */ 
/*    */     public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2)
/*    */     {
/* 60 */       assert (0 == l1);
/* 61 */       assert (0 == l2);
/* 62 */       return 0;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.NullWritable
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.io;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.DataInputStream;
/*    */ 
/*    */ public class DataInputBuffer extends DataInputStream
/*    */ {
/*    */   private Buffer buffer;
/*    */ 
/*    */   public DataInputBuffer()
/*    */   {
/* 63 */     this(new Buffer());
/*    */   }
/*    */ 
/*    */   private DataInputBuffer(Buffer buffer) {
/* 67 */     super(buffer);
/* 68 */     this.buffer = buffer;
/*    */   }
/*    */ 
/*    */   public void reset(byte[] input, int length)
/*    */   {
/* 73 */     this.buffer.reset(input, 0, length);
/*    */   }
/*    */ 
/*    */   public void reset(byte[] input, int start, int length)
/*    */   {
/* 78 */     this.buffer.reset(input, start, length);
/*    */   }
/*    */ 
/*    */   public byte[] getData() {
/* 82 */     return this.buffer.getData();
/*    */   }
/*    */ 
/*    */   public int getPosition() {
/* 86 */     return this.buffer.getPosition();
/*    */   }
/*    */   public int getLength() {
/* 89 */     return this.buffer.getLength();
/*    */   }
/*    */ 
/*    */   private static class Buffer extends ByteArrayInputStream
/*    */   {
/*    */     public Buffer()
/*    */     {
/* 44 */       super();
/*    */     }
/*    */ 
/*    */     public void reset(byte[] input, int start, int length) {
/* 48 */       this.buf = input;
/* 49 */       this.count = (start + length);
/* 50 */       this.mark = start;
/* 51 */       this.pos = start;
/*    */     }
/*    */     public byte[] getData() {
/* 54 */       return this.buf; } 
/* 55 */     public int getPosition() { return this.pos; } 
/* 56 */     public int getLength() { return this.count; }
/*    */ 
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.DataInputBuffer
 * JD-Core Version:    0.6.1
 */
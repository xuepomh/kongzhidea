/*     */ package org.apache.hadoop.io;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.apache.hadoop.conf.Configurable;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ 
/*     */ public abstract class AbstractMapWritable
/*     */   implements Writable, Configurable
/*     */ {
/*     */   private AtomicReference<Configuration> conf;
/*  46 */   Map<Class, Byte> classToIdMap = new ConcurrentHashMap();
/*     */ 
/*  49 */   Map<Byte, Class> idToClassMap = new ConcurrentHashMap();
/*     */ 
/*  52 */   private volatile byte newClasses = 0;
/*     */ 
/*     */   byte getNewClasses()
/*     */   {
/*  56 */     return this.newClasses;
/*     */   }
/*     */ 
/*     */   private synchronized void addToMap(Class clazz, byte id)
/*     */   {
/*  63 */     if (this.classToIdMap.containsKey(clazz)) {
/*  64 */       byte b = ((Byte)this.classToIdMap.get(clazz)).byteValue();
/*  65 */       if (b != id) {
/*  66 */         throw new IllegalArgumentException("Class " + clazz.getName() + " already registered but maps to " + b + " and not " + id);
/*     */       }
/*     */     }
/*     */ 
/*  70 */     if (this.idToClassMap.containsKey(Byte.valueOf(id))) {
/*  71 */       Class c = (Class)this.idToClassMap.get(Byte.valueOf(id));
/*  72 */       if (!c.equals(clazz)) {
/*  73 */         throw new IllegalArgumentException("Id " + id + " exists but maps to " + c.getName() + " and not " + clazz.getName());
/*     */       }
/*     */     }
/*     */ 
/*  77 */     this.classToIdMap.put(clazz, Byte.valueOf(id));
/*  78 */     this.idToClassMap.put(Byte.valueOf(id), clazz);
/*     */   }
/*     */ 
/*     */   protected synchronized void addToMap(Class clazz)
/*     */   {
/*  83 */     if (this.classToIdMap.containsKey(clazz)) {
/*  84 */       return;
/*     */     }
/*  86 */     if (this.newClasses + 1 > 127) {
/*  87 */       throw new IndexOutOfBoundsException("adding an additional class would exceed the maximum number allowed");
/*     */     }
/*     */ 
/*  90 */     byte id = this.newClasses = (byte)(this.newClasses + 1);
/*  91 */     addToMap(clazz, id);
/*     */   }
/*     */ 
/*     */   protected Class getClass(byte id)
/*     */   {
/*  96 */     return (Class)this.idToClassMap.get(Byte.valueOf(id));
/*     */   }
/*     */ 
/*     */   protected byte getId(Class clazz)
/*     */   {
/* 101 */     return this.classToIdMap.containsKey(clazz) ? ((Byte)this.classToIdMap.get(clazz)).byteValue() : -1;
/*     */   }
/*     */ 
/*     */   protected synchronized void copy(Writable other)
/*     */   {
/* 106 */     if (other != null) {
/*     */       try {
/* 108 */         DataOutputBuffer out = new DataOutputBuffer();
/* 109 */         other.write(out);
/* 110 */         DataInputBuffer in = new DataInputBuffer();
/* 111 */         in.reset(out.getData(), out.getLength());
/* 112 */         readFields(in);
/*     */       }
/*     */       catch (IOException e) {
/* 115 */         throw new IllegalArgumentException("map cannot be copied: " + e.getMessage());
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 120 */       throw new IllegalArgumentException("source map cannot be null");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected AbstractMapWritable()
/*     */   {
/* 126 */     this.conf = new AtomicReference();
/*     */ 
/* 128 */     addToMap(ArrayWritable.class, Byte.valueOf(Integer.valueOf(-127).byteValue()).byteValue());
/*     */ 
/* 130 */     addToMap(BooleanWritable.class, Byte.valueOf(Integer.valueOf(-126).byteValue()).byteValue());
/*     */ 
/* 132 */     addToMap(BytesWritable.class, Byte.valueOf(Integer.valueOf(-125).byteValue()).byteValue());
/*     */ 
/* 134 */     addToMap(FloatWritable.class, Byte.valueOf(Integer.valueOf(-124).byteValue()).byteValue());
/*     */ 
/* 136 */     addToMap(IntWritable.class, Byte.valueOf(Integer.valueOf(-123).byteValue()).byteValue());
/*     */ 
/* 138 */     addToMap(LongWritable.class, Byte.valueOf(Integer.valueOf(-122).byteValue()).byteValue());
/*     */ 
/* 140 */     addToMap(MapWritable.class, Byte.valueOf(Integer.valueOf(-121).byteValue()).byteValue());
/*     */ 
/* 142 */     addToMap(MD5Hash.class, Byte.valueOf(Integer.valueOf(-120).byteValue()).byteValue());
/*     */ 
/* 144 */     addToMap(NullWritable.class, Byte.valueOf(Integer.valueOf(-119).byteValue()).byteValue());
/*     */ 
/* 146 */     addToMap(ObjectWritable.class, Byte.valueOf(Integer.valueOf(-118).byteValue()).byteValue());
/*     */ 
/* 148 */     addToMap(SortedMapWritable.class, Byte.valueOf(Integer.valueOf(-117).byteValue()).byteValue());
/*     */ 
/* 150 */     addToMap(Text.class, Byte.valueOf(Integer.valueOf(-116).byteValue()).byteValue());
/*     */ 
/* 152 */     addToMap(TwoDArrayWritable.class, Byte.valueOf(Integer.valueOf(-115).byteValue()).byteValue());
/*     */ 
/* 157 */     addToMap(VIntWritable.class, Byte.valueOf(Integer.valueOf(-114).byteValue()).byteValue());
/*     */ 
/* 159 */     addToMap(VLongWritable.class, Byte.valueOf(Integer.valueOf(-113).byteValue()).byteValue());
/*     */   }
/*     */ 
/*     */   public Configuration getConf()
/*     */   {
/* 166 */     return (Configuration)this.conf.get();
/*     */   }
/*     */ 
/*     */   public void setConf(Configuration conf)
/*     */   {
/* 171 */     this.conf.set(conf);
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/* 180 */     out.writeByte(this.newClasses);
/*     */ 
/* 182 */     for (byte i = 1; i <= this.newClasses; i = (byte)(i + 1)) {
/* 183 */       out.writeByte(i);
/* 184 */       out.writeUTF(getClass(i).getName());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in)
/*     */     throws IOException
/*     */   {
/* 193 */     this.newClasses = in.readByte();
/*     */ 
/* 197 */     for (int i = 0; i < this.newClasses; i++) {
/* 198 */       byte id = in.readByte();
/* 199 */       String className = in.readUTF();
/*     */       try {
/* 201 */         addToMap(Class.forName(className), id);
/*     */       }
/*     */       catch (ClassNotFoundException e) {
/* 204 */         throw new IOException("can't find class: " + className + " because " + e.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.io.AbstractMapWritable
 * JD-Core Version:    0.6.1
 */
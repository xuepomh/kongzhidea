/*     */ package org.apache.hadoop.filecache;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FileStatus;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ public class DistributedCache
/*     */ {
/*     */   public static final String CACHE_FILES_SIZES = "mapred.cache.files.filesizes";
/*     */   public static final String CACHE_ARCHIVES_SIZES = "mapred.cache.archives.filesizes";
/*     */   public static final String CACHE_ARCHIVES_TIMESTAMPS = "mapred.cache.archives.timestamps";
/*     */   public static final String CACHE_FILES_TIMESTAMPS = "mapred.cache.files.timestamps";
/*     */   public static final String CACHE_ARCHIVES = "mapred.cache.archives";
/*     */   public static final String CACHE_FILES = "mapred.cache.files";
/*     */   public static final String CACHE_LOCALARCHIVES = "mapred.cache.localArchives";
/*     */   public static final String CACHE_LOCALFILES = "mapred.cache.localFiles";
/*     */   public static final String CACHE_SYMLINK = "mapred.create.symlink";
/*     */ 
/*     */   public static FileStatus getFileStatus(Configuration conf, URI cache)
/*     */     throws IOException
/*     */   {
/* 184 */     FileSystem fileSystem = FileSystem.get(cache, conf);
/* 185 */     return fileSystem.getFileStatus(new Path(cache.getPath()));
/*     */   }
/*     */ 
/*     */   public static long getTimestamp(Configuration conf, URI cache)
/*     */     throws IOException
/*     */   {
/* 197 */     return getFileStatus(conf, cache).getModificationTime();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static void createAllSymlink(Configuration conf, File jobCacheDir, File workDir)
/*     */     throws IOException
/*     */   {
/* 211 */     TrackerDistributedCacheManager.createAllSymlink(conf, jobCacheDir, workDir);
/*     */   }
/*     */ 
/*     */   public static void setCacheArchives(URI[] archives, Configuration conf)
/*     */   {
/* 221 */     String sarchives = StringUtils.uriToString(archives);
/* 222 */     conf.set("mapred.cache.archives", sarchives);
/*     */   }
/*     */ 
/*     */   public static void setCacheFiles(URI[] files, Configuration conf)
/*     */   {
/* 232 */     String sfiles = StringUtils.uriToString(files);
/* 233 */     conf.set("mapred.cache.files", sfiles);
/*     */   }
/*     */ 
/*     */   private static Path[] parsePaths(String[] strs) {
/* 237 */     if (strs == null) {
/* 238 */       return null;
/*     */     }
/* 240 */     Path[] result = new Path[strs.length];
/* 241 */     for (int i = 0; i < strs.length; i++) {
/* 242 */       result[i] = new Path(strs[i]);
/*     */     }
/* 244 */     return result;
/*     */   }
/*     */ 
/*     */   public static URI[] getCacheArchives(Configuration conf)
/*     */     throws IOException
/*     */   {
/* 255 */     return StringUtils.stringToURI(conf.getStrings("mapred.cache.archives"));
/*     */   }
/*     */ 
/*     */   public static URI[] getCacheFiles(Configuration conf)
/*     */     throws IOException
/*     */   {
/* 266 */     return StringUtils.stringToURI(conf.getStrings("mapred.cache.files"));
/*     */   }
/*     */ 
/*     */   public static Path[] getLocalCacheArchives(Configuration conf)
/*     */     throws IOException
/*     */   {
/* 278 */     return StringUtils.stringToPath(conf.getStrings("mapred.cache.localArchives"));
/*     */   }
/*     */ 
/*     */   public static Path[] getLocalCacheFiles(Configuration conf)
/*     */     throws IOException
/*     */   {
/* 291 */     return StringUtils.stringToPath(conf.getStrings("mapred.cache.localFiles"));
/*     */   }
/*     */ 
/*     */   private static long[] parseTimestamps(String[] strs)
/*     */   {
/* 300 */     if (strs == null) {
/* 301 */       return null;
/*     */     }
/* 303 */     long[] result = new long[strs.length];
/* 304 */     for (int i = 0; i < strs.length; i++) {
/* 305 */       result[i] = Long.parseLong(strs[i]);
/*     */     }
/* 307 */     return result;
/*     */   }
/*     */ 
/*     */   public static long[] getArchiveTimestamps(Configuration conf)
/*     */   {
/* 318 */     return parseTimestamps(conf.getStrings("mapred.cache.archives.timestamps"));
/*     */   }
/*     */ 
/*     */   public static long[] getFileTimestamps(Configuration conf)
/*     */   {
/* 329 */     return parseTimestamps(conf.getStrings("mapred.cache.files.timestamps"));
/*     */   }
/*     */ 
/*     */   public static void setArchiveTimestamps(Configuration conf, String timestamps)
/*     */   {
/* 340 */     conf.set("mapred.cache.archives.timestamps", timestamps);
/*     */   }
/*     */ 
/*     */   public static void setFileTimestamps(Configuration conf, String timestamps)
/*     */   {
/* 351 */     conf.set("mapred.cache.files.timestamps", timestamps);
/*     */   }
/*     */ 
/*     */   public static void setLocalArchives(Configuration conf, String str)
/*     */   {
/* 361 */     conf.set("mapred.cache.localArchives", str);
/*     */   }
/*     */ 
/*     */   public static void setLocalFiles(Configuration conf, String str)
/*     */   {
/* 371 */     conf.set("mapred.cache.localFiles", str);
/*     */   }
/*     */ 
/*     */   public static void addLocalArchives(Configuration conf, String str)
/*     */   {
/* 381 */     String archives = conf.get("mapred.cache.localArchives");
/* 382 */     conf.set("mapred.cache.localArchives", archives + "," + str);
/*     */   }
/*     */ 
/*     */   public static void addLocalFiles(Configuration conf, String str)
/*     */   {
/* 393 */     String files = conf.get("mapred.cache.localFiles");
/* 394 */     conf.set("mapred.cache.localFiles", files + "," + str);
/*     */   }
/*     */ 
/*     */   public static void addCacheArchive(URI uri, Configuration conf)
/*     */   {
/* 405 */     String archives = conf.get("mapred.cache.archives");
/* 406 */     conf.set("mapred.cache.archives", archives + "," + uri.toString());
/*     */   }
/*     */ 
/*     */   public static void addCacheFile(URI uri, Configuration conf)
/*     */   {
/* 417 */     String files = conf.get("mapred.cache.files");
/* 418 */     conf.set("mapred.cache.files", files + "," + uri.toString());
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static void addFileToClassPath(Path file, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 438 */     addFileToClassPath(file, conf, file.getFileSystem(conf));
/*     */   }
/*     */ 
/*     */   public static void addFileToClassPath(Path file, Configuration conf, FileSystem fs)
/*     */     throws IOException
/*     */   {
/* 453 */     String filepath = file.toUri().getPath();
/* 454 */     String classpath = conf.get("mapred.job.classpath.files");
/* 455 */     conf.set("mapred.job.classpath.files", classpath + System.getProperty("path.separator") + filepath);
/*     */ 
/* 458 */     URI uri = fs.makeQualified(file).toUri();
/* 459 */     addCacheFile(uri, conf);
/*     */   }
/*     */ 
/*     */   public static Path[] getFileClassPaths(Configuration conf)
/*     */   {
/* 469 */     String classpath = conf.get("mapred.job.classpath.files");
/* 470 */     if (classpath == null)
/* 471 */       return null;
/* 472 */     ArrayList list = Collections.list(new StringTokenizer(classpath, System.getProperty("path.separator")));
/*     */ 
/* 474 */     Path[] paths = new Path[list.size()];
/* 475 */     for (int i = 0; i < list.size(); i++) {
/* 476 */       paths[i] = new Path((String)list.get(i));
/*     */     }
/* 478 */     return paths;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static void addArchiveToClassPath(Path archive, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 498 */     addArchiveToClassPath(archive, conf, archive.getFileSystem(conf));
/*     */   }
/*     */ 
/*     */   public static void addArchiveToClassPath(Path archive, Configuration conf, FileSystem fs)
/*     */     throws IOException
/*     */   {
/* 512 */     String archivepath = archive.toUri().getPath();
/* 513 */     String classpath = conf.get("mapred.job.classpath.archives");
/* 514 */     conf.set("mapred.job.classpath.archives", classpath + System.getProperty("path.separator") + archivepath);
/*     */ 
/* 517 */     URI uri = fs.makeQualified(archive).toUri();
/*     */ 
/* 519 */     addCacheArchive(uri, conf);
/*     */   }
/*     */ 
/*     */   public static Path[] getArchiveClassPaths(Configuration conf)
/*     */   {
/* 529 */     String classpath = conf.get("mapred.job.classpath.archives");
/* 530 */     if (classpath == null)
/* 531 */       return null;
/* 532 */     ArrayList list = Collections.list(new StringTokenizer(classpath, System.getProperty("path.separator")));
/*     */ 
/* 534 */     Path[] paths = new Path[list.size()];
/* 535 */     for (int i = 0; i < list.size(); i++) {
/* 536 */       paths[i] = new Path((String)list.get(i));
/*     */     }
/* 538 */     return paths;
/*     */   }
/*     */ 
/*     */   public static void createSymlink(Configuration conf)
/*     */   {
/* 548 */     conf.set("mapred.create.symlink", "yes");
/*     */   }
/*     */ 
/*     */   public static boolean getSymlink(Configuration conf)
/*     */   {
/* 559 */     String result = conf.get("mapred.create.symlink");
/* 560 */     if ("yes".equals(result)) {
/* 561 */       return true;
/*     */     }
/* 563 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean checkURIs(URI[] uriFiles, URI[] uriArchives)
/*     */   {
/* 575 */     if ((uriFiles == null) && (uriArchives == null)) {
/* 576 */       return true;
/*     */     }
/*     */ 
/* 580 */     Set fragments = new HashSet();
/*     */ 
/* 583 */     if (uriFiles != null) {
/* 584 */       for (int i = 0; i < uriFiles.length; i++) {
/* 585 */         String fragment = uriFiles[i].getFragment();
/* 586 */         if (fragment == null) {
/* 587 */           return false;
/*     */         }
/* 589 */         String lowerCaseFragment = fragment.toLowerCase();
/* 590 */         if (fragments.contains(lowerCaseFragment)) {
/* 591 */           return false;
/*     */         }
/* 593 */         fragments.add(lowerCaseFragment);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 598 */     if (uriArchives != null) {
/* 599 */       for (int i = 0; i < uriArchives.length; i++) {
/* 600 */         String fragment = uriArchives[i].getFragment();
/* 601 */         if (fragment == null) {
/* 602 */           return false;
/*     */         }
/* 604 */         String lowerCaseFragment = fragment.toLowerCase();
/* 605 */         if (fragments.contains(lowerCaseFragment)) {
/* 606 */           return false;
/*     */         }
/* 608 */         fragments.add(lowerCaseFragment);
/*     */       }
/*     */     }
/* 611 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.filecache.DistributedCache
 * JD-Core Version:    0.6.1
 */
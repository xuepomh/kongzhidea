/*     */ package org.apache.hadoop.filecache;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FileStatus;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ 
/*     */ public class TaskDistributedCacheManager
/*     */ {
/*     */   private final TrackerDistributedCacheManager distributedCacheManager;
/*  49 */   private final List<CacheFile> cacheFiles = new ArrayList();
/*  50 */   private final List<String> classPaths = new ArrayList();
/*     */ 
/*  52 */   private boolean setupCalled = false;
/*     */ 
/*     */   TaskDistributedCacheManager(TrackerDistributedCacheManager distributedCacheManager, Configuration taskConf)
/*     */     throws IOException
/*     */   {
/* 144 */     this.distributedCacheManager = distributedCacheManager;
/*     */ 
/* 146 */     this.cacheFiles.addAll(CacheFile.makeCacheFiles(DistributedCache.getCacheFiles(taskConf), DistributedCache.getFileTimestamps(taskConf), TrackerDistributedCacheManager.getFileVisibilities(taskConf), DistributedCache.getFileClassPaths(taskConf), TaskDistributedCacheManager.CacheFile.FileType.REGULAR));
/*     */ 
/* 152 */     this.cacheFiles.addAll(CacheFile.makeCacheFiles(DistributedCache.getCacheArchives(taskConf), DistributedCache.getArchiveTimestamps(taskConf), TrackerDistributedCacheManager.getArchiveVisibilities(taskConf), DistributedCache.getArchiveClassPaths(taskConf), TaskDistributedCacheManager.CacheFile.FileType.ARCHIVE));
/*     */   }
/*     */ 
/*     */   public void setupCache(Configuration taskConf, String publicCacheSubdir, String privateCacheSubdir)
/*     */     throws IOException
/*     */   {
/* 172 */     this.setupCalled = true;
/* 173 */     ArrayList localArchives = new ArrayList();
/* 174 */     ArrayList localFiles = new ArrayList();
/*     */ 
/* 176 */     for (CacheFile cacheFile : this.cacheFiles) {
/* 177 */       URI uri = cacheFile.uri;
/* 178 */       FileSystem fileSystem = FileSystem.get(uri, taskConf);
/* 179 */       FileStatus fileStatus = fileSystem.getFileStatus(new Path(uri.getPath()));
/*     */       Path p;
/*     */       Path p;
/* 181 */       if (cacheFile.isPublic) {
/* 182 */         p = this.distributedCacheManager.getLocalCache(uri, taskConf, publicCacheSubdir, fileStatus, cacheFile.type == TaskDistributedCacheManager.CacheFile.FileType.ARCHIVE, cacheFile.timestamp, cacheFile.isPublic, cacheFile);
/*     */       }
/*     */       else
/*     */       {
/* 187 */         p = this.distributedCacheManager.getLocalCache(uri, taskConf, privateCacheSubdir, fileStatus, cacheFile.type == TaskDistributedCacheManager.CacheFile.FileType.ARCHIVE, cacheFile.timestamp, cacheFile.isPublic, cacheFile);
/*     */       }
/*     */ 
/* 192 */       cacheFile.setLocalized(true);
/*     */ 
/* 194 */       if (cacheFile.type == TaskDistributedCacheManager.CacheFile.FileType.ARCHIVE)
/* 195 */         localArchives.add(p);
/*     */       else {
/* 197 */         localFiles.add(p);
/*     */       }
/* 199 */       if (cacheFile.shouldBeAddedToClassPath) {
/* 200 */         this.classPaths.add(p.toString());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 205 */     if (!localArchives.isEmpty()) {
/* 206 */       DistributedCache.addLocalArchives(taskConf, stringifyPathList(localArchives));
/*     */     }
/*     */ 
/* 209 */     if (!localFiles.isEmpty())
/* 210 */       DistributedCache.addLocalFiles(taskConf, stringifyPathList(localFiles));
/*     */   }
/*     */ 
/*     */   List<CacheFile> getCacheFiles()
/*     */   {
/* 219 */     return this.cacheFiles;
/*     */   }
/*     */ 
/*     */   private static String stringifyPathList(List<Path> p) {
/* 223 */     if ((p == null) || (p.isEmpty())) {
/* 224 */       return null;
/*     */     }
/* 226 */     StringBuilder str = new StringBuilder(((Path)p.get(0)).toString());
/* 227 */     for (int i = 1; i < p.size(); i++) {
/* 228 */       str.append(",");
/* 229 */       str.append(((Path)p.get(i)).toString());
/*     */     }
/* 231 */     return str.toString();
/*     */   }
/*     */ 
/*     */   public List<String> getClassPaths()
/*     */     throws IOException
/*     */   {
/* 240 */     if (!this.setupCalled) {
/* 241 */       throw new IllegalStateException("getClassPaths() should be called after setup()");
/*     */     }
/*     */ 
/* 244 */     return this.classPaths;
/*     */   }
/*     */ 
/*     */   public void release()
/*     */     throws IOException
/*     */   {
/* 252 */     for (CacheFile c : this.cacheFiles)
/* 253 */       if ((c.getLocalized()) && (c.status != null))
/* 254 */         this.distributedCacheManager.releaseCache(c.status);
/*     */   }
/*     */ 
/*     */   public void setSizes(long[] sizes)
/*     */     throws IOException
/*     */   {
/* 260 */     int i = 0;
/* 261 */     for (CacheFile c : this.cacheFiles) {
/* 262 */       if ((!c.isPublic) && (c.status != null)) {
/* 263 */         this.distributedCacheManager.setSize(c.status, sizes[i]);
/*     */       }
/* 265 */       i++;
/*     */     }
/*     */   }
/*     */ 
/*     */   public ClassLoader makeClassLoader(final ClassLoader parent)
/*     */     throws MalformedURLException
/*     */   {
/* 275 */     final URL[] urls = new URL[this.classPaths.size()];
/* 276 */     for (int i = 0; i < this.classPaths.size(); i++) {
/* 277 */       urls[i] = new File((String)this.classPaths.get(i)).toURI().toURL();
/*     */     }
/* 279 */     return (ClassLoader)AccessController.doPrivileged(new PrivilegedAction()
/*     */     {
/*     */       public ClassLoader run() {
/* 282 */         return new URLClassLoader(urls, parent);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   static class CacheFile
/*     */   {
/*     */     final URI uri;
/*  66 */     boolean isPublic = true;
/*     */     final FileType type;
/*     */     final long timestamp;
/*     */     final boolean shouldBeAddedToClassPath;
/*  72 */     boolean localized = false;
/*     */     final String owner;
/*     */     private TrackerDistributedCacheManager.CacheStatus status;
/*     */ 
/*     */     CacheFile(URI uri, FileType type, boolean isPublic, long timestamp, boolean classPath)
/*     */       throws IOException
/*     */     {
/*  79 */       this.uri = uri;
/*  80 */       this.type = type;
/*  81 */       this.isPublic = isPublic;
/*  82 */       this.timestamp = timestamp;
/*  83 */       this.shouldBeAddedToClassPath = classPath;
/*  84 */       this.owner = TrackerDistributedCacheManager.getLocalizedCacheOwner(isPublic);
/*     */     }
/*     */ 
/*     */     public void setStatus(TrackerDistributedCacheManager.CacheStatus status)
/*     */     {
/*  93 */       this.status = status;
/*     */     }
/*     */ 
/*     */     public TrackerDistributedCacheManager.CacheStatus getStatus()
/*     */     {
/* 101 */       return this.status;
/*     */     }
/*     */ 
/*     */     private static List<CacheFile> makeCacheFiles(URI[] uris, long[] timestamps, boolean[] cacheVisibilities, Path[] paths, FileType type)
/*     */       throws IOException
/*     */     {
/* 111 */       List ret = new ArrayList();
/* 112 */       if (uris != null) {
/* 113 */         if (uris.length != timestamps.length) {
/* 114 */           throw new IllegalArgumentException("Mismatched uris and timestamps.");
/*     */         }
/* 116 */         Map classPaths = new HashMap();
/* 117 */         if (paths != null) {
/* 118 */           for (Path p : paths) {
/* 119 */             classPaths.put(p.toUri().getPath().toString(), p);
/*     */           }
/*     */         }
/* 122 */         for (int i = 0; i < uris.length; i++) {
/* 123 */           URI u = uris[i];
/* 124 */           boolean isClassPath = null != classPaths.get(u.getPath());
/* 125 */           ret.add(new CacheFile(u, type, cacheVisibilities[i], timestamps[i], isClassPath));
/*     */         }
/*     */       }
/*     */ 
/* 129 */       return ret;
/*     */     }
/*     */ 
/*     */     boolean getLocalized() {
/* 133 */       return this.localized;
/*     */     }
/*     */ 
/*     */     void setLocalized(boolean val) {
/* 137 */       this.localized = val;
/*     */     }
/*     */ 
/*     */     static enum FileType
/*     */     {
/*  63 */       REGULAR, 
/*  64 */       ARCHIVE;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.filecache.TaskDistributedCacheManager
 * JD-Core Version:    0.6.1
 */
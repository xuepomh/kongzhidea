/*      */ package org.apache.hadoop.filecache;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.text.DateFormat;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.concurrent.locks.ReentrantLock;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.apache.hadoop.conf.Configuration;
/*      */ import org.apache.hadoop.fs.FileStatus;
/*      */ import org.apache.hadoop.fs.FileSystem;
/*      */ import org.apache.hadoop.fs.FileUtil;
/*      */ import org.apache.hadoop.fs.LocalDirAllocator;
/*      */ import org.apache.hadoop.fs.LocalFileSystem;
/*      */ import org.apache.hadoop.fs.Path;
/*      */ import org.apache.hadoop.fs.permission.FsAction;
/*      */ import org.apache.hadoop.fs.permission.FsPermission;
/*      */ import org.apache.hadoop.mapred.InvalidJobConfException;
/*      */ import org.apache.hadoop.mapred.TaskController;
/*      */ import org.apache.hadoop.mapred.TaskTracker;
/*      */ import org.apache.hadoop.mapreduce.JobID;
/*      */ import org.apache.hadoop.mapreduce.security.TokenCache;
/*      */ import org.apache.hadoop.security.Credentials;
/*      */ import org.apache.hadoop.security.UserGroupInformation;
/*      */ import org.apache.hadoop.util.RunJar;
/*      */ 
/*      */ public class TrackerDistributedCacheManager
/*      */ {
/*   73 */   private LinkedHashMap<String, CacheStatus> cachedArchives = new LinkedHashMap();
/*      */ 
/*   75 */   private Map<JobID, TaskDistributedCacheManager> jobArchives = Collections.synchronizedMap(new HashMap());
/*      */   private final TaskController taskController;
/*   79 */   private static final FsPermission PUBLIC_CACHE_OBJECT_PERM = FsPermission.createImmutable((short)493);
/*      */   private static final long DEFAULT_CACHE_SIZE = 10737418240L;
/*      */   private static final long DEFAULT_CACHE_SUBDIR_LIMIT = 10000L;
/*      */   private static final float DEFAULT_CACHE_KEEP_AROUND_PCT = 0.95F;
/*      */   private long allowedCacheSize;
/*      */   private long allowedCacheSubdirs;
/*      */   private long allowedCacheSizeCleanupGoal;
/*      */   private long allowedCacheSubdirsCleanupGoal;
/*   91 */   private static final Log LOG = LogFactory.getLog(TrackerDistributedCacheManager.class);
/*      */   private final LocalFileSystem localFs;
/*      */   private LocalDirAllocator lDirAllocator;
/*      */   private Configuration trackerConf;
/*  100 */   private static final Random random = new Random();
/*      */ 
/*  102 */   protected BaseDirManager baseDirManager = new BaseDirManager();
/*      */   protected CleanupThread cleanupThread;
/*      */ 
/*      */   public TrackerDistributedCacheManager(Configuration conf, TaskController controller)
/*      */     throws IOException
/*      */   {
/*  108 */     this.localFs = FileSystem.getLocal(conf);
/*  109 */     this.trackerConf = conf;
/*  110 */     this.lDirAllocator = new LocalDirAllocator("mapred.local.dir");
/*      */ 
/*  113 */     this.allowedCacheSize = conf.getLong("local.cache.size", 10737418240L);
/*      */ 
/*  116 */     this.allowedCacheSubdirs = conf.getLong("mapreduce.tasktracker.local.cache.numberdirectories", 10000L);
/*      */ 
/*  119 */     double cleanupPct = conf.getFloat("mapreduce.tasktracker.cache.local.keep.pct", 0.95F);
/*      */ 
/*  121 */     this.allowedCacheSizeCleanupGoal = ()(this.allowedCacheSize * cleanupPct);
/*      */ 
/*  123 */     this.allowedCacheSubdirsCleanupGoal = ()(this.allowedCacheSubdirs * cleanupPct);
/*      */ 
/*  126 */     this.taskController = controller;
/*  127 */     this.cleanupThread = new CleanupThread(conf);
/*      */   }
/*      */ 
/*      */   Path getLocalCache(URI cache, Configuration conf, String subDir, FileStatus fileStatus, boolean isArchive, long confFileStamp, boolean isPublic, TaskDistributedCacheManager.CacheFile file)
/*      */     throws IOException
/*      */   {
/*  158 */     String user = getLocalizedCacheOwner(isPublic);
/*  159 */     String key = getKey(cache, conf, confFileStamp, user, isArchive);
/*      */ 
/*  161 */     Path localizedPath = null;
/*  162 */     Path localPath = null;
/*      */     CacheStatus lcacheStatus;
/*  163 */     synchronized (this.cachedArchives) {
/*  164 */       lcacheStatus = (CacheStatus)this.cachedArchives.get(key);
/*  165 */       if (lcacheStatus == null)
/*      */       {
/*  167 */         String uniqueString = new StringBuilder().append(String.valueOf(random.nextLong())).append("_").append(cache.hashCode()).append("_").append(confFileStamp % 2147483647L).toString();
/*      */ 
/*  171 */         String cachePath = new Path(subDir, new Path(uniqueString, makeRelative(cache, conf))).toString();
/*      */ 
/*  173 */         localPath = this.lDirAllocator.getLocalPathForWrite(cachePath, fileStatus.getLen(), this.trackerConf, isPublic);
/*      */ 
/*  175 */         lcacheStatus = new CacheStatus(new Path(localPath.toString().replace(cachePath, "")), localPath, new Path(subDir), uniqueString, isPublic ? null : user, key);
/*      */ 
/*  179 */         this.cachedArchives.put(key, lcacheStatus);
/*      */       }
/*      */ 
/*  183 */       file.setStatus(lcacheStatus);
/*  184 */       lcacheStatus.incRefCount();
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  189 */       synchronized (lcacheStatus) {
/*  190 */         if (!lcacheStatus.isInited()) {
/*  191 */           if (isPublic) {
/*  192 */             localizedPath = localizePublicCacheObject(conf, cache, confFileStamp, lcacheStatus, fileStatus, isArchive);
/*      */           }
/*      */           else
/*      */           {
/*  198 */             localizedPath = localPath;
/*  199 */             if (!isArchive)
/*      */             {
/*  203 */               lcacheStatus.size = fileStatus.getLen();
/*      */ 
/*  207 */               this.baseDirManager.addCacheInfoUpdate(lcacheStatus);
/*      */             }
/*      */           }
/*  210 */           lcacheStatus.initComplete();
/*      */         } else {
/*  212 */           localizedPath = checkCacheStatusValidity(conf, cache, confFileStamp, lcacheStatus, fileStatus, isArchive);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (IOException ie) {
/*  217 */       lcacheStatus.decRefCount();
/*  218 */       throw ie;
/*      */     }
/*  220 */     return localizedPath;
/*      */   }
/*      */ 
/*      */   void releaseCache(CacheStatus status)
/*      */     throws IOException
/*      */   {
/*  234 */     status.decRefCount();
/*      */   }
/*      */ 
/*      */   void setSize(CacheStatus status, long size) throws IOException {
/*  238 */     if (size != 0L)
/*  239 */       synchronized (status) {
/*  240 */         status.size = size;
/*  241 */         this.baseDirManager.addCacheInfoUpdate(status);
/*      */       }
/*      */   }
/*      */ 
/*      */   int getReferenceCount(CacheStatus status)
/*      */     throws IOException
/*      */   {
/*  250 */     return status.getRefCount();
/*      */   }
/*      */ 
/*      */   static String getLocalizedCacheOwner(boolean isPublic)
/*      */     throws IOException
/*      */   {
/*      */     String user;
/*      */     String user;
/*  263 */     if (isPublic)
/*  264 */       user = UserGroupInformation.getLoginUser().getShortUserName();
/*      */     else {
/*  266 */       user = UserGroupInformation.getCurrentUser().getShortUserName();
/*      */     }
/*  268 */     return user;
/*      */   }
/*      */ 
/*      */   String makeRelative(URI cache, Configuration conf)
/*      */     throws IOException
/*      */   {
/*  281 */     String host = cache.getHost();
/*  282 */     if (host == null) {
/*  283 */       host = cache.getScheme();
/*      */     }
/*  285 */     if (host == null) {
/*  286 */       URI defaultUri = FileSystem.get(conf).getUri();
/*  287 */       host = defaultUri.getHost();
/*  288 */       if (host == null) {
/*  289 */         host = defaultUri.getScheme();
/*      */       }
/*      */     }
/*  292 */     String path = new StringBuilder().append(host).append(cache.getPath()).toString();
/*  293 */     path = path.replace(":/", "/");
/*  294 */     return path;
/*      */   }
/*      */ 
/*      */   private Path checkCacheStatusValidity(Configuration conf, URI cache, long confFileStamp, CacheStatus cacheStatus, FileStatus fileStatus, boolean isArchive)
/*      */     throws IOException
/*      */   {
/*  303 */     FileSystem fs = FileSystem.get(cache, conf);
/*      */ 
/*  305 */     if (!ifExistsAndFresh(conf, fs, cache, confFileStamp, cacheStatus, fileStatus))
/*      */     {
/*  307 */       throw new IOException(new StringBuilder().append("Stale cache file: ").append(cacheStatus.localizedLoadPath).append(" for cache-file: ").append(cache).toString());
/*      */     }
/*      */ 
/*  310 */     LOG.info(String.format("Using existing cache of %s->%s", new Object[] { cache.toString(), cacheStatus.localizedLoadPath }));
/*      */ 
/*  312 */     return cacheStatus.localizedLoadPath;
/*      */   }
/*      */ 
/*      */   static boolean isPublic(Configuration conf, URI uri, Map<URI, FileStatus> statCache)
/*      */     throws IOException
/*      */   {
/*  325 */     FileSystem fs = FileSystem.get(uri, conf);
/*  326 */     Path current = new Path(uri.getPath());
/*      */ 
/*  328 */     if (!checkPermissionOfOther(fs, current, FsAction.READ, statCache)) {
/*  329 */       return false;
/*      */     }
/*  331 */     return ancestorsHaveExecutePermissions(fs, current.getParent(), statCache);
/*      */   }
/*      */ 
/*      */   static boolean ancestorsHaveExecutePermissions(FileSystem fs, Path path, Map<URI, FileStatus> statCache)
/*      */     throws IOException
/*      */   {
/*  341 */     Path current = path;
/*  342 */     while (current != null)
/*      */     {
/*  344 */       if (!checkPermissionOfOther(fs, current, FsAction.EXECUTE, statCache)) {
/*  345 */         return false;
/*      */       }
/*  347 */       current = current.getParent();
/*      */     }
/*  349 */     return true;
/*      */   }
/*      */ 
/*      */   private static boolean checkPermissionOfOther(FileSystem fs, Path path, FsAction action, Map<URI, FileStatus> statCache)
/*      */     throws IOException
/*      */   {
/*  363 */     FileStatus status = getFileStatus(fs, path, statCache);
/*  364 */     FsPermission perms = status.getPermission();
/*  365 */     FsAction otherAction = perms.getOtherAction();
/*  366 */     if (otherAction.implies(action)) {
/*  367 */       return true;
/*      */     }
/*  369 */     return false;
/*      */   }
/*      */ 
/*      */   private static Path createRandomPath(Path base) throws IOException {
/*  373 */     return new Path(new StringBuilder().append(base.toString()).append("-work-").append(random.nextLong()).toString());
/*      */   }
/*      */ 
/*      */   public static long downloadCacheObject(Configuration conf, URI source, Path destination, long desiredTimestamp, boolean isArchive, FsPermission permission)
/*      */     throws IOException
/*      */   {
/*  394 */     FileSystem sourceFs = FileSystem.get(source, conf);
/*  395 */     FileSystem localFs = FileSystem.getLocal(conf);
/*      */ 
/*  397 */     Path sourcePath = new Path(source.getPath());
/*  398 */     long modifiedTime = sourceFs.getFileStatus(sourcePath).getModificationTime();
/*      */ 
/*  400 */     if (modifiedTime != desiredTimestamp) {
/*  401 */       DateFormat df = DateFormat.getDateTimeInstance(3, 3);
/*      */ 
/*  403 */       throw new IOException(new StringBuilder().append("The distributed cache object ").append(source).append(" changed during the job from ").append(df.format(new Date(desiredTimestamp))).append(" to ").append(df.format(new Date(modifiedTime))).toString());
/*      */     }
/*      */ 
/*  409 */     Path parchive = null;
/*  410 */     if (isArchive)
/*  411 */       parchive = new Path(destination, destination.getName());
/*      */     else {
/*  413 */       parchive = destination;
/*      */     }
/*      */ 
/*  416 */     if (localFs.exists(parchive)) {
/*  417 */       return 0L;
/*      */     }
/*      */ 
/*  420 */     Path finalDir = parchive.getParent();
/*      */ 
/*  422 */     Path workDir = createRandomPath(finalDir);
/*  423 */     LOG.info(new StringBuilder().append("Creating ").append(destination.getName()).append(" in ").append(workDir).append(" with ").append(permission).toString());
/*      */ 
/*  425 */     if (!localFs.mkdirs(workDir, permission)) {
/*  426 */       throw new IOException(new StringBuilder().append("Mkdirs failed to create directory ").append(workDir).toString());
/*      */     }
/*  428 */     Path workFile = new Path(workDir, parchive.getName());
/*  429 */     sourceFs.copyToLocalFile(sourcePath, workFile);
/*  430 */     localFs.setPermission(workFile, permission);
/*  431 */     if (isArchive) {
/*  432 */       String tmpArchive = workFile.getName().toLowerCase();
/*  433 */       File srcFile = new File(workFile.toString());
/*  434 */       File destDir = new File(workDir.toString());
/*  435 */       LOG.info(String.format("Extracting %s to %s", new Object[] { srcFile.toString(), destDir.toString() }));
/*      */ 
/*  437 */       if (tmpArchive.endsWith(".jar"))
/*  438 */         RunJar.unJar(srcFile, destDir);
/*  439 */       else if (tmpArchive.endsWith(".zip"))
/*  440 */         FileUtil.unZip(srcFile, destDir);
/*  441 */       else if (isTarFile(tmpArchive))
/*  442 */         FileUtil.unTar(srcFile, destDir);
/*      */       else {
/*  444 */         LOG.warn(String.format("Cache file %s specified as archive, but not valid extension.", new Object[] { srcFile.toString() }));
/*      */       }
/*      */ 
/*  450 */       FileUtil.chmod(destDir.toString(), "ugo+rx", true);
/*      */     }
/*      */ 
/*  453 */     if (!localFs.rename(workDir, finalDir)) {
/*  454 */       localFs.delete(workDir, true);
/*  455 */       if (!localFs.exists(finalDir)) {
/*  456 */         throw new IOException(new StringBuilder().append("Failed to promote distributed cache object ").append(workDir).append(" to ").append(finalDir).toString());
/*      */       }
/*      */ 
/*  460 */       return 0L;
/*      */     }
/*      */ 
/*  463 */     LOG.info(String.format("Cached %s as %s", new Object[] { source.toString(), destination.toString() }));
/*      */ 
/*  465 */     long cacheSize = FileUtil.getDU(new File(parchive.getParent().toString()));
/*      */ 
/*  467 */     return cacheSize;
/*      */   }
/*      */ 
/*      */   Path localizePublicCacheObject(Configuration conf, URI cache, long confFileStamp, CacheStatus cacheStatus, FileStatus fileStatus, boolean isArchive)
/*      */     throws IOException
/*      */   {
/*  477 */     long size = downloadCacheObject(conf, cache, cacheStatus.localizedLoadPath, confFileStamp, isArchive, PUBLIC_CACHE_OBJECT_PERM);
/*      */ 
/*  480 */     cacheStatus.size = size;
/*      */ 
/*  484 */     this.baseDirManager.addCacheInfoUpdate(cacheStatus);
/*      */ 
/*  486 */     LOG.info(String.format("Cached %s as %s", new Object[] { cache.toString(), cacheStatus.localizedLoadPath }));
/*      */ 
/*  488 */     return cacheStatus.localizedLoadPath;
/*      */   }
/*      */ 
/*      */   private static boolean isTarFile(String filename) {
/*  492 */     return (filename.endsWith(".tgz")) || (filename.endsWith(".tar.gz")) || (filename.endsWith(".tar"));
/*      */   }
/*      */ 
/*      */   private boolean ifExistsAndFresh(Configuration conf, FileSystem fs, URI cache, long confFileStamp, CacheStatus lcacheStatus, FileStatus fileStatus)
/*      */     throws IOException
/*      */   {
/*      */     long dfsFileStamp;
/*      */     long dfsFileStamp;
/*  503 */     if (fileStatus != null)
/*  504 */       dfsFileStamp = fileStatus.getModificationTime();
/*      */     else {
/*  506 */       dfsFileStamp = DistributedCache.getTimestamp(conf, cache);
/*      */     }
/*      */ 
/*  510 */     if (dfsFileStamp != confFileStamp) {
/*  511 */       LOG.fatal(new StringBuilder().append("File: ").append(cache).append(" has changed on HDFS since job started").toString());
/*  512 */       throw new IOException(new StringBuilder().append("File: ").append(cache).append(" has changed on HDFS since job started").toString());
/*      */     }
/*      */ 
/*  516 */     return true;
/*      */   }
/*      */ 
/*      */   String getKey(URI cache, Configuration conf, long timeStamp, String user, boolean isArchive) throws IOException
/*      */   {
/*  521 */     return new StringBuilder().append(isArchive ? "a" : "f").append("^").append(makeRelative(cache, conf)).append(String.valueOf(timeStamp)).append(user).toString();
/*      */   }
/*      */ 
/*      */   public static void createAllSymlink(Configuration conf, File jobCacheDir, File workDir)
/*      */     throws IOException
/*      */   {
/*  539 */     if ((jobCacheDir == null) || (!jobCacheDir.isDirectory()) || (workDir == null) || (!workDir.isDirectory()))
/*      */     {
/*  541 */       return;
/*      */     }
/*  543 */     boolean createSymlink = DistributedCache.getSymlink(conf);
/*  544 */     if (createSymlink) {
/*  545 */       File[] list = jobCacheDir.listFiles();
/*  546 */       for (int i = 0; i < list.length; i++) {
/*  547 */         String target = list[i].getAbsolutePath();
/*  548 */         String link = new File(workDir, list[i].getName()).toString();
/*  549 */         LOG.info(String.format("Creating symlink: %s <- %s", new Object[] { target, link }));
/*  550 */         int ret = FileUtil.symLink(target, link);
/*  551 */         if (ret != 0)
/*  552 */           LOG.warn(String.format("Failed to create symlink: %s <- %s", new Object[] { target, link }));
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void purgeCache()
/*      */   {
/*  670 */     synchronized (this.cachedArchives) {
/*  671 */       for (Map.Entry f : this.cachedArchives.entrySet()) {
/*      */         try {
/*  673 */           this.localFs.delete(((CacheStatus)f.getValue()).localizedLoadPath, true);
/*      */         } catch (IOException ie) {
/*  675 */           LOG.debug(new StringBuilder().append("Error cleaning up cache (").append(((CacheStatus)f.getValue()).localizedLoadPath).append(")").toString(), ie);
/*      */         }
/*      */       }
/*      */ 
/*  679 */       this.cachedArchives.clear();
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskDistributedCacheManager newTaskDistributedCacheManager(JobID jobId, Configuration taskConf)
/*      */     throws IOException
/*      */   {
/*  686 */     TaskDistributedCacheManager result = new TaskDistributedCacheManager(this, taskConf);
/*      */ 
/*  688 */     this.jobArchives.put(jobId, result);
/*  689 */     return result;
/*      */   }
/*      */ 
/*      */   public void setArchiveSizes(JobID jobId, long[] sizes)
/*      */     throws IOException
/*      */   {
/*  697 */     TaskDistributedCacheManager mgr = (TaskDistributedCacheManager)this.jobArchives.get(jobId);
/*  698 */     if (mgr != null)
/*  699 */       mgr.setSizes(sizes);
/*      */   }
/*      */ 
/*      */   public void removeTaskDistributedCacheManager(JobID jobId)
/*      */   {
/*  704 */     this.jobArchives.remove(jobId);
/*      */   }
/*      */ 
/*      */   protected TaskDistributedCacheManager getTaskDistributedCacheManager(JobID jobId)
/*      */   {
/*  712 */     return (TaskDistributedCacheManager)this.jobArchives.get(jobId);
/*      */   }
/*      */ 
/*      */   private static FileStatus getFileStatus(Configuration job, URI uri, Map<URI, FileStatus> statCache)
/*      */     throws IOException
/*      */   {
/*  721 */     FileStatus stat = (FileStatus)statCache.get(uri);
/*  722 */     if (stat == null) {
/*  723 */       stat = DistributedCache.getFileStatus(job, uri);
/*  724 */       statCache.put(uri, stat);
/*      */     }
/*  726 */     return stat;
/*      */   }
/*      */ 
/*      */   private static FileStatus getFileStatus(FileSystem fs, Path path, Map<URI, FileStatus> statCache) throws IOException
/*      */   {
/*  731 */     URI uri = path.toUri();
/*  732 */     FileStatus stat = (FileStatus)statCache.get(uri);
/*  733 */     if (stat == null) {
/*  734 */       stat = fs.getFileStatus(path);
/*  735 */       statCache.put(uri, stat);
/*      */     }
/*  737 */     return stat;
/*      */   }
/*      */ 
/*      */   public static void determineTimestampsAndCacheVisibilities(Configuration job)
/*      */     throws IOException
/*      */   {
/*  754 */     Map statCache = new HashMap();
/*  755 */     determineTimestamps(job, statCache);
/*  756 */     determineCacheVisibilities(job, statCache);
/*      */   }
/*      */ 
/*      */   static void determineTimestamps(Configuration job, Map<URI, FileStatus> statCache)
/*      */     throws IOException
/*      */   {
/*  770 */     URI[] tarchives = DistributedCache.getCacheArchives(job);
/*  771 */     if (tarchives != null) {
/*  772 */       FileStatus status = getFileStatus(job, tarchives[0], statCache);
/*  773 */       StringBuffer archiveFileSizes = new StringBuffer(String.valueOf(status.getLen()));
/*      */ 
/*  775 */       StringBuffer archiveTimestamps = new StringBuffer(String.valueOf(status.getModificationTime()));
/*      */ 
/*  777 */       for (int i = 1; i < tarchives.length; i++) {
/*  778 */         status = getFileStatus(job, tarchives[i], statCache);
/*  779 */         archiveFileSizes.append(",");
/*  780 */         archiveFileSizes.append(String.valueOf(status.getLen()));
/*  781 */         archiveTimestamps.append(",");
/*  782 */         archiveTimestamps.append(String.valueOf(status.getModificationTime()));
/*      */       }
/*      */ 
/*  785 */       job.set("mapred.cache.archives.filesizes", archiveFileSizes.toString());
/*      */ 
/*  787 */       DistributedCache.setArchiveTimestamps(job, archiveTimestamps.toString());
/*      */     }
/*      */ 
/*  790 */     URI[] tfiles = DistributedCache.getCacheFiles(job);
/*  791 */     if (tfiles != null) {
/*  792 */       FileStatus status = getFileStatus(job, tfiles[0], statCache);
/*  793 */       StringBuffer fileSizes = new StringBuffer(String.valueOf(status.getLen()));
/*      */ 
/*  795 */       StringBuffer fileTimestamps = new StringBuffer(String.valueOf(status.getModificationTime()));
/*      */ 
/*  797 */       for (int i = 1; i < tfiles.length; i++) {
/*  798 */         status = DistributedCache.getFileStatus(job, tfiles[i]);
/*  799 */         fileSizes.append(",");
/*  800 */         fileSizes.append(String.valueOf(status.getLen()));
/*  801 */         fileTimestamps.append(",");
/*  802 */         fileTimestamps.append(String.valueOf(status.getModificationTime()));
/*      */       }
/*  804 */       job.set("mapred.cache.files.filesizes", fileSizes.toString());
/*  805 */       DistributedCache.setFileTimestamps(job, fileTimestamps.toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   static void determineCacheVisibilities(Configuration job, Map<URI, FileStatus> statCache)
/*      */     throws IOException
/*      */   {
/*  820 */     URI[] tarchives = DistributedCache.getCacheArchives(job);
/*  821 */     if (tarchives != null) {
/*  822 */       StringBuffer archiveVisibilities = new StringBuffer(String.valueOf(isPublic(job, tarchives[0], statCache)));
/*      */ 
/*  824 */       for (int i = 1; i < tarchives.length; i++) {
/*  825 */         archiveVisibilities.append(",");
/*  826 */         archiveVisibilities.append(String.valueOf(isPublic(job, tarchives[i], statCache)));
/*      */       }
/*  828 */       setArchiveVisibilities(job, archiveVisibilities.toString());
/*      */     }
/*  830 */     URI[] tfiles = DistributedCache.getCacheFiles(job);
/*  831 */     if (tfiles != null) {
/*  832 */       StringBuffer fileVisibilities = new StringBuffer(String.valueOf(isPublic(job, tfiles[0], statCache)));
/*      */ 
/*  834 */       for (int i = 1; i < tfiles.length; i++) {
/*  835 */         fileVisibilities.append(",");
/*  836 */         fileVisibilities.append(String.valueOf(isPublic(job, tfiles[i], statCache)));
/*      */       }
/*  838 */       setFileVisibilities(job, fileVisibilities.toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   private static boolean[] parseBooleans(String[] strs) {
/*  843 */     if (null == strs) {
/*  844 */       return null;
/*      */     }
/*  846 */     boolean[] result = new boolean[strs.length];
/*  847 */     for (int i = 0; i < strs.length; i++) {
/*  848 */       result[i] = Boolean.parseBoolean(strs[i]);
/*      */     }
/*  850 */     return result;
/*      */   }
/*      */ 
/*      */   public static boolean[] getFileVisibilities(Configuration conf)
/*      */   {
/*  861 */     return parseBooleans(conf.getStrings("mapreduce.job.cache.files.visibilities"));
/*      */   }
/*      */ 
/*      */   public static boolean[] getArchiveVisibilities(Configuration conf)
/*      */   {
/*  871 */     return parseBooleans(conf.getStrings("mapreduce.job.cache.archives.visibilities"));
/*      */   }
/*      */ 
/*      */   static void setArchiveVisibilities(Configuration conf, String booleans)
/*      */   {
/*  884 */     conf.set("mapreduce.job.cache.archives.visibilities", booleans);
/*      */   }
/*      */ 
/*      */   static void setFileVisibilities(Configuration conf, String booleans)
/*      */   {
/*  895 */     conf.set("mapreduce.job.cache.files.visibilities", booleans);
/*      */   }
/*      */ 
/*      */   public static void getDelegationTokens(Configuration job, Credentials credentials)
/*      */     throws IOException
/*      */   {
/*  907 */     URI[] tarchives = DistributedCache.getCacheArchives(job);
/*  908 */     URI[] tfiles = DistributedCache.getCacheFiles(job);
/*      */ 
/*  910 */     int size = (tarchives != null ? tarchives.length : 0) + (tfiles != null ? tfiles.length : 0);
/*  911 */     Path[] ps = new Path[size];
/*      */ 
/*  913 */     int i = 0;
/*  914 */     if (tarchives != null) {
/*  915 */       for (i = 0; i < tarchives.length; i++) {
/*  916 */         ps[i] = new Path(tarchives[i].toString());
/*      */       }
/*      */     }
/*      */ 
/*  920 */     if (tfiles != null) {
/*  921 */       for (int j = 0; j < tfiles.length; j++) {
/*  922 */         ps[(i + j)] = new Path(tfiles[j].toString());
/*      */       }
/*      */     }
/*      */ 
/*  926 */     TokenCache.obtainTokensForNamenodes(credentials, ps, job);
/*      */   }
/*      */ 
/*      */   public static void validate(Configuration conf)
/*      */     throws InvalidJobConfException
/*      */   {
/*  941 */     String[] archiveStrings = conf.getStrings("mapred.cache.archives");
/*      */ 
/*  943 */     String[] fileStrings = conf.getStrings("mapred.cache.files");
/*      */ 
/*  945 */     Path thisSubject = null;
/*      */ 
/*  947 */     if ((archiveStrings != null) && (fileStrings != null)) {
/*  948 */       Set archivesSet = new HashSet();
/*      */ 
/*  950 */       for (String archiveString : archiveStrings) {
/*  951 */         archivesSet.add(coreLocation(archiveString, conf));
/*      */       }
/*      */ 
/*  954 */       for (String fileString : fileStrings) {
/*  955 */         thisSubject = coreLocation(fileString, conf);
/*      */ 
/*  957 */         if (archivesSet.contains(thisSubject))
/*  958 */           throw new InvalidJobConfException(new StringBuilder().append("The core URI, \"").append(thisSubject).append("\" is listed both in ").append("mapred.cache.files").append(" and in ").append("mapred.cache.archives").append(" .").toString());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static Path coreLocation(String uriString, Configuration conf)
/*      */     throws InvalidJobConfException
/*      */   {
/*  971 */     if (DistributedCache.getSymlink(conf)) {
/*      */       try {
/*  973 */         URI uri = new URI(uriString);
/*  974 */         uriString = new URI(uri.getScheme(), uri.getAuthority(), uri.getPath(), null, null).toString();
/*      */       }
/*      */       catch (URISyntaxException e)
/*      */       {
/*  979 */         throw new InvalidJobConfException(new StringBuilder().append("Badly formatted URI: ").append(uriString).toString(), e);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  984 */     Path path = new Path(uriString);
/*      */     try
/*      */     {
/*  987 */       path = path.makeQualified(path.getFileSystem(conf));
/*      */     } catch (IOException e) {
/*  989 */       throw new InvalidJobConfException(new StringBuilder().append("Invalid file system in distributed cache for the URI: ").append(uriString).toString(), e);
/*      */     }
/*      */ 
/*  994 */     return path;
/*      */   }
/*      */ 
/*      */   public void startCleanupThread()
/*      */   {
/* 1195 */     this.cleanupThread.start();
/*      */   }
/*      */ 
/*      */   public void stopCleanupThread()
/*      */   {
/* 1202 */     this.cleanupThread.stopRunning();
/* 1203 */     this.cleanupThread.interrupt();
/*      */   }
/*      */ 
/*      */   protected class BaseDirManager
/*      */   {
/* 1055 */     private TreeMap<Path, TrackerDistributedCacheManager.CacheDir> properties = new TreeMap();
/*      */ 
/*      */     protected BaseDirManager() {
/*      */     }
/* 1059 */     void checkAndCleanup() throws IOException { Collection toBeDeletedCache = new LinkedList();
/* 1060 */       HashMap toBeCleanedBaseDir = new HashMap();
/*      */ 
/* 1062 */       synchronized (this.properties) {
/* 1063 */         TrackerDistributedCacheManager.LOG.debug("checkAndCleanup: Allowed Cache Size test");
/* 1064 */         for (Map.Entry baseDir : this.properties.entrySet()) {
/* 1065 */           TrackerDistributedCacheManager.CacheDir baseDirCounts = (TrackerDistributedCacheManager.CacheDir)baseDir.getValue();
/* 1066 */           TrackerDistributedCacheManager.LOG.debug(baseDir.getKey() + ": allowedCacheSize=" + TrackerDistributedCacheManager.this.allowedCacheSize + ",baseDirCounts.size=" + baseDirCounts.size + ",allowedCacheSubdirs=" + TrackerDistributedCacheManager.this.allowedCacheSubdirs + ",baseDirCounts.subdirs=" + baseDirCounts.subdirs);
/*      */ 
/* 1070 */           if ((TrackerDistributedCacheManager.this.allowedCacheSize < baseDirCounts.size) || (TrackerDistributedCacheManager.this.allowedCacheSubdirs < baseDirCounts.subdirs))
/*      */           {
/* 1072 */             TrackerDistributedCacheManager.CacheDir tcc = new TrackerDistributedCacheManager.CacheDir(null);
/* 1073 */             baseDirCounts.size -= TrackerDistributedCacheManager.this.allowedCacheSizeCleanupGoal;
/* 1074 */             baseDirCounts.subdirs -= TrackerDistributedCacheManager.this.allowedCacheSubdirsCleanupGoal;
/* 1075 */             toBeCleanedBaseDir.put(baseDir.getKey(), tcc);
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 1080 */       synchronized (TrackerDistributedCacheManager.this.cachedArchives) {
/* 1081 */         TrackerDistributedCacheManager.LOG.debug("checkAndCleanup: Global Cache Size Check");
/*      */ 
/* 1083 */         Iterator it = TrackerDistributedCacheManager.this.cachedArchives.entrySet().iterator();
/*      */ 
/* 1085 */         while (it.hasNext()) {
/* 1086 */           Map.Entry entry = (Map.Entry)it.next();
/* 1087 */           String cacheId = (String)entry.getKey();
/* 1088 */           TrackerDistributedCacheManager.CacheStatus cacheStatus = (TrackerDistributedCacheManager.CacheStatus)TrackerDistributedCacheManager.this.cachedArchives.get(cacheId);
/* 1089 */           TrackerDistributedCacheManager.CacheDir leftToClean = (TrackerDistributedCacheManager.CacheDir)toBeCleanedBaseDir.get(cacheStatus.getBaseDir());
/*      */ 
/* 1091 */           if ((leftToClean != null) && ((leftToClean.size > 0L) || (leftToClean.subdirs > 0L))) {
/* 1092 */             boolean gotLock = TrackerDistributedCacheManager.CacheStatus.access$700(cacheStatus).tryLock();
/* 1093 */             if (gotLock) {
/*      */               try
/*      */               {
/* 1096 */                 boolean isUsed = cacheStatus.isUsed();
/* 1097 */                 long cacheSize = cacheStatus.size;
/* 1098 */                 TrackerDistributedCacheManager.LOG.debug(cacheStatus.getLocalizedUniqueDir() + ": isUsed=" + isUsed + " size=" + cacheSize + " leftToClean.size=" + leftToClean.size);
/*      */ 
/* 1100 */                 if (!isUsed) {
/* 1101 */                   leftToClean.size -= cacheSize;
/* 1102 */                   leftToClean.subdirs -= 1L;
/*      */ 
/* 1105 */                   toBeDeletedCache.add(cacheStatus);
/* 1106 */                   it.remove();
/*      */                 }
/*      */               } finally {
/* 1109 */                 TrackerDistributedCacheManager.CacheStatus.access$700(cacheStatus).unlock();
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1117 */       for (TrackerDistributedCacheManager.CacheStatus cacheStatus : toBeDeletedCache) {
/* 1118 */         TrackerDistributedCacheManager.CacheStatus.access$700(cacheStatus).lock();
/*      */         try {
/* 1120 */           Path localizedDir = cacheStatus.getLocalizedUniqueDir();
/* 1121 */           if (cacheStatus.user == null) {
/* 1122 */             TrackerDistributedCacheManager.LOG.info("Deleted path " + localizedDir);
/*      */             try {
/* 1124 */               TrackerDistributedCacheManager.this.localFs.delete(localizedDir, true);
/*      */             } catch (IOException e) {
/* 1126 */               TrackerDistributedCacheManager.LOG.warn("Could not delete distributed cache empty directory " + localizedDir, e);
/*      */             }
/*      */           }
/*      */           else {
/* 1130 */             TrackerDistributedCacheManager.LOG.info("Deleted path " + localizedDir + " as " + cacheStatus.user);
/* 1131 */             String base = cacheStatus.getBaseDir().toString();
/* 1132 */             String userDir = TaskTracker.getUserDir(cacheStatus.user);
/* 1133 */             int skip = base.length() + 1 + userDir.length() + 1;
/* 1134 */             String relative = localizedDir.toString().substring(skip);
/* 1135 */             TrackerDistributedCacheManager.this.taskController.deleteAsUser(cacheStatus.user, relative);
/*      */           }
/* 1137 */           deleteCacheInfoUpdate(cacheStatus);
/*      */         } finally {
/* 1139 */           TrackerDistributedCacheManager.CacheStatus.access$700(cacheStatus).unlock();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public void deleteCacheInfoUpdate(TrackerDistributedCacheManager.CacheStatus cacheStatus)
/*      */     {
/* 1150 */       if (!cacheStatus.inited)
/*      */       {
/* 1152 */         return;
/*      */       }
/*      */ 
/* 1155 */       synchronized (TrackerDistributedCacheManager.this.baseDirManager.properties) {
/* 1156 */         TrackerDistributedCacheManager.CacheDir cacheDir = (TrackerDistributedCacheManager.CacheDir)this.properties.get(cacheStatus.getBaseDir());
/* 1157 */         if (cacheDir != null) {
/* 1158 */           cacheDir.size -= cacheStatus.size;
/* 1159 */           cacheDir.subdirs -= 1L;
/*      */         } else {
/* 1161 */           TrackerDistributedCacheManager.LOG.warn("Cannot find size and number of subdirectories of baseDir: " + cacheStatus.getBaseDir());
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public void addCacheInfoUpdate(TrackerDistributedCacheManager.CacheStatus cacheStatus)
/*      */     {
/* 1174 */       long cacheSize = cacheStatus.size;
/*      */ 
/* 1176 */       synchronized (TrackerDistributedCacheManager.this.baseDirManager.properties) {
/* 1177 */         TrackerDistributedCacheManager.CacheDir cacheDir = (TrackerDistributedCacheManager.CacheDir)this.properties.get(cacheStatus.getBaseDir());
/* 1178 */         if (cacheDir != null) {
/* 1179 */           cacheDir.size += cacheSize;
/* 1180 */           cacheDir.subdirs += 1L;
/*      */         } else {
/* 1182 */           cacheDir = new TrackerDistributedCacheManager.CacheDir(null);
/* 1183 */           cacheDir.size = cacheSize;
/* 1184 */           cacheDir.subdirs = 1L;
/* 1185 */           this.properties.put(cacheStatus.getBaseDir(), cacheDir);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class CacheDir
/*      */   {
/*      */     long size;
/*      */     long subdirs;
/*      */   }
/*      */ 
/*      */   protected class CleanupThread extends Thread
/*      */   {
/* 1003 */     private long cleanUpCheckPeriod = 60000L;
/*      */ 
/* 1010 */     private volatile boolean running = true;
/*      */ 
/*      */     public CleanupThread(Configuration conf)
/*      */     {
/* 1005 */       this.cleanUpCheckPeriod = conf.getLong("mapreduce.tasktracker.distributedcache.checkperiod", this.cleanUpCheckPeriod);
/*      */     }
/*      */ 
/*      */     public void stopRunning()
/*      */     {
/* 1013 */       this.running = false;
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/* 1018 */       while (this.running)
/*      */         try {
/* 1020 */           Thread.sleep(this.cleanUpCheckPeriod);
/* 1021 */           TrackerDistributedCacheManager.this.baseDirManager.checkAndCleanup();
/*      */         } catch (IOException e) {
/* 1023 */           TrackerDistributedCacheManager.LOG.error("Exception in DistributedCache CleanupThread.", e);
/*      */         } catch (InterruptedException e) {
/* 1025 */           TrackerDistributedCacheManager.LOG.info("Cleanup...", e);
/*      */ 
/* 1027 */           this.running = false;
/*      */         } catch (Throwable t) {
/* 1029 */           exitTaskTracker(t);
/*      */         }
/*      */     }
/*      */ 
/*      */     protected void exitTaskTracker(Throwable t)
/*      */     {
/* 1038 */       TrackerDistributedCacheManager.LOG.fatal("Distributed Cache cleanup thread received runtime exception. Exiting the TaskTracker", t);
/*      */ 
/* 1040 */       Runtime.getRuntime().exit(-1);
/*      */     }
/*      */   }
/*      */ 
/*      */   class CacheStatus
/*      */   {
/*      */     private AtomicInteger refcount;
/*      */     long size;
/*  570 */     boolean inited = false;
/*  571 */     private final ReentrantLock lock = new ReentrantLock();
/*      */     Path subDir;
/*      */     String uniqueString;
/*      */     Path localizedLoadPath;
/*      */     Path localizedBaseDir;
/*      */     final String user;
/*      */     private final String key;
/*      */ 
/*      */     public CacheStatus(Path baseDir, Path localLoadPath, Path subDir, String uniqueString, String user, String key)
/*      */     {
/*  594 */       this.localizedLoadPath = localLoadPath;
/*  595 */       this.refcount = new AtomicInteger();
/*  596 */       this.localizedBaseDir = baseDir;
/*  597 */       this.size = 0L;
/*  598 */       this.subDir = subDir;
/*  599 */       this.uniqueString = uniqueString;
/*  600 */       this.user = user;
/*  601 */       this.key = key;
/*      */     }
/*      */ 
/*      */     public void incRefCount() {
/*  605 */       this.lock.lock();
/*      */       try {
/*  607 */         this.refcount.incrementAndGet();
/*  608 */         TrackerDistributedCacheManager.LOG.debug(this.localizedLoadPath + ": refcount=" + this.refcount.get());
/*      */       } finally {
/*  610 */         this.lock.unlock();
/*      */       }
/*      */     }
/*      */ 
/*      */     public void decRefCount() {
/*  615 */       synchronized (TrackerDistributedCacheManager.this.cachedArchives) {
/*  616 */         this.lock.lock();
/*      */         try {
/*  618 */           this.refcount.decrementAndGet();
/*  619 */           TrackerDistributedCacheManager.LOG.debug(this.localizedLoadPath + ": refcount=" + this.refcount.get());
/*  620 */           if (this.refcount.get() <= 0) {
/*  621 */             String key = this.key;
/*  622 */             TrackerDistributedCacheManager.this.cachedArchives.remove(key);
/*  623 */             TrackerDistributedCacheManager.this.cachedArchives.put(key, this);
/*      */           }
/*      */         } finally {
/*  626 */           this.lock.unlock();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public int getRefCount() {
/*  632 */       return this.refcount.get();
/*      */     }
/*      */ 
/*      */     public boolean isUsed() {
/*  636 */       this.lock.lock();
/*      */       try {
/*  638 */         TrackerDistributedCacheManager.LOG.debug(this.localizedLoadPath + ": refcount=" + this.refcount.get());
/*  639 */         return this.refcount.get() > 0;
/*      */       } finally {
/*  641 */         this.lock.unlock();
/*      */       }
/*      */     }
/*      */ 
/*      */     Path getBaseDir() {
/*  646 */       return this.localizedBaseDir;
/*      */     }
/*      */ 
/*      */     void initComplete()
/*      */     {
/*  651 */       this.inited = true;
/*      */     }
/*      */ 
/*      */     boolean isInited()
/*      */     {
/*  656 */       return this.inited;
/*      */     }
/*      */ 
/*      */     Path getLocalizedUniqueDir() {
/*  660 */       return new Path(this.localizedBaseDir, new Path(this.subDir, this.uniqueString));
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.filecache.TrackerDistributedCacheManager
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.Comparator;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.BlockLocation;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlock;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlocks;
/*     */ import org.apache.hadoop.net.NodeBase;
/*     */ 
/*     */ public class DFSUtil
/*     */ {
/*     */   public static boolean isValidName(String src)
/*     */   {
/*  44 */     if (!src.startsWith("/")) {
/*  45 */       return false;
/*     */     }
/*     */ 
/*  49 */     StringTokenizer tokens = new StringTokenizer(src, "/");
/*  50 */     while (tokens.hasMoreTokens()) {
/*  51 */       String element = tokens.nextToken();
/*  52 */       if ((element.equals("..")) || (element.equals(".")) || (element.indexOf(":") >= 0) || (element.indexOf("/") >= 0))
/*     */       {
/*  56 */         return false;
/*     */       }
/*     */     }
/*  59 */     return true;
/*     */   }
/*     */ 
/*     */   public static String bytes2String(byte[] bytes)
/*     */   {
/*     */     try
/*     */     {
/*  67 */       return new String(bytes, "UTF8");
/*     */     } catch (UnsupportedEncodingException e) {
/*  69 */       if (!$assertionsDisabled) throw new AssertionError("UTF8 encoding is not supported ");
/*     */     }
/*  71 */     return null;
/*     */   }
/*     */ 
/*     */   public static byte[] string2Bytes(String str)
/*     */   {
/*     */     try
/*     */     {
/*  79 */       return str.getBytes("UTF8");
/*     */     } catch (UnsupportedEncodingException e) {
/*  81 */       if (!$assertionsDisabled) throw new AssertionError("UTF8 encoding is not supported ");
/*     */     }
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */   public static BlockLocation[] locatedBlocks2Locations(LocatedBlocks blocks)
/*     */   {
/*  92 */     if (blocks == null) {
/*  93 */       return new BlockLocation[0];
/*     */     }
/*  95 */     int nrBlocks = blocks.locatedBlockCount();
/*  96 */     BlockLocation[] blkLocations = new BlockLocation[nrBlocks];
/*  97 */     int idx = 0;
/*  98 */     for (LocatedBlock blk : blocks.getLocatedBlocks()) {
/*  99 */       assert (idx < nrBlocks) : "Incorrect index";
/* 100 */       DatanodeInfo[] locations = blk.getLocations();
/* 101 */       String[] hosts = new String[locations.length];
/* 102 */       String[] names = new String[locations.length];
/* 103 */       String[] racks = new String[locations.length];
/* 104 */       for (int hCnt = 0; hCnt < locations.length; hCnt++) {
/* 105 */         hosts[hCnt] = locations[hCnt].getHostName();
/* 106 */         names[hCnt] = locations[hCnt].getName();
/* 107 */         NodeBase node = new NodeBase(names[hCnt], locations[hCnt].getNetworkLocation());
/*     */ 
/* 109 */         racks[hCnt] = node.toString();
/*     */       }
/* 111 */       blkLocations[idx] = new BlockLocation(names, hosts, racks, blk.getStartOffset(), blk.getBlockSize());
/*     */ 
/* 114 */       idx++;
/*     */     }
/* 116 */     return blkLocations;
/*     */   }
/*     */ 
/*     */   public static URI createUri(String scheme, InetSocketAddress address)
/*     */   {
/*     */     try {
/* 122 */       return new URI(scheme, null, address.getHostName(), address.getPort(), null, null, null);
/*     */     }
/*     */     catch (URISyntaxException ue) {
/* 125 */       throw new IllegalArgumentException(ue);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static float getInvalidateWorkPctPerIteration(Configuration conf)
/*     */   {
/* 137 */     float blocksInvalidateWorkPct = conf.getFloat("dfs.namenode.invalidate.work.pct.per.iteration", 0.32F);
/*     */ 
/* 140 */     if ((blocksInvalidateWorkPct <= 0.0F) || (blocksInvalidateWorkPct > 1.0F)) {
/* 141 */       throw new IllegalArgumentException("dfs.namenode.invalidate.work.pct.per.iteration = '" + blocksInvalidateWorkPct + "' is invalid. " + "It should be a positive, non-zero float value " + "indicating a percentage.");
/*     */     }
/*     */ 
/* 147 */     return blocksInvalidateWorkPct;
/*     */   }
/*     */ 
/*     */   public static int getReplWorkMultiplier(Configuration conf)
/*     */   {
/* 159 */     int blocksReplWorkMultiplier = conf.getInt("dfs.namenode.replication.work.multiplier.per.iteration", 2);
/*     */ 
/* 163 */     if (blocksReplWorkMultiplier <= 0) {
/* 164 */       throw new IllegalArgumentException("dfs.namenode.replication.work.multiplier.per.iteration = '" + blocksReplWorkMultiplier + "' is invalid. " + "It should be a positive, non-zero integer value.");
/*     */     }
/*     */ 
/* 169 */     return blocksReplWorkMultiplier;
/*     */   }
/*     */ 
/*     */   public static class StaleComparator
/*     */     implements Comparator<DatanodeInfo>
/*     */   {
/*     */     private long staleInterval;
/*     */ 
/*     */     public StaleComparator(long interval)
/*     */     {
/* 187 */       this.staleInterval = interval;
/*     */     }
/*     */ 
/*     */     public int compare(DatanodeInfo a, DatanodeInfo b)
/*     */     {
/* 193 */       boolean aStale = a.isStale(this.staleInterval);
/* 194 */       boolean bStale = b.isStale(this.staleInterval);
/* 195 */       return aStale ? 1 : aStale == bStale ? 0 : -1;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.DFSUtil
 * JD-Core Version:    0.6.1
 */
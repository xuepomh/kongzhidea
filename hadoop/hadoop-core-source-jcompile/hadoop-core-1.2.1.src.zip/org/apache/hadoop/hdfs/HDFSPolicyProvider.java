/*    */ package org.apache.hadoop.hdfs;
/*    */ 
/*    */ import org.apache.hadoop.hdfs.protocol.ClientDatanodeProtocol;
/*    */ import org.apache.hadoop.hdfs.protocol.ClientProtocol;
/*    */ import org.apache.hadoop.hdfs.server.protocol.DatanodeProtocol;
/*    */ import org.apache.hadoop.hdfs.server.protocol.InterDatanodeProtocol;
/*    */ import org.apache.hadoop.hdfs.server.protocol.NamenodeProtocol;
/*    */ import org.apache.hadoop.security.RefreshUserMappingsProtocol;
/*    */ import org.apache.hadoop.security.authorize.PolicyProvider;
/*    */ import org.apache.hadoop.security.authorize.RefreshAuthorizationPolicyProtocol;
/*    */ import org.apache.hadoop.security.authorize.Service;
/*    */ 
/*    */ public class HDFSPolicyProvider extends PolicyProvider
/*    */ {
/* 34 */   private static final Service[] hdfsServices = { new Service("security.client.protocol.acl", ClientProtocol.class), new Service("security.client.datanode.protocol.acl", ClientDatanodeProtocol.class), new Service("security.datanode.protocol.acl", DatanodeProtocol.class), new Service("security.inter.datanode.protocol.acl", InterDatanodeProtocol.class), new Service("security.namenode.protocol.acl", NamenodeProtocol.class), new Service("security.refresh.policy.protocol.acl", RefreshAuthorizationPolicyProtocol.class), new Service("security.refresh.usertogroups.mappings.protocol.acl", RefreshUserMappingsProtocol.class) };
/*    */ 
/*    */   public Service[] getServices()
/*    */   {
/* 51 */     return hdfsServices;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.HDFSPolicyProvider
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.commons.io.input.BoundedInputStream;
/*     */ import org.apache.hadoop.fs.FSInputStream;
/*     */ 
/*     */ public abstract class ByteRangeInputStream extends FSInputStream
/*     */ {
/*     */   protected InputStream in;
/*     */   protected URLOpener originalURL;
/*     */   protected URLOpener resolvedURL;
/*  72 */   protected long startPos = 0L;
/*  73 */   protected long currentPos = 0L;
/*  74 */   protected Long fileLength = null;
/*     */ 
/*  76 */   StreamStatus status = StreamStatus.SEEK;
/*     */ 
/*     */   public ByteRangeInputStream(URLOpener o, URLOpener r)
/*     */   {
/*  85 */     this.originalURL = o;
/*  86 */     this.resolvedURL = r;
/*     */   }
/*     */ 
/*     */   protected abstract URL getResolvedUrl(HttpURLConnection paramHttpURLConnection) throws IOException;
/*     */ 
/*     */   protected InputStream getInputStream() throws IOException
/*     */   {
/*  93 */     switch (1.$SwitchMap$org$apache$hadoop$hdfs$ByteRangeInputStream$StreamStatus[this.status.ordinal()]) {
/*     */     case 1:
/*  95 */       break;
/*     */     case 2:
/*  97 */       if (this.in != null) {
/*  98 */         this.in.close();
/*     */       }
/* 100 */       this.in = openInputStream();
/* 101 */       this.status = StreamStatus.NORMAL;
/* 102 */       break;
/*     */     case 3:
/* 104 */       throw new IOException("Stream closed");
/*     */     }
/* 106 */     return this.in;
/*     */   }
/*     */ 
/*     */   protected InputStream openInputStream()
/*     */     throws IOException
/*     */   {
/* 112 */     boolean resolved = this.resolvedURL.getURL() != null;
/* 113 */     URLOpener opener = resolved ? this.resolvedURL : this.originalURL;
/*     */ 
/* 115 */     HttpURLConnection connection = opener.connect(this.startPos, resolved);
/* 116 */     this.resolvedURL.setURL(getResolvedUrl(connection));
/*     */ 
/* 118 */     InputStream in = connection.getInputStream();
/* 119 */     Map headers = connection.getHeaderFields();
/* 120 */     if (isChunkedTransferEncoding(headers))
/*     */     {
/* 122 */       this.fileLength = null;
/*     */     }
/*     */     else {
/* 125 */       String cl = connection.getHeaderField("Content-Length");
/* 126 */       if (cl == null) {
/* 127 */         throw new IOException("Content-Length is missing: " + headers);
/*     */       }
/*     */ 
/* 130 */       long streamlength = Long.parseLong(cl);
/* 131 */       this.fileLength = Long.valueOf(this.startPos + streamlength);
/*     */ 
/* 135 */       in = new BoundedInputStream(in, streamlength);
/*     */     }
/*     */ 
/* 138 */     return in;
/*     */   }
/*     */ 
/*     */   private static boolean isChunkedTransferEncoding(Map<String, List<String>> headers)
/*     */   {
/* 143 */     return (contains(headers, "Transfer-Encoding", "chunked")) || (contains(headers, "TE", "chunked"));
/*     */   }
/*     */ 
/*     */   private static boolean contains(Map<String, List<String>> headers, String key, String value)
/*     */   {
/* 150 */     List values = (List)headers.get(key);
/* 151 */     if (values != null) {
/* 152 */       for (String v : values) {
/* 153 */         StringTokenizer t = new StringTokenizer(v, ",");
/* 154 */         while (t.hasMoreTokens()) {
/* 155 */           if (value.equalsIgnoreCase(t.nextToken())) {
/* 156 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 161 */     return false;
/*     */   }
/*     */ 
/*     */   private int update(int n) throws IOException {
/* 165 */     if (n != -1)
/* 166 */       this.currentPos += n;
/* 167 */     else if ((this.fileLength != null) && (this.currentPos < this.fileLength.longValue())) {
/* 168 */       throw new IOException("Got EOF but currentPos = " + this.currentPos + " < filelength = " + this.fileLength);
/*     */     }
/*     */ 
/* 171 */     return n;
/*     */   }
/*     */ 
/*     */   public int read() throws IOException
/*     */   {
/* 176 */     int b = getInputStream().read();
/* 177 */     update(b == -1 ? -1 : 1);
/* 178 */     return b;
/*     */   }
/*     */ 
/*     */   public int read(byte[] b, int off, int len) throws IOException
/*     */   {
/* 183 */     return update(getInputStream().read(b, off, len));
/*     */   }
/*     */ 
/*     */   public void seek(long pos)
/*     */     throws IOException
/*     */   {
/* 193 */     if (pos != this.currentPos) {
/* 194 */       this.startPos = pos;
/* 195 */       this.currentPos = pos;
/* 196 */       if (this.status != StreamStatus.CLOSED)
/* 197 */         this.status = StreamStatus.SEEK;
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getPos()
/*     */     throws IOException
/*     */   {
/* 207 */     return this.currentPos;
/*     */   }
/*     */ 
/*     */   public boolean seekToNewSource(long targetPos)
/*     */     throws IOException
/*     */   {
/* 216 */     return false;
/*     */   }
/*     */ 
/*     */   public void close() throws IOException
/*     */   {
/* 221 */     if (this.in != null) {
/* 222 */       this.in.close();
/* 223 */       this.in = null;
/*     */     }
/* 225 */     this.status = StreamStatus.CLOSED;
/*     */   }
/*     */ 
/*     */   static enum StreamStatus
/*     */   {
/*  67 */     NORMAL, SEEK, CLOSED;
/*     */   }
/*     */ 
/*     */   public static abstract class URLOpener
/*     */   {
/*     */     protected URL url;
/*     */ 
/*     */     public URLOpener(URL u)
/*     */     {
/*  50 */       this.url = u;
/*     */     }
/*     */ 
/*     */     public void setURL(URL u) {
/*  54 */       this.url = u;
/*     */     }
/*     */ 
/*     */     public URL getURL() {
/*  58 */       return this.url;
/*     */     }
/*     */ 
/*     */     protected abstract HttpURLConnection connect(long paramLong, boolean paramBoolean)
/*     */       throws IOException;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.ByteRangeInputStream
 * JD-Core Version:    0.6.1
 */
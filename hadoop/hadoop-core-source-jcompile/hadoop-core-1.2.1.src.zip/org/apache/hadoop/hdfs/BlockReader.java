package org.apache.hadoop.hdfs;

import java.io.IOException;
import org.apache.hadoop.io.Closeable;

public abstract interface BlockReader extends Closeable
{
  public abstract int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException;

  public abstract int readAll(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException;

  public abstract long skip(long paramLong)
    throws IOException;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.BlockReader
 * JD-Core Version:    0.6.1
 */
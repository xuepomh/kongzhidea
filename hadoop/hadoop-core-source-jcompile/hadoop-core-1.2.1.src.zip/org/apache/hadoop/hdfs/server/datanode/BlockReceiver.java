/*     */ package org.apache.hadoop.hdfs.server.datanode;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.Closeable;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.FileDescriptor;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.util.LinkedList;
/*     */ import java.util.zip.Checksum;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.fs.FSInputChecker;
/*     */ import org.apache.hadoop.fs.FSOutputSummer;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.hdfs.protocol.DataTransferProtocol.PipelineAck;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.hdfs.protocol.FSConstants;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlock;
/*     */ import org.apache.hadoop.hdfs.server.datanode.metrics.DataNodeInstrumentation;
/*     */ import org.apache.hadoop.hdfs.server.protocol.DatanodeProtocol;
/*     */ import org.apache.hadoop.hdfs.server.protocol.DatanodeRegistration;
/*     */ import org.apache.hadoop.hdfs.util.DataTransferThrottler;
/*     */ import org.apache.hadoop.io.IOUtils;
/*     */ import org.apache.hadoop.io.nativeio.NativeIO;
/*     */ import org.apache.hadoop.util.Daemon;
/*     */ import org.apache.hadoop.util.DataChecksum;
/*     */ import org.apache.hadoop.util.PureJavaCrc32;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ class BlockReceiver
/*     */   implements Closeable, FSConstants
/*     */ {
/*  55 */   public static final Log LOG = DataNode.LOG;
/*  56 */   static final Log ClientTraceLog = DataNode.ClientTraceLog;
/*     */   private static final long CACHE_DROP_LAG_BYTES = 8388608L;
/*     */   private Block block;
/*     */   protected boolean finalized;
/*  62 */   private DataInputStream in = null;
/*     */   private DataChecksum checksum;
/*  64 */   private OutputStream out = null;
/*  65 */   private OutputStream cout = null;
/*     */   private FileDescriptor outFd;
/*  67 */   private DataOutputStream checksumOut = null;
/*     */   private int bytesPerChecksum;
/*     */   private int checksumSize;
/*     */   private ByteBuffer buf;
/*     */   private int bufRead;
/*     */   private int maxPacketReadLen;
/*     */   protected long offsetInBlock;
/*     */   protected final String inAddr;
/*     */   protected final String myAddr;
/*     */   private String mirrorAddr;
/*     */   private DataOutputStream mirrorOut;
/*  78 */   private Daemon responder = null;
/*     */   private DataTransferThrottler throttler;
/*     */   private FSDatasetInterface.BlockWriteStreams streams;
/*  81 */   private boolean isRecovery = false;
/*     */   private String clientName;
/*  83 */   DatanodeInfo srcDataNode = null;
/*  84 */   private Checksum partialCrc = null;
/*  85 */   private DataNode datanode = null;
/*     */   private volatile boolean mirrorError;
/*     */   private boolean dropCacheBehindWrites;
/*     */   private boolean syncBehindWrites;
/*  91 */   private long lastCacheDropOffset = 0L;
/*     */ 
/*     */   BlockReceiver(Block block, DataInputStream in, String inAddr, String myAddr, boolean isRecovery, String clientName, DatanodeInfo srcDataNode, DataNode datanode) throws IOException
/*     */   {
/*     */     try
/*     */     {
/*  97 */       this.block = block;
/*  98 */       this.in = in;
/*  99 */       this.inAddr = inAddr;
/* 100 */       this.myAddr = myAddr;
/* 101 */       this.isRecovery = isRecovery;
/* 102 */       this.clientName = clientName;
/* 103 */       this.offsetInBlock = 0L;
/* 104 */       this.srcDataNode = srcDataNode;
/* 105 */       this.datanode = datanode;
/* 106 */       this.checksum = DataChecksum.newDataChecksum(in);
/* 107 */       this.bytesPerChecksum = this.checksum.getBytesPerChecksum();
/* 108 */       this.checksumSize = this.checksum.getChecksumSize();
/* 109 */       this.dropCacheBehindWrites = datanode.shouldDropCacheBehindWrites();
/* 110 */       this.syncBehindWrites = datanode.shouldSyncBehindWrites();
/*     */ 
/* 114 */       this.streams = datanode.data.writeToBlock(block, isRecovery, (clientName == null) || (clientName.length() == 0));
/*     */ 
/* 116 */       this.finalized = false;
/* 117 */       if (this.streams != null) {
/* 118 */         this.out = this.streams.dataOut;
/* 119 */         this.cout = this.streams.checksumOut;
/* 120 */         if ((this.out instanceof FileOutputStream))
/* 121 */           this.outFd = ((FileOutputStream)this.out).getFD();
/*     */         else {
/* 123 */           LOG.warn("Could not get file descriptor for outputstream of class " + this.out.getClass());
/*     */         }
/*     */ 
/* 126 */         this.checksumOut = new DataOutputStream(new BufferedOutputStream(this.streams.checksumOut, SMALL_BUFFER_SIZE));
/*     */ 
/* 131 */         if ((datanode.blockScanner != null) && (isRecovery))
/* 132 */           datanode.blockScanner.deleteBlock(block);
/*     */       }
/*     */     }
/*     */     catch (BlockAlreadyExistsException bae) {
/* 136 */       throw bae;
/*     */     } catch (IOException ioe) {
/* 138 */       IOUtils.closeStream(this);
/* 139 */       cleanupBlock();
/*     */ 
/* 142 */       IOException cause = FSDataset.getCauseIfDiskError(ioe);
/* 143 */       DataNode.LOG.warn("IOException in BlockReceiver constructor. Cause is ", cause);
/*     */ 
/* 146 */       if (cause != null) {
/* 147 */         ioe = cause;
/* 148 */         datanode.checkDiskError(ioe);
/*     */       }
/*     */ 
/* 151 */       throw ioe;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 160 */     IOException ioe = null;
/*     */     try
/*     */     {
/* 163 */       if (this.checksumOut != null) {
/* 164 */         this.checksumOut.flush();
/* 165 */         if ((this.datanode.syncOnClose) && ((this.cout instanceof FileOutputStream))) {
/* 166 */           ((FileOutputStream)this.cout).getChannel().force(true);
/*     */         }
/* 168 */         this.checksumOut.close();
/* 169 */         this.checksumOut = null;
/*     */       }
/*     */     } catch (IOException e) {
/* 172 */       ioe = e;
/*     */     }
/*     */     try
/*     */     {
/* 176 */       if (this.out != null) {
/* 177 */         this.out.flush();
/* 178 */         if ((this.datanode.syncOnClose) && ((this.out instanceof FileOutputStream))) {
/* 179 */           ((FileOutputStream)this.out).getChannel().force(true);
/*     */         }
/* 181 */         this.out.close();
/* 182 */         this.out = null;
/*     */       }
/*     */     } catch (IOException e) {
/* 185 */       ioe = e;
/*     */     }
/*     */ 
/* 188 */     if (ioe != null) {
/* 189 */       this.datanode.checkDiskError(ioe);
/* 190 */       throw ioe;
/*     */     }
/*     */   }
/*     */ 
/*     */   void flush()
/*     */     throws IOException
/*     */   {
/* 199 */     if (this.checksumOut != null) {
/* 200 */       this.checksumOut.flush();
/*     */     }
/* 202 */     if (this.out != null)
/* 203 */       this.out.flush();
/*     */   }
/*     */ 
/*     */   private void handleMirrorOutError(IOException ioe)
/*     */     throws IOException
/*     */   {
/* 212 */     LOG.info(this.datanode.dnRegistration + ": Exception writing " + this.block + " to mirror " + this.mirrorAddr + "\n" + StringUtils.stringifyException(ioe));
/*     */ 
/* 215 */     if (Thread.interrupted()) {
/* 216 */       throw ioe;
/*     */     }
/*     */ 
/* 221 */     this.mirrorError = true;
/*     */   }
/*     */ 
/*     */   private void verifyChunks(byte[] dataBuf, int dataOff, int len, byte[] checksumBuf, int checksumOff)
/*     */     throws IOException
/*     */   {
/* 231 */     while (len > 0) {
/* 232 */       int chunkLen = Math.min(len, this.bytesPerChecksum);
/*     */ 
/* 234 */       this.checksum.update(dataBuf, dataOff, chunkLen);
/*     */ 
/* 236 */       if (!this.checksum.compare(checksumBuf, checksumOff)) {
/* 237 */         if (this.srcDataNode != null) {
/*     */           try {
/* 239 */             LOG.info("report corrupt " + this.block + " from datanode " + this.srcDataNode + " to namenode");
/*     */ 
/* 241 */             LocatedBlock lb = new LocatedBlock(this.block, new DatanodeInfo[] { this.srcDataNode });
/*     */ 
/* 243 */             this.datanode.namenode.reportBadBlocks(new LocatedBlock[] { lb });
/*     */           } catch (IOException e) {
/* 245 */             LOG.warn("Failed to report bad " + this.block + " from datanode " + this.srcDataNode + " to namenode");
/*     */           }
/*     */         }
/*     */ 
/* 249 */         throw new IOException("Unexpected checksum mismatch while writing " + this.block + " from " + this.inAddr);
/*     */       }
/*     */ 
/* 253 */       this.checksum.reset();
/* 254 */       dataOff += chunkLen;
/* 255 */       checksumOff += this.checksumSize;
/* 256 */       len -= chunkLen;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void shiftBufData()
/*     */   {
/* 265 */     if (this.bufRead != this.buf.limit()) {
/* 266 */       throw new IllegalStateException("bufRead should be same as buf.limit()");
/*     */     }
/*     */ 
/* 271 */     if (this.buf.position() > 0) {
/* 272 */       int dataLeft = this.buf.remaining();
/* 273 */       if (dataLeft > 0) {
/* 274 */         byte[] b = this.buf.array();
/* 275 */         System.arraycopy(b, this.buf.position(), b, 0, dataLeft);
/*     */       }
/* 277 */       this.buf.position(0);
/* 278 */       this.bufRead = dataLeft;
/* 279 */       this.buf.limit(this.bufRead);
/*     */     }
/*     */   }
/*     */ 
/*     */   private int readToBuf(int toRead)
/*     */     throws IOException
/*     */   {
/* 288 */     if (toRead < 0) {
/* 289 */       toRead = (this.maxPacketReadLen > 0 ? this.maxPacketReadLen : this.buf.capacity()) - this.buf.limit();
/*     */     }
/*     */ 
/* 293 */     int nRead = this.in.read(this.buf.array(), this.buf.limit(), toRead);
/*     */ 
/* 295 */     if (nRead < 0) {
/* 296 */       throw new EOFException("while trying to read " + toRead + " bytes");
/*     */     }
/* 298 */     this.bufRead = (this.buf.limit() + nRead);
/* 299 */     this.buf.limit(this.bufRead);
/* 300 */     return nRead;
/*     */   }
/*     */ 
/*     */   private int readNextPacket()
/*     */     throws IOException
/*     */   {
/* 318 */     if (this.buf == null)
/*     */     {
/* 323 */       int chunkSize = this.bytesPerChecksum + this.checksumSize;
/* 324 */       int chunksPerPacket = (this.datanode.writePacketSize - 21 - 4 + chunkSize - 1) / chunkSize;
/*     */ 
/* 326 */       this.buf = ByteBuffer.allocate(25 + Math.max(chunksPerPacket, 1) * chunkSize);
/*     */ 
/* 328 */       this.buf.limit(0);
/*     */     }
/*     */ 
/* 332 */     if (this.bufRead > this.buf.limit()) {
/* 333 */       this.buf.limit(this.bufRead);
/*     */     }
/*     */ 
/* 336 */     while (this.buf.remaining() < 4) {
/* 337 */       if (this.buf.position() > 0) {
/* 338 */         shiftBufData();
/*     */       }
/* 340 */       readToBuf(-1);
/*     */     }
/*     */ 
/* 345 */     this.buf.mark();
/* 346 */     int payloadLen = this.buf.getInt();
/* 347 */     this.buf.reset();
/*     */ 
/* 349 */     if (payloadLen == 0)
/*     */     {
/* 351 */       this.buf.limit(this.buf.position() + 4);
/* 352 */       return 0;
/*     */     }
/*     */ 
/* 356 */     if ((payloadLen < 0) || (payloadLen > 104857600)) {
/* 357 */       throw new IOException("Incorrect value for packet payload : " + payloadLen);
/*     */     }
/*     */ 
/* 361 */     int pktSize = payloadLen + 21;
/*     */ 
/* 363 */     if (this.buf.remaining() < pktSize)
/*     */     {
/* 365 */       int toRead = pktSize - this.buf.remaining();
/*     */ 
/* 368 */       int spaceLeft = this.buf.capacity() - this.buf.limit();
/* 369 */       if ((toRead > spaceLeft) && (this.buf.position() > 0)) {
/* 370 */         shiftBufData();
/* 371 */         spaceLeft = this.buf.capacity() - this.buf.limit();
/*     */       }
/* 373 */       if (toRead > spaceLeft) {
/* 374 */         byte[] oldBuf = this.buf.array();
/* 375 */         int toCopy = this.buf.limit();
/* 376 */         this.buf = ByteBuffer.allocate(toCopy + toRead);
/* 377 */         System.arraycopy(oldBuf, 0, this.buf.array(), 0, toCopy);
/* 378 */         this.buf.limit(toCopy);
/*     */       }
/*     */ 
/* 382 */       while (toRead > 0) {
/* 383 */         toRead -= readToBuf(toRead);
/*     */       }
/*     */     }
/*     */ 
/* 387 */     if (this.buf.remaining() > pktSize) {
/* 388 */       this.buf.limit(this.buf.position() + pktSize);
/*     */     }
/*     */ 
/* 391 */     if (pktSize > this.maxPacketReadLen) {
/* 392 */       this.maxPacketReadLen = pktSize;
/*     */     }
/*     */ 
/* 395 */     return payloadLen;
/*     */   }
/*     */ 
/*     */   private int receivePacket()
/*     */     throws IOException
/*     */   {
/* 404 */     int payloadLen = readNextPacket();
/*     */ 
/* 406 */     if (payloadLen <= 0) {
/* 407 */       return payloadLen;
/*     */     }
/*     */ 
/* 410 */     this.buf.mark();
/*     */ 
/* 412 */     this.buf.getInt();
/* 413 */     this.offsetInBlock = this.buf.getLong();
/* 414 */     long seqno = this.buf.getLong();
/* 415 */     boolean lastPacketInBlock = this.buf.get() != 0;
/*     */ 
/* 417 */     int endOfHeader = this.buf.position();
/* 418 */     this.buf.reset();
/*     */ 
/* 420 */     if (LOG.isDebugEnabled()) {
/* 421 */       LOG.debug("Receiving one packet for " + this.block + " of length " + payloadLen + " seqno " + seqno + " offsetInBlock " + this.offsetInBlock + " lastPacketInBlock " + lastPacketInBlock);
/*     */     }
/*     */ 
/* 428 */     setBlockPosition(this.offsetInBlock);
/*     */ 
/* 431 */     if ((this.mirrorOut != null) && (!this.mirrorError)) {
/*     */       try {
/* 433 */         this.mirrorOut.write(this.buf.array(), this.buf.position(), this.buf.remaining());
/* 434 */         this.mirrorOut.flush();
/*     */       } catch (IOException e) {
/* 436 */         handleMirrorOutError(e);
/*     */       }
/*     */     }
/*     */ 
/* 440 */     this.buf.position(endOfHeader);
/* 441 */     int len = this.buf.getInt();
/*     */ 
/* 443 */     if (len < 0) {
/* 444 */       throw new IOException("Got wrong length during writeBlock(" + this.block + ") from " + this.inAddr + " at offset " + this.offsetInBlock + ": " + len);
/*     */     }
/*     */ 
/* 449 */     if (len == 0) {
/* 450 */       LOG.debug("Receiving empty packet for " + this.block);
/*     */     } else {
/* 452 */       this.offsetInBlock += len;
/*     */ 
/* 454 */       int checksumLen = (len + this.bytesPerChecksum - 1) / this.bytesPerChecksum * this.checksumSize;
/*     */ 
/* 457 */       if (this.buf.remaining() != checksumLen + len) {
/* 458 */         throw new IOException("Data remaining in packet does not match sum of checksumLen and dataLen");
/*     */       }
/*     */ 
/* 461 */       int checksumOff = this.buf.position();
/* 462 */       int dataOff = checksumOff + checksumLen;
/* 463 */       byte[] pktBuf = this.buf.array();
/*     */ 
/* 465 */       this.buf.position(this.buf.limit());
/*     */ 
/* 474 */       if ((this.mirrorOut == null) || (this.clientName.length() == 0)) {
/* 475 */         verifyChunks(pktBuf, dataOff, len, pktBuf, checksumOff);
/*     */       }
/*     */       try
/*     */       {
/* 479 */         if (!this.finalized)
/*     */         {
/* 481 */           this.out.write(pktBuf, dataOff, len);
/*     */ 
/* 485 */           if (this.partialCrc != null) {
/* 486 */             if (len > this.bytesPerChecksum) {
/* 487 */               throw new IOException("Got wrong length during writeBlock(" + this.block + ") from " + this.inAddr + " " + "A packet can have only one partial chunk." + " len = " + len + " bytesPerChecksum " + this.bytesPerChecksum);
/*     */             }
/*     */ 
/* 493 */             this.partialCrc.update(pktBuf, dataOff, len);
/* 494 */             byte[] buf = FSOutputSummer.convertToByteStream(this.partialCrc, this.checksumSize);
/* 495 */             this.checksumOut.write(buf);
/* 496 */             LOG.debug("Writing out partial crc for data len " + len);
/* 497 */             this.partialCrc = null;
/*     */           } else {
/* 499 */             this.checksumOut.write(pktBuf, checksumOff, checksumLen);
/*     */           }
/* 501 */           this.datanode.myMetrics.incrBytesWritten(len);
/*     */ 
/* 503 */           flush();
/*     */ 
/* 506 */           this.datanode.data.setVisibleLength(this.block, this.offsetInBlock);
/* 507 */           dropOsCacheBehindWriter(this.offsetInBlock);
/*     */         }
/*     */       } catch (IOException iex) {
/* 510 */         this.datanode.checkDiskError(iex);
/* 511 */         throw iex;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 516 */     if (this.responder != null) {
/* 517 */       ((PacketResponder)this.responder.getRunnable()).enqueue(seqno, lastPacketInBlock);
/*     */     }
/*     */ 
/* 521 */     if (this.throttler != null) {
/* 522 */       this.throttler.throttle(payloadLen);
/*     */     }
/*     */ 
/* 525 */     return payloadLen;
/*     */   }
/*     */ 
/*     */   private void dropOsCacheBehindWriter(long offsetInBlock) throws IOException {
/*     */     try {
/* 530 */       if ((this.outFd != null) && (offsetInBlock > this.lastCacheDropOffset + 8388608L))
/*     */       {
/* 532 */         long twoWindowsAgo = this.lastCacheDropOffset - 8388608L;
/* 533 */         if ((twoWindowsAgo > 0L) && (this.dropCacheBehindWrites)) {
/* 534 */           NativeIO.posixFadviseIfPossible(this.outFd, 0L, this.lastCacheDropOffset, 4);
/*     */         }
/*     */ 
/* 538 */         if (this.syncBehindWrites) {
/* 539 */           NativeIO.syncFileRangeIfPossible(this.outFd, this.lastCacheDropOffset, 8388608L, 2);
/*     */         }
/*     */ 
/* 543 */         this.lastCacheDropOffset += 8388608L;
/*     */       }
/*     */     } catch (Throwable t) {
/* 546 */       LOG.warn("Couldn't drop os cache behind writer for " + this.block, t);
/*     */     }
/*     */   }
/*     */ 
/*     */   void writeChecksumHeader(DataOutputStream mirrorOut) throws IOException {
/* 551 */     this.checksum.writeHeader(mirrorOut);
/*     */   }
/*     */ 
/*     */   void receiveBlock(DataOutputStream mirrOut, DataInputStream mirrIn, DataOutputStream replyOut, String mirrAddr, DataTransferThrottler throttlerArg, int numTargets)
/*     */     throws IOException
/*     */   {
/* 562 */     this.mirrorOut = mirrOut;
/* 563 */     this.mirrorAddr = mirrAddr;
/* 564 */     this.throttler = throttlerArg;
/*     */     try
/*     */     {
/* 568 */       if (!this.finalized) {
/* 569 */         BlockMetadataHeader.writeHeader(this.checksumOut, this.checksum);
/*     */       }
/* 571 */       if (this.clientName.length() > 0) {
/* 572 */         this.responder = new Daemon(this.datanode.threadGroup, new PacketResponder(this, this.block, mirrIn, replyOut, numTargets, Thread.currentThread()));
/*     */ 
/* 576 */         this.responder.start();
/*     */       }
/*     */ 
/* 582 */       while (receivePacket() > 0);
/* 585 */       if (this.mirrorOut != null) {
/*     */         try {
/* 587 */           this.mirrorOut.writeInt(0);
/* 588 */           this.mirrorOut.flush();
/*     */         } catch (IOException e) {
/* 590 */           handleMirrorOutError(e);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 596 */       if (this.responder != null) {
/* 597 */         ((PacketResponder)this.responder.getRunnable()).close();
/*     */       }
/*     */ 
/* 603 */       if (this.clientName.length() == 0)
/*     */       {
/* 605 */         close();
/*     */ 
/* 608 */         this.block.setNumBytes(this.offsetInBlock);
/* 609 */         this.datanode.data.finalizeBlock(this.block);
/* 610 */         this.datanode.myMetrics.incrBlocksWritten();
/*     */       }
/*     */     }
/*     */     catch (IOException ioe) {
/* 614 */       LOG.info("Exception in receiveBlock for " + this.block + " " + ioe);
/* 615 */       IOUtils.closeStream(this);
/* 616 */       if (this.responder != null) {
/* 617 */         this.responder.interrupt();
/*     */       }
/* 619 */       cleanupBlock();
/* 620 */       throw ioe;
/*     */     } finally {
/* 622 */       if (this.responder != null) {
/*     */         try {
/* 624 */           this.responder.join();
/*     */         } catch (InterruptedException e) {
/* 626 */           throw new IOException("Interrupted receiveBlock");
/*     */         }
/* 628 */         this.responder = null;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void cleanupBlock()
/*     */     throws IOException
/*     */   {
/* 637 */     if (this.clientName.length() == 0)
/* 638 */       this.datanode.data.unfinalizeBlock(this.block);
/*     */   }
/*     */ 
/*     */   private void setBlockPosition(long offsetInBlock)
/*     */     throws IOException
/*     */   {
/* 646 */     if (this.finalized) {
/* 647 */       if (!this.isRecovery) {
/* 648 */         throw new IOException("Write to offset " + offsetInBlock + " of block " + this.block + " that is already finalized.");
/*     */       }
/*     */ 
/* 652 */       if (offsetInBlock > this.datanode.data.getLength(this.block)) {
/* 653 */         throw new IOException("Write to offset " + offsetInBlock + " of block " + this.block + " that is already finalized and is of size " + this.datanode.data.getLength(this.block));
/*     */       }
/*     */ 
/* 658 */       return;
/*     */     }
/*     */ 
/* 661 */     if (this.datanode.data.getChannelPosition(this.block, this.streams) == offsetInBlock) {
/* 662 */       return;
/*     */     }
/* 664 */     long offsetInChecksum = BlockMetadataHeader.getHeaderSize() + offsetInBlock / this.bytesPerChecksum * this.checksumSize;
/*     */ 
/* 666 */     if (this.out != null) {
/* 667 */       this.out.flush();
/*     */     }
/* 669 */     if (this.checksumOut != null) {
/* 670 */       this.checksumOut.flush();
/*     */     }
/*     */ 
/* 674 */     if (offsetInBlock % this.bytesPerChecksum != 0L) {
/* 675 */       LOG.info("setBlockPosition trying to set position to " + offsetInBlock + " for " + this.block + " which is not a multiple of bytesPerChecksum " + this.bytesPerChecksum);
/*     */ 
/* 679 */       computePartialChunkCrc(offsetInBlock, offsetInChecksum, this.bytesPerChecksum);
/*     */     }
/*     */ 
/* 682 */     if (LOG.isDebugEnabled()) {
/* 683 */       LOG.debug("Changing block file offset of block " + this.block + " from " + this.datanode.data.getChannelPosition(this.block, this.streams) + " to " + offsetInBlock + " meta file offset to " + offsetInChecksum);
/*     */     }
/*     */ 
/* 690 */     this.datanode.data.setChannelPosition(this.block, this.streams, offsetInBlock, offsetInChecksum);
/*     */   }
/*     */ 
/*     */   private void computePartialChunkCrc(long blkoff, long ckoff, int bytesPerChecksum)
/*     */     throws IOException
/*     */   {
/* 702 */     int sizePartialChunk = (int)(blkoff % bytesPerChecksum);
/* 703 */     int checksumSize = this.checksum.getChecksumSize();
/* 704 */     blkoff -= sizePartialChunk;
/* 705 */     LOG.info("computePartialChunkCrc sizePartialChunk " + sizePartialChunk + " " + this.block + " offset in block " + blkoff + " offset in metafile " + ckoff);
/*     */ 
/* 713 */     byte[] buf = new byte[sizePartialChunk];
/* 714 */     byte[] crcbuf = new byte[checksumSize];
/* 715 */     FSDatasetInterface.BlockInputStreams instr = null;
/*     */     try {
/* 717 */       instr = this.datanode.data.getTmpInputStreams(this.block, blkoff, ckoff);
/* 718 */       IOUtils.readFully(instr.dataIn, buf, 0, sizePartialChunk);
/*     */ 
/* 721 */       IOUtils.readFully(instr.checksumIn, crcbuf, 0, crcbuf.length);
/*     */     } finally {
/* 723 */       IOUtils.closeStream(instr);
/*     */     }
/*     */ 
/* 727 */     this.partialCrc = new PureJavaCrc32();
/* 728 */     this.partialCrc.update(buf, 0, sizePartialChunk);
/* 729 */     LOG.info("Read in partial CRC chunk from disk for " + this.block);
/*     */ 
/* 733 */     if (this.partialCrc.getValue() != FSInputChecker.checksum2long(crcbuf)) {
/* 734 */       String msg = "Partial CRC " + this.partialCrc.getValue() + " does not match value computed the " + " last time file was closed " + FSInputChecker.checksum2long(crcbuf);
/*     */ 
/* 738 */       throw new IOException(msg);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class Packet
/*     */   {
/*     */     long seqno;
/*     */     boolean lastPacketInBlock;
/*     */ 
/*     */     Packet(long seqno, boolean lastPacketInBlock)
/*     */     {
/* 968 */       this.seqno = seqno;
/* 969 */       this.lastPacketInBlock = lastPacketInBlock;
/*     */     }
/*     */   }
/*     */ 
/*     */   class PacketResponder
/*     */     implements Runnable, FSConstants
/*     */   {
/* 752 */     private LinkedList<BlockReceiver.Packet> ackQueue = new LinkedList();
/* 753 */     private volatile boolean running = true;
/*     */     private Block block;
/*     */     DataInputStream mirrorIn;
/*     */     DataOutputStream replyOut;
/*     */     private int numTargets;
/*     */     private BlockReceiver receiver;
/*     */     private Thread receiverThread;
/*     */ 
/*     */     public String toString()
/*     */     {
/* 762 */       return "PacketResponder " + this.numTargets + " for " + this.block;
/*     */     }
/*     */ 
/*     */     PacketResponder(BlockReceiver receiver, Block b, DataInputStream in, DataOutputStream out, int numTargets, Thread receiverThread)
/*     */     {
/* 768 */       this.receiver = receiver;
/* 769 */       this.block = b;
/* 770 */       this.mirrorIn = in;
/* 771 */       this.replyOut = out;
/* 772 */       this.numTargets = numTargets;
/* 773 */       this.receiverThread = receiverThread;
/*     */     }
/*     */ 
/*     */     synchronized void enqueue(long seqno, boolean lastPacketInBlock)
/*     */     {
/* 782 */       if (this.running) {
/* 783 */         BlockReceiver.LOG.debug("PacketResponder " + this.numTargets + " adding seqno " + seqno + " to ack queue.");
/*     */ 
/* 785 */         this.ackQueue.addLast(new BlockReceiver.Packet(seqno, lastPacketInBlock));
/* 786 */         notifyAll();
/*     */       }
/*     */     }
/*     */ 
/*     */     synchronized void close()
/*     */     {
/* 794 */       while ((this.running) && (this.ackQueue.size() != 0) && (BlockReceiver.this.datanode.shouldRun)) {
/*     */         try {
/* 796 */           wait();
/*     */         } catch (InterruptedException e) {
/* 798 */           this.running = false;
/*     */         }
/*     */       }
/* 801 */       BlockReceiver.LOG.debug("PacketResponder " + this.numTargets + " for block " + this.block + " Closing down.");
/*     */ 
/* 803 */       this.running = false;
/* 804 */       notifyAll();
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 812 */       boolean lastPacketInBlock = false;
/* 813 */       boolean isInterrupted = false;
/* 814 */       long startTime = BlockReceiver.ClientTraceLog.isInfoEnabled() ? System.nanoTime() : 0L;
/* 815 */       while ((this.running) && (BlockReceiver.this.datanode.shouldRun) && (!lastPacketInBlock))
/*     */       {
/*     */         try
/*     */         {
/* 825 */           long expected = -2L;
/* 826 */           long seqno = -2L;
/*     */ 
/* 828 */           DataTransferProtocol.PipelineAck ack = new DataTransferProtocol.PipelineAck();
/* 829 */           boolean localMirrorError = BlockReceiver.this.mirrorError;
/*     */           try {
/* 831 */             BlockReceiver.Packet pkt = null;
/* 832 */             synchronized (this)
/*     */             {
/* 834 */               while ((this.running) && (BlockReceiver.this.datanode.shouldRun) && (this.ackQueue.size() == 0)) {
/* 835 */                 if (BlockReceiver.LOG.isDebugEnabled()) {
/* 836 */                   BlockReceiver.LOG.debug("PacketResponder " + this.numTargets + " seqno = " + seqno + " for block " + this.block + " waiting for local datanode to finish write.");
/*     */                 }
/*     */ 
/* 841 */                 wait();
/*     */               }
/* 843 */               if ((this.running) && (!BlockReceiver.this.datanode.shouldRun)) {
/*     */                 break;
/*     */               }
/* 846 */               pkt = (BlockReceiver.Packet)this.ackQueue.removeFirst();
/* 847 */               expected = pkt.seqno;
/* 848 */               notifyAll();
/*     */             }
/*     */ 
/* 851 */             if ((this.numTargets > 0) && (!localMirrorError))
/*     */             {
/* 853 */               ack.readFields(this.mirrorIn);
/* 854 */               if (BlockReceiver.LOG.isDebugEnabled()) {
/* 855 */                 BlockReceiver.LOG.debug("PacketResponder " + this.numTargets + " for block " + this.block + " got " + ack);
/*     */               }
/*     */ 
/* 858 */               seqno = ack.getSeqno();
/*     */ 
/* 860 */               if (seqno != expected) {
/* 861 */                 throw new IOException("PacketResponder " + this.numTargets + " for block " + this.block + " expected seqno:" + expected + " received:" + seqno);
/*     */               }
/*     */ 
/*     */             }
/*     */ 
/* 867 */             lastPacketInBlock = pkt.lastPacketInBlock;
/*     */           } catch (InterruptedException ine) {
/* 869 */             isInterrupted = true;
/*     */           } catch (IOException ioe) {
/* 871 */             if (Thread.interrupted()) {
/* 872 */               isInterrupted = true;
/*     */             }
/*     */             else
/*     */             {
/* 877 */               BlockReceiver.this.mirrorError = true;
/* 878 */               BlockReceiver.LOG.info("PacketResponder " + this.block + " " + this.numTargets + " Exception " + StringUtils.stringifyException(ioe));
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 883 */           if ((Thread.interrupted()) || (isInterrupted))
/*     */           {
/* 891 */             BlockReceiver.LOG.info("PacketResponder " + this.block + " " + this.numTargets + " : Thread is interrupted.");
/*     */ 
/* 893 */             break;
/*     */           }
/*     */ 
/* 898 */           if ((lastPacketInBlock) && (!this.receiver.finalized)) {
/* 899 */             this.receiver.close();
/* 900 */             long endTime = BlockReceiver.ClientTraceLog.isInfoEnabled() ? System.nanoTime() : 0L;
/* 901 */             this.block.setNumBytes(this.receiver.offsetInBlock);
/* 902 */             BlockReceiver.this.datanode.data.finalizeBlock(this.block);
/* 903 */             BlockReceiver.this.datanode.myMetrics.incrBlocksWritten();
/* 904 */             BlockReceiver.this.datanode.notifyNamenodeReceivedBlock(this.block, "");
/*     */ 
/* 906 */             if ((BlockReceiver.ClientTraceLog.isInfoEnabled()) && (this.receiver.clientName.length() > 0))
/*     */             {
/* 908 */               long offset = 0L;
/* 909 */               BlockReceiver.ClientTraceLog.info(String.format("src: %s, dest: %s, bytes: %s, op: %s, cliID: %s, offset: %s, srvID: %s, blockid: %s, duration: %s", new Object[] { this.receiver.inAddr, this.receiver.myAddr, Long.valueOf(this.block.getNumBytes()), "HDFS_WRITE", this.receiver.clientName, Long.valueOf(offset), BlockReceiver.this.datanode.dnRegistration.getStorageID(), this.block, Long.valueOf(endTime - startTime) }));
/*     */             }
/*     */             else
/*     */             {
/* 914 */               BlockReceiver.LOG.info("Received " + this.block + " of size " + this.block.getNumBytes() + " from " + this.receiver.inAddr);
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 920 */           short[] replies = null;
/* 921 */           if (BlockReceiver.this.mirrorError) {
/* 922 */             replies = new short[2];
/* 923 */             replies[0] = 0;
/* 924 */             replies[1] = 1;
/*     */           } else {
/* 926 */             short ackLen = this.numTargets == 0 ? 0 : ack.getNumOfReplies();
/* 927 */             replies = new short[1 + ackLen];
/* 928 */             replies[0] = 0;
/* 929 */             for (int i = 0; i < ackLen; i++) {
/* 930 */               replies[(i + 1)] = ack.getReply(i);
/*     */             }
/*     */           }
/* 933 */           DataTransferProtocol.PipelineAck replyAck = new DataTransferProtocol.PipelineAck(expected, replies);
/*     */ 
/* 936 */           replyAck.write(this.replyOut);
/* 937 */           this.replyOut.flush();
/* 938 */           if (BlockReceiver.LOG.isDebugEnabled()) {
/* 939 */             BlockReceiver.LOG.debug("PacketResponder " + this.numTargets + " for block " + this.block + " responded an ack: " + replyAck);
/*     */           }
/*     */         }
/*     */         catch (Throwable e)
/*     */         {
/* 944 */           BlockReceiver.LOG.warn("IOException in BlockReceiver.run(): ", e);
/* 945 */           if (this.running) {
/* 946 */             BlockReceiver.LOG.info("PacketResponder " + this.block + " " + this.numTargets + " Exception " + StringUtils.stringifyException(e));
/*     */ 
/* 948 */             this.running = false;
/*     */           }
/* 950 */           if (!Thread.interrupted()) {
/* 951 */             this.receiverThread.interrupt();
/*     */           }
/*     */         }
/*     */       }
/* 955 */       BlockReceiver.LOG.info("PacketResponder " + this.numTargets + " for " + this.block + " terminating");
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.BlockReceiver
 * JD-Core Version:    0.6.1
 */
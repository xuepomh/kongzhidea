/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.SingleThreadModel;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.jsp.JspFactory;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.SkipPageException;
/*     */ import org.apache.hadoop.hdfs.server.common.Storage.StorageDirectory;
/*     */ import org.apache.hadoop.util.ServletUtil;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ import org.apache.hadoop.util.VersionInfo;
/*     */ import org.apache.jasper.runtime.HttpJspBase;
/*     */ import org.apache.jasper.runtime.JspSourceDependent;
/*     */ import org.apache.jasper.runtime.ResourceInjector;
/*     */ 
/*     */ public final class dfshealth_jsp extends HttpJspBase
/*     */   implements JspSourceDependent, SingleThreadModel
/*     */ {
/*  42 */   JspHelper jspHelper = new JspHelper();
/*     */ 
/*  44 */   int rowNum = 0;
/*  45 */   int colNum = 0;
/*     */ 
/*  53 */   long diskBytes = 1073741824L;
/*  54 */   String diskByteStr = "GB";
/*     */ 
/*  56 */   String sorterField = null;
/*  57 */   String sorterOrder = null;
/*     */ 
/* 255 */   private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();
/*     */   private static Vector _jspx_dependants;
/*     */   private ResourceInjector _jspx_resourceInjector;
/*     */ 
/*     */   String rowTxt()
/*     */   {
/*  47 */     this.colNum = 0;
/*  48 */     return new StringBuilder().append("<tr class=\"").append(this.rowNum++ % 2 == 0 ? "rowNormal" : "rowAlt").append("\"> ").toString();
/*     */   }
/*  50 */   String colTxt() { return new StringBuilder().append("<td id=\"col").append(++this.colNum).append("\"> ").toString(); } 
/*  51 */   void counterReset() { this.colNum = 0; this.rowNum = 0;
/*     */   }
/*     */ 
/*     */   String NodeHeaderStr(String name)
/*     */   {
/*  60 */     String ret = "class=header";
/*  61 */     String order = "ASC";
/*  62 */     if (name.equals(this.sorterField)) {
/*  63 */       ret = new StringBuilder().append(ret).append(this.sorterOrder).toString();
/*  64 */       if (this.sorterOrder.equals("ASC"))
/*  65 */         order = "DSC";
/*     */     }
/*  67 */     ret = new StringBuilder().append(ret).append(" onClick=\"window.document.location='/dfshealth.jsp?sorter/field=").append(name).append("&sorter/order=").append(order).append("'\" title=\"sort on this column\"").toString();
/*     */ 
/*  71 */     return ret;
/*     */   }
/*     */ 
/*     */   public void generateNodeData(JspWriter out, DatanodeDescriptor d, String suffix, boolean alive, int nnHttpPort)
/*     */     throws IOException
/*     */   {
/*  92 */     String url = new StringBuilder().append("http://").append(d.getHostName()).append(":").append(d.getInfoPort()).append("/browseDirectory.jsp?namenodeInfoPort=").append(nnHttpPort).append("&dir=").append(URLEncoder.encode("/", "UTF-8")).toString();
/*     */ 
/*  97 */     String name = new StringBuilder().append(d.getHostName()).append(":").append(d.getPort()).toString();
/*  98 */     if (!name.matches("\\d+\\.\\d+.\\d+\\.\\d+.*"))
/*  99 */       name = name.replaceAll("\\.[^.:]*", "");
/* 100 */     int idx = (suffix != null) && (name.endsWith(suffix)) ? name.indexOf(suffix) : -1;
/*     */ 
/* 103 */     out.print(new StringBuilder().append(rowTxt()).append("<td class=\"name\"><a title=\"").append(d.getHost()).append(":").append(d.getPort()).append("\" href=\"").append(url).append("\">").append(idx > 0 ? name.substring(0, idx) : name).append("</a>").append(alive ? "" : "\n").toString());
/*     */ 
/* 108 */     if (!alive) {
/* 109 */       return;
/*     */     }
/* 111 */     long c = d.getCapacity();
/* 112 */     long u = d.getDfsUsed();
/* 113 */     long nu = d.getNonDfsUsed();
/* 114 */     long r = d.getRemaining();
/* 115 */     String percentUsed = StringUtils.limitDecimalTo2(d.getDfsUsedPercent());
/* 116 */     String percentRemaining = StringUtils.limitDecimalTo2(d.getRemainingPercent());
/*     */ 
/* 118 */     String adminState = d.isDecommissionInProgress() ? "Decommission In Progress" : d.isDecommissioned() ? "Decommissioned" : "In Service";
/*     */ 
/* 122 */     long timestamp = d.getLastUpdate();
/* 123 */     long currentTime = System.currentTimeMillis();
/* 124 */     out.print(new StringBuilder().append("<td class=\"lastcontact\"> ").append((currentTime - timestamp) / 1000L).append("<td class=\"adminstate\">").append(adminState).append("<td align=\"right\" class=\"capacity\">").append(StringUtils.limitDecimalTo2(c * 1.0D / this.diskBytes)).append("<td align=\"right\" class=\"used\">").append(StringUtils.limitDecimalTo2(u * 1.0D / this.diskBytes)).append("<td align=\"right\" class=\"nondfsused\">").append(StringUtils.limitDecimalTo2(nu * 1.0D / this.diskBytes)).append("<td align=\"right\" class=\"remaining\">").append(StringUtils.limitDecimalTo2(r * 1.0D / this.diskBytes)).append("<td align=\"right\" class=\"pcused\">").append(percentUsed).append("<td class=\"pcused\">").append(ServletUtil.percentageGraph((int)Double.parseDouble(percentUsed), 100)).append("<td align=\"right\" class=\"pcremaining`\">").append(percentRemaining).append("<td title=").append("\"blocks scheduled : ").append(d.getBlocksScheduled()).append("\" class=\"blocks\">").append(d.numBlocks()).append("\n").toString());
/*     */   }
/*     */ 
/*     */   public void generateConfReport(JspWriter out, FSNamesystem fsn, HttpServletRequest request)
/*     */     throws IOException
/*     */   {
/* 149 */     long underReplicatedBlocks = fsn.getUnderReplicatedBlocks();
/* 150 */     FSImage fsImage = fsn.getFSImage();
/* 151 */     List removedStorageDirs = fsImage.getRemovedStorageDirs();
/* 152 */     String storageDirsSizeStr = ""; String removedStorageDirsSizeStr = ""; String storageDirsStr = ""; String removedStorageDirsStr = ""; String storageDirsDiv = ""; String removedStorageDirsDiv = "";
/*     */ 
/* 155 */     out.print("<h3> NameNode Storage: </h3>");
/* 156 */     out.print("<div id=\"dfstable\"> <table border=1 cellpadding=10 cellspacing=0 title=\"NameNode Storage\">\n<thead><tr><td><b>Storage Directory</b></td><td><b>Type</b></td><td><b>State</b></td></tr></thead>");
/*     */ 
/* 159 */     Storage.StorageDirectory st = null;
/* 160 */     for (Iterator it = fsImage.dirIterator(); it.hasNext(); ) {
/* 161 */       st = (Storage.StorageDirectory)it.next();
/* 162 */       String dir = new StringBuilder().append("").append(st.getRoot()).toString();
/* 163 */       String type = new StringBuilder().append("").append(st.getStorageDirType()).toString();
/* 164 */       out.print(new StringBuilder().append("<tr><td>").append(dir).append("</td><td>").append(type).append("</td><td>Active</td></tr>").toString());
/*     */     }
/*     */ 
/* 167 */     long storageDirsSize = removedStorageDirs.size();
/* 168 */     for (int i = 0; i < storageDirsSize; i++) {
/* 169 */       st = (Storage.StorageDirectory)removedStorageDirs.get(i);
/* 170 */       String dir = new StringBuilder().append("").append(st.getRoot()).toString();
/* 171 */       String type = new StringBuilder().append("").append(st.getStorageDirType()).toString();
/* 172 */       out.print(new StringBuilder().append("<tr><td>").append(dir).append("</td><td>").append(type).append("</td><td><font color=red>Failed</font></td></tr>").toString());
/*     */     }
/*     */ 
/* 175 */     out.print("</table></div><br>\n");
/*     */   }
/*     */ 
/*     */   public void generateDFSHealthReport(JspWriter out, NameNode nn, HttpServletRequest request)
/*     */     throws IOException
/*     */   {
/* 183 */     FSNamesystem fsn = nn.getNamesystem();
/* 184 */     ArrayList live = new ArrayList();
/* 185 */     ArrayList dead = new ArrayList();
/* 186 */     this.jspHelper.DFSNodesStatus(live, dead);
/*     */ 
/* 188 */     ArrayList decommissioning = fsn.getDecommissioningNodes();
/*     */ 
/* 191 */     this.sorterField = request.getParameter("sorter/field");
/* 192 */     this.sorterOrder = request.getParameter("sorter/order");
/* 193 */     if (this.sorterField == null)
/* 194 */       this.sorterField = "name";
/* 195 */     if (this.sorterOrder == null) {
/* 196 */       this.sorterOrder = "ASC";
/*     */     }
/*     */ 
/* 199 */     String port_suffix = null;
/* 200 */     if (live.size() > 0) {
/* 201 */       String name = ((DatanodeDescriptor)live.get(0)).getName();
/* 202 */       int idx = name.indexOf(':');
/* 203 */       if (idx > 0) {
/* 204 */         port_suffix = name.substring(idx);
/*     */       }
/*     */ 
/* 207 */       for (int i = 1; (port_suffix != null) && (i < live.size()); i++) {
/* 208 */         if (!((DatanodeDescriptor)live.get(i)).getName().endsWith(port_suffix)) {
/* 209 */           port_suffix = null;
/* 210 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 215 */     counterReset();
/*     */ 
/* 217 */     long total = fsn.getCapacityTotal();
/* 218 */     long remaining = fsn.getCapacityRemaining();
/* 219 */     long used = fsn.getCapacityUsed();
/* 220 */     long nonDFS = fsn.getCapacityUsedNonDFS();
/* 221 */     float percentUsed = fsn.getCapacityUsedPercent();
/* 222 */     float percentRemaining = fsn.getCapacityRemainingPercent();
/*     */ 
/* 224 */     out.print(new StringBuilder().append("<div id=\"dfstable\"> <table>\n").append(rowTxt()).append(colTxt()).append("Configured Capacity").append(colTxt()).append(":").append(colTxt()).append(StringUtils.byteDesc(total)).append(rowTxt()).append(colTxt()).append("DFS Used").append(colTxt()).append(":").append(colTxt()).append(StringUtils.byteDesc(used)).append(rowTxt()).append(colTxt()).append("Non DFS Used").append(colTxt()).append(":").append(colTxt()).append(StringUtils.byteDesc(nonDFS)).append(rowTxt()).append(colTxt()).append("DFS Remaining").append(colTxt()).append(":").append(colTxt()).append(StringUtils.byteDesc(remaining)).append(rowTxt()).append(colTxt()).append("DFS Used%").append(colTxt()).append(":").append(colTxt()).append(StringUtils.limitDecimalTo2(percentUsed)).append(" %").append(rowTxt()).append(colTxt()).append("DFS Remaining%").append(colTxt()).append(":").append(colTxt()).append(StringUtils.limitDecimalTo2(percentRemaining)).append(" %").append(rowTxt()).append(colTxt()).append("<a href=\"dfsnodelist.jsp?whatNodes=LIVE\">Live Nodes</a> ").append(colTxt()).append(":").append(colTxt()).append(live.size()).append(rowTxt()).append(colTxt()).append("<a href=\"dfsnodelist.jsp?whatNodes=DEAD\">Dead Nodes</a> ").append(colTxt()).append(":").append(colTxt()).append(dead.size()).append(rowTxt()).append(colTxt()).append("<a href=\"dfsnodelist.jsp?whatNodes=DECOMMISSIONING\">").append("Decommissioning Nodes</a> ").append(colTxt()).append(":").append(colTxt()).append(decommissioning.size()).append(rowTxt()).append(colTxt()).append("Number of Under-Replicated Blocks").append(colTxt()).append(":").append(colTxt()).append(fsn.getUnderReplicatedBlocks()).append("</table></div><br>\n").toString());
/*     */ 
/* 251 */     if ((live.isEmpty()) && (dead.isEmpty()))
/* 252 */       out.print("There are no datanodes in the cluster");
/*     */   }
/*     */ 
/*     */   public Object getDependants()
/*     */   {
/* 262 */     return _jspx_dependants;
/*     */   }
/*     */ 
/*     */   public void _jspService(HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException, ServletException
/*     */   {
/* 268 */     PageContext pageContext = null;
/* 269 */     HttpSession session = null;
/* 270 */     ServletContext application = null;
/* 271 */     ServletConfig config = null;
/* 272 */     JspWriter out = null;
/* 273 */     Object page = this;
/* 274 */     JspWriter _jspx_out = null;
/* 275 */     PageContext _jspx_page_context = null;
/*     */     try
/*     */     {
/* 278 */       response.setContentType("text/html; charset=UTF-8");
/* 279 */       pageContext = _jspxFactory.getPageContext(this, request, response, null, true, 8192, true);
/*     */ 
/* 281 */       _jspx_page_context = pageContext;
/* 282 */       application = pageContext.getServletContext();
/* 283 */       config = pageContext.getServletConfig();
/* 284 */       session = pageContext.getSession();
/* 285 */       out = pageContext.getOut();
/* 286 */       _jspx_out = out;
/* 287 */       this._jspx_resourceInjector = ((ResourceInjector)application.getAttribute("com.sun.appserv.jsp.resource.injector"));
/*     */ 
/* 289 */       out.write(10);
/* 290 */       out.write(10);
/* 291 */       out.write(10);
/* 292 */       out.write(10);
/*     */ 
/* 294 */       NameNode nn = (NameNode)application.getAttribute("name.node");
/* 295 */       FSNamesystem fsn = nn.getNamesystem();
/* 296 */       String namenodeLabel = new StringBuilder().append(nn.getNameNodeAddress().getHostName()).append(":").append(nn.getNameNodeAddress().getPort()).toString();
/*     */ 
/* 298 */       out.write("\n\n<!DOCTYPE html>\n<html>\n\n<link rel=\"stylesheet\" type=\"text/css\" href=\"/static/hadoop.css\">\n<title>Hadoop NameNode ");
/* 299 */       out.print(namenodeLabel);
/* 300 */       out.write("</title>\n    \n<body>\n<h1>NameNode '");
/* 301 */       out.print(namenodeLabel);
/* 302 */       out.write("'</h1>\n\n\n<div id=\"dfstable\"> <table>\t  \n<tr> <td id=\"col1\"> Started: <td> ");
/* 303 */       out.print(fsn.getStartTime());
/* 304 */       out.write("\n<tr> <td id=\"col1\"> Version: <td> ");
/* 305 */       out.print(VersionInfo.getVersion());
/* 306 */       out.write(", r");
/* 307 */       out.print(VersionInfo.getRevision());
/* 308 */       out.write("\n<tr> <td id=\"col1\"> Compiled: <td> ");
/* 309 */       out.print(VersionInfo.getDate());
/* 310 */       out.write(" by ");
/* 311 */       out.print(VersionInfo.getUser());
/* 312 */       out.write("\n<tr> <td id=\"col1\"> Upgrades: <td> ");
/* 313 */       out.print(this.jspHelper.getUpgradeStatusText());
/* 314 */       out.write("\n</table></div><br>\t\t\t\t      \n\n<b><a href=\"/nn_browsedfscontent.jsp\">Browse the filesystem</a></b><br>\n<b><a href=\"/logs/\">Namenode Logs</a></b>\n\n<hr>\n<h3>Cluster Summary</h3>\n<b> ");
/* 315 */       out.print(this.jspHelper.getSafeModeText());
/* 316 */       out.write(" </b>\n<b> ");
/* 317 */       out.print(this.jspHelper.getInodeLimitText());
/* 318 */       out.write(" </b>\n<a class=\"warning\" href=\"/corrupt_files.jsp\" title=\"List corrupt files\">\n  ");
/* 319 */       out.print(JspHelper.getWarningText(fsn));
/* 320 */       out.write("\n</a>\n\n\n");
/*     */ 
/* 322 */       generateDFSHealthReport(out, nn, request);
/*     */ 
/* 324 */       out.write("\n<hr>\n");
/*     */ 
/* 326 */       generateConfReport(out, fsn, request);
/*     */ 
/* 328 */       out.write(10);
/*     */ 
/* 330 */       out.println(ServletUtil.htmlFooter());
/*     */ 
/* 332 */       out.write(10);
/*     */     } catch (Throwable t) {
/* 334 */       if (!(t instanceof SkipPageException)) {
/* 335 */         out = _jspx_out;
/* 336 */         if ((out != null) && (out.getBufferSize() != 0))
/* 337 */           out.clearBuffer();
/* 338 */         if (_jspx_page_context != null) _jspx_page_context.handlePageException(t); 
/*     */       }
/*     */     }
/* 341 */     finally { _jspxFactory.releasePageContext(_jspx_page_context); }
/*     */ 
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.dfshealth_jsp
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs.server.datanode.web.resources;
/*     */ 
/*     */ import com.sun.jersey.spi.container.ResourceFilters;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.ws.rs.Consumes;
/*     */ import javax.ws.rs.DefaultValue;
/*     */ import javax.ws.rs.GET;
/*     */ import javax.ws.rs.POST;
/*     */ import javax.ws.rs.PUT;
/*     */ import javax.ws.rs.Path;
/*     */ import javax.ws.rs.PathParam;
/*     */ import javax.ws.rs.Produces;
/*     */ import javax.ws.rs.QueryParam;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.core.Response;
/*     */ import javax.ws.rs.core.Response.ResponseBuilder;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FSDataOutputStream;
/*     */ import org.apache.hadoop.fs.MD5MD5CRC32FileChecksum;
/*     */ import org.apache.hadoop.hdfs.DFSClient;
/*     */ import org.apache.hadoop.hdfs.DFSClient.DFSDataInputStream;
/*     */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenIdentifier;
/*     */ import org.apache.hadoop.hdfs.server.datanode.DataNode;
/*     */ import org.apache.hadoop.hdfs.server.namenode.NameNode;
/*     */ import org.apache.hadoop.hdfs.web.JsonUtil;
/*     */ import org.apache.hadoop.hdfs.web.ParamFilter;
/*     */ import org.apache.hadoop.hdfs.web.resources.BlockSizeParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.BufferSizeParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.DelegationParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.GetOpParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.GetOpParam.Op;
/*     */ import org.apache.hadoop.hdfs.web.resources.HttpOpParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.HttpOpParam.Op;
/*     */ import org.apache.hadoop.hdfs.web.resources.LengthParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.OffsetParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.OverwriteParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.Param;
/*     */ import org.apache.hadoop.hdfs.web.resources.PermissionParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.PostOpParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.PostOpParam.Op;
/*     */ import org.apache.hadoop.hdfs.web.resources.PutOpParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.PutOpParam.Op;
/*     */ import org.apache.hadoop.hdfs.web.resources.ReplicationParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.UriFsPathParam;
/*     */ import org.apache.hadoop.io.IOUtils;
/*     */ import org.apache.hadoop.security.SecurityUtil;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.token.Token;
/*     */ 
/*     */ @Path("")
/*     */ @ResourceFilters({ParamFilter.class})
/*     */ public class DatanodeWebHdfsMethods
/*     */ {
/*  81 */   public static final Log LOG = LogFactory.getLog(DatanodeWebHdfsMethods.class);
/*     */ 
/*  83 */   private static final UriFsPathParam ROOT = new UriFsPathParam("");
/*     */ 
/*     */   @Context
/*     */   private ServletContext context;
/*     */ 
/*     */   @Context
/*     */   private HttpServletResponse response;
/*     */ 
/*  91 */   private void init(UserGroupInformation ugi, DelegationParam delegation, UriFsPathParam path, HttpOpParam<?> op, Param<?, ?>[] parameters) throws IOException { if (LOG.isTraceEnabled()) {
/*  92 */       LOG.trace("HTTP " + ((HttpOpParam.Op)op.getValue()).getType() + ": " + op + ", " + path + ", ugi=" + ugi + Param.toSortedString(", ", parameters));
/*     */     }
/*     */ 
/*  97 */     this.response.setContentType(null);
/*     */ 
/*  99 */     if (UserGroupInformation.isSecurityEnabled())
/*     */     {
/* 101 */       DataNode datanode = (DataNode)this.context.getAttribute("datanode");
/* 102 */       InetSocketAddress nnRpcAddr = NameNode.getAddress(datanode.getConf());
/* 103 */       Token token = new Token();
/* 104 */       token.decodeFromUrlString((String)delegation.getValue());
/* 105 */       SecurityUtil.setTokenService(token, nnRpcAddr);
/* 106 */       token.setKind(DelegationTokenIdentifier.HDFS_DELEGATION_KIND);
/* 107 */       ugi.addToken(token);
/*     */     }
/*     */   }
/*     */ 
/*     */   @PUT
/*     */   @Path("/")
/*     */   @Consumes({"*/*"})
/*     */   @Produces({"application/octet-stream", "application/json"})
/*     */   public Response putRoot(InputStream in, @Context UserGroupInformation ugi, @QueryParam("delegation") @DefaultValue("") DelegationParam delegation, @QueryParam("op") @DefaultValue("null") PutOpParam op, @QueryParam("permission") @DefaultValue("null") PermissionParam permission, @QueryParam("overwrite") @DefaultValue("false") OverwriteParam overwrite, @QueryParam("buffersize") @DefaultValue("null") BufferSizeParam bufferSize, @QueryParam("replication") @DefaultValue("null") ReplicationParam replication, @QueryParam("blocksize") @DefaultValue("null") BlockSizeParam blockSize)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 134 */     return put(in, ugi, delegation, ROOT, op, permission, overwrite, bufferSize, replication, blockSize);
/*     */   }
/*     */ 
/*     */   @PUT
/*     */   @Path("{path:.*}")
/*     */   @Consumes({"*/*"})
/*     */   @Produces({"application/octet-stream", "application/json"})
/*     */   public Response put(final InputStream in, @Context UserGroupInformation ugi, @QueryParam("delegation") @DefaultValue("") DelegationParam delegation, @PathParam("path") final UriFsPathParam path, @QueryParam("op") @DefaultValue("null") final PutOpParam op, @QueryParam("permission") @DefaultValue("null") final PermissionParam permission, @QueryParam("overwrite") @DefaultValue("false") final OverwriteParam overwrite, @QueryParam("buffersize") @DefaultValue("null") final BufferSizeParam bufferSize, @QueryParam("replication") @DefaultValue("null") final ReplicationParam replication, @QueryParam("blocksize") @DefaultValue("null") final BlockSizeParam blockSize)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 163 */     init(ugi, delegation, path, op, new Param[] { permission, overwrite, bufferSize, replication, blockSize });
/*     */ 
/* 166 */     return (Response)ugi.doAs(new PrivilegedExceptionAction()
/*     */     {
/*     */       public Response run() throws IOException, URISyntaxException
/*     */       {
/* 170 */         String fullpath = path.getAbsolutePath();
/* 171 */         DataNode datanode = (DataNode)DatanodeWebHdfsMethods.this.context.getAttribute("datanode");
/*     */ 
/* 173 */         switch (DatanodeWebHdfsMethods.4.$SwitchMap$org$apache$hadoop$hdfs$web$resources$PutOpParam$Op[((PutOpParam.Op)op.getValue()).ordinal()])
/*     */         {
/*     */         case 1:
/* 176 */           Configuration conf = new Configuration(datanode.getConf());
/* 177 */           conf.set("dfs.umaskmode", "000");
/*     */ 
/* 179 */           int b = bufferSize.getValue(conf);
/* 180 */           DFSClient dfsclient = new DFSClient(conf);
/* 181 */           FSDataOutputStream out = null;
/*     */           try {
/* 183 */             out = new FSDataOutputStream(dfsclient.create(fullpath, permission.getFsPermission(), ((Boolean)overwrite.getValue()).booleanValue(), replication.getValue(conf), blockSize.getValue(conf), null, b), null);
/*     */ 
/* 186 */             IOUtils.copyBytes(in, out, b);
/* 187 */             out.close();
/* 188 */             out = null;
/* 189 */             dfsclient.close();
/* 190 */             dfsclient = null;
/*     */           } finally {
/* 192 */             IOUtils.cleanup(DatanodeWebHdfsMethods.LOG, new Closeable[] { out });
/* 193 */             IOUtils.cleanup(DatanodeWebHdfsMethods.LOG, new Closeable[] { dfsclient });
/*     */           }
/* 195 */           String nnAddr = NameNode.getInfoServer(conf);
/* 196 */           URI uri = new URI("webhdfs://" + nnAddr + fullpath);
/* 197 */           return Response.created(uri).type("application/octet-stream").build();
/*     */         }
/*     */ 
/* 200 */         throw new UnsupportedOperationException(op + " is not supported");
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   @POST
/*     */   @Path("/")
/*     */   @Consumes({"*/*"})
/*     */   @Produces({"application/octet-stream", "application/json"})
/*     */   public Response postRoot(InputStream in, @Context UserGroupInformation ugi, @QueryParam("delegation") @DefaultValue("") DelegationParam delegation, @QueryParam("op") @DefaultValue("null") PostOpParam op, @QueryParam("buffersize") @DefaultValue("null") BufferSizeParam bufferSize)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 221 */     return post(in, ugi, delegation, ROOT, op, bufferSize);
/*     */   }
/*     */ 
/*     */   @POST
/*     */   @Path("{path:.*}")
/*     */   @Consumes({"*/*"})
/*     */   @Produces({"application/octet-stream", "application/json"})
/*     */   public Response post(final InputStream in, @Context UserGroupInformation ugi, @QueryParam("delegation") @DefaultValue("") DelegationParam delegation, @PathParam("path") final UriFsPathParam path, @QueryParam("op") @DefaultValue("null") final PostOpParam op, @QueryParam("buffersize") @DefaultValue("null") final BufferSizeParam bufferSize)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 241 */     init(ugi, delegation, path, op, new Param[] { bufferSize });
/*     */ 
/* 243 */     return (Response)ugi.doAs(new PrivilegedExceptionAction()
/*     */     {
/*     */       public Response run() throws IOException
/*     */       {
/* 247 */         String fullpath = path.getAbsolutePath();
/* 248 */         DataNode datanode = (DataNode)DatanodeWebHdfsMethods.this.context.getAttribute("datanode");
/*     */ 
/* 250 */         switch (DatanodeWebHdfsMethods.4.$SwitchMap$org$apache$hadoop$hdfs$web$resources$PostOpParam$Op[((PostOpParam.Op)op.getValue()).ordinal()])
/*     */         {
/*     */         case 1:
/* 253 */           Configuration conf = new Configuration(datanode.getConf());
/* 254 */           int b = bufferSize.getValue(conf);
/* 255 */           DFSClient dfsclient = new DFSClient(conf);
/* 256 */           FSDataOutputStream out = null;
/*     */           try {
/* 258 */             out = dfsclient.append(fullpath, b, null, null);
/* 259 */             IOUtils.copyBytes(in, out, b);
/* 260 */             out.close();
/* 261 */             out = null;
/* 262 */             dfsclient.close();
/* 263 */             dfsclient = null;
/*     */           } finally {
/* 265 */             IOUtils.cleanup(DatanodeWebHdfsMethods.LOG, new Closeable[] { out });
/* 266 */             IOUtils.cleanup(DatanodeWebHdfsMethods.LOG, new Closeable[] { dfsclient });
/*     */           }
/* 268 */           return Response.ok().type("application/octet-stream").build();
/*     */         }
/*     */ 
/* 271 */         throw new UnsupportedOperationException(op + " is not supported");
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   @GET
/*     */   @Path("/")
/*     */   @Produces({"application/octet-stream", "application/json"})
/*     */   public Response getRoot(@Context UserGroupInformation ugi, @QueryParam("delegation") @DefaultValue("") DelegationParam delegation, @QueryParam("op") @DefaultValue("null") GetOpParam op, @QueryParam("offset") @DefaultValue("0") OffsetParam offset, @QueryParam("length") @DefaultValue("null") LengthParam length, @QueryParam("buffersize") @DefaultValue("null") BufferSizeParam bufferSize)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 294 */     return get(ugi, delegation, ROOT, op, offset, length, bufferSize);
/*     */   }
/*     */ 
/*     */   @GET
/*     */   @Path("{path:.*}")
/*     */   @Produces({"application/octet-stream", "application/json"})
/*     */   public Response get(@Context UserGroupInformation ugi, @QueryParam("delegation") @DefaultValue("") DelegationParam delegation, @PathParam("path") final UriFsPathParam path, @QueryParam("op") @DefaultValue("null") final GetOpParam op, @QueryParam("offset") @DefaultValue("0") final OffsetParam offset, @QueryParam("length") @DefaultValue("null") final LengthParam length, @QueryParam("buffersize") @DefaultValue("null") final BufferSizeParam bufferSize)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 316 */     init(ugi, delegation, path, op, new Param[] { offset, length, bufferSize });
/*     */ 
/* 318 */     return (Response)ugi.doAs(new PrivilegedExceptionAction()
/*     */     {
/*     */       public Response run() throws IOException
/*     */       {
/* 322 */         String fullpath = path.getAbsolutePath();
/* 323 */         DataNode datanode = (DataNode)DatanodeWebHdfsMethods.this.context.getAttribute("datanode");
/* 324 */         Configuration conf = new Configuration(datanode.getConf());
/* 325 */         InetSocketAddress nnRpcAddr = NameNode.getAddress(conf);
/*     */ 
/* 327 */         switch (DatanodeWebHdfsMethods.4.$SwitchMap$org$apache$hadoop$hdfs$web$resources$GetOpParam$Op[((GetOpParam.Op)op.getValue()).ordinal()])
/*     */         {
/*     */         case 1:
/* 330 */           int b = bufferSize.getValue(conf);
/* 331 */           DFSClient dfsclient = new DFSClient(nnRpcAddr, conf);
/* 332 */           DFSClient.DFSDataInputStream in = null;
/*     */           try {
/* 334 */             in = new DFSClient.DFSDataInputStream(dfsclient.open(fullpath, b, true, null));
/*     */ 
/* 336 */             in.seek(((Long)offset.getValue()).longValue());
/*     */           } catch (IOException ioe) {
/* 338 */             IOUtils.cleanup(DatanodeWebHdfsMethods.LOG, new Closeable[] { in });
/* 339 */             IOUtils.cleanup(DatanodeWebHdfsMethods.LOG, new Closeable[] { dfsclient });
/* 340 */             throw ioe;
/*     */           }
/*     */ 
/* 343 */           long n = length.getValue() != null ? ((Long)length.getValue()).longValue() : in.getVisibleLength();
/*     */ 
/* 345 */           return Response.ok(new OpenEntity(in, n, dfsclient)).type("application/octet-stream").build();
/*     */         case 2:
/* 350 */           MD5MD5CRC32FileChecksum checksum = null;
/* 351 */           DFSClient dfsclient = new DFSClient(nnRpcAddr, conf);
/*     */           try {
/* 353 */             checksum = dfsclient.getFileChecksum(fullpath);
/* 354 */             dfsclient.close();
/* 355 */             dfsclient = null;
/*     */           } finally {
/* 357 */             IOUtils.cleanup(DatanodeWebHdfsMethods.LOG, new Closeable[] { dfsclient });
/*     */           }
/* 359 */           String js = JsonUtil.toJsonString(checksum);
/* 360 */           return Response.ok(js).type("application/json").build();
/*     */         }
/*     */ 
/* 363 */         throw new UnsupportedOperationException(op + " is not supported");
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.web.resources.DatanodeWebHdfsMethods
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ 
/*     */ abstract class EditLogOutputStream extends OutputStream
/*     */ {
/*     */   private long numSync;
/*     */   private long totalTimeSync;
/*     */ 
/*     */   EditLogOutputStream()
/*     */     throws IOException
/*     */   {
/*  35 */     this.numSync = (this.totalTimeSync = 0L);
/*     */   }
/*     */ 
/*     */   abstract String getName();
/*     */ 
/*     */   public abstract void write(int paramInt)
/*     */     throws IOException;
/*     */ 
/*     */   abstract void write(byte paramByte, Writable[] paramArrayOfWritable)
/*     */     throws IOException;
/*     */ 
/*     */   abstract void create()
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void close()
/*     */     throws IOException;
/*     */ 
/*     */   abstract void setReadyToFlush()
/*     */     throws IOException;
/*     */ 
/*     */   protected abstract void flushAndSync()
/*     */     throws IOException;
/*     */ 
/*     */   public void flush()
/*     */     throws IOException
/*     */   {
/*  87 */     this.numSync += 1L;
/*  88 */     long start = FSNamesystem.now();
/*  89 */     flushAndSync();
/*  90 */     long end = FSNamesystem.now();
/*  91 */     this.totalTimeSync += end - start;
/*     */   }
/*     */ 
/*     */   abstract long length()
/*     */     throws IOException;
/*     */ 
/*     */   long getTotalSyncTime()
/*     */   {
/* 104 */     return this.totalTimeSync;
/*     */   }
/*     */ 
/*     */   long getNumSync()
/*     */   {
/* 111 */     return this.numSync;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.EditLogOutputStream
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.server.namenode;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.hadoop.classification.InterfaceAudience.Private;
/*    */ import org.apache.hadoop.classification.InterfaceStability.Evolving;
/*    */ 
/*    */ @InterfaceAudience.Private
/*    */ @InterfaceStability.Evolving
/*    */ public class UnsupportedActionException extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public UnsupportedActionException(String msg)
/*    */   {
/* 36 */     super(msg);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.UnsupportedActionException
 * JD-Core Version:    0.6.1
 */
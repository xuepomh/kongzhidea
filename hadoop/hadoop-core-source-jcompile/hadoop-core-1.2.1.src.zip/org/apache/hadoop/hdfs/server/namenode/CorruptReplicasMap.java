/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.ipc.Server;
/*     */ 
/*     */ public class CorruptReplicasMap
/*     */ {
/*  36 */   private Map<Block, Collection<DatanodeDescriptor>> corruptReplicasMap = new TreeMap();
/*     */ 
/*     */   public void addToCorruptReplicasMap(Block blk, DatanodeDescriptor dn)
/*     */   {
/*  46 */     Collection nodes = getNodes(blk);
/*  47 */     if (nodes == null) {
/*  48 */       nodes = new TreeSet();
/*  49 */       this.corruptReplicasMap.put(blk, nodes);
/*     */     }
/*  51 */     if (!nodes.contains(dn)) {
/*  52 */       nodes.add(dn);
/*  53 */       NameNode.stateChangeLog.info("BLOCK NameSystem.addToCorruptReplicasMap: " + blk.getBlockName() + " added as corrupt on " + dn.getName() + " by " + Server.getRemoteIp());
/*     */     }
/*     */     else
/*     */     {
/*  58 */       NameNode.stateChangeLog.info("BLOCK NameSystem.addToCorruptReplicasMap: duplicate requested for " + blk.getBlockName() + " to add as corrupt " + "on " + dn.getName() + " by " + Server.getRemoteIp());
/*     */     }
/*     */   }
/*     */ 
/*     */   void removeFromCorruptReplicasMap(Block blk)
/*     */   {
/*  72 */     if (this.corruptReplicasMap != null)
/*  73 */       this.corruptReplicasMap.remove(blk);
/*     */   }
/*     */ 
/*     */   boolean removeFromCorruptReplicasMap(Block blk, DatanodeDescriptor datanode)
/*     */   {
/*  85 */     Collection datanodes = (Collection)this.corruptReplicasMap.get(blk);
/*  86 */     if (datanodes == null)
/*  87 */       return false;
/*  88 */     if (datanodes.remove(datanode)) {
/*  89 */       if (datanodes.isEmpty())
/*     */       {
/*  91 */         this.corruptReplicasMap.remove(blk);
/*     */       }
/*  93 */       return true;
/*     */     }
/*  95 */     return false;
/*     */   }
/*     */ 
/*     */   Collection<DatanodeDescriptor> getNodes(Block blk)
/*     */   {
/* 106 */     return (Collection)this.corruptReplicasMap.get(blk);
/*     */   }
/*     */ 
/*     */   boolean isReplicaCorrupt(Block blk, DatanodeDescriptor node)
/*     */   {
/* 117 */     Collection nodes = getNodes(blk);
/* 118 */     return (nodes != null) && (nodes.contains(node));
/*     */   }
/*     */ 
/*     */   public int numCorruptReplicas(Block blk) {
/* 122 */     Collection nodes = getNodes(blk);
/* 123 */     return nodes == null ? 0 : nodes.size();
/*     */   }
/*     */ 
/*     */   public int size() {
/* 127 */     return this.corruptReplicasMap.size();
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.CorruptReplicasMap
 * JD-Core Version:    0.6.1
 */
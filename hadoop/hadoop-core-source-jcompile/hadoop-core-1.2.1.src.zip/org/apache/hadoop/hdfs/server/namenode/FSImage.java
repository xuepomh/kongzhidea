/*      */ package org.apache.hadoop.hdfs.server.namenode;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.DataInput;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutput;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.RandomAccessFile;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Random;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.hadoop.conf.Configuration;
/*      */ import org.apache.hadoop.fs.FileUtil;
/*      */ import org.apache.hadoop.fs.permission.FsPermission;
/*      */ import org.apache.hadoop.fs.permission.PermissionStatus;
/*      */ import org.apache.hadoop.hdfs.DFSUtil;
/*      */ import org.apache.hadoop.hdfs.protocol.Block;
/*      */ import org.apache.hadoop.hdfs.protocol.DatanodeID;
/*      */ import org.apache.hadoop.hdfs.server.common.HdfsConstants.NodeType;
/*      */ import org.apache.hadoop.hdfs.server.common.HdfsConstants.StartupOption;
/*      */ import org.apache.hadoop.hdfs.server.common.InconsistentFSStateException;
/*      */ import org.apache.hadoop.hdfs.server.common.Storage;
/*      */ import org.apache.hadoop.hdfs.server.common.Storage.StorageDirType;
/*      */ import org.apache.hadoop.hdfs.server.common.Storage.StorageDirectory;
/*      */ import org.apache.hadoop.hdfs.server.common.Storage.StorageState;
/*      */ import org.apache.hadoop.hdfs.server.common.StorageInfo;
/*      */ import org.apache.hadoop.hdfs.server.common.UpgradeManager;
/*      */ import org.apache.hadoop.hdfs.util.AtomicFileOutputStream;
/*      */ import org.apache.hadoop.io.IOUtils;
/*      */ import org.apache.hadoop.io.UTF8;
/*      */ import org.apache.hadoop.io.Writable;
/*      */ 
/*      */ public class FSImage extends Storage
/*      */ {
/*   72 */   private static final SimpleDateFormat DATE_FORM = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*      */ 
/*  115 */   protected long checkpointTime = -1L;
/*  116 */   protected FSEditLog editLog = null;
/*  117 */   private boolean isUpgradeFinalized = false;
/*      */ 
/*  122 */   private List<Storage.StorageDirectory> removedStorageDirs = new ArrayList();
/*      */   private Collection<File> checkpointDirs;
/*      */   private Collection<File> checkpointEditsDirs;
/*  134 */   private volatile CheckpointStates ckptState = CheckpointStates.START;
/*      */ 
/*  139 */   private static final FsPermission FILE_PERM = new FsPermission((short)0);
/*  140 */   private static final byte[] PATH_SEPARATOR = DFSUtil.string2Bytes("/");
/*      */ 
/*  143 */   private boolean restoreRemovedDirs = false;
/*      */ 
/*  145 */   private int editsTolerationLength = 0;
/*      */ 
/* 1826 */   private static final UTF8 U_STR = new UTF8();
/*      */ 
/*      */   FSImage()
/*      */   {
/*  150 */     super(HdfsConstants.NodeType.NAME_NODE);
/*  151 */     this.editLog = new FSEditLog(this);
/*      */   }
/*      */ 
/*      */   FSImage(Collection<File> fsDirs, Collection<File> fsEditsDirs)
/*      */     throws IOException
/*      */   {
/*  158 */     this();
/*  159 */     setStorageDirectories(fsDirs, fsEditsDirs);
/*      */   }
/*      */ 
/*      */   public FSImage(StorageInfo storageInfo) {
/*  163 */     super(HdfsConstants.NodeType.NAME_NODE, storageInfo);
/*      */   }
/*      */ 
/*      */   public FSImage(File imageDir)
/*      */     throws IOException
/*      */   {
/*  170 */     this();
/*  171 */     ArrayList dirs = new ArrayList(1);
/*  172 */     ArrayList editsDirs = new ArrayList(1);
/*  173 */     dirs.add(imageDir);
/*  174 */     editsDirs.add(imageDir);
/*  175 */     setStorageDirectories(dirs, editsDirs);
/*      */   }
/*      */ 
/*      */   void setStorageDirectories(Collection<File> fsNameDirs, Collection<File> fsEditsDirs)
/*      */     throws IOException
/*      */   {
/*  181 */     this.storageDirs = new ArrayList();
/*  182 */     this.removedStorageDirs = new ArrayList();
/*      */ 
/*  184 */     for (File dirName : fsNameDirs) {
/*  185 */       boolean isAlsoEdits = false;
/*  186 */       for (File editsDirName : fsEditsDirs) {
/*  187 */         if (editsDirName.compareTo(dirName) == 0) {
/*  188 */           isAlsoEdits = true;
/*  189 */           fsEditsDirs.remove(editsDirName);
/*  190 */           break;
/*      */         }
/*      */       }
/*  193 */       NameNodeDirType dirType = isAlsoEdits ? NameNodeDirType.IMAGE_AND_EDITS : NameNodeDirType.IMAGE;
/*      */ 
/*  196 */       addStorageDir(new Storage.StorageDirectory(this, dirName, dirType));
/*      */     }
/*      */ 
/*  200 */     for (File dirName : fsEditsDirs)
/*  201 */       addStorageDir(new Storage.StorageDirectory(this, dirName, NameNodeDirType.EDITS));
/*      */   }
/*      */ 
/*      */   void setCheckpointDirectories(Collection<File> dirs, Collection<File> editsDirs)
/*      */   {
/*  207 */     this.checkpointDirs = dirs;
/*  208 */     this.checkpointEditsDirs = editsDirs;
/*      */   }
/*      */ 
/*      */   static File getImageFile(Storage.StorageDirectory sd, NameNodeFile type) {
/*  212 */     return new File(sd.getCurrentDir(), type.getName());
/*      */   }
/*      */ 
/*      */   List<Storage.StorageDirectory> getRemovedStorageDirs() {
/*  216 */     return this.removedStorageDirs;
/*      */   }
/*      */ 
/*      */   void updateRemovedDirs(Storage.StorageDirectory sd, IOException ioe) {
/*  220 */     LOG.warn(new StringBuilder().append("Removing storage dir ").append(sd.getRoot().getPath()).toString(), ioe);
/*  221 */     this.removedStorageDirs.add(sd);
/*      */   }
/*      */ 
/*      */   void updateRemovedDirs(Storage.StorageDirectory sd) {
/*  225 */     LOG.warn(new StringBuilder().append("Removing storage dir ").append(sd.getRoot().getPath()).toString());
/*  226 */     this.removedStorageDirs.add(sd);
/*      */   }
/*      */ 
/*      */   File getEditFile(Storage.StorageDirectory sd) {
/*  230 */     return getImageFile(sd, NameNodeFile.EDITS);
/*      */   }
/*      */ 
/*      */   File getEditNewFile(Storage.StorageDirectory sd) {
/*  234 */     return getImageFile(sd, NameNodeFile.EDITS_NEW);
/*      */   }
/*      */ 
/*      */   File[] getFileNames(NameNodeFile type, NameNodeDirType dirType) {
/*  238 */     ArrayList list = new ArrayList();
/*  239 */     Iterator it = dirType == null ? dirIterator() : dirIterator(dirType);
/*      */ 
/*  241 */     while (it.hasNext()) {
/*  242 */       list.add(getImageFile((Storage.StorageDirectory)it.next(), type));
/*      */     }
/*  244 */     return (File[])list.toArray(new File[list.size()]);
/*      */   }
/*      */ 
/*      */   File[] getImageFiles() {
/*  248 */     return getFileNames(NameNodeFile.IMAGE, NameNodeDirType.IMAGE);
/*      */   }
/*      */ 
/*      */   File[] getEditsFiles() {
/*  252 */     return getFileNames(NameNodeFile.EDITS, NameNodeDirType.EDITS);
/*      */   }
/*      */ 
/*      */   boolean recoverTransitionRead(Collection<File> dataDirs, Collection<File> editsDirs, HdfsConstants.StartupOption startOpt)
/*      */     throws IOException
/*      */   {
/*  271 */     assert (startOpt != HdfsConstants.StartupOption.FORMAT) : "NameNode formatting should be performed before reading the image";
/*      */ 
/*  274 */     if ((dataDirs.size() == 0) || (editsDirs.size() == 0)) {
/*  275 */       throw new IOException("All specified directories are not accessible or do not exist.");
/*      */     }
/*      */ 
/*  278 */     if ((startOpt == HdfsConstants.StartupOption.IMPORT) && ((this.checkpointDirs == null) || (this.checkpointDirs.isEmpty())))
/*      */     {
/*  280 */       throw new IOException("Cannot import image from a checkpoint. \"fs.checkpoint.dir\" is not set.");
/*      */     }
/*      */ 
/*  283 */     if ((startOpt == HdfsConstants.StartupOption.IMPORT) && ((this.checkpointEditsDirs == null) || (this.checkpointEditsDirs.isEmpty())))
/*      */     {
/*  285 */       throw new IOException("Cannot import image from a checkpoint. \"fs.checkpoint.edits.dir\" is not set.");
/*      */     }
/*      */ 
/*  288 */     setStorageDirectories(dataDirs, editsDirs);
/*      */ 
/*  291 */     Map dataDirStates = new HashMap();
/*      */ 
/*  293 */     boolean isFormatted = false;
/*  294 */     Iterator it = dirIterator();
/*  295 */     while (it.hasNext()) { Storage.StorageDirectory sd = (Storage.StorageDirectory)it.next();
/*      */       Storage.StorageState curState;
/*      */       try {
/*  299 */         curState = sd.analyzeStorage(startOpt);
/*      */ 
/*  301 */         switch (1.$SwitchMap$org$apache$hadoop$hdfs$server$common$Storage$StorageState[curState.ordinal()])
/*      */         {
/*      */         case 1:
/*  304 */           throw new InconsistentFSStateException(sd.getRoot(), "storage directory does not exist or is not accessible.");
/*      */         case 2:
/*  307 */           break;
/*      */         case 3:
/*  309 */           break;
/*      */         default:
/*  311 */           sd.doRecover(curState);
/*      */         }
/*  313 */         if ((curState != Storage.StorageState.NOT_FORMATTED) && (startOpt != HdfsConstants.StartupOption.ROLLBACK))
/*      */         {
/*  315 */           sd.read();
/*  316 */           isFormatted = true;
/*      */         }
/*  318 */         if ((startOpt == HdfsConstants.StartupOption.IMPORT) && (isFormatted))
/*      */         {
/*  320 */           throw new IOException(new StringBuilder().append("Cannot import image from a checkpoint.  NameNode already contains an image in ").append(sd.getRoot()).toString());
/*      */         }
/*      */       } catch (IOException ioe) {
/*  323 */         sd.unlock();
/*  324 */         throw ioe;
/*      */       }
/*  326 */       dataDirStates.put(sd, curState);
/*      */     }
/*      */ 
/*  329 */     if ((!isFormatted) && (startOpt != HdfsConstants.StartupOption.ROLLBACK) && (startOpt != HdfsConstants.StartupOption.IMPORT))
/*      */     {
/*  331 */       throw new IOException("NameNode is not formatted.");
/*  332 */     }if (this.layoutVersion < -3) {
/*  333 */       checkVersionUpgradable(this.layoutVersion);
/*      */     }
/*  335 */     if ((startOpt != HdfsConstants.StartupOption.UPGRADE) && (this.layoutVersion < -3) && (this.layoutVersion != -41))
/*      */     {
/*  338 */       throw new IOException(new StringBuilder().append("\nFile system image contains an old layout version ").append(this.layoutVersion).append(".\nAn upgrade to version ").append(-41).append(" is required.\nPlease restart NameNode with -upgrade option.").toString());
/*      */     }
/*      */ 
/*  343 */     verifyDistributedUpgradeProgress(startOpt);
/*      */ 
/*  346 */     this.checkpointTime = 0L;
/*  347 */     Iterator it = dirIterator();
/*  348 */     while (it.hasNext()) {
/*  349 */       Storage.StorageDirectory sd = (Storage.StorageDirectory)it.next();
/*  350 */       Storage.StorageState curState = (Storage.StorageState)dataDirStates.get(sd);
/*  351 */       switch (curState) {
/*      */       case NON_EXISTENT:
/*  353 */         if (!$assertionsDisabled) throw new AssertionError(new StringBuilder().append(Storage.StorageState.NON_EXISTENT).append(" state cannot be here").toString());
/*      */       case NOT_FORMATTED:
/*  355 */         LOG.info(new StringBuilder().append("Storage directory ").append(sd.getRoot()).append(" is not formatted.").toString());
/*  356 */         LOG.info("Formatting ...");
/*  357 */         sd.clearDirectory();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  365 */     switch (1.$SwitchMap$org$apache$hadoop$hdfs$server$common$HdfsConstants$StartupOption[startOpt.ordinal()]) {
/*      */     case 1:
/*  367 */       doUpgrade();
/*  368 */       return false;
/*      */     case 2:
/*  370 */       doImportCheckpoint();
/*  371 */       return true;
/*      */     case 3:
/*  373 */       doRollback();
/*  374 */       break;
/*      */     case 4:
/*      */     }
/*      */ 
/*  378 */     return loadFSImage(startOpt.createRecoveryContext());
/*      */   }
/*      */ 
/*      */   private void doUpgrade() throws IOException {
/*  382 */     MetaRecoveryContext recovery = null;
/*  383 */     if (getDistributedUpgradeState())
/*      */     {
/*  386 */       loadFSImage(recovery);
/*  387 */       initializeDistributedUpgrade();
/*  388 */       return;
/*      */     }
/*      */ 
/*  392 */     Iterator it = dirIterator();
/*  393 */     while (it.hasNext()) {
/*  394 */       Storage.StorageDirectory sd = (Storage.StorageDirectory)it.next();
/*  395 */       if (sd.getPreviousDir().exists()) {
/*  396 */         throw new InconsistentFSStateException(sd.getRoot(), "previous fs state should not exist during upgrade. Finalize or rollback first.");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  402 */     loadFSImage(recovery);
/*      */ 
/*  405 */     long oldCTime = getCTime();
/*  406 */     this.cTime = FSNamesystem.now();
/*  407 */     int oldLV = getLayoutVersion();
/*  408 */     this.layoutVersion = -41;
/*  409 */     this.checkpointTime = FSNamesystem.now();
/*  410 */     Iterator it = dirIterator();
/*  411 */     while (it.hasNext()) {
/*  412 */       Storage.StorageDirectory sd = (Storage.StorageDirectory)it.next();
/*  413 */       LOG.info(new StringBuilder().append("Upgrading image directory ").append(sd.getRoot()).append(".\n   old LV = ").append(oldLV).append("; old CTime = ").append(oldCTime).append(".\n   new LV = ").append(getLayoutVersion()).append("; new CTime = ").append(getCTime()).toString());
/*      */ 
/*  418 */       File curDir = sd.getCurrentDir();
/*  419 */       File prevDir = sd.getPreviousDir();
/*  420 */       File tmpDir = sd.getPreviousTmp();
/*  421 */       assert (curDir.exists()) : "Current directory must exist.";
/*  422 */       assert (!prevDir.exists()) : "prvious directory must not exist.";
/*  423 */       assert (!tmpDir.exists()) : "prvious.tmp directory must not exist.";
/*      */ 
/*  425 */       rename(curDir, tmpDir);
/*      */ 
/*  427 */       saveCurrent(sd);
/*      */ 
/*  429 */       rename(tmpDir, prevDir);
/*  430 */       this.isUpgradeFinalized = false;
/*  431 */       LOG.info(new StringBuilder().append("Upgrade of ").append(sd.getRoot()).append(" is complete.").toString());
/*      */     }
/*  433 */     initializeDistributedUpgrade();
/*  434 */     this.editLog.open();
/*      */   }
/*      */ 
/*      */   private void doRollback()
/*      */     throws IOException
/*      */   {
/*  441 */     boolean canRollback = false;
/*  442 */     FSImage prevState = new FSImage();
/*  443 */     prevState.layoutVersion = -41;
/*  444 */     Iterator it = dirIterator();
/*  445 */     while (it.hasNext()) {
/*  446 */       Storage.StorageDirectory sd = (Storage.StorageDirectory)it.next();
/*  447 */       File prevDir = sd.getPreviousDir();
/*  448 */       if (!prevDir.exists()) {
/*  449 */         LOG.info(new StringBuilder().append("Storage directory ").append(sd.getRoot()).append(" does not contain previous fs state.").toString());
/*      */ 
/*  451 */         sd.read();
/*      */       }
/*      */       else
/*      */       {
/*      */         FSImage tmp105_104 = prevState; tmp105_104.getClass(); Storage.StorageDirectory sdPrev = new Storage.StorageDirectory(tmp105_104, sd.getRoot());
/*  455 */         sdPrev.read(sdPrev.getPreviousVersionFile());
/*  456 */         canRollback = true;
/*      */       }
/*      */     }
/*  458 */     if (!canRollback) {
/*  459 */       throw new IOException("Cannot rollback. None of the storage directories contain previous fs state.");
/*      */     }
/*      */ 
/*  464 */     Iterator it = dirIterator();
/*  465 */     while (it.hasNext()) {
/*  466 */       Storage.StorageDirectory sd = (Storage.StorageDirectory)it.next();
/*  467 */       File prevDir = sd.getPreviousDir();
/*  468 */       if (prevDir.exists())
/*      */       {
/*  471 */         LOG.info(new StringBuilder().append("Rolling back storage directory ").append(sd.getRoot()).append(".\n   new LV = ").append(prevState.getLayoutVersion()).append("; new CTime = ").append(prevState.getCTime()).toString());
/*      */ 
/*  474 */         File tmpDir = sd.getRemovedTmp();
/*  475 */         assert (!tmpDir.exists()) : "removed.tmp directory must not exist.";
/*      */ 
/*  477 */         File curDir = sd.getCurrentDir();
/*  478 */         assert (curDir.exists()) : "Current directory must exist.";
/*  479 */         rename(curDir, tmpDir);
/*      */ 
/*  481 */         rename(prevDir, curDir);
/*      */ 
/*  484 */         deleteDir(tmpDir);
/*  485 */         LOG.info(new StringBuilder().append("Rollback of ").append(sd.getRoot()).append(" is complete.").toString());
/*      */       }
/*      */     }
/*  487 */     this.isUpgradeFinalized = true;
/*      */ 
/*  489 */     verifyDistributedUpgradeProgress(HdfsConstants.StartupOption.REGULAR);
/*      */   }
/*      */ 
/*      */   private void doFinalize(Storage.StorageDirectory sd) throws IOException {
/*  493 */     File prevDir = sd.getPreviousDir();
/*  494 */     if (!prevDir.exists()) {
/*  495 */       LOG.info(new StringBuilder().append("Directory ").append(prevDir).append(" does not exist.").toString());
/*  496 */       LOG.info(new StringBuilder().append("Finalize upgrade for ").append(sd.getRoot()).append(" is not required.").toString());
/*  497 */       return;
/*      */     }
/*  499 */     LOG.info(new StringBuilder().append("Finalizing upgrade for storage directory ").append(sd.getRoot()).append(".").append(getLayoutVersion() == 0 ? "" : new StringBuilder().append("\n   cur LV = ").append(getLayoutVersion()).append("; cur CTime = ").append(getCTime()).toString()).toString());
/*      */ 
/*  504 */     assert (sd.getCurrentDir().exists()) : "Current directory must exist.";
/*  505 */     File tmpDir = sd.getFinalizedTmp();
/*      */ 
/*  507 */     rename(prevDir, tmpDir);
/*  508 */     deleteDir(tmpDir);
/*  509 */     this.isUpgradeFinalized = true;
/*  510 */     LOG.info(new StringBuilder().append("Finalize upgrade for ").append(sd.getRoot()).append(" is complete.").toString());
/*      */   }
/*      */ 
/*      */   void doImportCheckpoint()
/*      */     throws IOException
/*      */   {
/*  518 */     FSImage ckptImage = new FSImage();
/*  519 */     FSNamesystem fsNamesys = FSNamesystem.getFSNamesystem();
/*      */ 
/*  521 */     FSImage realImage = fsNamesys.getFSImage();
/*  522 */     assert (realImage == this);
/*  523 */     fsNamesys.dir.fsImage = ckptImage;
/*      */     try
/*      */     {
/*  526 */       ckptImage.recoverTransitionRead(this.checkpointDirs, this.checkpointEditsDirs, HdfsConstants.StartupOption.REGULAR);
/*      */     }
/*      */     finally {
/*  529 */       ckptImage.close();
/*      */     }
/*      */ 
/*  532 */     realImage.setStorageInfo(ckptImage);
/*  533 */     fsNamesys.dir.fsImage = realImage;
/*      */ 
/*  535 */     saveNamespace(false);
/*      */   }
/*      */ 
/*      */   void finalizeUpgrade() throws IOException {
/*  539 */     Iterator it = dirIterator();
/*  540 */     while (it.hasNext())
/*  541 */       doFinalize((Storage.StorageDirectory)it.next());
/*      */   }
/*      */ 
/*      */   boolean isUpgradeFinalized()
/*      */   {
/*  546 */     return this.isUpgradeFinalized;
/*      */   }
/*      */ 
/*      */   protected void getFields(Properties props, Storage.StorageDirectory sd)
/*      */     throws IOException
/*      */   {
/*  552 */     super.getFields(props, sd);
/*  553 */     if (this.layoutVersion == 0) {
/*  554 */       throw new IOException(new StringBuilder().append("NameNode directory ").append(sd.getRoot()).append(" is not formatted.").toString());
/*      */     }
/*      */ 
/*  557 */     String sDUS = props.getProperty("distributedUpgradeState");
/*  558 */     String sDUV = props.getProperty("distributedUpgradeVersion");
/*  559 */     setDistributedUpgradeState(sDUS == null ? false : Boolean.parseBoolean(sDUS), sDUV == null ? getLayoutVersion() : Integer.parseInt(sDUV));
/*      */ 
/*  562 */     this.checkpointTime = readCheckpointTime(sd);
/*      */   }
/*      */ 
/*      */   long readCheckpointTime(Storage.StorageDirectory sd) throws IOException {
/*  566 */     File timeFile = getImageFile(sd, NameNodeFile.TIME);
/*  567 */     long timeStamp = 0L;
/*  568 */     if ((timeFile.exists()) && (timeFile.canRead())) {
/*  569 */       DataInputStream in = new DataInputStream(new FileInputStream(timeFile));
/*      */       try {
/*  571 */         timeStamp = in.readLong();
/*      */       } catch (IOException e) {
/*  573 */         LOG.info(new StringBuilder().append("Could not read fstime file in storage directory ").append(sd).toString(), e);
/*      */       } finally {
/*  575 */         in.close();
/*      */       }
/*      */     }
/*  578 */     return timeStamp;
/*      */   }
/*      */ 
/*      */   protected void setFields(Properties props, Storage.StorageDirectory sd)
/*      */     throws IOException
/*      */   {
/*  594 */     super.setFields(props, sd);
/*  595 */     boolean uState = getDistributedUpgradeState();
/*  596 */     int uVersion = getDistributedUpgradeVersion();
/*  597 */     if ((uState) && (uVersion != getLayoutVersion())) {
/*  598 */       props.setProperty("distributedUpgradeState", Boolean.toString(uState));
/*  599 */       props.setProperty("distributedUpgradeVersion", Integer.toString(uVersion));
/*      */     }
/*  601 */     writeCheckpointTime(sd);
/*      */   }
/*      */ 
/*      */   void writeCheckpointTime(Storage.StorageDirectory sd)
/*      */     throws IOException
/*      */   {
/*  611 */     if (this.checkpointTime < 0L)
/*  612 */       return;
/*  613 */     File timeFile = getImageFile(sd, NameNodeFile.TIME);
/*  614 */     DataOutputStream out = new DataOutputStream(new AtomicFileOutputStream(timeFile));
/*      */     try
/*      */     {
/*  617 */       out.writeLong(this.checkpointTime);
/*      */     } finally {
/*  619 */       out.close();
/*      */     }
/*      */   }
/*      */ 
/*      */   void incrementCheckpointTime()
/*      */   {
/*  630 */     this.checkpointTime += 1L;
/*      */ 
/*  632 */     Iterator it = dirIterator();
/*  633 */     while (it.hasNext()) {
/*  634 */       Storage.StorageDirectory sd = (Storage.StorageDirectory)it.next();
/*      */       try {
/*  636 */         writeCheckpointTime(sd);
/*      */       } catch (IOException ioe) {
/*  638 */         this.editLog.removeEditsForStorageDir(sd);
/*  639 */         updateRemovedDirs(sd, ioe);
/*  640 */         it.remove();
/*      */       }
/*      */     }
/*  643 */     this.editLog.exitIfNoStreams();
/*      */   }
/*      */ 
/*      */   void removeStorageDir(File dir)
/*      */   {
/*  650 */     Iterator it = dirIterator();
/*  651 */     while (it.hasNext()) {
/*  652 */       Storage.StorageDirectory sd = (Storage.StorageDirectory)it.next();
/*  653 */       if (sd.getRoot().getPath().equals(dir.getPath())) {
/*  654 */         updateRemovedDirs(sd);
/*  655 */         it.remove();
/*  656 */         this.editLog.removeEditsForStorageDir(sd);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public FSEditLog getEditLog() {
/*  662 */     return this.editLog;
/*      */   }
/*      */ 
/*      */   public void setEditLog(FSEditLog newLog)
/*      */   {
/*  667 */     this.editLog = newLog;
/*      */   }
/*      */ 
/*      */   public boolean isConversionNeeded(Storage.StorageDirectory sd) throws IOException {
/*  671 */     File oldImageDir = new File(sd.getRoot(), "image");
/*  672 */     if (!oldImageDir.exists()) {
/*  673 */       if (sd.getVersionFile().exists()) {
/*  674 */         throw new InconsistentFSStateException(sd.getRoot(), new StringBuilder().append(oldImageDir).append(" does not exist.").toString());
/*      */       }
/*  676 */       return false;
/*      */     }
/*      */ 
/*  679 */     File oldF = new File(oldImageDir, "fsimage");
/*  680 */     RandomAccessFile oldFile = new RandomAccessFile(oldF, "rws");
/*      */     try {
/*  682 */       oldFile.seek(0L);
/*  683 */       int odlVersion = oldFile.readInt();
/*  684 */       if (odlVersion < -3)
/*  685 */         return false;
/*      */     } finally {
/*  687 */       oldFile.close();
/*      */     }
/*  689 */     return true;
/*      */   }
/*      */ 
/*      */   boolean recoverInterruptedCheckpoint(Storage.StorageDirectory nameSD, Storage.StorageDirectory editsSD)
/*      */     throws IOException
/*      */   {
/*  698 */     boolean needToSave = false;
/*  699 */     File curFile = getImageFile(nameSD, NameNodeFile.IMAGE);
/*  700 */     File ckptFile = getImageFile(nameSD, NameNodeFile.IMAGE_NEW);
/*      */ 
/*  705 */     if (ckptFile.exists()) {
/*  706 */       needToSave = true;
/*  707 */       if (getImageFile(editsSD, NameNodeFile.EDITS_NEW).exists())
/*      */       {
/*  714 */         if (!ckptFile.delete()) {
/*  715 */           throw new IOException(new StringBuilder().append("Unable to delete ").append(ckptFile).toString());
/*      */         }
/*      */ 
/*      */       }
/*  726 */       else if (!ckptFile.renameTo(curFile)) {
/*  727 */         if (!curFile.delete())
/*  728 */           LOG.warn(new StringBuilder().append("Unable to delete dir ").append(curFile).append(" before rename").toString());
/*  729 */         if (!ckptFile.renameTo(curFile)) {
/*  730 */           throw new IOException(new StringBuilder().append("Unable to rename ").append(ckptFile).append(" to ").append(curFile).toString());
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  736 */     return needToSave;
/*      */   }
/*      */ 
/*      */   boolean loadFSImage(MetaRecoveryContext recovery)
/*      */     throws IOException
/*      */   {
/*  748 */     long latestNameCheckpointTime = -9223372036854775808L;
/*  749 */     long latestEditsCheckpointTime = -9223372036854775808L;
/*  750 */     Storage.StorageDirectory latestNameSD = null;
/*  751 */     Storage.StorageDirectory latestEditsSD = null;
/*  752 */     boolean needToSave = false;
/*  753 */     this.isUpgradeFinalized = true;
/*  754 */     Collection imageDirs = new ArrayList();
/*  755 */     Collection editsDirs = new ArrayList();
/*  756 */     for (Iterator it = dirIterator(); it.hasNext(); ) {
/*  757 */       Storage.StorageDirectory sd = (Storage.StorageDirectory)it.next();
/*  758 */       if (!sd.getVersionFile().exists()) {
/*  759 */         needToSave |= true;
/*      */       }
/*      */       else {
/*  762 */         boolean imageExists = false; boolean editsExists = false;
/*  763 */         if (sd.getStorageDirType().isOfType(NameNodeDirType.IMAGE)) {
/*  764 */           imageExists = getImageFile(sd, NameNodeFile.IMAGE).exists();
/*  765 */           imageDirs.add(sd.getRoot().getCanonicalPath());
/*      */         }
/*  767 */         if (sd.getStorageDirType().isOfType(NameNodeDirType.EDITS)) {
/*  768 */           editsExists = getImageFile(sd, NameNodeFile.EDITS).exists();
/*  769 */           editsDirs.add(sd.getRoot().getCanonicalPath());
/*      */         }
/*      */ 
/*  772 */         this.checkpointTime = readCheckpointTime(sd);
/*  773 */         if ((this.checkpointTime != -9223372036854775808L) && ((this.checkpointTime != latestNameCheckpointTime) || (this.checkpointTime != latestEditsCheckpointTime)))
/*      */         {
/*  778 */           needToSave |= true;
/*      */         }
/*  780 */         if ((sd.getStorageDirType().isOfType(NameNodeDirType.IMAGE)) && (latestNameCheckpointTime < this.checkpointTime) && (imageExists))
/*      */         {
/*  782 */           latestNameCheckpointTime = this.checkpointTime;
/*  783 */           latestNameSD = sd;
/*      */         }
/*  785 */         if ((sd.getStorageDirType().isOfType(NameNodeDirType.EDITS)) && (latestEditsCheckpointTime < this.checkpointTime) && (editsExists))
/*      */         {
/*  787 */           latestEditsCheckpointTime = this.checkpointTime;
/*  788 */           latestEditsSD = sd;
/*      */         }
/*  790 */         if (this.checkpointTime <= 0L) {
/*  791 */           needToSave |= true;
/*      */         }
/*  793 */         this.isUpgradeFinalized = ((this.isUpgradeFinalized) && (!sd.getPreviousDir().exists()));
/*      */       }
/*      */     }
/*      */ 
/*  797 */     if (latestNameSD == null)
/*  798 */       throw new IOException(new StringBuilder().append("Image file is not found in ").append(imageDirs).toString());
/*  799 */     if (latestEditsSD == null) {
/*  800 */       throw new IOException(new StringBuilder().append("Edits file is not found in ").append(editsDirs).toString());
/*      */     }
/*      */ 
/*  803 */     if ((latestNameCheckpointTime > latestEditsCheckpointTime) && (latestNameSD != latestEditsSD) && (latestNameSD.getStorageDirType() == NameNodeDirType.IMAGE) && (latestEditsSD.getStorageDirType() == NameNodeDirType.EDITS))
/*      */     {
/*  811 */       LOG.error("This is a rare failure scenario!!!");
/*  812 */       LOG.error(new StringBuilder().append("Image checkpoint time ").append(latestNameCheckpointTime).append(" > edits checkpoint time ").append(latestEditsCheckpointTime).toString());
/*      */ 
/*  814 */       LOG.error("Name-node will treat the image as the latest state of the namespace. Old edits will be discarded.");
/*      */     }
/*  816 */     else if (latestNameCheckpointTime != latestEditsCheckpointTime) {
/*  817 */       throw new IOException(new StringBuilder().append("Inconsistent storage detected, image and edits checkpoint times do not match. image checkpoint time = ").append(latestNameCheckpointTime).append("edits checkpoint time = ").append(latestEditsCheckpointTime).toString());
/*      */     }
/*      */ 
/*  823 */     needToSave |= recoverInterruptedCheckpoint(latestNameSD, latestEditsSD);
/*      */ 
/*  825 */     long startTime = FSNamesystem.now();
/*  826 */     File imageFile = getImageFile(latestNameSD, NameNodeFile.IMAGE);
/*  827 */     long imageSize = imageFile.length();
/*      */ 
/*  832 */     latestNameSD.read();
/*  833 */     LOG.info(new StringBuilder().append("Start loading image file ").append(imageFile.getPath().toString()).toString());
/*  834 */     needToSave |= loadFSImage(imageFile);
/*  835 */     LOG.info(new StringBuilder().append("Image file ").append(imageFile.getPath().toString()).append(" of size ").append(imageSize).append(" bytes loaded in ").append((FSNamesystem.now() - startTime) / 1000L).append(" seconds.").toString());
/*      */ 
/*  840 */     if (latestNameCheckpointTime > latestEditsCheckpointTime)
/*      */     {
/*  842 */       needToSave |= true;
/*  843 */       FSNamesystem.getFSNamesystem().dir.updateCountForINodeWithQuota();
/*      */     } else {
/*  845 */       needToSave |= loadFSEdits(latestEditsSD, recovery) > 0;
/*      */     }
/*      */ 
/*  848 */     return needToSave;
/*      */   }
/*      */ 
/*      */   boolean loadFSImage(File curFile)
/*      */     throws IOException
/*      */   {
/*  857 */     assert (getLayoutVersion() < 0) : "Negative layout version is expected.";
/*  858 */     assert (curFile != null) : "curFile is null";
/*      */ 
/*  860 */     FSNamesystem fsNamesys = FSNamesystem.getFSNamesystem();
/*  861 */     FSDirectory fsDir = fsNamesys.dir;
/*      */ 
/*  866 */     boolean needToSave = true;
/*  867 */     DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(curFile)));
/*      */     try
/*      */     {
/*  881 */       int imgVersion = in.readInt();
/*      */ 
/*  883 */       this.namespaceID = in.readInt();
/*      */       long numFiles;
/*      */       long numFiles;
/*  887 */       if (imgVersion <= -16)
/*  888 */         numFiles = in.readLong();
/*      */       else {
/*  890 */         numFiles = in.readInt();
/*      */       }
/*      */ 
/*  893 */       this.layoutVersion = imgVersion;
/*      */ 
/*  895 */       if (imgVersion <= -12) {
/*  896 */         long genstamp = in.readLong();
/*  897 */         fsNamesys.setGenerationStamp(genstamp);
/*      */       }
/*      */ 
/*  900 */       needToSave = imgVersion != -41;
/*      */ 
/*  903 */       short replication = FSNamesystem.getFSNamesystem().getDefaultReplication();
/*      */ 
/*  905 */       LOG.info(new StringBuilder().append("Number of files = ").append(numFiles).toString());
/*      */ 
/*  908 */       String parentPath = "";
/*  909 */       INodeDirectory parentINode = fsDir.rootDir;
/*  910 */       for (long i = 0L; i < numFiles; i += 1L) {
/*  911 */         long modificationTime = 0L;
/*  912 */         long atime = 0L;
/*  913 */         long blockSize = 0L;
/*  914 */         String path = readString(in);
/*  915 */         replication = in.readShort();
/*  916 */         replication = FSEditLog.adjustReplication(replication);
/*  917 */         modificationTime = in.readLong();
/*  918 */         if (imgVersion <= -17) {
/*  919 */           atime = in.readLong();
/*      */         }
/*  921 */         if (imgVersion <= -8) {
/*  922 */           blockSize = in.readLong();
/*      */         }
/*  924 */         int numBlocks = in.readInt();
/*  925 */         Block[] blocks = null;
/*      */ 
/*  929 */         if (((-9 <= imgVersion) && (numBlocks > 0)) || ((imgVersion < -9) && (numBlocks >= 0)))
/*      */         {
/*  931 */           blocks = new Block[numBlocks];
/*  932 */           for (int j = 0; j < numBlocks; j++) {
/*  933 */             blocks[j] = new Block();
/*  934 */             if (-14 < imgVersion) {
/*  935 */               blocks[j].set(in.readLong(), in.readLong(), 0L);
/*      */             }
/*      */             else {
/*  938 */               blocks[j].readFields(in);
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  946 */         if ((-8 <= imgVersion) && (blockSize == 0L)) {
/*  947 */           if (numBlocks > 1) {
/*  948 */             blockSize = blocks[0].getNumBytes();
/*      */           } else {
/*  950 */             long first = numBlocks == 1 ? blocks[0].getNumBytes() : 0L;
/*  951 */             blockSize = Math.max(fsNamesys.getDefaultBlockSize(), first);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  956 */         long nsQuota = -1L;
/*  957 */         if ((imgVersion <= -16) && (blocks == null)) {
/*  958 */           nsQuota = in.readLong();
/*      */         }
/*  960 */         long dsQuota = -1L;
/*  961 */         if ((imgVersion <= -18) && (blocks == null)) {
/*  962 */           dsQuota = in.readLong();
/*      */         }
/*      */ 
/*  965 */         PermissionStatus permissions = fsNamesys.getUpgradePermission();
/*  966 */         if (imgVersion <= -11) {
/*  967 */           permissions = PermissionStatus.read(in);
/*      */         }
/*  969 */         if (path.length() == 0)
/*      */         {
/*  971 */           if ((nsQuota != -1L) || (dsQuota != -1L)) {
/*  972 */             fsDir.rootDir.setQuota(nsQuota, dsQuota);
/*      */           }
/*  974 */           fsDir.rootDir.setModificationTime(modificationTime);
/*  975 */           fsDir.rootDir.setPermissionStatus(permissions);
/*      */         }
/*      */         else
/*      */         {
/*  979 */           if (!isParent(path, parentPath)) {
/*  980 */             parentINode = null;
/*  981 */             parentPath = getParent(path);
/*      */           }
/*      */ 
/*  984 */           parentINode = fsDir.addToParent(path, parentINode, permissions, blocks, replication, modificationTime, atime, nsQuota, dsQuota, blockSize);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  990 */       loadDatanodes(imgVersion, in);
/*      */ 
/*  993 */       loadFilesUnderConstruction(imgVersion, in, fsNamesys);
/*      */ 
/*  995 */       loadSecretManagerState(imgVersion, in, fsNamesys);
/*      */     }
/*      */     finally {
/*  998 */       in.close();
/*      */     }
/*      */ 
/* 1001 */     return needToSave;
/*      */   }
/*      */ 
/*      */   String getParent(String path)
/*      */   {
/* 1008 */     return path.substring(0, path.lastIndexOf("/"));
/*      */   }
/*      */ 
/*      */   private boolean isParent(String path, String parent) {
/* 1012 */     return (parent != null) && (path != null) && (path.indexOf(parent) == 0) && (path.lastIndexOf("/") == parent.length());
/*      */   }
/*      */ 
/*      */   int loadFSEdits(Storage.StorageDirectory sd, MetaRecoveryContext recovery)
/*      */     throws IOException
/*      */   {
/* 1026 */     int numEdits = 0;
/* 1027 */     FSEditLog.EditLogFileInputStream edits = new FSEditLog.EditLogFileInputStream(getImageFile(sd, NameNodeFile.EDITS));
/*      */ 
/* 1029 */     numEdits = FSEditLog.loadFSEdits(edits, this.editsTolerationLength, recovery);
/* 1030 */     edits.close();
/* 1031 */     File editsNew = getImageFile(sd, NameNodeFile.EDITS_NEW);
/* 1032 */     if ((editsNew.exists()) && (editsNew.length() > 0L)) {
/* 1033 */       edits = new FSEditLog.EditLogFileInputStream(editsNew);
/* 1034 */       numEdits += FSEditLog.loadFSEdits(edits, this.editsTolerationLength, recovery);
/* 1035 */       edits.close();
/*      */     }
/*      */ 
/* 1038 */     FSNamesystem.getFSNamesystem().dir.updateCountForINodeWithQuota();
/* 1039 */     return numEdits;
/*      */   }
/*      */ 
/*      */   void saveFSImage(File newFile)
/*      */     throws IOException
/*      */   {
/* 1046 */     FSNamesystem fsNamesys = FSNamesystem.getFSNamesystem();
/* 1047 */     FSDirectory fsDir = fsNamesys.dir;
/* 1048 */     long startTime = FSNamesystem.now();
/*      */ 
/* 1052 */     DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(newFile)));
/*      */     try
/*      */     {
/* 1056 */       out.writeInt(-41);
/* 1057 */       out.writeInt(this.namespaceID);
/* 1058 */       out.writeLong(fsDir.rootDir.numItemsInTree());
/* 1059 */       out.writeLong(fsNamesys.getGenerationStamp());
/* 1060 */       byte[] byteStore = new byte[32000];
/* 1061 */       ByteBuffer strbuf = ByteBuffer.wrap(byteStore);
/*      */ 
/* 1063 */       saveINode2Image(strbuf, fsDir.rootDir, out);
/*      */ 
/* 1065 */       saveImage(strbuf, 0, fsDir.rootDir, out);
/* 1066 */       fsNamesys.saveFilesUnderConstruction(out);
/* 1067 */       fsNamesys.saveSecretManagerState(out);
/* 1068 */       strbuf = null;
/*      */     } finally {
/* 1070 */       out.close();
/*      */     }
/*      */ 
/* 1073 */     LOG.info(new StringBuilder().append("Image file ").append(newFile).append(" of size ").append(newFile.length()).append(" bytes saved in ").append((FSNamesystem.now() - startTime) / 1000L).append(" seconds.").toString());
/*      */   }
/*      */ 
/*      */   void saveNamespace(boolean renewCheckpointTime)
/*      */     throws IOException
/*      */   {
/* 1094 */     this.editLog.close();
/* 1095 */     if (renewCheckpointTime) {
/* 1096 */       this.checkpointTime = FSNamesystem.now();
/*      */     }
/*      */ 
/* 1099 */     for (Iterator it = dirIterator(); it.hasNext(); ) {
/* 1100 */       Storage.StorageDirectory sd = (Storage.StorageDirectory)it.next();
/*      */       try {
/* 1102 */         moveCurrent(sd);
/*      */       } catch (IOException ie) {
/* 1104 */         LOG.error(new StringBuilder().append("Unable to move current for ").append(sd.getRoot()).toString(), ie);
/* 1105 */         removeStorageDir(sd.getRoot());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1110 */     Iterator it = dirIterator(NameNodeDirType.IMAGE);
/* 1111 */     while (it.hasNext()) {
/* 1112 */       Storage.StorageDirectory sd = (Storage.StorageDirectory)it.next();
/*      */       try {
/* 1114 */         saveCurrent(sd);
/*      */       } catch (IOException ie) {
/* 1116 */         LOG.error(new StringBuilder().append("Unable to save image for ").append(sd.getRoot()).toString(), ie);
/* 1117 */         removeStorageDir(sd.getRoot());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1132 */     Iterator it = dirIterator(NameNodeDirType.EDITS);
/* 1133 */     while (it.hasNext()) {
/* 1134 */       Storage.StorageDirectory sd = (Storage.StorageDirectory)it.next();
/*      */       try {
/* 1136 */         if (!sd.getStorageDirType().isOfType(NameNodeDirType.IMAGE_AND_EDITS))
/*      */         {
/* 1138 */           saveCurrent(sd);
/*      */         }
/*      */       } catch (IOException ie) { LOG.error(new StringBuilder().append("Unable to save edits for ").append(sd.getRoot()).toString(), ie);
/* 1141 */         removeStorageDir(sd.getRoot());
/*      */       }
/*      */     }
/*      */ 
/* 1145 */     for (Iterator it = dirIterator(); it.hasNext(); ) {
/* 1146 */       Storage.StorageDirectory sd = (Storage.StorageDirectory)it.next();
/*      */       try {
/* 1148 */         moveLastCheckpoint(sd);
/*      */       } catch (IOException ie) {
/* 1150 */         LOG.error(new StringBuilder().append("Unable to move last checkpoint for ").append(sd.getRoot()).toString(), ie);
/* 1151 */         removeStorageDir(sd.getRoot());
/*      */       }
/*      */     }
/* 1154 */     if (!this.editLog.isOpen()) this.editLog.open();
/* 1155 */     this.ckptState = CheckpointStates.UPLOAD_DONE;
/*      */   }
/*      */ 
/*      */   protected void saveCurrent(Storage.StorageDirectory sd)
/*      */     throws IOException
/*      */   {
/* 1162 */     File curDir = sd.getCurrentDir();
/* 1163 */     NameNodeDirType dirType = (NameNodeDirType)sd.getStorageDirType();
/*      */ 
/* 1165 */     if ((!curDir.exists()) && (!curDir.mkdir()))
/* 1166 */       throw new IOException(new StringBuilder().append("Cannot create directory ").append(curDir).toString());
/* 1167 */     if (dirType.isOfType(NameNodeDirType.IMAGE))
/* 1168 */       saveFSImage(getImageFile(sd, NameNodeFile.IMAGE));
/* 1169 */     if (dirType.isOfType(NameNodeDirType.EDITS)) {
/* 1170 */       this.editLog.createEditLogFile(getImageFile(sd, NameNodeFile.EDITS));
/*      */     }
/* 1172 */     sd.write();
/*      */   }
/*      */ 
/*      */   protected void moveCurrent(Storage.StorageDirectory sd)
/*      */     throws IOException
/*      */   {
/* 1186 */     File curDir = sd.getCurrentDir();
/* 1187 */     File tmpCkptDir = sd.getLastCheckpointTmp();
/*      */ 
/* 1190 */     if (sd.getVersionFile().exists()) {
/* 1191 */       assert (curDir.exists()) : new StringBuilder().append(curDir).append(" directory must exist.").toString();
/* 1192 */       assert (!tmpCkptDir.exists()) : new StringBuilder().append(tmpCkptDir).append(" directory must not exist.").toString();
/* 1193 */       rename(curDir, tmpCkptDir);
/*      */     }
/*      */ 
/* 1196 */     if ((!curDir.exists()) && (!curDir.mkdir()))
/* 1197 */       throw new IOException(new StringBuilder().append("Cannot create directory ").append(curDir).toString());
/*      */   }
/*      */ 
/*      */   protected void moveLastCheckpoint(Storage.StorageDirectory sd)
/*      */     throws IOException
/*      */   {
/* 1208 */     File tmpCkptDir = sd.getLastCheckpointTmp();
/* 1209 */     File prevCkptDir = sd.getPreviousCheckpoint();
/*      */ 
/* 1211 */     if (prevCkptDir.exists()) {
/* 1212 */       deleteDir(prevCkptDir);
/*      */     }
/* 1214 */     if (tmpCkptDir.exists())
/* 1215 */       rename(tmpCkptDir, prevCkptDir);
/*      */   }
/*      */ 
/*      */   private int newNamespaceID()
/*      */   {
/* 1231 */     Random r = new Random();
/* 1232 */     r.setSeed(FSNamesystem.now());
/* 1233 */     int newID = 0;
/* 1234 */     while (newID == 0)
/* 1235 */       newID = r.nextInt(2147483647);
/* 1236 */     return newID;
/*      */   }
/*      */ 
/*      */   void setRestoreRemovedDirs(boolean allow) {
/* 1240 */     this.restoreRemovedDirs = allow;
/*      */   }
/*      */ 
/*      */   void setEditsTolerationLength(int editsTolerationLength) {
/* 1244 */     this.editsTolerationLength = editsTolerationLength;
/* 1245 */     FSEditLog.LOG.info(new StringBuilder().append("dfs.namenode.edits.toleration.length = ").append(editsTolerationLength).toString());
/*      */   }
/*      */ 
/*      */   private static void restoreFile(File src, File dstdir, String dstfile)
/*      */     throws IOException
/*      */   {
/* 1252 */     File dst = new File(dstdir, dstfile);
/* 1253 */     IOUtils.copyBytes(new FileInputStream(src), new FileOutputStream(dst), 4096, true);
/*      */   }
/*      */ 
/*      */   void restoreStorageDirs()
/*      */   {
/* 1261 */     if ((!this.restoreRemovedDirs) || (getRemovedStorageDirs().isEmpty())) {
/* 1262 */       return;
/*      */     }
/*      */ 
/* 1265 */     Iterator it = dirIterator(NameNodeDirType.EDITS);
/* 1266 */     if (!it.hasNext()) {
/* 1267 */       FSNamesystem.LOG.warn("No healthy edits directory");
/* 1268 */       return;
/*      */     }
/* 1270 */     Storage.StorageDirectory goodSd = (Storage.StorageDirectory)it.next();
/* 1271 */     File goodEdits = getEditFile(goodSd);
/*      */ 
/* 1273 */     it = dirIterator(NameNodeDirType.IMAGE);
/* 1274 */     if (!it.hasNext()) {
/* 1275 */       FSNamesystem.LOG.warn("No healthy fsimage directory");
/* 1276 */       return;
/*      */     }
/* 1278 */     goodSd = (Storage.StorageDirectory)it.next();
/* 1279 */     File goodImage = getImageFile(goodSd, NameNodeFile.IMAGE);
/* 1280 */     File goodFstime = getImageFile(goodSd, NameNodeFile.TIME);
/* 1281 */     File goodVersion = goodSd.getVersionFile();
/*      */ 
/* 1283 */     File goodImage013 = new File(goodSd.getRoot(), "image/fsimage");
/*      */ 
/* 1285 */     Iterator i = this.removedStorageDirs.iterator();
/* 1286 */     while (i.hasNext()) {
/* 1287 */       Storage.StorageDirectory sd = (Storage.StorageDirectory)i.next();
/* 1288 */       FSNamesystem.LOG.info(new StringBuilder().append("Try to recover removed directory ").append(sd.getRoot()).append(" by reformatting").toString());
/*      */       try
/*      */       {
/* 1292 */         if (!sd.getRoot().exists()) {
/* 1293 */           throw new IOException(new StringBuilder().append("Directory ").append(sd.getRoot()).append("doesn't exist").toString());
/*      */         }
/* 1295 */         if (!FileUtil.fullyDeleteContents(sd.getRoot())) {
/* 1296 */           throw new IOException(new StringBuilder().append("Can't fully delete content of ").append(sd.getRoot()).toString());
/*      */         }
/* 1298 */         sd.clearDirectory();
/* 1299 */         restoreFile(goodVersion, sd.getCurrentDir(), "VERSION");
/* 1300 */         restoreFile(goodFstime, sd.getCurrentDir(), NameNodeFile.TIME.getName());
/*      */ 
/* 1303 */         File imageDir = new File(sd.getRoot(), "image");
/* 1304 */         if (!imageDir.mkdir()) {
/* 1305 */           throw new IOException("Can't make directory 'image'.");
/*      */         }
/* 1307 */         restoreFile(goodImage013, imageDir, NameNodeFile.IMAGE.getName());
/*      */ 
/* 1309 */         if (sd.getStorageDirType().equals(NameNodeDirType.EDITS)) {
/* 1310 */           restoreFile(goodEdits, sd.getCurrentDir(), NameNodeFile.EDITS.getName());
/* 1311 */         } else if (sd.getStorageDirType().equals(NameNodeDirType.IMAGE)) {
/* 1312 */           restoreFile(goodImage, sd.getCurrentDir(), NameNodeFile.IMAGE.getName());
/* 1313 */         } else if (sd.getStorageDirType().equals(NameNodeDirType.IMAGE_AND_EDITS))
/*      */         {
/* 1315 */           restoreFile(goodEdits, sd.getCurrentDir(), NameNodeFile.EDITS.getName());
/* 1316 */           restoreFile(goodImage, sd.getCurrentDir(), NameNodeFile.IMAGE.getName());
/*      */         } else {
/* 1318 */           throw new IOException(new StringBuilder().append("Invalid NameNodeDirType: ").append(sd.getStorageDirType()).toString());
/*      */         }
/*      */ 
/* 1323 */         i.remove();
/* 1324 */         addStorageDir(new Storage.StorageDirectory(this, sd.getRoot(), sd.getStorageDirType()));
/*      */       } catch (IOException e) {
/* 1326 */         FSNamesystem.LOG.warn(new StringBuilder().append("Failed to recover removed directory ").append(sd.getRoot()).append(" with ").append(e).toString());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   void format(Storage.StorageDirectory sd)
/*      */     throws IOException
/*      */   {
/* 1337 */     sd.clearDirectory();
/* 1338 */     sd.lock();
/*      */     try {
/* 1340 */       saveCurrent(sd);
/*      */     } finally {
/* 1342 */       sd.unlock();
/*      */     }
/* 1344 */     LOG.info(new StringBuilder().append("Storage directory ").append(sd.getRoot()).append(" has been successfully formatted.").toString());
/*      */   }
/*      */ 
/*      */   public void format() throws IOException
/*      */   {
/* 1349 */     this.layoutVersion = -41;
/* 1350 */     this.namespaceID = newNamespaceID();
/* 1351 */     this.cTime = 0L;
/* 1352 */     this.checkpointTime = FSNamesystem.now();
/* 1353 */     Iterator it = dirIterator();
/* 1354 */     while (it.hasNext()) {
/* 1355 */       Storage.StorageDirectory sd = (Storage.StorageDirectory)it.next();
/* 1356 */       format(sd);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void saveINode2Image(ByteBuffer name, INode node, DataOutputStream out)
/*      */     throws IOException
/*      */   {
/* 1366 */     int nameLen = name.position();
/* 1367 */     out.writeShort(nameLen);
/* 1368 */     out.write(name.array(), name.arrayOffset(), nameLen);
/* 1369 */     if (!node.isDirectory()) {
/* 1370 */       INodeFile fileINode = (INodeFile)node;
/* 1371 */       out.writeShort(fileINode.getReplication());
/* 1372 */       out.writeLong(fileINode.getModificationTime());
/* 1373 */       out.writeLong(fileINode.getAccessTime());
/* 1374 */       out.writeLong(fileINode.getPreferredBlockSize());
/* 1375 */       Block[] blocks = fileINode.getBlocks();
/* 1376 */       out.writeInt(blocks.length);
/* 1377 */       for (Block blk : blocks)
/* 1378 */         blk.write(out);
/* 1379 */       FILE_PERM.fromShort(fileINode.getFsPermissionShort());
/* 1380 */       PermissionStatus.write(out, fileINode.getUserName(), fileINode.getGroupName(), FILE_PERM);
/*      */     }
/*      */     else
/*      */     {
/* 1384 */       out.writeShort(0);
/* 1385 */       out.writeLong(node.getModificationTime());
/* 1386 */       out.writeLong(0L);
/* 1387 */       out.writeLong(0L);
/* 1388 */       out.writeInt(-1);
/* 1389 */       out.writeLong(node.getNsQuota());
/* 1390 */       out.writeLong(node.getDsQuota());
/* 1391 */       FILE_PERM.fromShort(node.getFsPermissionShort());
/* 1392 */       PermissionStatus.write(out, node.getUserName(), node.getGroupName(), FILE_PERM);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void saveImage(ByteBuffer parentPrefix, int prefixLength, INodeDirectory current, DataOutputStream out)
/*      */     throws IOException
/*      */   {
/* 1406 */     int newPrefixLength = prefixLength;
/* 1407 */     if (current.getChildrenRaw() == null)
/* 1408 */       return;
/* 1409 */     for (INode child : current.getChildren())
/*      */     {
/* 1411 */       parentPrefix.position(prefixLength);
/* 1412 */       parentPrefix.put(PATH_SEPARATOR).put(child.getLocalNameBytes());
/* 1413 */       saveINode2Image(parentPrefix, child, out);
/*      */     }
/* 1415 */     for (INode child : current.getChildren())
/* 1416 */       if (child.isDirectory())
/*      */       {
/* 1418 */         parentPrefix.position(prefixLength);
/* 1419 */         parentPrefix.put(PATH_SEPARATOR).put(child.getLocalNameBytes());
/* 1420 */         newPrefixLength = parentPrefix.position();
/* 1421 */         saveImage(parentPrefix, newPrefixLength, (INodeDirectory)child, out);
/*      */       }
/* 1423 */     parentPrefix.position(prefixLength);
/*      */   }
/*      */ 
/*      */   void loadDatanodes(int version, DataInputStream in) throws IOException {
/* 1427 */     if (version > -3)
/* 1428 */       return;
/* 1429 */     if (version <= -12) {
/* 1430 */       return;
/*      */     }
/* 1432 */     int size = in.readInt();
/* 1433 */     for (int i = 0; i < size; i++) {
/* 1434 */       DatanodeImage nodeImage = new DatanodeImage();
/* 1435 */       nodeImage.readFields(in);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void loadFilesUnderConstruction(int version, DataInputStream in, FSNamesystem fs)
/*      */     throws IOException
/*      */   {
/* 1443 */     FSDirectory fsDir = fs.dir;
/* 1444 */     if (version > -13)
/* 1445 */       return;
/* 1446 */     int size = in.readInt();
/*      */ 
/* 1448 */     LOG.info(new StringBuilder().append("Number of files under construction = ").append(size).toString());
/*      */ 
/* 1450 */     for (int i = 0; i < size; i++) {
/* 1451 */       INodeFileUnderConstruction cons = readINodeUnderConstruction(in);
/*      */ 
/* 1454 */       String path = cons.getLocalName();
/* 1455 */       INode old = fsDir.getFileINode(path);
/* 1456 */       if (old == null) {
/* 1457 */         throw new IOException(new StringBuilder().append("Found lease for non-existent file ").append(path).toString());
/*      */       }
/* 1459 */       if (old.isDirectory()) {
/* 1460 */         throw new IOException(new StringBuilder().append("Found lease for directory ").append(path).toString());
/*      */       }
/* 1462 */       INodeFile oldnode = (INodeFile)old;
/* 1463 */       fsDir.replaceNode(path, oldnode, cons);
/* 1464 */       fs.leaseManager.addLease(cons.clientName, path);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void loadSecretManagerState(int version, DataInputStream in, FSNamesystem fs) throws IOException
/*      */   {
/* 1470 */     if (version > -19)
/*      */     {
/* 1473 */       return;
/*      */     }
/* 1475 */     fs.loadSecretManagerState(in);
/*      */   }
/*      */ 
/*      */   static INodeFileUnderConstruction readINodeUnderConstruction(DataInputStream in)
/*      */     throws IOException
/*      */   {
/* 1483 */     byte[] name = readBytes(in);
/* 1484 */     short blockReplication = in.readShort();
/* 1485 */     long modificationTime = in.readLong();
/* 1486 */     long preferredBlockSize = in.readLong();
/* 1487 */     int numBlocks = in.readInt();
/* 1488 */     BlocksMap.BlockInfo[] blocks = new BlocksMap.BlockInfo[numBlocks];
/* 1489 */     Block blk = new Block();
/* 1490 */     for (int i = 0; i < numBlocks; i++) {
/* 1491 */       blk.readFields(in);
/* 1492 */       blocks[i] = new BlocksMap.BlockInfo(blk, blockReplication);
/*      */     }
/* 1494 */     PermissionStatus perm = PermissionStatus.read(in);
/* 1495 */     String clientName = readString(in);
/* 1496 */     String clientMachine = readString(in);
/*      */ 
/* 1499 */     int numLocs = in.readInt();
/* 1500 */     DatanodeDescriptor[] locations = new DatanodeDescriptor[numLocs];
/* 1501 */     for (int i = 0; i < numLocs; i++) {
/* 1502 */       locations[i] = new DatanodeDescriptor();
/* 1503 */       locations[i].readFields(in);
/*      */     }
/*      */ 
/* 1506 */     return new INodeFileUnderConstruction(name, blockReplication, modificationTime, preferredBlockSize, blocks, perm, clientName, clientMachine, null);
/*      */   }
/*      */ 
/*      */   static void writeINodeUnderConstruction(DataOutputStream out, INodeFileUnderConstruction cons, String path)
/*      */     throws IOException
/*      */   {
/* 1524 */     writeString(path, out);
/* 1525 */     out.writeShort(cons.getReplication());
/* 1526 */     out.writeLong(cons.getModificationTime());
/* 1527 */     out.writeLong(cons.getPreferredBlockSize());
/* 1528 */     int nrBlocks = cons.getBlocks().length;
/* 1529 */     out.writeInt(nrBlocks);
/* 1530 */     for (int i = 0; i < nrBlocks; i++) {
/* 1531 */       cons.getBlocks()[i].write(out);
/*      */     }
/* 1533 */     cons.getPermissionStatus().write(out);
/* 1534 */     writeString(cons.getClientName(), out);
/* 1535 */     writeString(cons.getClientMachine(), out);
/*      */ 
/* 1537 */     out.writeInt(0);
/*      */   }
/*      */ 
/*      */   void rollFSImage()
/*      */     throws IOException
/*      */   {
/* 1545 */     if (this.ckptState != CheckpointStates.UPLOAD_DONE) {
/* 1546 */       throw new IOException("Cannot roll fsImage before rolling edits log.");
/*      */     }
/*      */ 
/* 1552 */     if (!this.editLog.existsNew()) {
/* 1553 */       throw new IOException("New Edits file does not exist");
/*      */     }
/* 1555 */     Iterator it = dirIterator(NameNodeDirType.IMAGE);
/* 1556 */     while (it.hasNext()) {
/* 1557 */       Storage.StorageDirectory sd = (Storage.StorageDirectory)it.next();
/* 1558 */       File ckpt = getImageFile(sd, NameNodeFile.IMAGE_NEW);
/* 1559 */       if (!ckpt.exists()) {
/* 1560 */         throw new IOException(new StringBuilder().append("Checkpoint file ").append(ckpt).append(" does not exist").toString());
/*      */       }
/*      */     }
/*      */ 
/* 1564 */     this.editLog.purgeEditLog();
/*      */ 
/* 1569 */     it = dirIterator(NameNodeDirType.IMAGE);
/* 1570 */     while (it.hasNext()) {
/* 1571 */       Storage.StorageDirectory sd = (Storage.StorageDirectory)it.next();
/* 1572 */       File ckpt = getImageFile(sd, NameNodeFile.IMAGE_NEW);
/* 1573 */       File curFile = getImageFile(sd, NameNodeFile.IMAGE);
/*      */ 
/* 1576 */       if (!ckpt.renameTo(curFile)) {
/* 1577 */         curFile.delete();
/* 1578 */         if (!ckpt.renameTo(curFile)) {
/* 1579 */           this.editLog.removeEditsForStorageDir(sd);
/* 1580 */           updateRemovedDirs(sd);
/* 1581 */           it.remove();
/*      */         }
/*      */       }
/*      */     }
/* 1585 */     this.editLog.exitIfNoStreams();
/*      */ 
/* 1591 */     this.layoutVersion = -41;
/* 1592 */     this.checkpointTime = FSNamesystem.now();
/* 1593 */     it = dirIterator();
/* 1594 */     while (it.hasNext()) {
/* 1595 */       Storage.StorageDirectory sd = (Storage.StorageDirectory)it.next();
/*      */ 
/* 1597 */       if (!sd.getStorageDirType().isOfType(NameNodeDirType.EDITS)) {
/* 1598 */         File editsFile = getImageFile(sd, NameNodeFile.EDITS);
/* 1599 */         editsFile.delete();
/*      */       }
/*      */ 
/* 1602 */       if (!sd.getStorageDirType().isOfType(NameNodeDirType.IMAGE)) {
/* 1603 */         File imageFile = getImageFile(sd, NameNodeFile.IMAGE);
/* 1604 */         imageFile.delete();
/*      */       }
/*      */       try {
/* 1607 */         sd.write();
/*      */       } catch (IOException ioe) {
/* 1609 */         this.editLog.removeEditsForStorageDir(sd);
/* 1610 */         updateRemovedDirs(sd, ioe);
/* 1611 */         it.remove();
/*      */       }
/*      */     }
/* 1614 */     this.ckptState = CheckpointStates.START;
/*      */   }
/*      */ 
/*      */   CheckpointSignature rollEditLog() throws IOException {
/* 1618 */     getEditLog().rollEditLog();
/* 1619 */     this.ckptState = CheckpointStates.ROLLED_EDITS;
/* 1620 */     return new CheckpointSignature(this);
/*      */   }
/*      */ 
/*      */   void validateCheckpointUpload(CheckpointSignature sig)
/*      */     throws IOException
/*      */   {
/* 1628 */     if (this.ckptState != CheckpointStates.ROLLED_EDITS) {
/* 1629 */       throw new IOException(new StringBuilder().append("Namenode is not expecting an new image ").append(this.ckptState).toString());
/*      */     }
/*      */ 
/* 1633 */     long modtime = getEditLog().getFsEditTime();
/* 1634 */     if (sig.editsTime != modtime) {
/* 1635 */       throw new IOException(new StringBuilder().append("Namenode has an edit log with timestamp of ").append(DATE_FORM.format(new Date(modtime))).append(" but new checkpoint was created using editlog ").append(" with timestamp ").append(DATE_FORM.format(new Date(sig.editsTime))).append(". Checkpoint Aborted.").toString());
/*      */     }
/*      */ 
/* 1642 */     sig.validateStorageInfo(this);
/* 1643 */     this.ckptState = CheckpointStates.UPLOAD_START;
/*      */   }
/*      */ 
/*      */   synchronized void checkpointUploadDone()
/*      */   {
/* 1650 */     this.ckptState = CheckpointStates.UPLOAD_DONE;
/*      */   }
/*      */ 
/*      */   void close() throws IOException {
/* 1654 */     getEditLog().close();
/* 1655 */     unlockAll();
/*      */   }
/*      */ 
/*      */   File getFsImageName()
/*      */   {
/* 1662 */     Storage.StorageDirectory sd = null;
/* 1663 */     Iterator it = dirIterator(NameNodeDirType.IMAGE);
/* 1664 */     while (it.hasNext())
/* 1665 */       sd = (Storage.StorageDirectory)it.next();
/* 1666 */     return getImageFile(sd, NameNodeFile.IMAGE);
/*      */   }
/*      */ 
/*      */   public File getFsEditName() throws IOException {
/* 1670 */     return getEditLog().getFsEditName();
/*      */   }
/*      */ 
/*      */   File getFsTimeName() {
/* 1674 */     Storage.StorageDirectory sd = null;
/*      */ 
/* 1676 */     Iterator it = dirIterator();
/* 1677 */     while (it.hasNext())
/* 1678 */       sd = (Storage.StorageDirectory)it.next();
/* 1679 */     return getImageFile(sd, NameNodeFile.TIME);
/*      */   }
/*      */ 
/*      */   File[] getFsImageNameCheckpoint()
/*      */   {
/* 1687 */     ArrayList list = new ArrayList();
/* 1688 */     Iterator it = dirIterator(NameNodeDirType.IMAGE);
/* 1689 */     while (it.hasNext()) {
/* 1690 */       list.add(getImageFile((Storage.StorageDirectory)it.next(), NameNodeFile.IMAGE_NEW));
/*      */     }
/* 1692 */     return (File[])list.toArray(new File[list.size()]);
/*      */   }
/*      */ 
/*      */   protected void corruptPreUpgradeStorage(File rootDir)
/*      */     throws IOException
/*      */   {
/* 1740 */     File oldImageDir = new File(rootDir, "image");
/* 1741 */     if ((!oldImageDir.exists()) && 
/* 1742 */       (!oldImageDir.mkdir()))
/* 1743 */       throw new IOException(new StringBuilder().append("Cannot create directory ").append(oldImageDir).toString());
/* 1744 */     File oldImage = new File(oldImageDir, "fsimage");
/* 1745 */     if (!oldImage.exists())
/*      */     {
/* 1747 */       if (!oldImage.createNewFile())
/* 1748 */         throw new IOException(new StringBuilder().append("Cannot create file ").append(oldImage).toString()); 
/*      */     }
/* 1749 */     RandomAccessFile oldFile = new RandomAccessFile(oldImage, "rws");
/*      */     try
/*      */     {
/* 1752 */       writeCorruptedData(oldFile);
/*      */     } finally {
/* 1754 */       oldFile.close();
/*      */     }
/*      */   }
/*      */ 
/*      */   private boolean getDistributedUpgradeState() {
/* 1759 */     return FSNamesystem.getFSNamesystem().getDistributedUpgradeState();
/*      */   }
/*      */ 
/*      */   private int getDistributedUpgradeVersion() {
/* 1763 */     return FSNamesystem.getFSNamesystem().getDistributedUpgradeVersion();
/*      */   }
/*      */ 
/*      */   private void setDistributedUpgradeState(boolean uState, int uVersion) {
/* 1767 */     FSNamesystem.getFSNamesystem().upgradeManager.setUpgradeState(uState, uVersion);
/*      */   }
/*      */ 
/*      */   private void verifyDistributedUpgradeProgress(HdfsConstants.StartupOption startOpt) throws IOException
/*      */   {
/* 1772 */     if ((startOpt == HdfsConstants.StartupOption.ROLLBACK) || (startOpt == HdfsConstants.StartupOption.IMPORT))
/* 1773 */       return;
/* 1774 */     UpgradeManager um = FSNamesystem.getFSNamesystem().upgradeManager;
/* 1775 */     assert (um != null) : "FSNameSystem.upgradeManager is null.";
/* 1776 */     if (startOpt != HdfsConstants.StartupOption.UPGRADE) {
/* 1777 */       if (um.getUpgradeState()) {
/* 1778 */         throw new IOException("\n   Previous distributed upgrade was not completed. \n   Please restart NameNode with -upgrade option.");
/*      */       }
/*      */ 
/* 1781 */       if (um.getDistributedUpgrades() != null)
/* 1782 */         throw new IOException(new StringBuilder().append("\n   Distributed upgrade for NameNode version ").append(um.getUpgradeVersion()).append(" to current LV ").append(-41).append(" is required.\n   Please restart NameNode with -upgrade option.").toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   private void initializeDistributedUpgrade()
/*      */     throws IOException
/*      */   {
/* 1789 */     UpgradeManagerNamenode um = FSNamesystem.getFSNamesystem().upgradeManager;
/* 1790 */     if (!um.initializeUpgrade()) {
/* 1791 */       return;
/*      */     }
/* 1793 */     FSNamesystem.getFSNamesystem().getFSImage().writeAll();
/* 1794 */     NameNode.LOG.info(new StringBuilder().append("\n   Distributed upgrade for NameNode version ").append(um.getUpgradeVersion()).append(" to current LV ").append(-41).append(" is initialized.").toString());
/*      */   }
/*      */ 
/*      */   static Collection<File> getCheckpointDirs(Configuration conf, String defaultName)
/*      */   {
/* 1801 */     Collection dirNames = conf.getStringCollection("fs.checkpoint.dir");
/* 1802 */     if ((dirNames.size() == 0) && (defaultName != null)) {
/* 1803 */       dirNames.add(defaultName);
/*      */     }
/* 1805 */     Collection dirs = new ArrayList(dirNames.size());
/* 1806 */     for (String name : dirNames) {
/* 1807 */       dirs.add(new File(name));
/*      */     }
/* 1809 */     return dirs;
/*      */   }
/*      */ 
/*      */   static Collection<File> getCheckpointEditsDirs(Configuration conf, String defaultName)
/*      */   {
/* 1814 */     Collection dirNames = conf.getStringCollection("fs.checkpoint.edits.dir");
/*      */ 
/* 1816 */     if ((dirNames.size() == 0) && (defaultName != null)) {
/* 1817 */       dirNames.add(defaultName);
/*      */     }
/* 1819 */     Collection dirs = new ArrayList(dirNames.size());
/* 1820 */     for (String name : dirNames) {
/* 1821 */       dirs.add(new File(name));
/*      */     }
/* 1823 */     return dirs;
/*      */   }
/*      */ 
/*      */   public static String readString(DataInputStream in) throws IOException
/*      */   {
/* 1828 */     U_STR.readFields(in);
/* 1829 */     return U_STR.toStringChecked();
/*      */   }
/*      */ 
/*      */   static String readString_EmptyAsNull(DataInputStream in) throws IOException {
/* 1833 */     String s = readString(in);
/* 1834 */     return s.isEmpty() ? null : s;
/*      */   }
/*      */ 
/*      */   public static byte[] readBytes(DataInputStream in) throws IOException {
/* 1838 */     U_STR.readFields(in);
/* 1839 */     int len = U_STR.getLength();
/* 1840 */     byte[] bytes = new byte[len];
/* 1841 */     System.arraycopy(U_STR.getBytes(), 0, bytes, 0, len);
/* 1842 */     return bytes;
/*      */   }
/*      */ 
/*      */   static void writeString(String str, DataOutputStream out) throws IOException {
/* 1846 */     U_STR.set(str);
/* 1847 */     U_STR.write(out);
/*      */   }
/*      */ 
/*      */   static class DatanodeImage
/*      */     implements Writable
/*      */   {
/* 1700 */     DatanodeDescriptor node = new DatanodeDescriptor();
/*      */ 
/*      */     public void write(DataOutput out)
/*      */       throws IOException
/*      */     {
/* 1710 */       new DatanodeID(this.node).write(out);
/* 1711 */       out.writeLong(this.node.getCapacity());
/* 1712 */       out.writeLong(this.node.getRemaining());
/* 1713 */       out.writeLong(this.node.getLastUpdate());
/* 1714 */       out.writeInt(this.node.getXceiverCount());
/*      */     }
/*      */ 
/*      */     public void readFields(DataInput in)
/*      */       throws IOException
/*      */     {
/* 1722 */       DatanodeID id = new DatanodeID();
/* 1723 */       id.readFields(in);
/* 1724 */       long capacity = in.readLong();
/* 1725 */       long remaining = in.readLong();
/* 1726 */       long lastUpdate = in.readLong();
/* 1727 */       int xceiverCount = in.readInt();
/*      */ 
/* 1730 */       this.node.updateRegInfo(id);
/* 1731 */       this.node.setStorageID(id.getStorageID());
/* 1732 */       this.node.setCapacity(capacity);
/* 1733 */       this.node.setRemaining(remaining);
/* 1734 */       this.node.setLastUpdate(lastUpdate);
/* 1735 */       this.node.setXceiverCount(xceiverCount);
/*      */     }
/*      */   }
/*      */ 
/*      */   static enum NameNodeDirType
/*      */     implements Storage.StorageDirType
/*      */   {
/*   99 */     UNDEFINED, 
/*  100 */     IMAGE, 
/*  101 */     EDITS, 
/*  102 */     IMAGE_AND_EDITS;
/*      */ 
/*      */     public Storage.StorageDirType getStorageDirType() {
/*  105 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isOfType(Storage.StorageDirType type) {
/*  109 */       if ((this == IMAGE_AND_EDITS) && ((type == IMAGE) || (type == EDITS)))
/*  110 */         return true;
/*  111 */       return this == type;
/*      */     }
/*      */   }
/*      */ 
/*      */   static enum CheckpointStates
/*      */   {
/*   91 */     START, ROLLED_EDITS, UPLOAD_START, UPLOAD_DONE;
/*      */   }
/*      */ 
/*      */   static enum NameNodeFile
/*      */   {
/*   79 */     IMAGE("fsimage"), 
/*   80 */     TIME("fstime"), 
/*   81 */     EDITS("edits"), 
/*   82 */     IMAGE_NEW("fsimage.ckpt"), 
/*   83 */     EDITS_NEW("edits.new");
/*      */ 
/*   85 */     private String fileName = null;
/*      */ 
/*   86 */     private NameNodeFile(String name) { this.fileName = name; } 
/*   87 */     String getName() { return this.fileName; }
/*      */ 
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.FSImage
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.server.protocol;
/*    */ 
/*    */ import java.io.DataInput;
/*    */ import java.io.DataOutput;
/*    */ import java.io.IOException;
/*    */ import org.apache.hadoop.hdfs.server.common.StorageInfo;
/*    */ import org.apache.hadoop.io.UTF8;
/*    */ import org.apache.hadoop.io.Writable;
/*    */ import org.apache.hadoop.io.WritableFactories;
/*    */ import org.apache.hadoop.io.WritableFactory;
/*    */ import org.apache.hadoop.util.VersionInfo;
/*    */ 
/*    */ public class NamespaceInfo extends StorageInfo
/*    */   implements Writable
/*    */ {
/*    */   String revision;
/*    */   String version;
/*    */   int distributedUpgradeVersion;
/*    */ 
/*    */   public NamespaceInfo()
/*    */   {
/*    */   }
/*    */ 
/*    */   public NamespaceInfo(int nsID, long cT, int duVersion)
/*    */   {
/* 48 */     super(-41, nsID, cT);
/* 49 */     this.version = VersionInfo.getVersion();
/* 50 */     this.revision = VersionInfo.getRevision();
/* 51 */     this.distributedUpgradeVersion = duVersion;
/*    */   }
/*    */ 
/*    */   public String getVersion() {
/* 55 */     return this.version;
/*    */   }
/*    */ 
/*    */   public String getRevision() {
/* 59 */     return this.revision;
/*    */   }
/*    */ 
/*    */   public int getDistributedUpgradeVersion() {
/* 63 */     return this.distributedUpgradeVersion;
/*    */   }
/*    */ 
/*    */   public void write(DataOutput out)
/*    */     throws IOException
/*    */   {
/* 78 */     UTF8.writeString(out, getVersion());
/* 79 */     UTF8.writeString(out, getRevision());
/* 80 */     out.writeInt(getLayoutVersion());
/* 81 */     out.writeInt(getNamespaceID());
/* 82 */     out.writeLong(getCTime());
/* 83 */     out.writeInt(getDistributedUpgradeVersion());
/*    */   }
/*    */ 
/*    */   public void readFields(DataInput in) throws IOException {
/* 87 */     this.version = UTF8.readString(in);
/* 88 */     this.revision = UTF8.readString(in);
/* 89 */     this.layoutVersion = in.readInt();
/* 90 */     this.namespaceID = in.readInt();
/* 91 */     this.cTime = in.readLong();
/* 92 */     this.distributedUpgradeVersion = in.readInt();
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 70 */     WritableFactories.setFactory(NamespaceInfo.class, new WritableFactory()
/*    */     {
/*    */       public Writable newInstance() {
/* 73 */         return new NamespaceInfo();
/*    */       }
/*    */     });
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.protocol.NamespaceInfo
 * JD-Core Version:    0.6.1
 */
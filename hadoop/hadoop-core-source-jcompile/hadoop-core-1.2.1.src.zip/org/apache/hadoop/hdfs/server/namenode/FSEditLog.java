/*      */ package org.apache.hadoop.hdfs.server.namenode;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.DataInput;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutput;
/*      */ import java.io.EOFException;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.FilterInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.RandomAccessFile;
/*      */ import java.nio.Buffer;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.channels.FileChannel;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.apache.hadoop.fs.permission.FsPermission;
/*      */ import org.apache.hadoop.fs.permission.PermissionStatus;
/*      */ import org.apache.hadoop.hdfs.protocol.Block;
/*      */ import org.apache.hadoop.hdfs.protocol.DatanodeID;
/*      */ import org.apache.hadoop.hdfs.protocol.HdfsFileStatus;
/*      */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenIdentifier;
/*      */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenSecretManager;
/*      */ import org.apache.hadoop.hdfs.server.common.Storage;
/*      */ import org.apache.hadoop.hdfs.server.common.Storage.StorageDirType;
/*      */ import org.apache.hadoop.hdfs.server.common.Storage.StorageDirectory;
/*      */ import org.apache.hadoop.hdfs.server.namenode.metrics.NameNodeInstrumentation;
/*      */ import org.apache.hadoop.io.ArrayWritable;
/*      */ import org.apache.hadoop.io.DataOutputBuffer;
/*      */ import org.apache.hadoop.io.LongWritable;
/*      */ import org.apache.hadoop.io.UTF8;
/*      */ import org.apache.hadoop.io.Writable;
/*      */ import org.apache.hadoop.io.WritableFactories;
/*      */ import org.apache.hadoop.io.WritableFactory;
/*      */ import org.apache.hadoop.security.token.delegation.DelegationKey;
/*      */ 
/*      */ public class FSEditLog
/*      */ {
/*   67 */   public static final Log LOG = LogFactory.getLog(FSEditLog.class);
/*      */   static final byte OP_INVALID = -1;
/*      */   private static final byte OP_ADD = 0;
/*      */   private static final byte OP_RENAME = 1;
/*      */   private static final byte OP_DELETE = 2;
/*      */   private static final byte OP_MKDIR = 3;
/*      */   private static final byte OP_SET_REPLICATION = 4;
/*      */ 
/*      */   @Deprecated
/*      */   private static final byte OP_DATANODE_ADD = 5;
/*      */ 
/*      */   @Deprecated
/*      */   private static final byte OP_DATANODE_REMOVE = 6;
/*      */   private static final byte OP_SET_PERMISSIONS = 7;
/*      */   private static final byte OP_SET_OWNER = 8;
/*      */   private static final byte OP_CLOSE = 9;
/*      */   private static final byte OP_SET_GENSTAMP = 10;
/*      */   private static final byte OP_SET_NS_QUOTA = 11;
/*      */   private static final byte OP_CLEAR_NS_QUOTA = 12;
/*      */   private static final byte OP_TIMES = 13;
/*      */   private static final byte OP_SET_QUOTA = 14;
/*      */   private static final byte OP_CONCAT_DELETE = 16;
/*      */   private static final byte OP_GET_DELEGATION_TOKEN = 18;
/*      */   private static final byte OP_RENEW_DELEGATION_TOKEN = 19;
/*      */   private static final byte OP_CANCEL_DELEGATION_TOKEN = 20;
/*      */   private static final byte OP_UPDATE_MASTER_KEY = 21;
/*   94 */   private static int sizeFlushBuffer = 524288;
/*      */   static final int MIN_PREALLOCATION_LENGTH = 1048576;
/*   98 */   private static int TRANSACTION_LENGTH_LIMIT = 2147483647;
/*      */ 
/*  100 */   private ArrayList<EditLogOutputStream> editStreams = null;
/*  101 */   private FSImage fsimage = null;
/*      */ 
/*  104 */   private long txid = 0L;
/*      */ 
/*  107 */   private long synctxid = 0L;
/*      */   private long lastPrintTime;
/*      */   private boolean isSyncRunning;
/*      */   private long numTransactions;
/*      */   private long numTransactionsBatchedInSync;
/*      */   private long totalTimeTransactions;
/*      */   private NameNodeInstrumentation metrics;
/*  130 */   private static final ThreadLocal<TransactionId> myTransactionId = new ThreadLocal() {
/*      */     protected synchronized FSEditLog.TransactionId initialValue() {
/*  132 */       return new FSEditLog.TransactionId(9223372036854775807L);
/*      */     }
/*  130 */   };
/*      */ 
/* 1103 */   private static final LongWritable longWritable = new LongWritable();
/*      */ 
/*      */   FSEditLog(FSImage image)
/*      */   {
/*  332 */     this.fsimage = image;
/*  333 */     this.isSyncRunning = false;
/*  334 */     this.metrics = NameNode.getNameNodeMetrics();
/*  335 */     this.lastPrintTime = FSNamesystem.now();
/*      */   }
/*      */ 
/*      */   private File getEditFile(Storage.StorageDirectory sd) {
/*  339 */     return this.fsimage.getEditFile(sd);
/*      */   }
/*      */ 
/*      */   private File getEditNewFile(Storage.StorageDirectory sd) {
/*  343 */     return this.fsimage.getEditNewFile(sd);
/*      */   }
/*      */ 
/*      */   private int getNumStorageDirs() {
/*  347 */     int numStorageDirs = 0;
/*  348 */     Iterator it = this.fsimage.dirIterator(FSImage.NameNodeDirType.EDITS);
/*  349 */     while (it.hasNext()) {
/*  350 */       numStorageDirs++;
/*  351 */       it.next();
/*      */     }
/*  353 */     return numStorageDirs;
/*      */   }
/*      */ 
/*      */   synchronized int getNumEditStreams() {
/*  357 */     return this.editStreams == null ? 0 : this.editStreams.size();
/*      */   }
/*      */ 
/*      */   boolean isOpen() {
/*  361 */     return getNumEditStreams() > 0;
/*      */   }
/*      */ 
/*      */   public synchronized void open()
/*      */     throws IOException
/*      */   {
/*  371 */     this.numTransactions = (this.totalTimeTransactions = this.numTransactionsBatchedInSync = 0L);
/*  372 */     if (this.editStreams == null) {
/*  373 */       this.editStreams = new ArrayList();
/*      */     }
/*  375 */     Iterator it = this.fsimage.dirIterator(FSImage.NameNodeDirType.EDITS);
/*  376 */     while (it.hasNext()) {
/*  377 */       Storage.StorageDirectory sd = (Storage.StorageDirectory)it.next();
/*  378 */       File eFile = getEditFile(sd);
/*      */       try {
/*  380 */         EditLogOutputStream eStream = new EditLogFileOutputStream(eFile);
/*  381 */         this.editStreams.add(eStream);
/*      */       } catch (IOException ioe) {
/*  383 */         this.fsimage.updateRemovedDirs(sd, ioe);
/*  384 */         it.remove();
/*      */       }
/*      */     }
/*  387 */     exitIfNoStreams();
/*      */   }
/*      */ 
/*      */   public synchronized void createEditLogFile(File name) throws IOException {
/*  391 */     EditLogOutputStream eStream = new EditLogFileOutputStream(name);
/*  392 */     eStream.create();
/*  393 */     eStream.close();
/*      */   }
/*      */ 
/*      */   public synchronized void close()
/*      */     throws IOException
/*      */   {
/*  400 */     while (this.isSyncRunning)
/*      */       try {
/*  402 */         wait(1000L);
/*      */       }
/*      */       catch (InterruptedException ie) {
/*      */       }
/*  406 */     if (this.editStreams == null) {
/*  407 */       return;
/*      */     }
/*  409 */     printStatistics(true);
/*  410 */     this.numTransactions = (this.totalTimeTransactions = this.numTransactionsBatchedInSync = 0L);
/*      */ 
/*  412 */     for (int idx = 0; idx < this.editStreams.size(); idx++) {
/*  413 */       EditLogOutputStream eStream = (EditLogOutputStream)this.editStreams.get(idx);
/*      */       try {
/*  415 */         eStream.setReadyToFlush();
/*  416 */         eStream.flush();
/*  417 */         eStream.close();
/*      */       } catch (IOException ioe) {
/*  419 */         removeEditsAndStorageDir(idx);
/*  420 */         idx--;
/*      */       }
/*      */     }
/*  423 */     this.editStreams.clear();
/*      */   }
/*      */ 
/*      */   void fatalExit(String msg) {
/*  427 */     LOG.fatal(msg, new Exception(msg));
/*  428 */     Runtime.getRuntime().exit(-1);
/*      */   }
/*      */ 
/*      */   private void exitIfStreamsNotSet()
/*      */   {
/*  436 */     if (this.editStreams == null)
/*  437 */       fatalExit("Edit streams not yet initialized");
/*      */   }
/*      */ 
/*      */   void exitIfNoStreams()
/*      */   {
/*  445 */     if ((this.editStreams == null) || (this.editStreams.isEmpty()))
/*  446 */       fatalExit("No edit streams are accessible");
/*      */   }
/*      */ 
/*      */   private File getStorageDirForStream(int idx)
/*      */   {
/*  454 */     File editsFile = ((EditLogFileOutputStream)this.editStreams.get(idx)).getFile();
/*      */ 
/*  457 */     return editsFile.getParentFile().getParentFile();
/*      */   }
/*      */ 
/*      */   synchronized void removeEditsAndStorageDir(int idx)
/*      */   {
/*  464 */     exitIfStreamsNotSet();
/*      */ 
/*  466 */     assert (idx < getNumStorageDirs());
/*  467 */     assert (getNumStorageDirs() == this.editStreams.size());
/*      */ 
/*  469 */     File dir = getStorageDirForStream(idx);
/*  470 */     this.editStreams.remove(idx);
/*  471 */     exitIfNoStreams();
/*  472 */     this.fsimage.removeStorageDir(dir);
/*      */   }
/*      */ 
/*      */   synchronized void removeEditsForStorageDir(Storage.StorageDirectory sd)
/*      */   {
/*  479 */     exitIfStreamsNotSet();
/*      */ 
/*  481 */     if (!sd.getStorageDirType().isOfType(FSImage.NameNodeDirType.EDITS)) {
/*  482 */       return;
/*      */     }
/*  484 */     for (int idx = 0; idx < this.editStreams.size(); idx++) {
/*  485 */       File parentDir = getStorageDirForStream(idx);
/*  486 */       if (parentDir.getAbsolutePath().equals(sd.getRoot().getAbsolutePath()))
/*      */       {
/*  488 */         this.editStreams.remove(idx);
/*  489 */         idx--;
/*      */       }
/*      */     }
/*  492 */     exitIfNoStreams();
/*      */   }
/*      */ 
/*      */   private void removeEditsStreamsAndStorageDirs(ArrayList<EditLogOutputStream> errorStreams)
/*      */   {
/*  501 */     if (errorStreams == null) {
/*  502 */       return;
/*      */     }
/*  504 */     for (EditLogOutputStream errorStream : errorStreams) {
/*  505 */       int idx = this.editStreams.indexOf(errorStream);
/*  506 */       if (-1 == idx) {
/*  507 */         fatalExit("Unable to find edits stream with IO error");
/*      */       }
/*  509 */       removeEditsAndStorageDir(idx);
/*      */     }
/*  511 */     this.fsimage.incrementCheckpointTime();
/*      */   }
/*      */ 
/*      */   boolean existsNew()
/*      */     throws IOException
/*      */   {
/*  518 */     Iterator it = this.fsimage.dirIterator(FSImage.NameNodeDirType.EDITS);
/*  519 */     while (it.hasNext()) {
/*  520 */       if (getEditNewFile((Storage.StorageDirectory)it.next()).exists()) {
/*  521 */         return true;
/*      */       }
/*      */     }
/*  524 */     return false;
/*      */   }
/*      */ 
/*      */   private static void checkEndOfLog(EditLogInputStream edits, DataInputStream in, PositionTrackingInputStream pin, int tolerationLength)
/*      */     throws IOException
/*      */   {
/*  537 */     if (tolerationLength < 0)
/*      */     {
/*  539 */       return;
/*      */     }
/*  541 */     LOG.info(new StringBuilder().append("Start checking end of edit log (").append(edits.getName()).append(") ...").toString());
/*      */ 
/*  543 */     in.mark(0);
/*  544 */     long readLength = pin.getPos();
/*      */ 
/*  546 */     long firstPadPos = -1L;
/*  547 */     byte pad = 0;
/*      */ 
/*  549 */     byte[] bytes = new byte[4096];
/*      */     int n;
/*  550 */     while ((n = in.read(bytes)) != -1)
/*  551 */       for (int i = 0; i < n; i++) {
/*  552 */         byte b = bytes[i];
/*      */ 
/*  554 */         if ((firstPadPos != -1L) && (b != pad))
/*      */         {
/*  556 */           firstPadPos = -1L;
/*      */ 
/*  558 */           if (LOG.isDebugEnabled()) {
/*  559 */             LOG.debug(String.format("reset: bytes[%d]=0x%X, pad=0x%02X", new Object[] { Integer.valueOf(i), Byte.valueOf(b), Byte.valueOf(pad) }));
/*      */           }
/*      */         }
/*      */ 
/*  563 */         if ((firstPadPos == -1L) && (
/*  564 */           (b == 0) || (b == -1)))
/*      */         {
/*  566 */           firstPadPos = pin.getPos() - n + i;
/*  567 */           pad = b;
/*      */ 
/*  569 */           if (LOG.isDebugEnabled())
/*  570 */             LOG.debug(String.format("found: bytes[%d]=0x%02X=pad, firstPadPos=%d", new Object[] { Integer.valueOf(i), Byte.valueOf(b), Long.valueOf(firstPadPos) }));
/*      */         }
/*      */       }
/*      */     long padLength;
/*      */     long corruptionLength;
/*      */     long padLength;
/*  580 */     if (firstPadPos == -1L) {
/*  581 */       long corruptionLength = edits.length() - readLength;
/*  582 */       padLength = 0L;
/*      */     } else {
/*  584 */       corruptionLength = firstPadPos - readLength;
/*  585 */       padLength = edits.length() - firstPadPos;
/*      */     }
/*      */ 
/*  588 */     LOG.info(new StringBuilder().append("Checked the bytes after the end of edit log (").append(edits.getName()).append("):").toString());
/*  589 */     LOG.info(new StringBuilder().append("  Padding position  = ").append(firstPadPos).append(" (-1 means padding not found)").toString());
/*  590 */     LOG.info(new StringBuilder().append("  Edit log length   = ").append(edits.length()).toString());
/*  591 */     LOG.info(new StringBuilder().append("  Read length       = ").append(readLength).toString());
/*  592 */     LOG.info(new StringBuilder().append("  Corruption length = ").append(corruptionLength).toString());
/*  593 */     LOG.info(new StringBuilder().append("  Toleration length = ").append(tolerationLength).append(" (= ").append("dfs.namenode.edits.toleration.length").append(")").toString());
/*      */ 
/*  595 */     LOG.info(String.format("Summary: |---------- Read=%d ----------|-- Corrupt=%d --|-- Pad=%d --|", new Object[] { Long.valueOf(readLength), Long.valueOf(corruptionLength), Long.valueOf(padLength) }));
/*      */ 
/*  599 */     if (pin.getPos() != edits.length()) {
/*  600 */       throw new IOException(new StringBuilder().append("Edit log length mismatched: edits.length() = ").append(edits.length()).append(" != input steam position = ").append(pin.getPos()).toString());
/*      */     }
/*      */ 
/*  603 */     if (corruptionLength > 0L) {
/*  604 */       String err = new StringBuilder().append("Edit log corruption detected: corruption length = ").append(corruptionLength).toString();
/*  605 */       if (corruptionLength <= tolerationLength) {
/*  606 */         LOG.warn(new StringBuilder().append(err).append(" <= toleration length = ").append(tolerationLength).append("; the corruption is tolerable.").toString());
/*      */       }
/*      */       else
/*  609 */         throw new IOException(new StringBuilder().append(err).append(" > toleration length = ").append(tolerationLength).append("; the corruption is intolerable.").toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   static int loadFSEdits(EditLogInputStream edits, int tolerationLength, MetaRecoveryContext recovery)
/*      */     throws IOException
/*      */   {
/*  623 */     FSNamesystem fsNamesys = FSNamesystem.getFSNamesystem();
/*  624 */     FSDirectory fsDir = fsNamesys.dir;
/*  625 */     int numEdits = 0;
/*  626 */     int logVersion = 0;
/*  627 */     String clientName = null;
/*  628 */     String clientMachine = null;
/*  629 */     String path = null;
/*  630 */     int numOpAdd = 0; int numOpClose = 0; int numOpDelete = 0;
/*  631 */     int numOpRename = 0; int numOpSetRepl = 0; int numOpMkDir = 0;
/*  632 */     int numOpSetPerm = 0; int numOpSetOwner = 0; int numOpSetGenStamp = 0;
/*  633 */     int numOpTimes = 0; int numOpGetDelegationToken = 0;
/*  634 */     int numOpRenewDelegationToken = 0; int numOpCancelDelegationToken = 0;
/*  635 */     int numOpUpdateMasterKey = 0; int numOpOther = 0;
/*  636 */     int numOpConcatDelete = 0;
/*  637 */     long highestGenStamp = -1L;
/*  638 */     long startTime = FSNamesystem.now();
/*      */ 
/*  640 */     LOG.info(new StringBuilder().append("Start loading edits file ").append(edits.getName()).toString());
/*      */ 
/*  644 */     PositionTrackingInputStream tracker = new PositionTrackingInputStream(new BufferedInputStream(edits));
/*      */ 
/*  646 */     long[] recentOpcodeOffsets = new long[4];
/*  647 */     Arrays.fill(recentOpcodeOffsets, -1L);
/*      */ 
/*  649 */     boolean isTolerationEnabled = tolerationLength >= 0;
/*  650 */     DataInputStream in = new DataInputStream(tracker);
/*  651 */     Byte opcode = null;
/*      */     try
/*      */     {
/*  654 */       in.mark(4);
/*      */ 
/*  657 */       boolean available = true;
/*      */       try {
/*  659 */         logVersion = in.readByte();
/*      */       } catch (EOFException e) {
/*  661 */         available = false;
/*      */       }
/*  663 */       if (available) {
/*  664 */         in.reset();
/*  665 */         logVersion = in.readInt();
/*  666 */         if (logVersion < -41) {
/*  667 */           throw new IOException(new StringBuilder().append("Unexpected version of the file system log file: ").append(logVersion).append(". Current version = ").append(-41).append(".").toString());
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  673 */       assert (logVersion <= -7) : new StringBuilder().append("Unsupported version ").append(logVersion).toString();
/*      */       while (true)
/*      */       {
/*  676 */         if (isTolerationEnabled)
/*      */         {
/*  678 */           in.mark(TRANSACTION_LENGTH_LIMIT);
/*      */         }
/*      */ 
/*  681 */         long timestamp = 0L;
/*  682 */         long mtime = 0L;
/*  683 */         long atime = 0L;
/*  684 */         long blockSize = 0L;
/*  685 */         opcode = null;
/*      */         try {
/*  687 */           opcode = Byte.valueOf(in.readByte());
/*  688 */           if (opcode.byteValue() == -1) {
/*  689 */             LOG.info(new StringBuilder().append("Invalid opcode, reached end of edit log Number of transactions found: ").append(numEdits).append(".  ").append("Bytes read: ").append(tracker.getPos()).toString());
/*      */ 
/*  692 */             break;
/*      */           }
/*      */         } catch (EOFException e) {
/*  695 */           LOG.info(new StringBuilder().append("EOF of ").append(edits.getName()).append(", reached end of edit log ").append("Number of transactions found: ").append(numEdits).append(".  ").append("Bytes read: ").append(tracker.getPos()).toString());
/*      */ 
/*  698 */           break;
/*      */         }
/*  700 */         recentOpcodeOffsets[(numEdits % recentOpcodeOffsets.length)] = tracker.getPos();
/*      */ 
/*  702 */         numEdits++;
/*  703 */         switch (opcode.byteValue())
/*      */         {
/*      */         case 0:
/*      */         case 9:
/*  708 */           int length = in.readInt();
/*  709 */           if (((-7 == logVersion) && (length != 3)) || ((-17 < logVersion) && (logVersion < -7) && (length != 4)) || ((logVersion <= -17) && (length != 5)))
/*      */           {
/*  712 */             throw new IOException(new StringBuilder().append("Incorrect data format. logVersion is ").append(logVersion).append(" but writables.length is ").append(length).append(". ").toString());
/*      */           }
/*      */ 
/*  717 */           path = FSImage.readString(in);
/*  718 */           short replication = adjustReplication(readShort(in));
/*  719 */           mtime = readLong(in);
/*  720 */           if (logVersion <= -17) {
/*  721 */             atime = readLong(in);
/*      */           }
/*  723 */           if (logVersion < -7) {
/*  724 */             blockSize = readLong(in);
/*      */           }
/*      */ 
/*  727 */           Block[] blocks = null;
/*  728 */           if (logVersion <= -14) {
/*  729 */             blocks = readBlocks(in);
/*      */           } else {
/*  731 */             BlockTwo oldblk = new BlockTwo();
/*  732 */             int num = in.readInt();
/*  733 */             blocks = new Block[num];
/*  734 */             for (int i = 0; i < num; i++) {
/*  735 */               oldblk.readFields(in);
/*  736 */               blocks[i] = new Block(oldblk.blkid, oldblk.len, 0L);
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  745 */           if ((-8 <= logVersion) && (blockSize == 0L)) {
/*  746 */             if (blocks.length > 1) {
/*  747 */               blockSize = blocks[0].getNumBytes();
/*      */             } else {
/*  749 */               long first = blocks.length == 1 ? blocks[0].getNumBytes() : 0L;
/*  750 */               blockSize = Math.max(fsNamesys.getDefaultBlockSize(), first);
/*      */             }
/*      */           }
/*      */ 
/*  754 */           PermissionStatus permissions = fsNamesys.getUpgradePermission();
/*  755 */           if (logVersion <= -11) {
/*  756 */             permissions = PermissionStatus.read(in);
/*      */           }
/*      */ 
/*  760 */           if ((opcode.byteValue() == 0) && (logVersion <= -12)) {
/*  761 */             clientName = FSImage.readString(in);
/*  762 */             clientMachine = FSImage.readString(in);
/*  763 */             if (-13 <= logVersion)
/*  764 */               readDatanodeDescriptorArray(in);
/*      */           }
/*      */           else {
/*  767 */             clientName = "";
/*  768 */             clientMachine = "";
/*      */           }
/*      */ 
/*  773 */           if (LOG.isDebugEnabled()) {
/*  774 */             LOG.debug(new StringBuilder().append(opcode).append(": ").append(path).append(" numblocks : ").append(blocks.length).append(" clientHolder ").append(clientName).append(" clientMachine ").append(clientMachine).toString());
/*      */           }
/*      */ 
/*  780 */           fsDir.unprotectedDelete(path, mtime);
/*      */ 
/*  783 */           INodeFile node = (INodeFile)fsDir.unprotectedAddFile(path, permissions, blocks, replication, mtime, atime, blockSize);
/*      */ 
/*  787 */           if (opcode.byteValue() == 0) {
/*  788 */             numOpAdd++;
/*      */ 
/*  793 */             INodeFileUnderConstruction cons = new INodeFileUnderConstruction(node.getLocalNameBytes(), node.getReplication(), node.getModificationTime(), node.getPreferredBlockSize(), node.getBlocks(), node.getPermissionStatus(), clientName, clientMachine, null);
/*      */ 
/*  803 */             fsDir.replaceNode(path, node, cons);
/*  804 */             fsNamesys.leaseManager.addLease(cons.clientName, path);
/*  805 */           }break;
/*      */         case 4:
/*  809 */           numOpSetRepl++;
/*  810 */           path = FSImage.readString(in);
/*  811 */           short replication = adjustReplication(readShort(in));
/*  812 */           fsDir.unprotectedSetReplication(path, replication, null);
/*  813 */           break;
/*      */         case 16:
/*  816 */           if (logVersion > -22) {
/*  817 */             throw new IOException(new StringBuilder().append("Unexpected opcode ").append(opcode).append(" for version ").append(logVersion).toString());
/*      */           }
/*      */ 
/*  820 */           numOpConcatDelete++;
/*  821 */           int length = in.readInt();
/*  822 */           if (length < 3) {
/*  823 */             throw new IOException("Incorrect data format. ConcatDelete operation.");
/*      */           }
/*      */ 
/*  826 */           String trg = FSImage.readString(in);
/*  827 */           int srcSize = length - 1 - 1;
/*  828 */           String[] srcs = new String[srcSize];
/*  829 */           for (int i = 0; i < srcSize; i++) {
/*  830 */             srcs[i] = FSImage.readString(in);
/*      */           }
/*  832 */           timestamp = readLong(in);
/*  833 */           fsDir.unprotectedConcat(trg, srcs, timestamp);
/*  834 */           break;
/*      */         case 1:
/*  837 */           numOpRename++;
/*  838 */           int length = in.readInt();
/*  839 */           if (length != 3) {
/*  840 */             throw new IOException("Incorrect data format. Rename operation.");
/*      */           }
/*      */ 
/*  843 */           String s = FSImage.readString(in);
/*  844 */           String d = FSImage.readString(in);
/*  845 */           timestamp = readLong(in);
/*  846 */           HdfsFileStatus dinfo = fsDir.getFileInfo(d);
/*  847 */           fsDir.unprotectedRenameTo(s, d, timestamp);
/*  848 */           fsNamesys.changeLease(s, d, dinfo);
/*  849 */           break;
/*      */         case 2:
/*  852 */           numOpDelete++;
/*  853 */           int length = in.readInt();
/*  854 */           if (length != 2) {
/*  855 */             throw new IOException("Incorrect data format. delete operation.");
/*      */           }
/*      */ 
/*  858 */           path = FSImage.readString(in);
/*  859 */           timestamp = readLong(in);
/*  860 */           fsDir.unprotectedDelete(path, timestamp);
/*  861 */           break;
/*      */         case 3:
/*  864 */           numOpMkDir++;
/*  865 */           PermissionStatus permissions = fsNamesys.getUpgradePermission();
/*  866 */           int length = in.readInt();
/*  867 */           if (((-17 < logVersion) && (length != 2)) || ((logVersion <= -17) && (length != 3)))
/*      */           {
/*  869 */             throw new IOException("Incorrect data format. Mkdir operation.");
/*      */           }
/*      */ 
/*  872 */           path = FSImage.readString(in);
/*  873 */           timestamp = readLong(in);
/*      */ 
/*  878 */           if (logVersion <= -17) {
/*  879 */             atime = readLong(in);
/*      */           }
/*      */ 
/*  882 */           if (logVersion <= -11) {
/*  883 */             permissions = PermissionStatus.read(in);
/*      */           }
/*  885 */           fsDir.unprotectedMkdir(path, permissions, timestamp);
/*  886 */           break;
/*      */         case 10:
/*  889 */           numOpSetGenStamp++;
/*  890 */           long lw = in.readLong();
/*  891 */           if ((highestGenStamp != -1L) && (highestGenStamp + 1L != lw)) {
/*  892 */             throw new IOException(new StringBuilder().append("OP_SET_GENSTAMP tried to set a genstamp of ").append(lw).append(" but the previous highest genstamp was ").append(highestGenStamp).toString());
/*      */           }
/*      */ 
/*  895 */           highestGenStamp = lw;
/*  896 */           fsDir.namesystem.setGenerationStamp(lw);
/*  897 */           break;
/*      */         case 5:
/*  900 */           numOpOther++;
/*  901 */           FSImage.DatanodeImage nodeimage = new FSImage.DatanodeImage();
/*  902 */           nodeimage.readFields(in);
/*      */ 
/*  904 */           break;
/*      */         case 6:
/*  907 */           numOpOther++;
/*  908 */           DatanodeID nodeID = new DatanodeID();
/*  909 */           nodeID.readFields(in);
/*      */ 
/*  911 */           break;
/*      */         case 7:
/*  914 */           numOpSetPerm++;
/*  915 */           if (logVersion > -11) {
/*  916 */             throw new IOException(new StringBuilder().append("Unexpected opcode ").append(opcode).append(" for version ").append(logVersion).toString());
/*      */           }
/*  918 */           fsDir.unprotectedSetPermission(FSImage.readString(in), FsPermission.read(in));
/*      */ 
/*  920 */           break;
/*      */         case 8:
/*  923 */           numOpSetOwner++;
/*  924 */           if (logVersion > -11) {
/*  925 */             throw new IOException(new StringBuilder().append("Unexpected opcode ").append(opcode).append(" for version ").append(logVersion).toString());
/*      */           }
/*  927 */           fsDir.unprotectedSetOwner(FSImage.readString(in), FSImage.readString_EmptyAsNull(in), FSImage.readString_EmptyAsNull(in));
/*      */ 
/*  930 */           break;
/*      */         case 11:
/*  933 */           if (logVersion > -16) {
/*  934 */             throw new IOException(new StringBuilder().append("Unexpected opcode ").append(opcode).append(" for version ").append(logVersion).toString());
/*      */           }
/*      */ 
/*  937 */           fsDir.unprotectedSetQuota(FSImage.readString(in), readLongWritable(in), 9223372036854775807L);
/*      */ 
/*  940 */           break;
/*      */         case 12:
/*  943 */           if (logVersion > -16) {
/*  944 */             throw new IOException(new StringBuilder().append("Unexpected opcode ").append(opcode).append(" for version ").append(logVersion).toString());
/*      */           }
/*      */ 
/*  947 */           fsDir.unprotectedSetQuota(FSImage.readString(in), -1L, 9223372036854775807L);
/*      */ 
/*  950 */           break;
/*      */         case 14:
/*  954 */           fsDir.unprotectedSetQuota(FSImage.readString(in), readLongWritable(in), readLongWritable(in));
/*      */ 
/*  958 */           break;
/*      */         case 13:
/*  961 */           numOpTimes++;
/*  962 */           int length = in.readInt();
/*  963 */           if (length != 3) {
/*  964 */             throw new IOException("Incorrect data format. times operation.");
/*      */           }
/*      */ 
/*  967 */           path = FSImage.readString(in);
/*  968 */           mtime = readLong(in);
/*  969 */           atime = readLong(in);
/*  970 */           fsDir.unprotectedSetTimes(path, mtime, atime, true);
/*  971 */           break;
/*      */         case 18:
/*  974 */           if (logVersion > -19) {
/*  975 */             throw new IOException(new StringBuilder().append("Unexpected opcode ").append(opcode).append(" for version ").append(logVersion).toString());
/*      */           }
/*      */ 
/*  978 */           numOpGetDelegationToken++;
/*  979 */           DelegationTokenIdentifier delegationTokenId = new DelegationTokenIdentifier();
/*      */ 
/*  981 */           delegationTokenId.readFields(in);
/*  982 */           long expiryTime = readLong(in);
/*  983 */           fsNamesys.getDelegationTokenSecretManager().addPersistedDelegationToken(delegationTokenId, expiryTime);
/*      */ 
/*  985 */           break;
/*      */         case 19:
/*  988 */           if (logVersion > -19) {
/*  989 */             throw new IOException(new StringBuilder().append("Unexpected opcode ").append(opcode).append(" for version ").append(logVersion).toString());
/*      */           }
/*      */ 
/*  992 */           numOpRenewDelegationToken++;
/*  993 */           DelegationTokenIdentifier delegationTokenId = new DelegationTokenIdentifier();
/*      */ 
/*  995 */           delegationTokenId.readFields(in);
/*  996 */           long expiryTime = readLong(in);
/*  997 */           fsNamesys.getDelegationTokenSecretManager().updatePersistedTokenRenewal(delegationTokenId, expiryTime);
/*      */ 
/*  999 */           break;
/*      */         case 20:
/* 1002 */           if (logVersion > -19) {
/* 1003 */             throw new IOException(new StringBuilder().append("Unexpected opcode ").append(opcode).append(" for version ").append(logVersion).toString());
/*      */           }
/*      */ 
/* 1006 */           numOpCancelDelegationToken++;
/* 1007 */           DelegationTokenIdentifier delegationTokenId = new DelegationTokenIdentifier();
/*      */ 
/* 1009 */           delegationTokenId.readFields(in);
/* 1010 */           fsNamesys.getDelegationTokenSecretManager().updatePersistedTokenCancellation(delegationTokenId);
/*      */ 
/* 1012 */           break;
/*      */         case 21:
/* 1015 */           if (logVersion > -19) {
/* 1016 */             throw new IOException(new StringBuilder().append("Unexpected opcode ").append(opcode).append(" for version ").append(logVersion).toString());
/*      */           }
/*      */ 
/* 1019 */           numOpUpdateMasterKey++;
/* 1020 */           DelegationKey delegationKey = new DelegationKey();
/* 1021 */           delegationKey.readFields(in);
/* 1022 */           fsNamesys.getDelegationTokenSecretManager().updatePersistedMasterKey(delegationKey);
/*      */ 
/* 1024 */           break;
/*      */         case 15:
/*      */         case 17:
/*      */         default:
/* 1027 */           throw new IOException(new StringBuilder().append("Never seen opcode ").append(opcode).toString());
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Throwable t) {
/* 1032 */       String msg = new StringBuilder().append("Failed to parse edit log (").append(edits.getName()).append(") at position ").append(tracker.getPos()).append(", edit log length is ").append(edits.length()).append(", opcode=").append(opcode).append(", isTolerationEnabled=").append(isTolerationEnabled).toString();
/*      */ 
/* 1040 */       if ((Storage.is203LayoutVersion(logVersion)) && (logVersion != -41))
/*      */       {
/* 1045 */         msg = new StringBuilder().append(msg).append(": During upgrade, failed to load the editlog version ").append(logVersion).append(" from release 0.20.203. Please go back to the old ").append(" release and restart the namenode. This empties the editlog ").append(" and saves the namespace. Resume the upgrade after this step.").toString();
/*      */ 
/* 1049 */         throw new IOException(msg, t);
/*      */       }
/* 1051 */       if (recentOpcodeOffsets[0] != -1L) {
/* 1052 */         Arrays.sort(recentOpcodeOffsets);
/* 1053 */         StringBuilder sb = new StringBuilder(", Recent opcode offsets=[").append(recentOpcodeOffsets[0]);
/*      */ 
/* 1055 */         for (int i = 1; i < recentOpcodeOffsets.length; i++) {
/* 1056 */           if (recentOpcodeOffsets[i] != -1L) {
/* 1057 */             sb.append(' ').append(recentOpcodeOffsets[i]);
/*      */           }
/*      */         }
/* 1060 */         msg = new StringBuilder().append(msg).append(sb.append("]")).toString();
/*      */       }
/*      */ 
/* 1063 */       LOG.warn(msg, t);
/* 1064 */       if (isTolerationEnabled) {
/* 1065 */         in.reset();
/*      */       }
/*      */       else
/* 1068 */         MetaRecoveryContext.editLogLoaderPrompt(msg, recovery);
/*      */     }
/*      */     finally {
/*      */       try {
/* 1072 */         checkEndOfLog(edits, in, tracker, tolerationLength);
/*      */       } finally {
/* 1074 */         in.close();
/*      */       }
/*      */     }
/* 1077 */     LOG.info(new StringBuilder().append("Edits file ").append(edits.getName()).append(" of size ").append(edits.length()).append(" edits # ").append(numEdits).append(" loaded in ").append((FSNamesystem.now() - startTime) / 1000L).append(" seconds.").toString());
/*      */ 
/* 1081 */     if (LOG.isDebugEnabled()) {
/* 1082 */       LOG.debug(new StringBuilder().append("numOpAdd = ").append(numOpAdd).append(" numOpClose = ").append(numOpClose).append(" numOpDelete = ").append(numOpDelete).append(" numOpRename = ").append(numOpRename).append(" numOpSetRepl = ").append(numOpSetRepl).append(" numOpMkDir = ").append(numOpMkDir).append(" numOpSetPerm = ").append(numOpSetPerm).append(" numOpSetOwner = ").append(numOpSetOwner).append(" numOpSetGenStamp = ").append(numOpSetGenStamp).append(" numOpTimes = ").append(numOpTimes).append(" numOpGetDelegationToken = ").append(numOpGetDelegationToken).append(" numOpRenewDelegationToken = ").append(numOpRenewDelegationToken).append(" numOpCancelDelegationToken = ").append(numOpCancelDelegationToken).append(" numOpUpdateMasterKey = ").append(numOpUpdateMasterKey).append(" numOpConcatDelete  = ").append(numOpConcatDelete).append(" numOpOther = ").append(numOpOther).toString());
/*      */     }
/*      */ 
/* 1097 */     if (logVersion != -41)
/* 1098 */       numEdits++;
/* 1099 */     return numEdits;
/*      */   }
/*      */ 
/*      */   private static long readLongWritable(DataInputStream in)
/*      */     throws IOException
/*      */   {
/* 1107 */     synchronized (longWritable) {
/* 1108 */       longWritable.readFields(in);
/* 1109 */       return longWritable.get();
/*      */     }
/*      */   }
/*      */ 
/*      */   static short adjustReplication(short replication) {
/* 1114 */     FSNamesystem fsNamesys = FSNamesystem.getFSNamesystem();
/* 1115 */     short minReplication = fsNamesys.getMinReplication();
/* 1116 */     if (replication < minReplication) {
/* 1117 */       replication = minReplication;
/*      */     }
/* 1119 */     short maxReplication = fsNamesys.getMaxReplication();
/* 1120 */     if (replication > maxReplication) {
/* 1121 */       replication = maxReplication;
/*      */     }
/* 1123 */     return replication;
/*      */   }
/*      */ 
/*      */   synchronized void logEdit(byte op, Writable[] writables)
/*      */   {
/* 1131 */     if (getNumEditStreams() < 1) {
/* 1132 */       throw new AssertionError("No edit streams to log to");
/*      */     }
/* 1134 */     long start = FSNamesystem.now();
/* 1135 */     for (int idx = 0; idx < this.editStreams.size(); idx++) {
/* 1136 */       EditLogOutputStream eStream = (EditLogOutputStream)this.editStreams.get(idx);
/*      */       try {
/* 1138 */         eStream.write(op, writables);
/*      */       } catch (IOException ioe) {
/* 1140 */         removeEditsAndStorageDir(idx);
/* 1141 */         idx--;
/*      */       }
/*      */     }
/* 1144 */     exitIfNoStreams();
/*      */ 
/* 1146 */     this.txid += 1L;
/*      */ 
/* 1151 */     TransactionId id = (TransactionId)myTransactionId.get();
/* 1152 */     id.txid = this.txid;
/*      */ 
/* 1155 */     long end = FSNamesystem.now();
/* 1156 */     this.numTransactions += 1L;
/* 1157 */     this.totalTimeTransactions += end - start;
/* 1158 */     if (this.metrics != null)
/* 1159 */       this.metrics.addTransaction(end - start);
/*      */   }
/*      */ 
/*      */   public void logSync()
/*      */     throws IOException
/*      */   {
/* 1166 */     ArrayList errorStreams = null;
/* 1167 */     long syncStart = 0L;
/*      */ 
/* 1170 */     long mytxid = ((TransactionId)myTransactionId.get()).txid;
/*      */ 
/* 1172 */     ArrayList streams = new ArrayList();
/* 1173 */     boolean sync = false;
/*      */     try {
/* 1175 */       synchronized (this) {
/* 1176 */         printStatistics(false);
/*      */ 
/* 1179 */         while ((mytxid > this.synctxid) && (this.isSyncRunning)) {
/*      */           try {
/* 1181 */             wait(1000L);
/*      */           }
/*      */           catch (InterruptedException ie)
/*      */           {
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1189 */         if (mytxid <= this.synctxid) {
/* 1190 */           this.numTransactionsBatchedInSync += 1L;
/* 1191 */           if (this.metrics != null) {
/* 1192 */             this.metrics.incrTransactionsBatchedInSync();
/*      */           }
/*      */           return;
/*      */         }
/*      */ 
/* 1197 */         syncStart = this.txid;
/* 1198 */         this.isSyncRunning = true;
/* 1199 */         sync = true;
/*      */ 
/* 1202 */         exitIfNoStreams();
/* 1203 */         for (EditLogOutputStream eStream : this.editStreams) {
/*      */           try {
/* 1205 */             eStream.setReadyToFlush();
/* 1206 */             streams.add(eStream);
/*      */           } catch (IOException ie) {
/* 1208 */             LOG.error("Unable to get ready to flush.", ie);
/*      */ 
/* 1212 */             if (errorStreams == null) {
/* 1213 */               errorStreams = new ArrayList(1);
/*      */             }
/* 1215 */             errorStreams.add(eStream);
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1221 */       long start = FSNamesystem.now();
/* 1222 */       for (EditLogOutputStream eStream : streams) {
/*      */         try {
/* 1224 */           eStream.flush();
/*      */         } catch (IOException ie) {
/* 1226 */           LOG.error("Unable to sync edit log.", ie);
/*      */ 
/* 1230 */           if (errorStreams == null) {
/* 1231 */             errorStreams = new ArrayList(1);
/*      */           }
/* 1233 */           errorStreams.add(eStream);
/*      */         }
/*      */       }
/* 1236 */       long elapsed = FSNamesystem.now() - start;
/* 1237 */       removeEditsStreamsAndStorageDirs(errorStreams);
/* 1238 */       exitIfNoStreams();
/*      */ 
/* 1240 */       if (this.metrics != null)
/* 1241 */         this.metrics.addSync(elapsed);
/*      */     }
/*      */     finally {
/* 1244 */       synchronized (this) {
/* 1245 */         if (sync) {
/* 1246 */           this.synctxid = syncStart;
/* 1247 */           this.isSyncRunning = false;
/*      */         }
/* 1249 */         notifyAll();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void printStatistics(boolean force)
/*      */   {
/* 1258 */     long now = FSNamesystem.now();
/* 1259 */     if ((this.lastPrintTime + 60000L > now) && (!force)) {
/* 1260 */       return;
/*      */     }
/* 1262 */     if ((this.editStreams == null) || (this.editStreams.size() == 0)) {
/* 1263 */       return;
/*      */     }
/* 1265 */     this.lastPrintTime = now;
/* 1266 */     StringBuilder buf = new StringBuilder();
/* 1267 */     buf.append("Number of transactions: ");
/* 1268 */     buf.append(this.numTransactions);
/* 1269 */     buf.append(" Total time for transactions(ms): ");
/* 1270 */     buf.append(this.totalTimeTransactions);
/* 1271 */     buf.append(" Number of transactions batched in Syncs: ");
/* 1272 */     buf.append(this.numTransactionsBatchedInSync);
/* 1273 */     buf.append(" Number of syncs: ");
/* 1274 */     buf.append(((EditLogOutputStream)this.editStreams.get(0)).getNumSync());
/* 1275 */     buf.append(" SyncTimes(ms): ");
/*      */ 
/* 1277 */     int numEditStreams = this.editStreams.size();
/* 1278 */     for (int idx = 0; idx < numEditStreams; idx++) {
/* 1279 */       EditLogOutputStream eStream = (EditLogOutputStream)this.editStreams.get(idx);
/* 1280 */       buf.append(eStream.getTotalSyncTime());
/* 1281 */       buf.append(" ");
/*      */     }
/* 1283 */     LOG.info(buf);
/*      */   }
/*      */ 
/*      */   public void logOpenFile(String path, INodeFileUnderConstruction newNode)
/*      */     throws IOException
/*      */   {
/* 1293 */     UTF8[] nameReplicationPair = { new UTF8(path), toLogReplication(newNode.getReplication()), toLogLong(newNode.getModificationTime()), toLogLong(newNode.getAccessTime()), toLogLong(newNode.getPreferredBlockSize()) };
/*      */ 
/* 1299 */     logEdit((byte)0, new Writable[] { new ArrayWritable(UTF8.class, nameReplicationPair), new ArrayWritable(Block.class, newNode.getBlocks()), newNode.getPermissionStatus(), new UTF8(newNode.getClientName()), new UTF8(newNode.getClientMachine()) });
/*      */   }
/*      */ 
/*      */   public void logCloseFile(String path, INodeFile newNode)
/*      */   {
/* 1311 */     UTF8[] nameReplicationPair = { new UTF8(path), toLogReplication(newNode.getReplication()), toLogLong(newNode.getModificationTime()), toLogLong(newNode.getAccessTime()), toLogLong(newNode.getPreferredBlockSize()) };
/*      */ 
/* 1317 */     logEdit((byte)9, new Writable[] { new ArrayWritable(UTF8.class, nameReplicationPair), new ArrayWritable(Block.class, newNode.getBlocks()), newNode.getPermissionStatus() });
/*      */   }
/*      */ 
/*      */   public void logMkDir(String path, INode newNode)
/*      */   {
/* 1327 */     UTF8[] info = { new UTF8(path), toLogLong(newNode.getModificationTime()), toLogLong(newNode.getAccessTime()) };
/*      */ 
/* 1332 */     logEdit((byte)3, new Writable[] { new ArrayWritable(UTF8.class, info), newNode.getPermissionStatus() });
/*      */   }
/*      */ 
/*      */   void logRename(String src, String dst, long timestamp)
/*      */   {
/* 1341 */     UTF8[] info = { new UTF8(src), new UTF8(dst), toLogLong(timestamp) };
/*      */ 
/* 1345 */     logEdit((byte)1, new Writable[] { new ArrayWritable(UTF8.class, info) });
/*      */   }
/*      */ 
/*      */   void logSetReplication(String src, short replication)
/*      */   {
/* 1352 */     logEdit((byte)4, new Writable[] { new UTF8(src), toLogReplication(replication) });
/*      */   }
/*      */ 
/*      */   void logSetQuota(String src, long nsQuota, long dsQuota)
/*      */   {
/* 1363 */     logEdit((byte)14, new Writable[] { new UTF8(src), new LongWritable(nsQuota), new LongWritable(dsQuota) });
/*      */   }
/*      */ 
/*      */   void logSetPermissions(String src, FsPermission permissions)
/*      */   {
/* 1369 */     logEdit((byte)7, new Writable[] { new UTF8(src), permissions });
/*      */   }
/*      */ 
/*      */   void logSetOwner(String src, String username, String groupname)
/*      */   {
/* 1374 */     UTF8 u = new UTF8(username == null ? "" : username);
/* 1375 */     UTF8 g = new UTF8(groupname == null ? "" : groupname);
/* 1376 */     logEdit((byte)8, new Writable[] { new UTF8(src), u, g });
/*      */   }
/*      */ 
/*      */   void logConcat(String trg, String[] srcs, long timestamp)
/*      */   {
/* 1383 */     int size = 1 + srcs.length + 1;
/* 1384 */     UTF8[] info = new UTF8[size];
/* 1385 */     int idx = 0;
/* 1386 */     info[(idx++)] = new UTF8(trg);
/* 1387 */     for (int i = 0; i < srcs.length; i++) {
/* 1388 */       info[(idx++)] = new UTF8(srcs[i]);
/*      */     }
/* 1390 */     info[idx] = toLogLong(timestamp);
/* 1391 */     logEdit((byte)16, new Writable[] { new ArrayWritable(UTF8.class, info) });
/*      */   }
/*      */ 
/*      */   void logDelete(String src, long timestamp)
/*      */   {
/* 1398 */     UTF8[] info = { new UTF8(src), toLogLong(timestamp) };
/*      */ 
/* 1401 */     logEdit((byte)2, new Writable[] { new ArrayWritable(UTF8.class, info) });
/*      */   }
/*      */ 
/*      */   void logGenerationStamp(long genstamp)
/*      */   {
/* 1408 */     logEdit((byte)10, new Writable[] { new LongWritable(genstamp) });
/*      */   }
/*      */ 
/*      */   void logTimes(String src, long mtime, long atime)
/*      */   {
/* 1415 */     UTF8[] info = { new UTF8(src), toLogLong(mtime), toLogLong(atime) };
/*      */ 
/* 1419 */     logEdit((byte)13, new Writable[] { new ArrayWritable(UTF8.class, info) });
/*      */   }
/*      */ 
/*      */   void logGetDelegationToken(DelegationTokenIdentifier id, long expiryTime)
/*      */   {
/* 1430 */     logEdit((byte)18, new Writable[] { id, toLogLong(expiryTime) });
/*      */   }
/*      */ 
/*      */   void logRenewDelegationToken(DelegationTokenIdentifier id, long expiryTime)
/*      */   {
/* 1435 */     logEdit((byte)19, new Writable[] { id, toLogLong(expiryTime) });
/*      */   }
/*      */ 
/*      */   void logCancelDelegationToken(DelegationTokenIdentifier id) {
/* 1439 */     logEdit((byte)20, new Writable[] { id });
/*      */   }
/*      */ 
/*      */   void logUpdateMasterKey(DelegationKey key) {
/* 1443 */     logEdit((byte)21, new Writable[] { key });
/*      */   }
/*      */ 
/*      */   private static UTF8 toLogReplication(short replication) {
/* 1447 */     return new UTF8(Short.toString(replication));
/*      */   }
/*      */ 
/*      */   private static UTF8 toLogLong(long timestamp) {
/* 1451 */     return new UTF8(Long.toString(timestamp));
/*      */   }
/*      */ 
/*      */   synchronized long getEditLogSize()
/*      */     throws IOException
/*      */   {
/* 1458 */     assert (getNumStorageDirs() == this.editStreams.size());
/* 1459 */     long size = 0L;
/* 1460 */     for (int idx = 0; idx < this.editStreams.size(); idx++) {
/* 1461 */       long curSize = ((EditLogOutputStream)this.editStreams.get(idx)).length();
/* 1462 */       assert ((size == 0L) || (size == curSize)) : "All streams must be the same";
/* 1463 */       size = curSize;
/*      */     }
/* 1465 */     return size;
/*      */   }
/*      */ 
/*      */   synchronized void rollEditLog()
/*      */     throws IOException
/*      */   {
/* 1477 */     if (existsNew()) {
/* 1478 */       Iterator it = this.fsimage.dirIterator(FSImage.NameNodeDirType.EDITS);
/*      */ 
/* 1480 */       StringBuilder b = new StringBuilder();
/* 1481 */       while (it.hasNext()) {
/* 1482 */         File editsNew = getEditNewFile((Storage.StorageDirectory)it.next());
/* 1483 */         b.append("\n  ").append(editsNew);
/* 1484 */         if (!editsNew.exists()) {
/* 1485 */           throw new IOException(new StringBuilder().append("Inconsistent existence of edits.new ").append(editsNew).toString());
/*      */         }
/*      */       }
/*      */ 
/* 1489 */       LOG.warn(new StringBuilder().append("Cannot roll edit log, edits.new files already exists in all healthy directories:").append(b).toString());
/*      */ 
/* 1491 */       return;
/*      */     }
/* 1493 */     close();
/*      */ 
/* 1497 */     this.fsimage.restoreStorageDirs();
/*      */ 
/* 1502 */     Iterator it = this.fsimage.dirIterator(FSImage.NameNodeDirType.EDITS);
/* 1503 */     LinkedList toRemove = new LinkedList();
/* 1504 */     while (it.hasNext()) {
/* 1505 */       Storage.StorageDirectory sd = (Storage.StorageDirectory)it.next();
/*      */       try {
/* 1507 */         EditLogFileOutputStream eStream = new EditLogFileOutputStream(getEditNewFile(sd));
/*      */ 
/* 1509 */         eStream.create();
/* 1510 */         this.editStreams.add(eStream);
/*      */       } catch (IOException ioe) {
/* 1512 */         LOG.error(new StringBuilder().append("error retrying to reopen storage directory '").append(sd.getRoot().getAbsolutePath()).append("'").toString(), ioe);
/*      */ 
/* 1514 */         toRemove.add(sd);
/* 1515 */         it.remove();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1521 */     for (Storage.StorageDirectory sd : toRemove) {
/* 1522 */       removeEditsForStorageDir(sd);
/* 1523 */       this.fsimage.updateRemovedDirs(sd);
/*      */     }
/* 1525 */     exitIfNoStreams();
/*      */   }
/*      */ 
/*      */   synchronized void purgeEditLog()
/*      */     throws IOException
/*      */   {
/* 1536 */     if (!existsNew()) {
/* 1537 */       throw new IOException("Attempt to purge edit log but edits.new does not exist.");
/*      */     }
/*      */ 
/* 1540 */     close();
/*      */ 
/* 1545 */     Iterator it = this.fsimage.dirIterator(FSImage.NameNodeDirType.EDITS);
/* 1546 */     while (it.hasNext()) {
/* 1547 */       Storage.StorageDirectory sd = (Storage.StorageDirectory)it.next();
/* 1548 */       if (!getEditNewFile(sd).renameTo(getEditFile(sd)))
/*      */       {
/* 1553 */         getEditFile(sd).delete();
/* 1554 */         if (!getEditNewFile(sd).renameTo(getEditFile(sd))) {
/* 1555 */           sd.unlock();
/* 1556 */           removeEditsForStorageDir(sd);
/* 1557 */           this.fsimage.updateRemovedDirs(sd);
/* 1558 */           it.remove();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1565 */     open();
/*      */   }
/*      */ 
/*      */   synchronized File getFsEditName()
/*      */     throws IOException
/*      */   {
/* 1572 */     Storage.StorageDirectory sd = null;
/* 1573 */     Iterator it = this.fsimage.dirIterator(FSImage.NameNodeDirType.EDITS);
/* 1574 */     while (it.hasNext())
/* 1575 */       sd = (Storage.StorageDirectory)it.next();
/* 1576 */     return getEditFile(sd);
/*      */   }
/*      */ 
/*      */   synchronized long getFsEditTime()
/*      */   {
/* 1583 */     Iterator it = this.fsimage.dirIterator(FSImage.NameNodeDirType.EDITS);
/* 1584 */     if (it.hasNext())
/* 1585 */       return getEditFile((Storage.StorageDirectory)it.next()).lastModified();
/* 1586 */     return 0L;
/*      */   }
/*      */ 
/*      */   static void setBufferCapacity(int size)
/*      */   {
/* 1591 */     sizeFlushBuffer = size;
/*      */   }
/*      */ 
/*      */   private static DatanodeDescriptor[] readDatanodeDescriptorArray(DataInput in)
/*      */     throws IOException
/*      */   {
/* 1632 */     DatanodeDescriptor[] locations = new DatanodeDescriptor[in.readInt()];
/* 1633 */     for (int i = 0; i < locations.length; i++) {
/* 1634 */       locations[i] = new DatanodeDescriptor();
/* 1635 */       locations[i].readFieldsFromFSEditLog(in);
/*      */     }
/* 1637 */     return locations;
/*      */   }
/*      */ 
/*      */   private static short readShort(DataInputStream in) throws IOException {
/* 1641 */     return Short.parseShort(FSImage.readString(in));
/*      */   }
/*      */ 
/*      */   private static long readLong(DataInputStream in) throws IOException {
/* 1645 */     return Long.parseLong(FSImage.readString(in));
/*      */   }
/*      */ 
/*      */   private static Block[] readBlocks(DataInputStream in) throws IOException {
/* 1649 */     int numBlocks = in.readInt();
/* 1650 */     Block[] blocks = new Block[numBlocks];
/* 1651 */     for (int i = 0; i < numBlocks; i++) {
/* 1652 */       blocks[i] = new Block();
/* 1653 */       blocks[i].readFields(in);
/*      */     }
/* 1655 */     return blocks;
/*      */   }
/*      */ 
/*      */   private static class PositionTrackingInputStream extends FilterInputStream
/*      */   {
/* 1662 */     private long curPos = 0L;
/* 1663 */     private long markPos = -1L;
/*      */ 
/*      */     public PositionTrackingInputStream(InputStream is) {
/* 1666 */       super();
/*      */     }
/*      */ 
/*      */     public int read() throws IOException {
/* 1670 */       int ret = super.read();
/* 1671 */       if (ret != -1) this.curPos += 1L;
/* 1672 */       return ret;
/*      */     }
/*      */ 
/*      */     public int read(byte[] data) throws IOException {
/* 1676 */       int ret = super.read(data);
/* 1677 */       if (ret > 0) this.curPos += ret;
/* 1678 */       return ret;
/*      */     }
/*      */ 
/*      */     public int read(byte[] data, int offset, int length) throws IOException {
/* 1682 */       int ret = super.read(data, offset, length);
/* 1683 */       if (ret > 0) this.curPos += ret;
/* 1684 */       return ret;
/*      */     }
/*      */ 
/*      */     public void mark(int limit) {
/* 1688 */       super.mark(limit);
/* 1689 */       this.markPos = this.curPos;
/*      */     }
/*      */ 
/*      */     public void reset() throws IOException {
/* 1693 */       if (this.markPos == -1L) {
/* 1694 */         throw new IOException("Not marked!");
/*      */       }
/* 1696 */       super.reset();
/* 1697 */       this.curPos = this.markPos;
/* 1698 */       this.markPos = -1L;
/*      */     }
/*      */ 
/*      */     public long getPos() {
/* 1702 */       return this.curPos;
/*      */     }
/*      */   }
/*      */ 
/*      */   static class BlockTwo
/*      */     implements Writable
/*      */   {
/*      */     long blkid;
/*      */     long len;
/*      */ 
/*      */     BlockTwo()
/*      */     {
/* 1612 */       this.blkid = 0L;
/* 1613 */       this.len = 0L;
/*      */     }
/*      */ 
/*      */     public void write(DataOutput out)
/*      */       throws IOException
/*      */     {
/* 1619 */       out.writeLong(this.blkid);
/* 1620 */       out.writeLong(this.len);
/*      */     }
/*      */ 
/*      */     public void readFields(DataInput in) throws IOException {
/* 1624 */       this.blkid = in.readLong();
/* 1625 */       this.len = in.readLong();
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1603 */       WritableFactories.setFactory(BlockTwo.class, new WritableFactory()
/*      */       {
/*      */         public Writable newInstance() {
/* 1606 */           return new FSEditLog.BlockTwo();
/*      */         }
/*      */       });
/*      */     }
/*      */   }
/*      */ 
/*      */   static class EditLogFileInputStream extends EditLogInputStream
/*      */   {
/*      */     private File file;
/*      */     private FileInputStream fStream;
/*      */ 
/*      */     EditLogFileInputStream(File name)
/*      */       throws IOException
/*      */     {
/*  295 */       this.file = name;
/*  296 */       this.fStream = new FileInputStream(name);
/*      */     }
/*      */ 
/*      */     String getName()
/*      */     {
/*  301 */       return this.file.getPath();
/*      */     }
/*      */ 
/*      */     public int available() throws IOException
/*      */     {
/*  306 */       return this.fStream.available();
/*      */     }
/*      */ 
/*      */     public int read() throws IOException
/*      */     {
/*  311 */       return this.fStream.read();
/*      */     }
/*      */ 
/*      */     public int read(byte[] b, int off, int len) throws IOException
/*      */     {
/*  316 */       return this.fStream.read(b, off, len);
/*      */     }
/*      */ 
/*      */     public void close() throws IOException
/*      */     {
/*  321 */       this.fStream.close();
/*      */     }
/*      */ 
/*      */     long length()
/*      */       throws IOException
/*      */     {
/*  327 */       return this.file.length();
/*      */     }
/*      */   }
/*      */ 
/*      */   static class EditLogFileOutputStream extends EditLogOutputStream
/*      */   {
/*      */     private static final ByteBuffer PREALLOCATION_BUFFER;
/*      */     private File file;
/*      */     private FileOutputStream fp;
/*      */     private FileChannel fc;
/*      */     private DataOutputBuffer bufCurrent;
/*      */     private DataOutputBuffer bufReady;
/*      */ 
/*      */     EditLogFileOutputStream(File name)
/*      */       throws IOException
/*      */     {
/*  159 */       this.file = name;
/*  160 */       this.bufCurrent = new DataOutputBuffer(FSEditLog.sizeFlushBuffer);
/*  161 */       this.bufReady = new DataOutputBuffer(FSEditLog.sizeFlushBuffer);
/*  162 */       RandomAccessFile rp = new RandomAccessFile(name, "rw");
/*  163 */       this.fp = new FileOutputStream(rp.getFD());
/*  164 */       this.fc = rp.getChannel();
/*  165 */       this.fc.position(this.fc.size());
/*      */     }
/*      */ 
/*      */     String getName()
/*      */     {
/*  170 */       return this.file.getPath();
/*      */     }
/*      */ 
/*      */     public void write(int b)
/*      */       throws IOException
/*      */     {
/*  176 */       this.bufCurrent.write(b);
/*      */     }
/*      */ 
/*      */     void write(byte op, Writable[] writables)
/*      */       throws IOException
/*      */     {
/*  182 */       write(op);
/*  183 */       for (Writable w : writables)
/*  184 */         w.write(this.bufCurrent);
/*      */     }
/*      */ 
/*      */     void create()
/*      */       throws IOException
/*      */     {
/*  193 */       this.fc.truncate(0L);
/*  194 */       this.fc.position(0L);
/*  195 */       this.bufCurrent.writeInt(-41);
/*  196 */       setReadyToFlush();
/*  197 */       flush();
/*      */     }
/*      */ 
/*      */     public void close() throws IOException
/*      */     {
/*  202 */       FSEditLog.LOG.info("closing edit log: position=" + this.fc.position() + ", editlog=" + getName());
/*      */ 
/*  206 */       int bufSize = this.bufCurrent.size();
/*  207 */       if (bufSize != 0) {
/*  208 */         throw new IOException("FSEditStream has " + bufSize + " bytes still to be flushed and cannot be closed.");
/*      */       }
/*      */ 
/*  211 */       this.bufCurrent.close();
/*  212 */       this.bufReady.close();
/*      */ 
/*  215 */       this.fc.truncate(this.fc.position());
/*  216 */       this.fp.close();
/*      */ 
/*  218 */       this.bufCurrent = (this.bufReady = null);
/*      */ 
/*  220 */       FSEditLog.LOG.info("close success: truncate to " + this.file.length() + ", editlog=" + getName());
/*      */     }
/*      */ 
/*      */     void setReadyToFlush()
/*      */       throws IOException
/*      */     {
/*  229 */       assert (this.bufReady.size() == 0) : "previous data is not flushed yet";
/*  230 */       DataOutputBuffer tmp = this.bufReady;
/*  231 */       this.bufReady = this.bufCurrent;
/*  232 */       this.bufCurrent = tmp;
/*      */     }
/*      */ 
/*      */     protected void flushAndSync()
/*      */       throws IOException
/*      */     {
/*  242 */       preallocate();
/*  243 */       this.bufReady.writeTo(this.fp);
/*  244 */       this.bufReady.reset();
/*  245 */       this.fc.force(false);
/*      */     }
/*      */ 
/*      */     long length()
/*      */       throws IOException
/*      */     {
/*  254 */       return this.fc.size() + this.bufReady.size() + this.bufCurrent.size();
/*      */     }
/*      */ 
/*      */     private void preallocate() throws IOException
/*      */     {
/*  259 */       long size = this.fc.size();
/*  260 */       int bufSize = this.bufReady.getLength();
/*  261 */       long need = bufSize - (size - this.fc.position());
/*  262 */       if (need <= 0L) {
/*  263 */         return;
/*      */       }
/*  265 */       long oldSize = size;
/*  266 */       long total = 0L;
/*  267 */       long fillCapacity = PREALLOCATION_BUFFER.capacity();
/*  268 */       while (need > 0L) {
/*  269 */         PREALLOCATION_BUFFER.position(0);
/*      */         do
/*  271 */           size += this.fc.write(PREALLOCATION_BUFFER, size);
/*  272 */         while (PREALLOCATION_BUFFER.remaining() > 0);
/*  273 */         need -= fillCapacity;
/*  274 */         total += fillCapacity;
/*      */       }
/*  276 */       if (FSNamesystem.LOG.isDebugEnabled())
/*  277 */         FSNamesystem.LOG.debug("Preallocated " + total + " bytes at the end of " + "the edit log (offset " + oldSize + ")");
/*      */     }
/*      */ 
/*      */     File getFile()
/*      */     {
/*  286 */       return this.file;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  142 */       PREALLOCATION_BUFFER = ByteBuffer.allocateDirect(1048576);
/*      */ 
/*  145 */       PREALLOCATION_BUFFER.position(0).limit(1048576);
/*  146 */       for (int i = 0; i < PREALLOCATION_BUFFER.capacity(); i++)
/*  147 */         PREALLOCATION_BUFFER.put((byte)-1);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class TransactionId
/*      */   {
/*      */     public long txid;
/*      */ 
/*      */     TransactionId(long value)
/*      */     {
/*  125 */       this.txid = value;
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.FSEditLog
 * JD-Core Version:    0.6.1
 */
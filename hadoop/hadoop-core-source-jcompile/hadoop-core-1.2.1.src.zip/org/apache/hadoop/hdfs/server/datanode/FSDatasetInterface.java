/*     */ package org.apache.hadoop.hdfs.server.datanode;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.hdfs.protocol.BlockLocalPathInfo;
/*     */ import org.apache.hadoop.hdfs.server.datanode.metrics.FSDatasetMBean;
/*     */ import org.apache.hadoop.hdfs.server.protocol.BlockRecoveryInfo;
/*     */ import org.apache.hadoop.io.IOUtils;
/*     */ import org.apache.hadoop.util.DiskChecker.DiskErrorException;
/*     */ 
/*     */ public abstract interface FSDatasetInterface extends FSDatasetMBean
/*     */ {
/*     */   public abstract long getMetaDataLength(Block paramBlock)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract MetaDataInputStream getMetaDataInputStream(Block paramBlock)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract boolean metaFileExists(Block paramBlock)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract long getLength(Block paramBlock)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract long getVisibleLength(Block paramBlock)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void setVisibleLength(Block paramBlock, long paramLong)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract Block getStoredBlock(long paramLong)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract InputStream getBlockInputStream(Block paramBlock)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract InputStream getBlockInputStream(Block paramBlock, long paramLong)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract BlockInputStreams getTmpInputStreams(Block paramBlock, long paramLong1, long paramLong2)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract BlockWriteStreams writeToBlock(Block paramBlock, boolean paramBoolean1, boolean paramBoolean2)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void updateBlock(Block paramBlock1, Block paramBlock2)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void finalizeBlock(Block paramBlock)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void finalizeBlockIfNeeded(Block paramBlock)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void unfinalizeBlock(Block paramBlock)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract Block[] getBlockReport();
/*     */ 
/*     */   public abstract void requestAsyncBlockReport();
/*     */ 
/*     */   public abstract boolean isAsyncBlockReportReady();
/*     */ 
/*     */   public abstract Block[] retrieveAsyncBlockReport();
/*     */ 
/*     */   public abstract Block[] getBlocksBeingWrittenReport();
/*     */ 
/*     */   public abstract boolean isValidBlock(Block paramBlock);
/*     */ 
/*     */   public abstract void invalidate(Block[] paramArrayOfBlock)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void checkDataDir()
/*     */     throws DiskChecker.DiskErrorException;
/*     */ 
/*     */   public abstract String toString();
/*     */ 
/*     */   public abstract void shutdown();
/*     */ 
/*     */   public abstract long getChannelPosition(Block paramBlock, BlockWriteStreams paramBlockWriteStreams)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void setChannelPosition(Block paramBlock, BlockWriteStreams paramBlockWriteStreams, long paramLong1, long paramLong2)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void validateBlockMetadata(Block paramBlock)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract boolean hasEnoughResource();
/*     */ 
/*     */   public abstract BlockRecoveryInfo startBlockRecovery(long paramLong)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract BlockLocalPathInfo getBlockLocalPathInfo(Block paramBlock)
/*     */     throws IOException;
/*     */ 
/*     */   public static class BlockInputStreams
/*     */     implements Closeable
/*     */   {
/*     */     final InputStream dataIn;
/*     */     final InputStream checksumIn;
/*     */ 
/*     */     BlockInputStreams(InputStream dataIn, InputStream checksumIn)
/*     */     {
/* 180 */       this.dataIn = dataIn;
/* 181 */       this.checksumIn = checksumIn;
/*     */     }
/*     */ 
/*     */     public void close()
/*     */     {
/* 186 */       IOUtils.closeStream(this.dataIn);
/* 187 */       IOUtils.closeStream(this.checksumIn);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class BlockWriteStreams
/*     */   {
/*     */     OutputStream dataOut;
/*     */     OutputStream checksumOut;
/*     */ 
/*     */     BlockWriteStreams(OutputStream dOut, OutputStream cOut)
/*     */     {
/* 165 */       this.dataOut = dOut;
/* 166 */       this.checksumOut = cOut;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class MetaDataInputStream extends FilterInputStream
/*     */   {
/*     */     private long length;
/*     */ 
/*     */     MetaDataInputStream(InputStream stream, long len)
/*     */     {
/*  63 */       super();
/*  64 */       this.length = len;
/*     */     }
/*     */ 
/*     */     public long getLength()
/*     */     {
/*  69 */       return this.length;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.FSDatasetInterface
 * JD-Core Version:    0.6.1
 */
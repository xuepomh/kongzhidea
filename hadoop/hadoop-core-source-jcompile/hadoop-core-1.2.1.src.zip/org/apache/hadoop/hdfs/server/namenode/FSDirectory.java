/*      */ package org.apache.hadoop.hdfs.server.namenode;
/*      */ 
/*      */ import java.io.Closeable;
/*      */ import java.io.File;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.hadoop.conf.Configuration;
/*      */ import org.apache.hadoop.fs.ContentSummary;
/*      */ import org.apache.hadoop.fs.Path;
/*      */ import org.apache.hadoop.fs.permission.FsPermission;
/*      */ import org.apache.hadoop.fs.permission.PermissionStatus;
/*      */ import org.apache.hadoop.hdfs.protocol.Block;
/*      */ import org.apache.hadoop.hdfs.protocol.DirectoryListing;
/*      */ import org.apache.hadoop.hdfs.protocol.FSConstants;
/*      */ import org.apache.hadoop.hdfs.protocol.HdfsFileStatus;
/*      */ import org.apache.hadoop.hdfs.protocol.QuotaExceededException;
/*      */ import org.apache.hadoop.hdfs.server.common.HdfsConstants.StartupOption;
/*      */ import org.apache.hadoop.hdfs.server.namenode.metrics.NameNodeInstrumentation;
/*      */ import org.apache.hadoop.hdfs.util.ByteArray;
/*      */ 
/*      */ class FSDirectory
/*      */   implements FSConstants, Closeable
/*      */ {
/*      */   final FSNamesystem namesystem;
/*      */   final INodeDirectoryWithQuota rootDir;
/*      */   FSImage fsImage;
/*   51 */   private boolean ready = false;
/*      */   private final int lsLimit;
/*      */   private final NameCache<ByteArray> nameCache;
/*      */ 
/*      */   FSDirectory(FSNamesystem ns, Configuration conf)
/*      */   {
/*   62 */     this(new FSImage(), ns, conf);
/*   63 */     this.fsImage.setCheckpointDirectories(FSImage.getCheckpointDirs(conf, null), FSImage.getCheckpointEditsDirs(conf, null));
/*      */   }
/*      */ 
/*      */   FSDirectory(FSImage fsImage, FSNamesystem ns, Configuration conf)
/*      */   {
/*   68 */     this.rootDir = new INodeDirectoryWithQuota("", ns.createFsOwnerPermissions(new FsPermission((short)493)), 2147483647L, -1L);
/*      */ 
/*   71 */     this.fsImage = fsImage;
/*   72 */     fsImage.setRestoreRemovedDirs(conf.getBoolean("dfs.namenode.name.dir.restore", false));
/*      */ 
/*   75 */     fsImage.setEditsTolerationLength(conf.getInt("dfs.namenode.edits.toleration.length", 0));
/*      */ 
/*   79 */     this.namesystem = ns;
/*   80 */     int configuredLimit = conf.getInt("dfs.ls.limit", 1000);
/*      */ 
/*   82 */     this.lsLimit = (configuredLimit > 0 ? configuredLimit : 1000);
/*      */ 
/*   85 */     int threshold = conf.getInt("dfs.namenode.name.cache.threshold", 10);
/*      */ 
/*   88 */     NameNode.LOG.info(new StringBuilder().append("Caching file names occuring more than ").append(threshold).append(" times ").toString());
/*      */ 
/*   90 */     this.nameCache = new NameCache(threshold);
/*      */   }
/*      */ 
/*      */   void loadFSImage(Collection<File> dataDirs, Collection<File> editsDirs, HdfsConstants.StartupOption startOpt)
/*      */     throws IOException
/*      */   {
/*   98 */     if (startOpt == HdfsConstants.StartupOption.FORMAT) {
/*   99 */       this.fsImage.setStorageDirectories(dataDirs, editsDirs);
/*  100 */       this.fsImage.format();
/*  101 */       startOpt = HdfsConstants.StartupOption.REGULAR;
/*      */     }
/*      */     try {
/*  104 */       if (this.fsImage.recoverTransitionRead(dataDirs, editsDirs, startOpt)) {
/*  105 */         this.fsImage.saveNamespace(true);
/*      */       }
/*  107 */       FSEditLog editLog = this.fsImage.getEditLog();
/*  108 */       assert (editLog != null) : "editLog must be initialized";
/*  109 */       if (!editLog.isOpen())
/*  110 */         editLog.open();
/*  111 */       this.fsImage.setCheckpointDirectories(null, null);
/*      */     } catch (IOException e) {
/*  113 */       this.fsImage.close();
/*  114 */       throw e;
/*      */     }
/*  116 */     synchronized (this) {
/*  117 */       this.ready = true;
/*  118 */       this.nameCache.initialized();
/*  119 */       notifyAll();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void incrDeletedFileCount(int count) {
/*  124 */     if (this.namesystem != null)
/*  125 */       NameNode.getNameNodeMetrics().incrFilesDeleted(count);
/*      */   }
/*      */ 
/*      */   public void close()
/*      */     throws IOException
/*      */   {
/*  132 */     this.fsImage.close();
/*      */   }
/*      */ 
/*      */   void waitForReady()
/*      */   {
/*  139 */     if (!this.ready)
/*  140 */       synchronized (this) {
/*  141 */         while (!this.ready)
/*      */           try {
/*  143 */             wait(5000L);
/*      */           }
/*      */           catch (InterruptedException ie)
/*      */           {
/*      */           }
/*      */       }
/*      */   }
/*      */ 
/*      */   INodeFileUnderConstruction addFile(String path, PermissionStatus permissions, short replication, long preferredBlockSize, String clientName, String clientMachine, DatanodeDescriptor clientNode, long generationStamp)
/*      */     throws IOException
/*      */   {
/*  163 */     waitForReady();
/*      */ 
/*  166 */     long modTime = FSNamesystem.now();
/*  167 */     if (!mkdirs(new Path(path).getParent().toString(), permissions, true, modTime))
/*      */     {
/*  169 */       return null;
/*      */     }
/*  171 */     INodeFileUnderConstruction newNode = new INodeFileUnderConstruction(permissions, replication, preferredBlockSize, modTime, clientName, clientMachine, clientNode);
/*      */ 
/*  175 */     synchronized (this.rootDir) {
/*  176 */       newNode = (INodeFileUnderConstruction)addNode(path, newNode, -1L, false);
/*      */     }
/*  178 */     if (newNode == null) {
/*  179 */       NameNode.stateChangeLog.info(new StringBuilder().append("DIR* addFile: failed to add ").append(path).toString());
/*  180 */       return null;
/*      */     }
/*      */ 
/*  183 */     this.fsImage.getEditLog().logOpenFile(path, newNode);
/*      */ 
/*  185 */     NameNode.stateChangeLog.debug(new StringBuilder().append("DIR* addFile: ").append(path).append(" is added").toString());
/*  186 */     return newNode;
/*      */   }
/*      */ 
/*      */   INode unprotectedAddFile(String path, PermissionStatus permissions, Block[] blocks, short replication, long modificationTime, long atime, long preferredBlockSize)
/*      */   {
/*  199 */     long diskspace = -1L;
/*      */     INode newNode;
/*      */     INode newNode;
/*  200 */     if (blocks == null) {
/*  201 */       newNode = new INodeDirectory(permissions, modificationTime);
/*      */     } else {
/*  203 */       newNode = new INodeFile(permissions, blocks.length, replication, modificationTime, atime, preferredBlockSize);
/*      */ 
/*  205 */       diskspace = ((INodeFile)newNode).diskspaceConsumed(blocks);
/*      */     }
/*  207 */     synchronized (this.rootDir) {
/*      */       try {
/*  209 */         newNode = addNode(path, newNode, diskspace, false);
/*  210 */         if ((newNode != null) && (blocks != null)) {
/*  211 */           int nrBlocks = blocks.length;
/*      */ 
/*  213 */           INodeFile newF = (INodeFile)newNode;
/*  214 */           for (int i = 0; i < nrBlocks; i++)
/*  215 */             newF.setBlock(i, this.namesystem.blocksMap.addINode(blocks[i], newF));
/*      */         }
/*      */       }
/*      */       catch (IOException e) {
/*  219 */         return null;
/*      */       }
/*  221 */       return newNode;
/*      */     }
/*      */   }
/*      */ 
/*      */   INodeDirectory addToParent(String src, INodeDirectory parentINode, PermissionStatus permissions, Block[] blocks, short replication, long modificationTime, long atime, long nsQuota, long dsQuota, long preferredBlockSize)
/*      */   {
/*      */     INode newNode;
/*      */     INode newNode;
/*  238 */     if (blocks == null)
/*      */     {
/*      */       INode newNode;
/*  239 */       if ((nsQuota >= 0L) || (dsQuota >= 0L)) {
/*  240 */         newNode = new INodeDirectoryWithQuota(permissions, modificationTime, nsQuota, dsQuota);
/*      */       }
/*      */       else
/*  243 */         newNode = new INodeDirectory(permissions, modificationTime);
/*      */     }
/*      */     else {
/*  246 */       newNode = new INodeFile(permissions, blocks.length, replication, modificationTime, atime, preferredBlockSize);
/*      */     }
/*      */ 
/*  249 */     INodeDirectory newParent = null;
/*  250 */     synchronized (this.rootDir) {
/*      */       try {
/*  252 */         newParent = this.rootDir.addToParent(src, newNode, parentINode, false);
/*  253 */         cacheName(newNode);
/*      */       } catch (FileNotFoundException e) {
/*  255 */         return null;
/*      */       }
/*  257 */       if (newParent == null)
/*  258 */         return null;
/*  259 */       if (blocks != null) {
/*  260 */         int nrBlocks = blocks.length;
/*      */ 
/*  262 */         INodeFile newF = (INodeFile)newNode;
/*  263 */         for (int i = 0; i < nrBlocks; i++) {
/*  264 */           newF.setBlock(i, this.namesystem.blocksMap.addINode(blocks[i], newF));
/*      */         }
/*      */       }
/*      */     }
/*  268 */     return newParent;
/*      */   }
/*      */ 
/*      */   Block addBlock(String path, INode[] inodes, Block block)
/*      */     throws IOException
/*      */   {
/*  275 */     waitForReady();
/*      */ 
/*  277 */     synchronized (this.rootDir) {
/*  278 */       INodeFile fileNode = (INodeFile)inodes[(inodes.length - 1)];
/*      */ 
/*  281 */       updateCount(inodes, inodes.length - 1, 0L, fileNode.getPreferredBlockSize() * fileNode.getReplication(), true);
/*      */ 
/*  285 */       this.namesystem.blocksMap.addINode(block, fileNode);
/*  286 */       BlocksMap.BlockInfo blockInfo = this.namesystem.blocksMap.getStoredBlock(block);
/*  287 */       fileNode.addBlock(blockInfo);
/*      */ 
/*  289 */       NameNode.stateChangeLog.debug(new StringBuilder().append("DIR* FSDirectory.addFile: ").append(path).append(" with ").append(block).append(" is added to the in-memory ").append("file system").toString());
/*      */     }
/*      */ 
/*  294 */     return block;
/*      */   }
/*      */ 
/*      */   void persistBlocks(String path, INodeFileUnderConstruction file)
/*      */     throws IOException
/*      */   {
/*  302 */     waitForReady();
/*      */ 
/*  304 */     synchronized (this.rootDir) {
/*  305 */       this.fsImage.getEditLog().logOpenFile(path, file);
/*  306 */       NameNode.stateChangeLog.debug(new StringBuilder().append("DIR* FSDirectory.persistBlocks: ").append(path).append(" with ").append(file.getBlocks().length).append(" blocks is persisted").toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   void closeFile(String path, INodeFile file)
/*      */     throws IOException
/*      */   {
/*  316 */     waitForReady();
/*  317 */     synchronized (this.rootDir)
/*      */     {
/*  319 */       this.fsImage.getEditLog().logCloseFile(path, file);
/*  320 */       if (NameNode.stateChangeLog.isDebugEnabled())
/*  321 */         NameNode.stateChangeLog.debug(new StringBuilder().append("DIR* FSDirectory.closeFile: ").append(path).append(" with ").append(file.getBlocks().length).append(" blocks is persisted").toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   boolean removeBlock(String path, INodeFileUnderConstruction fileNode, Block block)
/*      */     throws IOException
/*      */   {
/*  333 */     waitForReady();
/*      */ 
/*  335 */     synchronized (this.rootDir)
/*      */     {
/*  337 */       fileNode.removeBlock(block);
/*  338 */       this.namesystem.blocksMap.removeINode(block);
/*      */ 
/*  340 */       this.namesystem.corruptReplicas.removeFromCorruptReplicasMap(block);
/*      */ 
/*  343 */       this.fsImage.getEditLog().logOpenFile(path, fileNode);
/*  344 */       NameNode.stateChangeLog.debug(new StringBuilder().append("DIR* FSDirectory.addFile: ").append(path).append(" with ").append(block).append(" is added to the").toString());
/*      */ 
/*  347 */       INode[] pathINodes = getExistingPathINodes(path);
/*  348 */       updateCount(pathINodes, pathINodes.length - 1, 0L, -fileNode.getPreferredBlockSize() * fileNode.getReplication(), true);
/*      */     }
/*      */ 
/*  352 */     return true;
/*      */   }
/*      */ 
/*      */   boolean renameTo(String src, String dst)
/*      */     throws QuotaExceededException
/*      */   {
/*  359 */     if (NameNode.stateChangeLog.isDebugEnabled()) {
/*  360 */       NameNode.stateChangeLog.debug(new StringBuilder().append("DIR* FSDirectory.renameTo: ").append(src).append(" to ").append(dst).toString());
/*      */     }
/*      */ 
/*  363 */     waitForReady();
/*  364 */     long now = FSNamesystem.now();
/*  365 */     if (!unprotectedRenameTo(src, dst, now))
/*  366 */       return false;
/*  367 */     this.fsImage.getEditLog().logRename(src, dst, now);
/*  368 */     return true;
/*      */   }
/*      */ 
/*      */   boolean unprotectedRenameTo(String src, String dst, long timestamp)
/*      */     throws QuotaExceededException
/*      */   {
/*  380 */     synchronized (this.rootDir) {
/*  381 */       INode[] srcInodes = this.rootDir.getExistingPathINodes(src);
/*      */ 
/*  384 */       if (srcInodes[(srcInodes.length - 1)] == null) {
/*  385 */         NameNode.stateChangeLog.warn(new StringBuilder().append("DIR* FSDirectory.unprotectedRenameTo: failed to rename ").append(src).append(" to ").append(dst).append(" because source does not exist").toString());
/*      */ 
/*  388 */         return false;
/*      */       }
/*  390 */       if (srcInodes.length == 1) {
/*  391 */         NameNode.stateChangeLog.warn(new StringBuilder().append("DIR* FSDirectory.unprotectedRenameTo: failed to rename ").append(src).append(" to ").append(dst).append(" because source is the root").toString());
/*      */ 
/*  393 */         return false;
/*      */       }
/*  395 */       if (isDir(dst)) {
/*  396 */         dst = new StringBuilder().append(dst).append("/").append(new Path(src).getName()).toString();
/*      */       }
/*      */ 
/*  400 */       if (dst.equals(src)) {
/*  401 */         return true;
/*      */       }
/*      */ 
/*  404 */       if ((dst.startsWith(src)) && (dst.charAt(src.length()) == '/'))
/*      */       {
/*  406 */         NameNode.stateChangeLog.warn(new StringBuilder().append("DIR* FSDirectory.unprotectedRenameTo: failed to rename ").append(src).append(" to ").append(dst).append(" because destination starts with src").toString());
/*      */ 
/*  409 */         return false;
/*      */       }
/*      */ 
/*  412 */       byte[][] dstComponents = INode.getPathComponents(dst);
/*  413 */       INode[] dstInodes = new INode[dstComponents.length];
/*  414 */       this.rootDir.getExistingPathINodes(dstComponents, dstInodes);
/*  415 */       if (dstInodes[(dstInodes.length - 1)] != null) {
/*  416 */         NameNode.stateChangeLog.warn(new StringBuilder().append("DIR* FSDirectory.unprotectedRenameTo: failed to rename ").append(src).append(" to ").append(dst).append(" because destination exists").toString());
/*      */ 
/*  419 */         return false;
/*      */       }
/*  421 */       if (dstInodes[(dstInodes.length - 2)] == null) {
/*  422 */         NameNode.stateChangeLog.warn(new StringBuilder().append("DIR* FSDirectory.unprotectedRenameTo: failed to rename ").append(src).append(" to ").append(dst).append(" because destination's parent does not exist").toString());
/*      */ 
/*  425 */         return false;
/*      */       }
/*      */ 
/*  429 */       verifyQuotaForRename(srcInodes, dstInodes);
/*      */ 
/*  431 */       INode dstChild = null;
/*  432 */       INode srcChild = null;
/*  433 */       String srcChildName = null;
/*      */       try
/*      */       {
/*  436 */         srcChild = removeChild(srcInodes, srcInodes.length - 1);
/*      */         boolean bool;
/*  437 */         if (srcChild == null) {
/*  438 */           NameNode.stateChangeLog.warn(new StringBuilder().append("DIR* FSDirectory.unprotectedRenameTo: failed to rename ").append(src).append(" to ").append(dst).append(" because the source can not be removed").toString());
/*      */ 
/*  441 */           bool = false;
/*      */ 
/*  461 */           if ((dstChild == null) && (srcChild != null))
/*      */           {
/*  463 */             srcChild.setLocalName(srcChildName);
/*  464 */             addChildNoQuotaCheck(srcInodes, srcInodes.length - 1, srcChild, -1L, false); } return bool;
/*      */         }
/*  443 */         srcChildName = srcChild.getLocalName();
/*  444 */         srcChild.setLocalName(dstComponents[(dstInodes.length - 1)]);
/*      */ 
/*  447 */         dstChild = addChildNoQuotaCheck(dstInodes, dstInodes.length - 1, srcChild, -1L, false);
/*      */ 
/*  449 */         if (dstChild != null) {
/*  450 */           srcChild = null;
/*  451 */           if (NameNode.stateChangeLog.isDebugEnabled()) {
/*  452 */             NameNode.stateChangeLog.debug(new StringBuilder().append("DIR* FSDirectory.unprotectedRenameTo: ").append(src).append(" is renamed to ").append(dst).toString());
/*      */           }
/*      */ 
/*  456 */           srcInodes[(srcInodes.length - 2)].setModificationTime(timestamp);
/*  457 */           dstInodes[(dstInodes.length - 2)].setModificationTime(timestamp);
/*  458 */           bool = true;
/*      */ 
/*  461 */           if ((dstChild == null) && (srcChild != null))
/*      */           {
/*  463 */             srcChild.setLocalName(srcChildName);
/*  464 */             addChildNoQuotaCheck(srcInodes, srcInodes.length - 1, srcChild, -1L, false); } return bool;
/*      */         }
/*      */       }
/*      */       finally
/*      */       {
/*  461 */         if ((dstChild == null) && (srcChild != null))
/*      */         {
/*  463 */           srcChild.setLocalName(srcChildName);
/*  464 */           addChildNoQuotaCheck(srcInodes, srcInodes.length - 1, srcChild, -1L, false);
/*      */         }
/*      */       }
/*      */ 
/*  468 */       NameNode.stateChangeLog.warn(new StringBuilder().append("DIR* FSDirectory.unprotectedRenameTo: failed to rename ").append(src).append(" to ").append(dst).toString());
/*      */ 
/*  470 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */   Block[] setReplication(String src, short replication, int[] oldReplication)
/*      */     throws IOException
/*      */   {
/*  487 */     waitForReady();
/*  488 */     Block[] fileBlocks = unprotectedSetReplication(src, replication, oldReplication);
/*  489 */     if (fileBlocks != null)
/*  490 */       this.fsImage.getEditLog().logSetReplication(src, replication);
/*  491 */     return fileBlocks;
/*      */   }
/*      */ 
/*      */   Block[] unprotectedSetReplication(String src, short replication, int[] oldReplication)
/*      */     throws IOException
/*      */   {
/*  498 */     if (oldReplication == null)
/*  499 */       oldReplication = new int[1];
/*  500 */     oldReplication[0] = -1;
/*  501 */     Block[] fileBlocks = null;
/*  502 */     synchronized (this.rootDir) {
/*  503 */       INode[] inodes = this.rootDir.getExistingPathINodes(src);
/*  504 */       INode inode = inodes[(inodes.length - 1)];
/*  505 */       if (inode == null)
/*  506 */         return null;
/*  507 */       if (inode.isDirectory())
/*  508 */         return null;
/*  509 */       INodeFile fileNode = (INodeFile)inode;
/*  510 */       oldReplication[0] = fileNode.getReplication();
/*      */ 
/*  513 */       long dsDelta = replication - oldReplication[0] * (fileNode.diskspaceConsumed() / oldReplication[0]);
/*      */ 
/*  515 */       updateCount(inodes, inodes.length - 1, 0L, dsDelta, true);
/*      */ 
/*  517 */       fileNode.setReplication(replication);
/*  518 */       fileBlocks = fileNode.getBlocks();
/*      */     }
/*  520 */     return fileBlocks;
/*      */   }
/*      */ 
/*      */   long getPreferredBlockSize(String filename)
/*      */     throws IOException
/*      */   {
/*  530 */     synchronized (this.rootDir) {
/*  531 */       INode fileNode = this.rootDir.getNode(filename);
/*  532 */       if (fileNode == null) {
/*  533 */         throw new IOException(new StringBuilder().append("Unknown file: ").append(filename).toString());
/*      */       }
/*  535 */       if (fileNode.isDirectory()) {
/*  536 */         throw new IOException(new StringBuilder().append("Getting block size of a directory: ").append(filename).toString());
/*      */       }
/*      */ 
/*  539 */       return ((INodeFile)fileNode).getPreferredBlockSize();
/*      */     }
/*      */   }
/*      */ 
/*      */   boolean exists(String src) {
/*  544 */     src = normalizePath(src);
/*  545 */     synchronized (this.rootDir) {
/*  546 */       INode inode = this.rootDir.getNode(src);
/*  547 */       if (inode == null) {
/*  548 */         return false;
/*      */       }
/*  550 */       return inode.isDirectory();
/*      */     }
/*      */   }
/*      */ 
/*      */   void setPermission(String src, FsPermission permission) throws IOException
/*      */   {
/*  556 */     unprotectedSetPermission(src, permission);
/*  557 */     this.fsImage.getEditLog().logSetPermissions(src, permission);
/*      */   }
/*      */ 
/*      */   void unprotectedSetPermission(String src, FsPermission permissions) throws FileNotFoundException {
/*  561 */     synchronized (this.rootDir) {
/*  562 */       INode inode = this.rootDir.getNode(src);
/*  563 */       if (inode == null)
/*  564 */         throw new FileNotFoundException(new StringBuilder().append("File does not exist: ").append(src).toString());
/*  565 */       inode.setPermission(permissions);
/*      */     }
/*      */   }
/*      */ 
/*      */   void setOwner(String src, String username, String groupname) throws IOException
/*      */   {
/*  571 */     unprotectedSetOwner(src, username, groupname);
/*  572 */     this.fsImage.getEditLog().logSetOwner(src, username, groupname);
/*      */   }
/*      */ 
/*      */   void unprotectedSetOwner(String src, String username, String groupname) throws FileNotFoundException {
/*  576 */     synchronized (this.rootDir) {
/*  577 */       INode inode = this.rootDir.getNode(src);
/*  578 */       if (inode == null)
/*  579 */         throw new FileNotFoundException(new StringBuilder().append("File does not exist: ").append(src).toString());
/*  580 */       if (username != null) {
/*  581 */         inode.setUser(username);
/*      */       }
/*  583 */       if (groupname != null)
/*  584 */         inode.setGroup(groupname);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void concat(String target, String[] srcs)
/*      */     throws IOException
/*      */   {
/*  593 */     synchronized (this.rootDir)
/*      */     {
/*  595 */       waitForReady();
/*  596 */       long timestamp = FSNamesystem.now();
/*  597 */       unprotectedConcat(target, srcs, timestamp);
/*      */ 
/*  599 */       this.fsImage.getEditLog().logConcat(target, srcs, timestamp);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void unprotectedConcat(String target, String[] srcs, long timestamp)
/*      */   {
/*  615 */     if (NameNode.stateChangeLog.isDebugEnabled()) {
/*  616 */       NameNode.stateChangeLog.debug(new StringBuilder().append("DIR* FSNamesystem.concat to ").append(target).toString());
/*      */     }
/*      */ 
/*  620 */     INode[] trgINodes = getExistingPathINodes(target);
/*  621 */     INodeFile trgInode = (INodeFile)trgINodes[(trgINodes.length - 1)];
/*  622 */     INodeDirectory trgParent = (INodeDirectory)trgINodes[(trgINodes.length - 2)];
/*      */ 
/*  624 */     INodeFile[] allSrcInodes = new INodeFile[srcs.length];
/*  625 */     int i = 0;
/*  626 */     int totalBlocks = 0;
/*  627 */     for (String src : srcs) {
/*  628 */       INodeFile srcInode = getFileINode(src);
/*  629 */       allSrcInodes[(i++)] = srcInode;
/*  630 */       totalBlocks += srcInode.blocks.length;
/*      */     }
/*  632 */     trgInode.appendBlocks(allSrcInodes, totalBlocks);
/*      */ 
/*  635 */     int count = 0;
/*  636 */     for (INodeFile nodeToRemove : allSrcInodes) {
/*  637 */       if (nodeToRemove != null)
/*      */       {
/*  639 */         nodeToRemove.blocks = null;
/*  640 */         trgParent.removeChild(nodeToRemove);
/*  641 */         count++;
/*      */       }
/*      */     }
/*  644 */     trgInode.setModificationTime(timestamp);
/*  645 */     trgParent.setModificationTime(timestamp);
/*      */ 
/*  647 */     unprotectedUpdateCount(trgINodes, trgINodes.length - 1, -count, 0L);
/*      */   }
/*      */ 
/*      */   boolean delete(String src, List<Block> collectedBlocks)
/*      */   {
/*  660 */     if (NameNode.stateChangeLog.isDebugEnabled()) {
/*  661 */       NameNode.stateChangeLog.debug(new StringBuilder().append("DIR* FSDirectory.delete: ").append(src).toString());
/*      */     }
/*  663 */     waitForReady();
/*  664 */     long now = FSNamesystem.now();
/*  665 */     int filesRemoved = unprotectedDelete(src, collectedBlocks, now);
/*  666 */     if (filesRemoved <= 0) {
/*  667 */       return false;
/*      */     }
/*  669 */     incrDeletedFileCount(filesRemoved);
/*      */ 
/*  671 */     FSNamesystem.getFSNamesystem().removePathAndBlocks(src, null);
/*  672 */     this.fsImage.getEditLog().logDelete(src, now);
/*  673 */     return true;
/*      */   }
/*      */ 
/*      */   boolean isDirEmpty(String src)
/*      */   {
/*  678 */     boolean dirNotEmpty = true;
/*  679 */     if (!isDir(src)) {
/*  680 */       return true;
/*      */     }
/*  682 */     synchronized (this.rootDir) {
/*  683 */       INode targetNode = this.rootDir.getNode(src);
/*  684 */       assert (targetNode != null) : "should be taken care in isDir() above";
/*  685 */       if (((INodeDirectory)targetNode).getChildren().size() != 0) {
/*  686 */         dirNotEmpty = false;
/*      */       }
/*      */     }
/*  689 */     return dirNotEmpty;
/*      */   }
/*      */ 
/*      */   void unprotectedDelete(String src, long mTime)
/*      */   {
/*  703 */     List collectedBlocks = new ArrayList();
/*  704 */     int filesRemoved = unprotectedDelete(src, collectedBlocks, mTime);
/*  705 */     if (filesRemoved > 0)
/*  706 */       this.namesystem.removePathAndBlocks(src, collectedBlocks);
/*      */   }
/*      */ 
/*      */   int unprotectedDelete(String src, List<Block> collectedBlocks, long mtime)
/*      */   {
/*  723 */     src = normalizePath(src);
/*      */ 
/*  725 */     synchronized (this.rootDir) {
/*  726 */       INode[] inodes = this.rootDir.getExistingPathINodes(src);
/*  727 */       INode targetNode = inodes[(inodes.length - 1)];
/*      */ 
/*  729 */       if (targetNode == null) {
/*  730 */         NameNode.stateChangeLog.debug(new StringBuilder().append("DIR* FSDirectory.unprotectedDelete: failed to remove ").append(src).append(" because it does not exist").toString());
/*      */ 
/*  732 */         return 0;
/*      */       }
/*  734 */       if (inodes.length == 1) {
/*  735 */         NameNode.stateChangeLog.warn(new StringBuilder().append("DIR* FSDirectory.unprotectedDelete: failed to remove ").append(src).append(" because the root is not allowed to be deleted").toString());
/*      */ 
/*  738 */         return 0;
/*      */       }
/*  740 */       int pos = inodes.length - 1;
/*  741 */       targetNode = removeChild(inodes, pos);
/*  742 */       if (targetNode == null) {
/*  743 */         return 0;
/*      */       }
/*      */ 
/*  746 */       inodes[(pos - 1)].setModificationTime(mtime);
/*  747 */       int filesRemoved = targetNode.collectSubtreeBlocksAndClear(collectedBlocks);
/*      */ 
/*  749 */       if (NameNode.stateChangeLog.isDebugEnabled()) {
/*  750 */         NameNode.stateChangeLog.debug(new StringBuilder().append("DIR* FSDirectory.unprotectedDelete: ").append(src).append(" is removed").toString());
/*      */       }
/*      */ 
/*  753 */       return filesRemoved;
/*      */     }
/*      */   }
/*      */ 
/*      */   void replaceNode(String path, INodeFile oldnode, INodeFile newnode)
/*      */     throws IOException
/*      */   {
/*  762 */     synchronized (this.rootDir)
/*      */     {
/*  766 */       if (!oldnode.removeNode()) {
/*  767 */         NameNode.stateChangeLog.warn(new StringBuilder().append("DIR* FSDirectory.replaceNode: failed to remove ").append(path).toString());
/*      */ 
/*  769 */         throw new IOException(new StringBuilder().append("FSDirectory.replaceNode: failed to remove ").append(path).toString());
/*      */       }
/*      */ 
/*  777 */       this.rootDir.addNode(path, newnode);
/*      */ 
/*  779 */       int index = 0;
/*  780 */       for (Block b : newnode.getBlocks()) {
/*  781 */         BlocksMap.BlockInfo info = this.namesystem.blocksMap.addINode(b, newnode);
/*  782 */         newnode.setBlock(index, info);
/*  783 */         index++;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   DirectoryListing getListing(String src, byte[] startAfter)
/*      */   {
/*  796 */     String srcs = normalizePath(src);
/*      */ 
/*  798 */     synchronized (this.rootDir) {
/*  799 */       INode targetNode = this.rootDir.getNode(srcs);
/*  800 */       if (targetNode == null) {
/*  801 */         return null;
/*      */       }
/*  803 */       if (!targetNode.isDirectory()) {
/*  804 */         return new DirectoryListing(new HdfsFileStatus[] { createFileStatus(HdfsFileStatus.EMPTY_NAME, targetNode) }, 0);
/*      */       }
/*      */ 
/*  807 */       INodeDirectory dirInode = (INodeDirectory)targetNode;
/*  808 */       List contents = dirInode.getChildren();
/*  809 */       int startChild = dirInode.nextChild(startAfter);
/*  810 */       int totalNumChildren = contents.size();
/*  811 */       int numOfListing = Math.min(totalNumChildren - startChild, this.lsLimit);
/*  812 */       HdfsFileStatus[] listing = new HdfsFileStatus[numOfListing];
/*  813 */       for (int i = 0; i < numOfListing; i++) {
/*  814 */         INode cur = (INode)contents.get(startChild + i);
/*  815 */         listing[i] = createFileStatus(cur.name, cur);
/*      */       }
/*  817 */       return new DirectoryListing(listing, totalNumChildren - startChild - numOfListing);
/*      */     }
/*      */   }
/*      */ 
/*      */   HdfsFileStatus getFileInfo(String src)
/*      */   {
/*  828 */     String srcs = normalizePath(src);
/*  829 */     synchronized (this.rootDir) {
/*  830 */       INode targetNode = this.rootDir.getNode(srcs);
/*  831 */       if (targetNode == null) {
/*  832 */         return null;
/*      */       }
/*      */ 
/*  835 */       return createFileStatus(HdfsFileStatus.EMPTY_NAME, targetNode);
/*      */     }
/*      */   }
/*      */ 
/*      */   Block[] getFileBlocks(String src)
/*      */   {
/*  844 */     waitForReady();
/*  845 */     synchronized (this.rootDir) {
/*  846 */       INode targetNode = this.rootDir.getNode(src);
/*  847 */       if (targetNode == null)
/*  848 */         return null;
/*  849 */       if (targetNode.isDirectory())
/*  850 */         return null;
/*  851 */       return ((INodeFile)targetNode).getBlocks();
/*      */     }
/*      */   }
/*      */ 
/*      */   INodeFile getFileINode(String src)
/*      */   {
/*  859 */     synchronized (this.rootDir) {
/*  860 */       INode inode = this.rootDir.getNode(src);
/*  861 */       if ((inode == null) || (inode.isDirectory()))
/*  862 */         return null;
/*  863 */       return (INodeFile)inode;
/*      */     }
/*      */   }
/*      */ 
/*      */   INode[] getExistingPathINodes(String path)
/*      */   {
/*  880 */     synchronized (this.rootDir) {
/*  881 */       return this.rootDir.getExistingPathINodes(path);
/*      */     }
/*      */   }
/*      */ 
/*      */   boolean isValidToCreate(String src)
/*      */   {
/*  889 */     String srcs = normalizePath(src);
/*  890 */     synchronized (this.rootDir) {
/*  891 */       if ((srcs.startsWith("/")) && (!srcs.endsWith("/")) && (this.rootDir.getNode(srcs) == null))
/*      */       {
/*  894 */         return true;
/*      */       }
/*  896 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */   boolean isDir(String src)
/*      */   {
/*  905 */     synchronized (this.rootDir) {
/*  906 */       INode node = this.rootDir.getNode(normalizePath(src));
/*  907 */       return (node != null) && (node.isDirectory());
/*      */     }
/*      */   }
/*      */ 
/*      */   void updateSpaceConsumed(String path, long nsDelta, long dsDelta)
/*      */     throws QuotaExceededException, FileNotFoundException
/*      */   {
/*  923 */     synchronized (this.rootDir) {
/*  924 */       INode[] inodes = this.rootDir.getExistingPathINodes(path);
/*  925 */       int len = inodes.length;
/*  926 */       if (inodes[(len - 1)] == null) {
/*  927 */         throw new FileNotFoundException(new StringBuilder().append(path).append(" does not exist under rootDir.").toString());
/*      */       }
/*      */ 
/*  930 */       updateCount(inodes, len - 1, nsDelta, dsDelta, true);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void updateCount(INode[] inodes, int numOfINodes, long nsDelta, long dsDelta, boolean checkQuota)
/*      */     throws QuotaExceededException
/*      */   {
/*  946 */     if (!this.ready)
/*      */     {
/*  948 */       return;
/*      */     }
/*  950 */     if (numOfINodes > inodes.length) {
/*  951 */       numOfINodes = inodes.length;
/*      */     }
/*  953 */     if (checkQuota) {
/*  954 */       verifyQuota(inodes, numOfINodes, nsDelta, dsDelta, null);
/*      */     }
/*  956 */     for (int i = 0; i < numOfINodes; i++)
/*  957 */       if (inodes[i].isQuotaSet()) {
/*  958 */         INodeDirectoryWithQuota node = (INodeDirectoryWithQuota)inodes[i];
/*  959 */         node.updateNumItemsInTree(nsDelta, dsDelta);
/*      */       }
/*      */   }
/*      */ 
/*      */   private void updateCountNoQuotaCheck(INode[] inodes, int numOfINodes, long nsDelta, long dsDelta)
/*      */   {
/*      */     try
/*      */     {
/*  971 */       updateCount(inodes, numOfINodes, nsDelta, dsDelta, false);
/*      */     } catch (QuotaExceededException e) {
/*  973 */       NameNode.LOG.warn("FSDirectory.updateCountNoQuotaCheck - unexpected ", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   void unprotectedUpdateCount(INode[] inodes, int numOfINodes, long nsDelta, long dsDelta)
/*      */   {
/*  987 */     for (int i = 0; i < numOfINodes; i++)
/*  988 */       if (inodes[i].isQuotaSet()) {
/*  989 */         INodeDirectoryWithQuota node = (INodeDirectoryWithQuota)inodes[i];
/*  990 */         node.addSpaceConsumed(nsDelta, dsDelta);
/*      */       }
/*      */   }
/*      */ 
/*      */   private static String getFullPathName(INode[] inodes, int pos)
/*      */   {
/*  998 */     StringBuilder fullPathName = new StringBuilder();
/*  999 */     for (int i = 1; i <= pos; i++) {
/* 1000 */       fullPathName.append('/').append(inodes[i].getLocalName());
/*      */     }
/* 1002 */     return fullPathName.toString();
/*      */   }
/*      */ 
/*      */   static String getFullPathName(INode inode)
/*      */   {
/* 1008 */     int depth = 0;
/* 1009 */     for (INode i = inode; i != null; i = i.parent) {
/* 1010 */       depth++;
/*      */     }
/* 1012 */     INode[] inodes = new INode[depth];
/*      */ 
/* 1015 */     for (int i = 0; i < depth; i++) {
/* 1016 */       inodes[(depth - i - 1)] = inode;
/* 1017 */       inode = inode.parent;
/*      */     }
/* 1019 */     return getFullPathName(inodes, depth - 1);
/*      */   }
/*      */ 
/*      */   boolean mkdirs(String src, PermissionStatus permissions, boolean inheritPermission, long now)
/*      */     throws FileNotFoundException, QuotaExceededException
/*      */   {
/* 1040 */     src = normalizePath(src);
/* 1041 */     String[] names = INode.getPathNames(src);
/* 1042 */     byte[][] components = INode.getPathComponents(names);
/* 1043 */     INode[] inodes = new INode[components.length];
/*      */ 
/* 1045 */     synchronized (this.rootDir) {
/* 1046 */       this.rootDir.getExistingPathINodes(components, inodes);
/*      */ 
/* 1049 */       StringBuilder pathbuilder = new StringBuilder();
/* 1050 */       for (int i = 1; 
/* 1051 */         (i < inodes.length) && (inodes[i] != null); i++) {
/* 1052 */         pathbuilder.append(new StringBuilder().append("/").append(names[i]).toString());
/* 1053 */         if (!inodes[i].isDirectory()) {
/* 1054 */           throw new FileNotFoundException(new StringBuilder().append("Parent path is not a directory: ").append(pathbuilder).toString());
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1060 */       for (; i < inodes.length; i++) {
/* 1061 */         pathbuilder.append(new StringBuilder().append("/").append(names[i]).toString());
/* 1062 */         String cur = pathbuilder.toString();
/* 1063 */         unprotectedMkdir(inodes, i, components[i], permissions, (inheritPermission) || (i != components.length - 1), now);
/*      */ 
/* 1065 */         if (inodes[i] == null) {
/* 1066 */           return false;
/*      */         }
/*      */ 
/* 1070 */         if (this.namesystem != null)
/* 1071 */           NameNode.getNameNodeMetrics().incrNumFilesCreated();
/* 1072 */         this.fsImage.getEditLog().logMkDir(cur, inodes[i]);
/* 1073 */         NameNode.stateChangeLog.debug(new StringBuilder().append("DIR* FSDirectory.mkdirs: created directory ").append(cur).toString());
/*      */       }
/*      */     }
/*      */ 
/* 1077 */     return true;
/*      */   }
/*      */ 
/*      */   INode unprotectedMkdir(String src, PermissionStatus permissions, long timestamp)
/*      */     throws QuotaExceededException
/*      */   {
/* 1084 */     byte[][] components = INode.getPathComponents(src);
/* 1085 */     INode[] inodes = new INode[components.length];
/* 1086 */     synchronized (this.rootDir) {
/* 1087 */       this.rootDir.getExistingPathINodes(components, inodes);
/* 1088 */       unprotectedMkdir(inodes, inodes.length - 1, components[(inodes.length - 1)], permissions, false, timestamp);
/*      */ 
/* 1090 */       return inodes[(inodes.length - 1)];
/*      */     }
/*      */   }
/*      */ 
/*      */   private void unprotectedMkdir(INode[] inodes, int pos, byte[] name, PermissionStatus permission, boolean inheritPermission, long timestamp)
/*      */     throws QuotaExceededException
/*      */   {
/* 1101 */     inodes[pos] = addChild(inodes, pos, new INodeDirectory(name, permission, timestamp), -1L, inheritPermission);
/*      */   }
/*      */ 
/*      */   private <T extends INode> T addNode(String src, T child, long childDiskspace, boolean inheritPermission)
/*      */     throws QuotaExceededException
/*      */   {
/* 1112 */     byte[][] components = INode.getPathComponents(src);
/* 1113 */     byte[] path = components[(components.length - 1)];
/* 1114 */     child.setLocalName(path);
/* 1115 */     cacheName(child);
/* 1116 */     INode[] inodes = new INode[components.length];
/* 1117 */     synchronized (this.rootDir) {
/* 1118 */       this.rootDir.getExistingPathINodes(components, inodes);
/* 1119 */       return addChild(inodes, inodes.length - 1, child, childDiskspace, inheritPermission);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void verifyQuota(INode[] inodes, int pos, long nsDelta, long dsDelta, INode commonAncestor)
/*      */     throws QuotaExceededException
/*      */   {
/* 1139 */     if (!this.ready)
/*      */     {
/* 1141 */       return;
/*      */     }
/* 1143 */     if (pos > inodes.length) {
/* 1144 */       pos = inodes.length;
/*      */     }
/* 1146 */     int i = pos - 1;
/*      */     try
/*      */     {
/* 1149 */       for (; i >= 0; i--) {
/* 1150 */         if (commonAncestor == inodes[i])
/*      */         {
/* 1153 */           return;
/*      */         }
/* 1155 */         if (inodes[i].isQuotaSet()) {
/* 1156 */           INodeDirectoryWithQuota node = (INodeDirectoryWithQuota)inodes[i];
/* 1157 */           node.verifyQuota(nsDelta, dsDelta);
/*      */         }
/*      */       }
/*      */     } catch (QuotaExceededException e) {
/* 1161 */       e.setPathName(getFullPathName(inodes, i));
/* 1162 */       throw e;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void verifyQuotaForRename(INode[] srcInodes, INode[] dstInodes)
/*      */     throws QuotaExceededException
/*      */   {
/* 1176 */     if (!this.ready)
/*      */     {
/* 1178 */       return;
/*      */     }
/* 1180 */     INode srcInode = srcInodes[(srcInodes.length - 1)];
/* 1181 */     INode commonAncestor = null;
/* 1182 */     for (int i = 0; srcInodes[i] == dstInodes[i]; i++) {
/* 1183 */       commonAncestor = srcInodes[i];
/*      */     }
/* 1185 */     INode.DirCounts counts = new INode.DirCounts();
/* 1186 */     srcInode.spaceConsumedInTree(counts);
/* 1187 */     verifyQuota(dstInodes, dstInodes.length - 1, counts.getNsCount(), counts.getDsCount(), commonAncestor);
/*      */   }
/*      */ 
/*      */   private <T extends INode> T addChild(INode[] pathComponents, int pos, T child, long childDiskspace, boolean inheritPermission, boolean checkQuota)
/*      */     throws QuotaExceededException
/*      */   {
/* 1197 */     INode.DirCounts counts = new INode.DirCounts();
/* 1198 */     child.spaceConsumedInTree(counts);
/* 1199 */     if (childDiskspace < 0L) {
/* 1200 */       childDiskspace = counts.getDsCount();
/*      */     }
/* 1202 */     updateCount(pathComponents, pos, counts.getNsCount(), childDiskspace, checkQuota);
/*      */ 
/* 1204 */     INode addedNode = ((INodeDirectory)pathComponents[(pos - 1)]).addChild(child, inheritPermission);
/*      */ 
/* 1206 */     if (addedNode == null) {
/* 1207 */       updateCount(pathComponents, pos, -counts.getNsCount(), -childDiskspace, true);
/*      */     }
/*      */ 
/* 1210 */     return addedNode;
/*      */   }
/*      */ 
/*      */   private <T extends INode> T addChild(INode[] pathComponents, int pos, T child, long childDiskspace, boolean inheritPermission)
/*      */     throws QuotaExceededException
/*      */   {
/* 1216 */     return addChild(pathComponents, pos, child, childDiskspace, inheritPermission, true);
/*      */   }
/*      */ 
/*      */   private <T extends INode> T addChildNoQuotaCheck(INode[] pathComponents, int pos, T child, long childDiskspace, boolean inheritPermission)
/*      */   {
/* 1222 */     INode inode = null;
/*      */     try {
/* 1224 */       inode = addChild(pathComponents, pos, child, childDiskspace, inheritPermission, false);
/*      */     }
/*      */     catch (QuotaExceededException e) {
/* 1227 */       NameNode.LOG.warn("FSDirectory.addChildNoQuotaCheck - unexpected", e);
/*      */     }
/* 1229 */     return inode;
/*      */   }
/*      */ 
/*      */   private INode removeChild(INode[] pathComponents, int pos)
/*      */   {
/* 1238 */     INode removedNode = ((INodeDirectory)pathComponents[(pos - 1)]).removeChild(pathComponents[pos]);
/*      */ 
/* 1240 */     if (removedNode != null) {
/* 1241 */       INode.DirCounts counts = new INode.DirCounts();
/* 1242 */       removedNode.spaceConsumedInTree(counts);
/* 1243 */       updateCountNoQuotaCheck(pathComponents, pos, -counts.getNsCount(), -counts.getDsCount());
/*      */     }
/*      */ 
/* 1246 */     return removedNode;
/*      */   }
/*      */ 
/*      */   String normalizePath(String src)
/*      */   {
/* 1252 */     if ((src.length() > 1) && (src.endsWith("/"))) {
/* 1253 */       src = src.substring(0, src.length() - 1);
/*      */     }
/* 1255 */     return src;
/*      */   }
/*      */ 
/*      */   ContentSummary getContentSummary(String src) throws IOException {
/* 1259 */     String srcs = normalizePath(src);
/* 1260 */     synchronized (this.rootDir) {
/* 1261 */       INode targetNode = this.rootDir.getNode(srcs);
/* 1262 */       if (targetNode == null) {
/* 1263 */         throw new FileNotFoundException(new StringBuilder().append("File does not exist: ").append(srcs).toString());
/*      */       }
/*      */ 
/* 1266 */       return targetNode.computeContentSummary();
/*      */     }
/*      */   }
/*      */ 
/*      */   void updateCountForINodeWithQuota()
/*      */   {
/* 1279 */     updateCountForINodeWithQuota(this.rootDir, new INode.DirCounts(), new ArrayList(50));
/*      */   }
/*      */ 
/*      */   private static void updateCountForINodeWithQuota(INodeDirectory dir, INode.DirCounts counts, ArrayList<INode> nodesInPath)
/*      */   {
/* 1297 */     long parentNamespace = counts.nsCount;
/* 1298 */     long parentDiskspace = counts.dsCount;
/*      */ 
/* 1300 */     counts.nsCount = 1L;
/* 1301 */     counts.dsCount = 0L;
/*      */ 
/* 1305 */     nodesInPath.add(dir);
/*      */ 
/* 1307 */     for (INode child : dir.getChildren()) {
/* 1308 */       if (child.isDirectory()) {
/* 1309 */         updateCountForINodeWithQuota((INodeDirectory)child, counts, nodesInPath);
/*      */       }
/*      */       else {
/* 1312 */         counts.nsCount += 1L;
/* 1313 */         counts.dsCount += ((INodeFile)child).diskspaceConsumed();
/*      */       }
/*      */     }
/*      */ 
/* 1317 */     if (dir.isQuotaSet()) {
/* 1318 */       ((INodeDirectoryWithQuota)dir).setSpaceConsumed(counts.nsCount, counts.dsCount);
/*      */ 
/* 1322 */       if (((dir.getNsQuota() >= 0L) && (counts.nsCount > dir.getNsQuota())) || ((dir.getDsQuota() >= 0L) && (counts.dsCount > dir.getDsQuota())))
/*      */       {
/* 1326 */         StringBuilder path = new StringBuilder(512);
/* 1327 */         for (INode n : nodesInPath) {
/* 1328 */           path.append('/');
/* 1329 */           path.append(n.getLocalName());
/*      */         }
/*      */ 
/* 1332 */         NameNode.LOG.warn(new StringBuilder().append("Quota violation in image for ").append(path).append(" (Namespace quota : ").append(dir.getNsQuota()).append(" consumed : ").append(counts.nsCount).append(")").append(" (Diskspace quota : ").append(dir.getDsQuota()).append(" consumed : ").append(counts.dsCount).append(").").toString());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1341 */     nodesInPath.remove(nodesInPath.size() - 1);
/*      */ 
/* 1343 */     counts.nsCount += parentNamespace;
/* 1344 */     counts.dsCount += parentDiskspace;
/*      */   }
/*      */ 
/*      */   INodeDirectory unprotectedSetQuota(String src, long nsQuota, long dsQuota)
/*      */     throws FileNotFoundException, QuotaExceededException
/*      */   {
/* 1358 */     if (((nsQuota < 0L) && (nsQuota != 9223372036854775807L) && (nsQuota < -1L)) || ((dsQuota < 0L) && (dsQuota != 9223372036854775807L) && (dsQuota < -1L)))
/*      */     {
/* 1362 */       throw new IllegalArgumentException(new StringBuilder().append("Illegal value for nsQuota or dsQuota : ").append(nsQuota).append(" and ").append(dsQuota).toString());
/*      */     }
/*      */ 
/* 1367 */     String srcs = normalizePath(src);
/* 1368 */     INode[] inodes = this.rootDir.getExistingPathINodes(src);
/* 1369 */     INode targetNode = inodes[(inodes.length - 1)];
/* 1370 */     if (targetNode == null)
/* 1371 */       throw new FileNotFoundException(new StringBuilder().append("Directory does not exist: ").append(srcs).toString());
/* 1372 */     if (!targetNode.isDirectory())
/* 1373 */       throw new FileNotFoundException(new StringBuilder().append("Cannot set quota on a file: ").append(srcs).toString());
/* 1374 */     if ((targetNode.isRoot()) && (nsQuota == -1L)) {
/* 1375 */       throw new IllegalArgumentException("Cannot clear namespace quota on root.");
/*      */     }
/* 1377 */     INodeDirectory dirNode = (INodeDirectory)targetNode;
/* 1378 */     long oldNsQuota = dirNode.getNsQuota();
/* 1379 */     long oldDsQuota = dirNode.getDsQuota();
/* 1380 */     if (nsQuota == 9223372036854775807L) {
/* 1381 */       nsQuota = oldNsQuota;
/*      */     }
/* 1383 */     if (dsQuota == 9223372036854775807L) {
/* 1384 */       dsQuota = oldDsQuota;
/*      */     }
/*      */ 
/* 1387 */     if ((dirNode instanceof INodeDirectoryWithQuota))
/*      */     {
/* 1389 */       ((INodeDirectoryWithQuota)dirNode).setQuota(nsQuota, dsQuota);
/* 1390 */       if (!dirNode.isQuotaSet())
/*      */       {
/* 1392 */         INodeDirectory newNode = new INodeDirectory(dirNode);
/* 1393 */         INodeDirectory parent = (INodeDirectory)inodes[(inodes.length - 2)];
/* 1394 */         dirNode = newNode;
/* 1395 */         parent.replaceChild(newNode);
/*      */       }
/*      */     }
/*      */     else {
/* 1399 */       INodeDirectoryWithQuota newNode = new INodeDirectoryWithQuota(nsQuota, dsQuota, dirNode);
/*      */ 
/* 1402 */       INodeDirectory parent = (INodeDirectory)inodes[(inodes.length - 2)];
/* 1403 */       dirNode = newNode;
/* 1404 */       parent.replaceChild(newNode);
/*      */     }
/* 1406 */     return (oldNsQuota != nsQuota) || (oldDsQuota != dsQuota) ? dirNode : null;
/*      */   }
/*      */ 
/*      */   void setQuota(String src, long nsQuota, long dsQuota)
/*      */     throws FileNotFoundException, QuotaExceededException
/*      */   {
/* 1417 */     synchronized (this.rootDir) {
/* 1418 */       INodeDirectory dir = unprotectedSetQuota(src, nsQuota, dsQuota);
/* 1419 */       if (dir != null)
/* 1420 */         this.fsImage.getEditLog().logSetQuota(src, dir.getNsQuota(), dir.getDsQuota());
/*      */     }
/*      */   }
/*      */ 
/*      */   long totalInodes()
/*      */   {
/* 1427 */     synchronized (this.rootDir) {
/* 1428 */       return this.rootDir.numItemsInTree();
/*      */     }
/*      */   }
/*      */ 
/*      */   void setTimes(String src, INodeFile inode, long mtime, long atime, boolean force)
/*      */     throws IOException
/*      */   {
/* 1437 */     if (unprotectedSetTimes(src, inode, mtime, atime, force))
/* 1438 */       this.fsImage.getEditLog().logTimes(src, mtime, atime);
/*      */   }
/*      */ 
/*      */   boolean unprotectedSetTimes(String src, long mtime, long atime, boolean force)
/*      */     throws IOException
/*      */   {
/* 1444 */     INodeFile inode = getFileINode(src);
/* 1445 */     return unprotectedSetTimes(src, inode, mtime, atime, force);
/*      */   }
/*      */ 
/*      */   private boolean unprotectedSetTimes(String src, INodeFile inode, long mtime, long atime, boolean force) throws IOException
/*      */   {
/* 1450 */     boolean status = false;
/* 1451 */     if (mtime != -1L) {
/* 1452 */       inode.setModificationTimeForce(mtime);
/* 1453 */       status = true;
/*      */     }
/* 1455 */     if (atime != -1L) {
/* 1456 */       long inodeTime = inode.getAccessTime();
/*      */ 
/* 1460 */       if ((atime <= inodeTime + this.namesystem.getAccessTimePrecision()) && (!force)) {
/* 1461 */         status = false;
/*      */       } else {
/* 1463 */         inode.setAccessTime(atime);
/* 1464 */         status = true;
/*      */       }
/*      */     }
/* 1467 */     return status;
/*      */   }
/*      */ 
/*      */   private static HdfsFileStatus createFileStatus(byte[] path, INode node)
/*      */   {
/* 1475 */     return new HdfsFileStatus(node.isDirectory() ? 0L : ((INodeFile)node).computeContentSummary().getLength(), node.isDirectory(), node.isDirectory() ? 0 : ((INodeFile)node).getReplication(), node.isDirectory() ? 0L : ((INodeFile)node).getPreferredBlockSize(), node.getModificationTime(), node.getAccessTime(), node.getFsPermission(), node.getUserName(), node.getGroupName(), path);
/*      */   }
/*      */ 
/*      */   void cacheName(INode inode)
/*      */   {
/* 1494 */     if (inode.isDirectory()) {
/* 1495 */       return;
/*      */     }
/* 1497 */     ByteArray name = new ByteArray(inode.getLocalNameBytes());
/* 1498 */     name = (ByteArray)this.nameCache.put(name);
/* 1499 */     if (name != null)
/* 1500 */       inode.setLocalName(name.getBytes());
/*      */   }
/*      */ 
/*      */   void shutdown()
/*      */   {
/* 1505 */     this.nameCache.reset();
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.FSDirectory
 * JD-Core Version:    0.6.1
 */
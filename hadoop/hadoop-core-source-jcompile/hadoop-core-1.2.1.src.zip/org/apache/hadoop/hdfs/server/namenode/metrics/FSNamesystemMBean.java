package org.apache.hadoop.hdfs.server.namenode.metrics;

public abstract interface FSNamesystemMBean
{
  public abstract String getFSState();

  public abstract long getBlocksTotal();

  public abstract long getCapacityTotal();

  public abstract long getCapacityRemaining();

  public abstract long getCapacityUsed();

  public abstract long getFilesTotal();

  public abstract long getPendingReplicationBlocks();

  public abstract long getUnderReplicatedBlocks();

  public abstract long getScheduledReplicationBlocks();

  public abstract int getTotalLoad();

  public abstract int numLiveDataNodes();

  public abstract int numDeadDataNodes();
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.metrics.FSNamesystemMBean
 * JD-Core Version:    0.6.1
 */
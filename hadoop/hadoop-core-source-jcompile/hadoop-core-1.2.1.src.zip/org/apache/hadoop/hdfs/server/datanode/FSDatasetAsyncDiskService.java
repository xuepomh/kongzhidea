/*     */ package org.apache.hadoop.hdfs.server.datanode;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ class FSDatasetAsyncDiskService
/*     */ {
/*  50 */   public static final Log LOG = LogFactory.getLog(FSDatasetAsyncDiskService.class);
/*     */   private static final int CORE_THREADS_PER_VOLUME = 1;
/*     */   private static final int MAXIMUM_THREADS_PER_VOLUME = 4;
/*     */   private static final long THREADS_KEEP_ALIVE_SECONDS = 60L;
/*  59 */   private final ThreadGroup threadGroup = new ThreadGroup("async disk service");
/*     */   private ThreadFactory threadFactory;
/*  63 */   private HashMap<File, ThreadPoolExecutor> executors = new HashMap();
/*     */ 
/*     */   FSDatasetAsyncDiskService(File[] volumes)
/*     */   {
/*  77 */     this.threadFactory = new ThreadFactory() {
/*     */       public Thread newThread(Runnable r) {
/*  79 */         return new Thread(FSDatasetAsyncDiskService.this.threadGroup, r);
/*     */       }
/*     */     };
/*  84 */     for (int v = 0; v < volumes.length; v++) {
/*  85 */       ThreadPoolExecutor executor = new ThreadPoolExecutor(1, 4, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue(), this.threadFactory);
/*     */ 
/*  91 */       executor.allowCoreThreadTimeOut(true);
/*  92 */       this.executors.put(volumes[v], executor);
/*     */     }
/*     */   }
/*     */ 
/*     */   synchronized void execute(File root, Runnable task)
/*     */   {
/* 101 */     if (this.executors == null) {
/* 102 */       throw new RuntimeException("AsyncDiskService is already shutdown");
/*     */     }
/* 104 */     ThreadPoolExecutor executor = (ThreadPoolExecutor)this.executors.get(root);
/* 105 */     if (executor == null) {
/* 106 */       throw new RuntimeException("Cannot find root " + root + " for execution of task " + task);
/*     */     }
/*     */ 
/* 109 */     executor.execute(task);
/*     */   }
/*     */ 
/*     */   synchronized void shutdown()
/*     */   {
/* 119 */     if (this.executors == null)
/*     */     {
/* 121 */       LOG.warn("AsyncDiskService has already shut down.");
/*     */     }
/*     */     else {
/* 124 */       LOG.info("Shutting down all async disk service threads...");
/*     */ 
/* 127 */       for (Map.Entry e : this.executors.entrySet()) {
/* 128 */         ((ThreadPoolExecutor)e.getValue()).shutdown();
/*     */       }
/*     */ 
/* 131 */       this.executors = null;
/*     */ 
/* 133 */       LOG.info("All async disk service threads have been shut down");
/*     */     }
/*     */   }
/*     */ 
/*     */   void deleteAsync(FSDataset.FSVolume volume, File blockFile, File metaFile, long dfsBytes, String blockName)
/*     */   {
/* 143 */     DataNode.LOG.info("Scheduling " + blockName + " file " + blockFile + " for deletion");
/*     */ 
/* 145 */     ReplicaFileDeleteTask deletionTask = new ReplicaFileDeleteTask(volume, blockFile, metaFile, dfsBytes, blockName);
/*     */ 
/* 148 */     execute(volume.getCurrentDir(), deletionTask);
/*     */   }
/*     */ 
/*     */   static class ReplicaFileDeleteTask implements Runnable
/*     */   {
/*     */     FSDataset.FSVolume volume;
/*     */     File blockFile;
/*     */     File metaFile;
/*     */     long dfsBytes;
/*     */     String blockName;
/*     */ 
/*     */     ReplicaFileDeleteTask(FSDataset.FSVolume volume, File blockFile, File metaFile, long dfsBytes, String blockName) {
/* 164 */       this.volume = volume;
/* 165 */       this.blockFile = blockFile;
/* 166 */       this.metaFile = metaFile;
/* 167 */       this.dfsBytes = dfsBytes;
/* 168 */       this.blockName = blockName;
/*     */     }
/*     */ 
/*     */     FSDataset.FSVolume getVolume() {
/* 172 */       return this.volume;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 178 */       return "deletion of " + this.blockName + " with file " + this.blockFile + " and meta file " + this.metaFile + " from volume " + this.volume;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 184 */       if ((!this.blockFile.delete()) || ((!this.metaFile.delete()) && (this.metaFile.exists()))) {
/* 185 */         DataNode.LOG.warn("Unexpected error trying to delete " + this.blockName + " at file " + this.blockFile + ". Ignored.");
/*     */       }
/*     */       else {
/* 188 */         this.volume.decDfsUsed(this.dfsBytes);
/* 189 */         DataNode.LOG.info("Deleted " + this.blockName + " at file " + this.blockFile);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.FSDatasetAsyncDiskService
 * JD-Core Version:    0.6.1
 */
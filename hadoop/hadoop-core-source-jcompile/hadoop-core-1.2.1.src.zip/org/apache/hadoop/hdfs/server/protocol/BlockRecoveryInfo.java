/*    */ package org.apache.hadoop.hdfs.server.protocol;
/*    */ 
/*    */ import java.io.DataInput;
/*    */ import java.io.DataOutput;
/*    */ import java.io.IOException;
/*    */ import org.apache.hadoop.hdfs.protocol.Block;
/*    */ import org.apache.hadoop.io.Writable;
/*    */ 
/*    */ public class BlockRecoveryInfo
/*    */   implements Writable
/*    */ {
/*    */   private Block block;
/*    */   private boolean wasRecoveredOnStartup;
/*    */ 
/*    */   public BlockRecoveryInfo()
/*    */   {
/* 32 */     this.block = new Block();
/* 33 */     this.wasRecoveredOnStartup = false;
/*    */   }
/*    */ 
/*    */   public BlockRecoveryInfo(Block block, boolean wasRecoveredOnStartup)
/*    */   {
/* 39 */     this.block = new Block(block);
/* 40 */     this.wasRecoveredOnStartup = wasRecoveredOnStartup;
/*    */   }
/*    */ 
/*    */   public void readFields(DataInput in) throws IOException
/*    */   {
/* 45 */     this.block.readFields(in);
/* 46 */     this.wasRecoveredOnStartup = in.readBoolean();
/*    */   }
/*    */ 
/*    */   public void write(DataOutput out) throws IOException
/*    */   {
/* 51 */     this.block.write(out);
/* 52 */     out.writeBoolean(this.wasRecoveredOnStartup);
/*    */   }
/*    */ 
/*    */   public Block getBlock() {
/* 56 */     return this.block;
/*    */   }
/*    */   public boolean wasRecoveredOnStartup() {
/* 59 */     return this.wasRecoveredOnStartup;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 63 */     return "BlockRecoveryInfo(block=" + this.block + " wasRecoveredOnStartup=" + this.wasRecoveredOnStartup + ")";
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.protocol.BlockRecoveryInfo
 * JD-Core Version:    0.6.1
 */
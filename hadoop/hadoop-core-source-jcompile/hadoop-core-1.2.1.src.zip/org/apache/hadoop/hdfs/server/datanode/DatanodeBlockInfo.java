/*     */ package org.apache.hadoop.hdfs.server.datanode;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.fs.FileUtil;
/*     */ import org.apache.hadoop.fs.HardLink;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.io.IOUtils;
/*     */ 
/*     */ class DatanodeBlockInfo
/*     */ {
/*     */   private FSDataset.FSVolume volume;
/*     */   private File file;
/*     */   private boolean detached;
/*     */ 
/*     */   DatanodeBlockInfo(FSDataset.FSVolume vol, File file)
/*     */   {
/*  42 */     this.volume = vol;
/*  43 */     this.file = file;
/*  44 */     this.detached = false;
/*     */   }
/*     */ 
/*     */   DatanodeBlockInfo(FSDataset.FSVolume vol) {
/*  48 */     this.volume = vol;
/*  49 */     this.file = null;
/*  50 */     this.detached = false;
/*     */   }
/*     */ 
/*     */   FSDataset.FSVolume getVolume() {
/*  54 */     return this.volume;
/*     */   }
/*     */ 
/*     */   File getFile() {
/*  58 */     return this.file;
/*     */   }
/*     */ 
/*     */   boolean isDetached()
/*     */   {
/*  65 */     return this.detached;
/*     */   }
/*     */ 
/*     */   void setDetached()
/*     */   {
/*  72 */     this.detached = true;
/*     */   }
/*     */ 
/*     */   private void detachFile(File file, Block b)
/*     */     throws IOException
/*     */   {
/*  83 */     File tmpFile = this.volume.createDetachFile(b, file.getName());
/*     */     try {
/*  85 */       IOUtils.copyBytes(new FileInputStream(file), new FileOutputStream(tmpFile), 16384, true);
/*     */ 
/*  88 */       if (file.length() != tmpFile.length()) {
/*  89 */         throw new IOException("Copy of file " + file + " size " + file.length() + " into file " + tmpFile + " resulted in a size of " + tmpFile.length());
/*     */       }
/*     */ 
/*  93 */       FileUtil.replaceFile(tmpFile, file);
/*     */     } catch (IOException e) {
/*  95 */       boolean done = tmpFile.delete();
/*  96 */       if (!done) {
/*  97 */         DataNode.LOG.info("detachFile failed to delete temporary file " + tmpFile);
/*     */       }
/*     */ 
/* 100 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   boolean detachBlock(Block block, int numLinks)
/*     */     throws IOException
/*     */   {
/* 108 */     if (isDetached()) {
/* 109 */       return false;
/*     */     }
/* 111 */     if ((this.file == null) || (this.volume == null)) {
/* 112 */       throw new IOException("detachBlock: not found " + block);
/*     */     }
/* 114 */     File meta = FSDataset.getMetaFile(this.file, block);
/* 115 */     if (meta == null) {
/* 116 */       throw new IOException("Meta file not found for " + block);
/*     */     }
/*     */ 
/* 119 */     if (HardLink.getLinkCount(this.file) > numLinks) {
/* 120 */       DataNode.LOG.info("CopyOnWrite for " + block);
/* 121 */       detachFile(this.file, block);
/*     */     }
/* 123 */     if (HardLink.getLinkCount(meta) > numLinks) {
/* 124 */       detachFile(meta, block);
/*     */     }
/* 126 */     setDetached();
/* 127 */     return true;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 131 */     return getClass().getSimpleName() + "(volume=" + this.volume + ", file=" + this.file + ", detached=" + this.detached + ")";
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.DatanodeBlockInfo
 * JD-Core Version:    0.6.1
 */
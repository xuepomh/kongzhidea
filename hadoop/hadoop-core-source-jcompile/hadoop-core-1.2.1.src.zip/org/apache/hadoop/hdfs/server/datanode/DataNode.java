/*      */ package org.apache.hadoop.hdfs.server.datanode;
/*      */ 
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.net.InetAddress;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.ServerSocket;
/*      */ import java.net.Socket;
/*      */ import java.net.SocketException;
/*      */ import java.net.SocketTimeoutException;
/*      */ import java.net.UnknownHostException;
/*      */ import java.nio.channels.ClosedByInterruptException;
/*      */ import java.nio.channels.ServerSocketChannel;
/*      */ import java.nio.channels.SocketChannel;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.security.SecureRandom;
/*      */ import java.util.AbstractList;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.EnumSet;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import javax.management.ObjectName;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.apache.hadoop.conf.Configuration;
/*      */ import org.apache.hadoop.conf.Configured;
/*      */ import org.apache.hadoop.fs.FileSystem;
/*      */ import org.apache.hadoop.fs.LocalFileSystem;
/*      */ import org.apache.hadoop.fs.Path;
/*      */ import org.apache.hadoop.fs.permission.FsPermission;
/*      */ import org.apache.hadoop.hdfs.HDFSPolicyProvider;
/*      */ import org.apache.hadoop.hdfs.protocol.Block;
/*      */ import org.apache.hadoop.hdfs.protocol.BlockListAsLongs;
/*      */ import org.apache.hadoop.hdfs.protocol.BlockLocalPathInfo;
/*      */ import org.apache.hadoop.hdfs.protocol.ClientDatanodeProtocol;
/*      */ import org.apache.hadoop.hdfs.protocol.DatanodeID;
/*      */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*      */ import org.apache.hadoop.hdfs.protocol.FSConstants;
/*      */ import org.apache.hadoop.hdfs.protocol.LocatedBlock;
/*      */ import org.apache.hadoop.hdfs.protocol.UnregisteredDatanodeException;
/*      */ import org.apache.hadoop.hdfs.security.token.block.BlockTokenIdentifier;
/*      */ import org.apache.hadoop.hdfs.security.token.block.BlockTokenSecretManager;
/*      */ import org.apache.hadoop.hdfs.security.token.block.BlockTokenSecretManager.AccessMode;
/*      */ import org.apache.hadoop.hdfs.security.token.block.ExportedBlockKeys;
/*      */ import org.apache.hadoop.hdfs.server.common.HdfsConstants.StartupOption;
/*      */ import org.apache.hadoop.hdfs.server.common.IncorrectVersionException;
/*      */ import org.apache.hadoop.hdfs.server.datanode.metrics.DataNodeInstrumentation;
/*      */ import org.apache.hadoop.hdfs.server.datanode.web.resources.DatanodeWebHdfsMethods;
/*      */ import org.apache.hadoop.hdfs.server.namenode.FileChecksumServlets.GetServlet;
/*      */ import org.apache.hadoop.hdfs.server.namenode.NameNode;
/*      */ import org.apache.hadoop.hdfs.server.namenode.StreamFile;
/*      */ import org.apache.hadoop.hdfs.server.protocol.BalancerBandwidthCommand;
/*      */ import org.apache.hadoop.hdfs.server.protocol.BlockCommand;
/*      */ import org.apache.hadoop.hdfs.server.protocol.BlockMetaDataInfo;
/*      */ import org.apache.hadoop.hdfs.server.protocol.BlockRecoveryInfo;
/*      */ import org.apache.hadoop.hdfs.server.protocol.DatanodeCommand;
/*      */ import org.apache.hadoop.hdfs.server.protocol.DatanodeProtocol;
/*      */ import org.apache.hadoop.hdfs.server.protocol.DatanodeRegistration;
/*      */ import org.apache.hadoop.hdfs.server.protocol.DisallowedDatanodeException;
/*      */ import org.apache.hadoop.hdfs.server.protocol.InterDatanodeProtocol;
/*      */ import org.apache.hadoop.hdfs.server.protocol.KeyUpdateCommand;
/*      */ import org.apache.hadoop.hdfs.server.protocol.NamespaceInfo;
/*      */ import org.apache.hadoop.hdfs.server.protocol.UpgradeCommand;
/*      */ import org.apache.hadoop.hdfs.web.WebHdfsFileSystem;
/*      */ import org.apache.hadoop.hdfs.web.resources.Param;
/*      */ import org.apache.hadoop.http.HttpServer;
/*      */ import org.apache.hadoop.io.IOUtils;
/*      */ import org.apache.hadoop.io.ReadaheadPool;
/*      */ import org.apache.hadoop.io.Text;
/*      */ import org.apache.hadoop.ipc.RPC;
/*      */ import org.apache.hadoop.ipc.RemoteException;
/*      */ import org.apache.hadoop.ipc.Server;
/*      */ import org.apache.hadoop.metrics2.lib.DefaultMetricsSystem;
/*      */ import org.apache.hadoop.metrics2.util.MBeans;
/*      */ import org.apache.hadoop.net.DNS;
/*      */ import org.apache.hadoop.net.NetUtils;
/*      */ import org.apache.hadoop.security.AccessControlException;
/*      */ import org.apache.hadoop.security.SecurityUtil;
/*      */ import org.apache.hadoop.security.UserGroupInformation;
/*      */ import org.apache.hadoop.security.UserGroupInformation.AuthenticationMethod;
/*      */ import org.apache.hadoop.security.authorize.ServiceAuthorizationManager;
/*      */ import org.apache.hadoop.security.token.Token;
/*      */ import org.apache.hadoop.security.token.TokenIdentifier;
/*      */ import org.apache.hadoop.util.Daemon;
/*      */ import org.apache.hadoop.util.DiskChecker;
/*      */ import org.apache.hadoop.util.DiskChecker.DiskErrorException;
/*      */ import org.apache.hadoop.util.DiskChecker.DiskOutOfSpaceException;
/*      */ import org.apache.hadoop.util.ReflectionUtils;
/*      */ import org.apache.hadoop.util.ServicePlugin;
/*      */ import org.apache.hadoop.util.StringUtils;
/*      */ import org.apache.hadoop.util.VersionInfo;
/*      */ import org.mortbay.util.ajax.JSON;
/*      */ 
/*      */ public class DataNode extends Configured
/*      */   implements InterDatanodeProtocol, ClientDatanodeProtocol, FSConstants, Runnable, DataNodeMXBean
/*      */ {
/*      */   public static final Log LOG;
/*      */   public static final String DN_CLIENTTRACE_FORMAT = "src: %s, dest: %s, bytes: %s, op: %s, cliID: %s, offset: %s, srvID: %s, blockid: %s, duration: %s";
/*  188 */   static final Log ClientTraceLog = LogFactory.getLog(new StringBuilder().append(DataNode.class.getName()).append(".clienttrace").toString());
/*      */ 
/*  200 */   public DatanodeProtocol namenode = null;
/*  201 */   public FSDatasetInterface data = null;
/*  202 */   public DatanodeRegistration dnRegistration = null;
/*      */ 
/*  204 */   volatile boolean shouldRun = true;
/*  205 */   private LinkedList<Block> receivedBlockList = new LinkedList();
/*      */ 
/*  207 */   private final Map<Block, Block> ongoingRecovery = new HashMap();
/*  208 */   private LinkedList<String> delHints = new LinkedList();
/*      */   public static final String EMPTY_DEL_HINT = "";
/*  210 */   AtomicInteger xmitsInProgress = new AtomicInteger();
/*  211 */   Daemon dataXceiverServer = null;
/*  212 */   ThreadGroup threadGroup = null;
/*      */   long blockReportInterval;
/*  215 */   long lastBlockReport = 0L;
/*  216 */   boolean resetBlockReportTime = true;
/*  217 */   long initialBlockReportDelay = 0L;
/*  218 */   long lastHeartbeat = 0L;
/*      */   long heartBeatInterval;
/*  220 */   private DataStorage storage = null;
/*  221 */   private HttpServer infoServer = null;
/*      */   DataNodeInstrumentation myMetrics;
/*      */   private static InetSocketAddress nameNodeAddr;
/*      */   private InetSocketAddress selfAddr;
/*  225 */   private static DataNode datanodeObject = null;
/*  226 */   private Thread dataNodeThread = null;
/*      */   String machineName;
/*      */   private static String dnThreadName;
/*      */   int socketTimeout;
/*  230 */   int socketWriteTimeout = 0;
/*  231 */   boolean transferToAllowed = true;
/*  232 */   private boolean dropCacheBehindWrites = false;
/*  233 */   private boolean syncBehindWrites = false;
/*  234 */   private boolean dropCacheBehindReads = false;
/*  235 */   private long readaheadLength = 0L;
/*      */ 
/*  237 */   int writePacketSize = 0;
/*      */   private boolean durableSync;
/*      */   boolean isBlockTokenEnabled;
/*      */   BlockTokenSecretManager blockTokenSecretManager;
/*  241 */   boolean isBlockTokenInitialized = false;
/*      */   boolean syncOnClose;
/*      */   final String userWithLocalPathAccess;
/*      */   private boolean connectToDnViaHostname;
/*      */   private boolean relaxedVersionCheck;
/*      */   private boolean noVersionCheck;
/*  257 */   int artificialBlockReceivedDelay = 0;
/*      */ 
/*  259 */   public DataBlockScanner blockScanner = null;
/*  260 */   public Daemon blockScannerThread = null;
/*      */   private List<ServicePlugin> plugins;
/*  265 */   private static final Random R = new Random();
/*      */   public static final String DATA_DIR_KEY = "dfs.data.dir";
/*      */   public static final String DATA_DIR_PERMISSION_KEY = "dfs.datanode.data.dir.perm";
/*      */   private static final String DEFAULT_DATA_DIR_PERMISSION = "755";
/*      */   private static final long LATE_BLOCK_REPORT_WARN_THRESHOLD = 600000L;
/*      */   private static final long LATE_BLOCK_REPORT_INFO_THRESHOLD = 180000L;
/*      */   public Server ipcServer;
/*  284 */   private SecureDataNodeStarter.SecureResources secureResources = null;
/*      */   ReadaheadPool readaheadPool;
/*  572 */   private ObjectName mxBean = null;
/*      */ 
/* 1293 */   UpgradeManagerDatanode upgradeManager = new UpgradeManagerDatanode(this);
/*      */   public static final int PKT_HEADER_LEN = 21;
/*      */ 
/*      */   @Deprecated
/*      */   public static InetSocketAddress createSocketAddr(String target)
/*      */     throws IOException
/*      */   {
/*  197 */     return NetUtils.createSocketAddr(target);
/*      */   }
/*      */ 
/*      */   static long now()
/*      */   {
/*  293 */     return System.currentTimeMillis();
/*      */   }
/*      */ 
/*      */   DataNode(Configuration conf, AbstractList<File> dataDirs)
/*      */     throws IOException
/*      */   {
/*  302 */     this(conf, dataDirs, null);
/*      */   }
/*      */ 
/*      */   DataNode(Configuration conf, AbstractList<File> dataDirs, SecureDataNodeStarter.SecureResources resources)
/*      */     throws IOException
/*      */   {
/*  312 */     super(conf);
/*  313 */     SecurityUtil.login(conf, "dfs.datanode.keytab.file", "dfs.datanode.kerberos.principal");
/*      */ 
/*  316 */     datanodeObject = this;
/*  317 */     this.durableSync = conf.getBoolean("dfs.durable.sync", true);
/*  318 */     this.userWithLocalPathAccess = conf.get("dfs.block.local-path-access.user");
/*      */     try
/*      */     {
/*  321 */       startDataNode(conf, dataDirs, resources);
/*      */     } catch (IOException ie) {
/*  323 */       shutdown();
/*  324 */       throw ie;
/*      */     }
/*      */   }
/*      */ 
/*      */   void startDataNode(Configuration conf, AbstractList<File> dataDirs, SecureDataNodeStarter.SecureResources resources)
/*      */     throws IOException
/*      */   {
/*  345 */     if ((UserGroupInformation.isSecurityEnabled()) && (resources == null)) {
/*  346 */       throw new RuntimeException("Cannot start secure cluster without privileged resources.");
/*      */     }
/*      */ 
/*  349 */     this.secureResources = resources;
/*      */ 
/*  351 */     if (conf.get("slave.host.name") != null) {
/*  352 */       this.machineName = conf.get("slave.host.name");
/*      */     }
/*  354 */     if (this.machineName == null) {
/*  355 */       this.machineName = DNS.getDefaultHost(conf.get("dfs.datanode.dns.interface", "default"), conf.get("dfs.datanode.dns.nameserver", "default"));
/*      */     }
/*      */ 
/*  359 */     InetSocketAddress nameNodeAddr = NameNode.getServiceAddress(conf, true);
/*      */ 
/*  361 */     this.socketTimeout = conf.getInt("dfs.socket.timeout", 60000);
/*      */ 
/*  363 */     this.socketWriteTimeout = conf.getInt("dfs.datanode.socket.write.timeout", 480000);
/*      */ 
/*  367 */     this.transferToAllowed = conf.getBoolean("dfs.datanode.transferTo.allowed", true);
/*      */ 
/*  369 */     this.writePacketSize = conf.getInt("dfs.write.packet.size", 65536);
/*      */ 
/*  371 */     this.relaxedVersionCheck = conf.getBoolean("hadoop.relaxed.worker.version.check", false);
/*      */ 
/*  374 */     this.noVersionCheck = conf.getBoolean("hadoop.skip.worker.version.check", false);
/*      */ 
/*  378 */     InetSocketAddress socAddr = getStreamingAddr(conf);
/*  379 */     int tmpPort = socAddr.getPort();
/*  380 */     this.storage = new DataStorage();
/*      */ 
/*  382 */     this.dnRegistration = new DatanodeRegistration(new StringBuilder().append(this.machineName).append(":").append(tmpPort).toString());
/*      */ 
/*  385 */     this.namenode = ((DatanodeProtocol)RPC.waitForProxy(DatanodeProtocol.class, 26L, nameNodeAddr, conf));
/*      */ 
/*  391 */     NamespaceInfo nsInfo = handshake();
/*  392 */     HdfsConstants.StartupOption startOpt = getStartupOption(conf);
/*  393 */     assert (startOpt != null) : "Startup option must be set.";
/*      */ 
/*  395 */     boolean simulatedFSDataset = conf.getBoolean("dfs.datanode.simulateddatastorage", false);
/*      */ 
/*  397 */     if (simulatedFSDataset) {
/*  398 */       setNewStorageID(this.dnRegistration);
/*  399 */       this.dnRegistration.storageInfo.layoutVersion = -41;
/*  400 */       this.dnRegistration.storageInfo.namespaceID = nsInfo.namespaceID;
/*      */ 
/*  403 */       conf.set("StorageId", this.dnRegistration.getStorageID());
/*      */       try
/*      */       {
/*  407 */         this.data = ((FSDatasetInterface)ReflectionUtils.newInstance(Class.forName("org.apache.hadoop.hdfs.server.datanode.SimulatedFSDataset"), conf));
/*      */       }
/*      */       catch (ClassNotFoundException e) {
/*  410 */         throw new IOException(StringUtils.stringifyException(e));
/*      */       }
/*      */     }
/*      */     else {
/*  414 */       this.storage.recoverTransitionRead(nsInfo, dataDirs, startOpt);
/*      */ 
/*  416 */       this.dnRegistration.setStorageInfo(this.storage);
/*      */ 
/*  418 */       this.data = new FSDataset(this.storage, conf);
/*      */     }
/*      */ 
/*  422 */     registerMXBean(conf);
/*      */ 
/*  425 */     this.artificialBlockReceivedDelay = conf.getInt("dfs.datanode.artificialBlockReceivedDelay", 0);
/*      */     ServerSocket ss;
/*  430 */     if (this.secureResources == null) {
/*  431 */       ServerSocket ss = this.socketWriteTimeout > 0 ? ServerSocketChannel.open().socket() : new ServerSocket();
/*      */ 
/*  433 */       Server.bind(ss, socAddr, 0);
/*      */     } else {
/*  435 */       ss = resources.getStreamingSocket();
/*      */     }
/*  437 */     ss.setReceiveBufferSize(131072);
/*      */ 
/*  439 */     tmpPort = ss.getLocalPort();
/*  440 */     this.selfAddr = new InetSocketAddress(ss.getInetAddress().getHostAddress(), tmpPort);
/*      */ 
/*  442 */     this.dnRegistration.setName(new StringBuilder().append(this.machineName).append(":").append(tmpPort).toString());
/*  443 */     LOG.info(new StringBuilder().append("Opened data transfer server at ").append(tmpPort).toString());
/*      */ 
/*  445 */     this.threadGroup = new ThreadGroup("dataXceiverServer");
/*  446 */     this.dataXceiverServer = new Daemon(this.threadGroup, new DataXceiverServer(ss, conf, this));
/*      */ 
/*  448 */     this.threadGroup.setDaemon(true);
/*      */ 
/*  450 */     this.readaheadLength = conf.getLong("dfs.datanode.readahead.bytes", 4194304L);
/*      */ 
/*  453 */     this.dropCacheBehindWrites = conf.getBoolean("dfs.datanode.drop.cache.behind.writes", false);
/*      */ 
/*  456 */     this.syncBehindWrites = conf.getBoolean("dfs.datanode.sync.behind.writes", false);
/*      */ 
/*  459 */     this.dropCacheBehindReads = conf.getBoolean("dfs.datanode.drop.cache.behind.reads", false);
/*      */ 
/*  463 */     this.blockReportInterval = conf.getLong("dfs.blockreport.intervalMsec", 3600000L);
/*      */ 
/*  465 */     this.initialBlockReportDelay = (conf.getLong("dfs.blockreport.initialDelay", 0L) * 1000L);
/*      */ 
/*  467 */     if (this.initialBlockReportDelay >= this.blockReportInterval) {
/*  468 */       this.initialBlockReportDelay = 0L;
/*  469 */       LOG.info("dfs.blockreport.initialDelay is greater than dfs.blockreport.intervalMsec. Setting initial delay to 0 msec:");
/*      */     }
/*      */ 
/*  472 */     this.heartBeatInterval = (conf.getLong("dfs.heartbeat.interval", 3L) * 1000L);
/*      */ 
/*  475 */     this.syncOnClose = conf.getBoolean("dfs.datanode.synconclose", false);
/*      */ 
/*  478 */     nameNodeAddr = nameNodeAddr;
/*      */ 
/*  481 */     String reason = null;
/*  482 */     if (conf.getInt("dfs.datanode.scan.period.hours", 0) < 0)
/*  483 */       reason = "verification is turned off by configuration";
/*  484 */     else if (!(this.data instanceof FSDataset)) {
/*  485 */       reason = "verifcation is supported only with FSDataset";
/*      */     }
/*  487 */     if (reason == null)
/*  488 */       this.blockScanner = new DataBlockScanner(this, (FSDataset)this.data, conf);
/*      */     else {
/*  490 */       LOG.info(new StringBuilder().append("Periodic Block Verification is disabled because ").append(reason).toString());
/*      */     }
/*      */ 
/*  494 */     this.readaheadPool = ReadaheadPool.getInstance();
/*      */ 
/*  496 */     this.connectToDnViaHostname = conf.getBoolean("dfs.datanode.use.datanode.hostname", false);
/*      */ 
/*  499 */     LOG.debug(new StringBuilder().append("Connect to datanode via hostname is ").append(this.connectToDnViaHostname).toString());
/*      */ 
/*  502 */     InetSocketAddress infoSocAddr = getInfoAddr(conf);
/*  503 */     String infoHost = infoSocAddr.getHostName();
/*  504 */     int tmpInfoPort = infoSocAddr.getPort();
/*  505 */     if (tmpInfoPort == 0) tmpTernaryOp = 1; this.infoServer = (this.secureResources == null ? new HttpServer("datanode", infoHost, tmpInfoPort, false, conf, SecurityUtil.getAdminAcls(conf, "dfs.cluster.administrators")) : new HttpServer("datanode", infoHost, tmpInfoPort, tmpInfoPort == 0, conf, SecurityUtil.getAdminAcls(conf, "dfs.cluster.administrators"), this.secureResources.getListener()));
/*      */ 
/*  511 */     if (conf.getBoolean("dfs.https.enable", false)) {
/*  512 */       boolean needClientAuth = conf.getBoolean("dfs.https.need.client.auth", false);
/*  513 */       InetSocketAddress secInfoSocAddr = NetUtils.createSocketAddr(conf.get("dfs.datanode.https.address", new StringBuilder().append(infoHost).append(":").append(0).toString()));
/*      */ 
/*  515 */       Configuration sslConf = new Configuration(false);
/*  516 */       sslConf.addResource(conf.get("dfs.https.server.keystore.resource", "ssl-server.xml"));
/*      */ 
/*  518 */       this.infoServer.addSslListener(secInfoSocAddr, sslConf, needClientAuth);
/*      */     }
/*  520 */     this.infoServer.addInternalServlet(null, "/streamFile/*", StreamFile.class);
/*  521 */     this.infoServer.addInternalServlet(null, "/getFileChecksum/*", FileChecksumServlets.GetServlet.class);
/*      */ 
/*  524 */     this.infoServer.setAttribute("datanode", this);
/*  525 */     this.infoServer.setAttribute("datanode.blockScanner", this.blockScanner);
/*  526 */     this.infoServer.setAttribute("current.conf", conf);
/*  527 */     this.infoServer.addServlet(null, "/blockScannerReport", DataBlockScanner.Servlet.class);
/*      */ 
/*  530 */     if (WebHdfsFileSystem.isEnabled(conf, LOG)) {
/*  531 */       this.infoServer.addJerseyResourcePackage(new StringBuilder().append(DatanodeWebHdfsMethods.class.getPackage().getName()).append(";").append(Param.class.getPackage().getName()).toString(), "/webhdfs/v1/*");
/*      */     }
/*      */ 
/*  535 */     this.infoServer.start();
/*      */ 
/*  537 */     this.dnRegistration.setInfoPort(this.infoServer.getPort());
/*  538 */     this.myMetrics = DataNodeInstrumentation.create(conf, this.dnRegistration.getStorageID());
/*      */ 
/*  542 */     if (conf.getBoolean("hadoop.security.authorization", false))
/*      */     {
/*  544 */       ServiceAuthorizationManager.refresh(conf, new HDFSPolicyProvider());
/*      */     }
/*      */ 
/*  549 */     this.blockTokenSecretManager = new BlockTokenSecretManager(false, 0L, 0L);
/*      */ 
/*  552 */     InetSocketAddress ipcAddr = NetUtils.createSocketAddr(conf.get("dfs.datanode.ipc.address"));
/*      */ 
/*  554 */     this.ipcServer = RPC.getServer(this, ipcAddr.getHostName(), ipcAddr.getPort(), conf.getInt("dfs.datanode.handler.count", 3), false, conf, this.blockTokenSecretManager);
/*      */ 
/*  557 */     this.dnRegistration.setIpcPort(this.ipcServer.getListenerAddress().getPort());
/*      */ 
/*  559 */     LOG.info(new StringBuilder().append("dnRegistration = ").append(this.dnRegistration).toString());
/*      */ 
/*  561 */     this.plugins = conf.getInstances("dfs.datanode.plugins", ServicePlugin.class);
/*  562 */     for (ServicePlugin p : this.plugins)
/*      */       try {
/*  564 */         p.start(this);
/*  565 */         LOG.info(new StringBuilder().append("Started plug-in ").append(p).toString());
/*      */       } catch (Throwable t) {
/*  567 */         LOG.warn(new StringBuilder().append("ServicePlugin ").append(p).append(" could not be started").toString(), t);
/*      */       }
/*      */   }
/*      */ 
/*      */   void registerMXBean(Configuration conf)
/*      */   {
/*  581 */     this.mxBean = MBeans.register("DataNode", "DataNodeInfo", this);
/*      */   }
/*      */ 
/*      */   public void unRegisterMXBean() {
/*  585 */     if (this.mxBean != null)
/*  586 */       MBeans.unregister(this.mxBean);
/*      */   }
/*      */ 
/*      */   public static InetSocketAddress getInfoAddr(Configuration conf)
/*      */   {
/*  593 */     String infoAddr = NetUtils.getServerAddress(conf, "dfs.datanode.info.bindAddress", "dfs.datanode.info.port", "dfs.datanode.http.address");
/*      */ 
/*  598 */     return NetUtils.createSocketAddr(infoAddr);
/*      */   }
/*      */ 
/*      */   protected Socket newSocket()
/*      */     throws IOException
/*      */   {
/*  605 */     return this.socketWriteTimeout > 0 ? SocketChannel.open().socket() : new Socket();
/*      */   }
/*      */ 
/*      */   boolean isPermittedVersion(NamespaceInfo nsInfo)
/*      */   {
/*  614 */     boolean versionMatch = nsInfo.getVersion().equals(VersionInfo.getVersion());
/*      */ 
/*  616 */     boolean revisionMatch = nsInfo.getRevision().equals(VersionInfo.getRevision());
/*      */ 
/*  618 */     if ((revisionMatch) && (!versionMatch)) {
/*  619 */       throw new AssertionError(new StringBuilder().append("Invalid build. The revisions match but the NN version is ").append(nsInfo.getVersion()).append(" and the DN version is ").append(VersionInfo.getVersion()).toString());
/*      */     }
/*      */ 
/*  623 */     if (this.noVersionCheck) {
/*  624 */       LOG.info(new StringBuilder().append("Permitting datanode version '").append(VersionInfo.getVersion()).append("' and revision '").append(VersionInfo.getRevision()).append("' to connect to namenode version '").append(nsInfo.getVersion()).append("' and revision '").append(nsInfo.getRevision()).append("' because ").append("hadoop.skip.worker.version.check").append(" is enabled").toString());
/*      */ 
/*  630 */       return true;
/*      */     }
/*  632 */     if (this.relaxedVersionCheck) {
/*  633 */       if ((versionMatch) && (!revisionMatch)) {
/*  634 */         LOG.info(new StringBuilder().append("Permitting datanode revision ").append(VersionInfo.getRevision()).append(" to connect to namenode revision ").append(nsInfo.getRevision()).append(" because ").append("hadoop.relaxed.worker.version.check").append(" is enabled").toString());
/*      */       }
/*      */ 
/*  639 */       return versionMatch;
/*      */     }
/*  641 */     return revisionMatch;
/*      */   }
/*      */ 
/*      */   private NamespaceInfo handshake()
/*      */     throws IOException
/*      */   {
/*  647 */     NamespaceInfo nsInfo = new NamespaceInfo();
/*  648 */     while (this.shouldRun)
/*      */       try {
/*  650 */         nsInfo = this.namenode.versionRequest();
/*      */       }
/*      */       catch (SocketTimeoutException e) {
/*  653 */         LOG.info(new StringBuilder().append("Problem connecting to server: ").append(getNameNodeAddr()).toString());
/*      */         try {
/*  655 */           Thread.sleep(1000L);
/*      */         } catch (InterruptedException ie) {
/*      */         }
/*      */       }
/*  659 */     if (!isPermittedVersion(nsInfo)) {
/*  660 */       String errorMsg = new StringBuilder().append("Shutting down. Incompatible version or revision.DataNode version '").append(VersionInfo.getVersion()).append("' and revision '").append(VersionInfo.getRevision()).append("' and NameNode version '").append(nsInfo.getVersion()).append("' and revision '").append(nsInfo.getRevision()).append(" and ").append("hadoop.relaxed.worker.version.check").append(" is ").append(this.relaxedVersionCheck ? "enabled" : "not enabled").append(" and ").append("hadoop.skip.worker.version.check").append(" is ").append(this.noVersionCheck ? "enabled" : "not enabled").toString();
/*      */ 
/*  669 */       LOG.fatal(errorMsg);
/*  670 */       notifyNamenode(0, errorMsg);
/*  671 */       throw new IOException(errorMsg);
/*      */     }
/*      */ 
/*  674 */     assert (-41 == nsInfo.getLayoutVersion()) : new StringBuilder().append("Data-node and name-node layout versions must be the same.Expected: -41 actual ").append(nsInfo.getLayoutVersion()).toString();
/*      */ 
/*  676 */     return nsInfo;
/*      */   }
/*      */ 
/*      */   public static DataNode getDataNode()
/*      */   {
/*  683 */     return datanodeObject;
/*      */   }
/*      */ 
/*      */   public static InterDatanodeProtocol createInterDataNodeProtocolProxy(DatanodeInfo info, final Configuration conf, final int socketTimeout, boolean connectToDnViaHostname)
/*      */     throws IOException
/*      */   {
/*  689 */     String dnName = info.getNameWithIpcPort(connectToDnViaHostname);
/*  690 */     InetSocketAddress addr = NetUtils.createSocketAddr(dnName);
/*  691 */     if (DataNodeMXBean.LOG.isDebugEnabled()) {
/*  692 */       DataNodeMXBean.LOG.info(new StringBuilder().append("InterDatanodeProtocol addr=").append(addr).toString());
/*      */     }
/*      */ 
/*  695 */     UserGroupInformation loginUgi = UserGroupInformation.getLoginUser();
/*      */     try {
/*  697 */       return (DataNodeMXBean)loginUgi.doAs(new PrivilegedExceptionAction()
/*      */       {
/*      */         public InterDatanodeProtocol run() throws IOException {
/*  700 */           return (InterDatanodeProtocol)RPC.getProxy(InterDatanodeProtocol.class, 3L, this.val$addr, conf, socketTimeout);
/*      */         }
/*      */       });
/*      */     }
/*      */     catch (InterruptedException ie)
/*      */     {
/*  706 */       throw new IOException(ie.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public InetSocketAddress getNameNodeAddr() {
/*  711 */     return nameNodeAddr;
/*      */   }
/*      */ 
/*      */   public InetSocketAddress getSelfAddr() {
/*  715 */     return this.selfAddr;
/*      */   }
/*      */ 
/*      */   DataNodeInstrumentation getMetrics() {
/*  719 */     return this.myMetrics;
/*      */   }
/*      */ 
/*      */   public String getNamenode()
/*      */   {
/*  727 */     return "<namenode>";
/*      */   }
/*      */ 
/*      */   public static void setNewStorageID(DatanodeRegistration dnReg)
/*      */   {
/*  743 */     String ip = "unknownIP";
/*      */     try {
/*  745 */       ip = DNS.getDefaultIP("default");
/*      */     } catch (UnknownHostException ignored) {
/*  747 */       LOG.warn("Could not find ip address of \"default\" inteface.");
/*      */     }
/*      */ 
/*  750 */     int rand = 0;
/*      */     try {
/*  752 */       rand = SecureRandom.getInstance("SHA1PRNG").nextInt(2147483647);
/*      */     } catch (NoSuchAlgorithmException e) {
/*  754 */       LOG.warn("Could not use SecureRandom");
/*  755 */       rand = R.nextInt(2147483647);
/*      */     }
/*  757 */     dnReg.storageID = new StringBuilder().append("DS-").append(rand).append("-").append(ip).append("-").append(dnReg.getPort()).append("-").append(System.currentTimeMillis()).toString();
/*      */   }
/*      */ 
/*      */   private void register()
/*      */     throws IOException
/*      */   {
/*  772 */     if (this.dnRegistration.getStorageID().equals("")) {
/*  773 */       setNewStorageID(this.dnRegistration);
/*      */     }
/*  775 */     while (this.shouldRun) {
/*      */       try
/*      */       {
/*  778 */         this.dnRegistration.name = new StringBuilder().append(this.machineName).append(":").append(this.dnRegistration.getPort()).toString();
/*  779 */         this.dnRegistration = this.namenode.register(this.dnRegistration);
/*      */       }
/*      */       catch (SocketTimeoutException e) {
/*  782 */         LOG.info(new StringBuilder().append("Problem connecting to server: ").append(getNameNodeAddr()).toString());
/*      */         try {
/*  784 */           Thread.sleep(1000L);
/*      */         }
/*      */         catch (InterruptedException ie)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/*  791 */     assert ((("".equals(this.storage.getStorageID())) && (!"".equals(this.dnRegistration.getStorageID()))) || (this.storage.getStorageID().equals(this.dnRegistration.getStorageID()))) : "New storageID can be assigned only if data-node is not formatted";
/*  792 */     if (this.storage.getStorageID().equals("")) {
/*  793 */       this.storage.setStorageID(this.dnRegistration.getStorageID());
/*  794 */       this.storage.writeAll();
/*  795 */       LOG.info(new StringBuilder().append("New storage id ").append(this.dnRegistration.getStorageID()).append(" is assigned to data-node ").append(this.dnRegistration.getName()).toString());
/*      */     }
/*      */ 
/*  798 */     if (!this.storage.getStorageID().equals(this.dnRegistration.getStorageID())) {
/*  799 */       throw new IOException(new StringBuilder().append("Inconsistent storage IDs. Name-node returned ").append(this.dnRegistration.getStorageID()).append(". Expecting ").append(this.storage.getStorageID()).toString());
/*      */     }
/*      */ 
/*  804 */     if (!this.isBlockTokenInitialized)
/*      */     {
/*  806 */       ExportedBlockKeys keys = this.dnRegistration.exportedKeys;
/*  807 */       this.isBlockTokenEnabled = keys.isBlockTokenEnabled();
/*  808 */       if (this.isBlockTokenEnabled) {
/*  809 */         long blockKeyUpdateInterval = keys.getKeyUpdateInterval();
/*  810 */         long blockTokenLifetime = keys.getTokenLifetime();
/*  811 */         LOG.info(new StringBuilder().append("Block token params received from NN: keyUpdateInterval=").append(blockKeyUpdateInterval / 60000L).append(" min(s), tokenLifetime=").append(blockTokenLifetime / 60000L).append(" min(s)").toString());
/*      */ 
/*  814 */         this.blockTokenSecretManager.setTokenLifetime(blockTokenLifetime);
/*      */       }
/*  816 */       this.isBlockTokenInitialized = true;
/*      */     }
/*      */ 
/*  819 */     if (this.isBlockTokenEnabled) {
/*  820 */       this.blockTokenSecretManager.setKeys(this.dnRegistration.exportedKeys);
/*  821 */       this.dnRegistration.exportedKeys = ExportedBlockKeys.DUMMY_KEYS;
/*      */     }
/*      */ 
/*  824 */     if (this.durableSync) {
/*  825 */       Block[] bbwReport = this.data.getBlocksBeingWrittenReport();
/*  826 */       long[] blocksBeingWritten = BlockListAsLongs.convertToArrayLongs(bbwReport);
/*      */ 
/*  828 */       this.namenode.blocksBeingWrittenReport(this.dnRegistration, blocksBeingWritten);
/*      */     }
/*      */ 
/*  833 */     this.data.requestAsyncBlockReport();
/*  834 */     scheduleBlockReport(this.initialBlockReportDelay);
/*      */   }
/*      */ 
/*      */   public void shutdown()
/*      */   {
/*  844 */     if (this.plugins != null) {
/*  845 */       for (ServicePlugin p : this.plugins) {
/*      */         try {
/*  847 */           p.stop();
/*  848 */           LOG.info(new StringBuilder().append("Stopped plug-in ").append(p).toString());
/*      */         } catch (Throwable t) {
/*  850 */           LOG.warn(new StringBuilder().append("ServicePlugin ").append(p).append(" could not be stopped").toString(), t);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  855 */     unRegisterMXBean();
/*  856 */     if (this.infoServer != null) {
/*      */       try {
/*  858 */         this.infoServer.stop();
/*      */       } catch (Exception e) {
/*  860 */         LOG.warn("Exception shutting down DataNode", e);
/*      */       }
/*      */     }
/*  863 */     if (this.ipcServer != null) {
/*  864 */       this.ipcServer.stop();
/*      */     }
/*  866 */     this.shouldRun = false;
/*  867 */     if (this.dataXceiverServer != null) {
/*  868 */       ((DataXceiverServer)this.dataXceiverServer.getRunnable()).kill();
/*  869 */       this.dataXceiverServer.interrupt();
/*      */ 
/*  872 */       if (this.threadGroup != null)
/*      */         while (true) {
/*  874 */           this.threadGroup.interrupt();
/*  875 */           LOG.info(new StringBuilder().append("Waiting for threadgroup to exit, active threads is ").append(this.threadGroup.activeCount()).toString());
/*      */ 
/*  877 */           if (this.threadGroup.activeCount() == 0)
/*      */             break;
/*      */           try
/*      */           {
/*  881 */             Thread.sleep(1000L);
/*      */           }
/*      */           catch (InterruptedException e) {
/*      */           }
/*      */         }
/*      */       try {
/*  887 */         this.dataXceiverServer.join();
/*      */       }
/*      */       catch (InterruptedException ie) {
/*      */       }
/*      */     }
/*  892 */     RPC.stopProxy(this.namenode);
/*      */ 
/*  894 */     if (this.upgradeManager != null)
/*  895 */       this.upgradeManager.shutdownUpgrade();
/*  896 */     if (this.blockScannerThread != null) {
/*  897 */       this.blockScannerThread.interrupt();
/*      */       try {
/*  899 */         this.blockScannerThread.join(3600000L);
/*      */       } catch (InterruptedException ie) {
/*      */       }
/*      */     }
/*  903 */     if (this.storage != null)
/*      */       try {
/*  905 */         this.storage.unlockAll();
/*      */       }
/*      */       catch (IOException ie) {
/*      */       }
/*  909 */     if (this.dataNodeThread != null) {
/*  910 */       this.dataNodeThread.interrupt();
/*      */       try {
/*  912 */         this.dataNodeThread.join();
/*      */       } catch (InterruptedException ie) {
/*      */       }
/*      */     }
/*  916 */     if (this.data != null) {
/*  917 */       this.data.shutdown();
/*      */     }
/*  919 */     if (this.myMetrics != null)
/*  920 */       this.myMetrics.shutdown();
/*      */   }
/*      */ 
/*      */   protected void checkDiskError(Exception e)
/*      */     throws IOException
/*      */   {
/*  929 */     LOG.warn("checkDiskError: exception: ", e);
/*  930 */     if (((e instanceof SocketException)) || ((e instanceof SocketTimeoutException)) || ((e instanceof ClosedByInterruptException)) || (e.getMessage().startsWith("An established connection was aborted")) || (e.getMessage().startsWith("Broken pipe")) || (e.getMessage().startsWith("Connection reset")) || (e.getMessage().contains("java.nio.channels.SocketChannel")))
/*      */     {
/*  936 */       LOG.info("Not checking disk as checkDiskError was called on a network related exception");
/*      */ 
/*  938 */       return;
/*      */     }
/*      */ 
/*  941 */     if ((e.getMessage() != null) && (e.getMessage().startsWith("No space left on device")))
/*      */     {
/*  943 */       throw new DiskChecker.DiskOutOfSpaceException("No space left on device");
/*      */     }
/*  945 */     checkDiskError();
/*      */   }
/*      */ 
/*      */   protected void checkDiskError()
/*      */   {
/*      */     try
/*      */     {
/*  955 */       this.data.checkDataDir();
/*      */     } catch (DiskChecker.DiskErrorException de) {
/*  957 */       handleDiskError(de.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   private void notifyNamenode(int dpCode, String msg)
/*      */   {
/*      */     try {
/*  964 */       this.namenode.errorReport(this.dnRegistration, dpCode, msg);
/*      */     }
/*      */     catch (SocketTimeoutException e) {
/*  967 */       LOG.info(new StringBuilder().append("Problem connecting to server: ").append(getNameNodeAddr()).toString());
/*      */     } catch (IOException ignored) {
/*      */     }
/*      */   }
/*      */ 
/*      */   private void handleDiskError(String errMsgr) {
/*  973 */     boolean hasEnoughResource = this.data.hasEnoughResource();
/*  974 */     LOG.warn(new StringBuilder().append("DataNode.handleDiskError: Keep Running: ").append(hasEnoughResource).toString());
/*      */ 
/*  978 */     int dp_error = 1;
/*  979 */     if (!hasEnoughResource)
/*      */     {
/*  981 */       dp_error = 3;
/*      */     }
/*      */ 
/*  985 */     notifyNamenode(dp_error, errMsgr);
/*      */ 
/*  987 */     if (hasEnoughResource) {
/*  988 */       scheduleBlockReport(0L);
/*  989 */       return;
/*      */     }
/*      */ 
/*  992 */     LOG.warn(new StringBuilder().append("DataNode is shutting down.\n").append(errMsgr).toString());
/*  993 */     this.shouldRun = false;
/*      */   }
/*      */ 
/*      */   public int getXceiverCount()
/*      */   {
/*  999 */     return this.threadGroup == null ? 0 : this.threadGroup.activeCount();
/*      */   }
/*      */ 
/*      */   public void offerService()
/*      */     throws Exception
/*      */   {
/* 1007 */     LOG.info(new StringBuilder().append("using BLOCKREPORT_INTERVAL of ").append(this.blockReportInterval).append("msec").append(" Initial delay: ").append(this.initialBlockReportDelay).append("msec").toString());
/*      */ 
/* 1014 */     while (this.shouldRun)
/*      */       try {
/* 1016 */         long startTime = now();
/*      */ 
/* 1022 */         if (startTime - this.lastHeartbeat > this.heartBeatInterval)
/*      */         {
/* 1030 */           this.lastHeartbeat = startTime;
/* 1031 */           DatanodeCommand[] cmds = this.namenode.sendHeartbeat(this.dnRegistration, this.data.getCapacity(), this.data.getDfsUsed(), this.data.getRemaining(), this.xmitsInProgress.get(), getXceiverCount());
/*      */ 
/* 1037 */           this.myMetrics.addHeartBeat(now() - startTime);
/* 1038 */           if (!processCommand(cmds));
/*      */         }
/*      */         else
/*      */         {
/* 1043 */           Block[] blockArray = null;
/* 1044 */           String[] delHintArray = null;
/* 1045 */           synchronized (this.receivedBlockList) {
/* 1046 */             synchronized (this.delHints) {
/* 1047 */               int numBlocks = this.receivedBlockList.size();
/* 1048 */               if (numBlocks > 0) {
/* 1049 */                 if (numBlocks != this.delHints.size()) {
/* 1050 */                   LOG.warn("Panic: receiveBlockList and delHints are not of the same length");
/*      */                 }
/*      */ 
/* 1055 */                 blockArray = (Block[])this.receivedBlockList.toArray(new Block[numBlocks]);
/* 1056 */                 delHintArray = (String[])this.delHints.toArray(new String[numBlocks]);
/*      */               }
/*      */             }
/*      */           }
/* 1060 */           if (blockArray != null) {
/* 1061 */             if ((delHintArray == null) || (delHintArray.length != blockArray.length)) {
/* 1062 */               LOG.warn("Panic: block array & delHintArray are not the same");
/*      */             }
/* 1064 */             this.namenode.blockReceived(this.dnRegistration, blockArray, delHintArray);
/* 1065 */             synchronized (this.receivedBlockList) {
/* 1066 */               synchronized (this.delHints) {
/* 1067 */                 for (int i = 0; i < blockArray.length; i++) {
/* 1068 */                   this.receivedBlockList.remove(blockArray[i]);
/* 1069 */                   this.delHints.remove(delHintArray[i]);
/*      */                 }
/*      */               }
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/* 1076 */           if (startTime - this.lastBlockReport > this.blockReportInterval) {
/* 1077 */             if (this.data.isAsyncBlockReportReady())
/*      */             {
/* 1079 */               long brCreateStartTime = now();
/* 1080 */               Block[] bReport = this.data.retrieveAsyncBlockReport();
/*      */ 
/* 1083 */               long brSendStartTime = now();
/* 1084 */               DatanodeCommand cmd = this.namenode.blockReport(this.dnRegistration, BlockListAsLongs.convertToArrayLongs(bReport));
/*      */ 
/* 1088 */               long brSendCost = now() - brSendStartTime;
/* 1089 */               long brCreateCost = brSendStartTime - brCreateStartTime;
/* 1090 */               this.myMetrics.addBlockReport(brSendCost);
/* 1091 */               LOG.info(new StringBuilder().append("BlockReport of ").append(bReport.length).append(" blocks took ").append(brCreateCost).append(" msec to generate and ").append(brSendCost).append(" msecs for RPC and NN processing").toString());
/*      */ 
/* 1099 */               if (this.resetBlockReportTime) {
/* 1100 */                 this.lastBlockReport = (startTime - R.nextInt((int)this.blockReportInterval));
/*      */ 
/* 1102 */                 this.resetBlockReportTime = false;
/*      */               }
/*      */               else
/*      */               {
/* 1111 */                 this.lastBlockReport += (now() - this.lastBlockReport) / this.blockReportInterval * this.blockReportInterval;
/*      */               }
/*      */ 
/* 1114 */               processCommand(cmd);
/*      */             } else {
/* 1116 */               this.data.requestAsyncBlockReport();
/* 1117 */               if (this.lastBlockReport > 0L) {
/* 1118 */                 long waitingFor = startTime - this.lastBlockReport - this.blockReportInterval;
/*      */ 
/* 1120 */                 String msg = new StringBuilder().append("Block report is due, and been waiting for it for ").append(waitingFor / 1000L).append(" seconds...").toString();
/*      */ 
/* 1122 */                 if (waitingFor > 600000L)
/* 1123 */                   LOG.warn(msg);
/* 1124 */                 else if (waitingFor > 180000L)
/* 1125 */                   LOG.info(msg);
/* 1126 */                 else if (LOG.isDebugEnabled()) {
/* 1127 */                   LOG.debug(msg);
/*      */                 }
/*      */               }
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/* 1134 */           if ((this.blockScanner != null) && (this.blockScannerThread == null) && (this.upgradeManager.isUpgradeCompleted()))
/*      */           {
/* 1136 */             LOG.info("Starting Periodic block scanner");
/* 1137 */             this.blockScannerThread = new Daemon(this.blockScanner);
/* 1138 */             this.blockScannerThread.start();
/*      */           }
/*      */ 
/* 1145 */           long waitTime = this.heartBeatInterval - (System.currentTimeMillis() - this.lastHeartbeat);
/* 1146 */           synchronized (this.receivedBlockList) {
/* 1147 */             if ((waitTime > 0L) && (this.receivedBlockList.size() == 0)) {
/*      */               try {
/* 1149 */                 this.receivedBlockList.wait(waitTime);
/*      */               } catch (InterruptedException ie) {
/*      */               }
/* 1152 */               delayBeforeBlockReceived();
/*      */             }
/*      */           }
/*      */         }
/*      */       } catch (RemoteException re) { String reClass = re.getClassName();
/* 1157 */         if ((UnregisteredDatanodeException.class.getName().equals(reClass)) || (DisallowedDatanodeException.class.getName().equals(reClass)) || (IncorrectVersionException.class.getName().equals(reClass)))
/*      */         {
/* 1160 */           LOG.warn(new StringBuilder().append("DataNode is shutting down: ").append(StringUtils.stringifyException(re)).toString());
/*      */ 
/* 1162 */           shutdown();
/* 1163 */           return;
/*      */         }
/* 1165 */         LOG.warn(StringUtils.stringifyException(re));
/*      */       } catch (IOException e) {
/* 1167 */         LOG.warn(StringUtils.stringifyException(e));
/*      */       }
/*      */   }
/*      */ 
/*      */   private void delayBeforeBlockReceived()
/*      */   {
/* 1179 */     if ((this.artificialBlockReceivedDelay > 0) && (!this.receivedBlockList.isEmpty()))
/*      */       try {
/* 1181 */         long sleepFor = R.nextInt(this.artificialBlockReceivedDelay);
/* 1182 */         LOG.debug(new StringBuilder().append("DataNode ").append(this.dnRegistration).append(" sleeping for ").append("artificial delay: ").append(sleepFor).append(" ms").toString());
/*      */ 
/* 1184 */         Thread.sleep(sleepFor);
/*      */       } catch (InterruptedException ie) {
/* 1186 */         Thread.currentThread().interrupt();
/*      */       }
/*      */   }
/*      */ 
/*      */   private boolean processCommand(DatanodeCommand[] cmds)
/*      */   {
/* 1198 */     if (cmds != null) {
/* 1199 */       for (DatanodeCommand cmd : cmds) {
/*      */         try {
/* 1201 */           if (!processCommand(cmd))
/* 1202 */             return false;
/*      */         }
/*      */         catch (IOException ioe) {
/* 1205 */           LOG.warn("Error processing datanode Command", ioe);
/*      */         }
/*      */       }
/*      */     }
/* 1209 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean processCommand(DatanodeCommand cmd)
/*      */     throws IOException
/*      */   {
/* 1219 */     if (cmd == null)
/* 1220 */       return true;
/* 1221 */     BlockCommand bcmd = (cmd instanceof BlockCommand) ? (BlockCommand)cmd : null;
/*      */ 
/* 1223 */     switch (cmd.getAction())
/*      */     {
/*      */     case 1:
/* 1226 */       transferBlocks(bcmd.getBlocks(), bcmd.getTargets());
/* 1227 */       this.myMetrics.incrBlocksReplicated(bcmd.getBlocks().length);
/* 1228 */       break;
/*      */     case 2:
/* 1234 */       Block[] toDelete = bcmd.getBlocks();
/*      */       try {
/* 1236 */         if (this.blockScanner != null) {
/* 1237 */           this.blockScanner.deleteBlocks(toDelete);
/*      */         }
/* 1239 */         this.data.invalidate(toDelete);
/*      */       }
/*      */       catch (IOException e) {
/* 1242 */         throw e;
/*      */       }
/* 1244 */       this.myMetrics.incrBlocksRemoved(toDelete.length);
/* 1245 */       break;
/*      */     case 3:
/* 1248 */       shutdown();
/* 1249 */       return false;
/*      */     case 4:
/* 1252 */       LOG.info("DatanodeCommand action: DNA_REGISTER");
/* 1253 */       if (this.shouldRun)
/* 1254 */         register(); break;
/*      */     case 5:
/* 1258 */       this.storage.finalizeUpgrade();
/* 1259 */       break;
/*      */     case 101:
/* 1262 */       processDistributedUpgradeCommand((UpgradeCommand)cmd);
/* 1263 */       break;
/*      */     case 6:
/* 1265 */       recoverBlocks(bcmd.getBlocks(), bcmd.getTargets());
/* 1266 */       break;
/*      */     case 7:
/* 1268 */       LOG.info("DatanodeCommand action: DNA_ACCESSKEYUPDATE");
/* 1269 */       if (this.isBlockTokenEnabled)
/* 1270 */         this.blockTokenSecretManager.setKeys(((KeyUpdateCommand)cmd).getExportedKeys()); break;
/*      */     case 8:
/* 1274 */       LOG.info("DatanodeCommand action: DNA_BALANCERBANDWIDTHUPDATE");
/* 1275 */       int vsn = ((BalancerBandwidthCommand)cmd).getBalancerBandwidthVersion();
/* 1276 */       if (vsn >= 1) {
/* 1277 */         long bandwidth = ((BalancerBandwidthCommand)cmd).getBalancerBandwidthValue();
/*      */ 
/* 1279 */         if (bandwidth > 0L) {
/* 1280 */           DataXceiverServer dxcs = (DataXceiverServer)this.dataXceiverServer.getRunnable();
/*      */ 
/* 1282 */           dxcs.balanceThrottler.setBandwidth(bandwidth);
/*      */         }
/*      */       }
/* 1284 */       break;
/*      */     default:
/* 1287 */       LOG.warn(new StringBuilder().append("Unknown DatanodeCommand action: ").append(cmd.getAction()).toString());
/*      */     }
/* 1289 */     return true;
/*      */   }
/*      */ 
/*      */   private void processDistributedUpgradeCommand(UpgradeCommand comm)
/*      */     throws IOException
/*      */   {
/* 1297 */     assert (this.upgradeManager != null) : "DataNode.upgradeManager is null.";
/* 1298 */     this.upgradeManager.processUpgradeCommand(comm);
/*      */   }
/*      */ 
/*      */   private void startDistributedUpgradeIfNeeded()
/*      */     throws IOException
/*      */   {
/* 1306 */     UpgradeManagerDatanode um = getDataNode().upgradeManager;
/* 1307 */     assert (um != null) : "DataNode.upgradeManager is null.";
/* 1308 */     if (!um.getUpgradeState())
/* 1309 */       return;
/* 1310 */     um.setUpgradeState(false, um.getUpgradeVersion());
/* 1311 */     um.startUpgrade();
/*      */   }
/*      */ 
/*      */   private void transferBlock(Block block, DatanodeInfo[] xferTargets)
/*      */     throws IOException
/*      */   {
/* 1318 */     if (!this.data.isValidBlock(block))
/*      */     {
/* 1320 */       String errStr = new StringBuilder().append("Can't send invalid ").append(block).toString();
/* 1321 */       LOG.info(errStr);
/* 1322 */       notifyNamenode(2, errStr);
/* 1323 */       return;
/*      */     }
/*      */ 
/* 1327 */     long onDiskLength = this.data.getLength(block);
/* 1328 */     if (block.getNumBytes() > onDiskLength)
/*      */     {
/* 1330 */       this.namenode.reportBadBlocks(new LocatedBlock[] { new LocatedBlock(block, new DatanodeInfo[] { new DatanodeInfo(this.dnRegistration) }) });
/*      */ 
/* 1333 */       LOG.info(new StringBuilder().append("Can't replicate ").append(block).append(" because on-disk length ").append(onDiskLength).append(" is shorter than NameNode recorded length ").append(block.getNumBytes()).toString());
/*      */ 
/* 1336 */       return;
/*      */     }
/*      */ 
/* 1339 */     int numTargets = xferTargets.length;
/* 1340 */     if (numTargets > 0) {
/* 1341 */       if (LOG.isInfoEnabled()) {
/* 1342 */         StringBuilder xfersBuilder = new StringBuilder();
/* 1343 */         for (int i = 0; i < numTargets; i++) {
/* 1344 */           xfersBuilder.append(xferTargets[i].getName());
/* 1345 */           xfersBuilder.append(" ");
/*      */         }
/* 1347 */         LOG.info(new StringBuilder().append(this.dnRegistration).append(" Starting thread to transfer ").append(block).append(" to ").append(xfersBuilder).toString());
/*      */       }
/*      */ 
/* 1351 */       new Daemon(new DataTransfer(xferTargets, block, this)).start();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void transferBlocks(Block[] blocks, DatanodeInfo[][] xferTargets)
/*      */   {
/* 1358 */     for (int i = 0; i < blocks.length; i++)
/*      */       try {
/* 1360 */         transferBlock(blocks[i], xferTargets[i]);
/*      */       } catch (IOException ie) {
/* 1362 */         LOG.warn(new StringBuilder().append("Failed to transfer ").append(blocks[i]).toString(), ie);
/*      */       }
/*      */   }
/*      */ 
/*      */   protected void notifyNamenodeReceivedBlock(Block block, String delHint)
/*      */   {
/* 1373 */     if ((block == null) || (delHint == null)) {
/* 1374 */       throw new IllegalArgumentException(block == null ? "Block is null" : "delHint is null");
/*      */     }
/* 1376 */     synchronized (this.receivedBlockList) {
/* 1377 */       synchronized (this.delHints) {
/* 1378 */         this.receivedBlockList.add(block);
/* 1379 */         this.delHints.add(delHint);
/* 1380 */         this.receivedBlockList.notifyAll();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void run()
/*      */   {
/* 1579 */     LOG.info(new StringBuilder().append(this.dnRegistration).append("In DataNode.run, data = ").append(this.data).toString());
/*      */ 
/* 1582 */     this.dataXceiverServer.start();
/* 1583 */     this.ipcServer.start();
/*      */ 
/* 1585 */     while (this.shouldRun) {
/*      */       try {
/* 1587 */         startDistributedUpgradeIfNeeded();
/* 1588 */         offerService();
/*      */       } catch (Exception ex) {
/* 1590 */         LOG.error(new StringBuilder().append("Exception: ").append(StringUtils.stringifyException(ex)).toString());
/* 1591 */         if (this.shouldRun)
/*      */           try {
/* 1593 */             Thread.sleep(5000L);
/*      */           }
/*      */           catch (InterruptedException ie)
/*      */           {
/*      */           }
/*      */       }
/*      */     }
/* 1600 */     LOG.info(new StringBuilder().append(this.dnRegistration).append(":Finishing DataNode in: ").append(this.data).toString());
/* 1601 */     shutdown();
/*      */   }
/*      */ 
/*      */   public static void runDatanodeDaemon(DataNode dn)
/*      */     throws IOException
/*      */   {
/* 1608 */     if (dn != null)
/*      */     {
/* 1610 */       dn.register();
/* 1611 */       dn.dataNodeThread = new Thread(dn, dnThreadName);
/* 1612 */       dn.dataNodeThread.setDaemon(true);
/* 1613 */       dn.dataNodeThread.start();
/*      */     }
/*      */   }
/*      */ 
/*      */   static boolean isDatanodeUp(DataNode dn) {
/* 1618 */     return (dn.dataNodeThread != null) && (dn.dataNodeThread.isAlive());
/*      */   }
/*      */ 
/*      */   public static DataNode instantiateDataNode(String[] args, Configuration conf)
/*      */     throws IOException
/*      */   {
/* 1626 */     return instantiateDataNode(args, conf, null);
/*      */   }
/*      */ 
/*      */   public static DataNode instantiateDataNode(String[] args, Configuration conf, SecureDataNodeStarter.SecureResources resources)
/*      */     throws IOException
/*      */   {
/* 1636 */     if (conf == null)
/* 1637 */       conf = new Configuration();
/* 1638 */     if (!parseArguments(args, conf)) {
/* 1639 */       printUsage();
/* 1640 */       System.exit(-2);
/*      */     }
/* 1642 */     if (conf.get("dfs.network.script") != null) {
/* 1643 */       LOG.error("This configuration for rack identification is not supported anymore. RackID resolution is handled by the NameNode.");
/*      */ 
/* 1645 */       System.exit(-1);
/*      */     }
/* 1647 */     String[] dataDirs = conf.getStrings("dfs.data.dir");
/* 1648 */     dnThreadName = new StringBuilder().append("DataNode: [").append(StringUtils.arrayToString(dataDirs)).append("]").toString();
/*      */ 
/* 1650 */     DefaultMetricsSystem.initialize("DataNode");
/* 1651 */     return makeInstance(dataDirs, conf, resources);
/*      */   }
/*      */ 
/*      */   public static DataNode createDataNode(String[] args, Configuration conf)
/*      */     throws IOException
/*      */   {
/* 1659 */     return createDataNode(args, conf, null);
/*      */   }
/*      */ 
/*      */   public static DataNode createDataNode(String[] args, Configuration conf, SecureDataNodeStarter.SecureResources resources)
/*      */     throws IOException
/*      */   {
/* 1669 */     DataNode dn = instantiateDataNode(args, conf, resources);
/* 1670 */     runDatanodeDaemon(dn);
/* 1671 */     return dn;
/*      */   }
/*      */ 
/*      */   void join() {
/* 1675 */     if (this.dataNodeThread != null)
/*      */       try {
/* 1677 */         this.dataNodeThread.join();
/*      */       }
/*      */       catch (InterruptedException e)
/*      */       {
/*      */       }
/*      */   }
/*      */ 
/*      */   public static DataNode makeInstance(String[] dataDirs, Configuration conf, SecureDataNodeStarter.SecureResources resources)
/*      */     throws IOException
/*      */   {
/* 1696 */     UserGroupInformation.setConfiguration(conf);
/* 1697 */     LocalFileSystem localFS = FileSystem.getLocal(conf);
/* 1698 */     ArrayList dirs = new ArrayList();
/* 1699 */     FsPermission dataDirPermission = new FsPermission(conf.get("dfs.datanode.data.dir.perm", "755"));
/*      */ 
/* 1702 */     for (String dir : dataDirs) {
/*      */       try {
/* 1704 */         DiskChecker.checkDir(localFS, new Path(dir), dataDirPermission);
/* 1705 */         dirs.add(new File(dir));
/*      */       } catch (IOException e) {
/* 1707 */         LOG.warn(new StringBuilder().append("Invalid directory in dfs.data.dir: ").append(e.getMessage()).toString());
/*      */       }
/*      */     }
/*      */ 
/* 1711 */     if (dirs.size() > 0)
/* 1712 */       return new DataNode(conf, dirs, resources);
/* 1713 */     LOG.error("All directories in dfs.data.dir are invalid.");
/* 1714 */     return null;
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1719 */     return new StringBuilder().append("DataNode{data=").append(this.data).append(", localName='").append(this.dnRegistration.getName()).append("'").append(", storageID='").append(this.dnRegistration.getStorageID()).append("'").append(", xmitsInProgress=").append(this.xmitsInProgress.get()).append("}").toString();
/*      */   }
/*      */ 
/*      */   private static void printUsage()
/*      */   {
/* 1728 */     System.err.println("Usage: java DataNode");
/* 1729 */     System.err.println("           [-rollback]");
/*      */   }
/*      */ 
/*      */   private static boolean parseArguments(String[] args, Configuration conf)
/*      */   {
/* 1739 */     int argsLen = args == null ? 0 : args.length;
/* 1740 */     HdfsConstants.StartupOption startOpt = HdfsConstants.StartupOption.REGULAR;
/* 1741 */     for (int i = 0; i < argsLen; i++) {
/* 1742 */       String cmd = args[i];
/* 1743 */       if (("-r".equalsIgnoreCase(cmd)) || ("--rack".equalsIgnoreCase(cmd))) {
/* 1744 */         LOG.error("-r, --rack arguments are not supported anymore. RackID resolution is handled by the NameNode.");
/*      */ 
/* 1746 */         System.exit(-1);
/* 1747 */       } else if ("-rollback".equalsIgnoreCase(cmd)) {
/* 1748 */         startOpt = HdfsConstants.StartupOption.ROLLBACK;
/* 1749 */       } else if ("-regular".equalsIgnoreCase(cmd)) {
/* 1750 */         startOpt = HdfsConstants.StartupOption.REGULAR;
/*      */       } else {
/* 1752 */         return false;
/*      */       }
/*      */     }
/* 1754 */     setStartupOption(conf, startOpt);
/* 1755 */     return true;
/*      */   }
/*      */ 
/*      */   private static void setStartupOption(Configuration conf, HdfsConstants.StartupOption opt) {
/* 1759 */     conf.set("dfs.datanode.startup", opt.toString());
/*      */   }
/*      */ 
/*      */   static HdfsConstants.StartupOption getStartupOption(Configuration conf) {
/* 1763 */     return HdfsConstants.StartupOption.valueOf(conf.get("dfs.datanode.startup", HdfsConstants.StartupOption.REGULAR.toString()));
/*      */   }
/*      */ 
/*      */   public void scheduleBlockReport(long delay)
/*      */   {
/* 1771 */     if (delay > 0L) {
/* 1772 */       this.lastBlockReport = (System.currentTimeMillis() - (this.blockReportInterval - R.nextInt((int)delay)));
/*      */     }
/*      */     else {
/* 1775 */       this.lastBlockReport = (this.lastHeartbeat - this.blockReportInterval);
/*      */     }
/* 1777 */     this.resetBlockReportTime = true;
/*      */   }
/*      */ 
/*      */   public FSDatasetInterface getFSDataset()
/*      */   {
/* 1789 */     return this.data;
/*      */   }
/*      */ 
/*      */   public static void secureMain(String[] args, SecureDataNodeStarter.SecureResources resources) {
/*      */     try {
/* 1794 */       StringUtils.startupShutdownMessage(DataNode.class, args, LOG);
/* 1795 */       DataNode datanode = createDataNode(args, null, resources);
/* 1796 */       if (datanode != null)
/* 1797 */         datanode.join();
/*      */     } catch (Throwable e) {
/* 1799 */       LOG.error(StringUtils.stringifyException(e));
/* 1800 */       System.exit(-1);
/*      */     }
/*      */     finally
/*      */     {
/* 1806 */       LOG.info("Exiting Datanode");
/* 1807 */       System.exit(0);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void main(String[] args) {
/* 1812 */     secureMain(args, null);
/*      */   }
/*      */ 
/*      */   public BlockMetaDataInfo getBlockMetaDataInfo(Block block)
/*      */     throws IOException
/*      */   {
/* 1819 */     if (LOG.isDebugEnabled()) {
/* 1820 */       LOG.debug(new StringBuilder().append("block=").append(block).toString());
/*      */     }
/*      */ 
/* 1823 */     Block stored = this.data.getStoredBlock(block.getBlockId());
/*      */ 
/* 1825 */     if (stored == null) {
/* 1826 */       return null;
/*      */     }
/* 1828 */     BlockMetaDataInfo info = new BlockMetaDataInfo(stored, this.blockScanner.getLastScanTime(stored));
/*      */ 
/* 1830 */     if (LOG.isDebugEnabled()) {
/* 1831 */       LOG.debug(new StringBuilder().append("getBlockMetaDataInfo successful block=").append(stored).append(" length ").append(stored.getNumBytes()).append(" genstamp ").append(stored.getGenerationStamp()).toString());
/*      */     }
/*      */ 
/* 1838 */     this.data.validateBlockMetadata(stored);
/* 1839 */     return info;
/*      */   }
/*      */ 
/*      */   public BlockRecoveryInfo startBlockRecovery(Block block) throws IOException
/*      */   {
/* 1844 */     return this.data.startBlockRecovery(block.getBlockId());
/*      */   }
/*      */ 
/*      */   public Daemon recoverBlocks(final Block[] blocks, final DatanodeInfo[][] targets) {
/* 1848 */     Daemon d = new Daemon(this.threadGroup, new Runnable()
/*      */     {
/*      */       public void run() {
/* 1851 */         for (int i = 0; i < blocks.length; i++)
/*      */           try {
/* 1853 */             DataNode.logRecoverBlock("NameNode", blocks[i], targets[i]);
/* 1854 */             DataNode.this.recoverBlock(blocks[i], false, targets[i], true);
/*      */           } catch (IOException e) {
/* 1856 */             DataNode.LOG.warn("recoverBlocks FAILED, blocks[" + i + "]=" + blocks[i], e);
/*      */           }
/*      */       }
/*      */     });
/* 1861 */     d.start();
/* 1862 */     return d;
/*      */   }
/*      */ 
/*      */   public void updateBlock(Block oldblock, Block newblock, boolean finalize) throws IOException
/*      */   {
/* 1867 */     LOG.info(new StringBuilder().append("oldblock=").append(oldblock).append("(length=").append(oldblock.getNumBytes()).append("), newblock=").append(newblock).append("(length=").append(newblock.getNumBytes()).append("), datanode=").append(this.dnRegistration.getName()).toString());
/*      */ 
/* 1870 */     this.data.updateBlock(oldblock, newblock);
/* 1871 */     if (finalize) {
/* 1872 */       this.data.finalizeBlockIfNeeded(newblock);
/* 1873 */       this.myMetrics.incrBlocksWritten();
/* 1874 */       notifyNamenodeReceivedBlock(newblock, "");
/* 1875 */       LOG.info(new StringBuilder().append("Received ").append(newblock).append(" of size ").append(newblock.getNumBytes()).append(" as part of lease recovery").toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   public long getProtocolVersion(String protocol, long clientVersion)
/*      */     throws IOException
/*      */   {
/* 1884 */     if (protocol.equals(DataNodeMXBean.class.getName()))
/* 1885 */       return 3L;
/* 1886 */     if (protocol.equals(ClientDatanodeProtocol.class.getName())) {
/* 1887 */       return 4L;
/*      */     }
/* 1889 */     throw new IOException(new StringBuilder().append("Unknown protocol to ").append(getClass().getSimpleName()).append(": ").append(protocol).toString());
/*      */   }
/*      */ 
/*      */   private void checkKerberosAuthMethod(String msg)
/*      */     throws IOException
/*      */   {
/* 1896 */     if (!UserGroupInformation.isSecurityEnabled()) {
/* 1897 */       return;
/*      */     }
/* 1899 */     if (UserGroupInformation.getCurrentUser().getAuthenticationMethod() != UserGroupInformation.AuthenticationMethod.KERBEROS)
/*      */     {
/* 1901 */       throw new AccessControlException(new StringBuilder().append("Error in ").append(msg).append(". Only ").append("kerberos based authentication is allowed.").toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   private void checkBlockLocalPathAccess() throws IOException
/*      */   {
/* 1907 */     checkKerberosAuthMethod("getBlockLocalPathInfo()");
/* 1908 */     String currentUser = UserGroupInformation.getCurrentUser().getShortUserName();
/* 1909 */     if (!currentUser.equals(this.userWithLocalPathAccess))
/* 1910 */       throw new AccessControlException(new StringBuilder().append("Can't continue with getBlockLocalPathInfo() authorization. The user ").append(currentUser).append(" is not allowed to call getBlockLocalPathInfo").toString());
/*      */   }
/*      */ 
/*      */   public BlockLocalPathInfo getBlockLocalPathInfo(Block block, Token<BlockTokenIdentifier> token)
/*      */     throws IOException
/*      */   {
/* 1920 */     checkBlockLocalPathAccess();
/* 1921 */     checkBlockToken(block, token, BlockTokenSecretManager.AccessMode.READ);
/* 1922 */     BlockLocalPathInfo info = this.data.getBlockLocalPathInfo(block);
/* 1923 */     if (LOG.isDebugEnabled()) {
/* 1924 */       if (info != null) {
/* 1925 */         if (LOG.isTraceEnabled()) {
/* 1926 */           LOG.trace(new StringBuilder().append("getBlockLocalPathInfo successful block=").append(block).append(" blockfile ").append(info.getBlockPath()).append(" metafile ").append(info.getMetaPath()).toString());
/*      */         }
/*      */ 
/*      */       }
/* 1931 */       else if (LOG.isTraceEnabled()) {
/* 1932 */         LOG.trace(new StringBuilder().append("getBlockLocalPathInfo for block=").append(block).append(" returning null").toString());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1937 */     this.myMetrics.incrBlocksGetLocalPathInfo();
/* 1938 */     return info;
/*      */   }
/*      */ 
/*      */   private void checkBlockToken(Block block, Token<BlockTokenIdentifier> token, BlockTokenSecretManager.AccessMode accessMode) throws IOException
/*      */   {
/* 1943 */     if ((this.isBlockTokenEnabled) && (UserGroupInformation.isSecurityEnabled())) {
/* 1944 */       BlockTokenIdentifier id = new BlockTokenIdentifier();
/* 1945 */       ByteArrayInputStream buf = new ByteArrayInputStream(token.getIdentifier());
/* 1946 */       DataInputStream in = new DataInputStream(buf);
/* 1947 */       id.readFields(in);
/* 1948 */       if (LOG.isDebugEnabled()) {
/* 1949 */         LOG.debug(new StringBuilder().append("Got: ").append(id.toString()).toString());
/*      */       }
/* 1951 */       this.blockTokenSecretManager.checkAccess(id, null, block, accessMode);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void checkBlockToken(Block block, BlockTokenSecretManager.AccessMode accessMode)
/*      */     throws IOException
/*      */   {
/* 1958 */     if ((this.isBlockTokenEnabled) && (UserGroupInformation.isSecurityEnabled())) {
/* 1959 */       Set tokenIds = UserGroupInformation.getCurrentUser().getTokenIdentifiers();
/*      */ 
/* 1961 */       if (tokenIds.size() != 1) {
/* 1962 */         throw new IOException(new StringBuilder().append("Can't continue with authorization since ").append(tokenIds.size()).append(" BlockTokenIdentifier ").append("is found.").toString());
/*      */       }
/*      */ 
/* 1966 */       for (TokenIdentifier tokenId : tokenIds) {
/* 1967 */         BlockTokenIdentifier id = (BlockTokenIdentifier)tokenId;
/* 1968 */         if (LOG.isDebugEnabled()) {
/* 1969 */           LOG.debug(new StringBuilder().append("Got: ").append(id.toString()).toString());
/*      */         }
/* 1971 */         this.blockTokenSecretManager.checkAccess(id, null, block, accessMode);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private LocatedBlock recoverBlock(Block block, boolean keepLength, DatanodeInfo[] targets, boolean closeFile)
/*      */     throws IOException
/*      */   {
/* 2006 */     synchronized (this.ongoingRecovery) {
/* 2007 */       if (this.ongoingRecovery.get(block.getWithWildcardGS()) != null) {
/* 2008 */         String msg = new StringBuilder().append(block).append(" is already being recovered, ").append(" ignoring this request to recover it.").toString();
/*      */ 
/* 2010 */         LOG.info(msg);
/* 2011 */         throw new IOException(msg);
/*      */       }
/* 2013 */       this.ongoingRecovery.put(block, block);
/*      */     }
/*      */     try {
/* 2016 */       int errorCount = 0;
/*      */ 
/* 2020 */       int rbwCount = 0;
/*      */ 
/* 2025 */       int rwrCount = 0;
/*      */ 
/* 2027 */       List blockRecords = new ArrayList();
/* 2028 */       for (DatanodeInfo id : targets) {
/*      */         try {
/* 2030 */           InterDatanodeProtocol datanode = this.dnRegistration.equals(id) ? this : createInterDataNodeProtocolProxy(id, getConf(), this.socketTimeout, this.connectToDnViaHostname);
/*      */ 
/* 2033 */           BlockRecoveryInfo info = datanode.startBlockRecovery(block);
/* 2034 */           if (info == null) {
/* 2035 */             LOG.info(new StringBuilder().append("No block metadata found for ").append(block).append(" on datanode ").append(id).toString());
/*      */           }
/* 2039 */           else if (info.getBlock().getGenerationStamp() < block.getGenerationStamp()) {
/* 2040 */             LOG.info(new StringBuilder().append("Only old generation stamp ").append(info.getBlock().getGenerationStamp()).append(" found on datanode ").append(id).append(" (needed block=").append(block).append(")").toString());
/*      */           }
/*      */           else
/*      */           {
/* 2045 */             blockRecords.add(new BlockRecord(id, datanode, info));
/*      */ 
/* 2047 */             if (info.wasRecoveredOnStartup())
/* 2048 */               rwrCount++;
/*      */             else
/* 2050 */               rbwCount++;
/*      */           }
/*      */         } catch (IOException e) {
/* 2053 */           errorCount++;
/* 2054 */           DataNodeMXBean.LOG.warn(new StringBuilder().append("Failed to getBlockMetaDataInfo for block (=").append(block).append(") from datanode (=").append(id).append(")").toString(), e);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2063 */       boolean shouldRecoverRwrs = rbwCount == 0;
/*      */ 
/* 2065 */       List syncList = new ArrayList();
/* 2066 */       long minlength = 9223372036854775807L;
/*      */ 
/* 2068 */       for (BlockRecord record : blockRecords) {
/* 2069 */         BlockRecoveryInfo info = record.info;
/* 2070 */         assert ((info != null) && (info.getBlock().getGenerationStamp() >= block.getGenerationStamp()));
/* 2071 */         if ((!shouldRecoverRwrs) && (info.wasRecoveredOnStartup())) {
/* 2072 */           LOG.info(new StringBuilder().append("Not recovering replica ").append(record).append(" since it was recovered on ").append("startup and we have better replicas").toString());
/*      */         }
/* 2076 */         else if (keepLength) {
/* 2077 */           if (info.getBlock().getNumBytes() == block.getNumBytes())
/* 2078 */             syncList.add(record);
/*      */         }
/*      */         else {
/* 2081 */           syncList.add(record);
/* 2082 */           if (info.getBlock().getNumBytes() < minlength) {
/* 2083 */             minlength = info.getBlock().getNumBytes();
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 2088 */       if ((syncList.isEmpty()) && (errorCount > 0)) {
/* 2089 */         throw new IOException(new StringBuilder().append("All datanodes failed: block=").append(block).append(", datanodeids=").append(Arrays.asList(targets)).toString());
/*      */       }
/*      */ 
/* 2092 */       if (!keepLength) {
/* 2093 */         block.setNumBytes(minlength);
/*      */       }
/* 2095 */       return syncBlock(block, syncList, targets, closeFile);
/*      */     } finally {
/* 2097 */       synchronized (this.ongoingRecovery) {
/* 2098 */         this.ongoingRecovery.remove(block);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private LocatedBlock syncBlock(Block block, List<BlockRecord> syncList, DatanodeInfo[] targets, boolean closeFile)
/*      */     throws IOException
/*      */   {
/* 2106 */     if (LOG.isDebugEnabled()) {
/* 2107 */       LOG.debug(new StringBuilder().append("block=").append(block).append(", (length=").append(block.getNumBytes()).append("), syncList=").append(syncList).append(", closeFile=").append(closeFile).toString());
/*      */     }
/*      */ 
/* 2113 */     if (syncList.isEmpty()) {
/* 2114 */       this.namenode.commitBlockSynchronization(block, 0L, 0L, closeFile, true, DatanodeID.EMPTY_ARRAY);
/*      */ 
/* 2117 */       LocatedBlock b = new LocatedBlock(block, targets);
/* 2118 */       if (this.isBlockTokenEnabled) {
/* 2119 */         b.setBlockToken(this.blockTokenSecretManager.generateToken(null, b.getBlock(), EnumSet.of(BlockTokenSecretManager.AccessMode.WRITE)));
/*      */       }
/*      */ 
/* 2122 */       return b;
/*      */     }
/*      */ 
/* 2125 */     List successList = new ArrayList();
/*      */ 
/* 2127 */     long generationstamp = this.namenode.nextGenerationStamp(block, closeFile);
/* 2128 */     Block newblock = new Block(block.getBlockId(), block.getNumBytes(), generationstamp);
/*      */ 
/* 2130 */     for (BlockRecord r : syncList) {
/*      */       try {
/* 2132 */         r.datanode.updateBlock(r.info.getBlock(), newblock, closeFile);
/* 2133 */         successList.add(r.id);
/*      */       } catch (IOException e) {
/* 2135 */         DataNodeMXBean.LOG.warn(new StringBuilder().append("Failed to updateBlock (newblock=").append(newblock).append(", datanode=").append(r.id).append(")").toString(), e);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2140 */     if (!successList.isEmpty()) {
/* 2141 */       DatanodeID[] nlist = (DatanodeID[])successList.toArray(new DatanodeID[successList.size()]);
/*      */ 
/* 2143 */       this.namenode.commitBlockSynchronization(block, newblock.getGenerationStamp(), newblock.getNumBytes(), closeFile, false, nlist);
/*      */ 
/* 2146 */       DatanodeInfo[] info = new DatanodeInfo[nlist.length];
/* 2147 */       for (int i = 0; i < nlist.length; i++) {
/* 2148 */         info[i] = new DatanodeInfo(nlist[i]);
/*      */       }
/* 2150 */       LocatedBlock b = new LocatedBlock(newblock, info);
/*      */ 
/* 2153 */       if (this.isBlockTokenEnabled) {
/* 2154 */         b.setBlockToken(this.blockTokenSecretManager.generateToken(null, b.getBlock(), EnumSet.of(BlockTokenSecretManager.AccessMode.WRITE)));
/*      */       }
/*      */ 
/* 2157 */       return b;
/*      */     }
/*      */ 
/* 2161 */     StringBuilder b = new StringBuilder();
/* 2162 */     for (BlockRecord r : syncList) {
/* 2163 */       b.append(new StringBuilder().append("\n  ").append(r.id).toString());
/*      */     }
/* 2165 */     throw new IOException(new StringBuilder().append("Cannot recover ").append(block).append(", none of these ").append(syncList.size()).append(" datanodes success {").append(b).append("\n}").toString());
/*      */   }
/*      */ 
/*      */   public LocatedBlock recoverBlock(Block block, boolean keepLength, DatanodeInfo[] targets)
/*      */     throws IOException
/*      */   {
/* 2173 */     logRecoverBlock("Client", block, targets);
/* 2174 */     checkBlockToken(block, BlockTokenSecretManager.AccessMode.WRITE);
/* 2175 */     return recoverBlock(block, keepLength, targets, false);
/*      */   }
/*      */ 
/*      */   public Block getBlockInfo(Block block) throws IOException
/*      */   {
/* 2180 */     checkBlockToken(block, BlockTokenSecretManager.AccessMode.READ);
/* 2181 */     Block stored = this.data.getStoredBlock(block.getBlockId());
/* 2182 */     return stored;
/*      */   }
/*      */ 
/*      */   private static void logRecoverBlock(String who, Block block, DatanodeID[] targets)
/*      */   {
/* 2187 */     StringBuilder msg = new StringBuilder(targets[0].getName());
/* 2188 */     for (int i = 1; i < targets.length; i++) {
/* 2189 */       msg.append(new StringBuilder().append(", ").append(targets[i].getName()).toString());
/*      */     }
/* 2191 */     LOG.info(new StringBuilder().append(who).append(" calls recoverBlock(block=").append(block).append(", targets=[").append(msg).append("])").toString());
/*      */   }
/*      */ 
/*      */   public static InetSocketAddress getStreamingAddr(Configuration conf)
/*      */   {
/* 2196 */     String address = NetUtils.getServerAddress(conf, "dfs.datanode.bindAddress", "dfs.datanode.port", "dfs.datanode.address");
/*      */ 
/* 2201 */     return NetUtils.createSocketAddr(address);
/*      */   }
/*      */ 
/*      */   public String getHostName()
/*      */   {
/* 2207 */     return this.machineName;
/*      */   }
/*      */ 
/*      */   public String getVersion()
/*      */   {
/* 2212 */     return VersionInfo.getVersion();
/*      */   }
/*      */ 
/*      */   public String getRpcPort()
/*      */   {
/* 2217 */     InetSocketAddress ipcAddr = NetUtils.createSocketAddr(getConf().get("dfs.datanode.ipc.address"));
/*      */ 
/* 2219 */     return Integer.toString(ipcAddr.getPort());
/*      */   }
/*      */ 
/*      */   public String getHttpPort()
/*      */   {
/* 2224 */     return getConf().get("dfs.datanode.info.port");
/*      */   }
/*      */ 
/*      */   public String getNamenodeAddress()
/*      */   {
/* 2229 */     return nameNodeAddr.getHostName();
/*      */   }
/*      */ 
/*      */   public String getVolumeInfo()
/*      */   {
/* 2239 */     Map info = new HashMap();
/* 2240 */     Collection volumes = ((FSDataset)this.data).getVolumeInfo();
/* 2241 */     for (FSDataset.VolumeInfo v : volumes) {
/* 2242 */       Map innerInfo = new HashMap();
/* 2243 */       innerInfo.put("usedSpace", Long.valueOf(v.usedSpace));
/* 2244 */       innerInfo.put("freeSpace", Long.valueOf(v.freeSpace));
/* 2245 */       innerInfo.put("reservedSpace", Long.valueOf(v.reservedSpace));
/* 2246 */       info.put(v.directory, innerInfo);
/*      */     }
/* 2248 */     return JSON.toString(info);
/*      */   }
/*      */ 
/*      */   public Long getBalancerBandwidth()
/*      */   {
/* 2257 */     DataXceiverServer dxcs = (DataXceiverServer)this.dataXceiverServer.getRunnable();
/*      */ 
/* 2259 */     return Long.valueOf(dxcs.balanceThrottler.getBandwidth());
/*      */   }
/*      */ 
/*      */   long getReadaheadLength() {
/* 2263 */     return this.readaheadLength;
/*      */   }
/*      */ 
/*      */   boolean shouldDropCacheBehindWrites() {
/* 2267 */     return this.dropCacheBehindWrites;
/*      */   }
/*      */ 
/*      */   boolean shouldDropCacheBehindReads() {
/* 2271 */     return this.dropCacheBehindReads;
/*      */   }
/*      */ 
/*      */   boolean shouldSyncBehindWrites() {
/* 2275 */     return this.syncBehindWrites;
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*  170 */     LOG = LogFactory.getLog(DataNode.class);
/*      */ 
/*  173 */     Configuration.addDefaultResource("hdfs-default.xml");
/*  174 */     Configuration.addDefaultResource("hdfs-site.xml");
/*      */   }
/*      */ 
/*      */   private static class BlockRecord
/*      */   {
/*      */     final DatanodeID id;
/*      */     final InterDatanodeProtocol datanode;
/*      */     final BlockRecoveryInfo info;
/*      */ 
/*      */     BlockRecord(DatanodeID id, InterDatanodeProtocol datanode, BlockRecoveryInfo info)
/*      */     {
/* 1984 */       this.id = id;
/* 1985 */       this.datanode = datanode;
/* 1986 */       this.info = info;
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1991 */       return "BlockRecord(info=" + this.info + " node=" + this.id + ")";
/*      */     }
/*      */   }
/*      */ 
/*      */   class DataTransfer
/*      */     implements Runnable
/*      */   {
/*      */     DatanodeInfo[] targets;
/*      */     Block b;
/*      */     DataNode datanode;
/*      */ 
/*      */     public DataTransfer(DatanodeInfo[] targets, Block b, DataNode datanode)
/*      */       throws IOException
/*      */     {
/* 1492 */       this.targets = targets;
/* 1493 */       this.b = b;
/* 1494 */       this.datanode = datanode;
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/* 1501 */       DataNode.this.xmitsInProgress.getAndIncrement();
/* 1502 */       Socket sock = null;
/* 1503 */       DataOutputStream out = null;
/* 1504 */       BlockSender blockSender = null;
/*      */       try
/*      */       {
/* 1507 */         String dnName = this.targets[0].getName(DataNode.this.connectToDnViaHostname);
/* 1508 */         InetSocketAddress curTarget = NetUtils.createSocketAddr(dnName);
/* 1509 */         sock = DataNode.this.newSocket();
/* 1510 */         DataNode.LOG.debug("Connecting to " + dnName);
/* 1511 */         NetUtils.connect(sock, curTarget, DataNode.this.socketTimeout);
/* 1512 */         sock.setSoTimeout(this.targets.length * DataNode.this.socketTimeout);
/*      */ 
/* 1514 */         long writeTimeout = DataNode.this.socketWriteTimeout + 5000 * (this.targets.length - 1);
/*      */ 
/* 1516 */         OutputStream baseStream = NetUtils.getOutputStream(sock, writeTimeout);
/* 1517 */         out = new DataOutputStream(new BufferedOutputStream(baseStream, FSConstants.SMALL_BUFFER_SIZE));
/*      */ 
/* 1520 */         blockSender = new BlockSender(this.b, 0L, this.b.getNumBytes(), false, false, false, this.datanode);
/*      */ 
/* 1522 */         DatanodeInfo srcNode = new DatanodeInfo(DataNode.this.dnRegistration);
/*      */ 
/* 1527 */         out.writeShort(17);
/* 1528 */         out.writeByte(80);
/* 1529 */         out.writeLong(this.b.getBlockId());
/* 1530 */         out.writeLong(this.b.getGenerationStamp());
/* 1531 */         out.writeInt(0);
/* 1532 */         out.writeBoolean(false);
/* 1533 */         Text.writeString(out, "");
/* 1534 */         out.writeBoolean(true);
/* 1535 */         srcNode.write(out);
/*      */ 
/* 1537 */         out.writeInt(this.targets.length - 1);
/* 1538 */         for (int i = 1; i < this.targets.length; i++) {
/* 1539 */           this.targets[i].write(out);
/*      */         }
/* 1541 */         Token accessToken = BlockTokenSecretManager.DUMMY_TOKEN;
/* 1542 */         if (DataNode.this.isBlockTokenEnabled) {
/* 1543 */           accessToken = DataNode.this.blockTokenSecretManager.generateToken(null, this.b, EnumSet.of(BlockTokenSecretManager.AccessMode.WRITE));
/*      */         }
/*      */ 
/* 1546 */         accessToken.write(out);
/*      */ 
/* 1548 */         blockSender.sendBlock(out, baseStream, null);
/*      */ 
/* 1551 */         DataNode.LOG.info(DataNode.this.dnRegistration + ":Transmitted " + this.b + " to " + curTarget);
/*      */       }
/*      */       catch (IOException ie) {
/* 1554 */         DataNode.LOG.warn(DataNode.this.dnRegistration + ":Failed to transfer " + this.b + " to " + this.targets[0].getName() + " got " + StringUtils.stringifyException(ie));
/*      */         try
/*      */         {
/* 1558 */           DataNode.this.checkDiskError(ie);
/*      */         } catch (IOException e) {
/* 1560 */           DataNode.LOG.warn("DataNode.checkDiskError failed in run() with: ", e);
/*      */         }
/*      */       } finally {
/* 1563 */         DataNode.this.xmitsInProgress.getAndDecrement();
/* 1564 */         IOUtils.closeStream(blockSender);
/* 1565 */         IOUtils.closeStream(out);
/* 1566 */         IOUtils.closeSocket(sock);
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.DataNode
 * JD-Core Version:    0.6.1
 */
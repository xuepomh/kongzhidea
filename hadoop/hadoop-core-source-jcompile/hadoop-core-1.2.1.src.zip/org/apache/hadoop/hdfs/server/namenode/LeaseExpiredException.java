/*    */ package org.apache.hadoop.hdfs.server.namenode;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class LeaseExpiredException extends IOException
/*    */ {
/*    */   public LeaseExpiredException(String msg)
/*    */   {
/* 28 */     super(msg);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.LeaseExpiredException
 * JD-Core Version:    0.6.1
 */
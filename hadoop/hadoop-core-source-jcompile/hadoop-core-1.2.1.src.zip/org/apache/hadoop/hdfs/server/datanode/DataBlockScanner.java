/*     */ package org.apache.hadoop.hdfs.server.datanode;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.Closeable;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Random;
/*     */ import java.util.TreeSet;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlock;
/*     */ import org.apache.hadoop.hdfs.server.datanode.metrics.DataNodeInstrumentation;
/*     */ import org.apache.hadoop.hdfs.server.protocol.DatanodeProtocol;
/*     */ import org.apache.hadoop.hdfs.util.DataTransferThrottler;
/*     */ import org.apache.hadoop.io.IOUtils;
/*     */ import org.apache.hadoop.io.IOUtils.NullOutputStream;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ class DataBlockScanner
/*     */   implements Runnable
/*     */ {
/*  63 */   public static final Log LOG = LogFactory.getLog(DataBlockScanner.class);
/*     */   private static final int MAX_SCAN_RATE = 8388608;
/*     */   private static final int MIN_SCAN_RATE = 1048576;
/*     */   static final long DEFAULT_SCAN_PERIOD_HOURS = 504L;
/*     */   private static final long ONE_DAY = 86400000L;
/*  71 */   static final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS");
/*     */   static final String verificationLogFile = "dncp_block_verification.log";
/*     */   static final int verficationLogLimit = 5;
/*  77 */   private long scanPeriod = 1814400000L;
/*     */   DataNode datanode;
/*     */   FSDataset dataset;
/*     */   TreeSet<BlockScanInfo> blockInfoSet;
/*     */   HashMap<Block, BlockScanInfo> blockMap;
/*  85 */   long totalScans = 0L;
/*  86 */   long totalVerifications = 0L;
/*  87 */   long totalScanErrors = 0L;
/*  88 */   long totalTransientErrors = 0L;
/*     */ 
/*  90 */   long currentPeriodStart = System.currentTimeMillis();
/*  91 */   long bytesLeft = 0L;
/*  92 */   long totalBytesToScan = 0L;
/*     */   private LogFileHandler verificationLog;
/*  96 */   Random random = new Random();
/*     */ 
/*  98 */   DataTransferThrottler throttler = null;
/*     */ 
/*     */   DataBlockScanner(DataNode datanode, FSDataset dataset, Configuration conf)
/*     */   {
/* 139 */     this.datanode = datanode;
/* 140 */     this.dataset = dataset;
/* 141 */     this.scanPeriod = conf.getInt("dfs.datanode.scan.period.hours", 0);
/* 142 */     if (this.scanPeriod <= 0L) {
/* 143 */       this.scanPeriod = 504L;
/*     */     }
/* 145 */     this.scanPeriod *= 3600000L;
/*     */   }
/*     */ 
/*     */   private synchronized boolean isInitialized()
/*     */   {
/* 150 */     return this.throttler != null;
/*     */   }
/*     */ 
/*     */   private void updateBytesToScan(long len, long lastScanTime)
/*     */   {
/* 155 */     this.totalBytesToScan += len;
/* 156 */     if (lastScanTime < this.currentPeriodStart)
/* 157 */       this.bytesLeft += len;
/*     */   }
/*     */ 
/*     */   private synchronized void addBlockInfo(BlockScanInfo info)
/*     */   {
/* 164 */     boolean added = this.blockInfoSet.add(info);
/* 165 */     this.blockMap.put(info.block, info);
/*     */ 
/* 167 */     if (added) {
/* 168 */       LogFileHandler log = this.verificationLog;
/* 169 */       if (log != null) {
/* 170 */         log.setMaxNumLines(this.blockMap.size() * 5);
/*     */       }
/* 172 */       updateBytesToScan(info.block.getNumBytes(), info.lastScanTime);
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized void delBlockInfo(BlockScanInfo info) {
/* 177 */     boolean exists = this.blockInfoSet.remove(info);
/* 178 */     this.blockMap.remove(info.block);
/* 179 */     if (exists) {
/* 180 */       LogFileHandler log = this.verificationLog;
/* 181 */       if (log != null) {
/* 182 */         log.setMaxNumLines(this.blockMap.size() * 5);
/*     */       }
/* 184 */       updateBytesToScan(-info.block.getNumBytes(), info.lastScanTime);
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized void updateBlockInfo(LogEntry e)
/*     */   {
/* 190 */     BlockScanInfo info = (BlockScanInfo)this.blockMap.get(new Block(e.blockId, 0L, e.genStamp));
/*     */ 
/* 192 */     if ((info != null) && (e.verificationTime > 0L) && (info.lastScanTime < e.verificationTime))
/*     */     {
/* 194 */       delBlockInfo(info);
/* 195 */       info.lastScanTime = e.verificationTime;
/* 196 */       info.lastScanType = ScanType.VERIFICATION_SCAN;
/* 197 */       addBlockInfo(info);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void init()
/*     */   {
/* 204 */     Block[] arr = this.dataset.getBlockReport();
/* 205 */     Collections.shuffle(Arrays.asList(arr));
/*     */ 
/* 207 */     this.blockInfoSet = new TreeSet();
/* 208 */     this.blockMap = new HashMap();
/*     */ 
/* 210 */     long scanTime = -1L;
/* 211 */     for (Block block : arr) {
/* 212 */       BlockScanInfo info = new BlockScanInfo(block);
/* 213 */       info.lastScanTime = (scanTime--);
/*     */ 
/* 215 */       addBlockInfo(info);
/*     */     }
/*     */ 
/* 221 */     File dir = null;
/* 222 */     FSDataset.FSVolume[] volumes = this.dataset.volumes.volumes;
/* 223 */     for (FSDataset.FSVolume vol : volumes) {
/* 224 */       if (LogFileHandler.isFilePresent(vol.getDir(), "dncp_block_verification.log")) {
/* 225 */         dir = vol.getDir();
/* 226 */         break;
/*     */       }
/*     */     }
/* 229 */     if (dir == null) {
/* 230 */       dir = volumes[0].getDir();
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 235 */       this.verificationLog = new LogFileHandler(dir, "dncp_block_verification.log", 100);
/*     */     } catch (IOException e) {
/* 237 */       LOG.warn("Could not open verfication log. Verification times are not stored.");
/*     */     }
/*     */ 
/* 241 */     synchronized (this) {
/* 242 */       this.throttler = new DataTransferThrottler(200L, 8388608L);
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized long getNewBlockScanTime()
/*     */   {
/* 250 */     long period = Math.min(this.scanPeriod, Math.max(this.blockMap.size(), 1) * 600 * 1000L);
/*     */ 
/* 252 */     int periodInt = Math.abs((int)period);
/* 253 */     return System.currentTimeMillis() - this.scanPeriod + this.random.nextInt(periodInt);
/*     */   }
/*     */ 
/*     */   synchronized void addBlock(Block block)
/*     */   {
/* 259 */     if (!isInitialized()) {
/* 260 */       return;
/*     */     }
/*     */ 
/* 263 */     BlockScanInfo info = (BlockScanInfo)this.blockMap.get(block);
/* 264 */     if (info != null) {
/* 265 */       LOG.warn(new StringBuilder().append("Adding an already existing ").append(block).toString());
/* 266 */       delBlockInfo(info);
/*     */     }
/*     */ 
/* 269 */     info = new BlockScanInfo(block);
/* 270 */     info.lastScanTime = getNewBlockScanTime();
/*     */ 
/* 272 */     addBlockInfo(info);
/* 273 */     adjustThrottler();
/*     */   }
/*     */ 
/*     */   synchronized void deleteBlock(Block block)
/*     */   {
/* 278 */     if (!isInitialized()) {
/* 279 */       return;
/*     */     }
/* 281 */     BlockScanInfo info = (BlockScanInfo)this.blockMap.get(block);
/* 282 */     if (info != null)
/* 283 */       delBlockInfo(info);
/*     */   }
/*     */ 
/*     */   synchronized long getLastScanTime(Block block)
/*     */   {
/* 289 */     if (!isInitialized()) {
/* 290 */       return 0L;
/*     */     }
/* 292 */     BlockScanInfo info = (BlockScanInfo)this.blockMap.get(block);
/* 293 */     return info == null ? 0L : info.lastScanTime;
/*     */   }
/*     */ 
/*     */   void deleteBlocks(Block[] blocks)
/*     */   {
/* 298 */     for (Block b : blocks)
/* 299 */       deleteBlock(b);
/*     */   }
/*     */ 
/*     */   synchronized void verifiedByClient(Block block)
/*     */   {
/* 310 */     updateScanStatusInternal(block, ScanType.REMOTE_READ, true, true);
/*     */   }
/*     */ 
/*     */   private synchronized void updateScanStatus(Block block, ScanType type, boolean scanOk)
/*     */   {
/* 315 */     updateScanStatusInternal(block, type, scanOk, false);
/*     */   }
/*     */ 
/*     */   private synchronized void updateScanStatusInternal(Block block, ScanType type, boolean scanOk, boolean updateOnly)
/*     */   {
/* 331 */     if (!isInitialized()) {
/* 332 */       return;
/*     */     }
/* 334 */     BlockScanInfo info = (BlockScanInfo)this.blockMap.get(block);
/*     */ 
/* 336 */     if (info != null) {
/* 337 */       delBlockInfo(info);
/*     */     } else {
/* 339 */       if (updateOnly) {
/* 340 */         return;
/*     */       }
/*     */ 
/* 343 */       info = new BlockScanInfo(block);
/*     */     }
/*     */ 
/* 346 */     long now = System.currentTimeMillis();
/* 347 */     info.lastScanType = type;
/* 348 */     info.lastScanTime = now;
/* 349 */     info.lastScanOk = scanOk;
/* 350 */     addBlockInfo(info);
/*     */ 
/* 352 */     if (type == ScanType.REMOTE_READ) {
/* 353 */       this.totalVerifications += 1L;
/*     */     }
/*     */ 
/* 358 */     long diff = now - info.lastLogTime;
/* 359 */     if ((!scanOk) || ((type == ScanType.REMOTE_READ) && (diff < this.scanPeriod / 3L) && (diff < 86400000L)))
/*     */     {
/* 361 */       return;
/*     */     }
/*     */ 
/* 364 */     info.lastLogTime = now;
/* 365 */     LogFileHandler log = this.verificationLog;
/* 366 */     if (log != null)
/* 367 */       log.appendLine(LogEntry.newEnry(block, now));
/*     */   }
/*     */ 
/*     */   private void handleScanFailure(Block block)
/*     */   {
/* 372 */     LOG.info(new StringBuilder().append("Reporting bad ").append(block).append(" to namenode.").toString());
/*     */     try
/*     */     {
/* 375 */       DatanodeInfo[] dnArr = { new DatanodeInfo(this.datanode.dnRegistration) };
/* 376 */       LocatedBlock[] blocks = { new LocatedBlock(block, dnArr) };
/* 377 */       this.datanode.namenode.reportBadBlocks(blocks);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 382 */       LOG.warn(new StringBuilder().append("Failed to report bad ").append(block).append(" to namenode : ").append(" Exception : ").append(StringUtils.stringifyException(e)).toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized void adjustThrottler()
/*     */   {
/* 435 */     long timeLeft = this.currentPeriodStart + this.scanPeriod - System.currentTimeMillis();
/* 436 */     long bw = Math.max(this.bytesLeft * 1000L / timeLeft, 1048576L);
/* 437 */     this.throttler.setBandwidth(Math.min(bw, 8388608L));
/*     */   }
/*     */ 
/*     */   private void verifyBlock(Block block)
/*     */   {
/* 442 */     BlockSender blockSender = null;
/*     */ 
/* 448 */     for (int i = 0; i < 2; i++) {
/* 449 */       boolean second = i > 0;
/*     */       try
/*     */       {
/* 452 */         adjustThrottler();
/*     */ 
/* 454 */         blockSender = new BlockSender(block, 0L, -1L, false, false, true, this.datanode);
/*     */ 
/* 457 */         DataOutputStream out = new DataOutputStream(new IOUtils.NullOutputStream());
/*     */ 
/* 460 */         blockSender.sendBlock(out, null, this.throttler);
/*     */ 
/* 462 */         LOG.info(new StringBuilder().append(second ? "Second verification" : "Verification").append(" succeeded ").append(block).toString());
/*     */ 
/* 465 */         if (second) {
/* 466 */           this.totalTransientErrors += 1L;
/*     */         }
/*     */ 
/* 469 */         updateScanStatus(block, ScanType.VERIFICATION_SCAN, true);
/*     */         return;
/*     */       }
/*     */       catch (IOException e) {
/* 474 */         this.totalScanErrors += 1L;
/* 475 */         updateScanStatus(block, ScanType.VERIFICATION_SCAN, false);
/*     */ 
/* 478 */         if (this.dataset.getFile(block) == null) { LOG.info(new StringBuilder().append("Verification failed for ").append(block).append(". Its ok since ").append("it is not in datanode dataset anymore.").toString());
/*     */ 
/* 481 */           deleteBlock(block);
/*     */           return;
/*     */         }
/* 485 */         LOG.warn(new StringBuilder().append(second ? "Second " : "First ").append("Verification failed for ").append(block).append(". Exception : ").append(StringUtils.stringifyException(e)).toString());
/*     */ 
/* 489 */         if (second) { this.datanode.getMetrics().incrBlockVerificationFailures();
/* 491 */           handleScanFailure(block);
/*     */           return; }
/*     */       } finally {
/* 495 */         IOUtils.closeStream(blockSender);
/* 496 */         this.datanode.getMetrics().incrBlocksVerified();
/* 497 */         this.totalScans += 1L;
/* 498 */         this.totalVerifications += 1L;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized long getEarliestScanTime() {
/* 504 */     if (this.blockInfoSet.size() > 0) {
/* 505 */       return ((BlockScanInfo)this.blockInfoSet.first()).lastScanTime;
/*     */     }
/* 507 */     return 9223372036854775807L;
/*     */   }
/*     */ 
/*     */   private void verifyFirstBlock()
/*     */   {
/* 512 */     Block block = null;
/* 513 */     synchronized (this) {
/* 514 */       if (this.blockInfoSet.size() > 0) {
/* 515 */         block = ((BlockScanInfo)this.blockInfoSet.first()).block;
/*     */       }
/*     */     }
/*     */ 
/* 519 */     if (block != null)
/* 520 */       verifyBlock(block);
/*     */   }
/*     */ 
/*     */   private boolean assignInitialVerificationTimes()
/*     */   {
/* 528 */     int numBlocks = 1;
/* 529 */     synchronized (this) {
/* 530 */       numBlocks = Math.max(this.blockMap.size(), 1);
/*     */     }
/*     */ 
/* 534 */     DataBlockScanner.LogFileHandler.Reader logReader = null;
/*     */     try {
/* 536 */       if (this.verificationLog != null)
/*     */       {
/*     */         LogFileHandler tmp45_42 = this.verificationLog; tmp45_42.getClass(); logReader = new DataBlockScanner.LogFileHandler.Reader(tmp45_42, false, null);
/*     */       }
/*     */     } catch (IOException e) {
/* 540 */       LOG.warn(new StringBuilder().append("Could not read previous verification times : ").append(StringUtils.stringifyException(e)).toString());
/*     */     }
/*     */ 
/* 544 */     if (this.verificationLog != null) {
/* 545 */       this.verificationLog.updateCurNumLines();
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 550 */       while ((logReader != null) && (logReader.hasNext())) {
/* 551 */         if ((!this.datanode.shouldRun) || (Thread.interrupted())) {
/* 552 */           return false;
/*     */         }
/* 554 */         LogEntry entry = LogEntry.parseEntry(logReader.next());
/* 555 */         if (entry != null)
/* 556 */           updateBlockInfo(entry);
/*     */       }
/*     */     }
/*     */     finally {
/* 560 */       IOUtils.closeStream(logReader);
/*     */     }
/*     */ 
/* 567 */     long verifyInterval = ()Math.min(this.scanPeriod / 2.0D / numBlocks, 600000.0D);
/*     */ 
/* 569 */     long lastScanTime = System.currentTimeMillis() - this.scanPeriod;
/*     */ 
/* 575 */     synchronized (this) {
/* 576 */       if (this.blockInfoSet.size() > 0)
/*     */       {
/*     */         BlockScanInfo info;
/* 578 */         while ((info = (BlockScanInfo)this.blockInfoSet.first()).lastScanTime < 0L) {
/* 579 */           delBlockInfo(info);
/* 580 */           info.lastScanTime = lastScanTime;
/* 581 */           lastScanTime += verifyInterval;
/* 582 */           addBlockInfo(info);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 587 */     return true;
/*     */   }
/*     */ 
/*     */   private synchronized void startNewPeriod() {
/* 591 */     LOG.info(new StringBuilder().append("Starting a new period : work left in prev period : ").append(String.format("%.2f%%", new Object[] { Double.valueOf(this.bytesLeft * 100.0D / this.totalBytesToScan) })).toString());
/*     */ 
/* 594 */     this.bytesLeft = this.totalBytesToScan;
/* 595 */     this.currentPeriodStart = System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try {
/* 601 */       init();
/*     */ 
/* 604 */       if (!assignInitialVerificationTimes())
/*     */       {
/*     */         return;
/*     */       }
/* 608 */       adjustThrottler();
/*     */ 
/* 610 */       while ((this.datanode.shouldRun) && (!Thread.interrupted())) {
/* 611 */         long now = System.currentTimeMillis();
/* 612 */         synchronized (this) {
/* 613 */           if (now >= this.currentPeriodStart + this.scanPeriod) {
/* 614 */             startNewPeriod();
/*     */           }
/*     */         }
/* 617 */         if (now - getEarliestScanTime() >= this.scanPeriod)
/* 618 */           verifyFirstBlock();
/*     */         else
/*     */           try {
/* 621 */             Thread.sleep(1000L);
/*     */           } catch (InterruptedException ignored) {
/*     */           }
/*     */       }
/*     */     } catch (RuntimeException e) {
/* 626 */       LOG.warn(new StringBuilder().append("RuntimeException during DataBlockScanner.run() : ").append(StringUtils.stringifyException(e)).toString());
/*     */ 
/* 628 */       throw e;
/*     */     } finally {
/* 630 */       shutdown();
/* 631 */       LOG.info("Exiting DataBlockScanner thread");
/*     */     }
/*     */   }
/*     */ 
/*     */   synchronized void shutdown() {
/* 636 */     LogFileHandler log = this.verificationLog;
/* 637 */     this.verificationLog = null;
/* 638 */     if (log != null)
/* 639 */       log.close();
/*     */   }
/*     */ 
/*     */   synchronized void printBlockReport(StringBuilder buffer, boolean summaryOnly)
/*     */   {
/* 645 */     long oneHour = 3600000L;
/* 646 */     long oneDay = 24L * oneHour;
/* 647 */     long oneWeek = 7L * oneDay;
/* 648 */     long fourWeeks = 4L * oneWeek;
/*     */ 
/* 650 */     int inOneHour = 0;
/* 651 */     int inOneDay = 0;
/* 652 */     int inOneWeek = 0;
/* 653 */     int inFourWeeks = 0;
/* 654 */     int inScanPeriod = 0;
/* 655 */     int neverScanned = 0;
/*     */ 
/* 657 */     int total = this.blockInfoSet.size();
/*     */ 
/* 659 */     long now = System.currentTimeMillis();
/*     */ 
/* 661 */     Date date = new Date();
/*     */ 
/* 663 */     for (Iterator it = this.blockInfoSet.iterator(); it.hasNext(); ) {
/* 664 */       BlockScanInfo info = (BlockScanInfo)it.next();
/*     */ 
/* 666 */       long scanTime = info.getLastScanTime();
/* 667 */       long diff = now - scanTime;
/*     */ 
/* 669 */       if (diff <= oneHour) inOneHour++;
/* 670 */       if (diff <= oneDay) inOneDay++;
/* 671 */       if (diff <= oneWeek) inOneWeek++;
/* 672 */       if (diff <= fourWeeks) inFourWeeks++;
/* 673 */       if (diff <= this.scanPeriod) inScanPeriod++;
/* 674 */       if (scanTime <= 0L) neverScanned++;
/*     */ 
/* 676 */       if (!summaryOnly) {
/* 677 */         date.setTime(scanTime);
/* 678 */         String scanType = info.lastScanType == ScanType.VERIFICATION_SCAN ? "local" : info.lastScanType == ScanType.REMOTE_READ ? "remote" : "none";
/*     */ 
/* 682 */         buffer.append(String.format("%-26s : status : %-6s type : %-6s scan time : %-15d %s\n", new Object[] { info.block, info.lastScanOk ? "ok" : "failed", scanType, Long.valueOf(scanTime), scanTime <= 0L ? "not yet verified" : dateFormat.format(date) }));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 692 */     double pctPeriodLeft = this.scanPeriod + this.currentPeriodStart - now * 100.0D / this.scanPeriod;
/*     */ 
/* 694 */     double pctProgress = this.totalBytesToScan == 0L ? 100.0D : this.totalBytesToScan - this.bytesLeft * 10000.0D / this.totalBytesToScan / (100.0D - pctPeriodLeft + 1.0E-010D);
/*     */ 
/* 698 */     buffer.append(String.format("\nTotal Blocks                 : %6d\nVerified in last hour        : %6d\nVerified in last day         : %6d\nVerified in last week        : %6d\nVerified in last four weeks  : %6d\nVerified in SCAN_PERIOD      : %6d\nNot yet verified             : %6d\nVerified since restart       : %6d\nScans since restart          : %6d\nScan errors since restart    : %6d\nTransient scan errors        : %6d\nCurrent scan rate limit KBps : %6d\nProgress this period         : %6.0f%%\nTime left in cur period      : %6.2f%%\n", new Object[] { Integer.valueOf(total), Integer.valueOf(inOneHour), Integer.valueOf(inOneDay), Integer.valueOf(inOneWeek), Integer.valueOf(inFourWeeks), Integer.valueOf(inScanPeriod), Integer.valueOf(neverScanned), Long.valueOf(this.totalVerifications), Long.valueOf(this.totalScans), Long.valueOf(this.totalScanErrors), Long.valueOf(this.totalTransientErrors), Long.valueOf(Math.round(this.throttler.getBandwidth() / 1024.0D)), Double.valueOf(pctProgress), Double.valueOf(pctPeriodLeft) }));
/*     */   }
/*     */ 
/*     */   public static class Servlet extends HttpServlet
/*     */   {
/*     */     public void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */       throws IOException
/*     */     {
/* 978 */       response.setContentType("text/plain");
/*     */ 
/* 980 */       DataBlockScanner blockScanner = (DataBlockScanner)getServletContext().getAttribute("datanode.blockScanner");
/*     */ 
/* 983 */       boolean summary = request.getParameter("listblocks") == null;
/*     */ 
/* 985 */       StringBuilder buffer = new StringBuilder(8192);
/* 986 */       if (blockScanner == null) {
/* 987 */         buffer.append("Periodic block scanner is not running. Please check the datanode log if this is unexpected.");
/*     */       }
/* 989 */       else if (blockScanner.isInitialized())
/* 990 */         blockScanner.printBlockReport(buffer, summary);
/*     */       else {
/* 992 */         buffer.append("Periodic block scanner is not yet initialized. Please check back again after some time.");
/*     */       }
/*     */ 
/* 995 */       response.getWriter().write(buffer.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class LogFileHandler
/*     */   {
/*     */     private static final String curFileSuffix = ".curr";
/*     */     private static final String prevFileSuffix = ".prev";
/*     */     private static final long minRollingPeriod = 21600000L;
/*     */     private static final long minWarnPeriod = 21600000L;
/*     */     private static final int minLineLimit = 1000;
/*     */     private File curFile;
/*     */     private File prevFile;
/* 745 */     private int maxNumLines = -1;
/* 746 */     private int curNumLines = -1;
/*     */ 
/* 748 */     long lastWarningTime = 0L;
/*     */     private PrintStream out;
/* 752 */     int numReaders = 0;
/*     */ 
/*     */     static boolean isFilePresent(File dir, String filePrefix)
/*     */     {
/* 739 */       return (new File(dir, filePrefix + ".curr").exists()) || (new File(dir, filePrefix + ".prev").exists());
/*     */     }
/*     */ 
/*     */     LogFileHandler(File dir, String filePrefix, int maxNumLines)
/*     */       throws IOException
/*     */     {
/* 767 */       this.curFile = new File(dir, filePrefix + ".curr");
/* 768 */       this.prevFile = new File(dir, filePrefix + ".prev");
/* 769 */       openCurFile();
/* 770 */       this.curNumLines = -1;
/* 771 */       setMaxNumLines(maxNumLines);
/*     */     }
/*     */ 
/*     */     synchronized void setMaxNumLines(int maxNumLines)
/*     */     {
/* 776 */       this.maxNumLines = Math.max(maxNumLines, 1000);
/*     */     }
/*     */ 
/*     */     synchronized boolean appendLine(String line)
/*     */     {
/* 789 */       if (this.out == null) {
/* 790 */         return false;
/*     */       }
/* 792 */       this.out.println();
/* 793 */       this.out.print(line);
/* 794 */       this.curNumLines += (this.curNumLines < 0 ? -1 : 1);
/*     */       try {
/* 796 */         rollIfRequired();
/*     */       } catch (IOException e) {
/* 798 */         warn("Rolling failed for " + this.curFile + " : " + e.getMessage());
/* 799 */         return false;
/*     */       }
/* 801 */       return true;
/*     */     }
/*     */ 
/*     */     private synchronized void warn(String msg)
/*     */     {
/* 806 */       long now = System.currentTimeMillis();
/* 807 */       if (now - this.lastWarningTime >= 21600000L) {
/* 808 */         this.lastWarningTime = now;
/* 809 */         DataBlockScanner.LOG.warn(msg);
/*     */       }
/*     */     }
/*     */ 
/*     */     private synchronized void openCurFile() throws FileNotFoundException {
/* 814 */       close();
/* 815 */       this.out = new PrintStream(new FileOutputStream(this.curFile, true));
/*     */     }
/*     */ 
/*     */     void updateCurNumLines()
/*     */     {
/* 820 */       int count = 0;
/* 821 */       Reader it = null;
/*     */       try {
/* 823 */         for (it = new Reader(true, null); it.hasNext(); count++)
/* 824 */           it.next();
/*     */       }
/*     */       catch (IOException e) {
/*     */       }
/*     */       finally {
/* 829 */         synchronized (this) {
/* 830 */           this.curNumLines = count;
/*     */         }
/* 832 */         IOUtils.closeStream(it);
/*     */       }
/*     */     }
/*     */ 
/*     */     private void rollIfRequired() throws IOException {
/* 837 */       if ((this.curNumLines < this.maxNumLines) || (this.numReaders > 0)) {
/* 838 */         return;
/*     */       }
/*     */ 
/* 841 */       long now = System.currentTimeMillis();
/* 842 */       if (now < 21600000L) {
/* 843 */         return;
/*     */       }
/*     */ 
/* 846 */       if ((!this.prevFile.delete()) && (this.prevFile.exists())) {
/* 847 */         throw new IOException("Could not delete " + this.prevFile);
/*     */       }
/*     */ 
/* 850 */       close();
/*     */ 
/* 852 */       if (!this.curFile.renameTo(this.prevFile)) {
/* 853 */         openCurFile();
/* 854 */         throw new IOException("Could not rename " + this.curFile + " to " + this.prevFile);
/*     */       }
/*     */ 
/* 858 */       openCurFile();
/* 859 */       updateCurNumLines();
/*     */     }
/*     */ 
/*     */     synchronized void close() {
/* 863 */       if (this.out != null) {
/* 864 */         this.out.close();
/* 865 */         this.out = null;
/*     */       }
/*     */     }
/*     */ 
/*     */     private class Reader
/*     */       implements Iterator<String>, Closeable
/*     */     {
/*     */       BufferedReader reader;
/*     */       File file;
/*     */       String line;
/* 879 */       boolean closed = false;
/*     */ 
/*     */       private Reader(boolean skipPrevFile) throws IOException {
/* 882 */         synchronized (DataBlockScanner.LogFileHandler.this) {
/* 883 */           DataBlockScanner.LogFileHandler.this.numReaders += 1;
/*     */         }
/* 885 */         this.reader = null;
/* 886 */         this.file = (skipPrevFile ? DataBlockScanner.LogFileHandler.this.curFile : DataBlockScanner.LogFileHandler.this.prevFile);
/* 887 */         readNext();
/*     */       }
/*     */ 
/*     */       private boolean openFile() throws IOException
/*     */       {
/* 892 */         for (int i = 0; i < 2; i++) {
/* 893 */           if ((this.reader != null) || (i > 0))
/*     */           {
/* 895 */             this.file = (this.file == DataBlockScanner.LogFileHandler.this.prevFile ? DataBlockScanner.LogFileHandler.this.curFile : null);
/*     */           }
/* 897 */           if (this.file == null) {
/* 898 */             return false;
/*     */           }
/* 900 */           if (this.file.exists())
/*     */           {
/*     */             break;
/*     */           }
/*     */         }
/* 905 */         if (this.reader != null) {
/* 906 */           this.reader.close();
/* 907 */           this.reader = null;
/*     */         }
/*     */ 
/* 910 */         this.reader = new BufferedReader(new FileReader(this.file));
/* 911 */         return true;
/*     */       }
/*     */ 
/*     */       private void readNext() throws IOException
/*     */       {
/* 916 */         this.line = null;
/*     */         try {
/* 918 */           if ((this.reader != null) && ((this.line = this.reader.readLine()) != null)) {
/*     */             return;
/*     */           }
/* 921 */           if (this.line == null)
/*     */           {
/* 923 */             if (openFile())
/* 924 */               readNext();
/*     */           }
/*     */         }
/*     */         finally {
/* 928 */           if (!hasNext())
/* 929 */             close();
/*     */         }
/*     */       }
/*     */ 
/*     */       public boolean hasNext()
/*     */       {
/* 935 */         return this.line != null;
/*     */       }
/*     */ 
/*     */       public String next() {
/* 939 */         String curLine = this.line;
/*     */         try {
/* 941 */           readNext();
/*     */         } catch (IOException e) {
/* 943 */           DataBlockScanner.LOG.info("Could not reade next line in LogHandler : " + StringUtils.stringifyException(e));
/*     */         }
/*     */ 
/* 946 */         return curLine;
/*     */       }
/*     */ 
/*     */       public void remove() {
/* 950 */         throw new RuntimeException("remove() is not supported.");
/*     */       }
/*     */ 
/*     */       public void close() throws IOException {
/* 954 */         if (!this.closed)
/*     */           try {
/* 956 */             if (this.reader != null)
/* 957 */               this.reader.close();
/*     */           }
/*     */           finally {
/* 960 */             this.file = null;
/* 961 */             this.reader = null;
/* 962 */             this.closed = true;
/* 963 */             synchronized (DataBlockScanner.LogFileHandler.this) {
/* 964 */               DataBlockScanner.LogFileHandler.this.numReaders -= 1;
/* 965 */               if ((!$assertionsDisabled) && (DataBlockScanner.LogFileHandler.this.numReaders < 0)) throw new AssertionError();
/*     */             }
/*     */           }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class LogEntry
/*     */   {
/* 388 */     long blockId = -1L;
/* 389 */     long verificationTime = -1L;
/* 390 */     long genStamp = 0L;
/*     */ 
/* 398 */     private static Pattern entryPattern = Pattern.compile("\\G\\s*([^=\\p{Space}]+)=\"(.*?)\"\\s*");
/*     */ 
/*     */     static String newEnry(Block block, long time)
/*     */     {
/* 402 */       return "date=\"" + DataBlockScanner.dateFormat.format(new Date(time)) + "\"\t " + "time=\"" + time + "\"\t " + "genstamp=\"" + block.getGenerationStamp() + "\"\t " + "id=\"" + block.getBlockId() + "\"";
/*     */     }
/*     */ 
/*     */     static LogEntry parseEntry(String line)
/*     */     {
/* 409 */       LogEntry entry = new LogEntry();
/*     */ 
/* 411 */       Matcher matcher = entryPattern.matcher(line);
/* 412 */       while (matcher.find()) {
/* 413 */         String name = matcher.group(1);
/* 414 */         String value = matcher.group(2);
/*     */         try
/*     */         {
/* 417 */           if (name.equals("id"))
/* 418 */             entry.blockId = Long.valueOf(value).longValue();
/* 419 */           else if (name.equals("time"))
/* 420 */             entry.verificationTime = Long.valueOf(value).longValue();
/* 421 */           else if (name.equals("genstamp"))
/* 422 */             entry.genStamp = Long.valueOf(value).longValue();
/*     */         }
/*     */         catch (NumberFormatException nfe) {
/* 425 */           DataBlockScanner.LOG.warn("Cannot parse line: " + line, nfe);
/* 426 */           return null;
/*     */         }
/*     */       }
/*     */ 
/* 430 */       return entry;
/*     */     }
/*     */   }
/*     */ 
/*     */   static class BlockScanInfo
/*     */     implements Comparable<BlockScanInfo>
/*     */   {
/*     */     Block block;
/* 108 */     long lastScanTime = 0L;
/* 109 */     long lastLogTime = 0L;
/* 110 */     DataBlockScanner.ScanType lastScanType = DataBlockScanner.ScanType.NONE;
/* 111 */     boolean lastScanOk = true;
/*     */ 
/*     */     BlockScanInfo(Block block) {
/* 114 */       this.block = block;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 118 */       return this.block.hashCode();
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other) {
/* 122 */       return ((other instanceof BlockScanInfo)) && (compareTo((BlockScanInfo)other) == 0);
/*     */     }
/*     */ 
/*     */     long getLastScanTime()
/*     */     {
/* 127 */       return this.lastScanType == DataBlockScanner.ScanType.NONE ? 0L : this.lastScanTime;
/*     */     }
/*     */ 
/*     */     public int compareTo(BlockScanInfo other) {
/* 131 */       long t1 = this.lastScanTime;
/* 132 */       long t2 = other.lastScanTime;
/* 133 */       return t1 > t2 ? 1 : t1 < t2 ? -1 : this.block.compareTo(other.block);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static enum ScanType
/*     */   {
/* 101 */     REMOTE_READ, 
/* 102 */     VERIFICATION_SCAN, 
/* 103 */     NONE;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.DataBlockScanner
 * JD-Core Version:    0.6.1
 */
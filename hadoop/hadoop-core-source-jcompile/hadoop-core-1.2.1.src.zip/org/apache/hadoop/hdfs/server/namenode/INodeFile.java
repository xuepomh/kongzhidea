/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.fs.permission.PermissionStatus;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ 
/*     */ class INodeFile extends INode
/*     */ {
/*  30 */   static final FsPermission UMASK = FsPermission.createImmutable((short)73);
/*     */   static final short BLOCKBITS = 48;
/*     */   static final long HEADERMASK = -281474976710656L;
/*     */   protected long header;
/*  41 */   protected BlocksMap.BlockInfo[] blocks = null;
/*     */ 
/*     */   INodeFile(PermissionStatus permissions, int nrBlocks, short replication, long modificationTime, long atime, long preferredBlockSize)
/*     */   {
/*  46 */     this(permissions, new BlocksMap.BlockInfo[nrBlocks], replication, modificationTime, atime, preferredBlockSize);
/*     */   }
/*     */ 
/*     */   protected INodeFile()
/*     */   {
/*  51 */     this.blocks = null;
/*  52 */     this.header = 0L;
/*     */   }
/*     */ 
/*     */   protected INodeFile(PermissionStatus permissions, BlocksMap.BlockInfo[] blklist, short replication, long modificationTime, long atime, long preferredBlockSize)
/*     */   {
/*  58 */     super(permissions, modificationTime, atime);
/*  59 */     setReplication(replication);
/*  60 */     setPreferredBlockSize(preferredBlockSize);
/*  61 */     this.blocks = blklist;
/*     */   }
/*     */ 
/*     */   protected void setPermission(FsPermission permission)
/*     */   {
/*  70 */     super.setPermission(permission.applyUMask(UMASK));
/*     */   }
/*     */ 
/*     */   public boolean isDirectory() {
/*  74 */     return false;
/*     */   }
/*     */ 
/*     */   public short getReplication()
/*     */   {
/*  82 */     return (short)(int)((this.header & 0x0) >> 48);
/*     */   }
/*     */ 
/*     */   public void setReplication(short replication) {
/*  86 */     if (replication <= 0)
/*  87 */       throw new IllegalArgumentException("Unexpected value for the replication");
/*  88 */     this.header = (replication << 48 | this.header & 0xFFFFFFFF);
/*     */   }
/*     */ 
/*     */   public long getPreferredBlockSize()
/*     */   {
/*  96 */     return this.header & 0xFFFFFFFF;
/*     */   }
/*     */ 
/*     */   public void setPreferredBlockSize(long preferredBlkSize)
/*     */   {
/* 101 */     if ((preferredBlkSize < 0L) || (preferredBlkSize > 281474976710655L))
/* 102 */       throw new IllegalArgumentException("Unexpected value for the block size");
/* 103 */     this.header = (this.header & 0x0 | preferredBlkSize & 0xFFFFFFFF);
/*     */   }
/*     */ 
/*     */   BlocksMap.BlockInfo[] getBlocks()
/*     */   {
/* 111 */     return this.blocks;
/*     */   }
/*     */ 
/*     */   void appendBlocks(INodeFile[] inodes, int totalAddedBlocks)
/*     */   {
/* 118 */     int size = this.blocks.length;
/*     */ 
/* 120 */     BlocksMap.BlockInfo[] newlist = new BlocksMap.BlockInfo[size + totalAddedBlocks];
/* 121 */     System.arraycopy(this.blocks, 0, newlist, 0, size);
/*     */ 
/* 123 */     for (INodeFile in : inodes) {
/* 124 */       System.arraycopy(in.blocks, 0, newlist, size, in.blocks.length);
/* 125 */       size += in.blocks.length;
/*     */     }
/*     */ 
/* 128 */     for (BlocksMap.BlockInfo bi : this.blocks) {
/* 129 */       bi.setINode(this);
/*     */     }
/* 131 */     this.blocks = newlist;
/*     */   }
/*     */ 
/*     */   void addBlock(BlocksMap.BlockInfo newblock)
/*     */   {
/* 138 */     if (this.blocks == null) {
/* 139 */       this.blocks = new BlocksMap.BlockInfo[1];
/* 140 */       this.blocks[0] = newblock;
/*     */     } else {
/* 142 */       int size = this.blocks.length;
/* 143 */       BlocksMap.BlockInfo[] newlist = new BlocksMap.BlockInfo[size + 1];
/* 144 */       System.arraycopy(this.blocks, 0, newlist, 0, size);
/* 145 */       newlist[size] = newblock;
/* 146 */       this.blocks = newlist;
/*     */     }
/*     */   }
/*     */ 
/*     */   void setBlock(int idx, BlocksMap.BlockInfo blk)
/*     */   {
/* 154 */     this.blocks[idx] = blk;
/*     */   }
/*     */ 
/*     */   int collectSubtreeBlocksAndClear(List<Block> v) {
/* 158 */     this.parent = null;
/* 159 */     if ((this.blocks != null) && (v != null)) {
/* 160 */       for (BlocksMap.BlockInfo blk : this.blocks) {
/* 161 */         v.add(blk);
/* 162 */         blk.setINode(null);
/*     */       }
/*     */     }
/* 165 */     this.blocks = null;
/* 166 */     return 1;
/*     */   }
/*     */ 
/*     */   long[] computeContentSummary(long[] summary)
/*     */   {
/* 171 */     long bytes = 0L;
/* 172 */     for (Block blk : this.blocks) {
/* 173 */       bytes += blk.getNumBytes();
/*     */     }
/* 175 */     summary[0] += bytes;
/* 176 */     summary[1] += 1L;
/* 177 */     summary[3] += diskspaceConsumed();
/* 178 */     return summary;
/*     */   }
/*     */ 
/*     */   INode.DirCounts spaceConsumedInTree(INode.DirCounts counts)
/*     */   {
/* 185 */     counts.nsCount += 1L;
/* 186 */     counts.dsCount += diskspaceConsumed();
/* 187 */     return counts;
/*     */   }
/*     */ 
/*     */   long diskspaceConsumed() {
/* 191 */     return diskspaceConsumed(this.blocks);
/*     */   }
/*     */ 
/*     */   long diskspaceConsumed(Block[] blkArr) {
/* 195 */     long size = 0L;
/* 196 */     if (blkArr == null) {
/* 197 */       return 0L;
/*     */     }
/* 199 */     for (Block blk : blkArr) {
/* 200 */       if (blk != null) {
/* 201 */         size += blk.getNumBytes();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 207 */     if ((blkArr.length > 0) && (blkArr[(blkArr.length - 1)] != null) && (isUnderConstruction()))
/*     */     {
/* 209 */       size += getPreferredBlockSize() - this.blocks[(this.blocks.length - 1)].getNumBytes();
/*     */     }
/* 211 */     return size * getReplication();
/*     */   }
/*     */ 
/*     */   Block getPenultimateBlock()
/*     */   {
/* 218 */     if ((this.blocks == null) || (this.blocks.length <= 1)) {
/* 219 */       return null;
/*     */     }
/* 221 */     return this.blocks[(this.blocks.length - 2)];
/*     */   }
/*     */ 
/*     */   INodeFileUnderConstruction toINodeFileUnderConstruction(String clientName, String clientMachine, DatanodeDescriptor clientNode)
/*     */     throws IOException
/*     */   {
/* 227 */     if (isUnderConstruction()) {
/* 228 */       return (INodeFileUnderConstruction)this;
/*     */     }
/* 230 */     return new INodeFileUnderConstruction(this.name, getReplication(), this.modificationTime, getPreferredBlockSize(), this.blocks, getPermissionStatus(), clientName, clientMachine, clientNode);
/*     */   }
/*     */ 
/*     */   Block getLastBlock()
/*     */   {
/* 240 */     if ((this.blocks == null) || (this.blocks.length == 0))
/* 241 */       return null;
/* 242 */     return this.blocks[(this.blocks.length - 1)];
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.INodeFile
 * JD-Core Version:    0.6.1
 */
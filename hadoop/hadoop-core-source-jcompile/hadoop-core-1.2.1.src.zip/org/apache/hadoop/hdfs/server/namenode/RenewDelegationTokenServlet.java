/*    */ package org.apache.hadoop.hdfs.server.namenode;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.security.PrivilegedExceptionAction;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ import org.apache.hadoop.security.UserGroupInformation;
/*    */ import org.apache.hadoop.security.token.Token;
/*    */ 
/*    */ public class RenewDelegationTokenServlet extends DfsServlet
/*    */ {
/* 40 */   private static final Log LOG = LogFactory.getLog(RenewDelegationTokenServlet.class);
/*    */   public static final String PATH_SPEC = "/renewDelegationToken";
/*    */   public static final String TOKEN = "token";
/*    */ 
/*    */   protected void doGet(HttpServletRequest req, HttpServletResponse resp)
/*    */     throws ServletException, IOException
/*    */   {
/* 48 */     ServletContext context = getServletContext();
/* 49 */     Configuration conf = (Configuration)context.getAttribute("current.conf");
/*    */     UserGroupInformation ugi;
/*    */     try
/*    */     {
/* 52 */       ugi = getUGI(req, conf);
/*    */     } catch (IOException ioe) {
/* 54 */       LOG.info("Request for token received with no authentication from " + req.getRemoteAddr(), ioe);
/*    */ 
/* 56 */       resp.sendError(403, "Unable to identify or authenticate user");
/*    */ 
/* 58 */       return;
/*    */     }
/* 60 */     final NameNode nn = (NameNode)context.getAttribute("name.node");
/* 61 */     String tokenString = req.getParameter("token");
/* 62 */     if (tokenString == null) {
/* 63 */       resp.sendError(300, "Token to renew not specified");
/*    */     }
/*    */ 
/* 66 */     final Token token = new Token();
/*    */ 
/* 68 */     token.decodeFromUrlString(tokenString);
/*    */     try
/*    */     {
/* 71 */       long result = ((Long)ugi.doAs(new PrivilegedExceptionAction() {
/*    */         public Long run() throws Exception {
/* 73 */           return Long.valueOf(nn.renewDelegationToken(token));
/*    */         }
/*    */       })).longValue();
/*    */ 
/* 76 */       PrintStream os = new PrintStream(resp.getOutputStream());
/* 77 */       os.println(result);
/* 78 */       os.close();
/*    */     }
/*    */     catch (Exception e) {
/* 81 */       String exceptionClass = e.getClass().getCanonicalName();
/* 82 */       String exceptionMsg = e.getLocalizedMessage();
/* 83 */       String strException = exceptionClass + ";" + exceptionMsg;
/* 84 */       LOG.info("Exception while renewing token. Re-throwing. s=" + strException, e);
/*    */ 
/* 86 */       resp.sendError(500, strException);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.RenewDelegationTokenServlet
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.SortedSet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.hdfs.protocol.FSConstants.UpgradeAction;
/*     */ import org.apache.hadoop.hdfs.server.common.HdfsConstants.NodeType;
/*     */ import org.apache.hadoop.hdfs.server.common.IncorrectVersionException;
/*     */ import org.apache.hadoop.hdfs.server.common.UpgradeManager;
/*     */ import org.apache.hadoop.hdfs.server.common.UpgradeObjectCollection;
/*     */ import org.apache.hadoop.hdfs.server.common.UpgradeStatusReport;
/*     */ import org.apache.hadoop.hdfs.server.common.Upgradeable;
/*     */ import org.apache.hadoop.hdfs.server.protocol.UpgradeCommand;
/*     */ 
/*     */ class UpgradeManagerNamenode extends UpgradeManager
/*     */ {
/*     */   public HdfsConstants.NodeType getType()
/*     */   {
/*  45 */     return HdfsConstants.NodeType.NAME_NODE;
/*     */   }
/*     */ 
/*     */   public synchronized boolean startUpgrade()
/*     */     throws IOException
/*     */   {
/*  56 */     if (!this.upgradeState) {
/*  57 */       initializeUpgrade();
/*  58 */       if (!this.upgradeState) return false;
/*     */ 
/*  60 */       FSNamesystem.getFSNamesystem().getFSImage().writeAll();
/*     */     }
/*  62 */     assert (this.currentUpgrades != null) : "currentUpgrades is null";
/*  63 */     this.broadcastCommand = ((Upgradeable)this.currentUpgrades.first()).startUpgrade();
/*  64 */     NameNode.LOG.info("\n   Distributed upgrade for NameNode version " + getUpgradeVersion() + " to current LV " + -41 + " is started.");
/*     */ 
/*  67 */     return true;
/*     */   }
/*     */ 
/*     */   synchronized UpgradeCommand processUpgradeCommand(UpgradeCommand command) throws IOException
/*     */   {
/*  72 */     NameNode.LOG.debug("\n   Distributed upgrade for NameNode version " + getUpgradeVersion() + " to current LV " + -41 + " is processing upgrade command: " + command.getAction() + " status = " + getUpgradeStatus() + "%");
/*     */ 
/*  76 */     if (this.currentUpgrades == null) {
/*  77 */       NameNode.LOG.info("Ignoring upgrade command: " + command.getAction() + " version " + command.getVersion() + ". No distributed upgrades are currently running on the NameNode");
/*     */ 
/*  80 */       return null;
/*     */     }
/*  82 */     UpgradeObjectNamenode curUO = (UpgradeObjectNamenode)this.currentUpgrades.first();
/*  83 */     if (command.getVersion() != curUO.getVersion()) {
/*  84 */       throw new IncorrectVersionException(command.getVersion(), "UpgradeCommand", curUO.getVersion());
/*     */     }
/*  86 */     UpgradeCommand reply = curUO.processUpgradeCommand(command);
/*  87 */     if (curUO.getUpgradeStatus() < 100) {
/*  88 */       return reply;
/*     */     }
/*     */ 
/*  91 */     curUO.completeUpgrade();
/*  92 */     NameNode.LOG.info("\n   Distributed upgrade for NameNode version " + curUO.getVersion() + " to current LV " + -41 + " is complete.");
/*     */ 
/*  96 */     this.currentUpgrades.remove(curUO);
/*  97 */     if (this.currentUpgrades.isEmpty()) {
/*  98 */       completeUpgrade();
/*     */     } else {
/* 100 */       curUO = (UpgradeObjectNamenode)this.currentUpgrades.first();
/* 101 */       this.broadcastCommand = curUO.startUpgrade();
/*     */     }
/* 103 */     return reply;
/*     */   }
/*     */ 
/*     */   public synchronized void completeUpgrade() throws IOException
/*     */   {
/* 108 */     setUpgradeState(false, -41);
/* 109 */     FSNamesystem.getFSNamesystem().getFSImage().writeAll();
/* 110 */     this.currentUpgrades = null;
/* 111 */     this.broadcastCommand = null;
/* 112 */     FSNamesystem.getFSNamesystem().leaveSafeMode(false);
/*     */   }
/*     */ 
/*     */   UpgradeStatusReport distributedUpgradeProgress(FSConstants.UpgradeAction action) throws IOException
/*     */   {
/* 117 */     boolean isFinalized = false;
/* 118 */     if (this.currentUpgrades == null) {
/* 119 */       FSImage fsimage = FSNamesystem.getFSNamesystem().getFSImage();
/* 120 */       isFinalized = fsimage.isUpgradeFinalized();
/* 121 */       if (isFinalized)
/* 122 */         return null;
/* 123 */       return new UpgradeStatusReport(fsimage.getLayoutVersion(), (short)101, isFinalized);
/*     */     }
/*     */ 
/* 126 */     UpgradeObjectNamenode curUO = (UpgradeObjectNamenode)this.currentUpgrades.first();
/* 127 */     boolean details = false;
/* 128 */     switch (1.$SwitchMap$org$apache$hadoop$hdfs$protocol$FSConstants$UpgradeAction[action.ordinal()]) {
/*     */     case 1:
/* 130 */       break;
/*     */     case 2:
/* 132 */       details = true;
/* 133 */       break;
/*     */     case 3:
/* 135 */       curUO.forceProceed();
/*     */     }
/* 137 */     return curUO.getUpgradeStatusReport(details);
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws IOException {
/* 141 */     UpgradeManagerNamenode um = new UpgradeManagerNamenode();
/*     */ 
/* 143 */     SortedSet uos = UpgradeObjectCollection.getDistributedUpgrades(-4, HdfsConstants.NodeType.NAME_NODE);
/*     */ 
/* 145 */     System.out.println(uos.size());
/* 146 */     um.startUpgrade();
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.UpgradeManagerNamenode
 * JD-Core Version:    0.6.1
 */
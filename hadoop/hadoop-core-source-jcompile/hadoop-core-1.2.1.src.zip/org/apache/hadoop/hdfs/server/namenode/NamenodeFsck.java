/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.hdfs.BlockReader;
/*     */ import org.apache.hadoop.hdfs.DFSClient;
/*     */ import org.apache.hadoop.hdfs.DFSClient.RemoteBlockReader;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.hdfs.protocol.DirectoryListing;
/*     */ import org.apache.hadoop.hdfs.protocol.HdfsFileStatus;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlock;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlocks;
/*     */ import org.apache.hadoop.net.NetUtils;
/*     */ import org.apache.hadoop.net.NetworkTopology;
/*     */ import org.apache.hadoop.net.NodeBase;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ 
/*     */ public class NamenodeFsck
/*     */ {
/*  66 */   public static final Log LOG = LogFactory.getLog(NameNode.class.getName());
/*     */   public static final String CORRUPT_STATUS = "is CORRUPT";
/*     */   public static final String HEALTHY_STATUS = "is HEALTHY";
/*     */   public static final String NONEXISTENT_STATUS = "does not exist";
/*     */   public static final String FAILURE_STATUS = "FAILED";
/*     */   private final NameNode namenode;
/*     */   private final NetworkTopology networktopology;
/*     */   private final int totalDatanodes;
/*     */   private final short minReplication;
/*     */   private final InetAddress remoteAddress;
/*  80 */   private String lostFound = null;
/*  81 */   private boolean lfInited = false;
/*  82 */   private boolean lfInitedOk = false;
/*  83 */   private boolean showFiles = false;
/*  84 */   private boolean showOpenFiles = false;
/*  85 */   private boolean showBlocks = false;
/*  86 */   private boolean showLocations = false;
/*  87 */   private boolean showRacks = false;
/*     */ 
/*  94 */   private boolean doMove = false;
/*     */ 
/* 101 */   private boolean doDelete = false;
/*     */ 
/* 103 */   private String path = "/";
/*     */   private final Configuration conf;
/*     */   private final PrintWriter out;
/* 513 */   Random r = new Random();
/*     */ 
/*     */   NamenodeFsck(Configuration conf, NameNode namenode, NetworkTopology networktopology, Map<String, String[]> pmap, PrintWriter out, int totalDatanodes, short minReplication, InetAddress remoteAddress)
/*     */   {
/* 123 */     this.conf = conf;
/* 124 */     this.namenode = namenode;
/* 125 */     this.networktopology = networktopology;
/* 126 */     this.out = out;
/* 127 */     this.totalDatanodes = totalDatanodes;
/* 128 */     this.minReplication = minReplication;
/* 129 */     this.remoteAddress = remoteAddress;
/*     */ 
/* 131 */     for (Iterator it = pmap.keySet().iterator(); it.hasNext(); ) {
/* 132 */       String key = (String)it.next();
/* 133 */       if (key.equals("path")) this.path = ((String[])pmap.get("path"))[0];
/* 134 */       else if (key.equals("move")) this.doMove = true;
/* 135 */       else if (key.equals("delete")) this.doDelete = true;
/* 136 */       else if (key.equals("files")) this.showFiles = true;
/* 137 */       else if (key.equals("blocks")) this.showBlocks = true;
/* 138 */       else if (key.equals("locations")) this.showLocations = true;
/* 139 */       else if (key.equals("racks")) this.showRacks = true;
/* 140 */       else if (key.equals("openforwrite")) this.showOpenFiles = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void fsck()
/*     */   {
/* 148 */     long startTime = System.currentTimeMillis();
/*     */     try {
/* 150 */       String msg = "FSCK started by " + UserGroupInformation.getCurrentUser() + " from " + this.remoteAddress + " for path " + this.path + " at " + new Date();
/*     */ 
/* 152 */       LOG.info(msg);
/* 153 */       this.out.println(msg);
/* 154 */       this.namenode.getNamesystem().logFsckEvent(this.path, this.remoteAddress);
/* 155 */       Result res = new Result(this.conf, null);
/* 156 */       HdfsFileStatus file = this.namenode.getFileInfo(this.path);
/* 157 */       if (file != null) {
/* 158 */         check(this.path, file, res);
/*     */ 
/* 160 */         this.out.println(res);
/* 161 */         this.out.println(" Number of data-nodes:\t\t" + this.totalDatanodes);
/* 162 */         this.out.println(" Number of racks:\t\t" + this.networktopology.getNumOfRacks());
/*     */ 
/* 164 */         this.out.println("FSCK ended at " + new Date() + " in " + (System.currentTimeMillis() - startTime) + " milliseconds");
/*     */ 
/* 171 */         if (res.isHealthy())
/* 172 */           this.out.print("\n\nThe filesystem under path '" + this.path + "' " + "is HEALTHY");
/*     */         else
/* 174 */           this.out.print("\n\nThe filesystem under path '" + this.path + "' " + "is CORRUPT");
/*     */       }
/*     */       else {
/* 177 */         this.out.print("\n\nPath '" + this.path + "' " + "does not exist");
/*     */       }
/*     */     } catch (Exception e) {
/* 180 */       String errMsg = "Fsck on path '" + this.path + "' " + "FAILED";
/* 181 */       LOG.warn(errMsg, e);
/* 182 */       this.out.println("FSCK ended at " + new Date() + " in " + (System.currentTimeMillis() - startTime) + " milliseconds");
/*     */ 
/* 184 */       this.out.println(e.getMessage());
/* 185 */       this.out.print("\n\n" + errMsg);
/*     */     } finally {
/* 187 */       this.out.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void check(String parent, HdfsFileStatus file, Result res) throws IOException {
/* 192 */     String path = file.getFullName(parent);
/* 193 */     boolean isOpen = false;
/*     */ 
/* 195 */     if (file.isDir()) {
/* 196 */       byte[] lastReturnedName = HdfsFileStatus.EMPTY_NAME;
/*     */ 
/* 198 */       if (this.showFiles) {
/* 199 */         this.out.println(path + " <dir>");
/* 201 */       }Result.access$108(res);
/*     */       DirectoryListing thisListing;
/*     */       do { assert (lastReturnedName != null);
/* 204 */         thisListing = this.namenode.getListing(path, lastReturnedName);
/* 205 */         if (thisListing == null) {
/* 206 */           return;
/*     */         }
/* 208 */         HdfsFileStatus[] files = thisListing.getPartialListing();
/* 209 */         for (int i = 0; i < files.length; i++) {
/* 210 */           check(path, files[i], res);
/*     */         }
/* 212 */         lastReturnedName = thisListing.getLastName(); }
/* 213 */       while (thisListing.hasMore());
/* 214 */       return;
/*     */     }
/* 216 */     long fileLen = file.getLen();
/*     */ 
/* 219 */     LocatedBlocks blocks = this.namenode.getNamesystem().getBlockLocations(path, 0L, fileLen, false, false, false);
/*     */ 
/* 221 */     if (blocks == null) {
/* 222 */       return;
/*     */     }
/* 224 */     isOpen = blocks.isUnderConstruction();
/* 225 */     if ((isOpen) && (!this.showOpenFiles))
/*     */     {
/* 227 */       Result.access$214(res, fileLen);
/* 228 */       Result.access$314(res, blocks.locatedBlockCount());
/* 229 */       Result.access$408(res);
/* 230 */       return;
/*     */     }
/* 232 */     Result.access$508(res);
/* 233 */     Result.access$614(res, fileLen);
/* 234 */     Result.access$714(res, blocks.locatedBlockCount());
/* 235 */     if ((this.showOpenFiles) && (isOpen)) {
/* 236 */       this.out.print(path + " " + fileLen + " bytes, " + blocks.locatedBlockCount() + " block(s), OPENFORWRITE: ");
/*     */     }
/* 238 */     else if (this.showFiles) {
/* 239 */       this.out.print(path + " " + fileLen + " bytes, " + blocks.locatedBlockCount() + " block(s): ");
/*     */     }
/*     */     else {
/* 242 */       this.out.print('.');
/*     */     }
/* 244 */     if (res.totalFiles % 100L == 0L) { this.out.println(); this.out.flush(); }
/* 245 */     int missing = 0;
/* 246 */     int corrupt = 0;
/* 247 */     long missize = 0L;
/* 248 */     int underReplicatedPerFile = 0;
/* 249 */     int misReplicatedPerFile = 0;
/* 250 */     StringBuffer report = new StringBuffer();
/* 251 */     int i = 0;
/* 252 */     for (LocatedBlock lBlk : blocks.getLocatedBlocks()) {
/* 253 */       Block block = lBlk.getBlock();
/* 254 */       boolean isCorrupt = lBlk.isCorrupt();
/* 255 */       String blkName = block.toString();
/* 256 */       DatanodeInfo[] locs = lBlk.getLocations();
/* 257 */       Result.access$814(res, locs.length);
/* 258 */       short targetFileReplication = file.getReplication();
/* 259 */       if (locs.length > targetFileReplication) {
/* 260 */         Result.access$914(res, locs.length - targetFileReplication);
/* 261 */         Result.access$1014(res, 1L);
/*     */       }
/*     */ 
/* 264 */       if (isCorrupt) {
/* 265 */         corrupt++;
/* 266 */         Result.access$1108(res);
/* 267 */         this.out.print("\n" + path + ": CORRUPT block " + block.getBlockName() + "\n");
/*     */       }
/* 269 */       if (locs.length >= this.minReplication)
/* 270 */         Result.access$1208(res);
/* 271 */       if ((locs.length < targetFileReplication) && (locs.length > 0)) {
/* 272 */         Result.access$1314(res, targetFileReplication - locs.length);
/* 273 */         Result.access$1414(res, 1L);
/* 274 */         underReplicatedPerFile++;
/* 275 */         if (!this.showFiles) {
/* 276 */           this.out.print("\n" + path + ": ");
/*     */         }
/* 278 */         this.out.println(" Under replicated " + block + ". Target Replicas is " + targetFileReplication + " but found " + locs.length + " replica(s).");
/*     */       }
/*     */ 
/* 284 */       int missingRacks = BlockPlacementPolicy.getInstance(this.conf, null, this.networktopology).verifyBlockPlacement(path, lBlk, Math.min(2, targetFileReplication));
/*     */ 
/* 286 */       if (missingRacks > 0) {
/* 287 */         Result.access$1508(res);
/* 288 */         misReplicatedPerFile++;
/* 289 */         if (!this.showFiles) {
/* 290 */           if (underReplicatedPerFile == 0)
/* 291 */             this.out.println();
/* 292 */           this.out.print(path + ": ");
/*     */         }
/* 294 */         this.out.println(" Replica placement policy is violated for " + block + ". Block should be additionally replicated on " + missingRacks + " more rack(s).");
/*     */       }
/*     */ 
/* 299 */       report.append(i + ". " + blkName + " len=" + block.getNumBytes());
/* 300 */       if (locs.length == 0) {
/* 301 */         report.append(" MISSING!");
/* 302 */         res.addMissing(block.toString(), block.getNumBytes());
/* 303 */         missing++;
/* 304 */         missize += block.getNumBytes();
/*     */       } else {
/* 306 */         report.append(" repl=" + locs.length);
/* 307 */         if ((this.showLocations) || (this.showRacks)) {
/* 308 */           StringBuffer sb = new StringBuffer("[");
/* 309 */           for (int j = 0; j < locs.length; j++) {
/* 310 */             if (j > 0) sb.append(", ");
/* 311 */             if (this.showRacks)
/* 312 */               sb.append(NodeBase.getPath(locs[j]));
/*     */             else
/* 314 */               sb.append(locs[j]);
/*     */           }
/* 316 */           sb.append(']');
/* 317 */           report.append(" " + sb.toString());
/*     */         }
/*     */       }
/* 320 */       report.append('\n');
/* 321 */       i++;
/*     */     }
/* 323 */     if ((missing > 0) || (corrupt > 0)) {
/* 324 */       if ((!this.showFiles) && (missing > 0)) {
/* 325 */         this.out.print("\n" + path + ": MISSING " + missing + " blocks of total size " + missize + " B.");
/*     */       }
/*     */ 
/* 328 */       Result.access$1608(res);
/*     */       try {
/* 330 */         if ((this.doMove) && 
/* 331 */           (!isOpen)) {
/* 332 */           copyBlocksToLostFound(parent, file, blocks);
/*     */         }
/*     */ 
/* 335 */         if ((this.doDelete) && 
/* 336 */           (!isOpen)) {
/* 337 */           LOG.warn("\n - deleting corrupted file " + path);
/* 338 */           this.namenode.delete(path, true);
/*     */         }
/*     */       }
/*     */       catch (IOException e) {
/* 342 */         LOG.error("error processing " + path + ": " + e.toString());
/*     */       }
/*     */     }
/* 345 */     if (this.showFiles) {
/* 346 */       if (missing > 0)
/* 347 */         this.out.print(" MISSING " + missing + " blocks of total size " + missize + " B\n");
/* 348 */       else if ((underReplicatedPerFile == 0) && (misReplicatedPerFile == 0)) {
/* 349 */         this.out.print(" OK\n");
/*     */       }
/* 351 */       if (this.showBlocks)
/* 352 */         this.out.print(report.toString() + "\n");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void copyBlocksToLostFound(String parent, HdfsFileStatus file, LocatedBlocks blocks)
/*     */     throws IOException
/*     */   {
/* 359 */     DFSClient dfs = new DFSClient(NameNode.getAddress(this.conf), this.conf);
/*     */     try {
/* 361 */       if (!this.lfInited) {
/* 362 */         lostFoundInit(dfs);
/*     */       }
/* 364 */       if (!this.lfInitedOk) {
/*     */         return;
/*     */       }
/* 367 */       String fullName = file.getFullName(parent);
/* 368 */       String target = this.lostFound + fullName;
/* 369 */       String errmsg = "Failed to move " + fullName + " to /lost+found";
/*     */       try {
/* 371 */         if (!this.namenode.mkdirs(target, file.getPermission())) {
/* 372 */           LOG.warn(errmsg);
/*     */         }
/*     */         else
/*     */         {
/* 376 */           int chain = 0;
/* 377 */           OutputStream fos = null;
/* 378 */           for (LocatedBlock lBlk : blocks.getLocatedBlocks()) {
/* 379 */             LocatedBlock lblock = lBlk;
/* 380 */             DatanodeInfo[] locs = lblock.getLocations();
/* 381 */             if ((locs == null) || (locs.length == 0)) {
/* 382 */               if (fos != null) {
/* 383 */                 fos.flush();
/* 384 */                 fos.close();
/* 385 */                 fos = null;
/*     */               }
/*     */             }
/*     */             else {
/* 389 */               if (fos == null) {
/* 390 */                 fos = dfs.create(target + "/" + chain, true);
/* 391 */                 if (fos != null)
/* 392 */                   chain++;
/*     */                 else {
/* 394 */                   throw new IOException(errmsg + ": could not store chain " + chain);
/*     */                 }
/*     */               }
/*     */ 
/*     */               try
/*     */               {
/* 400 */                 copyBlock(dfs, lblock, fos);
/*     */               } catch (Exception e) {
/* 402 */                 e.printStackTrace();
/*     */ 
/* 404 */                 LOG.warn(" - could not copy block " + lblock.getBlock() + " to " + target);
/* 405 */                 fos.flush();
/* 406 */                 fos.close();
/* 407 */                 fos = null;
/*     */               }
/*     */             }
/*     */           }
/* 410 */           if (fos != null) fos.close();
/* 411 */           LOG.warn("\n - copied corrupted file " + fullName + " to /lost+found");
/*     */         }
/*     */       } catch (Exception e) { e.printStackTrace();
/* 414 */         LOG.warn(errmsg + ": " + e.getMessage()); }
/*     */     }
/*     */     finally {
/* 417 */       dfs.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void copyBlock(DFSClient dfs, LocatedBlock lblock, OutputStream fos)
/*     */     throws Exception
/*     */   {
/* 428 */     int failures = 0;
/* 429 */     InetSocketAddress targetAddr = null;
/* 430 */     TreeSet deadNodes = new TreeSet();
/* 431 */     Socket s = null;
/* 432 */     BlockReader blockReader = null;
/* 433 */     Block block = lblock.getBlock();
/*     */ 
/* 435 */     while (s == null)
/*     */     {
/*     */       DatanodeInfo chosenNode;
/*     */       try {
/* 439 */         chosenNode = bestNode(dfs, lblock.getLocations(), deadNodes);
/* 440 */         targetAddr = NetUtils.createSocketAddr(chosenNode.getName());
/*     */       } catch (IOException ie) {
/* 442 */         if (failures >= 3) {
/* 443 */           throw new IOException("Could not obtain block " + lblock);
/*     */         }
/* 445 */         LOG.info("Could not obtain block from any node:  " + ie);
/*     */         try {
/* 447 */           Thread.sleep(10000L);
/*     */         } catch (InterruptedException iex) {
/*     */         }
/* 450 */         deadNodes.clear();
/* 451 */         failures++;
/* 452 */       }continue;
/*     */       try
/*     */       {
/* 455 */         s = new Socket();
/* 456 */         s.connect(targetAddr, 60000);
/* 457 */         s.setSoTimeout(60000);
/*     */ 
/* 459 */         blockReader = DFSClient.RemoteBlockReader.newBlockReader(s, targetAddr.toString() + ":" + block.getBlockId(), block.getBlockId(), lblock.getBlockToken(), block.getGenerationStamp(), 0L, -1L, this.conf.getInt("io.file.buffer.size", 4096));
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/* 470 */         LOG.info("Failed to connect to " + targetAddr + ":" + ex);
/* 471 */         deadNodes.add(chosenNode);
/* 472 */         if (s != null)
/*     */           try {
/* 474 */             s.close();
/*     */           }
/*     */           catch (IOException iex) {
/*     */           }
/* 478 */         s = null;
/*     */       }
/*     */     }
/* 481 */     if (blockReader == null) {
/* 482 */       throw new Exception("Could not open data stream for " + lblock.getBlock());
/*     */     }
/* 484 */     byte[] buf = new byte[1024];
/* 485 */     int cnt = 0;
/* 486 */     boolean success = true;
/* 487 */     long bytesRead = 0L;
/*     */     try {
/* 489 */       while ((cnt = blockReader.read(buf, 0, buf.length)) > 0) {
/* 490 */         fos.write(buf, 0, cnt);
/* 491 */         bytesRead += cnt;
/*     */       }
/* 493 */       if (bytesRead != block.getNumBytes())
/* 494 */         throw new IOException("Recorded block size is " + block.getNumBytes() + ", but datanode returned " + bytesRead + " bytes");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 498 */       e.printStackTrace();
/* 499 */       success = false; } finally {
/*     */       try {
/* 501 */         s.close(); } catch (Exception e1) {  }
/*     */     }
/* 503 */     if (!success)
/* 504 */       throw new Exception("Could not copy block data for " + lblock.getBlock());
/*     */   }
/*     */ 
/*     */   private DatanodeInfo bestNode(DFSClient dfs, DatanodeInfo[] nodes, TreeSet<DatanodeInfo> deadNodes)
/*     */     throws IOException
/*     */   {
/* 516 */     if ((nodes == null) || (nodes.length - deadNodes.size() < 1))
/*     */     {
/* 518 */       throw new IOException("No live nodes contain current block");
/*     */     }
/*     */     DatanodeInfo chosenNode;
/*     */     do
/* 522 */       chosenNode = nodes[this.r.nextInt(nodes.length)];
/* 523 */     while (deadNodes.contains(chosenNode));
/* 524 */     return chosenNode;
/*     */   }
/*     */ 
/*     */   private void lostFoundInit(DFSClient dfs) {
/* 528 */     this.lfInited = true;
/*     */     try {
/* 530 */       String lfName = "/lost+found";
/*     */ 
/* 532 */       if (!dfs.exists(lfName)) {
/* 533 */         this.lfInitedOk = dfs.mkdirs(lfName);
/* 534 */         this.lostFound = lfName;
/* 535 */       } else if (!dfs.isDirectory(lfName)) {
/* 536 */         LOG.warn("Cannot use /lost+found : a regular file with this name exists.");
/* 537 */         this.lfInitedOk = false;
/*     */       } else {
/* 539 */         this.lostFound = lfName;
/* 540 */         this.lfInitedOk = true;
/*     */       }
/*     */     } catch (Exception e) {
/* 543 */       e.printStackTrace();
/* 544 */       this.lfInitedOk = false;
/*     */     }
/* 546 */     if (this.lostFound == null) {
/* 547 */       LOG.warn("Cannot initialize /lost+found .");
/* 548 */       this.lfInitedOk = false; }  } 
/* 556 */   private static class Result { private List<String> missingIds = new ArrayList();
/* 557 */     private long missingSize = 0L;
/* 558 */     private long corruptFiles = 0L;
/* 559 */     private long corruptBlocks = 0L;
/* 560 */     private long excessiveReplicas = 0L;
/* 561 */     private long missingReplicas = 0L;
/* 562 */     private long numOverReplicatedBlocks = 0L;
/* 563 */     private long numUnderReplicatedBlocks = 0L;
/* 564 */     private long numMisReplicatedBlocks = 0L;
/* 565 */     private long numMinReplicatedBlocks = 0L;
/* 566 */     private long totalBlocks = 0L;
/* 567 */     private long totalOpenFilesBlocks = 0L;
/* 568 */     private long totalFiles = 0L;
/* 569 */     private long totalOpenFiles = 0L;
/* 570 */     private long totalDirs = 0L;
/* 571 */     private long totalSize = 0L;
/* 572 */     private long totalOpenFilesSize = 0L;
/* 573 */     private long totalReplicas = 0L;
/*     */     final short replication;
/*     */ 
/* 578 */     private Result(Configuration conf) { this.replication = (short)conf.getInt("dfs.replication", 3); }
/*     */ 
/*     */ 
/*     */     boolean isHealthy()
/*     */     {
/* 585 */       return (this.missingIds.size() == 0) && (this.corruptBlocks == 0L);
/*     */     }
/*     */ 
/*     */     void addMissing(String id, long size)
/*     */     {
/* 590 */       this.missingIds.add(id);
/* 591 */       this.missingSize += size;
/*     */     }
/*     */ 
/*     */     float getReplicationFactor()
/*     */     {
/* 596 */       if (this.totalBlocks == 0L)
/* 597 */         return 0.0F;
/* 598 */       return (float)this.totalReplicas / (float)this.totalBlocks;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 603 */       StringBuffer res = new StringBuffer();
/* 604 */       res.append(new StringBuilder().append("Status: ").append(isHealthy() ? "HEALTHY" : "CORRUPT").toString());
/* 605 */       res.append(new StringBuilder().append("\n Total size:\t").append(this.totalSize).append(" B").toString());
/* 606 */       if (this.totalOpenFilesSize != 0L)
/* 607 */         res.append(new StringBuilder().append(" (Total open files size: ").append(this.totalOpenFilesSize).append(" B)").toString());
/* 608 */       res.append(new StringBuilder().append("\n Total dirs:\t").append(this.totalDirs).toString());
/* 609 */       res.append(new StringBuilder().append("\n Total files:\t").append(this.totalFiles).toString());
/* 610 */       if (this.totalOpenFiles != 0L) {
/* 611 */         res.append(new StringBuilder().append(" (Files currently being written: ").append(this.totalOpenFiles).append(")").toString());
/*     */       }
/* 613 */       res.append(new StringBuilder().append("\n Total blocks (validated):\t").append(this.totalBlocks).toString());
/* 614 */       if (this.totalBlocks > 0L) res.append(new StringBuilder().append(" (avg. block size ").append(this.totalSize / this.totalBlocks).append(" B)").toString());
/*     */ 
/* 616 */       if (this.totalOpenFilesBlocks != 0L) {
/* 617 */         res.append(new StringBuilder().append(" (Total open file blocks (not validated): ").append(this.totalOpenFilesBlocks).append(")").toString());
/*     */       }
/* 619 */       if (this.corruptFiles > 0L) {
/* 620 */         res.append("\n  ********************************");
/* 621 */         res.append(new StringBuilder().append("\n  CORRUPT FILES:\t").append(this.corruptFiles).toString());
/* 622 */         if (this.missingSize > 0L) {
/* 623 */           res.append(new StringBuilder().append("\n  MISSING BLOCKS:\t").append(this.missingIds.size()).toString());
/* 624 */           res.append(new StringBuilder().append("\n  MISSING SIZE:\t\t").append(this.missingSize).append(" B").toString());
/*     */         }
/* 626 */         if (this.corruptBlocks > 0L) {
/* 627 */           res.append(new StringBuilder().append("\n  CORRUPT BLOCKS: \t").append(this.corruptBlocks).toString());
/*     */         }
/* 629 */         res.append("\n  ********************************");
/*     */       }
/* 631 */       res.append(new StringBuilder().append("\n Minimally replicated blocks:\t").append(this.numMinReplicatedBlocks).toString());
/* 632 */       if (this.totalBlocks > 0L) res.append(new StringBuilder().append(" (").append((float)(this.numMinReplicatedBlocks * 100L) / (float)this.totalBlocks).append(" %)").toString());
/* 633 */       res.append(new StringBuilder().append("\n Over-replicated blocks:\t").append(this.numOverReplicatedBlocks).toString());
/* 634 */       if (this.totalBlocks > 0L) res.append(new StringBuilder().append(" (").append((float)(this.numOverReplicatedBlocks * 100L) / (float)this.totalBlocks).append(" %)").toString());
/* 635 */       res.append(new StringBuilder().append("\n Under-replicated blocks:\t").append(this.numUnderReplicatedBlocks).toString());
/* 636 */       if (this.totalBlocks > 0L) res.append(new StringBuilder().append(" (").append((float)(this.numUnderReplicatedBlocks * 100L) / (float)this.totalBlocks).append(" %)").toString());
/* 637 */       res.append(new StringBuilder().append("\n Mis-replicated blocks:\t\t").append(this.numMisReplicatedBlocks).toString());
/* 638 */       if (this.totalBlocks > 0L) res.append(new StringBuilder().append(" (").append((float)(this.numMisReplicatedBlocks * 100L) / (float)this.totalBlocks).append(" %)").toString());
/* 639 */       res.append(new StringBuilder().append("\n Default replication factor:\t").append(this.replication).toString());
/* 640 */       res.append(new StringBuilder().append("\n Average block replication:\t").append(getReplicationFactor()).toString());
/* 641 */       res.append(new StringBuilder().append("\n Corrupt blocks:\t\t").append(this.corruptBlocks).toString());
/* 642 */       res.append(new StringBuilder().append("\n Missing replicas:\t\t").append(this.missingReplicas).toString());
/* 643 */       if (this.totalReplicas > 0L) res.append(new StringBuilder().append(" (").append((float)(this.missingReplicas * 100L) / (float)this.totalReplicas).append(" %)").toString());
/* 644 */       return res.toString();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.NamenodeFsck
 * JD-Core Version:    0.6.1
 */
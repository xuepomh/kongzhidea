/*    */ package org.apache.hadoop.hdfs.server.namenode;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class SafeModeException extends IOException
/*    */ {
/*    */   public SafeModeException(String text, FSNamesystem.SafeModeInfo mode)
/*    */   {
/* 31 */     super(text + ". Name node is in safe mode.\n" + mode.getTurnOffTip());
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.SafeModeException
 * JD-Core Version:    0.6.1
 */
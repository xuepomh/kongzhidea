package org.apache.hadoop.hdfs.server.namenode;

public abstract interface FSClusterStats
{
  public abstract int getTotalLoad();

  public abstract boolean shouldAvoidStaleDataNodesForWrite();
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.FSClusterStats
 * JD-Core Version:    0.6.1
 */
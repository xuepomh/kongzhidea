/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Queue;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.hdfs.protocol.BlockListAsLongs;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeID;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo.AdminStates;
/*     */ import org.apache.hadoop.hdfs.server.protocol.BlockCommand;
/*     */ import org.apache.hadoop.io.Text;
/*     */ import org.apache.hadoop.io.UTF8;
/*     */ import org.apache.hadoop.io.WritableUtils;
/*     */ 
/*     */ public class DatanodeDescriptor extends DatanodeInfo
/*     */ {
/*  51 */   DecommissioningStatus decommissioningStatus = new DecommissioningStatus();
/*     */ 
/*  90 */   private volatile BlocksMap.BlockInfo blockList = null;
/*     */ 
/*  93 */   protected boolean isAlive = false;
/*  94 */   protected boolean needKeyUpdate = false;
/*     */   private long bandwidth;
/* 105 */   private BlockQueue replicateBlocks = new BlockQueue(null);
/*     */ 
/* 107 */   private BlockQueue recoverBlocks = new BlockQueue(null);
/*     */ 
/* 109 */   private Set<Block> invalidateBlocks = new TreeSet();
/*     */ 
/* 116 */   private int currApproxBlocksScheduled = 0;
/* 117 */   private int prevApproxBlocksScheduled = 0;
/* 118 */   private long lastBlocksScheduledRollTime = 0L;
/*     */   private static final int BLOCKS_SCHEDULED_ROLL_INTERVAL = 600000;
/* 122 */   private boolean firstBlockReport = true;
/*     */ 
/*     */   public DatanodeDescriptor()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DatanodeDescriptor(DatanodeID nodeID)
/*     */   {
/* 131 */     this(nodeID, 0L, 0L, 0L, 0);
/*     */   }
/*     */ 
/*     */   public DatanodeDescriptor(DatanodeID nodeID, String networkLocation)
/*     */   {
/* 141 */     this(nodeID, networkLocation, null);
/*     */   }
/*     */ 
/*     */   public DatanodeDescriptor(DatanodeID nodeID, String networkLocation, String hostName)
/*     */   {
/* 153 */     this(nodeID, networkLocation, hostName, 0L, 0L, 0L, 0);
/*     */   }
/*     */ 
/*     */   public DatanodeDescriptor(DatanodeID nodeID, long capacity, long dfsUsed, long remaining, int xceiverCount)
/*     */   {
/* 169 */     super(nodeID);
/* 170 */     updateHeartbeat(capacity, dfsUsed, remaining, xceiverCount);
/*     */   }
/*     */ 
/*     */   public DatanodeDescriptor(DatanodeID nodeID, String networkLocation, String hostName, long capacity, long dfsUsed, long remaining, int xceiverCount)
/*     */   {
/* 189 */     super(nodeID, networkLocation, hostName);
/* 190 */     updateHeartbeat(capacity, dfsUsed, remaining, xceiverCount);
/*     */   }
/*     */ 
/*     */   boolean addBlock(BlocksMap.BlockInfo b)
/*     */   {
/* 198 */     if (!b.addNode(this)) {
/* 199 */       return false;
/*     */     }
/* 201 */     this.blockList = b.listInsert(this.blockList, this);
/* 202 */     return true;
/*     */   }
/*     */ 
/*     */   boolean removeBlock(BlocksMap.BlockInfo b)
/*     */   {
/* 210 */     this.blockList = b.listRemove(this.blockList, this);
/* 211 */     return b.removeNode(this);
/*     */   }
/*     */ 
/*     */   void moveBlockToHead(BlocksMap.BlockInfo b)
/*     */   {
/* 218 */     this.blockList = b.listRemove(this.blockList, this);
/* 219 */     this.blockList = b.listInsert(this.blockList, this);
/*     */   }
/*     */ 
/*     */   void resetBlocks() {
/* 223 */     this.capacity = 0L;
/* 224 */     this.remaining = 0L;
/* 225 */     this.dfsUsed = 0L;
/* 226 */     this.xceiverCount = 0;
/* 227 */     this.blockList = null;
/* 228 */     this.invalidateBlocks.clear();
/*     */   }
/*     */ 
/*     */   public int numBlocks() {
/* 232 */     return this.blockList == null ? 0 : this.blockList.listCount(this);
/*     */   }
/*     */ 
/*     */   void updateHeartbeat(long capacity, long dfsUsed, long remaining, int xceiverCount)
/*     */   {
/* 239 */     this.capacity = capacity;
/* 240 */     this.dfsUsed = dfsUsed;
/* 241 */     this.remaining = remaining;
/* 242 */     this.lastUpdate = System.currentTimeMillis();
/* 243 */     this.xceiverCount = xceiverCount;
/* 244 */     rollBlocksScheduled(this.lastUpdate);
/*     */   }
/*     */ 
/*     */   Iterator<Block> getBlockIterator()
/*     */   {
/* 275 */     return new BlockIterator(this.blockList, this);
/*     */   }
/*     */ 
/*     */   void addBlockToBeReplicated(Block block, DatanodeDescriptor[] targets)
/*     */   {
/* 282 */     assert ((block != null) && (targets != null) && (targets.length > 0));
/* 283 */     this.replicateBlocks.offer(block, targets);
/*     */   }
/*     */ 
/*     */   void addBlockToBeRecovered(Block block, DatanodeDescriptor[] targets)
/*     */   {
/* 290 */     assert ((block != null) && (targets != null) && (targets.length > 0));
/* 291 */     this.recoverBlocks.offer(block, targets);
/*     */   }
/*     */ 
/*     */   void addBlocksToBeInvalidated(List<Block> blocklist)
/*     */   {
/* 298 */     assert ((blocklist != null) && (blocklist.size() > 0));
/* 299 */     synchronized (this.invalidateBlocks) {
/* 300 */       for (Block blk : blocklist)
/* 301 */         this.invalidateBlocks.add(blk);
/*     */     }
/*     */   }
/*     */ 
/*     */   int getNumberOfBlocksToBeReplicated()
/*     */   {
/* 310 */     return this.replicateBlocks.size();
/*     */   }
/*     */ 
/*     */   int getNumberOfBlocksToBeInvalidated()
/*     */   {
/* 318 */     synchronized (this.invalidateBlocks) {
/* 319 */       return this.invalidateBlocks.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   BlockCommand getReplicationCommand(int maxTransfers) {
/* 324 */     List blocktargetlist = this.replicateBlocks.poll(maxTransfers);
/* 325 */     return blocktargetlist == null ? null : new BlockCommand(1, blocktargetlist);
/*     */   }
/*     */ 
/*     */   BlockCommand getLeaseRecoveryCommand(int maxTransfers)
/*     */   {
/* 330 */     List blocktargetlist = this.recoverBlocks.poll(maxTransfers);
/* 331 */     return blocktargetlist == null ? null : new BlockCommand(6, blocktargetlist);
/*     */   }
/*     */ 
/*     */   BlockCommand getInvalidateBlocks(int maxblocks)
/*     */   {
/* 339 */     Block[] deleteList = getBlockArray(this.invalidateBlocks, maxblocks);
/* 340 */     return deleteList == null ? null : new BlockCommand(2, deleteList);
/*     */   }
/*     */ 
/*     */   private static Block[] getBlockArray(Collection<Block> blocks, int max)
/*     */   {
/* 345 */     Block[] blockarray = null;
/* 346 */     synchronized (blocks) {
/* 347 */       int available = blocks.size();
/* 348 */       int n = available;
/* 349 */       if ((max > 0) && (n > 0)) {
/* 350 */         if (max < n) {
/* 351 */           n = max;
/*     */         }
/*     */ 
/* 354 */         blockarray = new Block[n];
/*     */ 
/* 357 */         Iterator e = blocks.iterator();
/* 358 */         int blockCount = 0;
/*     */ 
/* 360 */         while ((blockCount < n) && (e.hasNext()))
/*     */         {
/* 362 */           blockarray[(blockCount++)] = ((Block)e.next());
/*     */ 
/* 366 */           if (n < available) {
/* 367 */             e.remove();
/*     */           }
/*     */         }
/* 370 */         assert (blockarray.length == n);
/*     */ 
/* 374 */         if (n == available) {
/* 375 */           blocks.clear();
/*     */         }
/*     */       }
/*     */     }
/* 379 */     return blockarray;
/*     */   }
/*     */ 
/*     */   void reportDiff(BlocksMap blocksMap, BlockListAsLongs newReport, Collection<Block> toAdd, Collection<Block> toRemove, Collection<Block> toInvalidate)
/*     */   {
/* 389 */     BlocksMap.BlockInfo delimiter = new BlocksMap.BlockInfo(new Block(), 1);
/* 390 */     boolean added = addBlock(delimiter);
/* 391 */     assert (added) : "Delimiting block cannot be present in the node";
/* 392 */     if (newReport == null) {
/* 393 */       newReport = new BlockListAsLongs(new long[0]);
/*     */     }
/*     */ 
/* 397 */     Block iblk = new Block();
/* 398 */     Block oblk = new Block();
/* 399 */     for (int i = 0; i < newReport.getNumberOfBlocks(); i++) {
/* 400 */       iblk.set(newReport.getBlockId(i), newReport.getBlockLen(i), newReport.getBlockGenStamp(i));
/*     */ 
/* 402 */       BlocksMap.BlockInfo storedBlock = blocksMap.getStoredBlock(iblk);
/* 403 */       if (storedBlock == null)
/*     */       {
/* 408 */         oblk.set(newReport.getBlockId(i), newReport.getBlockLen(i), 1L);
/*     */ 
/* 410 */         storedBlock = blocksMap.getStoredBlock(oblk);
/* 411 */         if ((storedBlock == null) || (storedBlock.getINode() == null) || ((storedBlock.getGenerationStamp() > iblk.getGenerationStamp()) && (!storedBlock.getINode().isUnderConstruction())))
/*     */         {
/* 416 */           storedBlock = null;
/*     */         }
/*     */       }
/* 419 */       if (storedBlock == null)
/*     */       {
/* 421 */         toInvalidate.add(new Block(iblk));
/*     */       }
/* 424 */       else if (storedBlock.findDatanode(this) < 0)
/*     */       {
/* 428 */         if (storedBlock.getNumBytes() != iblk.getNumBytes())
/* 429 */           toAdd.add(new Block(iblk));
/*     */         else {
/* 431 */           toAdd.add(storedBlock);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 436 */         moveBlockToHead(storedBlock);
/*     */       }
/*     */     }
/*     */ 
/* 440 */     Iterator it = new BlockIterator(delimiter.getNext(0), this);
/* 441 */     while (it.hasNext()) {
/* 442 */       BlocksMap.BlockInfo storedBlock = (BlocksMap.BlockInfo)it.next();
/* 443 */       INodeFile file = storedBlock.getINode();
/* 444 */       if ((file == null) || (!file.isUnderConstruction())) {
/* 445 */         toRemove.add(storedBlock);
/*     */       }
/*     */     }
/* 448 */     removeBlock(delimiter);
/*     */   }
/*     */ 
/*     */   void readFieldsFromFSEditLog(DataInput in) throws IOException
/*     */   {
/* 453 */     this.name = UTF8.readString(in);
/* 454 */     this.storageID = UTF8.readString(in);
/* 455 */     this.infoPort = (in.readShort() & 0xFFFF);
/*     */ 
/* 457 */     this.capacity = in.readLong();
/* 458 */     this.dfsUsed = in.readLong();
/* 459 */     this.remaining = in.readLong();
/* 460 */     this.lastUpdate = in.readLong();
/* 461 */     this.xceiverCount = in.readInt();
/* 462 */     this.location = Text.readString(in);
/* 463 */     this.hostName = Text.readString(in);
/* 464 */     setAdminState((DatanodeInfo.AdminStates)WritableUtils.readEnum(in, DatanodeInfo.AdminStates.class));
/*     */   }
/*     */ 
/*     */   public int getBlocksScheduled()
/*     */   {
/* 472 */     return this.currApproxBlocksScheduled + this.prevApproxBlocksScheduled;
/*     */   }
/*     */ 
/*     */   void incBlocksScheduled()
/*     */   {
/* 479 */     this.currApproxBlocksScheduled += 1;
/*     */   }
/*     */ 
/*     */   void decBlocksScheduled()
/*     */   {
/* 486 */     if (this.prevApproxBlocksScheduled > 0)
/* 487 */       this.prevApproxBlocksScheduled -= 1;
/* 488 */     else if (this.currApproxBlocksScheduled > 0)
/* 489 */       this.currApproxBlocksScheduled -= 1;
/*     */   }
/*     */ 
/*     */   private void rollBlocksScheduled(long now)
/*     */   {
/* 498 */     if (now - this.lastBlocksScheduledRollTime > 600000L)
/*     */     {
/* 500 */       this.prevApproxBlocksScheduled = this.currApproxBlocksScheduled;
/* 501 */       this.currApproxBlocksScheduled = 0;
/* 502 */       this.lastBlocksScheduledRollTime = now;
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getBalancerBandwidth()
/*     */   {
/* 558 */     return this.bandwidth;
/*     */   }
/*     */ 
/*     */   public void setBalancerBandwidth(long bandwidth)
/*     */   {
/* 565 */     this.bandwidth = bandwidth;
/*     */   }
/*     */ 
/*     */   boolean firstBlockReport() {
/* 569 */     return this.firstBlockReport;
/*     */   }
/*     */ 
/*     */   void processedBlockReport() {
/* 573 */     this.firstBlockReport = false;
/*     */   }
/*     */ 
/*     */   class DecommissioningStatus
/*     */   {
/*     */     int underReplicatedBlocks;
/*     */     int decommissionOnlyReplicas;
/*     */     int underReplicatedInOpenFiles;
/*     */     long startTime;
/*     */ 
/*     */     DecommissioningStatus()
/*     */     {
/*     */     }
/*     */ 
/*     */     synchronized void set(int underRep, int onlyRep, int underConstruction)
/*     */     {
/* 513 */       if (!DatanodeDescriptor.this.isDecommissionInProgress()) {
/* 514 */         return;
/*     */       }
/* 516 */       this.underReplicatedBlocks = underRep;
/* 517 */       this.decommissionOnlyReplicas = onlyRep;
/* 518 */       this.underReplicatedInOpenFiles = underConstruction;
/*     */     }
/*     */ 
/*     */     synchronized int getUnderReplicatedBlocks() {
/* 522 */       if (!DatanodeDescriptor.this.isDecommissionInProgress()) {
/* 523 */         return 0;
/*     */       }
/* 525 */       return this.underReplicatedBlocks;
/*     */     }
/*     */ 
/*     */     synchronized int getDecommissionOnlyReplicas() {
/* 529 */       if (!DatanodeDescriptor.this.isDecommissionInProgress()) {
/* 530 */         return 0;
/*     */       }
/* 532 */       return this.decommissionOnlyReplicas;
/*     */     }
/*     */ 
/*     */     synchronized int getUnderReplicatedInOpenFiles() {
/* 536 */       if (!DatanodeDescriptor.this.isDecommissionInProgress()) {
/* 537 */         return 0;
/*     */       }
/* 539 */       return this.underReplicatedInOpenFiles;
/*     */     }
/*     */ 
/*     */     synchronized void setStartTime(long time) {
/* 543 */       this.startTime = time;
/*     */     }
/*     */ 
/*     */     synchronized long getStartTime() {
/* 547 */       if (!DatanodeDescriptor.this.isDecommissionInProgress()) {
/* 548 */         return 0L;
/*     */       }
/* 550 */       return this.startTime;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class BlockIterator
/*     */     implements Iterator<Block>
/*     */   {
/*     */     private BlocksMap.BlockInfo current;
/*     */     private DatanodeDescriptor node;
/*     */ 
/*     */     BlockIterator(BlocksMap.BlockInfo head, DatanodeDescriptor dn)
/*     */     {
/* 255 */       this.current = head;
/* 256 */       this.node = dn;
/*     */     }
/*     */ 
/*     */     public boolean hasNext() {
/* 260 */       return this.current != null;
/*     */     }
/*     */ 
/*     */     public BlocksMap.BlockInfo next() {
/* 264 */       BlocksMap.BlockInfo res = this.current;
/* 265 */       this.current = this.current.getNext(this.current.findDatanode(this.node));
/* 266 */       return res;
/*     */     }
/*     */ 
/*     */     public void remove() {
/* 270 */       throw new UnsupportedOperationException("Sorry. can't remove.");
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class BlockQueue
/*     */   {
/*  66 */     private final Queue<DatanodeDescriptor.BlockTargetPair> blockq = new LinkedList();
/*     */ 
/*     */     synchronized int size() {
/*  69 */       return this.blockq.size();
/*     */     }
/*     */ 
/*     */     synchronized boolean offer(Block block, DatanodeDescriptor[] targets) {
/*  73 */       return this.blockq.offer(new DatanodeDescriptor.BlockTargetPair(block, targets));
/*     */     }
/*     */ 
/*     */     synchronized List<DatanodeDescriptor.BlockTargetPair> poll(int numBlocks)
/*     */     {
/*  78 */       if ((numBlocks <= 0) || (this.blockq.isEmpty())) {
/*  79 */         return null;
/*     */       }
/*     */ 
/*  82 */       List results = new ArrayList();
/*  83 */       for (; (!this.blockq.isEmpty()) && (numBlocks > 0); numBlocks--) {
/*  84 */         results.add(this.blockq.poll());
/*     */       }
/*  86 */       return results;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class BlockTargetPair
/*     */   {
/*     */     public final Block block;
/*     */     public final DatanodeDescriptor[] targets;
/*     */ 
/*     */     BlockTargetPair(Block block, DatanodeDescriptor[] targets)
/*     */     {
/*  59 */       this.block = block;
/*  60 */       this.targets = targets;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.DatanodeDescriptor
 * JD-Core Version:    0.6.1
 */
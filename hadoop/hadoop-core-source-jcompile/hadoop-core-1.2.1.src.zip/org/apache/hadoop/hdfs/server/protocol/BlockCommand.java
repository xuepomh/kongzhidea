/*     */ package org.apache.hadoop.hdfs.server.protocol;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.hdfs.server.namenode.DatanodeDescriptor.BlockTargetPair;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.WritableFactories;
/*     */ import org.apache.hadoop.io.WritableFactory;
/*     */ 
/*     */ public class BlockCommand extends DatanodeCommand
/*     */ {
/*     */   Block[] blocks;
/*     */   DatanodeInfo[][] targets;
/*  59 */   private static final DatanodeInfo[][] EMPTY_TARGET = new DatanodeInfo[0][];
/*     */ 
/*     */   public BlockCommand()
/*     */   {
/*     */   }
/*     */ 
/*     */   public BlockCommand(int action, List<DatanodeDescriptor.BlockTargetPair> blocktargetlist)
/*     */   {
/*  48 */     super(action);
/*     */ 
/*  50 */     this.blocks = new Block[blocktargetlist.size()];
/*  51 */     this.targets = new DatanodeInfo[this.blocks.length][];
/*  52 */     for (int i = 0; i < this.blocks.length; i++) {
/*  53 */       DatanodeDescriptor.BlockTargetPair p = (DatanodeDescriptor.BlockTargetPair)blocktargetlist.get(i);
/*  54 */       this.blocks[i] = p.block;
/*  55 */       this.targets[i] = p.targets;
/*     */     }
/*     */   }
/*     */ 
/*     */   public BlockCommand(int action, Block[] blocks)
/*     */   {
/*  66 */     super(action);
/*  67 */     this.blocks = blocks;
/*  68 */     this.targets = EMPTY_TARGET;
/*     */   }
/*     */ 
/*     */   public Block[] getBlocks() {
/*  72 */     return this.blocks;
/*     */   }
/*     */ 
/*     */   public DatanodeInfo[][] getTargets() {
/*  76 */     return this.targets;
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/*  91 */     super.write(out);
/*  92 */     out.writeInt(this.blocks.length);
/*  93 */     for (int i = 0; i < this.blocks.length; i++) {
/*  94 */       this.blocks[i].write(out);
/*     */     }
/*  96 */     out.writeInt(this.targets.length);
/*  97 */     for (int i = 0; i < this.targets.length; i++) {
/*  98 */       out.writeInt(this.targets[i].length);
/*  99 */       for (int j = 0; j < this.targets[i].length; j++)
/* 100 */         this.targets[i][j].write(out);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException
/*     */   {
/* 106 */     super.readFields(in);
/* 107 */     this.blocks = new Block[in.readInt()];
/* 108 */     for (int i = 0; i < this.blocks.length; i++) {
/* 109 */       this.blocks[i] = new Block();
/* 110 */       this.blocks[i].readFields(in);
/*     */     }
/*     */ 
/* 113 */     this.targets = new DatanodeInfo[in.readInt()][];
/* 114 */     for (int i = 0; i < this.targets.length; i++) {
/* 115 */       this.targets[i] = new DatanodeInfo[in.readInt()];
/* 116 */       for (int j = 0; j < this.targets[i].length; j++) {
/* 117 */         this.targets[i][j] = new DatanodeInfo();
/* 118 */         this.targets[i][j].readFields(in);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  83 */     WritableFactories.setFactory(BlockCommand.class, new WritableFactory()
/*     */     {
/*     */       public Writable newInstance() {
/*  86 */         return new BlockCommand();
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.protocol.BlockCommand
 * JD-Core Version:    0.6.1
 */
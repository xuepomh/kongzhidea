/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.sql.Time;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.util.Daemon;
/*     */ 
/*     */ class PendingReplicationBlocks
/*     */ {
/*     */   private Map<Block, PendingBlockInfo> pendingReplications;
/*     */   private ArrayList<Block> timedOutItems;
/*  40 */   Daemon timerThread = null;
/*  41 */   private volatile boolean fsRunning = true;
/*     */ 
/*  47 */   private long timeout = 300000L;
/*  48 */   private long defaultRecheckInterval = 300000L;
/*     */ 
/*     */   PendingReplicationBlocks(long timeoutPeriod) {
/*  51 */     if (timeoutPeriod > 0L) {
/*  52 */       this.timeout = timeoutPeriod;
/*     */     }
/*  54 */     init();
/*     */   }
/*     */ 
/*     */   PendingReplicationBlocks() {
/*  58 */     init();
/*     */   }
/*     */ 
/*     */   void init() {
/*  62 */     this.pendingReplications = new HashMap();
/*  63 */     this.timedOutItems = new ArrayList();
/*  64 */     this.timerThread = new Daemon(new PendingReplicationMonitor());
/*  65 */     this.timerThread.start();
/*     */   }
/*     */ 
/*     */   void increment(Block block, int numReplicas)
/*     */   {
/*  72 */     synchronized (this.pendingReplications) {
/*  73 */       PendingBlockInfo found = (PendingBlockInfo)this.pendingReplications.get(block);
/*  74 */       if (found == null) {
/*  75 */         this.pendingReplications.put(block, new PendingBlockInfo(numReplicas));
/*     */       } else {
/*  77 */         found.incrementReplicas(numReplicas);
/*  78 */         found.setTimeStamp();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   void decrement(Block block)
/*     */   {
/*  89 */     synchronized (this.pendingReplications) {
/*  90 */       PendingBlockInfo found = (PendingBlockInfo)this.pendingReplications.get(block);
/*  91 */       if (found != null) {
/*  92 */         FSNamesystem.LOG.debug("Removing pending replication for block" + block);
/*  93 */         found.decrementReplicas();
/*  94 */         if (found.getNumReplicas() <= 0)
/*  95 */           this.pendingReplications.remove(block);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   void remove(Block block)
/*     */   {
/* 107 */     synchronized (this.pendingReplications) {
/* 108 */       this.pendingReplications.remove(block);
/*     */     }
/*     */   }
/*     */ 
/*     */   int size()
/*     */   {
/* 116 */     return this.pendingReplications.size();
/*     */   }
/*     */ 
/*     */   int getNumReplicas(Block block)
/*     */   {
/* 123 */     synchronized (this.pendingReplications) {
/* 124 */       PendingBlockInfo found = (PendingBlockInfo)this.pendingReplications.get(block);
/* 125 */       if (found != null) {
/* 126 */         return found.getNumReplicas();
/*     */       }
/*     */     }
/* 129 */     return 0;
/*     */   }
/*     */ 
/*     */   Block[] getTimedOutBlocks()
/*     */   {
/* 138 */     synchronized (this.timedOutItems) {
/* 139 */       if (this.timedOutItems.size() <= 0) {
/* 140 */         return null;
/*     */       }
/* 142 */       Block[] blockList = (Block[])this.timedOutItems.toArray(new Block[this.timedOutItems.size()]);
/*     */ 
/* 144 */       this.timedOutItems.clear();
/* 145 */       return blockList;
/*     */     }
/*     */   }
/*     */ 
/*     */   void stop()
/*     */   {
/* 235 */     this.fsRunning = false;
/* 236 */     this.timerThread.interrupt();
/*     */     try {
/* 238 */       this.timerThread.join(3000L);
/*     */     }
/*     */     catch (InterruptedException ie)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   void metaSave(PrintWriter out)
/*     */   {
/* 247 */     synchronized (this.pendingReplications) {
/* 248 */       out.println("Metasave: Blocks being replicated: " + this.pendingReplications.size());
/*     */ 
/* 250 */       Iterator iter = this.pendingReplications.entrySet().iterator();
/* 251 */       while (iter.hasNext()) {
/* 252 */         Map.Entry entry = (Map.Entry)iter.next();
/* 253 */         PendingBlockInfo pendingBlock = (PendingBlockInfo)entry.getValue();
/* 254 */         Block block = (Block)entry.getKey();
/* 255 */         out.println(block + " StartTime: " + new Time(pendingBlock.timeStamp) + " NumReplicaInProgress: " + pendingBlock.numReplicasInProgress);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   class PendingReplicationMonitor
/*     */     implements Runnable
/*     */   {
/*     */     PendingReplicationMonitor()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 193 */       while (PendingReplicationBlocks.this.fsRunning) {
/* 194 */         long period = Math.min(PendingReplicationBlocks.this.defaultRecheckInterval, PendingReplicationBlocks.this.timeout);
/*     */         try {
/* 196 */           pendingReplicationCheck();
/* 197 */           Thread.sleep(period);
/*     */         } catch (InterruptedException ie) {
/* 199 */           FSNamesystem.LOG.debug("PendingReplicationMonitor thread received exception. " + ie);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     void pendingReplicationCheck()
/*     */     {
/* 209 */       synchronized (PendingReplicationBlocks.this.pendingReplications) {
/* 210 */         Iterator iter = PendingReplicationBlocks.this.pendingReplications.entrySet().iterator();
/* 211 */         long now = FSNamesystem.now();
/* 212 */         FSNamesystem.LOG.debug("PendingReplicationMonitor checking Q");
/* 213 */         while (iter.hasNext()) {
/* 214 */           Map.Entry entry = (Map.Entry)iter.next();
/* 215 */           PendingReplicationBlocks.PendingBlockInfo pendingBlock = (PendingReplicationBlocks.PendingBlockInfo)entry.getValue();
/* 216 */           if (now > pendingBlock.getTimeStamp() + PendingReplicationBlocks.this.timeout) {
/* 217 */             Block block = (Block)entry.getKey();
/* 218 */             synchronized (PendingReplicationBlocks.this.timedOutItems) {
/* 219 */               PendingReplicationBlocks.this.timedOutItems.add(block);
/*     */             }
/* 221 */             FSNamesystem.LOG.warn("PendingReplicationMonitor timed out block " + block);
/*     */ 
/* 223 */             iter.remove();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static class PendingBlockInfo
/*     */   {
/*     */     private long timeStamp;
/*     */     private int numReplicasInProgress;
/*     */ 
/*     */     PendingBlockInfo(int numReplicas)
/*     */     {
/* 161 */       this.timeStamp = FSNamesystem.now();
/* 162 */       this.numReplicasInProgress = numReplicas;
/*     */     }
/*     */ 
/*     */     long getTimeStamp() {
/* 166 */       return this.timeStamp;
/*     */     }
/*     */ 
/*     */     void setTimeStamp() {
/* 170 */       this.timeStamp = FSNamesystem.now();
/*     */     }
/*     */ 
/*     */     void incrementReplicas(int increment) {
/* 174 */       this.numReplicasInProgress += increment;
/*     */     }
/*     */ 
/*     */     void decrementReplicas() {
/* 178 */       this.numReplicasInProgress -= 1;
/* 179 */       assert (this.numReplicasInProgress >= 0);
/*     */     }
/*     */ 
/*     */     int getNumReplicas() {
/* 183 */       return this.numReplicasInProgress;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.PendingReplicationBlocks
 * JD-Core Version:    0.6.1
 */
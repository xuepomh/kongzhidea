/*    */ package org.apache.hadoop.hdfs.server.protocol;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.apache.hadoop.hdfs.protocol.Block;
/*    */ import org.apache.hadoop.ipc.VersionedProtocol;
/*    */ import org.apache.hadoop.security.KerberosInfo;
/*    */ 
/*    */ @KerberosInfo(serverPrincipal="dfs.datanode.kerberos.principal", clientPrincipal="dfs.datanode.kerberos.principal")
/*    */ public abstract interface InterDatanodeProtocol extends VersionedProtocol
/*    */ {
/* 36 */   public static final Log LOG = LogFactory.getLog(InterDatanodeProtocol.class);
/*    */   public static final long versionID = 3L;
/*    */ 
/*    */   public abstract BlockMetaDataInfo getBlockMetaDataInfo(Block paramBlock)
/*    */     throws IOException;
/*    */ 
/*    */   public abstract BlockRecoveryInfo startBlockRecovery(Block paramBlock)
/*    */     throws IOException;
/*    */ 
/*    */   public abstract void updateBlock(Block paramBlock1, Block paramBlock2, boolean paramBoolean)
/*    */     throws IOException;
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.protocol.InterDatanodeProtocol
 * JD-Core Version:    0.6.1
 */
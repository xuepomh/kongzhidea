/*      */ package org.apache.hadoop.hdfs.server.namenode;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.URI;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.apache.hadoop.conf.Configuration;
/*      */ import org.apache.hadoop.fs.ContentSummary;
/*      */ import org.apache.hadoop.fs.FileSystem;
/*      */ import org.apache.hadoop.fs.Path;
/*      */ import org.apache.hadoop.fs.Trash;
/*      */ import org.apache.hadoop.fs.permission.FsPermission;
/*      */ import org.apache.hadoop.fs.permission.PermissionStatus;
/*      */ import org.apache.hadoop.hdfs.HDFSPolicyProvider;
/*      */ import org.apache.hadoop.hdfs.protocol.Block;
/*      */ import org.apache.hadoop.hdfs.protocol.BlockListAsLongs;
/*      */ import org.apache.hadoop.hdfs.protocol.ClientProtocol;
/*      */ import org.apache.hadoop.hdfs.protocol.DatanodeID;
/*      */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*      */ import org.apache.hadoop.hdfs.protocol.DirectoryListing;
/*      */ import org.apache.hadoop.hdfs.protocol.FSConstants;
/*      */ import org.apache.hadoop.hdfs.protocol.FSConstants.DatanodeReportType;
/*      */ import org.apache.hadoop.hdfs.protocol.FSConstants.SafeModeAction;
/*      */ import org.apache.hadoop.hdfs.protocol.FSConstants.UpgradeAction;
/*      */ import org.apache.hadoop.hdfs.protocol.HdfsFileStatus;
/*      */ import org.apache.hadoop.hdfs.protocol.LocatedBlock;
/*      */ import org.apache.hadoop.hdfs.protocol.LocatedBlocks;
/*      */ import org.apache.hadoop.hdfs.protocol.UnregisteredDatanodeException;
/*      */ import org.apache.hadoop.hdfs.security.token.block.ExportedBlockKeys;
/*      */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenIdentifier;
/*      */ import org.apache.hadoop.hdfs.server.common.HdfsConstants.StartupOption;
/*      */ import org.apache.hadoop.hdfs.server.common.IncorrectVersionException;
/*      */ import org.apache.hadoop.hdfs.server.common.UpgradeStatusReport;
/*      */ import org.apache.hadoop.hdfs.server.namenode.metrics.NameNodeInstrumentation;
/*      */ import org.apache.hadoop.hdfs.server.namenode.web.resources.NamenodeWebHdfsMethods;
/*      */ import org.apache.hadoop.hdfs.server.protocol.BlocksWithLocations;
/*      */ import org.apache.hadoop.hdfs.server.protocol.DatanodeCommand;
/*      */ import org.apache.hadoop.hdfs.server.protocol.DatanodeProtocol;
/*      */ import org.apache.hadoop.hdfs.server.protocol.DatanodeRegistration;
/*      */ import org.apache.hadoop.hdfs.server.protocol.NamenodeProtocol;
/*      */ import org.apache.hadoop.hdfs.server.protocol.NamespaceInfo;
/*      */ import org.apache.hadoop.hdfs.server.protocol.UpgradeCommand;
/*      */ import org.apache.hadoop.hdfs.web.AuthFilter;
/*      */ import org.apache.hadoop.hdfs.web.WebHdfsFileSystem;
/*      */ import org.apache.hadoop.hdfs.web.resources.Param;
/*      */ import org.apache.hadoop.http.HttpServer;
/*      */ import org.apache.hadoop.io.Text;
/*      */ import org.apache.hadoop.ipc.RPC;
/*      */ import org.apache.hadoop.ipc.RPC.Server;
/*      */ import org.apache.hadoop.metrics2.lib.DefaultMetricsSystem;
/*      */ import org.apache.hadoop.net.NetUtils;
/*      */ import org.apache.hadoop.net.NetworkTopology;
/*      */ import org.apache.hadoop.net.Node;
/*      */ import org.apache.hadoop.security.Groups;
/*      */ import org.apache.hadoop.security.RefreshUserMappingsProtocol;
/*      */ import org.apache.hadoop.security.SecurityUtil;
/*      */ import org.apache.hadoop.security.UserGroupInformation;
/*      */ import org.apache.hadoop.security.authentication.server.AuthenticationFilter;
/*      */ import org.apache.hadoop.security.authorize.AccessControlList;
/*      */ import org.apache.hadoop.security.authorize.AuthorizationException;
/*      */ import org.apache.hadoop.security.authorize.PolicyProvider;
/*      */ import org.apache.hadoop.security.authorize.ProxyUsers;
/*      */ import org.apache.hadoop.security.authorize.RefreshAuthorizationPolicyProtocol;
/*      */ import org.apache.hadoop.security.authorize.ServiceAuthorizationManager;
/*      */ import org.apache.hadoop.security.token.SecretManager.InvalidToken;
/*      */ import org.apache.hadoop.security.token.Token;
/*      */ import org.apache.hadoop.util.ReflectionUtils;
/*      */ import org.apache.hadoop.util.ServicePlugin;
/*      */ import org.apache.hadoop.util.StringUtils;
/*      */ 
/*      */ public class NameNode
/*      */   implements ClientProtocol, DatanodeProtocol, NamenodeProtocol, FSConstants, RefreshAuthorizationPolicyProtocol, RefreshUserMappingsProtocol
/*      */ {
/*      */   public static final int DEFAULT_PORT = 8020;
/*  162 */   public static final Log LOG = LogFactory.getLog(NameNode.class.getName());
/*  163 */   public static final Log stateChangeLog = LogFactory.getLog("org.apache.hadoop.hdfs.StateChange");
/*      */   private FSNamesystem namesystem;
/*      */   private RPC.Server server;
/*      */   private RPC.Server serviceRpcServer;
/*  175 */   private InetSocketAddress serverAddress = null;
/*      */ 
/*  177 */   protected InetSocketAddress serviceRPCAddress = null;
/*      */   private HttpServer httpServer;
/*  181 */   private InetSocketAddress httpAddress = null;
/*      */   private Thread emptier;
/*  184 */   private boolean stopRequested = false;
/*      */ 
/*  186 */   private boolean serviceAuthEnabled = false;
/*      */   private List<ServicePlugin> plugins;
/*      */   static NameNodeInstrumentation myMetrics;
/*      */ 
/*      */   public long getProtocolVersion(String protocol, long clientVersion)
/*      */     throws IOException
/*      */   {
/*  145 */     if (protocol.equals(RefreshUserMappingsProtocol.class.getName()))
/*  146 */       return 61L;
/*  147 */     if (protocol.equals(DatanodeProtocol.class.getName()))
/*  148 */       return 26L;
/*  149 */     if (protocol.equals(NamenodeProtocol.class.getName()))
/*  150 */       return 3L;
/*  151 */     if (protocol.equals(RefreshAuthorizationPolicyProtocol.class.getName()))
/*  152 */       return 1L;
/*  153 */     if (protocol.equals(RefreshUserMappingsProtocol.class.getName())) {
/*  154 */       return 1L;
/*      */     }
/*  156 */     throw new IOException(new StringBuilder().append("Unknown protocol to name node: ").append(protocol).toString());
/*      */   }
/*      */ 
/*      */   public static void format(Configuration conf)
/*      */     throws IOException
/*      */   {
/*  193 */     format(conf, false, true);
/*      */   }
/*      */ 
/*      */   public void setNamesystem(FSNamesystem ns)
/*      */   {
/*  200 */     this.namesystem = ns;
/*      */   }
/*      */ 
/*      */   public FSNamesystem getNamesystem() {
/*  204 */     return this.namesystem;
/*      */   }
/*      */ 
/*      */   public static NameNodeInstrumentation getNameNodeMetrics() {
/*  208 */     return myMetrics;
/*      */   }
/*      */ 
/*      */   public static InetSocketAddress getAddress(String address) {
/*  212 */     return NetUtils.createSocketAddr(address, 8020);
/*      */   }
/*      */ 
/*      */   public static void setServiceAddress(Configuration conf, String address)
/*      */   {
/*  221 */     LOG.info(new StringBuilder().append("Setting ADDRESS ").append(address).toString());
/*  222 */     conf.set("dfs.namenode.servicerpc-address", address);
/*      */   }
/*      */ 
/*      */   public static InetSocketAddress getServiceAddress(Configuration conf, boolean fallback)
/*      */   {
/*  234 */     String addr = conf.get("dfs.namenode.servicerpc-address");
/*  235 */     if ((addr == null) || (addr.isEmpty())) {
/*  236 */       return fallback ? getAddress(conf) : null;
/*      */     }
/*  238 */     return getAddress(addr);
/*      */   }
/*      */ 
/*      */   public static InetSocketAddress getAddress(Configuration conf) {
/*  242 */     String addr = conf.get("dfs.namenode.rpc-address");
/*  243 */     if ((addr == null) || (addr.isEmpty())) {
/*  244 */       return getAddress(FileSystem.getDefaultUri(conf).toString());
/*      */     }
/*  246 */     return getAddress(addr);
/*      */   }
/*      */ 
/*      */   public static URI getUri(InetSocketAddress namenode) {
/*  250 */     int port = namenode.getPort();
/*  251 */     String portString = port == 8020 ? "" : new StringBuilder().append(":").append(port).toString();
/*  252 */     return URI.create(new StringBuilder().append("hdfs://").append(namenode.getHostName()).append(portString).toString());
/*      */   }
/*      */ 
/*      */   protected InetSocketAddress getServiceRpcServerAddress(Configuration conf)
/*      */     throws IOException
/*      */   {
/*  261 */     return getServiceAddress(conf, false);
/*      */   }
/*      */ 
/*      */   protected void setRpcServiceServerAddress(Configuration conf)
/*      */   {
/*  269 */     String address = new StringBuilder().append(this.serviceRPCAddress.getHostName()).append(":").append(this.serviceRPCAddress.getPort()).toString();
/*      */ 
/*  271 */     setServiceAddress(conf, address);
/*      */   }
/*      */ 
/*      */   private void initialize(Configuration conf)
/*      */     throws IOException
/*      */   {
/*  280 */     InetSocketAddress socAddr = getAddress(conf);
/*  281 */     UserGroupInformation.setConfiguration(conf);
/*  282 */     SecurityUtil.login(conf, "dfs.namenode.keytab.file", "dfs.namenode.kerberos.principal", socAddr.getHostName());
/*      */ 
/*  284 */     int handlerCount = conf.getInt("dfs.namenode.handler.count", 10);
/*      */ 
/*  287 */     if ((this.serviceAuthEnabled = conf.getBoolean("hadoop.security.authorization", false)))
/*      */     {
/*  290 */       PolicyProvider policyProvider = (PolicyProvider)ReflectionUtils.newInstance(conf.getClass("hadoop.security.authorization.policyprovider", HDFSPolicyProvider.class, PolicyProvider.class), conf);
/*      */ 
/*  295 */       ServiceAuthorizationManager.refresh(conf, policyProvider);
/*      */     }
/*      */ 
/*  298 */     myMetrics = NameNodeInstrumentation.create(conf);
/*  299 */     this.namesystem = new FSNamesystem(this, conf);
/*      */ 
/*  303 */     boolean alwaysUseDelegationTokensForTests = conf.getBoolean("dfs.namenode.delegation.token.always-use", false);
/*      */ 
/*  307 */     if ((UserGroupInformation.isSecurityEnabled()) || (alwaysUseDelegationTokensForTests))
/*      */     {
/*  309 */       this.namesystem.activateSecretManager();
/*      */     }
/*      */ 
/*  313 */     InetSocketAddress dnSocketAddr = getServiceRpcServerAddress(conf);
/*  314 */     if (dnSocketAddr != null) {
/*  315 */       int serviceHandlerCount = conf.getInt("dfs.namenode.service.handler.count", 10);
/*      */ 
/*  318 */       this.serviceRpcServer = RPC.getServer(this, dnSocketAddr.getHostName(), dnSocketAddr.getPort(), serviceHandlerCount, false, conf, this.namesystem.getDelegationTokenSecretManager());
/*      */ 
/*  321 */       this.serviceRPCAddress = this.serviceRpcServer.getListenerAddress();
/*  322 */       setRpcServiceServerAddress(conf);
/*      */     }
/*  324 */     this.server = RPC.getServer(this, socAddr.getHostName(), socAddr.getPort(), handlerCount, false, conf, this.namesystem.getDelegationTokenSecretManager());
/*      */ 
/*  328 */     this.server.addTerseExceptions(new Class[] { SafeModeException.class });
/*      */ 
/*  331 */     this.serverAddress = this.server.getListenerAddress();
/*  332 */     FileSystem.setDefaultUri(conf, getUri(this.serverAddress));
/*  333 */     LOG.info(new StringBuilder().append("Namenode up at: ").append(this.serverAddress).toString());
/*      */ 
/*  337 */     startHttpServer(conf);
/*  338 */     this.server.start();
/*  339 */     if (this.serviceRpcServer != null) {
/*  340 */       this.serviceRpcServer.start();
/*      */     }
/*  342 */     startTrashEmptier(conf);
/*      */ 
/*  344 */     this.plugins = conf.getInstances("dfs.namenode.plugins", ServicePlugin.class);
/*  345 */     for (ServicePlugin p : this.plugins)
/*      */       try {
/*  347 */         p.start(this);
/*      */       } catch (Throwable t) {
/*  349 */         LOG.warn(new StringBuilder().append("ServicePlugin ").append(p).append(" could not be started").toString(), t);
/*      */       }
/*      */   }
/*      */ 
/*      */   private void startTrashEmptier(Configuration conf) throws IOException
/*      */   {
/*  355 */     this.emptier = new Thread(new Trash(conf).getEmptier(), "Trash Emptier");
/*  356 */     this.emptier.setDaemon(true);
/*  357 */     this.emptier.start();
/*      */   }
/*      */ 
/*      */   public static String getInfoServer(Configuration conf)
/*      */   {
/*  362 */     String http = SecurityUtil.useKsslAuth() ? "dfs.https.address" : "dfs.http.address";
/*      */ 
/*  364 */     return NetUtils.getServerAddress(conf, "dfs.info.bindAddress", "dfs.info.port", http);
/*      */   }
/*      */ 
/*      */   public static String getHttpUriScheme()
/*      */   {
/*  373 */     return SecurityUtil.useKsslAuth() ? "https" : "http";
/*      */   }
/*      */ 
/*      */   private void startHttpServer(final Configuration conf) throws IOException
/*      */   {
/*  378 */     String infoAddr = NetUtils.getServerAddress(conf, "dfs.info.bindAddress", "dfs.info.port", "dfs.http.address");
/*      */ 
/*  380 */     final InetSocketAddress infoSocAddr = NetUtils.createSocketAddr(infoAddr);
/*      */ 
/*  382 */     if (SecurityUtil.useKsslAuth()) {
/*  383 */       String httpsUser = SecurityUtil.getServerPrincipal(conf.get("dfs.namenode.kerberos.https.principal"), infoSocAddr.getHostName());
/*      */ 
/*  387 */       LOG.info(new StringBuilder().append("Logging in as ").append(httpsUser).append(" to start http server.").toString());
/*  388 */       SecurityUtil.login(conf, "dfs.namenode.keytab.file", "dfs.namenode.kerberos.https.principal", infoSocAddr.getHostName());
/*      */     }
/*      */ 
/*  393 */     UserGroupInformation ugi = UserGroupInformation.getLoginUser();
/*      */     try {
/*  395 */       this.httpServer = ((HttpServer)ugi.doAs(new PrivilegedExceptionAction()
/*      */       {
/*      */         public HttpServer run() throws IOException, InterruptedException {
/*  398 */           String infoHost = infoSocAddr.getHostName();
/*  399 */           int infoPort = infoSocAddr.getPort();
/*  400 */           NameNode.this.httpServer = new HttpServer("hdfs", infoHost, infoPort, infoPort == 0, conf, SecurityUtil.getAdminAcls(conf, "dfs.cluster.administrators"))
/*      */           {
/*      */             private Map<String, String> getAuthFilterParams(Configuration conf)
/*      */               throws IOException
/*      */             {
/*  450 */               Map params = new HashMap();
/*  451 */               String principalInConf = conf.get("dfs.web.authentication.kerberos.principal");
/*      */ 
/*  453 */               if ((principalInConf != null) && (!principalInConf.isEmpty())) {
/*  454 */                 params.put("dfs.web.authentication.kerberos.principal", SecurityUtil.getServerPrincipal(principalInConf, NameNode.this.serverAddress.getHostName()));
/*      */               }
/*      */ 
/*  460 */               String httpKeytab = conf.get("dfs.web.authentication.kerberos.keytab");
/*      */ 
/*  462 */               if ((httpKeytab != null) && (!httpKeytab.isEmpty())) {
/*  463 */                 params.put("dfs.web.authentication.kerberos.keytab", httpKeytab);
/*      */               }
/*      */ 
/*  467 */               return params;
/*      */             }
/*      */           };
/*  471 */           boolean certSSL = conf.getBoolean("dfs.https.enable", false);
/*  472 */           if ((certSSL) || (SecurityUtil.useKsslAuth())) {
/*  473 */             boolean needClientAuth = conf.getBoolean("dfs.https.need.client.auth", false);
/*  474 */             InetSocketAddress secInfoSocAddr = NetUtils.createSocketAddr(infoHost + ":" + conf.get("dfs.https.port", new StringBuilder().append(infoHost).append(":").append(0).toString()));
/*      */ 
/*  476 */             Configuration sslConf = new Configuration(false);
/*  477 */             if (certSSL) {
/*  478 */               sslConf.addResource(conf.get("dfs.https.server.keystore.resource", "ssl-server.xml"));
/*      */             }
/*      */ 
/*  481 */             NameNode.this.httpServer.addSslListener(secInfoSocAddr, sslConf, needClientAuth, SecurityUtil.useKsslAuth());
/*      */ 
/*  484 */             InetSocketAddress datanodeSslPort = NetUtils.createSocketAddr(conf.get("dfs.datanode.https.address", infoHost + ":" + 50475));
/*      */ 
/*  486 */             NameNode.this.httpServer.setAttribute("datanode.https.port", Integer.valueOf(datanodeSslPort.getPort()));
/*      */           }
/*      */ 
/*  489 */           NameNode.this.httpServer.setAttribute("name.node", NameNode.this);
/*  490 */           NameNode.this.httpServer.setAttribute("name.node.address", NameNode.this.getNameNodeAddress());
/*  491 */           NameNode.this.httpServer.setAttribute("name.system.image", NameNode.this.getFSImage());
/*  492 */           NameNode.this.httpServer.setAttribute("current.conf", conf);
/*  493 */           NameNode.this.httpServer.addInternalServlet("getDelegationToken", "/getDelegationToken", GetDelegationTokenServlet.class, true, SecurityUtil.useKsslAuth());
/*      */ 
/*  497 */           NameNode.this.httpServer.addInternalServlet("renewDelegationToken", "/renewDelegationToken", RenewDelegationTokenServlet.class, true, SecurityUtil.useKsslAuth());
/*      */ 
/*  501 */           NameNode.this.httpServer.addInternalServlet("cancelDelegationToken", "/cancelDelegationToken", CancelDelegationTokenServlet.class, true, SecurityUtil.useKsslAuth());
/*      */ 
/*  505 */           NameNode.this.httpServer.addInternalServlet("fsck", "/fsck", FsckServlet.class, true, SecurityUtil.useKsslAuth());
/*      */ 
/*  507 */           NameNode.this.httpServer.addInternalServlet("getimage", "/getimage", GetImageServlet.class, true, SecurityUtil.useKsslAuth());
/*      */ 
/*  509 */           NameNode.this.httpServer.addInternalServlet("listPaths", "/listPaths/*", ListPathsServlet.class);
/*      */ 
/*  511 */           NameNode.this.httpServer.addInternalServlet("data", "/data/*", FileDataServlet.class);
/*      */ 
/*  513 */           NameNode.this.httpServer.addInternalServlet("checksum", "/fileChecksum/*", FileChecksumServlets.RedirectServlet.class);
/*      */ 
/*  515 */           NameNode.this.httpServer.addInternalServlet("contentSummary", "/contentSummary/*", ContentSummaryServlet.class);
/*      */ 
/*  517 */           NameNode.this.httpServer.start();
/*      */ 
/*  520 */           infoPort = NameNode.this.httpServer.getPort();
/*  521 */           NameNode.this.httpAddress = new InetSocketAddress(infoHost, infoPort);
/*  522 */           conf.set("dfs.http.address", infoHost + ":" + infoPort);
/*  523 */           NameNode.LOG.info("Web-server up at: " + infoHost + ":" + infoPort);
/*  524 */           return NameNode.this.httpServer;
/*      */         } } ));
/*      */     }
/*      */     catch (InterruptedException e) {
/*  528 */       throw new IOException(e);
/*      */     } finally {
/*  530 */       if (SecurityUtil.useKsslAuth())
/*      */       {
/*  532 */         LOG.info(new StringBuilder().append("Logging back in as ").append(SecurityUtil.getServerPrincipal(conf.get("dfs.namenode.kerberos.principal"), this.serverAddress.getHostName())).append(" following http server start.").toString());
/*      */ 
/*  536 */         SecurityUtil.login(conf, "dfs.namenode.keytab.file", "dfs.namenode.kerberos.principal", this.serverAddress.getHostName());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public NameNode(Configuration conf)
/*      */     throws IOException
/*      */   {
/*      */     try
/*      */     {
/*  569 */       initialize(conf);
/*      */     } catch (IOException e) {
/*  571 */       stop();
/*  572 */       throw e;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void join()
/*      */   {
/*      */     try
/*      */     {
/*  582 */       this.server.join();
/*      */     }
/*      */     catch (InterruptedException ie)
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   public void stop()
/*      */   {
/*  591 */     if (this.stopRequested)
/*  592 */       return;
/*  593 */     this.stopRequested = true;
/*  594 */     if (this.plugins != null) {
/*  595 */       for (ServicePlugin p : this.plugins)
/*      */         try {
/*  597 */           p.stop();
/*      */         } catch (Throwable t) {
/*  599 */           LOG.warn(new StringBuilder().append("ServicePlugin ").append(p).append(" could not be stopped").toString(), t);
/*      */         }
/*      */     }
/*      */     try
/*      */     {
/*  604 */       if (this.httpServer != null) this.httpServer.stop(); 
/*      */     }
/*  606 */     catch (Exception e) { LOG.error(StringUtils.stringifyException(e)); }
/*      */ 
/*  608 */     if (this.namesystem != null) this.namesystem.close();
/*  609 */     if (this.emptier != null) this.emptier.interrupt();
/*  610 */     if (this.server != null) this.server.stop();
/*  611 */     if (this.serviceRpcServer != null) this.serviceRpcServer.stop();
/*  612 */     if (myMetrics != null) {
/*  613 */       myMetrics.shutdown();
/*      */     }
/*  615 */     if (this.namesystem != null)
/*  616 */       this.namesystem.shutdown();
/*      */   }
/*      */ 
/*      */   public BlocksWithLocations getBlocks(DatanodeInfo datanode, long size)
/*      */     throws IOException
/*      */   {
/*  632 */     if (size <= 0L) {
/*  633 */       throw new IllegalArgumentException(new StringBuilder().append("Unexpected not positive size: ").append(size).toString());
/*      */     }
/*      */ 
/*  637 */     return this.namesystem.getBlocks(datanode, size);
/*      */   }
/*      */ 
/*      */   public Token<DelegationTokenIdentifier> getDelegationToken(Text renewer)
/*      */     throws IOException
/*      */   {
/*  646 */     return this.namesystem.getDelegationToken(renewer);
/*      */   }
/*      */ 
/*      */   public long renewDelegationToken(Token<DelegationTokenIdentifier> token)
/*      */     throws SecretManager.InvalidToken, IOException
/*      */   {
/*  652 */     return this.namesystem.renewDelegationToken(token);
/*      */   }
/*      */ 
/*      */   public void cancelDelegationToken(Token<DelegationTokenIdentifier> token)
/*      */     throws IOException
/*      */   {
/*  658 */     this.namesystem.cancelDelegationToken(token);
/*      */   }
/*      */ 
/*      */   public LocatedBlocks getBlockLocations(String src, long offset, long length)
/*      */     throws IOException
/*      */   {
/*  665 */     myMetrics.incrNumGetBlockLocations();
/*  666 */     return this.namesystem.getBlockLocations(getClientMachine(), src, offset, length);
/*      */   }
/*      */ 
/*      */   private static String getClientMachine()
/*      */   {
/*  671 */     String clientMachine = NamenodeWebHdfsMethods.getRemoteAddress();
/*  672 */     if (clientMachine == null) {
/*  673 */       clientMachine = RPC.Server.getRemoteAddress();
/*      */     }
/*  675 */     if (clientMachine == null) {
/*  676 */       clientMachine = "";
/*      */     }
/*  678 */     return clientMachine;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public void create(String src, FsPermission masked, String clientName, boolean overwrite, short replication, long blockSize)
/*      */     throws IOException
/*      */   {
/*  689 */     create(src, masked, clientName, overwrite, true, replication, blockSize);
/*      */   }
/*      */ 
/*      */   public void create(String src, FsPermission masked, String clientName, boolean overwrite, boolean createParent, short replication, long blockSize)
/*      */     throws IOException
/*      */   {
/*  701 */     String clientMachine = getClientMachine();
/*  702 */     if (stateChangeLog.isDebugEnabled()) {
/*  703 */       stateChangeLog.debug(new StringBuilder().append("*DIR* NameNode.create: ").append(src).append(" for ").append(clientName).append(" at ").append(clientMachine).toString());
/*      */     }
/*      */ 
/*  706 */     if (!checkPathLength(src)) {
/*  707 */       throw new IOException("create: Pathname too long.  Limit 8000 characters, 1000 levels.");
/*      */     }
/*      */ 
/*  710 */     this.namesystem.startFile(src, new PermissionStatus(UserGroupInformation.getCurrentUser().getShortUserName(), null, masked), clientName, clientMachine, overwrite, createParent, replication, blockSize);
/*      */ 
/*  714 */     myMetrics.incrNumFilesCreated();
/*  715 */     myMetrics.incrNumCreateFileOps();
/*      */   }
/*      */ 
/*      */   public LocatedBlock append(String src, String clientName) throws IOException
/*      */   {
/*  720 */     String clientMachine = getClientMachine();
/*  721 */     if (stateChangeLog.isDebugEnabled()) {
/*  722 */       stateChangeLog.debug(new StringBuilder().append("*DIR* NameNode.append: ").append(src).append(" for ").append(clientName).append(" at ").append(clientMachine).toString());
/*      */     }
/*      */ 
/*  725 */     LocatedBlock info = this.namesystem.appendFile(src, clientName, clientMachine);
/*  726 */     myMetrics.incrNumFilesAppended();
/*  727 */     return info;
/*      */   }
/*      */ 
/*      */   public boolean isFileClosed(String src) throws IOException
/*      */   {
/*  732 */     return this.namesystem.isFileClosed(src);
/*      */   }
/*      */ 
/*      */   public boolean recoverLease(String src, String clientName) throws IOException
/*      */   {
/*  737 */     String clientMachine = getClientMachine();
/*  738 */     return this.namesystem.recoverLease(src, clientName, clientMachine);
/*      */   }
/*      */ 
/*      */   public boolean setReplication(String src, short replication)
/*      */     throws IOException
/*      */   {
/*  745 */     return this.namesystem.setReplication(src, replication);
/*      */   }
/*      */ 
/*      */   public void setPermission(String src, FsPermission permissions)
/*      */     throws IOException
/*      */   {
/*  751 */     this.namesystem.setPermission(src, permissions);
/*      */   }
/*      */ 
/*      */   public void setOwner(String src, String username, String groupname)
/*      */     throws IOException
/*      */   {
/*  757 */     this.namesystem.setOwner(src, username, groupname);
/*      */   }
/*      */ 
/*      */   public LocatedBlock addBlock(String src, String clientName)
/*      */     throws IOException
/*      */   {
/*  765 */     return addBlock(src, clientName, null);
/*      */   }
/*      */ 
/*      */   public LocatedBlock addBlock(String src, String clientName, DatanodeInfo[] excludedNodes)
/*      */     throws IOException
/*      */   {
/*  773 */     HashMap excludedNodesSet = null;
/*  774 */     if (excludedNodes != null) {
/*  775 */       excludedNodesSet = new HashMap(excludedNodes.length);
/*  776 */       for (Node node : excludedNodes) {
/*  777 */         excludedNodesSet.put(node, node);
/*      */       }
/*      */     }
/*      */ 
/*  781 */     stateChangeLog.debug(new StringBuilder().append("*BLOCK* NameNode.addBlock: ").append(src).append(" for ").append(clientName).toString());
/*      */ 
/*  783 */     LocatedBlock locatedBlock = this.namesystem.getAdditionalBlock(src, clientName, excludedNodesSet);
/*      */ 
/*  785 */     if (locatedBlock != null)
/*  786 */       myMetrics.incrNumAddBlockOps();
/*  787 */     return locatedBlock;
/*      */   }
/*      */ 
/*      */   public void abandonBlock(Block b, String src, String holder)
/*      */     throws IOException
/*      */   {
/*  795 */     stateChangeLog.debug(new StringBuilder().append("*BLOCK* NameNode.abandonBlock: ").append(b).append(" of ").append(src).toString());
/*      */ 
/*  797 */     if (!this.namesystem.abandonBlock(b, src, holder))
/*  798 */       throw new IOException(new StringBuilder().append("Cannot abandon block during write to ").append(src).toString());
/*      */   }
/*      */ 
/*      */   public boolean complete(String src, String clientName)
/*      */     throws IOException
/*      */   {
/*  804 */     stateChangeLog.debug(new StringBuilder().append("*DIR* NameNode.complete: ").append(src).append(" for ").append(clientName).toString());
/*  805 */     FSNamesystem.CompleteFileStatus returnCode = this.namesystem.completeFile(src, clientName);
/*  806 */     if (returnCode == FSNamesystem.CompleteFileStatus.STILL_WAITING)
/*  807 */       return false;
/*  808 */     if (returnCode == FSNamesystem.CompleteFileStatus.COMPLETE_SUCCESS) {
/*  809 */       return true;
/*      */     }
/*  811 */     throw new IOException(new StringBuilder().append("Could not complete write to ").append(src).append(" by ").append(clientName).toString());
/*      */   }
/*      */ 
/*      */   public void reportBadBlocks(LocatedBlock[] blocks)
/*      */     throws IOException
/*      */   {
/*  822 */     stateChangeLog.info("*DIR* NameNode.reportBadBlocks");
/*  823 */     for (int i = 0; i < blocks.length; i++) {
/*  824 */       Block blk = blocks[i].getBlock();
/*  825 */       DatanodeInfo[] nodes = blocks[i].getLocations();
/*  826 */       for (int j = 0; j < nodes.length; j++) {
/*  827 */         DatanodeInfo dn = nodes[j];
/*  828 */         this.namesystem.markBlockAsCorrupt(blk, dn);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public long nextGenerationStamp(Block block, boolean fromNN) throws IOException
/*      */   {
/*  835 */     return this.namesystem.nextGenerationStampForBlock(block, fromNN);
/*      */   }
/*      */ 
/*      */   public void commitBlockSynchronization(Block block, long newgenerationstamp, long newlength, boolean closeFile, boolean deleteblock, DatanodeID[] newtargets)
/*      */     throws IOException
/*      */   {
/*  843 */     this.namesystem.commitBlockSynchronization(block, newgenerationstamp, newlength, closeFile, deleteblock, newtargets);
/*      */   }
/*      */ 
/*      */   public long getPreferredBlockSize(String filename) throws IOException
/*      */   {
/*  848 */     return this.namesystem.getPreferredBlockSize(filename);
/*      */   }
/*      */ 
/*      */   public void concat(String trg, String[] src)
/*      */     throws IOException
/*      */   {
/*  855 */     this.namesystem.concat(trg, src);
/*      */   }
/*      */ 
/*      */   public boolean rename(String src, String dst)
/*      */     throws IOException
/*      */   {
/*  861 */     stateChangeLog.debug(new StringBuilder().append("*DIR* NameNode.rename: ").append(src).append(" to ").append(dst).toString());
/*  862 */     if (!checkPathLength(dst)) {
/*  863 */       throw new IOException("rename: Pathname too long.  Limit 8000 characters, 1000 levels.");
/*      */     }
/*      */ 
/*  866 */     boolean ret = this.namesystem.renameTo(src, dst);
/*  867 */     if (ret) {
/*  868 */       myMetrics.incrNumFilesRenamed();
/*      */     }
/*  870 */     return ret;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public boolean delete(String src)
/*      */     throws IOException
/*      */   {
/*  877 */     return delete(src, true);
/*      */   }
/*      */ 
/*      */   public boolean delete(String src, boolean recursive) throws IOException
/*      */   {
/*  882 */     if (stateChangeLog.isDebugEnabled()) {
/*  883 */       stateChangeLog.debug(new StringBuilder().append("*DIR* Namenode.delete: src=").append(src).append(", recursive=").append(recursive).toString());
/*      */     }
/*      */ 
/*  886 */     boolean ret = this.namesystem.delete(src, recursive);
/*  887 */     if (ret)
/*  888 */       myMetrics.incrNumDeleteFileOps();
/*  889 */     return ret;
/*      */   }
/*      */ 
/*      */   private boolean checkPathLength(String src)
/*      */   {
/*  899 */     Path srcPath = new Path(src);
/*  900 */     return (src.length() <= 8000) && (srcPath.depth() <= 1000);
/*      */   }
/*      */ 
/*      */   public boolean mkdirs(String src, FsPermission masked)
/*      */     throws IOException
/*      */   {
/*  906 */     stateChangeLog.debug(new StringBuilder().append("*DIR* NameNode.mkdirs: ").append(src).toString());
/*  907 */     if (!checkPathLength(src)) {
/*  908 */       throw new IOException("mkdirs: Pathname too long.  Limit 8000 characters, 1000 levels.");
/*      */     }
/*      */ 
/*  911 */     return this.namesystem.mkdirs(src, new PermissionStatus(UserGroupInformation.getCurrentUser().getShortUserName(), null, masked));
/*      */   }
/*      */ 
/*      */   public void renewLease(String clientName)
/*      */     throws IOException
/*      */   {
/*  919 */     this.namesystem.renewLease(clientName);
/*      */   }
/*      */ 
/*      */   public DirectoryListing getListing(String src, byte[] startAfter)
/*      */     throws IOException
/*      */   {
/*  925 */     DirectoryListing files = this.namesystem.getListing(src, startAfter);
/*  926 */     myMetrics.incrNumGetListingOps();
/*  927 */     if (files != null) {
/*  928 */       myMetrics.incrNumFilesInGetListingOps(files.getPartialListing().length);
/*      */     }
/*  930 */     return files;
/*      */   }
/*      */ 
/*      */   public HdfsFileStatus getFileInfo(String src)
/*      */     throws IOException
/*      */   {
/*  941 */     myMetrics.incrNumFileInfoOps();
/*  942 */     return this.namesystem.getFileInfo(src);
/*      */   }
/*      */ 
/*      */   public long[] getStats() throws IOException
/*      */   {
/*  947 */     return this.namesystem.getStats();
/*      */   }
/*      */ 
/*      */   public DatanodeInfo[] getDatanodeReport(FSConstants.DatanodeReportType type)
/*      */     throws IOException
/*      */   {
/*  954 */     DatanodeInfo[] results = this.namesystem.datanodeReport(type);
/*  955 */     if (results == null) {
/*  956 */       throw new IOException("Cannot find datanode report");
/*      */     }
/*  958 */     return results;
/*      */   }
/*      */ 
/*      */   public boolean setSafeMode(FSConstants.SafeModeAction action)
/*      */     throws IOException
/*      */   {
/*  965 */     return this.namesystem.setSafeMode(action);
/*      */   }
/*      */ 
/*      */   public boolean isInSafeMode()
/*      */   {
/*  972 */     return this.namesystem.isInSafeMode();
/*      */   }
/*      */ 
/*      */   public void saveNamespace()
/*      */     throws IOException
/*      */   {
/*  979 */     this.namesystem.saveNamespace();
/*      */   }
/*      */ 
/*      */   public void refreshNodes()
/*      */     throws IOException
/*      */   {
/*  988 */     this.namesystem.refreshNodes(new Configuration());
/*      */   }
/*      */ 
/*      */   public long getEditLogSize()
/*      */     throws IOException
/*      */   {
/*  995 */     return this.namesystem.getEditLogSize();
/*      */   }
/*      */ 
/*      */   public CheckpointSignature rollEditLog()
/*      */     throws IOException
/*      */   {
/* 1002 */     return this.namesystem.rollEditLog();
/*      */   }
/*      */ 
/*      */   public void rollFsImage()
/*      */     throws IOException
/*      */   {
/* 1009 */     this.namesystem.rollFSImage();
/*      */   }
/*      */ 
/*      */   public void finalizeUpgrade() throws IOException {
/* 1013 */     this.namesystem.finalizeUpgrade();
/*      */   }
/*      */ 
/*      */   public UpgradeStatusReport distributedUpgradeProgress(FSConstants.UpgradeAction action) throws IOException
/*      */   {
/* 1018 */     return this.namesystem.distributedUpgradeProgress(action);
/*      */   }
/*      */ 
/*      */   public void metaSave(String filename)
/*      */     throws IOException
/*      */   {
/* 1025 */     this.namesystem.metaSave(filename);
/*      */   }
/*      */ 
/*      */   public void setBalancerBandwidth(long bandwidth)
/*      */     throws IOException
/*      */   {
/* 1035 */     this.namesystem.setBalancerBandwidth(bandwidth);
/*      */   }
/*      */ 
/*      */   public ContentSummary getContentSummary(String path) throws IOException
/*      */   {
/* 1040 */     return this.namesystem.getContentSummary(path);
/*      */   }
/*      */ 
/*      */   public void setQuota(String path, long namespaceQuota, long diskspaceQuota)
/*      */     throws IOException
/*      */   {
/* 1046 */     this.namesystem.setQuota(path, namespaceQuota, diskspaceQuota);
/*      */   }
/*      */ 
/*      */   public void fsync(String src, String clientName) throws IOException
/*      */   {
/* 1051 */     this.namesystem.fsync(src, clientName);
/*      */   }
/*      */ 
/*      */   public void setTimes(String src, long mtime, long atime) throws IOException
/*      */   {
/* 1056 */     this.namesystem.setTimes(src, mtime, atime);
/*      */   }
/*      */ 
/*      */   public DatanodeRegistration register(DatanodeRegistration nodeReg)
/*      */     throws IOException
/*      */   {
/* 1066 */     verifyVersion(nodeReg.getVersion());
/* 1067 */     this.namesystem.registerDatanode(nodeReg);
/*      */ 
/* 1069 */     return nodeReg;
/*      */   }
/*      */ 
/*      */   public DatanodeCommand[] sendHeartbeat(DatanodeRegistration nodeReg, long capacity, long dfsUsed, long remaining, int xmitsInProgress, int xceiverCount)
/*      */     throws IOException
/*      */   {
/* 1083 */     verifyRequest(nodeReg);
/* 1084 */     return this.namesystem.handleHeartbeat(nodeReg, capacity, dfsUsed, remaining, xceiverCount, xmitsInProgress);
/*      */   }
/*      */ 
/*      */   public DatanodeCommand blockReport(DatanodeRegistration nodeReg, long[] blocks)
/*      */     throws IOException
/*      */   {
/* 1090 */     verifyRequest(nodeReg);
/* 1091 */     BlockListAsLongs blist = new BlockListAsLongs(blocks);
/* 1092 */     stateChangeLog.debug(new StringBuilder().append("*BLOCK* NameNode.blockReport: from ").append(nodeReg.getName()).append(" ").append(blist.getNumberOfBlocks()).append(" blocks").toString());
/*      */ 
/* 1095 */     this.namesystem.processReport(nodeReg, blist);
/* 1096 */     if (getFSImage().isUpgradeFinalized())
/* 1097 */       return DatanodeCommand.FINALIZE;
/* 1098 */     return null;
/*      */   }
/*      */ 
/*      */   public void blocksBeingWrittenReport(DatanodeRegistration nodeReg, long[] blocks)
/*      */     throws IOException
/*      */   {
/* 1107 */     verifyRequest(nodeReg);
/* 1108 */     BlockListAsLongs blist = new BlockListAsLongs(blocks);
/* 1109 */     this.namesystem.processBlocksBeingWrittenReport(nodeReg, blist);
/*      */ 
/* 1111 */     stateChangeLog.info(new StringBuilder().append("*BLOCK* NameNode.blocksBeingWrittenReport: from ").append(nodeReg.getName()).append(" ").append(blist.getNumberOfBlocks()).append(" blocks").toString());
/*      */   }
/*      */ 
/*      */   public void blockReceived(DatanodeRegistration nodeReg, Block[] blocks, String[] delHints)
/*      */     throws IOException
/*      */   {
/* 1119 */     verifyRequest(nodeReg);
/* 1120 */     stateChangeLog.debug(new StringBuilder().append("*BLOCK* NameNode.blockReceived: from ").append(nodeReg.getName()).append(" ").append(blocks.length).append(" blocks.").toString());
/*      */ 
/* 1122 */     for (int i = 0; i < blocks.length; i++)
/* 1123 */       this.namesystem.blockReceived(nodeReg, blocks[i], delHints[i]);
/*      */   }
/*      */ 
/*      */   public ExportedBlockKeys getBlockKeys()
/*      */     throws IOException
/*      */   {
/* 1129 */     return this.namesystem.getBlockKeys();
/*      */   }
/*      */ 
/*      */   public void errorReport(DatanodeRegistration nodeReg, int errorCode, String msg)
/*      */     throws IOException
/*      */   {
/* 1138 */     String dnName = nodeReg == null ? "unknown DataNode" : nodeReg.getName();
/* 1139 */     LOG.info(new StringBuilder().append("Error report from ").append(dnName).append(": ").append(msg).toString());
/* 1140 */     if (errorCode == 0) {
/* 1141 */       return;
/*      */     }
/* 1143 */     verifyRequest(nodeReg);
/* 1144 */     if (errorCode == 1)
/* 1145 */       LOG.warn(new StringBuilder().append("Volume failed on ").append(dnName).toString());
/* 1146 */     else if (errorCode == 3)
/* 1147 */       this.namesystem.removeDatanode(nodeReg);
/*      */   }
/*      */ 
/*      */   public NamespaceInfo versionRequest() throws IOException
/*      */   {
/* 1152 */     return this.namesystem.getNamespaceInfo();
/*      */   }
/*      */ 
/*      */   public UpgradeCommand processUpgradeCommand(UpgradeCommand comm) throws IOException {
/* 1156 */     return this.namesystem.processDistributedUpgradeCommand(comm);
/*      */   }
/*      */ 
/*      */   public void verifyRequest(DatanodeRegistration nodeReg)
/*      */     throws IOException
/*      */   {
/* 1169 */     verifyVersion(nodeReg.getVersion());
/* 1170 */     if (!this.namesystem.getRegistrationID().equals(nodeReg.getRegistrationID()))
/* 1171 */       throw new UnregisteredDatanodeException(nodeReg);
/*      */   }
/*      */ 
/*      */   public void verifyVersion(int version)
/*      */     throws IOException
/*      */   {
/* 1181 */     if (version != -41)
/* 1182 */       throw new IncorrectVersionException(version, "data node");
/*      */   }
/*      */ 
/*      */   public File getFsImageName()
/*      */     throws IOException
/*      */   {
/* 1189 */     return getFSImage().getFsImageName();
/*      */   }
/*      */ 
/*      */   public FSImage getFSImage() {
/* 1193 */     return this.namesystem.dir.fsImage;
/*      */   }
/*      */ 
/*      */   public File[] getFsImageNameCheckpoint()
/*      */     throws IOException
/*      */   {
/* 1201 */     return getFSImage().getFsImageNameCheckpoint();
/*      */   }
/*      */ 
/*      */   public InetSocketAddress getNameNodeAddress()
/*      */   {
/* 1209 */     return this.serverAddress;
/*      */   }
/*      */ 
/*      */   public InetSocketAddress getHttpAddress()
/*      */   {
/* 1219 */     return this.httpAddress;
/*      */   }
/*      */ 
/*      */   NetworkTopology getNetworkTopology() {
/* 1223 */     return this.namesystem.clusterMap;
/*      */   }
/*      */ 
/*      */   private static boolean format(Configuration conf, boolean isConfirmationNeeded, boolean isInteractive)
/*      */     throws IOException
/*      */   {
/* 1238 */     Collection dirsToFormat = FSNamesystem.getNamespaceDirs(conf);
/* 1239 */     Collection editDirsToFormat = FSNamesystem.getNamespaceEditsDirs(conf);
/*      */ 
/* 1241 */     for (Iterator it = dirsToFormat.iterator(); it.hasNext(); ) {
/* 1242 */       File curDir = (File)it.next();
/* 1243 */       if (curDir.exists())
/*      */       {
/* 1245 */         if (isConfirmationNeeded) {
/* 1246 */           if (!isInteractive) {
/* 1247 */             System.err.println(new StringBuilder().append("Format aborted: ").append(curDir).append(" exists.").toString());
/* 1248 */             return true;
/*      */           }
/* 1250 */           System.err.print(new StringBuilder().append("Re-format filesystem in ").append(curDir).append(" ? (Y or N) ").toString());
/* 1251 */           if (System.in.read() != 89) {
/* 1252 */             System.err.println(new StringBuilder().append("Format aborted in ").append(curDir).toString());
/* 1253 */             return true;
/*      */           }
/* 1255 */           while (System.in.read() != 10);
/*      */         }
/*      */       }
/*      */     }
/* 1259 */     FSNamesystem nsys = new FSNamesystem(new FSImage(dirsToFormat, editDirsToFormat), conf);
/*      */ 
/* 1261 */     nsys.dir.fsImage.format();
/* 1262 */     return false;
/*      */   }
/*      */ 
/*      */   private static boolean finalize(Configuration conf, boolean isConfirmationNeeded)
/*      */     throws IOException
/*      */   {
/* 1268 */     Collection dirsToFormat = FSNamesystem.getNamespaceDirs(conf);
/* 1269 */     Collection editDirsToFormat = FSNamesystem.getNamespaceEditsDirs(conf);
/*      */ 
/* 1271 */     FSNamesystem nsys = new FSNamesystem(new FSImage(dirsToFormat, editDirsToFormat), conf);
/*      */ 
/* 1273 */     System.err.print("\"finalize\" will remove the previous state of the files system.\nRecent upgrade will become permanent.\nRollback option will not be available anymore.\n");
/*      */ 
/* 1277 */     if (isConfirmationNeeded) {
/* 1278 */       System.err.print("Finalize filesystem state ? (Y or N) ");
/* 1279 */       if (System.in.read() != 89) {
/* 1280 */         System.err.println("Finalize aborted.");
/* 1281 */         return true;
/*      */       }
/* 1283 */       while (System.in.read() != 10);
/*      */     }
/* 1285 */     nsys.dir.fsImage.finalizeUpgrade();
/* 1286 */     return false;
/*      */   }
/*      */ 
/*      */   public void refreshServiceAcl() throws IOException
/*      */   {
/* 1291 */     if (!this.serviceAuthEnabled) {
/* 1292 */       throw new AuthorizationException("Service Level Authorization not enabled!");
/*      */     }
/*      */ 
/* 1295 */     ServiceAuthorizationManager.refresh(new Configuration(), new HDFSPolicyProvider());
/*      */   }
/*      */ 
/*      */   public void refreshUserToGroupsMappings()
/*      */     throws IOException
/*      */   {
/* 1301 */     LOG.info(new StringBuilder().append("Refreshing all user-to-groups mappings. Requested by user: ").append(UserGroupInformation.getCurrentUser().getShortUserName()).toString());
/*      */ 
/* 1303 */     Groups.getUserToGroupsMappingService().refresh();
/*      */   }
/*      */ 
/*      */   public void refreshSuperUserGroupsConfiguration()
/*      */   {
/* 1308 */     LOG.info("Refreshing SuperUser proxy group mapping list ");
/*      */ 
/* 1310 */     ProxyUsers.refreshSuperUserGroupsConfiguration();
/*      */   }
/*      */ 
/*      */   private static void printUsage() {
/* 1314 */     System.err.println(new StringBuilder().append("Usage: java NameNode [").append(HdfsConstants.StartupOption.FORMAT.getName()).append(" [").append(HdfsConstants.StartupOption.FORCE.getName()).append(" ] [").append(HdfsConstants.StartupOption.NONINTERACTIVE.getName()).append("]] | [").append(HdfsConstants.StartupOption.UPGRADE.getName()).append("] | [").append(HdfsConstants.StartupOption.ROLLBACK.getName()).append("] | [").append(HdfsConstants.StartupOption.FINALIZE.getName()).append("] | [").append(HdfsConstants.StartupOption.IMPORT.getName()).append("] | [").append(HdfsConstants.StartupOption.RECOVER.getName()).append(" [ ").append(HdfsConstants.StartupOption.FORCE.getName()).append(" ] ]").toString());
/*      */   }
/*      */ 
/*      */   private static HdfsConstants.StartupOption parseArguments(String[] args)
/*      */   {
/* 1327 */     int argsLen = args == null ? 0 : args.length;
/* 1328 */     HdfsConstants.StartupOption startOpt = HdfsConstants.StartupOption.REGULAR;
/* 1329 */     label310: for (int i = 0; i < argsLen; i++) {
/* 1330 */       String cmd = args[i];
/* 1331 */       if (HdfsConstants.StartupOption.FORMAT.getName().equalsIgnoreCase(cmd)) {
/* 1332 */         startOpt = HdfsConstants.StartupOption.FORMAT;
/*      */ 
/* 1334 */         for (i += 1; i < argsLen; i++) {
/* 1335 */           if (args[i].equalsIgnoreCase(HdfsConstants.StartupOption.FORCE.getName())) {
/* 1336 */             startOpt.setConfirmationNeeded(false);
/*      */           }
/* 1338 */           if (args[i].equalsIgnoreCase(HdfsConstants.StartupOption.NONINTERACTIVE.getName()))
/* 1339 */             startOpt.setInteractive(false);
/*      */         }
/*      */       }
/* 1342 */       if (HdfsConstants.StartupOption.REGULAR.getName().equalsIgnoreCase(cmd)) {
/* 1343 */         startOpt = HdfsConstants.StartupOption.REGULAR;
/* 1344 */       } else if (HdfsConstants.StartupOption.UPGRADE.getName().equalsIgnoreCase(cmd)) {
/* 1345 */         startOpt = HdfsConstants.StartupOption.UPGRADE; } else {
/* 1346 */         if (HdfsConstants.StartupOption.RECOVER.getName().equalsIgnoreCase(cmd)) {
/* 1347 */           if (startOpt != HdfsConstants.StartupOption.REGULAR) {
/* 1348 */             throw new RuntimeException("Can't combine -recover with other startup options.");
/*      */           }
/*      */ 
/* 1351 */           startOpt = HdfsConstants.StartupOption.RECOVER;
/*      */           while (true) { i++; if (i >= argsLen) break label310;
/* 1353 */             if (!args[i].equalsIgnoreCase(HdfsConstants.StartupOption.FORCE.getName()))
/*      */               break;
/* 1355 */             startOpt.setForce(1);
/*      */           }
/* 1357 */           throw new RuntimeException(new StringBuilder().append("Error parsing recovery options: can't understand option \"").append(args[i]).append("\"").toString());
/*      */         }
/*      */ 
/* 1361 */         if (HdfsConstants.StartupOption.ROLLBACK.getName().equalsIgnoreCase(cmd))
/* 1362 */           startOpt = HdfsConstants.StartupOption.ROLLBACK;
/* 1363 */         else if (HdfsConstants.StartupOption.FINALIZE.getName().equalsIgnoreCase(cmd))
/* 1364 */           startOpt = HdfsConstants.StartupOption.FINALIZE;
/* 1365 */         else if (HdfsConstants.StartupOption.IMPORT.getName().equalsIgnoreCase(cmd))
/* 1366 */           startOpt = HdfsConstants.StartupOption.IMPORT;
/*      */         else
/* 1368 */           return null; 
/*      */       }
/*      */     }
/* 1370 */     return startOpt;
/*      */   }
/*      */ 
/*      */   private static void setStartupOption(Configuration conf, HdfsConstants.StartupOption opt) {
/* 1374 */     conf.set("dfs.namenode.startup", opt.toString());
/*      */   }
/*      */ 
/*      */   static HdfsConstants.StartupOption getStartupOption(Configuration conf) {
/* 1378 */     return HdfsConstants.StartupOption.valueOf(conf.get("dfs.namenode.startup", HdfsConstants.StartupOption.REGULAR.toString()));
/*      */   }
/*      */ 
/*      */   private static void doRecovery(HdfsConstants.StartupOption startOpt, Configuration conf)
/*      */     throws IOException
/*      */   {
/* 1384 */     if ((startOpt.getForce() < 2) && 
/* 1385 */       (!confirmPrompt("You have selected Metadata Recovery mode.  This mode is intended to recover lost metadata on a corrupt filesystem.  Metadata recovery mode often permanently deletes data from your HDFS filesystem.  Please back up your edit log and image before trying this!\n\nAre you ready to proceed? (Y/N)\n")))
/*      */     {
/* 1391 */       System.err.println("Recovery aborted at user request.\n");
/* 1392 */       return;
/*      */     }
/*      */ 
/* 1395 */     int tolerationLength = conf.getInt("dfs.namenode.edits.toleration.length", 0);
/*      */ 
/* 1398 */     if (tolerationLength >= 0) {
/* 1399 */       if (!confirmPrompt(new StringBuilder().append("You have selected Metadata Recovery mode and have set dfs.namenode.edits.toleration.length = ").append(tolerationLength).append(".  However, Metadata Recovery mode and the").append(" Edit Log Toleration feature cannot be enabled at the same time.").append("  Disable Edit Log Toleration? (Y/N)\n").toString()))
/*      */       {
/* 1404 */         System.err.println("Recovery aborted at user request.\n");
/* 1405 */         return;
/*      */       }
/* 1407 */       conf.setInt("dfs.namenode.edits.toleration.length", -1);
/*      */     }
/*      */ 
/* 1410 */     MetaRecoveryContext.LOG.info("starting recovery...");
/* 1411 */     Collection namespaceDirs = FSNamesystem.getNamespaceDirs(conf);
/* 1412 */     Collection editDirs = FSNamesystem.getNamespaceEditsDirs(conf);
/*      */ 
/* 1414 */     FSNamesystem fsn = null;
/*      */     try {
/* 1416 */       fsn = new FSNamesystem(new FSImage(namespaceDirs, editDirs), conf);
/* 1417 */       fsn.dir.fsImage.loadFSImage(startOpt.createRecoveryContext());
/* 1418 */       fsn.dir.fsImage.saveNamespace(true);
/* 1419 */       MetaRecoveryContext.LOG.info("RECOVERY COMPLETE");
/*      */     } finally {
/* 1421 */       if (fsn != null)
/* 1422 */         fsn.close();
/*      */     }
/*      */   }
/*      */ 
/*      */   static boolean confirmPrompt(String prompt)
/*      */     throws IOException
/*      */   {
/*      */     while (true)
/*      */     {
/* 1432 */       System.err.print(new StringBuilder().append(prompt).append(" (Y or N) ").toString());
/* 1433 */       StringBuilder responseBuilder = new StringBuilder();
/*      */       while (true) {
/* 1435 */         int c = System.in.read();
/* 1436 */         if ((c == -1) || (c == 13) || (c == 10)) {
/*      */           break;
/*      */         }
/* 1439 */         responseBuilder.append((char)c);
/*      */       }
/*      */ 
/* 1442 */       String response = responseBuilder.toString();
/* 1443 */       if ((response.equalsIgnoreCase("y")) || (response.equalsIgnoreCase("yes")))
/*      */       {
/* 1445 */         return true;
/* 1446 */       }if ((response.equalsIgnoreCase("n")) || (response.equalsIgnoreCase("no")))
/*      */       {
/* 1448 */         return false;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static NameNode createNameNode(String[] argv, Configuration conf)
/*      */     throws IOException
/*      */   {
/* 1456 */     if (conf == null)
/* 1457 */       conf = new Configuration();
/* 1458 */     HdfsConstants.StartupOption startOpt = parseArguments(argv);
/* 1459 */     if (startOpt == null) {
/* 1460 */       printUsage();
/* 1461 */       System.exit(-2);
/*      */     }
/* 1463 */     setStartupOption(conf, startOpt);
/*      */     boolean aborted;
/* 1465 */     switch (2.$SwitchMap$org$apache$hadoop$hdfs$server$common$HdfsConstants$StartupOption[startOpt.ordinal()]) {
/*      */     case 1:
/* 1467 */       aborted = format(conf, startOpt.getConfirmationNeeded(), startOpt.getInteractive());
/*      */ 
/* 1469 */       System.exit(aborted ? 1 : 0);
/*      */     case 2:
/* 1471 */       aborted = finalize(conf, true);
/* 1472 */       System.exit(aborted ? 1 : 0);
/*      */     case 3:
/* 1474 */       doRecovery(startOpt, conf);
/* 1475 */       return null;
/*      */     }
/*      */ 
/* 1478 */     DefaultMetricsSystem.initialize("NameNode");
/* 1479 */     NameNode namenode = new NameNode(conf);
/* 1480 */     return namenode;
/*      */   }
/*      */ 
/*      */   public static void main(String[] argv) throws Exception
/*      */   {
/*      */     try
/*      */     {
/* 1487 */       StringUtils.startupShutdownMessage(NameNode.class, argv, LOG);
/* 1488 */       NameNode namenode = createNameNode(argv, null);
/* 1489 */       if (namenode != null)
/* 1490 */         namenode.join();
/*      */     } catch (Throwable e) {
/* 1492 */       LOG.error(StringUtils.stringifyException(e));
/* 1493 */       System.exit(-1);
/*      */     }
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*  139 */     Configuration.addDefaultResource("hdfs-default.xml");
/*  140 */     Configuration.addDefaultResource("hdfs-site.xml");
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.NameNode
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.server.common;
/*    */ 
/*    */ import org.apache.hadoop.hdfs.server.namenode.MetaRecoveryContext;
/*    */ 
/*    */ public abstract interface HdfsConstants
/*    */ {
/*    */   public static final int READ_TIMEOUT = 60000;
/*    */   public static final int READ_TIMEOUT_EXTENSION = 3000;
/*    */   public static final int WRITE_TIMEOUT = 480000;
/*    */   public static final int WRITE_TIMEOUT_EXTENSION = 5000;
/*    */   public static final String NN_RECOVERY_LEASEHOLDER = "NN_Recovery";
/*    */ 
/*    */   public static enum StartupOption
/*    */   {
/* 39 */     FORMAT("-format"), 
/* 40 */     REGULAR("-regular"), 
/* 41 */     UPGRADE("-upgrade"), 
/* 42 */     RECOVER("-recover"), 
/* 43 */     FORCE("-force"), 
/* 44 */     ROLLBACK("-rollback"), 
/* 45 */     FINALIZE("-finalize"), 
/* 46 */     IMPORT("-importCheckpoint"), 
/* 47 */     NONINTERACTIVE("-nonInteractive");
/*    */ 
/* 50 */     private int force = 0;
/*    */ 
/* 53 */     private boolean isConfirmationNeeded = true;
/* 54 */     private boolean isInteractive = true;
/*    */ 
/* 56 */     private String name = null;
/*    */ 
/* 57 */     private StartupOption(String arg) { this.name = arg; } 
/* 58 */     public String getName() { return this.name; }
/*    */ 
/*    */     public MetaRecoveryContext createRecoveryContext() {
/* 61 */       if (!this.name.equals(RECOVER.name))
/* 62 */         return null;
/* 63 */       return new MetaRecoveryContext(this.force);
/*    */     }
/*    */ 
/*    */     public void setForce(int force) {
/* 67 */       this.force = force;
/*    */     }
/*    */ 
/*    */     public int getForce() {
/* 71 */       return this.force;
/*    */     }
/*    */ 
/*    */     public void setConfirmationNeeded(boolean confirmationNeeded) {
/* 75 */       this.isConfirmationNeeded = confirmationNeeded;
/*    */     }
/*    */ 
/*    */     public boolean getConfirmationNeeded() {
/* 79 */       return this.isConfirmationNeeded;
/*    */     }
/*    */ 
/*    */     public void setInteractive(boolean interactive) {
/* 83 */       this.isInteractive = interactive;
/*    */     }
/*    */ 
/*    */     public boolean getInteractive() {
/* 87 */       return this.isInteractive;
/*    */     }
/*    */   }
/*    */ 
/*    */   public static enum NodeType
/*    */   {
/* 33 */     NAME_NODE, 
/* 34 */     DATA_NODE;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.common.HdfsConstants
 * JD-Core Version:    0.6.1
 */
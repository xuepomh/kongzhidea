/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.List;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.hdfs.protocol.ClientProtocol;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeID;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.hdfs.protocol.HdfsFileStatus;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlocks;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ 
/*     */ public class FileDataServlet extends DfsServlet
/*     */ {
/*  68 */   private static JspHelper jspHelper = null;
/*     */ 
/*     */   protected URI createUri(String parent, HdfsFileStatus i, UserGroupInformation ugi, ClientProtocol nnproxy, HttpServletRequest request, String dt)
/*     */     throws IOException, URISyntaxException
/*     */   {
/*  46 */     String scheme = request.getScheme();
/*  47 */     DatanodeID host = pickSrcDatanode(parent, i, nnproxy);
/*     */     String hostname;
/*     */     String hostname;
/*  49 */     if ((host instanceof DatanodeInfo))
/*  50 */       hostname = ((DatanodeInfo)host).getHostName();
/*     */     else {
/*  52 */       hostname = host.getHost();
/*     */     }
/*     */ 
/*  55 */     String dtParam = "";
/*  56 */     if (dt != null) {
/*  57 */       dtParam = JspHelper.getDelegationTokenUrlParam(dt);
/*     */     }
/*     */ 
/*  60 */     return new URI(scheme, null, hostname, "https".equals(scheme) ? ((Integer)getServletContext().getAttribute("datanode.https.port")).intValue() : host.getInfoPort(), "/streamFile" + i.getFullName(parent), "ugi=" + ugi.getShortUserName() + dtParam, null);
/*     */   }
/*     */ 
/*     */   private static DatanodeID pickSrcDatanode(String parent, HdfsFileStatus i, ClientProtocol nnproxy)
/*     */     throws IOException
/*     */   {
/*  79 */     if (jspHelper == null)
/*  80 */       jspHelper = new JspHelper();
/*  81 */     LocatedBlocks blks = nnproxy.getBlockLocations(i.getFullPath(new Path(parent)).toUri().getPath(), 0L, 1L);
/*     */ 
/*  83 */     if ((i.getLen() == 0L) || (blks.getLocatedBlocks().size() <= 0))
/*     */     {
/*  85 */       return jspHelper.randomNode();
/*     */     }
/*  87 */     return JspHelper.bestNode(blks.get(0));
/*     */   }
/*     */ 
/*     */   public void doGet(final HttpServletRequest request, final HttpServletResponse response)
/*     */     throws IOException
/*     */   {
/* 100 */     Configuration conf = (Configuration)getServletContext().getAttribute("current.conf");
/*     */ 
/* 102 */     final UserGroupInformation ugi = getUGI(request, conf);
/*     */     try
/*     */     {
/* 105 */       ugi.doAs(new PrivilegedExceptionAction()
/*     */       {
/*     */         public Void run() throws IOException {
/* 108 */           ClientProtocol nn = FileDataServlet.this.createNameNodeProxy();
/* 109 */           String path = request.getPathInfo() != null ? request.getPathInfo() : "/";
/*     */ 
/* 112 */           String delegationToken = request.getParameter("delegation");
/*     */ 
/* 115 */           HdfsFileStatus info = nn.getFileInfo(path);
/* 116 */           if ((info != null) && (!info.isDir()))
/*     */             try {
/* 118 */               response.sendRedirect(FileDataServlet.this.createUri(path, info, ugi, nn, request, delegationToken).toURL().toString());
/*     */             }
/*     */             catch (URISyntaxException e) {
/* 121 */               response.getWriter().println(e.toString());
/*     */             }
/* 123 */           else if (info == null)
/* 124 */             response.sendError(400, "File not found " + path);
/*     */           else {
/* 126 */             response.sendError(400, path + " is a directory");
/*     */           }
/* 128 */           return null;
/*     */         }
/*     */       });
/*     */     }
/*     */     catch (IOException e) {
/* 133 */       response.sendError(400, e.getMessage());
/*     */     } catch (InterruptedException e) {
/* 135 */       response.sendError(400, e.getMessage());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.FileDataServlet
 * JD-Core Version:    0.6.1
 */
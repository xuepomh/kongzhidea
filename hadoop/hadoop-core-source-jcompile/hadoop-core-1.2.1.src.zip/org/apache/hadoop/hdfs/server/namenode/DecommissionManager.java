/*    */ package org.apache.hadoop.hdfs.server.namenode;
/*    */ 
/*    */ import java.util.Map.Entry;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.apache.hadoop.util.CyclicIteration;
/*    */ 
/*    */ class DecommissionManager
/*    */ {
/* 30 */   static final Log LOG = LogFactory.getLog(DecommissionManager.class);
/*    */   private final FSNamesystem fsnamesystem;
/*    */ 
/*    */   DecommissionManager(FSNamesystem namesystem)
/*    */   {
/* 35 */     this.fsnamesystem = namesystem;
/*    */   }
/*    */ 
/*    */   class Monitor
/*    */     implements Runnable
/*    */   {
/*    */     private final long recheckInterval;
/*    */     private final int numNodesPerCheck;
/* 47 */     private String firstkey = "";
/*    */ 
/*    */     Monitor(int recheckIntervalInSecond, int numNodesPerCheck) {
/* 50 */       this.recheckInterval = (recheckIntervalInSecond * 1000L);
/* 51 */       this.numNodesPerCheck = numNodesPerCheck;
/*    */     }
/*    */ 
/*    */     public void run()
/*    */     {
/* 59 */       while (DecommissionManager.this.fsnamesystem.isRunning()) {
/* 60 */         synchronized (DecommissionManager.this.fsnamesystem) {
/* 61 */           check();
/*    */         }
/*    */         try
/*    */         {
/* 65 */           Thread.sleep(this.recheckInterval);
/*    */         } catch (InterruptedException ie) {
/* 67 */           DecommissionManager.LOG.info("Interrupted " + getClass().getSimpleName(), ie);
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/*    */     private void check() {
/* 73 */       int count = 0;
/*    */ 
/* 75 */       for (Map.Entry entry : new CyclicIteration(DecommissionManager.this.fsnamesystem.datanodeMap, this.firstkey))
/*    */       {
/* 77 */         DatanodeDescriptor d = (DatanodeDescriptor)entry.getValue();
/* 78 */         this.firstkey = ((String)entry.getKey());
/*    */ 
/* 80 */         if (d.isDecommissionInProgress()) {
/*    */           try {
/* 82 */             DecommissionManager.this.fsnamesystem.checkDecommissionStateInternal(d);
/*    */           } catch (Exception e) {
/* 84 */             DecommissionManager.LOG.warn("entry=" + entry, e);
/*    */           }
/* 86 */           count++; if (count == this.numNodesPerCheck)
/* 87 */             return;
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.DecommissionManager
 * JD-Core Version:    0.6.1
 */
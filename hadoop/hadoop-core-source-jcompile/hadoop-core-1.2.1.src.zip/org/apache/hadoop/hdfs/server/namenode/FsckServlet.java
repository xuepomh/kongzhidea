/*    */ package org.apache.hadoop.hdfs.server.namenode;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import java.net.InetAddress;
/*    */ import java.security.PrivilegedExceptionAction;
/*    */ import java.util.Map;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ import org.apache.hadoop.hdfs.protocol.FSConstants.DatanodeReportType;
/*    */ import org.apache.hadoop.security.UserGroupInformation;
/*    */ 
/*    */ public class FsckServlet extends DfsServlet
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException
/*    */   {
/* 45 */     final Map pmap = request.getParameterMap();
/* 46 */     final PrintWriter out = response.getWriter();
/* 47 */     final InetAddress remoteAddress = InetAddress.getByName(request.getRemoteAddr());
/*    */ 
/* 49 */     final ServletContext context = getServletContext();
/* 50 */     final Configuration conf = (Configuration)context.getAttribute("current.conf");
/*    */ 
/* 52 */     UserGroupInformation ugi = getUGI(request, conf);
/*    */     try {
/* 54 */       ugi.doAs(new PrivilegedExceptionAction()
/*    */       {
/*    */         public Object run() throws Exception {
/* 57 */           NameNode nn = (NameNode)context.getAttribute("name.node");
/* 58 */           int totalDatanodes = nn.getNamesystem().getNumberOfDatanodes(FSConstants.DatanodeReportType.LIVE);
/* 59 */           short minReplication = nn.getNamesystem().getMinReplication();
/*    */ 
/* 61 */           new NamenodeFsck(conf, nn, nn.getNetworkTopology(), pmap, out, totalDatanodes, minReplication, remoteAddress).fsck();
/*    */ 
/* 63 */           return null;
/*    */         } } );
/*    */     }
/*    */     catch (InterruptedException e) {
/* 67 */       response.sendError(400, e.getMessage());
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.FsckServlet
 * JD-Core Version:    0.6.1
 */
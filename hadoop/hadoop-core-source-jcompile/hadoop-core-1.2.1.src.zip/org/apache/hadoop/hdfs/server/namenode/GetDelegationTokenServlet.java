/*    */ package org.apache.hadoop.hdfs.server.namenode;
/*    */ 
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.security.Principal;
/*    */ import java.security.PrivilegedExceptionAction;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenSecretManager;
/*    */ import org.apache.hadoop.security.Credentials;
/*    */ import org.apache.hadoop.security.UserGroupInformation;
/*    */ 
/*    */ public class GetDelegationTokenServlet extends DfsServlet
/*    */ {
/* 44 */   private static final Log LOG = LogFactory.getLog(GetDelegationTokenServlet.class);
/*    */   public static final String PATH_SPEC = "/getDelegationToken";
/*    */   public static final String RENEWER = "renewer";
/*    */ 
/*    */   protected void doGet(HttpServletRequest req, HttpServletResponse resp)
/*    */     throws ServletException, IOException
/*    */   {
/* 52 */     ServletContext context = getServletContext();
/* 53 */     Configuration conf = (Configuration)context.getAttribute("current.conf");
/*    */     final UserGroupInformation ugi;
/*    */     try
/*    */     {
/* 56 */       ugi = getUGI(req, conf);
/*    */     } catch (IOException ioe) {
/* 58 */       LOG.info("Request for token received with no authentication from " + req.getRemoteAddr(), ioe);
/*    */ 
/* 60 */       resp.sendError(403, "Unable to identify or authenticate user");
/*    */ 
/* 62 */       return;
/*    */     }
/* 64 */     LOG.info("Sending token: {" + ugi.getUserName() + "," + req.getRemoteAddr() + "}");
/* 65 */     final NameNode nn = (NameNode)context.getAttribute("name.node");
/* 66 */     String renewer = req.getParameter("renewer");
/* 67 */     final String renewerFinal = renewer == null ? req.getUserPrincipal().getName() : renewer;
/*    */ 
/* 70 */     DataOutputStream dos = null;
/*    */     try {
/* 72 */       dos = new DataOutputStream(resp.getOutputStream());
/* 73 */       final DataOutputStream dosFinal = dos;
/* 74 */       ugi.doAs(new PrivilegedExceptionAction()
/*    */       {
/*    */         public Void run() throws IOException {
/* 77 */           Credentials ts = DelegationTokenSecretManager.createCredentials(nn, ugi, renewerFinal);
/*    */ 
/* 79 */           ts.write(dosFinal);
/* 80 */           dosFinal.close();
/* 81 */           return null;
/*    */         }
/*    */       });
/*    */     }
/*    */     catch (Exception e) {
/* 86 */       LOG.info("Exception while sending token. Re-throwing. ", e);
/* 87 */       resp.sendError(500);
/*    */     } finally {
/* 89 */       if (dos != null) dos.close();
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.GetDelegationTokenServlet
 * JD-Core Version:    0.6.1
 */
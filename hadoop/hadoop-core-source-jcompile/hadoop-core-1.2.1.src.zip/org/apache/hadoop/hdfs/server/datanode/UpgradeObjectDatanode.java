/*     */ package org.apache.hadoop.hdfs.server.datanode;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.SocketTimeoutException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.hdfs.server.common.HdfsConstants.NodeType;
/*     */ import org.apache.hadoop.hdfs.server.common.UpgradeObject;
/*     */ import org.apache.hadoop.hdfs.server.protocol.DatanodeProtocol;
/*     */ import org.apache.hadoop.hdfs.server.protocol.NamespaceInfo;
/*     */ import org.apache.hadoop.hdfs.server.protocol.UpgradeCommand;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ public abstract class UpgradeObjectDatanode extends UpgradeObject
/*     */   implements Runnable
/*     */ {
/*  35 */   private DataNode dataNode = null;
/*     */ 
/*     */   public HdfsConstants.NodeType getType() {
/*  38 */     return HdfsConstants.NodeType.DATA_NODE;
/*     */   }
/*     */ 
/*     */   protected DataNode getDatanode() {
/*  42 */     return this.dataNode;
/*     */   }
/*     */ 
/*     */   void setDatanode(DataNode dataNode) {
/*  46 */     this.dataNode = dataNode;
/*     */   }
/*     */ 
/*     */   public abstract void doUpgrade()
/*     */     throws IOException;
/*     */ 
/*     */   boolean preUpgradeAction(NamespaceInfo nsInfo)
/*     */     throws IOException
/*     */   {
/*  78 */     int nsUpgradeVersion = nsInfo.getDistributedUpgradeVersion();
/*  79 */     if (nsUpgradeVersion >= getVersion()) {
/*  80 */       return false;
/*     */     }
/*  82 */     String errorMsg = "\n   Data-node missed a distributed upgrade and will shutdown.\n   " + getDescription() + "." + " Name-node version = " + nsInfo.getLayoutVersion() + ".";
/*     */ 
/*  86 */     DataNode.LOG.fatal(errorMsg);
/*     */     try {
/*  88 */       this.dataNode.namenode.errorReport(this.dataNode.dnRegistration, 0, errorMsg);
/*     */     }
/*     */     catch (SocketTimeoutException e) {
/*  91 */       DataNode.LOG.info("Problem connecting to server: " + this.dataNode.getNameNodeAddr());
/*     */     }
/*     */ 
/*  94 */     throw new IOException(errorMsg);
/*     */   }
/*     */ 
/*     */   public void run() {
/*  98 */     assert (this.dataNode != null) : "UpgradeObjectDatanode.dataNode is null";
/*  99 */     if (this.dataNode.shouldRun) {
/*     */       try {
/* 101 */         doUpgrade();
/*     */       } catch (Exception e) {
/* 103 */         DataNode.LOG.error(StringUtils.stringifyException(e));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 109 */     if (getUpgradeStatus() < 100) {
/* 110 */       DataNode.LOG.info("\n   Distributed upgrade for DataNode version " + getVersion() + " to current LV " + -41 + " cannot be completed");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 117 */       this.dataNode.upgradeManager.completeUpgrade();
/*     */     } catch (IOException e) {
/* 119 */       DataNode.LOG.error(StringUtils.stringifyException(e));
/*     */     }
/*     */   }
/*     */ 
/*     */   public UpgradeCommand completeUpgrade()
/*     */     throws IOException
/*     */   {
/* 131 */     return new UpgradeCommand(100, getVersion(), (short)100);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.UpgradeObjectDatanode
 * JD-Core Version:    0.6.1
 */
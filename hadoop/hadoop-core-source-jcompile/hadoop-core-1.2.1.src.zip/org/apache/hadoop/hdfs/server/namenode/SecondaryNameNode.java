/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.security.DigestInputStream;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.hdfs.protocol.FSConstants;
/*     */ import org.apache.hadoop.hdfs.server.common.HdfsConstants.StartupOption;
/*     */ import org.apache.hadoop.hdfs.server.common.InconsistentFSStateException;
/*     */ import org.apache.hadoop.hdfs.server.common.Storage.StorageDirectory;
/*     */ import org.apache.hadoop.hdfs.server.common.Storage.StorageState;
/*     */ import org.apache.hadoop.hdfs.server.protocol.NamenodeProtocol;
/*     */ import org.apache.hadoop.http.HttpServer;
/*     */ import org.apache.hadoop.io.MD5Hash;
/*     */ import org.apache.hadoop.ipc.RPC;
/*     */ import org.apache.hadoop.ipc.RemoteException;
/*     */ import org.apache.hadoop.metrics2.source.JvmMetricsSource;
/*     */ import org.apache.hadoop.net.NetUtils;
/*     */ import org.apache.hadoop.security.Krb5AndCertsSslSocketConnector;
/*     */ import org.apache.hadoop.security.SecurityUtil;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.authentication.server.AuthenticationFilter;
/*     */ import org.apache.hadoop.security.authorize.AccessControlList;
/*     */ import org.apache.hadoop.util.Daemon;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ public class SecondaryNameNode
/*     */   implements Runnable
/*     */ {
/*  76 */   public static final Log LOG = LogFactory.getLog(SecondaryNameNode.class.getName());
/*     */ 
/*  79 */   private final long starttime = System.currentTimeMillis();
/*  80 */   private volatile long lastCheckpointTime = 0L;
/*     */   private String fsName;
/*     */   private CheckpointStorage checkpointImage;
/*     */   private NamenodeProtocol namenode;
/*     */   private Configuration conf;
/*     */   private InetSocketAddress nameNodeAddr;
/*     */   private volatile boolean shouldRun;
/*     */   private HttpServer infoServer;
/*     */   private int infoPort;
/*     */   private int imagePort;
/*     */   private String infoBindAddress;
/*     */   private Collection<File> checkpointDirs;
/*     */   private Collection<File> checkpointEditsDirs;
/*     */   private long checkpointPeriod;
/*     */   private long checkpointSize;
/*     */ 
/*     */   public String toString()
/*     */   {
/* 101 */     return new StringBuilder().append(getClass().getSimpleName()).append(" Status").append("\nName Node Address    : ").append(this.nameNodeAddr).append("\nStart Time           : ").append(new Date(this.starttime)).append("\nLast Checkpoint Time : ").append(this.lastCheckpointTime == 0L ? "--" : new Date(this.lastCheckpointTime)).append("\nCheckpoint Period    : ").append(this.checkpointPeriod).append(" seconds").append("\nCheckpoint Size      : ").append(StringUtils.byteDesc(this.checkpointSize)).append(" (= ").append(this.checkpointSize).append(" bytes)").append("\nCheckpoint Dirs      : ").append(this.checkpointDirs).append("\nCheckpoint Edits Dirs: ").append(this.checkpointEditsDirs).toString();
/*     */   }
/*     */ 
/*     */   FSImage getFSImage()
/*     */   {
/* 142 */     return this.checkpointImage;
/*     */   }
/*     */ 
/*     */   public SecondaryNameNode(Configuration conf)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 150 */       initialize(conf);
/*     */     } catch (IOException e) {
/* 152 */       shutdown();
/* 153 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static InetSocketAddress getHttpAddress(Configuration conf)
/*     */   {
/* 159 */     String infoAddr = NetUtils.getServerAddress(conf, "dfs.secondary.info.bindAddress", "dfs.secondary.info.port", "dfs.secondary.http.address");
/*     */ 
/* 162 */     return NetUtils.createSocketAddr(infoAddr);
/*     */   }
/*     */ 
/*     */   private void initialize(Configuration conf)
/*     */     throws IOException
/*     */   {
/* 171 */     int editsTolerationLength = conf.getInt("dfs.namenode.edits.toleration.length", 0);
/*     */ 
/* 174 */     if (editsTolerationLength >= 0) {
/* 175 */       LOG.info(new StringBuilder().append("dfs.namenode.edits.toleration.length is set to ").append(editsTolerationLength).append(".  Override it with -1, i.e. disable it.").toString());
/*     */ 
/* 178 */       conf.setInt("dfs.namenode.edits.toleration.length", -1);
/*     */     }
/*     */ 
/* 181 */     InetSocketAddress infoSocAddr = getHttpAddress(conf);
/* 182 */     this.infoBindAddress = infoSocAddr.getHostName();
/* 183 */     if (UserGroupInformation.isSecurityEnabled()) {
/* 184 */       SecurityUtil.login(conf, "dfs.secondary.namenode.keytab.file", "dfs.secondary.namenode.kerberos.principal", this.infoBindAddress);
/*     */     }
/*     */ 
/* 190 */     JvmMetricsSource.create("SecondaryNameNode", conf.get("session.id"));
/*     */ 
/* 193 */     this.shouldRun = true;
/* 194 */     this.nameNodeAddr = NameNode.getServiceAddress(conf, true);
/*     */ 
/* 196 */     this.conf = conf;
/* 197 */     this.namenode = ((NamenodeProtocol)RPC.waitForProxy(NamenodeProtocol.class, 3L, this.nameNodeAddr, conf));
/*     */ 
/* 202 */     this.fsName = getInfoServer();
/* 203 */     this.checkpointDirs = FSImage.getCheckpointDirs(conf, "/tmp/hadoop/dfs/namesecondary");
/*     */ 
/* 205 */     this.checkpointEditsDirs = FSImage.getCheckpointEditsDirs(conf, "/tmp/hadoop/dfs/namesecondary");
/*     */ 
/* 207 */     this.checkpointImage = new CheckpointStorage();
/* 208 */     this.checkpointImage.recoverCreate(this.checkpointDirs, this.checkpointEditsDirs);
/*     */ 
/* 211 */     this.checkpointPeriod = conf.getLong("fs.checkpoint.period", 3600L);
/* 212 */     this.checkpointSize = conf.getLong("fs.checkpoint.size", 4194304L);
/*     */ 
/* 215 */     if (SecurityUtil.useKsslAuth())
/* 216 */       initializeKsslWebServer(infoSocAddr);
/*     */     else {
/* 218 */       initializeHttpWebServer(infoSocAddr);
/*     */     }
/*     */ 
/* 221 */     LOG.info("Web server init done");
/*     */ 
/* 224 */     this.infoPort = this.infoServer.getPort();
/* 225 */     if (!SecurityUtil.useKsslAuth()) {
/* 226 */       this.imagePort = this.infoPort;
/*     */     }
/* 228 */     conf.set("dfs.secondary.http.address", new StringBuilder().append(this.infoBindAddress).append(":").append(this.infoPort).toString());
/* 229 */     LOG.info(new StringBuilder().append("Secondary Web-server up at: ").append(this.infoBindAddress).append(":").append(this.infoPort).toString());
/* 230 */     LOG.warn(new StringBuilder().append("Checkpoint Period   :").append(this.checkpointPeriod).append(" secs ").append("(").append(this.checkpointPeriod / 60L).append(" min)").toString());
/*     */ 
/* 232 */     LOG.warn(new StringBuilder().append("Log Size Trigger    :").append(this.checkpointSize).append(" bytes ").append("(").append(this.checkpointSize / 1024L).append(" KB)").toString());
/*     */   }
/*     */ 
/*     */   private void initializeHttpWebServer(final InetSocketAddress infoSocAddr)
/*     */     throws IOException
/*     */   {
/* 238 */     int tmpInfoPort = infoSocAddr.getPort();
/* 239 */     this.infoServer = new HttpServer("secondary", this.infoBindAddress, tmpInfoPort, tmpInfoPort == 0, this.conf, SecurityUtil.getAdminAcls(this.conf, "dfs.cluster.administrators"))
/*     */     {
/*     */     };
/* 273 */     this.infoServer.setAttribute("secondary.name.node", this);
/* 274 */     this.infoServer.setAttribute("name.system.image", this.checkpointImage);
/* 275 */     this.infoServer.setAttribute("current.conf", this.conf);
/* 276 */     this.infoServer.addInternalServlet("getimage", "/getimage", GetImageServlet.class, true, false);
/*     */ 
/* 278 */     this.infoServer.start();
/*     */   }
/*     */ 
/*     */   private void initializeKsslWebServer(final InetSocketAddress infoSocAddr)
/*     */     throws IOException
/*     */   {
/* 284 */     UserGroupInformation httpUGI = UserGroupInformation.loginUserFromKeytabAndReturnUGI(SecurityUtil.getServerPrincipal(this.conf.get("dfs.secondary.namenode.kerberos.https.principal"), this.infoBindAddress), this.conf.get("dfs.secondary.namenode.keytab.file"));
/*     */     try
/*     */     {
/* 291 */       this.infoServer = ((HttpServer)httpUGI.doAs(new PrivilegedExceptionAction()
/*     */       {
/*     */         public HttpServer run() throws IOException, InterruptedException
/*     */         {
/* 295 */           SecondaryNameNode.LOG.info("Starting web server as: " + UserGroupInformation.getCurrentUser().getUserName());
/*     */ 
/* 298 */           int tmpInfoPort = infoSocAddr.getPort();
/* 299 */           SecondaryNameNode.this.infoServer = new HttpServer("secondary", SecondaryNameNode.this.infoBindAddress, tmpInfoPort, tmpInfoPort == 0, SecondaryNameNode.this.conf, SecurityUtil.getAdminAcls(SecondaryNameNode.this.conf, "dfs.cluster.administrators"));
/*     */ 
/* 303 */           System.setProperty("https.cipherSuites", (String)Krb5AndCertsSslSocketConnector.KRB5_CIPHER_SUITES.get(0));
/*     */ 
/* 305 */           InetSocketAddress secInfoSocAddr = NetUtils.createSocketAddr(SecondaryNameNode.this.infoBindAddress + ":" + SecondaryNameNode.this.conf.getInt("dfs.secondary.https.port", 50490));
/*     */ 
/* 308 */           SecondaryNameNode.this.imagePort = secInfoSocAddr.getPort();
/* 309 */           SecondaryNameNode.this.infoServer.addSslListener(secInfoSocAddr, SecondaryNameNode.this.conf, false, true);
/*     */ 
/* 311 */           SecondaryNameNode.this.infoServer.setAttribute("name.system.image", SecondaryNameNode.this.checkpointImage);
/* 312 */           SecondaryNameNode.this.infoServer.setAttribute("current.conf", SecondaryNameNode.this.conf);
/* 313 */           SecondaryNameNode.this.infoServer.addInternalServlet("getimage", "/getimage", GetImageServlet.class, true, true);
/*     */ 
/* 315 */           SecondaryNameNode.this.infoServer.start();
/* 316 */           return SecondaryNameNode.this.infoServer;
/*     */         } } ));
/*     */     }
/*     */     catch (InterruptedException e) {
/* 320 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void shutdown()
/*     */   {
/* 329 */     this.shouldRun = false;
/*     */     try {
/* 331 */       if (this.infoServer != null) this.infoServer.stop(); 
/*     */     }
/* 333 */     catch (Exception e) { LOG.warn("Exception shutting down SecondaryNameNode", e); }
/*     */     try
/*     */     {
/* 336 */       if (this.checkpointImage != null) this.checkpointImage.close(); 
/*     */     }
/* 338 */     catch (IOException e) { LOG.warn(StringUtils.stringifyException(e)); }
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/* 343 */     if (UserGroupInformation.isSecurityEnabled()) {
/* 344 */       UserGroupInformation ugi = null;
/*     */       try {
/* 346 */         ugi = UserGroupInformation.getLoginUser();
/*     */       } catch (IOException e) {
/* 348 */         LOG.error(StringUtils.stringifyException(e));
/* 349 */         e.printStackTrace();
/* 350 */         Runtime.getRuntime().exit(-1);
/*     */       }
/* 352 */       ugi.doAs(new PrivilegedAction()
/*     */       {
/*     */         public Object run() {
/* 355 */           SecondaryNameNode.this.doWork();
/* 356 */           return null;
/*     */         } } );
/*     */     }
/*     */     else {
/* 360 */       doWork();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void doWork()
/*     */   {
/* 372 */     long period = 300L;
/* 373 */     if (this.checkpointPeriod < period) {
/* 374 */       period = this.checkpointPeriod;
/*     */     }
/*     */ 
/* 377 */     while (this.shouldRun) {
/*     */       try {
/* 379 */         Thread.sleep(1000L * period);
/*     */       }
/*     */       catch (InterruptedException ie) {
/*     */       }
/* 383 */       if (!this.shouldRun) {
/*     */         break;
/*     */       }
/*     */       try
/*     */       {
/* 388 */         if (UserGroupInformation.isSecurityEnabled()) {
/* 389 */           UserGroupInformation.getCurrentUser().reloginFromKeytab();
/*     */         }
/* 391 */         long now = System.currentTimeMillis();
/*     */ 
/* 393 */         long size = this.namenode.getEditLogSize();
/* 394 */         if ((size >= this.checkpointSize) || (now >= this.lastCheckpointTime + 1000L * this.checkpointPeriod))
/*     */         {
/* 396 */           doCheckpoint();
/* 397 */           this.lastCheckpointTime = now;
/*     */         }
/*     */       } catch (IOException e) {
/* 400 */         LOG.error("Exception in doCheckpoint: ");
/* 401 */         LOG.error(StringUtils.stringifyException(e));
/* 402 */         e.printStackTrace();
/*     */       } catch (Throwable e) {
/* 404 */         LOG.error("Throwable Exception in doCheckpoint: ");
/* 405 */         LOG.error(StringUtils.stringifyException(e));
/* 406 */         e.printStackTrace();
/* 407 */         Runtime.getRuntime().exit(-1);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void downloadCheckpointFiles(final CheckpointSignature sig)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 420 */       UserGroupInformation.getCurrentUser().doAs(new PrivilegedExceptionAction()
/*     */       {
/*     */         public Void run() throws Exception
/*     */         {
/* 424 */           SecondaryNameNode.this.checkpointImage.cTime = sig.cTime;
/* 425 */           SecondaryNameNode.this.checkpointImage.checkpointTime = sig.checkpointTime;
/*     */ 
/* 428 */           String fileid = "getimage=1";
/* 429 */           File[] srcNames = SecondaryNameNode.this.checkpointImage.getImageFiles();
/* 430 */           assert (srcNames.length > 0) : "No checkpoint targets.";
/* 431 */           TransferFsImage.getFileClient(SecondaryNameNode.this.fsName, fileid, srcNames, false);
/* 432 */           SecondaryNameNode.LOG.info("Downloaded file " + srcNames[0].getName() + " size " + srcNames[0].length() + " bytes.");
/*     */ 
/* 436 */           fileid = "getedit=1";
/* 437 */           srcNames = SecondaryNameNode.this.checkpointImage.getEditsFiles();
/* 438 */           assert (srcNames.length > 0) : "No checkpoint targets.";
/* 439 */           TransferFsImage.getFileClient(SecondaryNameNode.this.fsName, fileid, srcNames, false);
/* 440 */           SecondaryNameNode.LOG.info("Downloaded file " + srcNames[0].getName() + " size " + srcNames[0].length() + " bytes.");
/*     */ 
/* 443 */           SecondaryNameNode.this.checkpointImage.checkpointUploadDone();
/* 444 */           return null;
/*     */         } } );
/*     */     }
/*     */     catch (InterruptedException e) {
/* 448 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void putFSImage(CheckpointSignature sig)
/*     */     throws IOException
/*     */   {
/* 457 */     String fileid = new StringBuilder().append("putimage=1&port=").append(this.imagePort).append("&machine=").append(this.infoBindAddress).append("&token=").append(sig.toString()).append("&newChecksum=").append(getNewChecksum()).toString();
/*     */ 
/* 461 */     LOG.info(new StringBuilder().append("Posted URL ").append(this.fsName).append(fileid).toString());
/* 462 */     TransferFsImage.getFileClient(this.fsName, fileid, (File[])null, false);
/*     */   }
/*     */ 
/*     */   MD5Hash getNewChecksum()
/*     */     throws IOException
/*     */   {
/* 470 */     DigestInputStream imageIn = null;
/*     */     try {
/* 472 */       MessageDigest digester = MD5Hash.getDigester();
/* 473 */       imageIn = new DigestInputStream(new FileInputStream(this.checkpointImage.getFsImageName()), digester);
/*     */ 
/* 475 */       byte[] in = new byte[FSConstants.BUFFER_SIZE];
/* 476 */       int totalRead = 0;
/* 477 */       int read = 0;
/* 478 */       while ((read = imageIn.read(in)) > 0) {
/* 479 */         totalRead += read;
/* 480 */         LOG.debug(new StringBuilder().append("Computing fsimage checksum. Read ").append(totalRead).append(" bytes so far.").toString());
/*     */       }
/* 482 */       return new MD5Hash(digester.digest());
/*     */     } finally {
/* 484 */       if (imageIn != null)
/* 485 */         imageIn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getInfoServer()
/*     */     throws IOException
/*     */   {
/* 494 */     String infoAddr = NameNode.getInfoServer(this.conf);
/* 495 */     if (infoAddr == null) {
/* 496 */       throw new IOException("This is not a DFS");
/*     */     }
/* 498 */     LOG.debug(new StringBuilder().append("infoAddr = ").append(infoAddr).toString());
/* 499 */     return infoAddr;
/*     */   }
/*     */ 
/*     */   void doCheckpoint()
/*     */     throws IOException
/*     */   {
/* 508 */     startCheckpoint();
/*     */ 
/* 512 */     CheckpointSignature sig = this.namenode.rollEditLog();
/*     */ 
/* 515 */     if (ErrorSimulator.getErrorSimulation(0)) {
/* 516 */       throw new IOException("Simulating error0 after creating edits.new");
/*     */     }
/*     */ 
/* 520 */     downloadCheckpointFiles(sig);
/* 521 */     doMerge(sig);
/*     */ 
/* 525 */     putFSImage(sig);
/*     */ 
/* 528 */     if (ErrorSimulator.getErrorSimulation(1)) {
/* 529 */       throw new IOException("Simulating error1 after uploading new image to NameNode");
/*     */     }
/*     */ 
/* 535 */     this.namenode.rollFsImage();
/* 536 */     this.checkpointImage.endCheckpoint();
/*     */ 
/* 538 */     LOG.info(new StringBuilder().append("Checkpoint done. New Image Size: ").append(this.checkpointImage.getFsImageName().length()).toString());
/*     */   }
/*     */ 
/*     */   private void startCheckpoint() throws IOException
/*     */   {
/* 543 */     this.checkpointImage.unlockAll();
/* 544 */     this.checkpointImage.getEditLog().close();
/* 545 */     this.checkpointImage.recoverCreate(this.checkpointDirs, this.checkpointEditsDirs);
/* 546 */     this.checkpointImage.startCheckpoint();
/*     */   }
/*     */ 
/*     */   private void doMerge(CheckpointSignature sig)
/*     */     throws IOException
/*     */   {
/* 554 */     FSNamesystem namesystem = new FSNamesystem(this.checkpointImage, this.conf);
/*     */ 
/* 556 */     assert (namesystem.dir.fsImage == this.checkpointImage);
/* 557 */     this.checkpointImage.doMerge(sig);
/*     */   }
/*     */ 
/*     */   private int processArgs(String[] argv)
/*     */     throws Exception
/*     */   {
/* 567 */     if (argv.length < 1) {
/* 568 */       printUsage("");
/* 569 */       return -1;
/*     */     }
/*     */ 
/* 572 */     int exitCode = -1;
/* 573 */     int i = 0;
/* 574 */     String cmd = argv[(i++)];
/*     */ 
/* 579 */     if ("-geteditsize".equals(cmd)) {
/* 580 */       if (argv.length != 1) {
/* 581 */         printUsage(cmd);
/* 582 */         return exitCode;
/*     */       }
/* 584 */     } else if ("-checkpoint".equals(cmd)) {
/* 585 */       if ((argv.length != 1) && (argv.length != 2)) {
/* 586 */         printUsage(cmd);
/* 587 */         return exitCode;
/*     */       }
/* 589 */       if ((argv.length == 2) && (!"force".equals(argv[i]))) {
/* 590 */         printUsage(cmd);
/* 591 */         return exitCode;
/*     */       }
/*     */     }
/*     */ 
/* 595 */     exitCode = 0;
/*     */     try {
/* 597 */       if ("-checkpoint".equals(cmd)) {
/* 598 */         long size = this.namenode.getEditLogSize();
/* 599 */         if ((size >= this.checkpointSize) || ((argv.length == 2) && ("force".equals(argv[i]))))
/*     */         {
/* 601 */           doCheckpoint();
/*     */         } else {
/* 603 */           System.err.println(new StringBuilder().append("EditLog size ").append(size).append(" bytes is ").append("smaller than configured checkpoint ").append("size ").append(this.checkpointSize).append(" bytes.").toString());
/*     */ 
/* 606 */           System.err.println("Skipping checkpoint.");
/*     */         }
/* 608 */       } else if ("-geteditsize".equals(cmd)) {
/* 609 */         long size = this.namenode.getEditLogSize();
/* 610 */         System.out.println(new StringBuilder().append("EditLog size is ").append(size).append(" bytes").toString());
/*     */       } else {
/* 612 */         exitCode = -1;
/* 613 */         LOG.error(new StringBuilder().append(cmd.substring(1)).append(": Unknown command").toString());
/* 614 */         printUsage("");
/*     */       }
/*     */     } catch (RemoteException e) { e = 
/* 639 */         e;
/*     */ 
/* 620 */       exitCode = -1;
/*     */       try
/*     */       {
/* 623 */         String[] content = e.getLocalizedMessage().split("\n");
/* 624 */         LOG.error(new StringBuilder().append(cmd.substring(1)).append(": ").append(content[0]).toString());
/*     */       }
/*     */       catch (Exception ex) {
/* 627 */         LOG.error(new StringBuilder().append(cmd.substring(1)).append(": ").append(ex.getLocalizedMessage()).toString());
/*     */       }
/*     */     } catch (IOException e) {
/* 630 */       e = 
/* 639 */         e;
/*     */ 
/* 634 */       exitCode = -1;
/* 635 */       LOG.error(new StringBuilder().append(cmd.substring(1)).append(": ").append(e.getLocalizedMessage()).toString());
/*     */     }
/*     */     finally
/*     */     {
/*     */     }
/* 640 */     return exitCode;
/*     */   }
/*     */ 
/*     */   private void printUsage(String cmd)
/*     */   {
/* 648 */     if ("-geteditsize".equals(cmd)) {
/* 649 */       System.err.println("Usage: java SecondaryNameNode [-geteditsize]");
/*     */     }
/* 651 */     else if ("-checkpoint".equals(cmd)) {
/* 652 */       System.err.println("Usage: java SecondaryNameNode [-checkpoint [force]]");
/*     */     }
/*     */     else
/* 655 */       System.err.println("Usage: java SecondaryNameNode [-checkpoint [force]] [-geteditsize] ");
/*     */   }
/*     */ 
/*     */   public static void main(String[] argv)
/*     */     throws Exception
/*     */   {
/* 667 */     StringUtils.startupShutdownMessage(SecondaryNameNode.class, argv, LOG);
/* 668 */     Configuration tconf = new Configuration();
/* 669 */     if (argv.length >= 1) {
/* 670 */       SecondaryNameNode secondary = new SecondaryNameNode(tconf);
/* 671 */       int ret = secondary.processArgs(argv);
/* 672 */       System.exit(ret);
/*     */     }
/*     */ 
/* 676 */     Daemon checkpointThread = new Daemon(new SecondaryNameNode(tconf));
/* 677 */     checkpointThread.start();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  73 */     Configuration.addDefaultResource("hdfs-default.xml");
/*  74 */     Configuration.addDefaultResource("hdfs-site.xml");
/*     */   }
/*     */ 
/*     */   static class CheckpointStorage extends FSImage
/*     */   {
/*     */     CheckpointStorage()
/*     */       throws IOException
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean isConversionNeeded(Storage.StorageDirectory sd)
/*     */     {
/* 690 */       return false;
/*     */     }
/*     */ 
/*     */     void recoverCreate(Collection<File> dataDirs, Collection<File> editsDirs)
/*     */       throws IOException
/*     */     {
/* 704 */       Collection tempDataDirs = new ArrayList(dataDirs);
/* 705 */       Collection tempEditsDirs = new ArrayList(editsDirs);
/* 706 */       this.storageDirs = new ArrayList();
/* 707 */       setStorageDirectories(tempDataDirs, tempEditsDirs);
/* 708 */       Iterator it = dirIterator();
/* 709 */       while (it.hasNext()) {
/* 710 */         Storage.StorageDirectory sd = (Storage.StorageDirectory)it.next();
/* 711 */         boolean isAccessible = true;
/*     */         try {
/* 713 */           if (sd.getRoot().mkdirs());
/*     */         }
/*     */         catch (SecurityException se)
/*     */         {
/* 717 */           isAccessible = false;
/*     */         }
/* 719 */         if (!isAccessible) {
/* 720 */           throw new InconsistentFSStateException(sd.getRoot(), "cannot access checkpoint directory.");
/*     */         }
/*     */         try
/*     */         {
/* 724 */           Storage.StorageState curState = sd.analyzeStorage(HdfsConstants.StartupOption.REGULAR);
/*     */ 
/* 726 */           switch (SecondaryNameNode.5.$SwitchMap$org$apache$hadoop$hdfs$server$common$Storage$StorageState[curState.ordinal()])
/*     */           {
/*     */           case 1:
/* 729 */             throw new InconsistentFSStateException(sd.getRoot(), "checkpoint directory does not exist or is not accessible.");
/*     */           case 2:
/* 732 */             break;
/*     */           case 3:
/* 734 */             break;
/*     */           default:
/* 736 */             sd.doRecover(curState);
/*     */           }
/*     */         } catch (IOException ioe) {
/* 739 */           sd.unlock();
/* 740 */           throw ioe;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     void startCheckpoint()
/*     */       throws IOException
/*     */     {
/* 753 */       for (Storage.StorageDirectory sd : this.storageDirs)
/* 754 */         moveCurrent(sd);
/*     */     }
/*     */ 
/*     */     void endCheckpoint() throws IOException
/*     */     {
/* 759 */       for (Storage.StorageDirectory sd : this.storageDirs)
/* 760 */         moveLastCheckpoint(sd);
/*     */     }
/*     */ 
/*     */     private void doMerge(CheckpointSignature sig)
/*     */       throws IOException
/*     */     {
/* 768 */       getEditLog().open();
/* 769 */       Storage.StorageDirectory sdName = null;
/* 770 */       Storage.StorageDirectory sdEdits = null;
/* 771 */       Iterator it = null;
/* 772 */       it = dirIterator(FSImage.NameNodeDirType.IMAGE);
/* 773 */       if (it.hasNext())
/* 774 */         sdName = (Storage.StorageDirectory)it.next();
/* 775 */       it = dirIterator(FSImage.NameNodeDirType.EDITS);
/* 776 */       if (it.hasNext())
/* 777 */         sdEdits = (Storage.StorageDirectory)it.next();
/* 778 */       if ((sdName == null) || (sdEdits == null))
/* 779 */         throw new IOException("Could not locate checkpoint directories");
/* 780 */       loadFSImage(FSImage.getImageFile(sdName, FSImage.NameNodeFile.IMAGE));
/* 781 */       loadFSEdits(sdEdits, null);
/* 782 */       sig.validateStorageInfo(this);
/* 783 */       saveNamespace(false);
/*     */     }
/*     */   }
/*     */ 
/*     */   static class ErrorSimulator
/*     */   {
/* 115 */     private static boolean[] simulation = null;
/*     */ 
/* 117 */     static void initializeErrorSimulationEvent(int numberOfEvents) { simulation = new boolean[numberOfEvents];
/* 118 */       for (int i = 0; i < numberOfEvents; i++)
/* 119 */         simulation[i] = false;
/*     */     }
/*     */ 
/*     */     static boolean getErrorSimulation(int index)
/*     */     {
/* 124 */       if (simulation == null)
/* 125 */         return false;
/* 126 */       assert (index < simulation.length);
/* 127 */       return simulation[index];
/*     */     }
/*     */ 
/*     */     static void setErrorSimulation(int index) {
/* 131 */       assert (index < simulation.length);
/* 132 */       simulation[index] = true;
/*     */     }
/*     */ 
/*     */     static void clearErrorSimulation(int index) {
/* 136 */       assert (index < simulation.length);
/* 137 */       simulation[index] = false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.SecondaryNameNode
 * JD-Core Version:    0.6.1
 */
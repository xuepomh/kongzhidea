/*    */ package org.apache.hadoop.hdfs.server.protocol;
/*    */ 
/*    */ import java.io.DataInput;
/*    */ import java.io.DataOutput;
/*    */ import java.io.IOException;
/*    */ import org.apache.hadoop.io.Writable;
/*    */ import org.apache.hadoop.io.WritableFactories;
/*    */ import org.apache.hadoop.io.WritableFactory;
/*    */ 
/*    */ public abstract class DatanodeCommand
/*    */   implements Writable
/*    */ {
/* 48 */   public static final DatanodeCommand REGISTER = new Register(null);
/* 49 */   public static final DatanodeCommand FINALIZE = new Finalize(null);
/*    */   private int action;
/*    */ 
/*    */   public DatanodeCommand()
/*    */   {
/* 54 */     this(0);
/*    */   }
/*    */ 
/*    */   DatanodeCommand(int action) {
/* 58 */     this.action = action;
/*    */   }
/*    */ 
/*    */   public int getAction() {
/* 62 */     return this.action;
/*    */   }
/*    */ 
/*    */   public void write(DataOutput out)
/*    */     throws IOException
/*    */   {
/* 69 */     out.writeInt(this.action);
/*    */   }
/*    */ 
/*    */   public void readFields(DataInput in) throws IOException {
/* 73 */     this.action = in.readInt();
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 38 */     WritableFactories.setFactory(Register.class, new WritableFactory() {
/*    */       public Writable newInstance() {
/* 40 */         return new DatanodeCommand.Register(null);
/*    */       }
/*    */     });
/* 42 */     WritableFactories.setFactory(Finalize.class, new WritableFactory() {
/*    */       public Writable newInstance() {
/* 44 */         return new DatanodeCommand.Finalize(null);
/*    */       }
/*    */     });
/*    */   }
/*    */ 
/*    */   static class Finalize extends DatanodeCommand
/*    */   {
/*    */     private Finalize()
/*    */     {
/* 32 */       super();
/*    */     }
/*    */ 
/*    */     public void readFields(DataInput in)
/*    */     {
/*    */     }
/*    */ 
/*    */     public void write(DataOutput out)
/*    */     {
/*    */     }
/*    */   }
/*    */ 
/*    */   static class Register extends DatanodeCommand
/*    */   {
/*    */     private Register()
/*    */     {
/* 26 */       super();
/*    */     }
/*    */ 
/*    */     public void readFields(DataInput in)
/*    */     {
/*    */     }
/*    */ 
/*    */     public void write(DataOutput out)
/*    */     {
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.protocol.DatanodeCommand
 * JD-Core Version:    0.6.1
 */
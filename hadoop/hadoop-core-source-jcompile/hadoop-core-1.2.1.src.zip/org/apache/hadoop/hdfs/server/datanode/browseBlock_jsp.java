/*     */ package org.apache.hadoop.hdfs.server.datanode;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.jsp.JspFactory;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.SkipPageException;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.hdfs.DFSClient;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.hdfs.protocol.ClientProtocol;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlock;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlocks;
/*     */ import org.apache.hadoop.hdfs.security.token.block.BlockTokenSecretManager;
/*     */ import org.apache.hadoop.hdfs.server.namenode.JspHelper;
/*     */ import org.apache.hadoop.http.HtmlQuoting;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.token.Token;
/*     */ import org.apache.hadoop.util.ServletUtil;
/*     */ import org.apache.jasper.runtime.HttpJspBase;
/*     */ import org.apache.jasper.runtime.JspSourceDependent;
/*     */ import org.apache.jasper.runtime.ResourceInjector;
/*     */ 
/*     */ public final class browseBlock_jsp extends HttpJspBase
/*     */   implements JspSourceDependent
/*     */ {
/*  46 */   static JspHelper jspHelper = new JspHelper();
/*     */ 
/* 430 */   private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();
/*     */   private static Vector _jspx_dependants;
/*     */   private ResourceInjector _jspx_resourceInjector;
/*     */ 
/*     */   public void generateFileDetails(JspWriter out, HttpServletRequest req, Configuration conf)
/*     */     throws IOException, InterruptedException
/*     */   {
/*  52 */     int chunkSizeToView = 0;
/*  53 */     long startOffset = 0L;
/*     */ 
/*  56 */     String blockIdStr = null;
/*  57 */     long currBlockId = 0L;
/*  58 */     blockIdStr = req.getParameter("blockId");
/*  59 */     if (blockIdStr == null) {
/*  60 */       out.print("Invalid input (blockId absent)");
/*  61 */       return;
/*     */     }
/*  63 */     currBlockId = Long.parseLong(blockIdStr);
/*     */ 
/*  65 */     String datanodePortStr = req.getParameter("datanodePort");
/*  66 */     if (datanodePortStr == null) {
/*  67 */       out.print("Invalid input (datanodePort absent)");
/*  68 */       return;
/*     */     }
/*  70 */     int datanodePort = Integer.parseInt(datanodePortStr);
/*     */ 
/*  72 */     String namenodeInfoPortStr = req.getParameter("namenodeInfoPort");
/*  73 */     int namenodeInfoPort = -1;
/*  74 */     if (namenodeInfoPortStr != null) {
/*  75 */       namenodeInfoPort = Integer.parseInt(namenodeInfoPortStr);
/*     */     }
/*  77 */     String chunkSizeToViewStr = req.getParameter("chunkSizeToView");
/*  78 */     if ((chunkSizeToViewStr != null) && (Integer.parseInt(chunkSizeToViewStr) > 0))
/*     */     {
/*  80 */       chunkSizeToView = Integer.parseInt(chunkSizeToViewStr);
/*     */     }
/*  82 */     else chunkSizeToView = JspHelper.getDefaultChunkSize(conf);
/*     */ 
/*  85 */     String startOffsetStr = req.getParameter("startOffset");
/*  86 */     if ((startOffsetStr == null) || (Long.parseLong(startOffsetStr) < 0L))
/*  87 */       startOffset = 0L;
/*  88 */     else startOffset = Long.parseLong(startOffsetStr);
/*     */ 
/*  90 */     String filename = HtmlQuoting.unquoteHtmlChars(req.getParameter("filename"));
/*  91 */     if ((filename == null) || (filename.length() == 0)) {
/*  92 */       out.print("Invalid input");
/*  93 */       return;
/*     */     }
/*     */ 
/*  96 */     String blockSizeStr = req.getParameter("blockSize");
/*  97 */     long blockSize = 0L;
/*  98 */     if ((blockSizeStr == null) || (blockSizeStr.length() == 0)) {
/*  99 */       out.print("Invalid input");
/* 100 */       return; } blockSize = Long.parseLong(blockSizeStr);
/*     */ 
/* 104 */     String tokenString = req.getParameter("delegation");
/* 105 */     UserGroupInformation ugi = JspHelper.getUGI(req, conf);
/* 106 */     DFSClient dfs = JspHelper.getDFSClient(ugi, JspHelper.nameNodeAddr, conf);
/* 107 */     List blocks = dfs.namenode.getBlockLocations(filename, 0L, 9223372036854775807L).getLocatedBlocks();
/*     */ 
/* 111 */     String downloadUrl = "http://" + req.getServerName() + ":" + req.getServerPort() + "/streamFile" + URLEncoder.encode(filename, "UTF-8") + "?" + "delegation" + "=" + tokenString;
/*     */ 
/* 116 */     out.print("<a name=\"viewOptions\"></a>");
/* 117 */     out.print("<a href=\"" + downloadUrl + "\">Download this file</a><br>");
/*     */ 
/* 121 */     LocatedBlock lastBlk = (LocatedBlock)blocks.get(blocks.size() - 1);
/* 122 */     long blockId = lastBlk.getBlock().getBlockId();
/*     */     DatanodeInfo chosenNode;
/*     */     try { chosenNode = JspHelper.bestNode(lastBlk);
/*     */     } catch (IOException e) {
/* 126 */       out.print(e.toString());
/* 127 */       dfs.close();
/* 128 */       return;
/*     */     }
/* 130 */     String fqdn = InetAddress.getByName(chosenNode.getHost()).getCanonicalHostName();
/*     */ 
/* 132 */     String tailUrl = "http://" + fqdn + ":" + chosenNode.getInfoPort() + "/tail.jsp?filename=" + URLEncoder.encode(filename, "UTF-8") + "&namenodeInfoPort=" + namenodeInfoPort + "&chunkSizeToView=" + chunkSizeToView + "&referrer=" + URLEncoder.encode(new StringBuilder().append(req.getRequestURL()).append("?").append(req.getQueryString()).toString(), "UTF-8") + JspHelper.getDelegationTokenUrlParam(tokenString);
/*     */ 
/* 141 */     out.print("<a href=\"" + tailUrl + "\">Tail this file</a><br>");
/*     */ 
/* 143 */     out.print("<form action=\"/browseBlock.jsp\" method=GET>");
/* 144 */     out.print("<b>Chunk size to view (in bytes, up to file's DFS block size): </b>");
/* 145 */     out.print("<input type=\"hidden\" name=\"blockId\" value=\"" + currBlockId + "\">");
/*     */ 
/* 147 */     out.print("<input type=\"hidden\" name=\"blockSize\" value=\"" + blockSize + "\">");
/*     */ 
/* 149 */     out.print("<input type=\"hidden\" name=\"startOffset\" value=\"" + startOffset + "\">");
/*     */ 
/* 151 */     out.print("<input type=\"hidden\" name=\"filename\" value=\"" + filename + "\">");
/*     */ 
/* 153 */     out.print("<input type=\"hidden\" name=\"datanodePort\" value=\"" + datanodePort + "\">");
/*     */ 
/* 155 */     out.print("<input type=\"hidden\" name=\"namenodeInfoPort\" value=\"" + namenodeInfoPort + "\">");
/*     */ 
/* 157 */     out.print("<input type=\"text\" name=\"chunkSizeToView\" value=" + chunkSizeToView + " size=10 maxlength=10>");
/*     */ 
/* 159 */     out.print("&nbsp;&nbsp;<input type=\"submit\" name=\"submit\" value=\"Refresh\">");
/* 160 */     out.print("</form>");
/* 161 */     out.print("<hr>");
/* 162 */     out.print("<a name=\"blockDetails\"></a>");
/* 163 */     out.print("<B>Total number of blocks: " + blocks.size() + "</B><br>");
/*     */ 
/* 165 */     out.println("\n<table>");
/* 166 */     for (LocatedBlock cur : blocks) {
/* 167 */       out.print("<tr>");
/* 168 */       blockId = cur.getBlock().getBlockId();
/* 169 */       blockSize = cur.getBlock().getNumBytes();
/* 170 */       String blk = "blk_" + Long.toString(blockId);
/* 171 */       out.print("<td>" + Long.toString(blockId) + ":</td>");
/* 172 */       DatanodeInfo[] locs = cur.getLocations();
/* 173 */       for (int j = 0; j < locs.length; j++) {
/* 174 */         String datanodeAddr = locs[j].getName();
/* 175 */         datanodePort = Integer.parseInt(datanodeAddr.substring(datanodeAddr.indexOf(':') + 1, datanodeAddr.length()));
/*     */ 
/* 178 */         fqdn = InetAddress.getByName(locs[j].getHost()).getCanonicalHostName();
/* 179 */         String blockUrl = "http://" + fqdn + ":" + locs[j].getInfoPort() + "/browseBlock.jsp?blockId=" + Long.toString(blockId) + "&blockSize=" + blockSize + "&filename=" + URLEncoder.encode(filename, "UTF-8") + "&datanodePort=" + datanodePort + "&genstamp=" + cur.getBlock().getGenerationStamp() + "&namenodeInfoPort=" + namenodeInfoPort + "&chunkSizeToView=" + chunkSizeToView;
/*     */ 
/* 188 */         out.print("<td>&nbsp</td><td><a href=\"" + blockUrl + "\">" + datanodeAddr + "</a></td>");
/*     */       }
/*     */ 
/* 191 */       out.println("</tr>");
/*     */     }
/* 193 */     out.println("</table>");
/* 194 */     out.print("<hr>");
/* 195 */     String namenodeHost = JspHelper.nameNodeAddr.getHostName();
/* 196 */     out.print("<br><a href=\"http://" + InetAddress.getByName(namenodeHost).getCanonicalHostName() + ":" + namenodeInfoPort + "/dfshealth.jsp\">Go back to DFS home</a>");
/*     */ 
/* 199 */     dfs.close();
/*     */   }
/*     */ 
/*     */   public void generateFileChunks(JspWriter out, HttpServletRequest req, Configuration conf)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 205 */     long startOffset = 0L;
/* 206 */     int datanodePort = 0;
/* 207 */     int chunkSizeToView = 0;
/*     */ 
/* 209 */     String namenodeInfoPortStr = req.getParameter("namenodeInfoPort");
/* 210 */     int namenodeInfoPort = -1;
/* 211 */     if (namenodeInfoPortStr != null) {
/* 212 */       namenodeInfoPort = Integer.parseInt(namenodeInfoPortStr);
/*     */     }
/* 214 */     String filename = HtmlQuoting.unquoteHtmlChars(req.getParameter("filename"));
/* 215 */     if (filename == null) {
/* 216 */       out.print("Invalid input (filename absent)");
/* 217 */       return;
/*     */     }
/*     */ 
/* 220 */     String blockIdStr = null;
/* 221 */     long blockId = 0L;
/* 222 */     blockIdStr = req.getParameter("blockId");
/* 223 */     if (blockIdStr == null) {
/* 224 */       out.print("Invalid input (blockId absent)");
/* 225 */       return;
/*     */     }
/* 227 */     blockId = Long.parseLong(blockIdStr);
/*     */ 
/* 229 */     String tokenString = req.getParameter("delegation");
/* 230 */     UserGroupInformation ugi = JspHelper.getUGI(req, conf);
/* 231 */     DFSClient dfs = JspHelper.getDFSClient(ugi, JspHelper.nameNodeAddr, conf);
/*     */ 
/* 234 */     Token accessToken = BlockTokenSecretManager.DUMMY_TOKEN;
/* 235 */     if (conf.getBoolean("dfs.block.access.token.enable", false))
/*     */     {
/* 237 */       List blks = dfs.namenode.getBlockLocations(filename, 0L, 9223372036854775807L).getLocatedBlocks();
/*     */ 
/* 239 */       if ((blks == null) || (blks.size() == 0)) {
/* 240 */         out.print("Can't locate file blocks");
/* 241 */         dfs.close();
/* 242 */         return;
/*     */       }
/* 244 */       for (int i = 0; i < blks.size(); i++) {
/* 245 */         if (((LocatedBlock)blks.get(i)).getBlock().getBlockId() == blockId) {
/* 246 */           accessToken = ((LocatedBlock)blks.get(i)).getBlockToken();
/* 247 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 252 */     String blockGenStamp = null;
/* 253 */     long genStamp = 0L;
/* 254 */     blockGenStamp = req.getParameter("genstamp");
/* 255 */     if (blockGenStamp == null) {
/* 256 */       out.print("Invalid input (genstamp absent)");
/* 257 */       return;
/*     */     }
/* 259 */     genStamp = Long.parseLong(blockGenStamp);
/*     */ 
/* 262 */     long blockSize = 0L;
/* 263 */     String blockSizeStr = req.getParameter("blockSize");
/* 264 */     if (blockSizeStr == null) {
/* 265 */       out.print("Invalid input (blockSize absent)");
/* 266 */       return;
/*     */     }
/* 268 */     blockSize = Long.parseLong(blockSizeStr);
/*     */ 
/* 270 */     String chunkSizeToViewStr = req.getParameter("chunkSizeToView");
/* 271 */     if ((chunkSizeToViewStr != null) && (Integer.parseInt(chunkSizeToViewStr) > 0))
/* 272 */       chunkSizeToView = Integer.parseInt(chunkSizeToViewStr);
/* 273 */     else chunkSizeToView = JspHelper.getDefaultChunkSize(conf);
/*     */ 
/* 275 */     String startOffsetStr = req.getParameter("startOffset");
/* 276 */     if ((startOffsetStr == null) || (Long.parseLong(startOffsetStr) < 0L))
/* 277 */       startOffset = 0L;
/* 278 */     else startOffset = Long.parseLong(startOffsetStr);
/*     */ 
/* 280 */     String datanodePortStr = req.getParameter("datanodePort");
/* 281 */     if (datanodePortStr == null) {
/* 282 */       out.print("Invalid input (datanodePort absent)");
/* 283 */       return;
/*     */     }
/* 285 */     datanodePort = Integer.parseInt(datanodePortStr);
/* 286 */     out.print("<h3>File: ");
/* 287 */     JspHelper.printPathWithLinks(HtmlQuoting.quoteHtmlChars(filename), out, namenodeInfoPort, tokenString);
/*     */ 
/* 289 */     out.print("</h3><hr>");
/* 290 */     String parent = new File(filename).getParent();
/* 291 */     JspHelper.printGotoForm(out, namenodeInfoPort, tokenString, HtmlQuoting.quoteHtmlChars(parent));
/*     */ 
/* 293 */     out.print("<hr>");
/* 294 */     out.print("<a href=\"http://" + req.getServerName() + ":" + req.getServerPort() + "/browseDirectory.jsp?dir=" + URLEncoder.encode(parent, "UTF-8") + "&namenodeInfoPort=" + namenodeInfoPort + "\"><i>Go back to dir listing</i></a><br>");
/*     */ 
/* 300 */     out.print("<a href=\"#viewOptions\">Advanced view/download options</a><br>");
/* 301 */     out.print("<hr>");
/*     */ 
/* 304 */     long nextStartOffset = 0L;
/* 305 */     long nextBlockSize = 0L;
/* 306 */     String nextBlockIdStr = null;
/* 307 */     String nextGenStamp = null;
/* 308 */     String nextHost = req.getServerName();
/* 309 */     int nextPort = req.getServerPort();
/* 310 */     int nextDatanodePort = datanodePort;
/*     */ 
/* 312 */     if (startOffset + chunkSizeToView >= blockSize)
/*     */     {
/* 314 */       List blocks = dfs.namenode.getBlockLocations(filename, 0L, 9223372036854775807L).getLocatedBlocks();
/*     */ 
/* 316 */       for (int i = 0; i < blocks.size(); i++) {
/* 317 */         if ((((LocatedBlock)blocks.get(i)).getBlock().getBlockId() == blockId) && 
/* 318 */           (i != blocks.size() - 1)) {
/* 319 */           LocatedBlock nextBlock = (LocatedBlock)blocks.get(i + 1);
/* 320 */           nextBlockIdStr = Long.toString(nextBlock.getBlock().getBlockId());
/* 321 */           nextGenStamp = Long.toString(nextBlock.getBlock().getGenerationStamp());
/* 322 */           nextStartOffset = 0L;
/* 323 */           nextBlockSize = nextBlock.getBlock().getNumBytes();
/* 324 */           DatanodeInfo d = JspHelper.bestNode(nextBlock);
/* 325 */           String datanodeAddr = d.getName();
/* 326 */           nextDatanodePort = Integer.parseInt(datanodeAddr.substring(datanodeAddr.indexOf(':') + 1, datanodeAddr.length()));
/*     */ 
/* 330 */           nextHost = InetAddress.getByName(d.getHost()).getCanonicalHostName();
/* 331 */           nextPort = d.getInfoPort();
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 338 */       nextBlockIdStr = blockIdStr;
/* 339 */       nextStartOffset = startOffset + chunkSizeToView;
/* 340 */       nextBlockSize = blockSize;
/* 341 */       nextGenStamp = blockGenStamp;
/*     */     }
/* 343 */     String nextUrl = null;
/* 344 */     if (nextBlockIdStr != null) {
/* 345 */       nextUrl = "http://" + nextHost + ":" + nextPort + "/browseBlock.jsp?blockId=" + nextBlockIdStr + "&blockSize=" + nextBlockSize + "&startOffset=" + nextStartOffset + "&genstamp=" + nextGenStamp + "&filename=" + URLEncoder.encode(filename, "UTF-8") + "&chunkSizeToView=" + chunkSizeToView + "&datanodePort=" + nextDatanodePort + "&namenodeInfoPort=" + namenodeInfoPort + JspHelper.getDelegationTokenUrlParam(tokenString);
/*     */ 
/* 356 */       out.print("<a href=\"" + nextUrl + "\">View Next chunk</a>&nbsp;&nbsp;");
/*     */     }
/*     */ 
/* 359 */     String prevBlockIdStr = null;
/* 360 */     String prevGenStamp = null;
/* 361 */     long prevStartOffset = 0L;
/* 362 */     long prevBlockSize = 0L;
/* 363 */     String prevHost = req.getServerName();
/* 364 */     int prevPort = req.getServerPort();
/* 365 */     int prevDatanodePort = datanodePort;
/* 366 */     if (startOffset == 0L) {
/* 367 */       List blocks = dfs.namenode.getBlockLocations(filename, 0L, 9223372036854775807L).getLocatedBlocks();
/*     */ 
/* 369 */       for (int i = 0; i < blocks.size(); i++) {
/* 370 */         if ((((LocatedBlock)blocks.get(i)).getBlock().getBlockId() == blockId) && 
/* 371 */           (i != 0)) {
/* 372 */           LocatedBlock prevBlock = (LocatedBlock)blocks.get(i - 1);
/* 373 */           prevBlockIdStr = Long.toString(prevBlock.getBlock().getBlockId());
/* 374 */           prevGenStamp = Long.toString(prevBlock.getBlock().getGenerationStamp());
/* 375 */           prevStartOffset = prevBlock.getBlock().getNumBytes() - chunkSizeToView;
/* 376 */           if (prevStartOffset < 0L)
/* 377 */             prevStartOffset = 0L;
/* 378 */           prevBlockSize = prevBlock.getBlock().getNumBytes();
/* 379 */           DatanodeInfo d = JspHelper.bestNode(prevBlock);
/* 380 */           String datanodeAddr = d.getName();
/* 381 */           prevDatanodePort = Integer.parseInt(datanodeAddr.substring(datanodeAddr.indexOf(':') + 1, datanodeAddr.length()));
/*     */ 
/* 385 */           prevHost = InetAddress.getByName(d.getHost()).getCanonicalHostName();
/* 386 */           prevPort = d.getInfoPort();
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 393 */       prevBlockIdStr = blockIdStr;
/* 394 */       prevStartOffset = startOffset - chunkSizeToView;
/* 395 */       if (prevStartOffset < 0L) prevStartOffset = 0L;
/* 396 */       prevBlockSize = blockSize;
/* 397 */       prevGenStamp = blockGenStamp;
/*     */     }
/*     */ 
/* 400 */     String prevUrl = null;
/* 401 */     if (prevBlockIdStr != null) {
/* 402 */       prevUrl = "http://" + prevHost + ":" + prevPort + "/browseBlock.jsp?blockId=" + prevBlockIdStr + "&blockSize=" + prevBlockSize + "&startOffset=" + prevStartOffset + "&filename=" + URLEncoder.encode(filename, "UTF-8") + "&chunkSizeToView=" + chunkSizeToView + "&genstamp=" + prevGenStamp + "&datanodePort=" + prevDatanodePort + "&namenodeInfoPort=" + namenodeInfoPort + JspHelper.getDelegationTokenUrlParam(tokenString);
/*     */ 
/* 413 */       out.print("<a href=\"" + prevUrl + "\">View Prev chunk</a>&nbsp;&nbsp;");
/*     */     }
/* 415 */     out.print("<hr>");
/* 416 */     out.print("<textarea cols=\"100\" rows=\"25\" wrap=\"virtual\" style=\"width:100%\" READONLY>");
/*     */     try {
/* 418 */       jspHelper.streamBlockInAscii(new InetSocketAddress(req.getServerName(), datanodePort), blockId, accessToken, genStamp, blockSize, startOffset, chunkSizeToView, out, conf);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 423 */       out.print(e);
/*     */     }
/* 425 */     out.print("</textarea>");
/* 426 */     dfs.close();
/*     */   }
/*     */ 
/*     */   public Object getDependants()
/*     */   {
/* 437 */     return _jspx_dependants;
/*     */   }
/*     */ 
/*     */   public void _jspService(HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException, ServletException
/*     */   {
/* 443 */     PageContext pageContext = null;
/* 444 */     HttpSession session = null;
/* 445 */     ServletContext application = null;
/* 446 */     ServletConfig config = null;
/* 447 */     JspWriter out = null;
/* 448 */     Object page = this;
/* 449 */     JspWriter _jspx_out = null;
/* 450 */     PageContext _jspx_page_context = null;
/*     */     try
/*     */     {
/* 453 */       response.setContentType("text/html; charset=UTF-8");
/* 454 */       pageContext = _jspxFactory.getPageContext(this, request, response, null, true, 8192, true);
/*     */ 
/* 456 */       _jspx_page_context = pageContext;
/* 457 */       application = pageContext.getServletContext();
/* 458 */       config = pageContext.getServletConfig();
/* 459 */       session = pageContext.getSession();
/* 460 */       out = pageContext.getOut();
/* 461 */       _jspx_out = out;
/* 462 */       this._jspx_resourceInjector = ((ResourceInjector)application.getAttribute("com.sun.appserv.jsp.resource.injector"));
/*     */ 
/* 464 */       out.write("\n\n\n");
/* 465 */       out.write("\n<!DOCTYPE html>\n<html>\n<head>\n");
/* 466 */       JspHelper.createTitle(out, request, request.getParameter("filename"));
/* 467 */       out.write("\n</head>\n<body onload=\"document.goto.dir.focus()\">\n");
/*     */ 
/* 469 */       Configuration conf = (Configuration)getServletContext().getAttribute("current.conf");
/*     */ 
/* 471 */       generateFileChunks(out, request, conf);
/*     */ 
/* 473 */       out.write("\n<hr>\n");
/*     */ 
/* 475 */       generateFileDetails(out, request, conf);
/*     */ 
/* 477 */       out.write("\n\n<h2>Local logs</h2>\n<a href=\"/logs/\">Log</a> directory\n\n");
/*     */ 
/* 479 */       out.println(ServletUtil.htmlFooter());
/*     */ 
/* 481 */       out.write(10);
/*     */     } catch (Throwable t) {
/* 483 */       if (!(t instanceof SkipPageException)) {
/* 484 */         out = _jspx_out;
/* 485 */         if ((out != null) && (out.getBufferSize() != 0))
/* 486 */           out.clearBuffer();
/* 487 */         if (_jspx_page_context != null) _jspx_page_context.handlePageException(t); 
/*     */       }
/*     */     }
/* 490 */     finally { _jspxFactory.releasePageContext(_jspx_page_context); }
/*     */ 
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.browseBlock_jsp
 * JD-Core Version:    0.6.1
 */
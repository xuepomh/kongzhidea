package org.apache.hadoop.hdfs.server.protocol;

import java.io.IOException;
import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
import org.apache.hadoop.hdfs.security.token.block.ExportedBlockKeys;
import org.apache.hadoop.hdfs.server.namenode.CheckpointSignature;
import org.apache.hadoop.ipc.VersionedProtocol;
import org.apache.hadoop.security.KerberosInfo;

@KerberosInfo(serverPrincipal="dfs.namenode.kerberos.principal", clientPrincipal="dfs.namenode.kerberos.principal")
public abstract interface NamenodeProtocol extends VersionedProtocol
{
  public static final long versionID = 3L;

  public abstract BlocksWithLocations getBlocks(DatanodeInfo paramDatanodeInfo, long paramLong)
    throws IOException;

  public abstract ExportedBlockKeys getBlockKeys()
    throws IOException;

  public abstract long getEditLogSize()
    throws IOException;

  public abstract CheckpointSignature rollEditLog()
    throws IOException;

  public abstract void rollFsImage()
    throws IOException;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.protocol.NamenodeProtocol
 * JD-Core Version:    0.6.1
 */
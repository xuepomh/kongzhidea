/*    */ package org.apache.hadoop.hdfs.server.common;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public abstract class UpgradeObject
/*    */   implements Upgradeable
/*    */ {
/*    */   protected short status;
/*    */ 
/*    */   public short getUpgradeStatus()
/*    */   {
/* 34 */     return this.status;
/*    */   }
/*    */ 
/*    */   public String getDescription() {
/* 38 */     return "Upgrade object for " + getType() + " layout version " + getVersion();
/*    */   }
/*    */ 
/*    */   public UpgradeStatusReport getUpgradeStatusReport(boolean details) throws IOException
/*    */   {
/* 43 */     return new UpgradeStatusReport(getVersion(), getUpgradeStatus(), false);
/*    */   }
/*    */ 
/*    */   public int compareTo(Upgradeable o) {
/* 47 */     if (getVersion() != o.getVersion())
/* 48 */       return getVersion() > o.getVersion() ? -1 : 1;
/* 49 */     int res = getType().toString().compareTo(o.getType().toString());
/* 50 */     if (res != 0)
/* 51 */       return res;
/* 52 */     return getClass().getCanonicalName().compareTo(o.getClass().getCanonicalName());
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 57 */     if (!(o instanceof UpgradeObject)) {
/* 58 */       return false;
/*    */     }
/* 60 */     return compareTo((UpgradeObject)o) == 0;
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 64 */     return new UpgradeObjectCollection.UOSignature(this).hashCode();
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.common.UpgradeObject
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Random;
/*     */ import java.util.TreeSet;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.hdfs.BlockReader;
/*     */ import org.apache.hadoop.hdfs.DFSClient;
/*     */ import org.apache.hadoop.hdfs.DFSClient.RemoteBlockReader;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeID;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.hdfs.protocol.FSConstants.UpgradeAction;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlock;
/*     */ import org.apache.hadoop.hdfs.security.token.block.BlockTokenIdentifier;
/*     */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenIdentifier;
/*     */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenSecretManager;
/*     */ import org.apache.hadoop.hdfs.server.common.UpgradeStatusReport;
/*     */ import org.apache.hadoop.hdfs.server.datanode.DataNode;
/*     */ import org.apache.hadoop.http.HtmlQuoting;
/*     */ import org.apache.hadoop.net.NetUtils;
/*     */ import org.apache.hadoop.security.KerberosName;
/*     */ import org.apache.hadoop.security.SecurityUtil;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.UserGroupInformation.AuthenticationMethod;
/*     */ import org.apache.hadoop.security.authorize.AuthorizationException;
/*     */ import org.apache.hadoop.security.authorize.ProxyUsers;
/*     */ import org.apache.hadoop.security.token.Token;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ import org.apache.hadoop.util.VersionInfo;
/*     */ 
/*     */ public class JspHelper
/*     */ {
/*     */   public static final String CURRENT_CONF = "current.conf";
/*     */   public static final String WEB_UGI_PROPERTY_NAME = "dfs.web.ugi";
/*     */   public static final String DELEGATION_PARAMETER_NAME = "delegation";
/*     */   static final String SET_DELEGATION = "&delegation=";
/*  76 */   private static final Log LOG = LogFactory.getLog(JspHelper.class);
/*     */ 
/*  78 */   static FSNamesystem fsn = null;
/*     */   public static InetSocketAddress nameNodeAddr;
/*  81 */   static Random rand = new Random();
/*     */ 
/*     */   public JspHelper() {
/*  84 */     fsn = FSNamesystem.getFSNamesystem();
/*  85 */     if (DataNode.getDataNode() != null) {
/*  86 */       nameNodeAddr = DataNode.getDataNode().getNameNodeAddr();
/*     */     }
/*     */     else
/*  89 */       nameNodeAddr = fsn.getDFSNameNodeAddress();
/*     */   }
/*     */ 
/*     */   public DatanodeID randomNode() throws IOException
/*     */   {
/*  94 */     return fsn.getRandomDatanode();
/*     */   }
/*     */ 
/*     */   public static DatanodeInfo bestNode(LocatedBlock blk) throws IOException {
/*  98 */     TreeSet deadNodes = new TreeSet();
/*  99 */     DatanodeInfo chosenNode = null;
/* 100 */     int failures = 0;
/* 101 */     Socket s = null;
/* 102 */     DatanodeInfo[] nodes = blk.getLocations();
/* 103 */     if ((nodes == null) || (nodes.length == 0)) {
/* 104 */       throw new IOException("No nodes contain this block");
/*     */     }
/* 106 */     while (s == null) {
/* 107 */       if (chosenNode == null) {
/*     */         do
/* 109 */           chosenNode = nodes[rand.nextInt(nodes.length)];
/* 110 */         while (deadNodes.contains(chosenNode));
/*     */       }
/* 112 */       int index = rand.nextInt(nodes.length);
/* 113 */       chosenNode = nodes[index];
/*     */ 
/* 116 */       InetSocketAddress targetAddr = NetUtils.createSocketAddr(new StringBuilder().append(chosenNode.getHost()).append(":").append(chosenNode.getInfoPort()).toString());
/*     */       try
/*     */       {
/* 120 */         s = new Socket();
/* 121 */         s.connect(targetAddr, 60000);
/* 122 */         s.setSoTimeout(60000);
/*     */       } catch (IOException e) {
/* 124 */         deadNodes.add(chosenNode);
/* 125 */         s.close();
/* 126 */         s = null;
/* 127 */         failures++;
/*     */       }
/* 129 */       if (failures == nodes.length) {
/* 130 */         throw new IOException("Could not reach the block containing the data. Please try again");
/*     */       }
/*     */     }
/* 133 */     s.close();
/* 134 */     return chosenNode;
/*     */   }
/*     */ 
/*     */   public void streamBlockInAscii(InetSocketAddress addr, long blockId, Token<BlockTokenIdentifier> accessToken, long genStamp, long blockSize, long offsetIntoBlock, long chunkSizeToView, JspWriter out, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 143 */     if (chunkSizeToView == 0L) return;
/* 144 */     Socket s = new Socket();
/* 145 */     s.connect(addr, 60000);
/* 146 */     s.setSoTimeout(60000);
/*     */ 
/* 148 */     long amtToRead = Math.min(chunkSizeToView, blockSize - offsetIntoBlock);
/*     */ 
/* 151 */     BlockReader blockReader = DFSClient.RemoteBlockReader.newBlockReader(s, new StringBuilder().append(addr.toString()).append(":").append(blockId).toString(), blockId, accessToken, genStamp, offsetIntoBlock, amtToRead, conf.getInt("io.file.buffer.size", 4096));
/*     */ 
/* 157 */     byte[] buf = new byte[(int)amtToRead];
/* 158 */     int readOffset = 0;
/* 159 */     int retries = 2;
/* 160 */     while (amtToRead > 0L) {
/*     */       int numRead;
/*     */       try {
/* 163 */         numRead = blockReader.readAll(buf, readOffset, (int)amtToRead);
/*     */       }
/*     */       catch (IOException e) {
/* 166 */         retries--;
/* 167 */         if (retries == 0)
/* 168 */           throw new IOException("Could not read data from datanode"); 
/*     */       }
/* 169 */       continue;
/*     */ 
/* 171 */       amtToRead -= numRead;
/* 172 */       readOffset += numRead;
/*     */     }
/* 174 */     blockReader = null;
/* 175 */     s.close();
/* 176 */     out.print(HtmlQuoting.quoteHtmlChars(new String(buf)));
/*     */   }
/*     */ 
/*     */   public void DFSNodesStatus(ArrayList<DatanodeDescriptor> live, ArrayList<DatanodeDescriptor> dead) {
/* 180 */     if (fsn != null) {
/* 181 */       fsn.DFSNodesStatus(live, dead);
/* 182 */       fsn.removeDecomNodeFromDeadList(dead);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addTableHeader(JspWriter out) throws IOException {
/* 187 */     out.print("<table border=\"1\" cellpadding=\"2\" cellspacing=\"2\">");
/*     */ 
/* 189 */     out.print("<tbody>");
/*     */   }
/*     */   public void addTableRow(JspWriter out, String[] columns) throws IOException {
/* 192 */     out.print("<tr>");
/* 193 */     for (int i = 0; i < columns.length; i++) {
/* 194 */       out.print(new StringBuilder().append("<td style=\"vertical-align: top;\"><B>").append(columns[i]).append("</B><br></td>").toString());
/*     */     }
/* 196 */     out.print("</tr>");
/*     */   }
/*     */   public void addTableRow(JspWriter out, String[] columns, int row) throws IOException {
/* 199 */     out.print("<tr>");
/*     */ 
/* 201 */     for (int i = 0; i < columns.length; i++) {
/* 202 */       if (row / 2 * 2 == row)
/* 203 */         out.print(new StringBuilder().append("<td style=\"vertical-align: top;background-color:LightGrey;\"><B>").append(columns[i]).append("</B><br></td>").toString());
/*     */       else {
/* 205 */         out.print(new StringBuilder().append("<td style=\"vertical-align: top;background-color:LightBlue;\"><B>").append(columns[i]).append("</B><br></td>").toString());
/*     */       }
/*     */     }
/*     */ 
/* 209 */     out.print("</tr>");
/*     */   }
/*     */   public void addTableFooter(JspWriter out) throws IOException {
/* 212 */     out.print("</tbody></table>");
/*     */   }
/*     */ 
/*     */   public String getSafeModeText() {
/* 216 */     if (!fsn.isInSafeMode())
/* 217 */       return "";
/* 218 */     return new StringBuilder().append("Safe mode is ON. <em>").append(fsn.getSafeModeTip()).append("</em><br>").toString();
/*     */   }
/*     */ 
/*     */   public static String getWarningText(FSNamesystem fsn)
/*     */   {
/* 223 */     long missingBlocks = fsn.getMissingBlocksCount();
/* 224 */     if (missingBlocks > 0L) {
/* 225 */       return new StringBuilder().append("<br> WARNING : There are about ").append(missingBlocks).append(" missing blocks. Please check the log or run fsck. <br><br>").toString();
/*     */     }
/*     */ 
/* 229 */     return "";
/*     */   }
/*     */ 
/*     */   public String getInodeLimitText() {
/* 233 */     long inodes = fsn.dir.totalInodes();
/* 234 */     long blocks = fsn.getBlocksTotal();
/* 235 */     long maxobjects = fsn.getMaxObjects();
/* 236 */     long totalMemory = Runtime.getRuntime().totalMemory();
/* 237 */     long maxMemory = Runtime.getRuntime().maxMemory();
/*     */ 
/* 239 */     long used = totalMemory * 100L / maxMemory;
/*     */ 
/* 241 */     String str = new StringBuilder().append(inodes).append(" files and directories, ").append(blocks).append(" blocks = ").append(inodes + blocks).append(" total").toString();
/*     */ 
/* 244 */     if (maxobjects != 0L) {
/* 245 */       long pct = (inodes + blocks) * 100L / maxobjects;
/* 246 */       str = new StringBuilder().append(str).append(" / ").append(maxobjects).append(" (").append(pct).append("%)").toString();
/*     */     }
/* 248 */     str = new StringBuilder().append(str).append(".  Heap Size is ").append(StringUtils.byteDesc(totalMemory)).append(" / ").append(StringUtils.byteDesc(maxMemory)).append(" (").append(used).append("%) <br>").toString();
/*     */ 
/* 251 */     return str;
/*     */   }
/*     */ 
/*     */   public String getUpgradeStatusText() {
/* 255 */     String statusText = "";
/*     */     try {
/* 257 */       UpgradeStatusReport status = fsn.distributedUpgradeProgress(FSConstants.UpgradeAction.GET_STATUS);
/*     */ 
/* 259 */       statusText = status == null ? "There are no upgrades in progress." : status.getStatusText(false);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 263 */       statusText = "Upgrade status unknown.";
/*     */     }
/* 265 */     return statusText;
/*     */   }
/*     */ 
/*     */   public void sortNodeList(ArrayList<DatanodeDescriptor> nodes, String field, String order)
/*     */   {
/* 360 */     Collections.sort(nodes, new Comparator()
/*     */     {
/*     */       static final int FIELD_NAME = 1;
/*     */       static final int FIELD_LAST_CONTACT = 2;
/*     */       static final int FIELD_BLOCKS = 3;
/*     */       static final int FIELD_CAPACITY = 4;
/*     */       static final int FIELD_USED = 5;
/*     */       static final int FIELD_PERCENT_USED = 6;
/*     */       static final int FIELD_NONDFS_USED = 7;
/*     */       static final int FIELD_REMAINING = 8;
/*     */       static final int FIELD_PERCENT_REMAINING = 9;
/*     */       static final int SORT_ORDER_ASC = 1;
/*     */       static final int SORT_ORDER_DSC = 2;
/* 285 */       int sortField = 1;
/* 286 */       int sortOrder = 1;
/*     */ 
/*     */       public int compare(DatanodeDescriptor d1, DatanodeDescriptor d2)
/*     */       {
/* 318 */         int ret = 0;
/*     */         long dlong;
/*     */         double ddbl;
/* 319 */         switch (this.sortField) {
/*     */         case 2:
/* 321 */           ret = (int)(d2.getLastUpdate() - d1.getLastUpdate());
/* 322 */           break;
/*     */         case 4:
/* 324 */           dlong = d1.getCapacity() - d2.getCapacity();
/* 325 */           ret = dlong > 0L ? 1 : dlong < 0L ? -1 : 0;
/* 326 */           break;
/*     */         case 5:
/* 328 */           dlong = d1.getDfsUsed() - d2.getDfsUsed();
/* 329 */           ret = dlong > 0L ? 1 : dlong < 0L ? -1 : 0;
/* 330 */           break;
/*     */         case 7:
/* 332 */           dlong = d1.getNonDfsUsed() - d2.getNonDfsUsed();
/* 333 */           ret = dlong > 0L ? 1 : dlong < 0L ? -1 : 0;
/* 334 */           break;
/*     */         case 8:
/* 336 */           dlong = d1.getRemaining() - d2.getRemaining();
/* 337 */           ret = dlong > 0L ? 1 : dlong < 0L ? -1 : 0;
/* 338 */           break;
/*     */         case 6:
/* 340 */           ddbl = d1.getDfsUsedPercent() - d2.getDfsUsedPercent();
/*     */ 
/* 342 */           ret = ddbl > 0.0D ? 1 : ddbl < 0.0D ? -1 : 0;
/* 343 */           break;
/*     */         case 9:
/* 345 */           ddbl = d1.getRemainingPercent() - d2.getRemainingPercent();
/*     */ 
/* 347 */           ret = ddbl > 0.0D ? 1 : ddbl < 0.0D ? -1 : 0;
/* 348 */           break;
/*     */         case 3:
/* 350 */           ret = d1.numBlocks() - d2.numBlocks();
/* 351 */           break;
/*     */         case 1:
/* 353 */           ret = d1.getHostName().compareTo(d2.getHostName());
/*     */         }
/*     */ 
/* 356 */         return this.sortOrder == 2 ? -ret : ret;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public static void printPathWithLinks(String dir, JspWriter out, int namenodeInfoPort, String tokenString)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 368 */       String[] parts = dir.split("/");
/* 369 */       StringBuilder tempPath = new StringBuilder(dir.length());
/* 370 */       out.print(new StringBuilder().append("<a href=\"browseDirectory.jsp?dir=/&namenodeInfoPort=").append(namenodeInfoPort).append(getDelegationTokenUrlParam(tokenString)).append("\">").append("/").append("</a>").toString());
/*     */ 
/* 374 */       tempPath.append("/");
/* 375 */       for (int i = 0; i < parts.length - 1; i++) {
/* 376 */         if (!parts[i].equals("")) {
/* 377 */           tempPath.append(parts[i]);
/* 378 */           out.print(new StringBuilder().append("<a href=\"browseDirectory.jsp?dir=").append(tempPath.toString()).append("&namenodeInfoPort=").append(namenodeInfoPort).append(getDelegationTokenUrlParam(tokenString)).toString());
/*     */ 
/* 381 */           out.print(new StringBuilder().append("\">").append(parts[i]).append("</a>").append("/").toString());
/* 382 */           tempPath.append("/");
/*     */         }
/*     */       }
/* 385 */       if (parts.length > 0)
/* 386 */         out.print(parts[(parts.length - 1)]);
/*     */     }
/*     */     catch (UnsupportedEncodingException ex)
/*     */     {
/* 390 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void printGotoForm(JspWriter out, int namenodeInfoPort, String tokenString, String file)
/*     */     throws IOException
/*     */   {
/* 398 */     out.print("<form action=\"browseDirectory.jsp\" method=\"get\" name=\"goto\">");
/* 399 */     out.print("Goto : ");
/* 400 */     out.print(new StringBuilder().append("<input name=\"dir\" type=\"text\" width=\"50\" id\"dir\" value=\"").append(file).append("\">").toString());
/* 401 */     out.print("<input name=\"go\" type=\"submit\" value=\"go\">");
/* 402 */     out.print(new StringBuilder().append("<input name=\"namenodeInfoPort\" type=\"hidden\" value=\"").append(namenodeInfoPort).append("\">").toString());
/*     */ 
/* 404 */     if (UserGroupInformation.isSecurityEnabled()) {
/* 405 */       out.print(new StringBuilder().append("<input name=\"delegation\" type=\"hidden\" value=\"").append(tokenString).append("\">").toString());
/*     */     }
/*     */ 
/* 408 */     out.print("</form>");
/*     */   }
/*     */ 
/*     */   public static void createTitle(JspWriter out, HttpServletRequest req, String file)
/*     */     throws IOException
/*     */   {
/* 414 */     if (file == null) file = "";
/* 415 */     int start = Math.max(0, file.length() - 100);
/* 416 */     if (start != 0)
/* 417 */       file = new StringBuilder().append("...").append(file.substring(start, file.length())).toString();
/* 418 */     out.print(new StringBuilder().append("<title>HDFS:").append(file).append("</title>").toString());
/*     */   }
/*     */ 
/*     */   public static UserGroupInformation getDefaultWebUser(Configuration conf)
/*     */     throws IOException
/*     */   {
/* 429 */     String[] strings = conf.getStrings("dfs.web.ugi");
/* 430 */     if ((strings == null) || (strings.length == 0)) {
/* 431 */       throw new IOException("Cannot determine UGI from request or conf");
/*     */     }
/* 433 */     return UserGroupInformation.createRemoteUser(strings[0]);
/*     */   }
/*     */ 
/*     */   public static UserGroupInformation getUGI(HttpServletRequest request, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 439 */     return getUGI(null, request, conf);
/*     */   }
/*     */ 
/*     */   public static UserGroupInformation getUGI(ServletContext context, HttpServletRequest request, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 452 */     return getUGI(context, request, conf, UserGroupInformation.AuthenticationMethod.KERBEROS_SSL, true);
/*     */   }
/*     */ 
/*     */   public static UserGroupInformation getUGI(ServletContext context, HttpServletRequest request, Configuration conf, UserGroupInformation.AuthenticationMethod secureAuthMethod, boolean tryUgiParameter)
/*     */     throws IOException
/*     */   {
/* 472 */     String usernameFromQuery = getUsernameFromQuery(request, tryUgiParameter);
/* 473 */     String doAsUserFromQuery = request.getParameter("doas");
/*     */     UserGroupInformation ugi;
/*     */     UserGroupInformation ugi;
/* 475 */     if (UserGroupInformation.isSecurityEnabled()) {
/* 476 */       String remoteUser = request.getRemoteUser();
/* 477 */       String tokenString = request.getParameter("delegation");
/* 478 */       if (tokenString != null) {
/* 479 */         Token token = new Token();
/*     */ 
/* 481 */         token.decodeFromUrlString(tokenString);
/* 482 */         SecurityUtil.setTokenService(token, NameNode.getAddress(conf));
/* 483 */         token.setKind(DelegationTokenIdentifier.HDFS_DELEGATION_KIND);
/*     */ 
/* 485 */         ByteArrayInputStream buf = new ByteArrayInputStream(token.getIdentifier());
/*     */ 
/* 487 */         DataInputStream in = new DataInputStream(buf);
/* 488 */         DelegationTokenIdentifier id = new DelegationTokenIdentifier();
/* 489 */         id.readFields(in);
/* 490 */         if (context != null) {
/* 491 */           NameNode nn = (NameNode)context.getAttribute("name.node");
/* 492 */           if (nn != null)
/*     */           {
/* 494 */             nn.getNamesystem().getDelegationTokenSecretManager().verifyToken(id, token.getPassword());
/*     */           }
/*     */         }
/*     */ 
/* 498 */         UserGroupInformation ugi = id.getUser();
/* 499 */         if (ugi.getRealUser() == null)
/*     */         {
/* 501 */           checkUsername(ugi.getShortUserName(), usernameFromQuery);
/* 502 */           checkUsername(null, doAsUserFromQuery);
/*     */         }
/*     */         else {
/* 505 */           checkUsername(ugi.getRealUser().getShortUserName(), usernameFromQuery);
/* 506 */           checkUsername(ugi.getShortUserName(), doAsUserFromQuery);
/* 507 */           ProxyUsers.authorize(ugi, request.getRemoteAddr(), conf);
/*     */         }
/* 509 */         ugi.addToken(token);
/*     */       } else {
/* 511 */         if (remoteUser == null) {
/* 512 */           throw new IOException("Security enabled but user not authenticated by filter");
/*     */         }
/*     */ 
/* 515 */         UserGroupInformation realUgi = UserGroupInformation.createRemoteUser(remoteUser);
/* 516 */         checkUsername(realUgi.getShortUserName(), usernameFromQuery);
/*     */ 
/* 519 */         realUgi.setAuthenticationMethod(secureAuthMethod);
/* 520 */         ugi = initUGI(realUgi, doAsUserFromQuery, request, true, conf);
/*     */       }
/*     */     } else {
/* 523 */       UserGroupInformation realUgi = usernameFromQuery == null ? getDefaultWebUser(conf) : UserGroupInformation.createRemoteUser(usernameFromQuery);
/*     */ 
/* 526 */       realUgi.setAuthenticationMethod(UserGroupInformation.AuthenticationMethod.SIMPLE);
/* 527 */       ugi = initUGI(realUgi, doAsUserFromQuery, request, false, conf);
/*     */     }
/*     */ 
/* 530 */     if (LOG.isDebugEnabled())
/* 531 */       LOG.debug(new StringBuilder().append("getUGI is returning: ").append(ugi.getShortUserName()).toString());
/* 532 */     return ugi;
/*     */   }
/*     */ 
/*     */   private static UserGroupInformation initUGI(UserGroupInformation realUgi, String doAsUserFromQuery, HttpServletRequest request, boolean isSecurityEnabled, Configuration conf)
/*     */     throws AuthorizationException
/*     */   {
/*     */     UserGroupInformation ugi;
/*     */     UserGroupInformation ugi;
/* 540 */     if (doAsUserFromQuery == null)
/*     */     {
/* 542 */       ugi = realUgi;
/*     */     }
/*     */     else {
/* 545 */       ugi = UserGroupInformation.createProxyUser(doAsUserFromQuery, realUgi);
/* 546 */       ugi.setAuthenticationMethod(isSecurityEnabled ? UserGroupInformation.AuthenticationMethod.PROXY : UserGroupInformation.AuthenticationMethod.SIMPLE);
/*     */ 
/* 548 */       ProxyUsers.authorize(ugi, request.getRemoteAddr(), conf);
/*     */     }
/* 550 */     return ugi;
/*     */   }
/*     */ 
/*     */   private static void checkUsername(String expected, String name)
/*     */     throws IOException
/*     */   {
/* 558 */     if ((expected == null) && (name != null)) {
/* 559 */       throw new IOException(new StringBuilder().append("Usernames not matched: expecting null but name=").append(name).toString());
/*     */     }
/*     */ 
/* 562 */     if (name == null) {
/* 563 */       return;
/*     */     }
/* 565 */     KerberosName u = new KerberosName(name);
/* 566 */     String shortName = u.getShortName();
/* 567 */     if (!shortName.equals(expected))
/* 568 */       throw new IOException(new StringBuilder().append("Usernames not matched: name=").append(shortName).append(" != expected=").append(expected).toString());
/*     */   }
/*     */ 
/*     */   private static String getUsernameFromQuery(HttpServletRequest request, boolean tryUgiParameter)
/*     */   {
/* 575 */     String username = request.getParameter("user.name");
/* 576 */     if ((username == null) && (tryUgiParameter))
/*     */     {
/* 578 */       String ugiStr = request.getParameter("ugi");
/* 579 */       if (ugiStr != null) {
/* 580 */         username = ugiStr.split(",")[0];
/*     */       }
/*     */     }
/* 583 */     return username;
/*     */   }
/*     */ 
/*     */   public static DFSClient getDFSClient(UserGroupInformation user, InetSocketAddress addr, final Configuration conf)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 591 */     return (DFSClient)user.doAs(new PrivilegedExceptionAction()
/*     */     {
/*     */       public DFSClient run() throws IOException {
/* 594 */         return new DFSClient(this.val$addr, conf);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public static String getDelegationTokenUrlParam(String tokenString)
/*     */   {
/* 605 */     if (tokenString == null) {
/* 606 */       return "";
/*     */     }
/* 608 */     if (UserGroupInformation.isSecurityEnabled()) {
/* 609 */       return new StringBuilder().append("&delegation=").append(tokenString).toString();
/*     */     }
/* 611 */     return "";
/*     */   }
/*     */ 
/*     */   public static int string2ChunkSizeToView(String s, int defaultValue)
/*     */   {
/* 617 */     int n = s == null ? 0 : Integer.parseInt(s);
/* 618 */     return n > 0 ? n : defaultValue;
/*     */   }
/*     */ 
/*     */   public static int getDefaultChunkSize(Configuration conf)
/*     */   {
/* 627 */     return conf.getInt("dfs.default.chunk.view.size", 32768);
/*     */   }
/*     */ 
/*     */   static String getVersionTable(FSNamesystem fsn)
/*     */   {
/* 632 */     return new StringBuilder().append("<div class='dfstable'><table>\n  <tr><td class='col1'>Started:</td><td>").append(fsn.getStartTime()).append("</td></tr>\n").append("\n  <tr><td class='col1'>Version:</td><td>").append(VersionInfo.getVersion()).append(", ").append(VersionInfo.getRevision()).append("</td></tr>\n").append("\n  <tr><td class='col1'>Compiled:</td><td>").append(VersionInfo.getDate()).append(" by ").append(VersionInfo.getUser()).append("</td></tr>\n</table></div>").toString();
/*     */   }
/*     */ 
/*     */   public static String getVersionTable()
/*     */   {
/* 643 */     return new StringBuilder().append("<div id='dfstable'><table>\n  <tr><td id='col1'>Version:</td><td>").append(VersionInfo.getVersion()).append(", ").append(VersionInfo.getRevision()).append("\n  <tr><td id='col1'>Compiled:</td><td>").append(VersionInfo.getDate()).append(" by ").append(VersionInfo.getUser()).append("\n</table></div>").toString();
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.JspHelper
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.server.protocol;
/*    */ 
/*    */ import java.io.DataInput;
/*    */ import java.io.DataOutput;
/*    */ import java.io.IOException;
/*    */ import org.apache.hadoop.hdfs.protocol.Block;
/*    */ import org.apache.hadoop.io.Writable;
/*    */ import org.apache.hadoop.io.WritableFactories;
/*    */ import org.apache.hadoop.io.WritableFactory;
/*    */ 
/*    */ public class BlockMetaDataInfo extends Block
/*    */ {
/* 29 */   static final WritableFactory FACTORY = new WritableFactory() {
/* 30 */     public Writable newInstance() { return new BlockMetaDataInfo(); }
/* 29 */   };
/*    */   private long lastScanTime;
/*    */ 
/*    */   public BlockMetaDataInfo()
/*    */   {
/*    */   }
/*    */ 
/*    */   public BlockMetaDataInfo(Block b, long lastScanTime)
/*    */   {
/* 41 */     super(b);
/* 42 */     this.lastScanTime = lastScanTime;
/*    */   }
/*    */   public long getLastScanTime() {
/* 45 */     return this.lastScanTime;
/*    */   }
/*    */ 
/*    */   public void write(DataOutput out) throws IOException {
/* 49 */     super.write(out);
/* 50 */     out.writeLong(this.lastScanTime);
/*    */   }
/*    */ 
/*    */   public void readFields(DataInput in) throws IOException
/*    */   {
/* 55 */     super.readFields(in);
/* 56 */     this.lastScanTime = in.readLong();
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 33 */     WritableFactories.setFactory(BlockMetaDataInfo.class, FACTORY);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.protocol.BlockMetaDataInfo
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.SingleThreadModel;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.jsp.JspFactory;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.SkipPageException;
/*     */ import org.apache.hadoop.util.ServletUtil;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ import org.apache.hadoop.util.VersionInfo;
/*     */ import org.apache.jasper.runtime.HttpJspBase;
/*     */ import org.apache.jasper.runtime.JspSourceDependent;
/*     */ import org.apache.jasper.runtime.ResourceInjector;
/*     */ 
/*     */ public final class dfsnodelist_jsp extends HttpJspBase
/*     */   implements JspSourceDependent, SingleThreadModel
/*     */ {
/*  41 */   JspHelper jspHelper = new JspHelper();
/*     */ 
/*  43 */   int rowNum = 0;
/*  44 */   int colNum = 0;
/*     */ 
/*  52 */   long diskBytes = 1073741824L;
/*  53 */   String diskByteStr = "GB";
/*     */ 
/*  55 */   String sorterField = null;
/*  56 */   String sorterOrder = null;
/*  57 */   String whatNodes = "LIVE";
/*     */ 
/* 330 */   private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();
/*     */   private static Vector _jspx_dependants;
/*     */   private ResourceInjector _jspx_resourceInjector;
/*     */ 
/*     */   String rowTxt()
/*     */   {
/*  46 */     this.colNum = 0;
/*  47 */     return new StringBuilder().append("<tr class=\"").append(this.rowNum++ % 2 == 0 ? "rowNormal" : "rowAlt").append("\"> ").toString();
/*     */   }
/*  49 */   String colTxt() { return new StringBuilder().append("<td id=\"col").append(++this.colNum).append("\"> ").toString(); } 
/*  50 */   void counterReset() { this.colNum = 0; this.rowNum = 0;
/*     */   }
/*     */ 
/*     */   String NodeHeaderStr(String name)
/*     */   {
/*  60 */     String ret = "class=header";
/*  61 */     String order = "ASC";
/*  62 */     if (name.equals(this.sorterField)) {
/*  63 */       ret = new StringBuilder().append(ret).append(this.sorterOrder).toString();
/*  64 */       if (this.sorterOrder.equals("ASC"))
/*  65 */         order = "DSC";
/*     */     }
/*  67 */     ret = new StringBuilder().append(ret).append(" onClick=\"window.document.location='/dfsnodelist.jsp?whatNodes=").append(this.whatNodes).append("&sorter/field=").append(name).append("&sorter/order=").append(order).append("'\" title=\"sort on this column\"").toString();
/*     */ 
/*  71 */     return ret;
/*     */   }
/*     */ 
/*     */   void generateDecommissioningNodeData(JspWriter out, DatanodeDescriptor d, String suffix, boolean alive, int nnHttpPort) throws IOException
/*     */   {
/*  76 */     String url = new StringBuilder().append("http://").append(d.getHostName()).append(":").append(d.getInfoPort()).append("/browseDirectory.jsp?namenodeInfoPort=").append(nnHttpPort).append("&dir=").append(URLEncoder.encode("/", "UTF-8")).toString();
/*     */ 
/*  80 */     String name = new StringBuilder().append(d.getHostName()).append(":").append(d.getPort()).toString();
/*  81 */     if (!name.matches("\\d+\\.\\d+.\\d+\\.\\d+.*"))
/*  82 */       name = name.replaceAll("\\.[^.:]*", "");
/*  83 */     int idx = (suffix != null) && (name.endsWith(suffix)) ? name.indexOf(suffix) : -1;
/*     */ 
/*  86 */     out.print(new StringBuilder().append(rowTxt()).append("<td class=\"name\"><a title=\"").append(d.getHost()).append(":").append(d.getPort()).append("\" href=\"").append(url).append("\">").append(idx > 0 ? name.substring(0, idx) : name).append("</a>").append(alive ? "" : "\n").toString());
/*     */ 
/*  90 */     if (!alive) {
/*  91 */       return;
/*     */     }
/*     */ 
/*  94 */     long decommRequestTime = d.decommissioningStatus.getStartTime();
/*  95 */     long timestamp = d.getLastUpdate();
/*  96 */     long currentTime = System.currentTimeMillis();
/*  97 */     long hoursSinceDecommStarted = (currentTime - decommRequestTime) / 3600000L;
/*  98 */     long remainderMinutes = (currentTime - decommRequestTime) / 60000L % 60L;
/*  99 */     out.print(new StringBuilder().append("<td class=\"lastcontact\"> ").append((currentTime - timestamp) / 1000L).append("<td class=\"underreplicatedblocks\">").append(d.decommissioningStatus.getUnderReplicatedBlocks()).append("<td class=\"blockswithonlydecommissioningreplicas\">").append(d.decommissioningStatus.getDecommissionOnlyReplicas()).append("<td class=\"underrepblocksinfilesunderconstruction\">").append(d.decommissioningStatus.getUnderReplicatedInOpenFiles()).append("<td class=\"timesincedecommissionrequest\">").append(hoursSinceDecommStarted).append(" hrs ").append(remainderMinutes).append(" mins").append("\n").toString());
/*     */   }
/*     */ 
/*     */   public void generateNodeData(JspWriter out, DatanodeDescriptor d, String suffix, boolean alive, int nnHttpPort)
/*     */     throws IOException
/*     */   {
/* 131 */     String url = new StringBuilder().append("http://").append(d.getHostName()).append(":").append(d.getInfoPort()).append("/browseDirectory.jsp?namenodeInfoPort=").append(nnHttpPort).append("&dir=").append(URLEncoder.encode("/", "UTF-8")).toString();
/*     */ 
/* 136 */     String name = new StringBuilder().append(d.getHostName()).append(":").append(d.getPort()).toString();
/* 137 */     if (!name.matches("\\d+\\.\\d+.\\d+\\.\\d+.*"))
/* 138 */       name = name.replaceAll("\\.[^.:]*", "");
/* 139 */     int idx = (suffix != null) && (name.endsWith(suffix)) ? name.indexOf(suffix) : -1;
/*     */ 
/* 142 */     out.print(new StringBuilder().append(rowTxt()).append("<td class=\"name\"><a title=\"").append(d.getHost()).append(":").append(d.getPort()).append("\" href=\"").append(url).append("\">").append(idx > 0 ? name.substring(0, idx) : name).append("</a>").append(alive ? "" : "\n").toString());
/*     */ 
/* 147 */     if (!alive) {
/* 148 */       return;
/*     */     }
/* 150 */     long c = d.getCapacity();
/* 151 */     long u = d.getDfsUsed();
/* 152 */     long nu = d.getNonDfsUsed();
/* 153 */     long r = d.getRemaining();
/* 154 */     String percentUsed = StringUtils.limitDecimalTo2(d.getDfsUsedPercent());
/* 155 */     String percentRemaining = StringUtils.limitDecimalTo2(d.getRemainingPercent());
/*     */ 
/* 157 */     String adminState = d.isDecommissionInProgress() ? "Decommission In Progress" : d.isDecommissioned() ? "Decommissioned" : "In Service";
/*     */ 
/* 161 */     long timestamp = d.getLastUpdate();
/* 162 */     long currentTime = System.currentTimeMillis();
/* 163 */     out.print(new StringBuilder().append("<td class=\"lastcontact\"> ").append((currentTime - timestamp) / 1000L).append("<td class=\"adminstate\">").append(adminState).append("<td align=\"right\" class=\"capacity\">").append(StringUtils.limitDecimalTo2(c * 1.0D / this.diskBytes)).append("<td align=\"right\" class=\"used\">").append(StringUtils.limitDecimalTo2(u * 1.0D / this.diskBytes)).append("<td align=\"right\" class=\"nondfsused\">").append(StringUtils.limitDecimalTo2(nu * 1.0D / this.diskBytes)).append("<td align=\"right\" class=\"remaining\">").append(StringUtils.limitDecimalTo2(r * 1.0D / this.diskBytes)).append("<td align=\"right\" class=\"pcused\">").append(percentUsed).append("<td class=\"pcused\">").append(ServletUtil.percentageGraph((int)Double.parseDouble(percentUsed), 100)).append("<td align=\"right\" class=\"pcremaining`\">").append(percentRemaining).append("<td title=").append("\"blocks scheduled : ").append(d.getBlocksScheduled()).append("\" class=\"blocks\">").append(d.numBlocks()).append("\n").toString());
/*     */   }
/*     */ 
/*     */   public void generateDFSNodesList(JspWriter out, NameNode nn, HttpServletRequest request)
/*     */     throws IOException
/*     */   {
/* 189 */     ArrayList live = new ArrayList();
/* 190 */     ArrayList dead = new ArrayList();
/* 191 */     this.jspHelper.DFSNodesStatus(live, dead);
/*     */ 
/* 194 */     String whatNodes = request.getParameter("whatNodes");
/* 195 */     if ((whatNodes == null) || (whatNodes.length() == 0)) {
/* 196 */       out.print("Invalid input");
/* 197 */       return;
/*     */     }
/*     */ 
/* 200 */     this.sorterField = request.getParameter("sorter/field");
/* 201 */     this.sorterOrder = request.getParameter("sorter/order");
/* 202 */     if (this.sorterField == null)
/* 203 */       this.sorterField = "name";
/* 204 */     if (this.sorterOrder == null) {
/* 205 */       this.sorterOrder = "ASC";
/*     */     }
/* 207 */     this.jspHelper.sortNodeList(live, this.sorterField, this.sorterOrder);
/* 208 */     this.jspHelper.sortNodeList(dead, "name", "ASC");
/*     */ 
/* 211 */     String port_suffix = null;
/* 212 */     if (live.size() > 0) {
/* 213 */       String name = ((DatanodeDescriptor)live.get(0)).getName();
/* 214 */       int idx = name.indexOf(':');
/* 215 */       if (idx > 0) {
/* 216 */         port_suffix = name.substring(idx);
/*     */       }
/*     */ 
/* 219 */       for (int i = 1; (port_suffix != null) && (i < live.size()); i++) {
/* 220 */         if (!((DatanodeDescriptor)live.get(i)).getName().endsWith(port_suffix)) {
/* 221 */           port_suffix = null;
/* 222 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 227 */     counterReset();
/*     */     try
/*     */     {
/* 230 */       Thread.sleep(1000L);
/*     */     } catch (InterruptedException e) {
/*     */     }
/* 233 */     if ((live.isEmpty()) && (dead.isEmpty())) {
/* 234 */       out.print("There are no datanodes in the cluster");
/*     */     }
/*     */     else
/*     */     {
/* 238 */       int nnHttpPort = nn.getHttpAddress().getPort();
/* 239 */       out.print("<div id=\"dfsnodetable\"> ");
/* 240 */       if (whatNodes.equals("LIVE"))
/*     */       {
/* 242 */         out.print(new StringBuilder().append("<a name=\"LiveNodes\" id=\"title\">Live Datanodes : ").append(live.size()).append("</a>").append("<br><br>\n<table border=1 cellspacing=0>\n").toString());
/*     */ 
/* 247 */         counterReset();
/*     */ 
/* 249 */         if (live.size() > 0)
/*     */         {
/* 251 */           if (((DatanodeDescriptor)live.get(0)).getCapacity() > 1024L * this.diskBytes) {
/* 252 */             this.diskBytes *= 1024L;
/* 253 */             this.diskByteStr = "TB";
/*     */           }
/*     */ 
/* 256 */           out.print(new StringBuilder().append("<tr class=\"headerRow\"> <th ").append(NodeHeaderStr("name")).append("> Node <th ").append(NodeHeaderStr("lastcontact")).append("> Last <br>Contact <th ").append(NodeHeaderStr("adminstate")).append("> Admin State <th ").append(NodeHeaderStr("capacity")).append("> Configured <br>Capacity (").append(this.diskByteStr).append(") <th ").append(NodeHeaderStr("used")).append("> Used <br>(").append(this.diskByteStr).append(") <th ").append(NodeHeaderStr("nondfsused")).append("> Non DFS <br>Used (").append(this.diskByteStr).append(") <th ").append(NodeHeaderStr("remaining")).append("> Remaining <br>(").append(this.diskByteStr).append(") <th ").append(NodeHeaderStr("pcused")).append("> Used <br>(%) <th ").append(NodeHeaderStr("pcused")).append("> Used <br>(%) <th ").append(NodeHeaderStr("pcremaining")).append("> Remaining <br>(%) <th ").append(NodeHeaderStr("blocks")).append("> Blocks\n").toString());
/*     */ 
/* 273 */           this.jspHelper.sortNodeList(live, this.sorterField, this.sorterOrder);
/* 274 */           for (int i = 0; i < live.size(); i++) {
/* 275 */             generateNodeData(out, (DatanodeDescriptor)live.get(i), port_suffix, true, nnHttpPort);
/*     */           }
/*     */         }
/* 278 */         out.print("</table>\n");
/* 279 */       } else if (whatNodes.equals("DEAD"))
/*     */       {
/* 281 */         out.print(new StringBuilder().append("<br> <a name=\"DeadNodes\" id=\"title\">  Dead Datanodes : ").append(dead.size()).append("</a><br><br>\n").toString());
/*     */ 
/* 284 */         if (dead.size() > 0) {
/* 285 */           out.print("<table border=1 cellspacing=0> <tr id=\"row1\"> <td> Node \n");
/*     */ 
/* 288 */           this.jspHelper.sortNodeList(dead, "name", "ASC");
/* 289 */           for (int i = 0; i < dead.size(); i++) {
/* 290 */             generateNodeData(out, (DatanodeDescriptor)dead.get(i), port_suffix, false, nnHttpPort);
/*     */           }
/*     */ 
/* 293 */           out.print("</table>\n");
/*     */         }
/* 295 */       } else if (whatNodes.equals("DECOMMISSIONING"))
/*     */       {
/* 297 */         ArrayList decommissioning = nn.getNamesystem().getDecommissioningNodes();
/*     */ 
/* 299 */         out.print(new StringBuilder().append("<br> <a name=\"DecommissioningNodes\" id=\"title\">  Decommissioning Datanodes : ").append(decommissioning.size()).append("</a><br><br>\n").toString());
/*     */ 
/* 302 */         if (decommissioning.size() > 0) {
/* 303 */           out.print(new StringBuilder().append("<table border=1 cellspacing=0> <tr class=\"headRow\"> <th ").append(NodeHeaderStr("name")).append("> Node <th ").append(NodeHeaderStr("lastcontact")).append("> Last <br>Contact <th ").append(NodeHeaderStr("underreplicatedblocks")).append("> Under Replicated Blocks <th ").append(NodeHeaderStr("blockswithonlydecommissioningreplicas")).append("> Blocks With No <br> Live Replicas <th ").append(NodeHeaderStr("underrepblocksinfilesunderconstruction")).append("> Under Replicated Blocks <br> In Files Under Construction").append(" <th ").append(NodeHeaderStr("timesincedecommissionrequest")).append("> Time Since Decommissioning Started").toString());
/*     */ 
/* 316 */           this.jspHelper.sortNodeList(decommissioning, "name", "ASC");
/* 317 */           for (int i = 0; i < decommissioning.size(); i++) {
/* 318 */             generateDecommissioningNodeData(out, (DatanodeDescriptor)decommissioning.get(i), port_suffix, true, nnHttpPort);
/*     */           }
/*     */ 
/* 321 */           out.print("</table>\n");
/*     */         }
/* 323 */         out.print("</div>");
/*     */       }
/*     */       else {
/* 326 */         out.println("Invalid input");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object getDependants()
/*     */   {
/* 337 */     return _jspx_dependants;
/*     */   }
/*     */ 
/*     */   public void _jspService(HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException, ServletException
/*     */   {
/* 343 */     PageContext pageContext = null;
/* 344 */     HttpSession session = null;
/* 345 */     ServletContext application = null;
/* 346 */     ServletConfig config = null;
/* 347 */     JspWriter out = null;
/* 348 */     Object page = this;
/* 349 */     JspWriter _jspx_out = null;
/* 350 */     PageContext _jspx_page_context = null;
/*     */     try
/*     */     {
/* 353 */       response.setContentType("text/html; charset=UTF-8");
/* 354 */       pageContext = _jspxFactory.getPageContext(this, request, response, null, true, 8192, true);
/*     */ 
/* 356 */       _jspx_page_context = pageContext;
/* 357 */       application = pageContext.getServletContext();
/* 358 */       config = pageContext.getServletConfig();
/* 359 */       session = pageContext.getSession();
/* 360 */       out = pageContext.getOut();
/* 361 */       _jspx_out = out;
/* 362 */       this._jspx_resourceInjector = ((ResourceInjector)application.getAttribute("com.sun.appserv.jsp.resource.injector"));
/*     */ 
/* 364 */       out.write(10);
/* 365 */       out.write(10);
/* 366 */       out.write(10);
/* 367 */       out.write(10);
/*     */ 
/* 369 */       NameNode nn = (NameNode)application.getAttribute("name.node");
/* 370 */       FSNamesystem fsn = nn.getNamesystem();
/* 371 */       String namenodeLabel = new StringBuilder().append(nn.getNameNodeAddress().getHostName()).append(":").append(nn.getNameNodeAddress().getPort()).toString();
/*     */ 
/* 373 */       out.write("\n\n<!DOCTYPE html>\n<html>\n\n<link rel=\"stylesheet\" type=\"text/css\" href=\"/static/hadoop.css\">\n<title>Hadoop NameNode ");
/* 374 */       out.print(namenodeLabel);
/* 375 */       out.write("</title>\n  \n<body>\n<h1>NameNode '");
/* 376 */       out.print(namenodeLabel);
/* 377 */       out.write("'</h1>\n\n\n<div id=\"dfstable\"> <table>\t  \n<tr> <td id=\"col1\"> Started: <td> ");
/* 378 */       out.print(fsn.getStartTime());
/* 379 */       out.write("\n<tr> <td id=\"col1\"> Version: <td> ");
/* 380 */       out.print(VersionInfo.getVersion());
/* 381 */       out.write(", r");
/* 382 */       out.print(VersionInfo.getRevision());
/* 383 */       out.write("\n<tr> <td id=\"col1\"> Compiled: <td> ");
/* 384 */       out.print(VersionInfo.getDate());
/* 385 */       out.write(" by ");
/* 386 */       out.print(VersionInfo.getUser());
/* 387 */       out.write("\n<tr> <td id=\"col1\"> Upgrades: <td> ");
/* 388 */       out.print(this.jspHelper.getUpgradeStatusText());
/* 389 */       out.write("\n</table></div><br>\t\t\t\t      \n\n<b><a href=\"/nn_browsedfscontent.jsp\">Browse the filesystem</a></b><br>\n<b><a href=\"/logs/\">Namenode Logs</a></b><br>\n<b><a href=/dfshealth.jsp> Go back to DFS home</a></b>\n<hr>\n");
/*     */ 
/* 391 */       generateDFSNodesList(out, nn, request);
/*     */ 
/* 393 */       out.write(10);
/* 394 */       out.write(10);
/*     */ 
/* 396 */       out.println(ServletUtil.htmlFooter());
/*     */ 
/* 398 */       out.write(10);
/*     */     } catch (Throwable t) {
/* 400 */       if (!(t instanceof SkipPageException)) {
/* 401 */         out = _jspx_out;
/* 402 */         if ((out != null) && (out.getBufferSize() != 0))
/* 403 */           out.clearBuffer();
/* 404 */         if (_jspx_page_context != null) _jspx_page_context.handlePageException(t); 
/*     */       }
/*     */     }
/* 407 */     finally { _jspxFactory.releasePageContext(_jspx_page_context); }
/*     */ 
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.dfsnodelist_jsp
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs.server.protocol;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.io.Text;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.WritableUtils;
/*     */ 
/*     */ public class BlocksWithLocations
/*     */   implements Writable
/*     */ {
/*     */   private BlockWithLocations[] blocks;
/*     */ 
/*     */   BlocksWithLocations()
/*     */   {
/*     */   }
/*     */ 
/*     */   public BlocksWithLocations(BlockWithLocations[] blocks)
/*     */   {
/*  92 */     this.blocks = blocks;
/*     */   }
/*     */ 
/*     */   public BlockWithLocations[] getBlocks()
/*     */   {
/*  97 */     return this.blocks;
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out) throws IOException
/*     */   {
/* 102 */     WritableUtils.writeVInt(out, this.blocks.length);
/* 103 */     for (int i = 0; i < this.blocks.length; i++)
/* 104 */       this.blocks[i].write(out);
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in)
/*     */     throws IOException
/*     */   {
/* 110 */     int len = WritableUtils.readVInt(in);
/* 111 */     this.blocks = new BlockWithLocations[len];
/* 112 */     for (int i = 0; i < len; i++) {
/* 113 */       this.blocks[i] = new BlockWithLocations();
/* 114 */       this.blocks[i].readFields(in);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class BlockWithLocations
/*     */     implements Writable
/*     */   {
/*     */     Block block;
/*     */     String[] datanodeIDs;
/*     */ 
/*     */     public BlockWithLocations()
/*     */     {
/*  44 */       this.block = new Block();
/*  45 */       this.datanodeIDs = null;
/*     */     }
/*     */ 
/*     */     public BlockWithLocations(Block b, String[] datanodes)
/*     */     {
/*  50 */       this.block = b;
/*  51 */       this.datanodeIDs = datanodes;
/*     */     }
/*     */ 
/*     */     public Block getBlock()
/*     */     {
/*  56 */       return this.block;
/*     */     }
/*     */ 
/*     */     public String[] getDatanodes()
/*     */     {
/*  61 */       return this.datanodeIDs;
/*     */     }
/*     */ 
/*     */     public void readFields(DataInput in) throws IOException
/*     */     {
/*  66 */       this.block.readFields(in);
/*  67 */       int len = WritableUtils.readVInt(in);
/*  68 */       this.datanodeIDs = new String[len];
/*  69 */       for (int i = 0; i < len; i++)
/*  70 */         this.datanodeIDs[i] = Text.readString(in);
/*     */     }
/*     */ 
/*     */     public void write(DataOutput out)
/*     */       throws IOException
/*     */     {
/*  76 */       this.block.write(out);
/*  77 */       WritableUtils.writeVInt(out, this.datanodeIDs.length);
/*  78 */       for (String id : this.datanodeIDs)
/*  79 */         Text.writeString(out, id);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.protocol.BlocksWithLocations
 * JD-Core Version:    0.6.1
 */
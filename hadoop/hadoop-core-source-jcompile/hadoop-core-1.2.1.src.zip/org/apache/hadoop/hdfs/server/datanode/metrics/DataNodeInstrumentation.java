/*     */ package org.apache.hadoop.hdfs.server.datanode.metrics;
/*     */ 
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.metrics2.MetricsBuilder;
/*     */ import org.apache.hadoop.metrics2.MetricsSource;
/*     */ import org.apache.hadoop.metrics2.MetricsSystem;
/*     */ import org.apache.hadoop.metrics2.lib.DefaultMetricsSystem;
/*     */ import org.apache.hadoop.metrics2.lib.MetricMutableCounterInt;
/*     */ import org.apache.hadoop.metrics2.lib.MetricMutableCounterLong;
/*     */ import org.apache.hadoop.metrics2.lib.MetricMutableStat;
/*     */ import org.apache.hadoop.metrics2.lib.MetricsRegistry;
/*     */ import org.apache.hadoop.metrics2.source.JvmMetricsSource;
/*     */ 
/*     */ public class DataNodeInstrumentation
/*     */   implements MetricsSource
/*     */ {
/*  34 */   final MetricsRegistry registry = new MetricsRegistry("datanode");
/*     */ 
/*  36 */   final MetricMutableCounterLong bytesWritten = this.registry.newCounter("bytes_written", "", 0L);
/*     */ 
/*  38 */   final MetricMutableCounterLong bytesRead = this.registry.newCounter("bytes_read", "", 0L);
/*     */ 
/*  40 */   final MetricMutableCounterInt blocksWritten = this.registry.newCounter("blocks_written", "", 0);
/*     */ 
/*  42 */   final MetricMutableCounterInt blocksRead = this.registry.newCounter("blocks_read", "", 0);
/*     */ 
/*  44 */   final MetricMutableCounterInt blocksReplicated = this.registry.newCounter("blocks_replicated", "", 0);
/*     */ 
/*  46 */   final MetricMutableCounterInt blocksRemoved = this.registry.newCounter("blocks_removed", "", 0);
/*     */ 
/*  48 */   final MetricMutableCounterInt blocksVerified = this.registry.newCounter("blocks_verified", "", 0);
/*     */ 
/*  50 */   final MetricMutableCounterInt blockVerificationFailures = this.registry.newCounter("block_verification_failures", "", 0);
/*     */ 
/*  52 */   final MetricMutableCounterInt blocksGetLocalPathInfo = this.registry.newCounter("blocks_get_local_pathinfo", "", 0);
/*     */ 
/*  55 */   final MetricMutableCounterInt readsFromLocalClient = this.registry.newCounter("reads_from_local_client", "", 0);
/*     */ 
/*  57 */   final MetricMutableCounterInt readsFromRemoteClient = this.registry.newCounter("reads_from_remote_client", "", 0);
/*     */ 
/*  59 */   final MetricMutableCounterInt writesFromLocalClient = this.registry.newCounter("writes_from_local_client", "", 0);
/*     */ 
/*  61 */   final MetricMutableCounterInt writesFromRemoteClient = this.registry.newCounter("writes_from_remote_client", "", 0);
/*     */ 
/*  64 */   final MetricMutableStat readBlockOp = this.registry.newStat("readBlockOp");
/*  65 */   final MetricMutableStat writeBlockOp = this.registry.newStat("writeBlockOp");
/*  66 */   final MetricMutableStat blockChecksumOp = this.registry.newStat("blockChecksumOp");
/*  67 */   final MetricMutableStat copyBlockOp = this.registry.newStat("copyBlockOp");
/*  68 */   final MetricMutableStat replaceBlockOp = this.registry.newStat("replaceBlockOp");
/*  69 */   final MetricMutableStat heartbeats = this.registry.newStat("heartBeats");
/*  70 */   final MetricMutableStat blockReports = this.registry.newStat("blockReports");
/*     */ 
/*     */   public DataNodeInstrumentation(Configuration conf, String storageId)
/*     */   {
/*  74 */     String sessionId = conf.get("session.id");
/*  75 */     JvmMetricsSource.create("DataNode", sessionId);
/*  76 */     this.registry.setContext("dfs").tag("sessionId", "", sessionId);
/*     */   }
/*     */ 
/*     */   public void shutdown()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void resetAllMinMax()
/*     */   {
/*  86 */     this.readBlockOp.resetMinMax();
/*  87 */     this.writeBlockOp.resetMinMax();
/*  88 */     this.blockChecksumOp.resetMinMax();
/*  89 */     this.copyBlockOp.resetMinMax();
/*  90 */     this.replaceBlockOp.resetMinMax();
/*  91 */     this.heartbeats.resetMinMax();
/*  92 */     this.blockReports.resetMinMax();
/*     */   }
/*     */ 
/*     */   public void addHeartBeat(long latency)
/*     */   {
/*  97 */     this.heartbeats.add(latency);
/*     */   }
/*     */ 
/*     */   public void addBlockReport(long latency)
/*     */   {
/* 102 */     this.blockReports.add(latency);
/*     */   }
/*     */ 
/*     */   public void incrBlocksReplicated(int delta)
/*     */   {
/* 107 */     this.blocksReplicated.incr(delta);
/*     */   }
/*     */ 
/*     */   public void incrBlocksWritten()
/*     */   {
/* 112 */     this.blocksWritten.incr();
/*     */   }
/*     */ 
/*     */   public void incrBlocksRemoved(int delta)
/*     */   {
/* 117 */     this.blocksRemoved.incr(delta);
/*     */   }
/*     */ 
/*     */   public void incrBytesWritten(int delta)
/*     */   {
/* 122 */     this.bytesWritten.incr(delta);
/*     */   }
/*     */ 
/*     */   public void incrBlockVerificationFailures()
/*     */   {
/* 127 */     this.blockVerificationFailures.incr();
/*     */   }
/*     */ 
/*     */   public void incrBlocksVerified()
/*     */   {
/* 132 */     this.blocksVerified.incr();
/*     */   }
/*     */ 
/*     */   public void incrBlocksGetLocalPathInfo()
/*     */   {
/* 137 */     this.blocksGetLocalPathInfo.incr();
/*     */   }
/*     */ 
/*     */   public void addReadBlockOp(long latency)
/*     */   {
/* 142 */     this.readBlockOp.add(latency);
/*     */   }
/*     */ 
/*     */   public void incrReadsFromLocalClient()
/*     */   {
/* 147 */     this.readsFromLocalClient.incr();
/*     */   }
/*     */ 
/*     */   public void incrReadsFromRemoteClient()
/*     */   {
/* 152 */     this.readsFromRemoteClient.incr();
/*     */   }
/*     */ 
/*     */   public void addWriteBlockOp(long latency)
/*     */   {
/* 157 */     this.writeBlockOp.add(latency);
/*     */   }
/*     */ 
/*     */   public void incrWritesFromLocalClient()
/*     */   {
/* 162 */     this.writesFromLocalClient.incr();
/*     */   }
/*     */ 
/*     */   public void incrWritesFromRemoteClient()
/*     */   {
/* 167 */     this.writesFromRemoteClient.incr();
/*     */   }
/*     */ 
/*     */   public void addReplaceBlockOp(long latency)
/*     */   {
/* 172 */     this.replaceBlockOp.add(latency);
/*     */   }
/*     */ 
/*     */   public void addCopyBlockOp(long latency)
/*     */   {
/* 177 */     this.copyBlockOp.add(latency);
/*     */   }
/*     */ 
/*     */   public void addBlockChecksumOp(long latency)
/*     */   {
/* 182 */     this.blockChecksumOp.add(latency);
/*     */   }
/*     */ 
/*     */   public void incrBytesRead(int delta)
/*     */   {
/* 187 */     this.bytesRead.incr(delta);
/*     */   }
/*     */ 
/*     */   public void incrBlocksRead()
/*     */   {
/* 192 */     this.blocksRead.incr();
/*     */   }
/*     */ 
/*     */   public void getMetrics(MetricsBuilder builder, boolean all)
/*     */   {
/* 197 */     this.registry.snapshot(builder.addRecord(this.registry.name()), all);
/*     */   }
/*     */ 
/*     */   public static DataNodeInstrumentation create(Configuration conf, String storageID)
/*     */   {
/* 202 */     return create(conf, storageID, DefaultMetricsSystem.INSTANCE);
/*     */   }
/*     */ 
/*     */   public static DataNodeInstrumentation create(Configuration conf, String storageID, MetricsSystem ms)
/*     */   {
/* 208 */     return (DataNodeInstrumentation)ms.register("DataNode", "DataNode metrics", new DataNodeInstrumentation(conf, storageID));
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.metrics.DataNodeInstrumentation
 * JD-Core Version:    0.6.1
 */
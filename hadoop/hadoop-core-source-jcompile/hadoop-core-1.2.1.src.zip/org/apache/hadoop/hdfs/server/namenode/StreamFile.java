/*    */ package org.apache.hadoop.hdfs.server.namenode;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.io.PrintWriter;
/*    */ import java.net.InetSocketAddress;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ import org.apache.hadoop.hdfs.DFSClient;
/*    */ import org.apache.hadoop.hdfs.DFSClient.DFSInputStream;
/*    */ import org.apache.hadoop.hdfs.server.datanode.DataNode;
/*    */ import org.apache.hadoop.security.UserGroupInformation;
/*    */ 
/*    */ public class StreamFile extends DfsServlet
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   public static final String CONTENT_LENGTH = "Content-Length";
/*    */   static InetSocketAddress nameNodeAddr;
/* 41 */   static DataNode datanode = null;
/*    */ 
/*    */   protected DFSClient getDFSClient(HttpServletRequest request)
/*    */     throws IOException, InterruptedException
/*    */   {
/* 52 */     Configuration conf = (Configuration)getServletContext().getAttribute("current.conf");
/*    */ 
/* 54 */     UserGroupInformation ugi = getUGI(request, conf);
/*    */ 
/* 56 */     return JspHelper.getDFSClient(ugi, nameNodeAddr, conf);
/*    */   }
/*    */ 
/*    */   public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
/*    */   {
/* 61 */     String filename = request.getPathInfo() != null ? request.getPathInfo() : "/";
/*    */ 
/* 63 */     if ((filename == null) || (filename.length() == 0)) { response.setContentType("text/plain");
/* 65 */       PrintWriter out = response.getWriter();
/* 66 */       out.print("Invalid input");
/*    */       return; }
/*    */     DFSClient dfs;
/*    */     try {
/* 72 */       dfs = getDFSClient(request);
/*    */     } catch (InterruptedException e) {
/* 74 */       response.sendError(400, e.getMessage());
/* 75 */       return;
/*    */     }
/*    */ 
/* 78 */     DFSClient.DFSInputStream in = dfs.open(filename);
/* 79 */     OutputStream os = response.getOutputStream();
/* 80 */     response.setHeader("Content-Disposition", "attachment; filename=\"" + filename + "\"");
/*    */ 
/* 82 */     response.setContentType("application/octet-stream");
/* 83 */     response.setHeader("Content-Length", "" + in.getFileLength());
/* 84 */     byte[] buf = new byte[4096];
/*    */     try
/*    */     {
/*    */       int bytesRead;
/* 87 */       while ((bytesRead = in.read(buf)) != -1)
/* 88 */         os.write(buf, 0, bytesRead);
/*    */     }
/*    */     catch (IOException e) {
/* 91 */       if (LOG.isDebugEnabled()) {
/* 92 */         LOG.debug("response.isCommitted()=" + response.isCommitted(), e);
/*    */       }
/* 94 */       throw e;
/*    */     } finally {
/*    */       try {
/* 97 */         in.close();
/* 98 */         os.close();
/*    */       } finally {
/* 100 */         dfs.close();
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 43 */     if ((StreamFile.datanode = DataNode.getDataNode()) != null)
/* 44 */       nameNodeAddr = datanode.getNameNodeAddr();
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.StreamFile
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs.server.namenode.metrics;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.metrics2.MetricsBuilder;
/*     */ import org.apache.hadoop.metrics2.MetricsSource;
/*     */ import org.apache.hadoop.metrics2.MetricsSystem;
/*     */ import org.apache.hadoop.metrics2.lib.DefaultMetricsSystem;
/*     */ import org.apache.hadoop.metrics2.lib.MetricMutableCounterInt;
/*     */ import org.apache.hadoop.metrics2.lib.MetricMutableGaugeInt;
/*     */ import org.apache.hadoop.metrics2.lib.MetricMutableStat;
/*     */ import org.apache.hadoop.metrics2.lib.MetricsRegistry;
/*     */ import org.apache.hadoop.metrics2.source.JvmMetricsSource;
/*     */ 
/*     */ public class NameNodeInstrumentation
/*     */   implements MetricsSource
/*     */ {
/*  35 */   static final Log LOG = LogFactory.getLog(NameNodeInstrumentation.class);
/*     */   final String sessionId;
/*  38 */   final MetricsRegistry registry = new MetricsRegistry("namenode");
/*  39 */   final MetricMutableCounterInt numFilesCreated = this.registry.newCounter("FilesCreated", "", 0);
/*     */ 
/*  41 */   final MetricMutableCounterInt numFilesAppended = this.registry.newCounter("FilesAppended", "", 0);
/*     */ 
/*  43 */   final MetricMutableCounterInt numGetBlockLocations = this.registry.newCounter("GetBlockLocations", "", 0);
/*     */ 
/*  45 */   final MetricMutableCounterInt numFilesRenamed = this.registry.newCounter("FilesRenamed", "", 0);
/*     */ 
/*  47 */   final MetricMutableCounterInt numGetListingOps = this.registry.newCounter("GetListingOps", "", 0);
/*     */ 
/*  49 */   final MetricMutableCounterInt numCreateFileOps = this.registry.newCounter("CreateFileOps", "", 0);
/*     */ 
/*  51 */   final MetricMutableCounterInt numFilesDeleted = this.registry.newCounter("FilesDeleted", "Files deleted (inc. rename)", 0);
/*     */ 
/*  53 */   final MetricMutableCounterInt numDeleteFileOps = this.registry.newCounter("DeleteFileOps", "", 0);
/*     */ 
/*  55 */   final MetricMutableCounterInt numFileInfoOps = this.registry.newCounter("FileInfoOps", "", 0);
/*     */ 
/*  57 */   final MetricMutableCounterInt numAddBlockOps = this.registry.newCounter("AddBlockOps", "", 0);
/*     */ 
/*  59 */   final MetricMutableStat transactions = this.registry.newStat("Transactions");
/*  60 */   final MetricMutableStat syncs = this.registry.newStat("Syncs");
/*  61 */   final MetricMutableCounterInt transactionsBatchedInSync = this.registry.newCounter("JournalTransactionsBatchedInSync", "", 0);
/*     */ 
/*  63 */   final MetricMutableStat blockReport = this.registry.newStat("blockReport");
/*  64 */   final MetricMutableGaugeInt safeModeTime = this.registry.newGauge("SafemodeTime", "Time spent in safe mode", 0);
/*     */ 
/*  66 */   final MetricMutableGaugeInt fsImageLoadTime = this.registry.newGauge("fsImageLoadTime", "", 0);
/*     */ 
/*  68 */   final MetricMutableCounterInt numFilesInGetListingOps = this.registry.newCounter("FilesInGetListingOps", "", 0);
/*     */ 
/*     */   NameNodeInstrumentation(Configuration conf)
/*     */   {
/*  72 */     this.sessionId = conf.get("session.id");
/*  73 */     JvmMetricsSource.create("NameNode", this.sessionId);
/*  74 */     this.registry.setContext("dfs").tag("sessionId", "", this.sessionId);
/*     */   }
/*     */ 
/*     */   public static NameNodeInstrumentation create(Configuration conf) {
/*  78 */     return create(conf, DefaultMetricsSystem.INSTANCE);
/*     */   }
/*     */ 
/*     */   public static NameNodeInstrumentation create(Configuration conf, MetricsSystem ms)
/*     */   {
/*  89 */     return (NameNodeInstrumentation)ms.register("NameNode", "NameNode metrics", new NameNodeInstrumentation(conf));
/*     */   }
/*     */ 
/*     */   public void shutdown()
/*     */   {
/*     */   }
/*     */ 
/*     */   public final void incrNumGetBlockLocations()
/*     */   {
/* 100 */     this.numGetBlockLocations.incr();
/*     */   }
/*     */ 
/*     */   public final void incrNumFilesCreated()
/*     */   {
/* 105 */     this.numFilesCreated.incr();
/*     */   }
/*     */ 
/*     */   public final void incrNumCreateFileOps()
/*     */   {
/* 110 */     this.numCreateFileOps.incr();
/*     */   }
/*     */ 
/*     */   public final void incrNumFilesAppended()
/*     */   {
/* 115 */     this.numFilesAppended.incr();
/*     */   }
/*     */ 
/*     */   public final void incrNumAddBlockOps()
/*     */   {
/* 120 */     this.numAddBlockOps.incr();
/*     */   }
/*     */ 
/*     */   public final void incrNumFilesRenamed()
/*     */   {
/* 125 */     this.numFilesRenamed.incr();
/*     */   }
/*     */ 
/*     */   public void incrFilesDeleted(int delta)
/*     */   {
/* 130 */     this.numFilesDeleted.incr(delta);
/*     */   }
/*     */ 
/*     */   public final void incrNumDeleteFileOps()
/*     */   {
/* 135 */     this.numDeleteFileOps.incr();
/*     */   }
/*     */ 
/*     */   public final void incrNumGetListingOps()
/*     */   {
/* 140 */     this.numGetListingOps.incr();
/*     */   }
/*     */ 
/*     */   public final void incrNumFilesInGetListingOps(int delta)
/*     */   {
/* 145 */     this.numFilesInGetListingOps.incr(delta);
/*     */   }
/*     */ 
/*     */   public final void incrNumFileInfoOps()
/*     */   {
/* 150 */     this.numFileInfoOps.incr();
/*     */   }
/*     */ 
/*     */   public final void addTransaction(long latency)
/*     */   {
/* 155 */     this.transactions.add(latency);
/*     */   }
/*     */ 
/*     */   public final void incrTransactionsBatchedInSync()
/*     */   {
/* 160 */     this.transactionsBatchedInSync.incr();
/*     */   }
/*     */ 
/*     */   public final void addSync(long elapsed)
/*     */   {
/* 165 */     this.syncs.add(elapsed);
/*     */   }
/*     */ 
/*     */   public final void setFsImageLoadTime(long elapsed)
/*     */   {
/* 170 */     this.fsImageLoadTime.set((int)elapsed);
/*     */   }
/*     */ 
/*     */   public final void addBlockReport(long latency)
/*     */   {
/* 175 */     this.blockReport.add(latency);
/*     */   }
/*     */ 
/*     */   public final void setSafeModeTime(long elapsed)
/*     */   {
/* 180 */     this.safeModeTime.set((int)elapsed);
/*     */   }
/*     */ 
/*     */   public void getMetrics(MetricsBuilder builder, boolean all)
/*     */   {
/* 185 */     this.registry.snapshot(builder.addRecord(this.registry.name()), all);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.metrics.NameNodeInstrumentation
 * JD-Core Version:    0.6.1
 */
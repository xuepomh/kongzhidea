/*     */ package org.apache.hadoop.hdfs.server.datanode;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.SortedSet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.hdfs.server.common.HdfsConstants.NodeType;
/*     */ import org.apache.hadoop.hdfs.server.common.UpgradeManager;
/*     */ import org.apache.hadoop.hdfs.server.protocol.DatanodeProtocol;
/*     */ import org.apache.hadoop.hdfs.server.protocol.DatanodeRegistration;
/*     */ import org.apache.hadoop.hdfs.server.protocol.NamespaceInfo;
/*     */ import org.apache.hadoop.hdfs.server.protocol.UpgradeCommand;
/*     */ import org.apache.hadoop.util.Daemon;
/*     */ 
/*     */ class UpgradeManagerDatanode extends UpgradeManager
/*     */ {
/*  39 */   DataNode dataNode = null;
/*  40 */   Daemon upgradeDaemon = null;
/*     */ 
/*     */   UpgradeManagerDatanode(DataNode dataNode)
/*     */   {
/*  44 */     this.dataNode = dataNode;
/*     */   }
/*     */ 
/*     */   public HdfsConstants.NodeType getType() {
/*  48 */     return HdfsConstants.NodeType.DATA_NODE;
/*     */   }
/*     */ 
/*     */   synchronized void initializeUpgrade(NamespaceInfo nsInfo) throws IOException {
/*  52 */     if (!super.initializeUpgrade())
/*  53 */       return;
/*  54 */     DataNode.LOG.info("\n   Distributed upgrade for DataNode " + this.dataNode.dnRegistration.getName() + " version " + getUpgradeVersion() + " to current LV " + -41 + " is initialized");
/*     */ 
/*  58 */     UpgradeObjectDatanode curUO = (UpgradeObjectDatanode)this.currentUpgrades.first();
/*  59 */     curUO.setDatanode(this.dataNode);
/*  60 */     this.upgradeState = curUO.preUpgradeAction(nsInfo);
/*     */   }
/*     */ 
/*     */   public synchronized boolean startUpgrade()
/*     */     throws IOException
/*     */   {
/*  72 */     if (this.upgradeState)
/*     */     {
/*  74 */       assert (this.currentUpgrades != null) : "UpgradeManagerDatanode.currentUpgrades is null.";
/*  75 */       UpgradeObjectDatanode curUO = (UpgradeObjectDatanode)this.currentUpgrades.first();
/*  76 */       curUO.startUpgrade();
/*  77 */       return true;
/*     */     }
/*  79 */     if (this.broadcastCommand != null) {
/*  80 */       if (this.broadcastCommand.getVersion() > getUpgradeVersion())
/*     */       {
/*  83 */         this.broadcastCommand = null;
/*     */       }
/*     */       else
/*     */       {
/*  89 */         assert (this.currentUpgrades == null) : "UpgradeManagerDatanode.currentUpgrades is not null.";
/*     */ 
/*  91 */         assert (this.upgradeDaemon == null) : "UpgradeManagerDatanode.upgradeDaemon is not null.";
/*  92 */         this.dataNode.namenode.processUpgradeCommand(this.broadcastCommand);
/*  93 */         return true;
/*     */       }
/*     */     }
/*  96 */     if (this.currentUpgrades == null)
/*  97 */       this.currentUpgrades = getDistributedUpgrades();
/*  98 */     if (this.currentUpgrades == null) {
/*  99 */       DataNode.LOG.info("\n   Distributed upgrade for DataNode version " + getUpgradeVersion() + " to current LV " + -41 + " cannot be started. " + "The upgrade object is not defined");
/*     */ 
/* 103 */       return false;
/*     */     }
/* 105 */     this.upgradeState = true;
/* 106 */     UpgradeObjectDatanode curUO = (UpgradeObjectDatanode)this.currentUpgrades.first();
/* 107 */     curUO.setDatanode(this.dataNode);
/* 108 */     curUO.startUpgrade();
/* 109 */     this.upgradeDaemon = new Daemon(curUO);
/* 110 */     this.upgradeDaemon.start();
/* 111 */     DataNode.LOG.info("\n   Distributed upgrade for DataNode " + this.dataNode.dnRegistration.getName() + " version " + getUpgradeVersion() + " to current LV " + -41 + " is started");
/*     */ 
/* 115 */     return true;
/*     */   }
/*     */ 
/*     */   synchronized void processUpgradeCommand(UpgradeCommand command)
/*     */     throws IOException
/*     */   {
/* 121 */     assert (command.getAction() == 101) : "Only start upgrade action can be processed at this time.";
/* 122 */     this.upgradeVersion = command.getVersion();
/*     */ 
/* 124 */     if (startUpgrade())
/* 125 */       return;
/* 126 */     throw new IOException("Distributed upgrade for DataNode " + this.dataNode.dnRegistration.getName() + " version " + getUpgradeVersion() + " to current LV " + -41 + " cannot be started. " + "The upgrade object is not defined.");
/*     */   }
/*     */ 
/*     */   public synchronized void completeUpgrade()
/*     */     throws IOException
/*     */   {
/* 135 */     assert (this.currentUpgrades != null) : "UpgradeManagerDatanode.currentUpgrades is null.";
/* 136 */     UpgradeObjectDatanode curUO = (UpgradeObjectDatanode)this.currentUpgrades.first();
/* 137 */     this.broadcastCommand = curUO.completeUpgrade();
/* 138 */     this.upgradeState = false;
/* 139 */     this.currentUpgrades = null;
/* 140 */     this.upgradeDaemon = null;
/* 141 */     DataNode.LOG.info("\n   Distributed upgrade for DataNode " + this.dataNode.dnRegistration.getName() + " version " + getUpgradeVersion() + " to current LV " + -41 + " is complete");
/*     */   }
/*     */ 
/*     */   synchronized void shutdownUpgrade()
/*     */   {
/* 148 */     if (this.upgradeDaemon != null)
/* 149 */       this.upgradeDaemon.interrupt();
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.UpgradeManagerDatanode
 * JD-Core Version:    0.6.1
 */
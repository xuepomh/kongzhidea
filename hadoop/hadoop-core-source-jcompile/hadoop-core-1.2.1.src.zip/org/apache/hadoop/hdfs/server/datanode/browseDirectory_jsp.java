/*     */ package org.apache.hadoop.hdfs.server.datanode;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URLEncoder;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.jsp.JspFactory;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.SkipPageException;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FsShell;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.hdfs.DFSClient;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.hdfs.protocol.ClientProtocol;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.hdfs.protocol.DirectoryListing;
/*     */ import org.apache.hadoop.hdfs.protocol.HdfsFileStatus;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlock;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlocks;
/*     */ import org.apache.hadoop.hdfs.server.namenode.JspHelper;
/*     */ import org.apache.hadoop.http.HtmlQuoting;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.util.ServletUtil;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ import org.apache.jasper.runtime.HttpJspBase;
/*     */ import org.apache.jasper.runtime.JspSourceDependent;
/*     */ import org.apache.jasper.runtime.ResourceInjector;
/*     */ 
/*     */ public final class browseDirectory_jsp extends HttpJspBase
/*     */   implements JspSourceDependent
/*     */ {
/*  45 */   static JspHelper jspHelper = new JspHelper();
/*     */ 
/* 186 */   private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();
/*     */   private static Vector _jspx_dependants;
/*     */   private ResourceInjector _jspx_resourceInjector;
/*     */ 
/*     */   public void generateDirectoryStructure(JspWriter out, HttpServletRequest req, HttpServletResponse resp, Configuration conf)
/*     */     throws IOException, InterruptedException
/*     */   {
/*  53 */     String dir = HtmlQuoting.unquoteHtmlChars(req.getParameter("dir"));
/*     */ 
/*  55 */     if ((dir == null) || (dir.length() == 0)) {
/*  56 */       out.print("Invalid input");
/*  57 */       return;
/*     */     }
/*     */ 
/*  60 */     String tokenString = req.getParameter("delegation");
/*  61 */     UserGroupInformation ugi = JspHelper.getUGI(req, conf);
/*  62 */     String namenodeInfoPortStr = req.getParameter("namenodeInfoPort");
/*  63 */     int namenodeInfoPort = -1;
/*  64 */     if (namenodeInfoPortStr != null) {
/*  65 */       namenodeInfoPort = Integer.parseInt(namenodeInfoPortStr);
/*     */     }
/*  67 */     DFSClient dfs = JspHelper.getDFSClient(ugi, JspHelper.nameNodeAddr, conf);
/*     */ 
/*  69 */     String target = dir;
/*  70 */     if (!dfs.exists(target)) {
/*  71 */       out.print("<h3>File or directory : " + target + " does not exist</h3>");
/*  72 */       JspHelper.printGotoForm(out, namenodeInfoPort, tokenString, HtmlQuoting.quoteHtmlChars(target));
/*     */     }
/*     */     else
/*     */     {
/*  76 */       if (!dfs.isDirectory(target)) {
/*  77 */         List blocks = dfs.namenode.getBlockLocations(dir, 0L, 1L).getLocatedBlocks();
/*     */ 
/*  80 */         LocatedBlock firstBlock = null;
/*  81 */         DatanodeInfo[] locations = null;
/*  82 */         if (blocks.size() > 0) {
/*  83 */           firstBlock = (LocatedBlock)blocks.get(0);
/*  84 */           locations = firstBlock.getLocations();
/*     */         }
/*  86 */         if ((locations == null) || (locations.length == 0)) {
/*  87 */           out.print("Empty file");
/*     */         } else {
/*  89 */           DatanodeInfo chosenNode = JspHelper.bestNode(firstBlock);
/*  90 */           String fqdn = InetAddress.getByName(chosenNode.getHost()).getCanonicalHostName();
/*     */ 
/*  92 */           String datanodeAddr = chosenNode.getName();
/*  93 */           int datanodePort = Integer.parseInt(datanodeAddr.substring(datanodeAddr.indexOf(58) + 1, datanodeAddr.length()));
/*     */ 
/*  97 */           String redirectLocation = "http://" + fqdn + ":" + chosenNode.getInfoPort() + "/browseBlock.jsp?blockId=" + firstBlock.getBlock().getBlockId() + "&blockSize=" + firstBlock.getBlock().getNumBytes() + "&genstamp=" + firstBlock.getBlock().getGenerationStamp() + "&filename=" + URLEncoder.encode(dir, "UTF-8") + "&datanodePort=" + datanodePort + "&namenodeInfoPort=" + namenodeInfoPort + JspHelper.getDelegationTokenUrlParam(tokenString);
/*     */ 
/* 107 */           resp.sendRedirect(redirectLocation);
/*     */         }
/* 109 */         return;
/*     */       }
/*     */ 
/* 113 */       String[] headings = { "Name", "Type", "Size", "Replication", "Block Size", "Modification Time", "Permission", "Owner", "Group" };
/*     */ 
/* 116 */       out.print("<h3>Contents of directory ");
/* 117 */       JspHelper.printPathWithLinks(HtmlQuoting.quoteHtmlChars(dir), out, namenodeInfoPort, tokenString);
/*     */ 
/* 119 */       out.print("</h3><hr>");
/* 120 */       JspHelper.printGotoForm(out, namenodeInfoPort, tokenString, HtmlQuoting.quoteHtmlChars(dir));
/*     */ 
/* 122 */       out.print("<hr>");
/*     */ 
/* 124 */       File f = new File(dir);
/*     */       String parent;
/* 126 */       if ((parent = f.getParent()) != null) {
/* 127 */         out.print("<a href=\"" + req.getRequestURL() + "?dir=" + URLEncoder.encode(parent, "UTF-8") + "&namenodeInfoPort=" + namenodeInfoPort + JspHelper.getDelegationTokenUrlParam(tokenString) + "\">Go to parent directory</a><br>");
/*     */       }
/*     */ 
/* 133 */       DirectoryListing thisListing = dfs.listPaths(target, HdfsFileStatus.EMPTY_NAME);
/* 134 */       if ((thisListing == null) || (thisListing.getPartialListing().length == 0)) {
/* 135 */         out.print("Empty directory");
/*     */       }
/*     */       else {
/* 138 */         jspHelper.addTableHeader(out);
/* 139 */         int row = 0;
/* 140 */         jspHelper.addTableRow(out, headings, row++);
/* 141 */         String[] cols = new String[headings.length];
/*     */         do {
/* 143 */           HdfsFileStatus[] files = thisListing.getPartialListing();
/* 144 */           for (int i = 0; i < files.length; i++)
/*     */           {
/* 146 */             String localname = files[i].getLocalName();
/* 147 */             if (!files[i].isDir()) {
/* 148 */               cols[1] = "file";
/* 149 */               cols[2] = StringUtils.byteDesc(files[i].getLen());
/* 150 */               cols[3] = Short.toString(files[i].getReplication());
/* 151 */               cols[4] = StringUtils.byteDesc(files[i].getBlockSize());
/*     */             }
/*     */             else {
/* 154 */               cols[1] = "dir";
/* 155 */               cols[2] = "";
/* 156 */               cols[3] = "";
/* 157 */               cols[4] = "";
/*     */             }
/* 159 */             String datanodeUrl = req.getRequestURL() + "?dir=" + URLEncoder.encode(files[i].getFullName(target), "UTF-8") + "&namenodeInfoPort=" + namenodeInfoPort + JspHelper.getDelegationTokenUrlParam(tokenString);
/*     */ 
/* 163 */             cols[0] = ("<a href=\"" + datanodeUrl + "\">" + localname + "</a>");
/* 164 */             cols[5] = FsShell.dateForm.format(new Date(files[i].getModificationTime()));
/* 165 */             cols[6] = files[i].getPermission().toString();
/* 166 */             cols[7] = files[i].getOwner();
/* 167 */             cols[8] = files[i].getGroup();
/* 168 */             jspHelper.addTableRow(out, cols, row++);
/*     */           }
/* 170 */           if (!thisListing.hasMore()) {
/*     */             break;
/*     */           }
/* 173 */           thisListing = dfs.listPaths(target, thisListing.getLastName());
/* 174 */         }while (thisListing != null);
/* 175 */         jspHelper.addTableFooter(out);
/*     */       }
/*     */     }
/* 178 */     String namenodeHost = JspHelper.nameNodeAddr.getHostName();
/* 179 */     out.print("<br><a href=\"http://" + InetAddress.getByName(namenodeHost).getCanonicalHostName() + ":" + namenodeInfoPort + "/dfshealth.jsp\">Go back to DFS home</a>");
/*     */ 
/* 182 */     dfs.close();
/*     */   }
/*     */ 
/*     */   public Object getDependants()
/*     */   {
/* 193 */     return _jspx_dependants;
/*     */   }
/*     */ 
/*     */   public void _jspService(HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException, ServletException
/*     */   {
/* 199 */     PageContext pageContext = null;
/* 200 */     HttpSession session = null;
/* 201 */     ServletContext application = null;
/* 202 */     ServletConfig config = null;
/* 203 */     JspWriter out = null;
/* 204 */     Object page = this;
/* 205 */     JspWriter _jspx_out = null;
/* 206 */     PageContext _jspx_page_context = null;
/*     */     try
/*     */     {
/* 209 */       response.setContentType("text/html; charset=UTF-8");
/* 210 */       pageContext = _jspxFactory.getPageContext(this, request, response, null, true, 8192, true);
/*     */ 
/* 212 */       _jspx_page_context = pageContext;
/* 213 */       application = pageContext.getServletContext();
/* 214 */       config = pageContext.getServletConfig();
/* 215 */       session = pageContext.getSession();
/* 216 */       out = pageContext.getOut();
/* 217 */       _jspx_out = out;
/* 218 */       this._jspx_resourceInjector = ((ResourceInjector)application.getAttribute("com.sun.appserv.jsp.resource.injector"));
/*     */ 
/* 220 */       out.write(10);
/* 221 */       out.write(10);
/* 222 */       out.write("\n\n<!DOCTYPE html>\n<html>\n<head>\n<style type=text/css>\n<!--\nbody \n  {\n  font-face:sanserif;\n  }\n-->\n</style>\n");
/* 223 */       JspHelper.createTitle(out, request, request.getParameter("dir"));
/* 224 */       out.write("\n</head>\n\n<body onload=\"document.goto.dir.focus()\">\n");
/*     */ 
/* 226 */       Configuration conf = (Configuration)getServletContext().getAttribute("current.conf");
/*     */       try
/*     */       {
/* 229 */         generateDirectoryStructure(out, request, response, conf);
/*     */       }
/*     */       catch (IOException ioe) {
/* 232 */         String msg = ioe.getLocalizedMessage();
/* 233 */         int i = msg.indexOf("\n");
/* 234 */         if (i >= 0) {
/* 235 */           msg = msg.substring(0, i);
/*     */         }
/* 237 */         out.print("<h3>" + msg + "</h3>");
/*     */       }
/*     */ 
/* 240 */       out.write("\n<hr>\n\n<h2>Local logs</h2>\n<a href=\"/logs/\">Log</a> directory\n\n");
/*     */ 
/* 242 */       out.println(ServletUtil.htmlFooter());
/*     */ 
/* 244 */       out.write(10);
/*     */     } catch (Throwable t) {
/* 246 */       if (!(t instanceof SkipPageException)) {
/* 247 */         out = _jspx_out;
/* 248 */         if ((out != null) && (out.getBufferSize() != 0))
/* 249 */           out.clearBuffer();
/* 250 */         if (_jspx_page_context != null) _jspx_page_context.handlePageException(t); 
/*     */       }
/*     */     }
/* 253 */     finally { _jspxFactory.releasePageContext(_jspx_page_context); }
/*     */ 
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.browseDirectory_jsp
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.fs.permission.FsAction;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.security.AccessControlException;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ 
/*     */ class FSPermissionChecker
/*     */ {
/*  42 */   static final Log LOG = LogFactory.getLog(UserGroupInformation.class);
/*     */   private final UserGroupInformation ugi;
/*     */   private final String user;
/*     */   private final Set<String> groups;
/*     */   private final boolean isSuper;
/*     */ 
/*     */   FSPermissionChecker(String fsOwner, String supergroup)
/*     */     throws AccessControlException
/*     */   {
/*     */     try
/*     */     {
/*  53 */       this.ugi = UserGroupInformation.getCurrentUser();
/*     */     } catch (IOException e) {
/*  55 */       throw new AccessControlException(e);
/*     */     }
/*     */ 
/*  58 */     HashSet s = new HashSet(Arrays.asList(this.ugi.getGroupNames()));
/*  59 */     this.groups = Collections.unmodifiableSet(s);
/*  60 */     this.user = this.ugi.getShortUserName();
/*  61 */     this.isSuper = ((this.user.equals(fsOwner)) || (this.groups.contains(supergroup)));
/*     */   }
/*     */ 
/*     */   public boolean containsGroup(String group)
/*     */   {
/*  68 */     return this.groups.contains(group);
/*     */   }
/*     */   public String getUser() {
/*  71 */     return this.user;
/*     */   }
/*     */ 
/*     */   public boolean isSuperUser() {
/*  75 */     return this.isSuper;
/*     */   }
/*     */ 
/*     */   public void checkSuperuserPrivilege()
/*     */     throws AccessControlException
/*     */   {
/*  84 */     if (!this.isSuper)
/*  85 */       throw new AccessControlException("Access denied for user " + this.user + ". Superuser privilege is required");
/*     */   }
/*     */ 
/*     */   void checkPermission(String path, INodeDirectory root, boolean doCheckOwner, FsAction ancestorAccess, FsAction parentAccess, FsAction access, FsAction subAccess)
/*     */     throws AccessControlException
/*     */   {
/* 124 */     if (LOG.isDebugEnabled()) {
/* 125 */       LOG.debug("ACCESS CHECK: " + this + ", doCheckOwner=" + doCheckOwner + ", ancestorAccess=" + ancestorAccess + ", parentAccess=" + parentAccess + ", access=" + access + ", subAccess=" + subAccess);
/*     */     }
/*     */ 
/* 133 */     synchronized (root) {
/* 134 */       INode[] inodes = root.getExistingPathINodes(path);
/* 135 */       int ancestorIndex = inodes.length - 2;
/* 136 */       while ((ancestorIndex >= 0) && (inodes[ancestorIndex] == null))
/* 137 */         ancestorIndex--;
/* 138 */       checkTraverse(inodes, ancestorIndex);
/*     */ 
/* 140 */       if ((ancestorAccess != null) && (inodes.length > 1)) {
/* 141 */         check(inodes, ancestorIndex, ancestorAccess);
/*     */       }
/* 143 */       if ((parentAccess != null) && (inodes.length > 1)) {
/* 144 */         check(inodes, inodes.length - 2, parentAccess);
/*     */       }
/* 146 */       if (access != null) {
/* 147 */         check(inodes[(inodes.length - 1)], access);
/*     */       }
/* 149 */       if (subAccess != null) {
/* 150 */         checkSubAccess(inodes[(inodes.length - 1)], subAccess);
/*     */       }
/* 152 */       if (doCheckOwner)
/* 153 */         checkOwner(inodes[(inodes.length - 1)]);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkOwner(INode inode)
/*     */     throws AccessControlException
/*     */   {
/* 160 */     if ((inode != null) && (this.user.equals(inode.getUserName()))) {
/* 161 */       return;
/*     */     }
/* 163 */     throw new AccessControlException("Permission denied");
/*     */   }
/*     */ 
/*     */   private void checkTraverse(INode[] inodes, int last)
/*     */     throws AccessControlException
/*     */   {
/* 169 */     for (int j = 0; j <= last; j++)
/* 170 */       check(inodes[j], FsAction.EXECUTE);
/*     */   }
/*     */ 
/*     */   private void checkSubAccess(INode inode, FsAction access)
/*     */     throws AccessControlException
/*     */   {
/* 177 */     if ((inode == null) || (!inode.isDirectory())) {
/* 178 */       return;
/*     */     }
/*     */ 
/* 181 */     Stack directories = new Stack();
/* 182 */     for (directories.push((INodeDirectory)inode); !directories.isEmpty(); ) {
/* 183 */       INodeDirectory d = (INodeDirectory)directories.pop();
/* 184 */       check(d, access);
/*     */ 
/* 186 */       for (INode child : d.getChildren())
/* 187 */         if (child.isDirectory())
/* 188 */           directories.push((INodeDirectory)child);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void check(INode[] inodes, int i, FsAction access)
/*     */     throws AccessControlException
/*     */   {
/* 197 */     check(i >= 0 ? inodes[i] : null, access);
/*     */   }
/*     */ 
/*     */   private void check(INode inode, FsAction access)
/*     */     throws AccessControlException
/*     */   {
/* 203 */     if (inode == null) {
/* 204 */       return;
/*     */     }
/* 206 */     FsPermission mode = inode.getFsPermission();
/*     */ 
/* 208 */     if (this.user.equals(inode.getUserName())) {
/* 209 */       if (!mode.getUserAction().implies(access));
/*     */     }
/* 211 */     else if (this.groups.contains(inode.getGroupName()))
/*     */     {
/* 212 */       if (!mode.getGroupAction().implies(access));
/*     */     }
/* 215 */     else if (mode.getOtherAction().implies(access)) return;
/*     */ 
/* 217 */     throw new AccessControlException("Permission denied: user=" + this.user + ", access=" + access + ", inode=" + inode);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.FSPermissionChecker
 * JD-Core Version:    0.6.1
 */
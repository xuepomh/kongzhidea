/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.hdfs.DFSClient;
/*     */ import org.apache.hadoop.hdfs.protocol.ClientProtocol;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeID;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.ipc.RemoteException;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.znerd.xmlenc.XMLOutputter;
/*     */ 
/*     */ abstract class DfsServlet extends HttpServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  48 */   static final Log LOG = LogFactory.getLog(DfsServlet.class.getCanonicalName());
/*     */ 
/*     */   protected void writeXml(Exception except, String path, XMLOutputter doc)
/*     */     throws IOException
/*     */   {
/*  53 */     doc.startTag(RemoteException.class.getSimpleName());
/*  54 */     doc.attribute("path", path);
/*  55 */     if ((except instanceof RemoteException))
/*  56 */       doc.attribute("class", ((RemoteException)except).getClassName());
/*     */     else {
/*  58 */       doc.attribute("class", except.getClass().getName());
/*     */     }
/*  60 */     String msg = except.getLocalizedMessage();
/*  61 */     int i = msg.indexOf("\n");
/*  62 */     if (i >= 0) {
/*  63 */       msg = msg.substring(0, i);
/*     */     }
/*  65 */     doc.attribute("message", msg.substring(msg.indexOf(":") + 1).trim());
/*  66 */     doc.endTag();
/*     */   }
/*     */ 
/*     */   protected UserGroupInformation getUGI(HttpServletRequest request, Configuration conf)
/*     */     throws IOException
/*     */   {
/*  74 */     return JspHelper.getUGI(getServletContext(), request, conf);
/*     */   }
/*     */ 
/*     */   protected ClientProtocol createNameNodeProxy()
/*     */     throws IOException
/*     */   {
/*  81 */     ServletContext context = getServletContext();
/*     */ 
/*  84 */     NameNode nn = (NameNode)context.getAttribute("name.node");
/*  85 */     if (nn != null) {
/*  86 */       return nn;
/*     */     }
/*  88 */     InetSocketAddress nnAddr = (InetSocketAddress)context.getAttribute("name.node.address");
/*  89 */     Configuration conf = new Configuration((Configuration)context.getAttribute("current.conf"));
/*     */ 
/*  91 */     return DFSClient.createNamenode(nnAddr, conf);
/*     */   }
/*     */ 
/*     */   protected URI createRedirectUri(String servletpath, UserGroupInformation ugi, DatanodeID host, HttpServletRequest request, String tokenString)
/*     */     throws URISyntaxException
/*     */   {
/*  99 */     String hostname = (host instanceof DatanodeInfo) ? ((DatanodeInfo)host).getHostName() : host.getHost();
/*     */ 
/* 101 */     String scheme = request.getScheme();
/* 102 */     int port = "https".equals(scheme) ? ((Integer)getServletContext().getAttribute("datanode.https.port")).intValue() : host.getInfoPort();
/*     */ 
/* 105 */     String filename = request.getPathInfo();
/* 106 */     String dt = "";
/* 107 */     if (tokenString != null) {
/* 108 */       dt = JspHelper.getDelegationTokenUrlParam(tokenString);
/*     */     }
/* 110 */     return new URI(scheme, null, hostname, port, servletpath, "filename=" + filename + "&ugi=" + ugi.getShortUserName() + dt, null);
/*     */   }
/*     */ 
/*     */   protected String getFilename(HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException
/*     */   {
/* 117 */     String filename = request.getParameter("filename");
/* 118 */     if ((filename == null) || (filename.length() == 0)) {
/* 119 */       throw new IOException("Invalid filename");
/*     */     }
/* 121 */     return filename;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.DfsServlet
 * JD-Core Version:    0.6.1
 */
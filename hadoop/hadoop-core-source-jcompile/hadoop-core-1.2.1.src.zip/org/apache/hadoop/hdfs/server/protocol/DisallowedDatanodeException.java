/*    */ package org.apache.hadoop.hdfs.server.protocol;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.hadoop.hdfs.protocol.DatanodeID;
/*    */ 
/*    */ public class DisallowedDatanodeException extends IOException
/*    */ {
/*    */   public DisallowedDatanodeException(DatanodeID nodeID)
/*    */   {
/* 35 */     super("Datanode denied communication with namenode: " + nodeID.getName());
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.protocol.DisallowedDatanodeException
 * JD-Core Version:    0.6.1
 */
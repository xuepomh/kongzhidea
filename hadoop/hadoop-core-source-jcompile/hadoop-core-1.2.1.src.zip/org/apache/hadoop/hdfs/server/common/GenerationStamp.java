/*     */ package org.apache.hadoop.hdfs.server.common;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.WritableComparable;
/*     */ import org.apache.hadoop.io.WritableFactories;
/*     */ import org.apache.hadoop.io.WritableFactory;
/*     */ 
/*     */ public class GenerationStamp
/*     */   implements WritableComparable<GenerationStamp>
/*     */ {
/*     */   public static final long WILDCARD_STAMP = 1L;
/*     */   public static final long FIRST_VALID_STAMP = 1000L;
/*     */   long genstamp;
/*     */ 
/*     */   public GenerationStamp()
/*     */   {
/*  43 */     this(1000L);
/*     */   }
/*     */ 
/*     */   GenerationStamp(long stamp)
/*     */   {
/*  48 */     this.genstamp = stamp;
/*     */   }
/*     */ 
/*     */   public long getStamp()
/*     */   {
/*  54 */     return this.genstamp;
/*     */   }
/*     */ 
/*     */   public void setStamp(long stamp)
/*     */   {
/*  61 */     this.genstamp = stamp;
/*     */   }
/*     */ 
/*     */   public synchronized long nextStamp()
/*     */   {
/*  68 */     this.genstamp += 1L;
/*  69 */     return this.genstamp;
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/*  76 */     out.writeLong(this.genstamp);
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException {
/*  80 */     this.genstamp = in.readLong();
/*  81 */     if (this.genstamp < 0L)
/*  82 */       throw new IOException("Bad Generation Stamp: " + this.genstamp);
/*     */   }
/*     */ 
/*     */   public static int compare(long x, long y)
/*     */   {
/*  90 */     return x == y ? 0 : x < y ? -1 : 1;
/*     */   }
/*     */ 
/*     */   public int compareTo(GenerationStamp that)
/*     */   {
/*  95 */     return compare(this.genstamp, that.genstamp);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 100 */     if (!(o instanceof GenerationStamp)) {
/* 101 */       return false;
/*     */     }
/* 103 */     return this.genstamp == ((GenerationStamp)o).genstamp;
/*     */   }
/*     */ 
/*     */   public static boolean equalsWithWildcard(long x, long y) {
/* 107 */     return (x == y) || (x == 1L) || (y == 1L);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 112 */     return 629 + (int)(this.genstamp ^ this.genstamp >>> 32);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  31 */     WritableFactories.setFactory(GenerationStamp.class, new WritableFactory()
/*     */     {
/*     */       public Writable newInstance() {
/*  34 */         return new GenerationStamp(0L);
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.common.GenerationStamp
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.URI;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Stack;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.hdfs.HftpFileSystem;
/*     */ import org.apache.hadoop.hdfs.protocol.ClientProtocol;
/*     */ import org.apache.hadoop.hdfs.protocol.DirectoryListing;
/*     */ import org.apache.hadoop.hdfs.protocol.HdfsFileStatus;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.util.VersionInfo;
/*     */ import org.znerd.xmlenc.XMLOutputter;
/*     */ 
/*     */ public class ListPathsServlet extends DfsServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  51 */   public static final ThreadLocal<SimpleDateFormat> df = new ThreadLocal()
/*     */   {
/*     */     protected SimpleDateFormat initialValue() {
/*  54 */       return HftpFileSystem.getDateFormat();
/*     */     }
/*  51 */   };
/*     */ 
/*     */   static void writeInfo(Path fullpath, HdfsFileStatus i, XMLOutputter doc)
/*     */     throws IOException
/*     */   {
/*  65 */     SimpleDateFormat ldf = (SimpleDateFormat)df.get();
/*  66 */     doc.startTag(i.isDir() ? "directory" : "file");
/*  67 */     doc.attribute("path", fullpath.toUri().getPath());
/*  68 */     doc.attribute("modified", ldf.format(new Date(i.getModificationTime())));
/*  69 */     doc.attribute("accesstime", ldf.format(new Date(i.getAccessTime())));
/*  70 */     if (!i.isDir()) {
/*  71 */       doc.attribute("size", String.valueOf(i.getLen()));
/*  72 */       doc.attribute("replication", String.valueOf(i.getReplication()));
/*  73 */       doc.attribute("blocksize", String.valueOf(i.getBlockSize()));
/*     */     }
/*  75 */     doc.attribute("permission", new StringBuilder().append(i.isDir() ? "d" : "-").append(i.getPermission()).toString());
/*  76 */     doc.attribute("owner", i.getOwner());
/*  77 */     doc.attribute("group", i.getGroup());
/*  78 */     doc.endTag();
/*     */   }
/*     */ 
/*     */   protected Map<String, String> buildRoot(HttpServletRequest request, XMLOutputter doc)
/*     */   {
/*  86 */     String path = request.getPathInfo() != null ? request.getPathInfo() : "/";
/*     */ 
/*  88 */     String exclude = request.getParameter("exclude") != null ? request.getParameter("exclude") : "";
/*     */ 
/*  90 */     String filter = request.getParameter("filter") != null ? request.getParameter("filter") : ".*";
/*     */ 
/*  92 */     boolean recur = (request.getParameter("recursive") != null) && ("yes".equals(request.getParameter("recursive")));
/*     */ 
/*  95 */     Map root = new HashMap();
/*  96 */     root.put("path", path);
/*  97 */     root.put("recursive", recur ? "yes" : "no");
/*  98 */     root.put("filter", filter);
/*  99 */     root.put("exclude", exclude);
/* 100 */     root.put("time", ((SimpleDateFormat)df.get()).format(new Date()));
/* 101 */     root.put("version", VersionInfo.getVersion());
/* 102 */     return root;
/*     */   }
/*     */ 
/*     */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 130 */     PrintWriter out = response.getWriter();
/* 131 */     final XMLOutputter doc = new XMLOutputter(out, "UTF-8");
/*     */ 
/* 133 */     final Map root = buildRoot(request, doc);
/* 134 */     final String path = (String)root.get("path");
/*     */     try
/*     */     {
/* 137 */       final boolean recur = "yes".equals(root.get("recursive"));
/* 138 */       final Pattern filter = Pattern.compile((String)root.get("filter"));
/* 139 */       final Pattern exclude = Pattern.compile((String)root.get("exclude"));
/* 140 */       Configuration conf = (Configuration)getServletContext().getAttribute("current.conf");
/*     */ 
/* 143 */       getUGI(request, conf).doAs(new PrivilegedExceptionAction()
/*     */       {
/*     */         public Void run() throws IOException
/*     */         {
/* 147 */           ClientProtocol nn = ListPathsServlet.this.createNameNodeProxy();
/* 148 */           doc.declaration();
/* 149 */           doc.startTag("listing");
/* 150 */           for (Map.Entry m : root.entrySet()) {
/* 151 */             doc.attribute((String)m.getKey(), (String)m.getValue());
/*     */           }
/*     */ 
/* 154 */           HdfsFileStatus base = nn.getFileInfo(path);
/* 155 */           if ((base != null) && (base.isDir())) {
/* 156 */             ListPathsServlet.writeInfo(base.getFullPath(new Path(path)), base, doc);
/*     */           }
/*     */ 
/* 159 */           Stack pathstack = new Stack();
/* 160 */           pathstack.push(path);
/* 161 */           while (!pathstack.empty()) {
/* 162 */             String p = (String)pathstack.pop();
/*     */             try { byte[] lastReturnedName = HdfsFileStatus.EMPTY_NAME;
/*     */               DirectoryListing thisListing;
/*     */               do {
/* 167 */                 assert (lastReturnedName != null);
/* 168 */                 thisListing = nn.getListing(p, lastReturnedName);
/* 169 */                 if (thisListing == null) {
/* 170 */                   if (lastReturnedName.length != 0) break;
/* 171 */                   DfsServlet.LOG.warn("ListPathsServlet - Path " + p + " does not exist"); break;
/*     */                 }
/*     */ 
/* 175 */                 HdfsFileStatus[] listing = thisListing.getPartialListing();
/* 176 */                 for (HdfsFileStatus i : listing) {
/* 177 */                   Path fullpath = i.getFullPath(new Path(p));
/* 178 */                   String localName = fullpath.getName();
/* 179 */                   if ((!exclude.matcher(localName).matches()) && (filter.matcher(localName).matches()))
/*     */                   {
/* 183 */                     if ((recur) && (i.isDir())) {
/* 184 */                       pathstack.push(new Path(p, localName).toUri().getPath());
/*     */                     }
/* 186 */                     ListPathsServlet.writeInfo(fullpath, i, doc);
/*     */                   }
/*     */                 }
/* 188 */                 lastReturnedName = thisListing.getLastName();
/* 189 */               }while (thisListing.hasMore());
/*     */             } catch (IOException re) {
/* 191 */               ListPathsServlet.this.writeXml(re, p, doc);
/*     */             }
/*     */           }
/* 194 */           return null;
/*     */         } } );
/*     */     }
/*     */     catch (IOException ioe) {
/* 198 */       writeXml(ioe, path, doc);
/*     */     } catch (InterruptedException e) {
/* 200 */       LOG.warn("ListPathServlet encountered InterruptedException", e);
/* 201 */       response.sendError(400, e.getMessage());
/*     */     } finally {
/* 203 */       if (doc != null) {
/* 204 */         doc.endDocument();
/*     */       }
/* 206 */       if (out != null)
/* 207 */         out.close();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.ListPathsServlet
 * JD-Core Version:    0.6.1
 */
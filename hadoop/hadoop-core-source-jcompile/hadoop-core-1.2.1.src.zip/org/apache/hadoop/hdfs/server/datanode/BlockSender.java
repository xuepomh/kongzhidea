/*     */ package org.apache.hadoop.hdfs.server.datanode;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.Closeable;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.FileDescriptor;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.SocketException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.fs.ChecksumException;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.hdfs.protocol.FSConstants;
/*     */ import org.apache.hadoop.hdfs.util.DataTransferThrottler;
/*     */ import org.apache.hadoop.io.IOUtils;
/*     */ import org.apache.hadoop.io.ReadaheadPool;
/*     */ import org.apache.hadoop.io.ReadaheadPool.ReadaheadRequest;
/*     */ import org.apache.hadoop.io.nativeio.NativeIO;
/*     */ import org.apache.hadoop.net.SocketOutputStream;
/*     */ import org.apache.hadoop.util.ChecksumUtil;
/*     */ import org.apache.hadoop.util.DataChecksum;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ class BlockSender
/*     */   implements Closeable, FSConstants
/*     */ {
/*  51 */   public static final Log LOG = DataNode.LOG;
/*  52 */   static final Log ClientTraceLog = DataNode.ClientTraceLog;
/*     */   private Block block;
/*     */   private InputStream blockIn;
/*  56 */   private long blockInPosition = -1L;
/*     */   private DataInputStream checksumIn;
/*     */   private DataChecksum checksum;
/*     */   private long initialOffset;
/*     */   private long offset;
/*     */   private long endOffset;
/*     */   private long blockLength;
/*     */   private int bytesPerChecksum;
/*     */   private int checksumSize;
/*     */   private boolean corruptChecksumOk;
/*     */   private boolean chunkOffsetOK;
/*     */   private long seqno;
/*  69 */   private boolean transferToAllowed = true;
/*     */   private boolean blockReadFully;
/*     */   private boolean verifyChecksum;
/*     */   private DataTransferThrottler throttler;
/*     */   private final String clientTraceFmt;
/*     */   private final MemoizedBlock memoizedBlock;
/*     */   private static final int MIN_BUFFER_WITH_TRANSFERTO = 65536;
/*     */   private FileDescriptor blockInFd;
/*     */   private final long readaheadLength;
/*     */   private boolean shouldDropCacheBehindRead;
/*     */   private ReadaheadPool readaheadPool;
/*     */   private ReadaheadPool.ReadaheadRequest curReadahead;
/*     */   private long lastCacheDropOffset;
/*     */   private static final long CACHE_DROP_INTERVAL_BYTES = 1048576L;
/*     */   private static final long LONG_READ_THRESHOLD_BYTES = 262144L;
/*     */ 
/*     */   BlockSender(Block block, long startOffset, long length, boolean corruptChecksumOk, boolean chunkOffsetOK, boolean verifyChecksum, DataNode datanode)
/*     */     throws IOException
/*     */   {
/* 102 */     this(block, startOffset, length, corruptChecksumOk, chunkOffsetOK, verifyChecksum, datanode, null);
/*     */   }
/*     */ 
/*     */   BlockSender(Block block, long startOffset, long length, boolean corruptChecksumOk, boolean chunkOffsetOK, boolean verifyChecksum, DataNode datanode, String clientTraceFmt)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 111 */       this.block = block;
/* 112 */       this.chunkOffsetOK = chunkOffsetOK;
/* 113 */       this.corruptChecksumOk = corruptChecksumOk;
/* 114 */       this.verifyChecksum = verifyChecksum;
/* 115 */       this.blockLength = datanode.data.getVisibleLength(block);
/* 116 */       this.transferToAllowed = datanode.transferToAllowed;
/* 117 */       this.clientTraceFmt = clientTraceFmt;
/* 118 */       this.readaheadLength = datanode.getReadaheadLength();
/* 119 */       this.readaheadPool = datanode.readaheadPool;
/* 120 */       this.shouldDropCacheBehindRead = datanode.shouldDropCacheBehindReads();
/*     */ 
/* 122 */       if ((!corruptChecksumOk) || (datanode.data.metaFileExists(block))) {
/* 123 */         this.checksumIn = new DataInputStream(new BufferedInputStream(datanode.data.getMetaDataInputStream(block), BUFFER_SIZE));
/*     */ 
/* 128 */         BlockMetadataHeader header = BlockMetadataHeader.readHeader(this.checksumIn);
/* 129 */         short version = header.getVersion();
/*     */ 
/* 131 */         if (version != 1) {
/* 132 */           LOG.warn("Wrong version (" + version + ") for metadata file for " + block + " ignoring ...");
/*     */         }
/*     */ 
/* 135 */         this.checksum = header.getChecksum();
/*     */       } else {
/* 137 */         LOG.warn("Could not find metadata file for " + block);
/*     */ 
/* 139 */         this.checksum = DataChecksum.newDataChecksum(0, 16384);
/*     */       }
/*     */ 
/* 147 */       this.bytesPerChecksum = this.checksum.getBytesPerChecksum();
/* 148 */       if ((this.bytesPerChecksum > 10485760) && (this.bytesPerChecksum > this.blockLength)) {
/* 149 */         this.checksum = DataChecksum.newDataChecksum(this.checksum.getChecksumType(), Math.max((int)this.blockLength, 10485760));
/*     */ 
/* 151 */         this.bytesPerChecksum = this.checksum.getBytesPerChecksum();
/*     */       }
/* 153 */       this.checksumSize = this.checksum.getChecksumSize();
/*     */ 
/* 155 */       if (length < 0L) {
/* 156 */         length = this.blockLength;
/*     */       }
/*     */ 
/* 159 */       this.endOffset = this.blockLength;
/* 160 */       if ((startOffset < 0L) || (startOffset > this.endOffset) || (length + startOffset > this.endOffset))
/*     */       {
/* 162 */         String msg = " Offset " + startOffset + " and length " + length + " don't match " + block + " ( blockLen " + this.endOffset + " )";
/*     */ 
/* 164 */         LOG.warn(datanode.dnRegistration + ":sendBlock() : " + msg);
/* 165 */         throw new IOException(msg);
/*     */       }
/*     */ 
/* 169 */       this.offset = (startOffset - startOffset % this.bytesPerChecksum);
/* 170 */       if (length >= 0L)
/*     */       {
/* 172 */         long tmpLen = startOffset + length;
/* 173 */         if (tmpLen % this.bytesPerChecksum != 0L) {
/* 174 */           tmpLen += this.bytesPerChecksum - tmpLen % this.bytesPerChecksum;
/*     */         }
/* 176 */         if (tmpLen < this.endOffset) {
/* 177 */           this.endOffset = tmpLen;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 182 */       if (this.offset > 0L) {
/* 183 */         long checksumSkip = this.offset / this.bytesPerChecksum * this.checksumSize;
/*     */ 
/* 185 */         if (checksumSkip > 0L)
/*     */         {
/* 187 */           IOUtils.skipFully(this.checksumIn, checksumSkip);
/*     */         }
/*     */       }
/* 190 */       this.seqno = 0L;
/*     */ 
/* 192 */       this.blockIn = datanode.data.getBlockInputStream(block, this.offset);
/* 193 */       if ((this.blockIn instanceof FileInputStream))
/* 194 */         this.blockInFd = ((FileInputStream)this.blockIn).getFD();
/*     */       else {
/* 196 */         this.blockInFd = null;
/*     */       }
/* 198 */       this.memoizedBlock = new MemoizedBlock(this.blockIn, this.blockLength, datanode.data, block, null);
/*     */     } catch (IOException ioe) {
/* 200 */       IOUtils.closeStream(this);
/* 201 */       IOUtils.closeStream(this.blockIn);
/* 202 */       throw ioe;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 210 */     if ((this.blockInFd != null) && (this.shouldDropCacheBehindRead) && (isLongRead())) {
/*     */       try
/*     */       {
/* 213 */         NativeIO.posixFadviseIfPossible(this.blockInFd, this.lastCacheDropOffset, this.offset - this.lastCacheDropOffset, 4);
/*     */       }
/*     */       catch (Exception e) {
/* 216 */         LOG.warn("Unable to drop cache on file close", e);
/*     */       }
/*     */     }
/* 219 */     if (this.curReadahead != null) {
/* 220 */       this.curReadahead.cancel();
/*     */     }
/*     */ 
/* 223 */     IOException ioe = null;
/*     */ 
/* 225 */     if (this.checksumIn != null) {
/*     */       try {
/* 227 */         this.checksumIn.close();
/*     */       } catch (IOException e) {
/* 229 */         ioe = e;
/*     */       }
/* 231 */       this.checksumIn = null;
/*     */     }
/*     */ 
/* 234 */     if (this.blockIn != null) {
/*     */       try {
/* 236 */         this.blockIn.close();
/*     */       } catch (IOException e) {
/* 238 */         ioe = e;
/*     */       }
/* 240 */       this.blockIn = null;
/* 241 */       this.blockInFd = null;
/*     */     }
/*     */ 
/* 244 */     if (ioe != null)
/* 245 */       throw ioe;
/*     */   }
/*     */ 
/*     */   private static IOException ioeToSocketException(IOException ioe)
/*     */   {
/* 256 */     if (ioe.getClass().equals(IOException.class))
/*     */     {
/* 258 */       IOException se = new SocketException("Original Exception : " + ioe);
/* 259 */       se.initCause(ioe);
/*     */ 
/* 262 */       se.setStackTrace(ioe.getStackTrace());
/* 263 */       return se;
/*     */     }
/*     */ 
/* 266 */     return ioe;
/*     */   }
/*     */ 
/*     */   private int sendChunks(ByteBuffer pkt, int maxChunks, OutputStream out)
/*     */     throws IOException
/*     */   {
/* 281 */     int len = (int)Math.min(this.endOffset - this.offset, this.bytesPerChecksum * maxChunks);
/*     */ 
/* 288 */     if ((len > this.bytesPerChecksum) && (len % this.bytesPerChecksum != 0)) {
/* 289 */       len -= len % this.bytesPerChecksum;
/*     */     }
/*     */ 
/* 292 */     if (len == 0) {
/* 293 */       return 0;
/*     */     }
/*     */ 
/* 296 */     int numChunks = (len + this.bytesPerChecksum - 1) / this.bytesPerChecksum;
/* 297 */     int packetLen = len + numChunks * this.checksumSize + 4;
/* 298 */     pkt.clear();
/*     */ 
/* 301 */     pkt.putInt(packetLen);
/* 302 */     pkt.putLong(this.offset);
/* 303 */     pkt.putLong(this.seqno);
/* 304 */     pkt.put((byte)(this.offset + len >= this.endOffset ? 1 : 0));
/*     */ 
/* 306 */     pkt.putInt(len);
/*     */ 
/* 308 */     int checksumOff = pkt.position();
/* 309 */     int checksumLen = numChunks * this.checksumSize;
/* 310 */     byte[] buf = pkt.array();
/*     */ 
/* 312 */     if ((this.checksumSize > 0) && (this.checksumIn != null)) {
/*     */       try {
/* 314 */         this.checksumIn.readFully(buf, checksumOff, checksumLen);
/*     */       } catch (IOException e) {
/* 316 */         LOG.warn(" Could not read or failed to veirfy checksum for data at offset " + this.offset + " for block " + this.block + " got : " + StringUtils.stringifyException(e));
/*     */ 
/* 319 */         IOUtils.closeStream(this.checksumIn);
/* 320 */         this.checksumIn = null;
/* 321 */         if (this.corruptChecksumOk) {
/* 322 */           if (checksumOff < checksumLen)
/*     */           {
/* 324 */             Arrays.fill(buf, checksumOff, checksumLen, (byte)0);
/*     */           }
/*     */         }
/* 327 */         else throw e;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 332 */     int dataOff = checksumOff + checksumLen;
/*     */ 
/* 334 */     if (this.blockInPosition < 0L)
/*     */     {
/* 336 */       IOUtils.readFully(this.blockIn, buf, dataOff, len);
/*     */ 
/* 338 */       if (this.verifyChecksum) {
/* 339 */         int dOff = dataOff;
/* 340 */         int cOff = checksumOff;
/* 341 */         int dLeft = len;
/*     */ 
/* 343 */         for (int i = 0; i < numChunks; i++) {
/* 344 */           this.checksum.reset();
/* 345 */           int dLen = Math.min(dLeft, this.bytesPerChecksum);
/* 346 */           this.checksum.update(buf, dOff, dLen);
/* 347 */           if (!this.checksum.compare(buf, cOff)) {
/* 348 */             throw new ChecksumException("Checksum failed at " + (this.offset + len - dLeft), len);
/*     */           }
/*     */ 
/* 351 */           dLeft -= dLen;
/* 352 */           dOff += dLen;
/* 353 */           cOff += this.checksumSize;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 359 */       if (this.memoizedBlock.hasBlockChanged(len)) {
/* 360 */         ChecksumUtil.updateChunkChecksum(buf, checksumOff, dataOff, len, this.checksum);
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 366 */         out.write(buf, 0, dataOff + len);
/*     */       } catch (IOException e) {
/* 368 */         throw ioeToSocketException(e);
/*     */       }
/*     */     }
/*     */     else {
/*     */       try {
/* 373 */         SocketOutputStream sockOut = (SocketOutputStream)out;
/* 374 */         FileChannel fileChannel = ((FileInputStream)this.blockIn).getChannel();
/*     */ 
/* 376 */         if (this.memoizedBlock.hasBlockChanged(len)) {
/* 377 */           fileChannel.position(this.blockInPosition);
/* 378 */           IOUtils.readFileChannelFully(fileChannel, buf, dataOff, len);
/*     */ 
/* 385 */           ChecksumUtil.updateChunkChecksum(buf, checksumOff, dataOff, len, this.checksum);
/*     */ 
/* 388 */           sockOut.write(buf, 0, dataOff + len);
/*     */         }
/*     */         else {
/* 391 */           sockOut.write(buf, 0, dataOff);
/*     */ 
/* 393 */           sockOut.transferToFully(fileChannel, this.blockInPosition, len);
/*     */         }
/*     */ 
/* 396 */         this.blockInPosition += len;
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 402 */         throw ioeToSocketException(e);
/*     */       }
/*     */     }
/*     */ 
/* 406 */     if (this.throttler != null) {
/* 407 */       this.throttler.throttle(packetLen);
/*     */     }
/*     */ 
/* 410 */     return len;
/*     */   }
/*     */ 
/*     */   long sendBlock(DataOutputStream out, OutputStream baseStream, DataTransferThrottler throttler)
/*     */     throws IOException
/*     */   {
/* 428 */     if (out == null) {
/* 429 */       throw new IOException("out stream is null");
/*     */     }
/* 431 */     this.throttler = throttler;
/*     */ 
/* 433 */     this.initialOffset = this.offset;
/* 434 */     long totalRead = 0L;
/* 435 */     OutputStream streamForSendChunks = out;
/*     */ 
/* 437 */     this.lastCacheDropOffset = this.initialOffset;
/*     */ 
/* 439 */     if ((isLongRead()) && (this.blockInFd != null))
/*     */     {
/* 441 */       NativeIO.posixFadviseIfPossible(this.blockInFd, 0L, 0L, 2);
/*     */     }
/*     */ 
/* 446 */     manageOsCache();
/*     */ 
/* 448 */     long startTime = ClientTraceLog.isInfoEnabled() ? System.nanoTime() : 0L;
/*     */     try {
/*     */       try {
/* 451 */         this.checksum.writeHeader(out);
/* 452 */         if (this.chunkOffsetOK) {
/* 453 */           out.writeLong(this.offset);
/*     */         }
/* 455 */         out.flush();
/*     */       } catch (IOException e) {
/* 457 */         throw ioeToSocketException(e);
/*     */       }
/*     */ 
/* 461 */       int pktSize = 25;
/*     */       int maxChunksPerPacket;
/* 463 */       if ((this.transferToAllowed) && (!this.verifyChecksum) && ((baseStream instanceof SocketOutputStream)) && ((this.blockIn instanceof FileInputStream)))
/*     */       {
/* 467 */         FileChannel fileChannel = ((FileInputStream)this.blockIn).getChannel();
/*     */ 
/* 470 */         this.blockInPosition = fileChannel.position();
/* 471 */         streamForSendChunks = baseStream;
/*     */ 
/* 474 */         int maxChunksPerPacket = (Math.max(BUFFER_SIZE, 65536) + this.bytesPerChecksum - 1) / this.bytesPerChecksum;
/*     */ 
/* 480 */         pktSize += (this.bytesPerChecksum + this.checksumSize) * maxChunksPerPacket;
/*     */       } else {
/* 482 */         maxChunksPerPacket = Math.max(1, (BUFFER_SIZE + this.bytesPerChecksum - 1) / this.bytesPerChecksum);
/*     */ 
/* 484 */         pktSize += (this.bytesPerChecksum + this.checksumSize) * maxChunksPerPacket;
/*     */       }
/*     */ 
/* 487 */       ByteBuffer pktBuf = ByteBuffer.allocate(pktSize);
/*     */ 
/* 489 */       while (this.endOffset > this.offset) {
/* 490 */         manageOsCache();
/* 491 */         long len = sendChunks(pktBuf, maxChunksPerPacket, streamForSendChunks);
/*     */ 
/* 493 */         this.offset += len;
/* 494 */         totalRead += len + (len + this.bytesPerChecksum - 1L) / this.bytesPerChecksum * this.checksumSize;
/*     */ 
/* 496 */         this.seqno += 1L;
/*     */       }
/*     */       try {
/* 499 */         out.writeInt(0);
/* 500 */         out.flush();
/*     */       } catch (IOException e) {
/* 502 */         throw ioeToSocketException(e);
/*     */       }
/*     */     }
/*     */     catch (RuntimeException e)
/*     */     {
/*     */       long endTime;
/* 506 */       LOG.error("unexpected exception sending block", e);
/*     */ 
/* 508 */       throw new IOException("unexpected runtime exception", e);
/*     */     }
/*     */     finally {
/* 511 */       if (this.clientTraceFmt != null) {
/* 512 */         long endTime = System.nanoTime();
/* 513 */         ClientTraceLog.info(String.format(this.clientTraceFmt, new Object[] { Long.valueOf(totalRead), Long.valueOf(this.initialOffset), Long.valueOf(endTime - startTime) }));
/*     */       }
/* 515 */       close();
/*     */     }
/*     */ 
/* 518 */     this.blockReadFully = ((this.initialOffset == 0L) && (this.offset >= this.blockLength));
/*     */ 
/* 520 */     return totalRead;
/*     */   }
/*     */ 
/*     */   private void manageOsCache()
/*     */     throws IOException
/*     */   {
/* 527 */     if ((!isLongRead()) || (this.blockInFd == null))
/*     */     {
/* 530 */       return;
/*     */     }
/*     */ 
/* 534 */     if ((this.readaheadLength > 0L) && (this.readaheadPool != null)) {
/* 535 */       this.curReadahead = this.readaheadPool.readaheadStream(this.clientTraceFmt, this.blockInFd, this.offset, this.readaheadLength, 9223372036854775807L, this.curReadahead);
/*     */     }
/*     */ 
/* 541 */     long nextCacheDropOffset = this.lastCacheDropOffset + 1048576L;
/* 542 */     if ((this.shouldDropCacheBehindRead) && (this.offset >= nextCacheDropOffset)) {
/* 543 */       long dropLength = this.offset - this.lastCacheDropOffset;
/* 544 */       if (dropLength >= 1024L) {
/* 545 */         NativeIO.posixFadviseIfPossible(this.blockInFd, this.lastCacheDropOffset, dropLength, 4);
/*     */       }
/*     */ 
/* 548 */       this.lastCacheDropOffset += 1048576L;
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isLongRead() {
/* 553 */     return this.endOffset - this.offset > 262144L;
/*     */   }
/*     */ 
/*     */   boolean isBlockReadFully() {
/* 557 */     return this.blockReadFully;
/*     */   }
/*     */ 
/*     */   private class MemoizedBlock
/*     */   {
/*     */     private InputStream inputStream;
/*     */     private long blockLength;
/*     */     private final FSDatasetInterface fsDataset;
/*     */     private final Block block;
/*     */ 
/*     */     private MemoizedBlock(InputStream inputStream, long blockLength, FSDatasetInterface fsDataset, Block block)
/*     */     {
/* 575 */       this.inputStream = inputStream;
/* 576 */       this.blockLength = blockLength;
/* 577 */       this.fsDataset = fsDataset;
/* 578 */       this.block = block;
/*     */     }
/*     */ 
/*     */     boolean hasBlockChanged(long dataLen)
/*     */       throws IOException
/*     */     {
/* 587 */       if (BlockSender.this.blockInPosition >= 0L) {
/* 588 */         long currentLength = ((FileInputStream)this.inputStream).getChannel().size();
/*     */ 
/* 590 */         return ((BlockSender.this.blockInPosition % BlockSender.this.bytesPerChecksum != 0L) || (dataLen % BlockSender.this.bytesPerChecksum != 0L)) && (currentLength > this.blockLength);
/*     */       }
/*     */ 
/* 595 */       long currentLength = this.fsDataset.getLength(this.block);
/*     */ 
/* 598 */       return ((BlockSender.this.offset % BlockSender.this.bytesPerChecksum != 0L) || (dataLen % BlockSender.this.bytesPerChecksum != 0L)) && (currentLength > this.blockLength);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.BlockSender
 * JD-Core Version:    0.6.1
 */
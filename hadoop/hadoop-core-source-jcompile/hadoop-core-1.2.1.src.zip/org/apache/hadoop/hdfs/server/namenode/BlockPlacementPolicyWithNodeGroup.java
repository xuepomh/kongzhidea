/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.net.NetworkTopology;
/*     */ import org.apache.hadoop.net.NetworkTopologyWithNodeGroup;
/*     */ import org.apache.hadoop.net.Node;
/*     */ 
/*     */ public class BlockPlacementPolicyWithNodeGroup extends BlockPlacementPolicyDefault
/*     */ {
/*     */   BlockPlacementPolicyWithNodeGroup(Configuration conf, FSClusterStats stats, NetworkTopology clusterMap)
/*     */   {
/*  49 */     initialize(conf, stats, clusterMap);
/*     */   }
/*     */ 
/*     */   BlockPlacementPolicyWithNodeGroup()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void initialize(Configuration conf, FSClusterStats stats, NetworkTopology clusterMap)
/*     */   {
/*  58 */     super.initialize(conf, stats, clusterMap);
/*     */   }
/*     */ 
/*     */   protected DatanodeDescriptor chooseLocalNode(DatanodeDescriptor localMachine, HashMap<Node, Node> excludedNodes, long blocksize, int maxNodesPerRack, List<DatanodeDescriptor> results, boolean avoidStaleNodes)
/*     */     throws BlockPlacementPolicy.NotEnoughReplicasException
/*     */   {
/*  72 */     if (localMachine == null) {
/*  73 */       return chooseRandom("", excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */     }
/*     */ 
/*  77 */     Node oldNode = (Node)excludedNodes.put(localMachine, localMachine);
/*  78 */     if ((oldNode == null) && 
/*  79 */       (isGoodTarget(localMachine, blocksize, maxNodesPerRack, false, results, avoidStaleNodes)))
/*     */     {
/*  81 */       results.add(localMachine);
/*     */ 
/*  83 */       addNodeGroupToExcludedNodes(excludedNodes, localMachine.getNetworkLocation());
/*     */ 
/*  85 */       return localMachine;
/*     */     }
/*     */ 
/*  90 */     DatanodeDescriptor chosenNode = chooseLocalNodeGroup((NetworkTopologyWithNodeGroup)this.clusterMap, localMachine, excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */ 
/*  93 */     if (chosenNode != null) {
/*  94 */       return chosenNode;
/*     */     }
/*     */ 
/*  97 */     return chooseLocalRack(localMachine, excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */   }
/*     */ 
/*     */   protected void adjustExcludedNodes(HashMap<Node, Node> excludedNodes, Node chosenNode)
/*     */   {
/* 106 */     addNodeGroupToExcludedNodes(excludedNodes, chosenNode.getNetworkLocation());
/*     */   }
/*     */ 
/*     */   private void addNodeGroupToExcludedNodes(HashMap<Node, Node> excludedNodes, String nodeGroup)
/*     */   {
/* 112 */     List leafNodes = this.clusterMap.getLeaves(nodeGroup);
/* 113 */     for (Node node : leafNodes)
/* 114 */       excludedNodes.put(node, node);
/*     */   }
/*     */ 
/*     */   protected DatanodeDescriptor chooseLocalRack(DatanodeDescriptor localMachine, HashMap<Node, Node> excludedNodes, long blocksize, int maxNodesPerRack, List<DatanodeDescriptor> results, boolean avoidStaleNodes)
/*     */     throws BlockPlacementPolicy.NotEnoughReplicasException
/*     */   {
/* 124 */     if (localMachine == null) {
/* 125 */       return chooseRandom("", excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 132 */       return chooseRandom(NetworkTopology.getFirstHalf(localMachine.getNetworkLocation()), excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */     }
/*     */     catch (BlockPlacementPolicy.NotEnoughReplicasException e1)
/*     */     {
/* 139 */       DatanodeDescriptor newLocal = null;
/* 140 */       Iterator iter = results.iterator();
/* 141 */       while (iter.hasNext()) {
/* 142 */         DatanodeDescriptor nextNode = (DatanodeDescriptor)iter.next();
/* 143 */         if (nextNode != localMachine) {
/* 144 */           newLocal = nextNode;
/* 145 */           break;
/*     */         }
/*     */       }
/* 148 */       if (newLocal != null) {
/*     */         try {
/* 150 */           return chooseRandom(this.clusterMap.getRack(newLocal.getNetworkLocation()), excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */         }
/*     */         catch (BlockPlacementPolicy.NotEnoughReplicasException e2)
/*     */         {
/* 155 */           return chooseRandom("", excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 160 */     return chooseRandom("", excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */   }
/*     */ 
/*     */   protected void chooseRemoteRack(int numOfReplicas, DatanodeDescriptor localMachine, HashMap<Node, Node> excludedNodes, long blocksize, int maxReplicasPerRack, List<DatanodeDescriptor> results, boolean avoidStaleNodes)
/*     */     throws BlockPlacementPolicy.NotEnoughReplicasException
/*     */   {
/* 171 */     int oldNumOfReplicas = results.size();
/*     */     try
/*     */     {
/* 174 */       chooseRandom(numOfReplicas, "~" + NetworkTopology.getFirstHalf(localMachine.getNetworkLocation()), excludedNodes, blocksize, maxReplicasPerRack, results, avoidStaleNodes);
/*     */     }
/*     */     catch (BlockPlacementPolicy.NotEnoughReplicasException e)
/*     */     {
/* 180 */       chooseRandom(numOfReplicas - (results.size() - oldNumOfReplicas), localMachine.getNetworkLocation(), excludedNodes, blocksize, maxReplicasPerRack, results, avoidStaleNodes);
/*     */     }
/*     */   }
/*     */ 
/*     */   private DatanodeDescriptor chooseLocalNodeGroup(NetworkTopologyWithNodeGroup clusterMap, DatanodeDescriptor localMachine, HashMap<Node, Node> excludedNodes, long blocksize, int maxNodesPerRack, List<DatanodeDescriptor> results, boolean avoidStaleNodes)
/*     */     throws BlockPlacementPolicy.NotEnoughReplicasException
/*     */   {
/* 198 */     if (localMachine == null) {
/* 199 */       return chooseRandom("", excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 205 */       return chooseRandom(clusterMap.getNodeGroup(localMachine.getNetworkLocation()), excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */     }
/*     */     catch (BlockPlacementPolicy.NotEnoughReplicasException e1)
/*     */     {
/* 210 */       DatanodeDescriptor newLocal = null;
/* 211 */       Iterator iter = results.iterator();
/* 212 */       while (iter.hasNext()) {
/* 213 */         DatanodeDescriptor nextNode = (DatanodeDescriptor)iter.next();
/* 214 */         if (nextNode != localMachine) {
/* 215 */           newLocal = nextNode;
/* 216 */           break;
/*     */         }
/*     */       }
/* 219 */       if (newLocal != null) {
/*     */         try {
/* 221 */           return chooseRandom(clusterMap.getNodeGroup(newLocal.getNetworkLocation()), excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */         }
/*     */         catch (BlockPlacementPolicy.NotEnoughReplicasException e2)
/*     */         {
/* 227 */           return chooseRandom("", excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 232 */     return chooseRandom("", excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */   }
/*     */ 
/*     */   protected String getRack(DatanodeInfo cur)
/*     */   {
/* 240 */     String nodeGroupString = cur.getNetworkLocation();
/* 241 */     return NetworkTopology.getFirstHalf(nodeGroupString);
/*     */   }
/*     */ 
/*     */   protected int addToExcludedNodes(DatanodeDescriptor localMachine, HashMap<Node, Node> excludedNodes)
/*     */   {
/* 252 */     int countOfExcludedNodes = 0;
/* 253 */     String nodeGroupScope = localMachine.getNetworkLocation();
/* 254 */     List leafNodes = this.clusterMap.getLeaves(nodeGroupScope);
/* 255 */     for (Node leafNode : leafNodes) {
/* 256 */       Node node = (Node)excludedNodes.put(leafNode, leafNode);
/* 257 */       if (node == null)
/*     */       {
/* 259 */         countOfExcludedNodes++;
/*     */       }
/*     */     }
/* 262 */     return countOfExcludedNodes;
/*     */   }
/*     */ 
/*     */   public Iterator<DatanodeDescriptor> pickupReplicaSet(Collection<DatanodeDescriptor> first, Collection<DatanodeDescriptor> second)
/*     */   {
/* 280 */     if (first.isEmpty()) {
/* 281 */       return second.iterator();
/*     */     }
/*     */ 
/* 286 */     Map nodeGroupMap = new HashMap();
/*     */ 
/* 289 */     for (DatanodeDescriptor node : first) {
/* 290 */       String nodeGroupName = NetworkTopology.getLastHalf(node.getNetworkLocation());
/*     */ 
/* 292 */       List datanodeList = (List)nodeGroupMap.get(nodeGroupName);
/*     */ 
/* 294 */       if (datanodeList == null) {
/* 295 */         datanodeList = new ArrayList();
/* 296 */         nodeGroupMap.put(nodeGroupName, datanodeList);
/*     */       }
/* 298 */       datanodeList.add(node);
/*     */     }
/*     */ 
/* 301 */     List moreThanOne = new ArrayList();
/* 302 */     List exactlyOne = new ArrayList();
/*     */ 
/* 304 */     for (List datanodeList : nodeGroupMap.values()) {
/* 305 */       if (datanodeList.size() == 1)
/*     */       {
/* 307 */         exactlyOne.add(datanodeList.get(0));
/*     */       }
/*     */       else {
/* 310 */         moreThanOne.addAll(datanodeList);
/*     */       }
/*     */     }
/*     */ 
/* 314 */     Iterator iter = moreThanOne.isEmpty() ? exactlyOne.iterator() : moreThanOne.iterator();
/*     */ 
/* 316 */     return iter;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.BlockPlacementPolicyWithNodeGroup
 * JD-Core Version:    0.6.1
 */
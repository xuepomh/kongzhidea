package org.apache.hadoop.hdfs.server.namenode;

public abstract interface NameNodeMXBean
{
  public abstract String getHostName();

  public abstract String getVersion();

  public abstract long getUsed();

  public abstract long getFree();

  public abstract long getTotal();

  public abstract String getSafemode();

  public abstract boolean isUpgradeFinalized();

  public abstract long getNonDfsUsedSpace();

  public abstract float getPercentUsed();

  public abstract float getPercentRemaining();

  public abstract long getTotalBlocks();

  public abstract long getTotalFiles();

  public abstract int getThreads();

  public abstract String getLiveNodes();

  public abstract String getDeadNodes();

  public abstract String getDecomNodes();

  public abstract String getNameDirStatuses();
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.NameNodeMXBean
 * JD-Core Version:    0.6.1
 */
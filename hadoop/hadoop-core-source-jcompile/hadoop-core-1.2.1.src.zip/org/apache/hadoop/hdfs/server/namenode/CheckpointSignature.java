/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.hdfs.server.common.StorageInfo;
/*     */ import org.apache.hadoop.io.WritableComparable;
/*     */ 
/*     */ public class CheckpointSignature extends StorageInfo
/*     */   implements WritableComparable<CheckpointSignature>
/*     */ {
/*     */   private static final String FIELD_SEPARATOR = ":";
/*  33 */   long editsTime = -1L;
/*  34 */   long checkpointTime = -1L;
/*     */ 
/*     */   CheckpointSignature() {
/*     */   }
/*     */   CheckpointSignature(FSImage fsImage) {
/*  39 */     super(fsImage);
/*  40 */     this.editsTime = fsImage.getEditLog().getFsEditTime();
/*  41 */     this.checkpointTime = fsImage.checkpointTime;
/*     */   }
/*     */ 
/*     */   CheckpointSignature(String str) {
/*  45 */     String[] fields = str.split(":");
/*  46 */     assert (fields.length == 5) : "Must be 5 fields in CheckpointSignature";
/*  47 */     this.layoutVersion = Integer.valueOf(fields[0]).intValue();
/*  48 */     this.namespaceID = Integer.valueOf(fields[1]).intValue();
/*  49 */     this.cTime = Long.valueOf(fields[2]).longValue();
/*  50 */     this.editsTime = Long.valueOf(fields[3]).longValue();
/*  51 */     this.checkpointTime = Long.valueOf(fields[4]).longValue();
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  55 */     return String.valueOf(this.layoutVersion) + ":" + String.valueOf(this.namespaceID) + ":" + String.valueOf(this.cTime) + ":" + String.valueOf(this.editsTime) + ":" + String.valueOf(this.checkpointTime);
/*     */   }
/*     */ 
/*     */   void validateStorageInfo(StorageInfo si)
/*     */     throws IOException
/*     */   {
/*  63 */     if ((this.layoutVersion != si.layoutVersion) || (this.namespaceID != si.namespaceID) || (this.cTime != si.cTime))
/*     */     {
/*  66 */       throw new IOException("Inconsistent checkpoint fileds. LV = " + this.layoutVersion + " namespaceID = " + this.namespaceID + " cTime = " + this.cTime + ". Expecting respectively: " + si.layoutVersion + "; " + si.namespaceID + "; " + si.cTime);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int compareTo(CheckpointSignature o)
/*     */   {
/*  77 */     return this.checkpointTime > o.checkpointTime ? 1 : this.checkpointTime < o.checkpointTime ? -1 : this.editsTime > o.editsTime ? 1 : this.editsTime < o.editsTime ? -1 : this.cTime > o.cTime ? 1 : this.cTime < o.cTime ? -1 : this.namespaceID > o.namespaceID ? 1 : this.namespaceID < o.namespaceID ? -1 : this.layoutVersion > o.layoutVersion ? 1 : this.layoutVersion < o.layoutVersion ? -1 : 0;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/*  88 */     if (!(o instanceof CheckpointSignature)) {
/*  89 */       return false;
/*     */     }
/*  91 */     return compareTo((CheckpointSignature)o) == 0;
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/*  95 */     return this.layoutVersion ^ this.namespaceID ^ (int)(this.cTime ^ this.editsTime ^ this.checkpointTime);
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/* 103 */     out.writeInt(getLayoutVersion());
/* 104 */     out.writeInt(getNamespaceID());
/* 105 */     out.writeLong(getCTime());
/* 106 */     out.writeLong(this.editsTime);
/* 107 */     out.writeLong(this.checkpointTime);
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException {
/* 111 */     this.layoutVersion = in.readInt();
/* 112 */     this.namespaceID = in.readInt();
/* 113 */     this.cTime = in.readLong();
/* 114 */     this.editsTime = in.readLong();
/* 115 */     this.checkpointTime = in.readLong();
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.CheckpointSignature
 * JD-Core Version:    0.6.1
 */
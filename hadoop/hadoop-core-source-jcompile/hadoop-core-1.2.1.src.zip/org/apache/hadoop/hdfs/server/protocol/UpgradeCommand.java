/*    */ package org.apache.hadoop.hdfs.server.protocol;
/*    */ 
/*    */ import java.io.DataInput;
/*    */ import java.io.DataOutput;
/*    */ import java.io.IOException;
/*    */ import org.apache.hadoop.io.Writable;
/*    */ import org.apache.hadoop.io.WritableFactories;
/*    */ import org.apache.hadoop.io.WritableFactory;
/*    */ 
/*    */ public class UpgradeCommand extends DatanodeCommand
/*    */ {
/*    */   static final int UC_ACTION_UNKNOWN = 0;
/*    */   public static final int UC_ACTION_REPORT_STATUS = 100;
/*    */   public static final int UC_ACTION_START_UPGRADE = 101;
/*    */   private int version;
/*    */   private short upgradeStatus;
/*    */ 
/*    */   public UpgradeCommand()
/*    */   {
/* 47 */     super(0);
/* 48 */     this.version = 0;
/* 49 */     this.upgradeStatus = 0;
/*    */   }
/*    */ 
/*    */   public UpgradeCommand(int action, int version, short status) {
/* 53 */     super(action);
/* 54 */     this.version = version;
/* 55 */     this.upgradeStatus = status;
/*    */   }
/*    */ 
/*    */   public int getVersion() {
/* 59 */     return this.version;
/*    */   }
/*    */ 
/*    */   public short getCurrentStatus() {
/* 63 */     return this.upgradeStatus;
/*    */   }
/*    */ 
/*    */   public void write(DataOutput out)
/*    */     throws IOException
/*    */   {
/* 80 */     super.write(out);
/* 81 */     out.writeInt(this.version);
/* 82 */     out.writeShort(this.upgradeStatus);
/*    */   }
/*    */ 
/*    */   public void readFields(DataInput in)
/*    */     throws IOException
/*    */   {
/* 88 */     super.readFields(in);
/* 89 */     this.version = in.readInt();
/* 90 */     this.upgradeStatus = in.readShort();
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 70 */     WritableFactories.setFactory(UpgradeCommand.class, new WritableFactory()
/*    */     {
/*    */       public Writable newInstance() {
/* 73 */         return new UpgradeCommand();
/*    */       }
/*    */     });
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.protocol.UpgradeCommand
 * JD-Core Version:    0.6.1
 */
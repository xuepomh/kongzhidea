/*     */ package org.apache.hadoop.hdfs.server.datanode;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketException;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.hdfs.protocol.FSConstants;
/*     */ import org.apache.hadoop.hdfs.security.token.block.BlockTokenSecretManager;
/*     */ import org.apache.hadoop.hdfs.security.token.block.BlockTokenSecretManager.AccessMode;
/*     */ import org.apache.hadoop.hdfs.server.datanode.metrics.DataNodeInstrumentation;
/*     */ import org.apache.hadoop.hdfs.server.protocol.DatanodeRegistration;
/*     */ import org.apache.hadoop.io.IOUtils;
/*     */ import org.apache.hadoop.io.MD5Hash;
/*     */ import org.apache.hadoop.io.Text;
/*     */ import org.apache.hadoop.net.NetUtils;
/*     */ import org.apache.hadoop.security.token.SecretManager.InvalidToken;
/*     */ import org.apache.hadoop.security.token.Token;
/*     */ import org.apache.hadoop.util.DataChecksum;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ class DataXceiver
/*     */   implements Runnable, FSConstants
/*     */ {
/*  54 */   public static final Log LOG = DataNode.LOG;
/*  55 */   static final Log ClientTraceLog = DataNode.ClientTraceLog;
/*     */   Socket s;
/*     */   final String remoteAddress;
/*     */   final String localAddress;
/*     */   DataNode datanode;
/*     */   DataXceiverServer dataXceiverServer;
/*     */   private boolean connectToDnViaHostname;
/*     */ 
/*     */   public DataXceiver(Socket s, DataNode datanode, DataXceiverServer dataXceiverServer)
/*     */   {
/*  67 */     this.s = s;
/*  68 */     this.datanode = datanode;
/*  69 */     this.dataXceiverServer = dataXceiverServer;
/*  70 */     dataXceiverServer.childSockets.put(s, s);
/*  71 */     this.remoteAddress = s.getRemoteSocketAddress().toString();
/*  72 */     this.localAddress = s.getLocalSocketAddress().toString();
/*  73 */     LOG.debug("Number of active connections is: " + datanode.getXceiverCount());
/*  74 */     this.connectToDnViaHostname = datanode.getConf().getBoolean("dfs.datanode.use.datanode.hostname", false);
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*  83 */     DataInputStream in = null;
/*     */     try {
/*  85 */       in = new DataInputStream(new BufferedInputStream(NetUtils.getInputStream(this.s), SMALL_BUFFER_SIZE));
/*     */ 
/*  88 */       short version = in.readShort();
/*  89 */       if (version != 17) {
/*  90 */         throw new IOException("Version Mismatch");
/*     */       }
/*  92 */       boolean local = this.s.getInetAddress().equals(this.s.getLocalAddress());
/*  93 */       byte op = in.readByte();
/*     */ 
/*  95 */       int curXceiverCount = this.datanode.getXceiverCount();
/*  96 */       if (curXceiverCount > this.dataXceiverServer.maxXceiverCount) {
/*  97 */         throw new IOException("xceiverCount " + curXceiverCount + " exceeds the limit of concurrent xcievers " + this.dataXceiverServer.maxXceiverCount);
/*     */       }
/*     */ 
/* 101 */       long startTime = DataNode.now();
/* 102 */       switch (op) {
/*     */       case 81:
/* 104 */         readBlock(in);
/* 105 */         this.datanode.myMetrics.addReadBlockOp(DataNode.now() - startTime);
/* 106 */         if (local)
/* 107 */           this.datanode.myMetrics.incrReadsFromLocalClient();
/*     */         else
/* 109 */           this.datanode.myMetrics.incrReadsFromRemoteClient();
/* 110 */         break;
/*     */       case 80:
/* 112 */         writeBlock(in);
/* 113 */         this.datanode.myMetrics.addWriteBlockOp(DataNode.now() - startTime);
/* 114 */         if (local)
/* 115 */           this.datanode.myMetrics.incrWritesFromLocalClient();
/*     */         else
/* 117 */           this.datanode.myMetrics.incrWritesFromRemoteClient();
/* 118 */         break;
/*     */       case 83:
/* 120 */         replaceBlock(in);
/* 121 */         this.datanode.myMetrics.addReplaceBlockOp(DataNode.now() - startTime);
/* 122 */         break;
/*     */       case 84:
/* 125 */         copyBlock(in);
/* 126 */         this.datanode.myMetrics.addCopyBlockOp(DataNode.now() - startTime);
/* 127 */         break;
/*     */       case 85:
/* 129 */         getBlockChecksum(in);
/* 130 */         this.datanode.myMetrics.addBlockChecksumOp(DataNode.now() - startTime);
/* 131 */         break;
/*     */       case 82:
/*     */       default:
/* 133 */         throw new IOException("Unknown opcode " + op + " in data stream");
/*     */       }
/*     */     } catch (Throwable t) {
/* 136 */       LOG.error(this.datanode.dnRegistration + ":DataXceiver", t);
/*     */     } finally {
/* 138 */       LOG.debug(this.datanode.dnRegistration + ":Number of active connections is: " + this.datanode.getXceiverCount());
/*     */ 
/* 140 */       IOUtils.closeStream(in);
/* 141 */       IOUtils.closeSocket(this.s);
/* 142 */       this.dataXceiverServer.childSockets.remove(this.s);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void readBlock(DataInputStream in)
/*     */     throws IOException
/*     */   {
/* 155 */     long blockId = in.readLong();
/* 156 */     Block block = new Block(blockId, 0L, in.readLong());
/*     */ 
/* 158 */     long startOffset = in.readLong();
/* 159 */     long length = in.readLong();
/* 160 */     String clientName = Text.readString(in);
/* 161 */     Token accessToken = new Token();
/* 162 */     accessToken.readFields(in);
/* 163 */     OutputStream baseStream = NetUtils.getOutputStream(this.s, this.datanode.socketWriteTimeout);
/*     */ 
/* 165 */     DataOutputStream out = new DataOutputStream(new BufferedOutputStream(baseStream, SMALL_BUFFER_SIZE));
/*     */ 
/* 168 */     if (this.datanode.isBlockTokenEnabled) {
/*     */       try {
/* 170 */         this.datanode.blockTokenSecretManager.checkAccess(accessToken, null, block, BlockTokenSecretManager.AccessMode.READ);
/*     */       }
/*     */       catch (SecretManager.InvalidToken e) {
/*     */         try {
/* 174 */           out.writeShort(5);
/* 175 */           out.flush();
/* 176 */           throw new IOException("Access token verification failed, for client " + this.remoteAddress + " for OP_READ_BLOCK for " + block);
/*     */         }
/*     */         finally {
/* 179 */           IOUtils.closeStream(out);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 184 */     BlockSender blockSender = null;
/* 185 */     String clientTraceFmt = this.datanode.dnRegistration + " Served " + block + " to " + this.s.getInetAddress();
/*     */     try
/*     */     {
/*     */       try
/*     */       {
/* 194 */         blockSender = new BlockSender(block, startOffset, length, true, true, false, this.datanode, clientTraceFmt);
/*     */       }
/*     */       catch (IOException e) {
/* 197 */         out.writeShort(1);
/* 198 */         throw e;
/*     */       }
/*     */ 
/* 201 */       out.writeShort(0);
/* 202 */       long read = blockSender.sendBlock(out, baseStream, null);
/*     */ 
/* 204 */       if (blockSender.isBlockReadFully())
/*     */       {
/*     */         try
/*     */         {
/* 208 */           if ((in.readShort() == 6) && (this.datanode.blockScanner != null))
/*     */           {
/* 210 */             this.datanode.blockScanner.verifiedByClient(block);
/*     */           }
/*     */         } catch (IOException ignored) {
/*     */         }
/*     */       }
/* 215 */       this.datanode.myMetrics.incrBytesRead((int)read);
/* 216 */       this.datanode.myMetrics.incrBlocksRead();
/*     */     }
/*     */     catch (SocketException ignored) {
/* 219 */       this.datanode.myMetrics.incrBlocksRead();
/*     */     }
/*     */     catch (IOException ioe)
/*     */     {
/* 224 */       LOG.warn(this.datanode.dnRegistration + ":Got exception while serving " + block + " to " + this.s.getInetAddress() + ":\n" + StringUtils.stringifyException(ioe));
/*     */ 
/* 227 */       throw ioe;
/*     */     } finally {
/* 229 */       IOUtils.closeStream(out);
/* 230 */       IOUtils.closeStream(blockSender);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void writeBlock(DataInputStream in)
/*     */     throws IOException
/*     */   {
/* 241 */     DatanodeInfo srcDataNode = null;
/* 242 */     LOG.debug("writeBlock receive buf size " + this.s.getReceiveBufferSize() + " tcp no delay " + this.s.getTcpNoDelay());
/*     */ 
/* 247 */     Block block = new Block(in.readLong(), this.dataXceiverServer.estimateBlockSize, in.readLong());
/*     */ 
/* 249 */     LOG.info("Receiving " + block + " src: " + this.remoteAddress + " dest: " + this.localAddress);
/*     */ 
/* 251 */     int pipelineSize = in.readInt();
/* 252 */     boolean isRecovery = in.readBoolean();
/* 253 */     String client = Text.readString(in);
/* 254 */     boolean hasSrcDataNode = in.readBoolean();
/* 255 */     if (hasSrcDataNode) {
/* 256 */       srcDataNode = new DatanodeInfo();
/* 257 */       srcDataNode.readFields(in);
/*     */     }
/* 259 */     int numTargets = in.readInt();
/* 260 */     if (numTargets < 0) {
/* 261 */       throw new IOException("Mislabelled incoming datastream.");
/*     */     }
/* 263 */     DatanodeInfo[] targets = new DatanodeInfo[numTargets];
/* 264 */     for (int i = 0; i < targets.length; i++) {
/* 265 */       DatanodeInfo tmp = new DatanodeInfo();
/* 266 */       tmp.readFields(in);
/* 267 */       targets[i] = tmp;
/*     */     }
/* 269 */     Token accessToken = new Token();
/* 270 */     accessToken.readFields(in);
/* 271 */     DataOutputStream replyOut = null;
/* 272 */     replyOut = new DataOutputStream(NetUtils.getOutputStream(this.s, this.datanode.socketWriteTimeout));
/*     */ 
/* 274 */     if (this.datanode.isBlockTokenEnabled) {
/*     */       try {
/* 276 */         this.datanode.blockTokenSecretManager.checkAccess(accessToken, null, block, BlockTokenSecretManager.AccessMode.WRITE);
/*     */       }
/*     */       catch (SecretManager.InvalidToken e) {
/*     */         try {
/* 280 */           if (client.length() != 0) {
/* 281 */             replyOut.writeShort(5);
/* 282 */             Text.writeString(replyOut, this.datanode.dnRegistration.getName());
/* 283 */             replyOut.flush();
/*     */           }
/* 285 */           throw new IOException("Access token verification failed, for client " + this.remoteAddress + " for OP_WRITE_BLOCK for " + block);
/*     */         }
/*     */         finally {
/* 288 */           IOUtils.closeStream(replyOut);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 293 */     DataOutputStream mirrorOut = null;
/* 294 */     DataInputStream mirrorIn = null;
/* 295 */     Socket mirrorSock = null;
/* 296 */     BlockReceiver blockReceiver = null;
/* 297 */     String mirrorNode = null;
/* 298 */     String firstBadLink = "";
/* 299 */     short mirrorInStatus = 0;
/*     */     try
/*     */     {
/* 302 */       blockReceiver = new BlockReceiver(block, in, this.s.getRemoteSocketAddress().toString(), this.s.getLocalSocketAddress().toString(), isRecovery, client, srcDataNode, this.datanode);
/*     */ 
/* 311 */       if (targets.length > 0) {
/* 312 */         InetSocketAddress mirrorTarget = null;
/*     */ 
/* 314 */         String mirrorAddrString = targets[0].getName(this.connectToDnViaHostname);
/*     */ 
/* 316 */         mirrorNode = targets[0].getName();
/* 317 */         mirrorTarget = NetUtils.createSocketAddr(mirrorAddrString);
/* 318 */         mirrorSock = this.datanode.newSocket();
/*     */         try {
/* 320 */           int timeoutValue = this.datanode.socketTimeout + 3000 * numTargets;
/*     */ 
/* 322 */           int writeTimeout = this.datanode.socketWriteTimeout + 5000 * numTargets;
/*     */ 
/* 324 */           LOG.debug("Connecting to " + mirrorAddrString);
/* 325 */           NetUtils.connect(mirrorSock, mirrorTarget, timeoutValue);
/* 326 */           mirrorSock.setSoTimeout(timeoutValue);
/* 327 */           mirrorSock.setSendBufferSize(131072);
/* 328 */           mirrorOut = new DataOutputStream(new BufferedOutputStream(NetUtils.getOutputStream(mirrorSock, writeTimeout), SMALL_BUFFER_SIZE));
/*     */ 
/* 332 */           mirrorIn = new DataInputStream(NetUtils.getInputStream(mirrorSock));
/*     */ 
/* 335 */           mirrorOut.writeShort(17);
/* 336 */           mirrorOut.write(80);
/* 337 */           mirrorOut.writeLong(block.getBlockId());
/* 338 */           mirrorOut.writeLong(block.getGenerationStamp());
/* 339 */           mirrorOut.writeInt(pipelineSize);
/* 340 */           mirrorOut.writeBoolean(isRecovery);
/* 341 */           Text.writeString(mirrorOut, client);
/* 342 */           mirrorOut.writeBoolean(hasSrcDataNode);
/* 343 */           if (hasSrcDataNode) {
/* 344 */             srcDataNode.write(mirrorOut);
/*     */           }
/* 346 */           mirrorOut.writeInt(targets.length - 1);
/* 347 */           for (int i = 1; i < targets.length; i++) {
/* 348 */             targets[i].write(mirrorOut);
/*     */           }
/* 350 */           accessToken.write(mirrorOut);
/*     */ 
/* 352 */           blockReceiver.writeChecksumHeader(mirrorOut);
/* 353 */           mirrorOut.flush();
/*     */ 
/* 356 */           if (client.length() != 0) {
/* 357 */             mirrorInStatus = mirrorIn.readShort();
/* 358 */             firstBadLink = Text.readString(mirrorIn);
/* 359 */             if ((LOG.isDebugEnabled()) || (mirrorInStatus != 0)) {
/* 360 */               LOG.info("Datanode " + targets.length + " got response for connect ack " + " from downstream datanode with firstbadlink as " + firstBadLink);
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */         }
/*     */         catch (IOException e)
/*     */         {
/* 368 */           if (client.length() != 0) {
/* 369 */             replyOut.writeShort(1);
/* 370 */             Text.writeString(replyOut, mirrorNode);
/* 371 */             replyOut.flush();
/*     */           }
/* 373 */           IOUtils.closeStream(mirrorOut);
/* 374 */           mirrorOut = null;
/* 375 */           IOUtils.closeStream(mirrorIn);
/* 376 */           mirrorIn = null;
/* 377 */           IOUtils.closeSocket(mirrorSock);
/* 378 */           mirrorSock = null;
/* 379 */           if (client.length() > 0) {
/* 380 */             throw e;
/*     */           }
/* 382 */           LOG.info(this.datanode.dnRegistration + ":Exception transfering " + block + " to mirror " + mirrorNode + "- continuing without the mirror\n" + StringUtils.stringifyException(e));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 391 */       if (client.length() != 0) {
/* 392 */         if ((LOG.isDebugEnabled()) || (mirrorInStatus != 0)) {
/* 393 */           LOG.info("Datanode " + targets.length + " forwarding connect ack to upstream firstbadlink is " + firstBadLink);
/*     */         }
/*     */ 
/* 397 */         replyOut.writeShort(mirrorInStatus);
/* 398 */         Text.writeString(replyOut, firstBadLink);
/* 399 */         replyOut.flush();
/*     */       }
/*     */ 
/* 403 */       String mirrorAddr = mirrorSock == null ? null : mirrorNode;
/* 404 */       blockReceiver.receiveBlock(mirrorOut, mirrorIn, replyOut, mirrorAddr, null, targets.length);
/*     */ 
/* 410 */       if (client.length() == 0) {
/* 411 */         this.datanode.notifyNamenodeReceivedBlock(block, "");
/* 412 */         LOG.info("Received " + block + " src: " + this.remoteAddress + " dest: " + this.localAddress + " size " + block.getNumBytes());
/*     */       }
/*     */ 
/* 416 */       if (this.datanode.blockScanner != null)
/* 417 */         this.datanode.blockScanner.addBlock(block);
/*     */     }
/*     */     catch (IOException ioe)
/*     */     {
/* 421 */       LOG.info("writeBlock " + block + " received exception " + ioe);
/* 422 */       throw ioe;
/*     */     }
/*     */     finally {
/* 425 */       IOUtils.closeStream(mirrorOut);
/* 426 */       IOUtils.closeStream(mirrorIn);
/* 427 */       IOUtils.closeStream(replyOut);
/* 428 */       IOUtils.closeSocket(mirrorSock);
/* 429 */       IOUtils.closeStream(blockReceiver);
/*     */     }
/*     */   }
/*     */ 
/*     */   void getBlockChecksum(DataInputStream in)
/*     */     throws IOException
/*     */   {
/* 438 */     Block block = new Block(in.readLong(), 0L, in.readLong());
/* 439 */     Token accessToken = new Token();
/* 440 */     accessToken.readFields(in);
/* 441 */     DataOutputStream out = new DataOutputStream(NetUtils.getOutputStream(this.s, this.datanode.socketWriteTimeout));
/*     */ 
/* 443 */     if (this.datanode.isBlockTokenEnabled) {
/*     */       try {
/* 445 */         this.datanode.blockTokenSecretManager.checkAccess(accessToken, null, block, BlockTokenSecretManager.AccessMode.READ);
/*     */       }
/*     */       catch (SecretManager.InvalidToken e) {
/*     */         try {
/* 449 */           out.writeShort(5);
/* 450 */           out.flush();
/* 451 */           throw new IOException("Access token verification failed, for client " + this.remoteAddress + " for OP_BLOCK_CHECKSUM for " + block);
/*     */         }
/*     */         finally
/*     */         {
/* 455 */           IOUtils.closeStream(out);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 460 */     FSDatasetInterface.MetaDataInputStream metadataIn = this.datanode.data.getMetaDataInputStream(block);
/* 461 */     DataInputStream checksumIn = new DataInputStream(new BufferedInputStream(metadataIn, BUFFER_SIZE));
/*     */     try
/*     */     {
/* 466 */       BlockMetadataHeader header = BlockMetadataHeader.readHeader(checksumIn);
/* 467 */       DataChecksum checksum = header.getChecksum();
/* 468 */       int bytesPerCRC = checksum.getBytesPerChecksum();
/* 469 */       long crcPerBlock = (metadataIn.getLength() - BlockMetadataHeader.getHeaderSize()) / checksum.getChecksumSize();
/*     */ 
/* 473 */       MD5Hash md5 = MD5Hash.digest(checksumIn);
/*     */ 
/* 475 */       if (LOG.isDebugEnabled()) {
/* 476 */         LOG.debug("block=" + block + ", bytesPerCRC=" + bytesPerCRC + ", crcPerBlock=" + crcPerBlock + ", md5=" + md5);
/*     */       }
/*     */ 
/* 481 */       out.writeShort(0);
/* 482 */       out.writeInt(bytesPerCRC);
/* 483 */       out.writeLong(crcPerBlock);
/* 484 */       md5.write(out);
/* 485 */       out.flush();
/*     */     } finally {
/* 487 */       IOUtils.closeStream(out);
/* 488 */       IOUtils.closeStream(checksumIn);
/* 489 */       IOUtils.closeStream(metadataIn);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void copyBlock(DataInputStream in)
/*     */     throws IOException
/*     */   {
/* 501 */     long blockId = in.readLong();
/* 502 */     Block block = new Block(blockId, 0L, in.readLong());
/* 503 */     Token accessToken = new Token();
/* 504 */     accessToken.readFields(in);
/* 505 */     if (this.datanode.isBlockTokenEnabled) {
/*     */       try {
/* 507 */         this.datanode.blockTokenSecretManager.checkAccess(accessToken, null, block, BlockTokenSecretManager.AccessMode.COPY);
/*     */       }
/*     */       catch (SecretManager.InvalidToken e) {
/* 510 */         LOG.warn("Invalid access token in request from " + this.remoteAddress + " for OP_COPY_BLOCK for " + block);
/*     */ 
/* 512 */         sendResponse(this.s, (short)5, this.datanode.socketWriteTimeout);
/*     */ 
/* 515 */         return;
/*     */       }
/*     */     }
/*     */ 
/* 519 */     if (!this.dataXceiverServer.balanceThrottler.acquire()) {
/* 520 */       LOG.info("Not able to copy block " + blockId + " to " + this.s.getRemoteSocketAddress() + " because threads quota is exceeded");
/*     */ 
/* 522 */       sendResponse(this.s, (short)1, this.datanode.socketWriteTimeout);
/*     */ 
/* 524 */       return;
/*     */     }
/*     */ 
/* 527 */     BlockSender blockSender = null;
/* 528 */     DataOutputStream reply = null;
/* 529 */     boolean isOpSuccess = true;
/*     */     try
/*     */     {
/* 533 */       blockSender = new BlockSender(block, 0L, -1L, false, false, false, this.datanode);
/*     */ 
/* 537 */       OutputStream baseStream = NetUtils.getOutputStream(this.s, this.datanode.socketWriteTimeout);
/*     */ 
/* 539 */       reply = new DataOutputStream(new BufferedOutputStream(baseStream, SMALL_BUFFER_SIZE));
/*     */ 
/* 543 */       reply.writeShort(0);
/*     */ 
/* 545 */       long read = blockSender.sendBlock(reply, baseStream, this.dataXceiverServer.balanceThrottler);
/*     */ 
/* 548 */       this.datanode.myMetrics.incrBytesRead((int)read);
/* 549 */       this.datanode.myMetrics.incrBlocksRead();
/*     */ 
/* 551 */       LOG.info("Copied " + block + " to " + this.s.getRemoteSocketAddress());
/*     */     } catch (IOException ioe) {
/* 553 */       isOpSuccess = false;
/* 554 */       throw ioe;
/*     */     } finally {
/* 556 */       this.dataXceiverServer.balanceThrottler.release();
/* 557 */       if (isOpSuccess)
/*     */         try
/*     */         {
/* 560 */           reply.writeChar(100);
/*     */         }
/*     */         catch (IOException ignored) {
/*     */         }
/* 564 */       IOUtils.closeStream(reply);
/* 565 */       IOUtils.closeStream(blockSender);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void replaceBlock(DataInputStream in)
/*     */     throws IOException
/*     */   {
/* 578 */     long blockId = in.readLong();
/* 579 */     Block block = new Block(blockId, this.dataXceiverServer.estimateBlockSize, in.readLong());
/*     */ 
/* 581 */     String sourceID = Text.readString(in);
/* 582 */     DatanodeInfo proxySource = new DatanodeInfo();
/* 583 */     proxySource.readFields(in);
/* 584 */     Token accessToken = new Token();
/* 585 */     accessToken.readFields(in);
/* 586 */     if (this.datanode.isBlockTokenEnabled) {
/*     */       try {
/* 588 */         this.datanode.blockTokenSecretManager.checkAccess(accessToken, null, block, BlockTokenSecretManager.AccessMode.REPLACE);
/*     */       }
/*     */       catch (SecretManager.InvalidToken e) {
/* 591 */         LOG.warn("Invalid access token in request from " + this.remoteAddress + " for OP_REPLACE_BLOCK for block " + block);
/*     */ 
/* 593 */         sendResponse(this.s, (short)5, this.datanode.socketWriteTimeout);
/*     */ 
/* 595 */         return;
/*     */       }
/*     */     }
/*     */ 
/* 599 */     if (!this.dataXceiverServer.balanceThrottler.acquire()) {
/* 600 */       LOG.warn("Not able to receive block " + blockId + " from " + this.s.getRemoteSocketAddress() + " because threads quota is exceeded.");
/*     */ 
/* 602 */       sendResponse(this.s, (short)1, this.datanode.socketWriteTimeout);
/*     */ 
/* 604 */       return;
/*     */     }
/*     */ 
/* 607 */     Socket proxySock = null;
/* 608 */     DataOutputStream proxyOut = null;
/* 609 */     short opStatus = 0;
/* 610 */     BlockReceiver blockReceiver = null;
/* 611 */     DataInputStream proxyReply = null;
/*     */     try
/*     */     {
/* 615 */       String proxyAddrString = proxySource.getName(this.connectToDnViaHostname);
/*     */ 
/* 617 */       InetSocketAddress proxyAddr = NetUtils.createSocketAddr(proxyAddrString);
/* 618 */       proxySock = this.datanode.newSocket();
/* 619 */       LOG.debug("Connecting to " + proxyAddrString);
/* 620 */       NetUtils.connect(proxySock, proxyAddr, this.datanode.socketTimeout);
/* 621 */       proxySock.setSoTimeout(this.datanode.socketTimeout);
/*     */ 
/* 623 */       OutputStream baseStream = NetUtils.getOutputStream(proxySock, this.datanode.socketWriteTimeout);
/*     */ 
/* 625 */       proxyOut = new DataOutputStream(new BufferedOutputStream(baseStream, SMALL_BUFFER_SIZE));
/*     */ 
/* 629 */       proxyOut.writeShort(17);
/* 630 */       proxyOut.writeByte(84);
/* 631 */       proxyOut.writeLong(block.getBlockId());
/* 632 */       proxyOut.writeLong(block.getGenerationStamp());
/* 633 */       accessToken.write(proxyOut);
/* 634 */       proxyOut.flush();
/*     */ 
/* 637 */       proxyReply = new DataInputStream(new BufferedInputStream(NetUtils.getInputStream(proxySock), BUFFER_SIZE));
/*     */ 
/* 639 */       short status = proxyReply.readShort();
/* 640 */       if (status != 0) {
/* 641 */         if (status == 5) {
/* 642 */           throw new IOException("Copy " + block + " from " + proxySock.getRemoteSocketAddress() + " failed due to access token error");
/*     */         }
/*     */ 
/* 646 */         throw new IOException("Copy " + block + " from " + proxySock.getRemoteSocketAddress() + " failed");
/*     */       }
/*     */ 
/* 650 */       blockReceiver = new BlockReceiver(block, proxyReply, proxySock.getRemoteSocketAddress().toString(), proxySock.getLocalSocketAddress().toString(), false, "", null, this.datanode);
/*     */ 
/* 656 */       blockReceiver.receiveBlock(null, null, null, null, this.dataXceiverServer.balanceThrottler, -1);
/*     */ 
/* 660 */       this.datanode.notifyNamenodeReceivedBlock(block, sourceID);
/*     */ 
/* 662 */       LOG.info("Moved " + block + " from " + this.s.getRemoteSocketAddress());
/*     */     }
/*     */     catch (IOException ioe)
/*     */     {
/* 666 */       opStatus = 1;
/* 667 */       throw ioe;
/*     */     }
/*     */     finally {
/* 670 */       if (opStatus == 0) {
/*     */         try {
/* 672 */           proxyReply.readChar();
/*     */         }
/*     */         catch (IOException ignored)
/*     */         {
/*     */         }
/*     */       }
/* 678 */       this.dataXceiverServer.balanceThrottler.release();
/*     */       try
/*     */       {
/* 682 */         sendResponse(this.s, opStatus, this.datanode.socketWriteTimeout);
/*     */       } catch (IOException ioe) {
/* 684 */         LOG.warn("Error writing reply back to " + this.s.getRemoteSocketAddress());
/*     */       }
/* 686 */       IOUtils.closeStream(proxyOut);
/* 687 */       IOUtils.closeStream(blockReceiver);
/* 688 */       IOUtils.closeStream(proxyReply);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void sendResponse(Socket s, short opStatus, long timeout)
/*     */     throws IOException
/*     */   {
/* 700 */     DataOutputStream reply = new DataOutputStream(NetUtils.getOutputStream(s, timeout));
/*     */     try
/*     */     {
/* 703 */       reply.writeShort(opStatus);
/* 704 */       reply.flush();
/*     */     } finally {
/* 706 */       IOUtils.closeStream(reply);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.DataXceiver
 * JD-Core Version:    0.6.1
 */
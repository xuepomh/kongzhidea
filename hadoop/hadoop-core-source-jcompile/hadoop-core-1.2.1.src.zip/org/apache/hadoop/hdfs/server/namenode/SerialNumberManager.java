/*    */ package org.apache.hadoop.hdfs.server.namenode;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ class SerialNumberManager
/*    */ {
/* 25 */   static final SerialNumberManager INSTANCE = new SerialNumberManager();
/*    */ 
/* 27 */   private SerialNumberMap<String> usermap = new SerialNumberMap(null);
/* 28 */   private SerialNumberMap<String> groupmap = new SerialNumberMap(null);
/*    */ 
/*    */   private SerialNumberManager()
/*    */   {
/* 38 */     getUserSerialNumber(null);
/* 39 */     getGroupSerialNumber(null);
/*    */   }
/*    */ 
/*    */   int getUserSerialNumber(String u)
/*    */   {
/* 32 */     return this.usermap.get(u); } 
/* 33 */   int getGroupSerialNumber(String g) { return this.groupmap.get(g); } 
/* 34 */   String getUser(int n) { return (String)this.usermap.get(n); } 
/* 35 */   String getGroup(int n) { return (String)this.groupmap.get(n); }
/*    */ 
/*    */ 
/*    */   private static class SerialNumberMap<T>
/*    */   {
/* 43 */     private int max = 0;
/*    */ 
/* 46 */     private Map<T, Integer> t2i = new HashMap();
/* 47 */     private Map<Integer, T> i2t = new HashMap();
/*    */ 
/*    */     private int nextSerialNumber()
/*    */     {
/* 44 */       return this.max++;
/*    */     }
/*    */ 
/*    */     synchronized int get(T t)
/*    */     {
/* 50 */       Integer sn = (Integer)this.t2i.get(t);
/* 51 */       if (sn == null) {
/* 52 */         sn = Integer.valueOf(nextSerialNumber());
/* 53 */         this.t2i.put(t, sn);
/* 54 */         this.i2t.put(sn, t);
/*    */       }
/* 56 */       return sn.intValue();
/*    */     }
/*    */ 
/*    */     synchronized T get(int i) {
/* 60 */       if (!this.i2t.containsKey(Integer.valueOf(i))) {
/* 61 */         throw new IllegalStateException("!i2t.containsKey(" + i + "), this=" + this);
/*    */       }
/*    */ 
/* 64 */       return this.i2t.get(Integer.valueOf(i));
/*    */     }
/*    */ 
/*    */     public String toString()
/*    */     {
/* 69 */       return "max=" + this.max + ",\n  t2i=" + this.t2i + ",\n  i2t=" + this.i2t;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.SerialNumberManager
 * JD-Core Version:    0.6.1
 */
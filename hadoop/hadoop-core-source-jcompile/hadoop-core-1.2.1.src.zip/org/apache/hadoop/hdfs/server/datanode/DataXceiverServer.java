/*     */ package org.apache.hadoop.hdfs.server.datanode;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketTimeoutException;
/*     */ import java.nio.channels.AsynchronousCloseException;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.hdfs.protocol.FSConstants;
/*     */ import org.apache.hadoop.hdfs.util.DataTransferThrottler;
/*     */ import org.apache.hadoop.util.Daemon;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ class DataXceiverServer
/*     */   implements Runnable, FSConstants
/*     */ {
/*  45 */   public static final Log LOG = DataNode.LOG;
/*     */   ServerSocket ss;
/*     */   DataNode datanode;
/*  50 */   Map<Socket, Socket> childSockets = Collections.synchronizedMap(new HashMap());
/*     */   static final int MAX_XCEIVER_COUNT = 256;
/*  59 */   int maxXceiverCount = 256;
/*     */   BlockBalanceThrottler balanceThrottler;
/*     */   long estimateBlockSize;
/*     */ 
/*     */   DataXceiverServer(ServerSocket ss, Configuration conf, DataNode datanode)
/*     */   {
/* 114 */     this.ss = ss;
/* 115 */     this.datanode = datanode;
/*     */ 
/* 117 */     this.maxXceiverCount = conf.getInt("dfs.datanode.max.xcievers", 256);
/*     */ 
/* 120 */     this.estimateBlockSize = conf.getLong("dfs.block.size", 67108864L);
/*     */ 
/* 123 */     this.balanceThrottler = new BlockBalanceThrottler(conf.getLong("dfs.balance.bandwidthPerSec", 1048576L), null);
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/* 130 */     while (this.datanode.shouldRun)
/*     */       try {
/* 132 */         Socket s = this.ss.accept();
/* 133 */         s.setTcpNoDelay(true);
/* 134 */         new Daemon(this.datanode.threadGroup, new DataXceiver(s, this.datanode, this)).start();
/*     */       }
/*     */       catch (SocketTimeoutException ignored) {
/*     */       }
/*     */       catch (AsynchronousCloseException ace) {
/* 139 */         LOG.warn(this.datanode.dnRegistration + ":DataXceiveServer:" + StringUtils.stringifyException(ace));
/*     */ 
/* 141 */         this.datanode.shouldRun = false;
/*     */       } catch (IOException ie) {
/* 143 */         LOG.warn(this.datanode.dnRegistration + ":DataXceiveServer: IOException due to:" + StringUtils.stringifyException(ie));
/*     */       }
/*     */       catch (Throwable te) {
/* 146 */         LOG.error(this.datanode.dnRegistration + ":DataXceiveServer: Exiting due to:" + StringUtils.stringifyException(te));
/*     */ 
/* 148 */         this.datanode.shouldRun = false;
/*     */       }
/*     */     try
/*     */     {
/* 152 */       this.ss.close();
/*     */     } catch (IOException ie) {
/* 154 */       LOG.warn(this.datanode.dnRegistration + ":DataXceiveServer: Close exception due to: " + StringUtils.stringifyException(ie));
/*     */     }
/*     */ 
/* 157 */     LOG.info("Exiting DataXceiveServer");
/*     */   }
/*     */ 
/*     */   void kill()
/*     */   {
/* 162 */     assert (!this.datanode.shouldRun) : "shoudRun should be set to false before killing";
/*     */     try {
/* 164 */       this.ss.close();
/*     */     } catch (IOException ie) {
/* 166 */       LOG.warn(this.datanode.dnRegistration + ":DataXceiveServer.kill(): " + StringUtils.stringifyException(ie));
/*     */     }
/*     */ 
/* 171 */     synchronized (this.childSockets) {
/* 172 */       Iterator it = this.childSockets.values().iterator();
/* 173 */       while (it.hasNext()) {
/* 174 */         Socket thissock = (Socket)it.next();
/*     */         try {
/* 176 */           thissock.close();
/*     */         }
/*     */         catch (IOException e)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static class BlockBalanceThrottler extends DataTransferThrottler
/*     */   {
/*     */     private int numThreads;
/*     */ 
/*     */     private BlockBalanceThrottler(long bandwidth)
/*     */     {
/*  75 */       super();
/*  76 */       DataXceiverServer.LOG.info("Balancing bandwith is " + bandwidth + " bytes/s");
/*     */     }
/*     */ 
/*     */     synchronized boolean acquire()
/*     */     {
/*  85 */       if (this.numThreads >= 5) {
/*  86 */         return false;
/*     */       }
/*  88 */       this.numThreads += 1;
/*  89 */       return true;
/*     */     }
/*     */ 
/*     */     synchronized void release()
/*     */     {
/*  94 */       this.numThreads -= 1;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.DataXceiverServer
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.server.common;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class IncorrectVersionException extends IOException
/*    */ {
/*    */   public IncorrectVersionException(int versionReported, String ofWhat)
/*    */   {
/* 32 */     this(versionReported, ofWhat, -41);
/*    */   }
/*    */ 
/*    */   public IncorrectVersionException(int versionReported, String ofWhat, int versionExpected)
/*    */   {
/* 38 */     super(new StringBuilder().append("Unexpected version ").append(ofWhat == null ? "" : new StringBuilder().append("of ").append(ofWhat).toString()).append(". Reported: ").append(versionReported).append(". Expecting = ").append(versionExpected).append(".").toString());
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.common.IncorrectVersionException
 * JD-Core Version:    0.6.1
 */
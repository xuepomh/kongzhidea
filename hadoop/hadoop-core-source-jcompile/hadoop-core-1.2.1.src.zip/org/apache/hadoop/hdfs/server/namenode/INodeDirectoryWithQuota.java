/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import org.apache.hadoop.fs.permission.PermissionStatus;
/*     */ import org.apache.hadoop.hdfs.protocol.DSQuotaExceededException;
/*     */ import org.apache.hadoop.hdfs.protocol.NSQuotaExceededException;
/*     */ import org.apache.hadoop.hdfs.protocol.QuotaExceededException;
/*     */ 
/*     */ class INodeDirectoryWithQuota extends INodeDirectory
/*     */ {
/*     */   private long nsQuota;
/*     */   private long nsCount;
/*     */   private long dsQuota;
/*     */   private long diskspace;
/*     */ 
/*     */   INodeDirectoryWithQuota(long nsQuota, long dsQuota, INodeDirectory other)
/*     */     throws QuotaExceededException
/*     */   {
/*  42 */     super(other);
/*  43 */     INode.DirCounts counts = new INode.DirCounts();
/*  44 */     other.spaceConsumedInTree(counts);
/*  45 */     this.nsCount = counts.getNsCount();
/*  46 */     this.diskspace = counts.getDsCount();
/*  47 */     setQuota(nsQuota, dsQuota);
/*     */   }
/*     */ 
/*     */   INodeDirectoryWithQuota(PermissionStatus permissions, long modificationTime, long nsQuota, long dsQuota)
/*     */   {
/*  55 */     super(permissions, modificationTime);
/*  56 */     this.nsQuota = nsQuota;
/*  57 */     this.dsQuota = dsQuota;
/*  58 */     this.nsCount = 1L;
/*     */   }
/*     */ 
/*     */   INodeDirectoryWithQuota(String name, PermissionStatus permissions, long nsQuota, long dsQuota)
/*     */   {
/*  65 */     super(name, permissions);
/*  66 */     this.nsQuota = nsQuota;
/*  67 */     this.dsQuota = dsQuota;
/*  68 */     this.nsCount = 1L;
/*     */   }
/*     */ 
/*     */   long getNsQuota()
/*     */   {
/*  75 */     return this.nsQuota;
/*     */   }
/*     */ 
/*     */   long getDsQuota()
/*     */   {
/*  82 */     return this.dsQuota;
/*     */   }
/*     */ 
/*     */   void setQuota(long newNsQuota, long newDsQuota)
/*     */   {
/*  92 */     this.nsQuota = newNsQuota;
/*  93 */     this.dsQuota = newDsQuota;
/*     */   }
/*     */ 
/*     */   INode.DirCounts spaceConsumedInTree(INode.DirCounts counts)
/*     */   {
/*  99 */     counts.nsCount += this.nsCount;
/* 100 */     counts.dsCount += this.diskspace;
/* 101 */     return counts;
/*     */   }
/*     */ 
/*     */   long numItemsInTree()
/*     */   {
/* 108 */     return this.nsCount;
/*     */   }
/*     */ 
/*     */   long diskspaceConsumed() {
/* 112 */     return this.diskspace;
/*     */   }
/*     */ 
/*     */   void updateNumItemsInTree(long nsDelta, long dsDelta)
/*     */   {
/* 121 */     this.nsCount += nsDelta;
/* 122 */     this.diskspace += dsDelta;
/*     */   }
/*     */ 
/*     */   void addSpaceConsumed(long nsDelta, long dsDelta)
/*     */   {
/* 131 */     setSpaceConsumed(this.nsCount + nsDelta, this.diskspace + dsDelta);
/*     */   }
/*     */ 
/*     */   void setSpaceConsumed(long namespace, long diskspace)
/*     */   {
/* 143 */     this.nsCount = namespace;
/* 144 */     this.diskspace = diskspace;
/*     */   }
/*     */ 
/*     */   void verifyQuota(long nsDelta, long dsDelta)
/*     */     throws QuotaExceededException
/*     */   {
/* 151 */     long newCount = this.nsCount + nsDelta;
/* 152 */     long newDiskspace = this.diskspace + dsDelta;
/* 153 */     if ((nsDelta > 0L) || (dsDelta > 0L)) {
/* 154 */       if ((this.nsQuota >= 0L) && (this.nsQuota < newCount)) {
/* 155 */         throw new NSQuotaExceededException(this.nsQuota, newCount);
/*     */       }
/* 157 */       if ((this.dsQuota >= 0L) && (this.dsQuota < newDiskspace))
/* 158 */         throw new DSQuotaExceededException(this.dsQuota, newDiskspace);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.INodeDirectoryWithQuota
 * JD-Core Version:    0.6.1
 */
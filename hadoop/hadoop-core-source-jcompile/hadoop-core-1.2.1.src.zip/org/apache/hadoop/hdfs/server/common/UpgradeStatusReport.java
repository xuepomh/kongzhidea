/*     */ package org.apache.hadoop.hdfs.server.common;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.WritableFactories;
/*     */ import org.apache.hadoop.io.WritableFactory;
/*     */ 
/*     */ public class UpgradeStatusReport
/*     */   implements Writable
/*     */ {
/*     */   protected int version;
/*     */   protected short upgradeStatus;
/*     */   protected boolean finalized;
/*     */ 
/*     */   public UpgradeStatusReport()
/*     */   {
/*  40 */     this.version = 0;
/*  41 */     this.upgradeStatus = 0;
/*  42 */     this.finalized = false;
/*     */   }
/*     */ 
/*     */   public UpgradeStatusReport(int version, short status, boolean isFinalized) {
/*  46 */     this.version = version;
/*  47 */     this.upgradeStatus = status;
/*  48 */     this.finalized = isFinalized;
/*     */   }
/*     */ 
/*     */   public int getVersion()
/*     */   {
/*  56 */     return this.version;
/*     */   }
/*     */ 
/*     */   public short getUpgradeStatus()
/*     */   {
/*  65 */     return this.upgradeStatus;
/*     */   }
/*     */ 
/*     */   public boolean isFinalized()
/*     */   {
/*  73 */     return this.finalized;
/*     */   }
/*     */ 
/*     */   public String getStatusText(boolean details)
/*     */   {
/*  85 */     return new StringBuilder().append("Upgrade for version ").append(getVersion()).append(this.upgradeStatus < 100 ? new StringBuilder().append(" is in progress. Status = ").append(this.upgradeStatus).append("%").toString() : new StringBuilder().append(" has been completed.\nUpgrade is ").append(this.finalized ? "" : "not ").append("finalized.").toString()).toString();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  97 */     return getStatusText(false);
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/* 114 */     out.writeInt(this.version);
/* 115 */     out.writeShort(this.upgradeStatus);
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in)
/*     */     throws IOException
/*     */   {
/* 121 */     this.version = in.readInt();
/* 122 */     this.upgradeStatus = in.readShort();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 104 */     WritableFactories.setFactory(UpgradeStatusReport.class, new WritableFactory()
/*     */     {
/*     */       public Writable newInstance() {
/* 107 */         return new UpgradeStatusReport();
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.common.UpgradeStatusReport
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.server.protocol;
/*    */ 
/*    */ import java.io.DataInput;
/*    */ import java.io.DataOutput;
/*    */ import java.io.IOException;
/*    */ import org.apache.hadoop.hdfs.security.token.block.ExportedBlockKeys;
/*    */ import org.apache.hadoop.io.Writable;
/*    */ import org.apache.hadoop.io.WritableFactories;
/*    */ import org.apache.hadoop.io.WritableFactory;
/*    */ 
/*    */ public class KeyUpdateCommand extends DatanodeCommand
/*    */ {
/*    */   private ExportedBlockKeys keys;
/*    */ 
/*    */   KeyUpdateCommand()
/*    */   {
/* 33 */     this(new ExportedBlockKeys());
/*    */   }
/*    */ 
/*    */   public KeyUpdateCommand(ExportedBlockKeys keys) {
/* 37 */     super(7);
/* 38 */     this.keys = keys;
/*    */   }
/*    */ 
/*    */   public ExportedBlockKeys getExportedKeys() {
/* 42 */     return this.keys;
/*    */   }
/*    */ 
/*    */   public void write(DataOutput out)
/*    */     throws IOException
/*    */   {
/* 59 */     super.write(out);
/* 60 */     this.keys.write(out);
/*    */   }
/*    */ 
/*    */   public void readFields(DataInput in)
/*    */     throws IOException
/*    */   {
/* 66 */     super.readFields(in);
/* 67 */     this.keys.readFields(in);
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 49 */     WritableFactories.setFactory(KeyUpdateCommand.class, new WritableFactory() {
/*    */       public Writable newInstance() {
/* 51 */         return new KeyUpdateCommand();
/*    */       }
/*    */     });
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.protocol.KeyUpdateCommand
 * JD-Core Version:    0.6.1
 */
package org.apache.hadoop.hdfs.server.common;

import java.io.IOException;
import org.apache.hadoop.hdfs.server.protocol.UpgradeCommand;

public abstract interface Upgradeable extends Comparable<Upgradeable>
{
  public abstract int getVersion();

  public abstract HdfsConstants.NodeType getType();

  public abstract String getDescription();

  public abstract short getUpgradeStatus();

  public abstract UpgradeCommand startUpgrade()
    throws IOException;

  public abstract UpgradeCommand completeUpgrade()
    throws IOException;

  public abstract UpgradeStatusReport getUpgradeStatusReport(boolean paramBoolean)
    throws IOException;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.common.Upgradeable
 * JD-Core Version:    0.6.1
 */
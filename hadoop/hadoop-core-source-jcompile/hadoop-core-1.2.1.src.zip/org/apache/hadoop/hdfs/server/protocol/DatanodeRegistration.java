/*     */ package org.apache.hadoop.hdfs.server.protocol;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeID;
/*     */ import org.apache.hadoop.hdfs.security.token.block.ExportedBlockKeys;
/*     */ import org.apache.hadoop.hdfs.server.common.Storage;
/*     */ import org.apache.hadoop.hdfs.server.common.StorageInfo;
/*     */ import org.apache.hadoop.hdfs.server.datanode.DataStorage;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.WritableFactories;
/*     */ import org.apache.hadoop.io.WritableFactory;
/*     */ 
/*     */ public class DatanodeRegistration extends DatanodeID
/*     */   implements Writable
/*     */ {
/*     */   public StorageInfo storageInfo;
/*     */   public ExportedBlockKeys exportedKeys;
/*     */ 
/*     */   public DatanodeRegistration()
/*     */   {
/*  56 */     this("");
/*     */   }
/*     */ 
/*     */   public DatanodeRegistration(String nodeName)
/*     */   {
/*  63 */     super(nodeName);
/*  64 */     this.storageInfo = new StorageInfo();
/*  65 */     this.exportedKeys = new ExportedBlockKeys();
/*     */   }
/*     */ 
/*     */   public void setInfoPort(int infoPort) {
/*  69 */     this.infoPort = infoPort;
/*     */   }
/*     */ 
/*     */   public void setIpcPort(int ipcPort) {
/*  73 */     this.ipcPort = ipcPort;
/*     */   }
/*     */ 
/*     */   public void setStorageInfo(DataStorage storage) {
/*  77 */     this.storageInfo = new StorageInfo(storage);
/*  78 */     this.storageID = storage.getStorageID();
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/*  82 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public int getVersion()
/*     */   {
/*  88 */     return this.storageInfo.getLayoutVersion();
/*     */   }
/*     */ 
/*     */   public String getRegistrationID()
/*     */   {
/*  94 */     return Storage.getRegistrationID(this.storageInfo);
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  98 */     return getClass().getSimpleName() + "(" + this.name + ", storageID=" + this.storageID + ", infoPort=" + this.infoPort + ", ipcPort=" + this.ipcPort + ")";
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/* 110 */     super.write(out);
/*     */ 
/* 113 */     out.writeShort(this.ipcPort);
/*     */ 
/* 115 */     out.writeInt(this.storageInfo.getLayoutVersion());
/* 116 */     out.writeInt(this.storageInfo.getNamespaceID());
/* 117 */     out.writeLong(this.storageInfo.getCTime());
/* 118 */     this.exportedKeys.write(out);
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException
/*     */   {
/* 123 */     super.readFields(in);
/*     */ 
/* 126 */     this.ipcPort = (in.readShort() & 0xFFFF);
/*     */ 
/* 128 */     this.storageInfo.layoutVersion = in.readInt();
/* 129 */     this.storageInfo.namespaceID = in.readInt();
/* 130 */     this.storageInfo.cTime = in.readLong();
/* 131 */     this.exportedKeys.readFields(in);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  42 */     WritableFactories.setFactory(DatanodeRegistration.class, new WritableFactory()
/*     */     {
/*     */       public Writable newInstance() {
/*  45 */         return new DatanodeRegistration();
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.protocol.DatanodeRegistration
 * JD-Core Version:    0.6.1
 */
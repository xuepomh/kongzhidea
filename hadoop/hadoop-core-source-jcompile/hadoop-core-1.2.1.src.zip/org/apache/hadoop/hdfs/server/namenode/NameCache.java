/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ class NameCache<K>
/*     */ {
/*  65 */   static final Log LOG = LogFactory.getLog(NameCache.class.getName());
/*     */ 
/*  68 */   private boolean initialized = false;
/*     */   private final int useThreshold;
/*  74 */   private int lookups = 0;
/*     */ 
/*  77 */   final HashMap<K, K> cache = new HashMap();
/*     */ 
/*  80 */   Map<K, NameCache<K>.UseCount> transientMap = new HashMap();
/*     */ 
/*     */   NameCache(int useThreshold)
/*     */   {
/*  88 */     this.useThreshold = useThreshold;
/*     */   }
/*     */ 
/*     */   K put(K name)
/*     */   {
/*  99 */     Object internal = this.cache.get(name);
/* 100 */     if (internal != null) {
/* 101 */       this.lookups += 1;
/* 102 */       return internal;
/*     */     }
/*     */ 
/* 106 */     if (!this.initialized) {
/* 107 */       UseCount useCount = (UseCount)this.transientMap.get(name);
/* 108 */       if (useCount != null) {
/* 109 */         useCount.increment();
/* 110 */         if (useCount.get() >= this.useThreshold) {
/* 111 */           promote(name);
/*     */         }
/* 113 */         return useCount.value;
/*     */       }
/* 115 */       useCount = new UseCount(name);
/* 116 */       this.transientMap.put(name, useCount);
/*     */     }
/* 118 */     return null;
/*     */   }
/*     */ 
/*     */   int getLookupCount()
/*     */   {
/* 126 */     return this.lookups;
/*     */   }
/*     */ 
/*     */   int size()
/*     */   {
/* 134 */     return this.cache.size();
/*     */   }
/*     */ 
/*     */   void initialized()
/*     */   {
/* 143 */     LOG.info("initialized with " + size() + " entries " + this.lookups + " lookups");
/* 144 */     this.initialized = true;
/* 145 */     this.transientMap.clear();
/* 146 */     this.transientMap = null;
/*     */   }
/*     */ 
/*     */   private void promote(K name)
/*     */   {
/* 151 */     this.transientMap.remove(name);
/* 152 */     this.cache.put(name, name);
/* 153 */     this.lookups += this.useThreshold;
/*     */   }
/*     */ 
/*     */   public void reset() {
/* 157 */     this.initialized = false;
/* 158 */     this.cache.clear();
/* 159 */     if (this.transientMap == null)
/* 160 */       this.transientMap = new HashMap();
/*     */     else
/* 162 */       this.transientMap.clear();
/*     */   }
/*     */ 
/*     */   private class UseCount
/*     */   {
/*     */     int count;
/*     */     final K value;
/*     */ 
/*     */     UseCount()
/*     */     {
/*  52 */       this.count = 1;
/*  53 */       this.value = value;
/*     */     }
/*     */ 
/*     */     void increment() {
/*  57 */       this.count += 1;
/*     */     }
/*     */ 
/*     */     int get() {
/*  61 */       return this.count;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.NameCache
 * JD-Core Version:    0.6.1
 */
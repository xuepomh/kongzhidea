/*      */ package org.apache.hadoop.hdfs.server.namenode;
/*      */ 
/*      */ import java.io.BufferedWriter;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.Closeable;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileWriter;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.lang.management.ManagementFactory;
/*      */ import java.lang.management.ThreadMXBean;
/*      */ import java.net.InetAddress;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.EnumSet;
/*      */ import java.util.Formatter;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.NavigableMap;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ import java.util.TreeSet;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import javax.management.NotCompliantMBeanException;
/*      */ import javax.management.ObjectName;
/*      */ import javax.management.StandardMBean;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.apache.hadoop.conf.Configuration;
/*      */ import org.apache.hadoop.fs.ContentSummary;
/*      */ import org.apache.hadoop.fs.FileAlreadyExistsException;
/*      */ import org.apache.hadoop.fs.Path;
/*      */ import org.apache.hadoop.fs.permission.FsAction;
/*      */ import org.apache.hadoop.fs.permission.FsPermission;
/*      */ import org.apache.hadoop.fs.permission.PermissionStatus;
/*      */ import org.apache.hadoop.hdfs.DFSUtil;
/*      */ import org.apache.hadoop.hdfs.DFSUtil.StaleComparator;
/*      */ import org.apache.hadoop.hdfs.protocol.AlreadyBeingCreatedException;
/*      */ import org.apache.hadoop.hdfs.protocol.Block;
/*      */ import org.apache.hadoop.hdfs.protocol.BlockListAsLongs;
/*      */ import org.apache.hadoop.hdfs.protocol.DatanodeID;
/*      */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*      */ import org.apache.hadoop.hdfs.protocol.DirectoryListing;
/*      */ import org.apache.hadoop.hdfs.protocol.FSConstants;
/*      */ import org.apache.hadoop.hdfs.protocol.FSConstants.DatanodeReportType;
/*      */ import org.apache.hadoop.hdfs.protocol.FSConstants.SafeModeAction;
/*      */ import org.apache.hadoop.hdfs.protocol.FSConstants.UpgradeAction;
/*      */ import org.apache.hadoop.hdfs.protocol.HdfsFileStatus;
/*      */ import org.apache.hadoop.hdfs.protocol.LocatedBlock;
/*      */ import org.apache.hadoop.hdfs.protocol.LocatedBlocks;
/*      */ import org.apache.hadoop.hdfs.protocol.UnregisteredDatanodeException;
/*      */ import org.apache.hadoop.hdfs.security.token.block.BlockTokenSecretManager;
/*      */ import org.apache.hadoop.hdfs.security.token.block.BlockTokenSecretManager.AccessMode;
/*      */ import org.apache.hadoop.hdfs.security.token.block.ExportedBlockKeys;
/*      */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenIdentifier;
/*      */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenSecretManager;
/*      */ import org.apache.hadoop.hdfs.server.common.GenerationStamp;
/*      */ import org.apache.hadoop.hdfs.server.common.HdfsConstants.StartupOption;
/*      */ import org.apache.hadoop.hdfs.server.common.Storage;
/*      */ import org.apache.hadoop.hdfs.server.common.Storage.StorageDirectory;
/*      */ import org.apache.hadoop.hdfs.server.common.UpgradeStatusReport;
/*      */ import org.apache.hadoop.hdfs.server.namenode.metrics.FSNamesystemMBean;
/*      */ import org.apache.hadoop.hdfs.server.namenode.metrics.NameNodeInstrumentation;
/*      */ import org.apache.hadoop.hdfs.server.protocol.BalancerBandwidthCommand;
/*      */ import org.apache.hadoop.hdfs.server.protocol.BlocksWithLocations;
/*      */ import org.apache.hadoop.hdfs.server.protocol.BlocksWithLocations.BlockWithLocations;
/*      */ import org.apache.hadoop.hdfs.server.protocol.DatanodeCommand;
/*      */ import org.apache.hadoop.hdfs.server.protocol.DatanodeRegistration;
/*      */ import org.apache.hadoop.hdfs.server.protocol.DisallowedDatanodeException;
/*      */ import org.apache.hadoop.hdfs.server.protocol.KeyUpdateCommand;
/*      */ import org.apache.hadoop.hdfs.server.protocol.NamespaceInfo;
/*      */ import org.apache.hadoop.hdfs.server.protocol.UpgradeCommand;
/*      */ import org.apache.hadoop.io.IOUtils;
/*      */ import org.apache.hadoop.io.Text;
/*      */ import org.apache.hadoop.ipc.Server;
/*      */ import org.apache.hadoop.metrics2.MetricsBuilder;
/*      */ import org.apache.hadoop.metrics2.MetricsRecordBuilder;
/*      */ import org.apache.hadoop.metrics2.MetricsSource;
/*      */ import org.apache.hadoop.metrics2.MetricsSystem;
/*      */ import org.apache.hadoop.metrics2.lib.DefaultMetricsSystem;
/*      */ import org.apache.hadoop.metrics2.util.MBeans;
/*      */ import org.apache.hadoop.net.CachedDNSToSwitchMapping;
/*      */ import org.apache.hadoop.net.DNSToSwitchMapping;
/*      */ import org.apache.hadoop.net.NetworkTopology;
/*      */ import org.apache.hadoop.net.Node;
/*      */ import org.apache.hadoop.net.NodeBase;
/*      */ import org.apache.hadoop.net.ScriptBasedMapping;
/*      */ import org.apache.hadoop.security.AccessControlException;
/*      */ import org.apache.hadoop.security.UserGroupInformation;
/*      */ import org.apache.hadoop.security.UserGroupInformation.AuthenticationMethod;
/*      */ import org.apache.hadoop.security.token.SecretManager.InvalidToken;
/*      */ import org.apache.hadoop.security.token.Token;
/*      */ import org.apache.hadoop.security.token.delegation.DelegationKey;
/*      */ import org.apache.hadoop.util.Daemon;
/*      */ import org.apache.hadoop.util.HostsFileReader;
/*      */ import org.apache.hadoop.util.QueueProcessingStatistics;
/*      */ import org.apache.hadoop.util.ReflectionUtils;
/*      */ import org.apache.hadoop.util.StringUtils;
/*      */ import org.apache.hadoop.util.VersionInfo;
/*      */ import org.mortbay.util.ajax.JSON;
/*      */ 
/*      */ public class FSNamesystem
/*      */   implements FSConstants, FSNamesystemMBean, FSClusterStats, NameNodeMXBean, MetricsSource
/*      */ {
/*  148 */   public static final Log LOG = LogFactory.getLog(FSNamesystem.class);
/*      */   public static final String AUDIT_FORMAT = "ugi=%s\tip=%s\tcmd=%s\tsrc=%s\tdst=%s\tperm=%s";
/*  157 */   private static final ThreadLocal<Formatter> auditFormatter = new ThreadLocal()
/*      */   {
/*      */     protected Formatter initialValue() {
/*  160 */       return new Formatter(new StringBuilder("ugi=%s\tip=%s\tcmd=%s\tsrc=%s\tdst=%s\tperm=%s".length() * 4));
/*      */     }
/*  157 */   };
/*      */ 
/*  178 */   public static final Log auditLog = LogFactory.getLog(new StringBuilder().append(FSNamesystem.class.getName()).append(".audit").toString());
/*      */   public static final int DEFAULT_INITIAL_MAP_CAPACITY = 16;
/*      */   public static final float DEFAULT_MAP_LOAD_FACTOR = 0.75F;
/*  184 */   static int BLOCK_DELETION_INCREMENT = 1000;
/*      */   private float blocksInvalidateWorkPct;
/*      */   private int blocksReplWorkMultiplier;
/*      */   private boolean isPermissionEnabled;
/*      */   private boolean persistBlocks;
/*      */   private UserGroupInformation fsOwner;
/*      */   private String fsOwnerShortUserName;
/*      */   private String supergroup;
/*      */   private PermissionStatus defaultPermission;
/*  196 */   private long capacityTotal = 0L; private long capacityUsed = 0L; private long capacityRemaining = 0L;
/*  197 */   private int totalLoad = 0;
/*      */   boolean isAccessTokenEnabled;
/*      */   BlockTokenSecretManager accessTokenHandler;
/*      */   private long accessKeyUpdateInterval;
/*      */   private long accessTokenLifetime;
/*  204 */   private static final long DELEGATION_TOKEN_REMOVER_SCAN_INTERVAL = TimeUnit.MILLISECONDS.convert(1L, TimeUnit.HOURS);
/*      */   private DelegationTokenSecretManager dtSecretManager;
/*  208 */   volatile long pendingReplicationBlocksCount = 0L;
/*  209 */   volatile long corruptReplicaBlocksCount = 0L;
/*  210 */   volatile long underReplicatedBlocksCount = 0L;
/*  211 */   volatile long scheduledReplicationBlocksCount = 0L;
/*  212 */   volatile long excessBlocksCount = 0L;
/*  213 */   volatile long pendingDeletionBlocksCount = 0L;
/*      */   public FSDirectory dir;
/*  223 */   final BlocksMap blocksMap = new BlocksMap(16, 0.75F);
/*      */ 
/*  229 */   public CorruptReplicasMap corruptReplicas = new CorruptReplicasMap();
/*      */ 
/*  252 */   NavigableMap<String, DatanodeDescriptor> datanodeMap = new TreeMap();
/*      */ 
/*  261 */   private Map<String, Collection<Block>> recentInvalidateSets = new TreeMap();
/*      */ 
/*  270 */   Map<String, Collection<Block>> excessReplicateMap = new TreeMap();
/*      */ 
/*  273 */   Random r = new Random();
/*      */ 
/*  282 */   ArrayList<DatanodeDescriptor> heartbeats = new ArrayList();
/*      */ 
/*  288 */   private UnderReplicatedBlocks neededReplications = new UnderReplicatedBlocks();
/*      */   PendingReplicationBlocks pendingReplications;
/*  292 */   public LeaseManager leaseManager = new LeaseManager(this);
/*      */ 
/*  298 */   Daemon hbthread = null;
/*  299 */   public Daemon lmthread = null;
/*  300 */   Daemon smmthread = null;
/*  301 */   public Daemon replthread = null;
/*  302 */   private ReplicationMonitor replmon = null;
/*      */ 
/*  304 */   private volatile boolean fsRunning = true;
/*  305 */   long systemStart = 0L;
/*      */   private int maxReplication;
/*      */   private int maxReplicationStreams;
/*      */   private int minReplication;
/*      */   private int defaultReplication;
/*  316 */   private volatile boolean stallReplicationWork = false;
/*      */   private long heartbeatRecheckInterval;
/*      */   private long heartbeatExpireInterval;
/*      */   private long replicationRecheckInterval;
/*  325 */   private long defaultBlockSize = 0L;
/*      */ 
/*  327 */   private boolean allowBrokenAppend = false;
/*      */ 
/*  329 */   private boolean durableSync = true;
/*      */   int maxCorruptFilesReturned;
/*  336 */   private int replIndex = 0;
/*  337 */   private long missingBlocksInCurIter = 0L;
/*  338 */   private long missingBlocksInPrevIter = 0L;
/*      */   public static FSNamesystem fsNamesystemObject;
/*  342 */   private InetSocketAddress nameNodeAddress = null;
/*      */   private SafeModeInfo safeMode;
/*  344 */   private Host2NodesMap host2DataNodeMap = new Host2NodesMap();
/*      */   NetworkTopology clusterMap;
/*      */   private DNSToSwitchMapping dnsToSwitchMapping;
/*      */   BlockPlacementPolicy replicator;
/*      */   private HostsFileReader hostsReader;
/*  354 */   private Daemon dnthread = null;
/*      */ 
/*  356 */   private long maxFsObjects = 0L;
/*      */ 
/*  361 */   private final GenerationStamp generationStamp = new GenerationStamp();
/*      */ 
/*  364 */   int blockInvalidateLimit = 100;
/*      */ 
/*  367 */   private long accessTimePrecision = 0L;
/*      */   private String nameNodeHostName;
/*      */   private long staleInterval;
/*      */   private boolean avoidStaleDataNodesForRead;
/*      */   private boolean avoidStaleDataNodesForWrite;
/*      */   private float ratioUseStaleDataNodesForWrite;
/*  388 */   private volatile int numStaleNodes = 0;
/*      */ 
/* 2087 */   static Random randBlockId = new Random();
/*      */ 
/* 5666 */   UpgradeManagerNamenode upgradeManager = new UpgradeManagerNamenode();
/*      */   private ObjectName mbeanName;
/* 5822 */   private ObjectName mxBean = null;
/*      */ 
/*      */   private static final void logAuditEvent(UserGroupInformation ugi, InetAddress addr, String cmd, String src, String dst, HdfsFileStatus stat)
/*      */   {
/*  167 */     Formatter fmt = (Formatter)auditFormatter.get();
/*  168 */     ((StringBuilder)fmt.out()).setLength(0);
/*  169 */     auditLog.info(fmt.format("ugi=%s\tip=%s\tcmd=%s\tsrc=%s\tdst=%s\tperm=%s", new Object[] { ugi, addr, cmd, src, dst, stat == null ? null : new StringBuilder().append(stat.getOwner()).append(':').append(stat.getGroup()).append(':').append(stat.getPermission()).toString() }).toString());
/*      */   }
/*      */ 
/*      */   FSNamesystem(NameNode nn, Configuration conf)
/*      */     throws IOException
/*      */   {
/*      */     try
/*      */     {
/*  395 */       initialize(nn, conf);
/*      */     } catch (IOException e) {
/*  397 */       LOG.error(new StringBuilder().append(getClass().getSimpleName()).append(" initialization failed.").toString(), e);
/*  398 */       close();
/*  399 */       shutdown();
/*  400 */       throw e;
/*      */     } catch (RuntimeException e) {
/*  402 */       LOG.error(new StringBuilder().append(getClass().getSimpleName()).append(" initialization failed.").toString(), e);
/*  403 */       close();
/*  404 */       shutdown();
/*  405 */       throw e;
/*      */     }
/*      */   }
/*      */ 
/*      */   void activateSecretManager() throws IOException {
/*  410 */     if (this.dtSecretManager != null)
/*  411 */       this.dtSecretManager.startThreads();
/*      */   }
/*      */ 
/*      */   private void initialize(NameNode nn, Configuration conf)
/*      */     throws IOException
/*      */   {
/*  419 */     this.systemStart = now();
/*  420 */     setConfigurationParameters(conf);
/*  421 */     this.dtSecretManager = createDelegationTokenSecretManager(conf);
/*      */ 
/*  423 */     this.nameNodeAddress = nn.getNameNodeAddress();
/*  424 */     registerMBean(conf);
/*  425 */     this.dir = new FSDirectory(this, conf);
/*  426 */     HdfsConstants.StartupOption startOpt = NameNode.getStartupOption(conf);
/*  427 */     this.dir.loadFSImage(getNamespaceDirs(conf), getNamespaceEditsDirs(conf), startOpt);
/*      */ 
/*  429 */     long timeTakenToLoadFSImage = now() - this.systemStart;
/*  430 */     LOG.info(new StringBuilder().append("Finished loading FSImage in ").append(timeTakenToLoadFSImage).append(" msecs").toString());
/*  431 */     NameNode.getNameNodeMetrics().setFsImageLoadTime(timeTakenToLoadFSImage);
/*  432 */     this.safeMode = new SafeModeInfo(conf);
/*  433 */     setBlockTotal();
/*  434 */     this.pendingReplications = new PendingReplicationBlocks(conf.getInt("dfs.replication.pending.timeout.sec", -1) * 1000L);
/*      */ 
/*  437 */     if (this.isAccessTokenEnabled) {
/*  438 */       this.accessTokenHandler = new BlockTokenSecretManager(true, this.accessKeyUpdateInterval, this.accessTokenLifetime);
/*      */     }
/*      */ 
/*  441 */     this.hbthread = new Daemon(new HeartbeatMonitor());
/*      */     LeaseManager tmp218_215 = this.leaseManager; tmp218_215.getClass(); this.lmthread = new Daemon(new LeaseManager.Monitor(tmp218_215));
/*  443 */     this.replmon = new ReplicationMonitor();
/*  444 */     this.replthread = new Daemon(this.replmon);
/*  445 */     this.hbthread.start();
/*  446 */     this.lmthread.start();
/*  447 */     this.replthread.start();
/*      */ 
/*  449 */     this.hostsReader = new HostsFileReader(conf.get("dfs.hosts", ""), conf.get("dfs.hosts.exclude", ""));
/*      */     void tmp324_321 = new DecommissionManager(this); tmp324_321.getClass(); this.dnthread = new Daemon(new DecommissionManager.Monitor(tmp324_321, conf.getInt("dfs.namenode.decommission.interval", 30), conf.getInt("dfs.namenode.decommission.nodes.per.interval", 5)));
/*      */ 
/*  454 */     this.dnthread.start();
/*      */ 
/*  456 */     this.dnsToSwitchMapping = ((DNSToSwitchMapping)ReflectionUtils.newInstance(conf.getClass("topology.node.switch.mapping.impl", ScriptBasedMapping.class, DNSToSwitchMapping.class), conf));
/*      */ 
/*  465 */     if ((this.dnsToSwitchMapping instanceof CachedDNSToSwitchMapping)) {
/*  466 */       this.dnsToSwitchMapping.resolve(new ArrayList(this.hostsReader.getHosts()));
/*      */     }
/*      */ 
/*  469 */     InetSocketAddress socAddr = NameNode.getAddress(conf);
/*  470 */     this.nameNodeHostName = socAddr.getHostName();
/*      */ 
/*  472 */     registerWith(DefaultMetricsSystem.INSTANCE);
/*      */   }
/*      */ 
/*      */   public static Collection<File> getNamespaceDirs(Configuration conf) {
/*  476 */     Collection dirNames = conf.getStringCollection("dfs.name.dir");
/*  477 */     if (dirNames.isEmpty())
/*  478 */       dirNames.add("/tmp/hadoop/dfs/name");
/*  479 */     Collection dirs = new ArrayList(dirNames.size());
/*  480 */     for (String name : dirNames) {
/*  481 */       dirs.add(new File(name));
/*      */     }
/*  483 */     return dirs;
/*      */   }
/*      */ 
/*      */   public static Collection<File> getNamespaceEditsDirs(Configuration conf) {
/*  487 */     Collection editsDirNames = conf.getStringCollection("dfs.name.edits.dir");
/*      */ 
/*  489 */     if (editsDirNames.isEmpty())
/*  490 */       editsDirNames.add("/tmp/hadoop/dfs/name");
/*  491 */     Collection dirs = new ArrayList(editsDirNames.size());
/*  492 */     for (String name : editsDirNames) {
/*  493 */       dirs.add(new File(name));
/*      */     }
/*  495 */     return dirs;
/*      */   }
/*      */ 
/*      */   FSNamesystem(FSImage fsImage, Configuration conf)
/*      */     throws IOException
/*      */   {
/*  503 */     setConfigurationParameters(conf);
/*  504 */     this.dir = new FSDirectory(fsImage, this, conf);
/*  505 */     this.dtSecretManager = createDelegationTokenSecretManager(conf);
/*      */   }
/*      */ 
/*      */   private void setConfigurationParameters(Configuration conf)
/*      */     throws IOException
/*      */   {
/*  513 */     fsNamesystemObject = this;
/*  514 */     this.fsOwner = UserGroupInformation.getCurrentUser();
/*  515 */     this.fsOwnerShortUserName = this.fsOwner.getShortUserName();
/*  516 */     LOG.info(new StringBuilder().append("fsOwner=").append(this.fsOwner).toString());
/*      */ 
/*  518 */     this.supergroup = conf.get("dfs.permissions.supergroup", "supergroup");
/*  519 */     this.isPermissionEnabled = conf.getBoolean("dfs.permissions", true);
/*  520 */     LOG.info(new StringBuilder().append("supergroup=").append(this.supergroup).toString());
/*  521 */     LOG.info(new StringBuilder().append("isPermissionEnabled=").append(this.isPermissionEnabled).toString());
/*      */ 
/*  523 */     this.persistBlocks = conf.getBoolean("dfs.persist.blocks", false);
/*      */ 
/*  526 */     short filePermission = (short)conf.getInt("dfs.upgrade.permission", 511);
/*  527 */     this.defaultPermission = PermissionStatus.createImmutable(this.fsOwnerShortUserName, this.supergroup, new FsPermission(filePermission));
/*      */ 
/*  530 */     this.blocksInvalidateWorkPct = DFSUtil.getInvalidateWorkPctPerIteration(conf);
/*      */ 
/*  533 */     this.blocksReplWorkMultiplier = DFSUtil.getReplWorkMultiplier(conf);
/*  534 */     this.clusterMap = NetworkTopology.getInstance(conf);
/*      */ 
/*  536 */     this.maxCorruptFilesReturned = conf.getInt("dfs.corruptfilesreturned.max", 500);
/*      */ 
/*  539 */     this.replicator = BlockPlacementPolicy.getInstance(conf, this, this.clusterMap);
/*  540 */     this.defaultReplication = conf.getInt("dfs.replication", 3);
/*  541 */     this.maxReplication = conf.getInt("dfs.replication.max", 512);
/*  542 */     this.minReplication = conf.getInt("dfs.replication.min", 1);
/*  543 */     if (this.minReplication <= 0) {
/*  544 */       throw new IOException(new StringBuilder().append("Unexpected configuration parameters: dfs.replication.min = ").append(this.minReplication).append(" must be greater than 0").toString());
/*      */     }
/*      */ 
/*  548 */     if (this.maxReplication >= 32767) {
/*  549 */       throw new IOException(new StringBuilder().append("Unexpected configuration parameters: dfs.replication.max = ").append(this.maxReplication).append(" must be less than ").append(32767).toString());
/*      */     }
/*      */ 
/*  552 */     if (this.maxReplication < this.minReplication) {
/*  553 */       throw new IOException(new StringBuilder().append("Unexpected configuration parameters: dfs.replication.min = ").append(this.minReplication).append(" must be less than dfs.replication.max = ").append(this.maxReplication).toString());
/*      */     }
/*      */ 
/*  558 */     this.maxReplicationStreams = conf.getInt("dfs.max-repl-streams", 2);
/*  559 */     long heartbeatInterval = conf.getLong("dfs.heartbeat.interval", 3L) * 1000L;
/*  560 */     this.heartbeatRecheckInterval = conf.getInt("heartbeat.recheck.interval", 300000);
/*      */ 
/*  562 */     this.heartbeatExpireInterval = (2L * this.heartbeatRecheckInterval + 10L * heartbeatInterval);
/*      */ 
/*  564 */     this.replicationRecheckInterval = (conf.getInt("dfs.replication.interval", 3) * 1000L);
/*      */ 
/*  566 */     this.defaultBlockSize = conf.getLong("dfs.block.size", 67108864L);
/*  567 */     this.maxFsObjects = conf.getLong("dfs.max.objects", 0L);
/*      */ 
/*  570 */     this.blockInvalidateLimit = Math.max(this.blockInvalidateLimit, 20 * (int)(heartbeatInterval / 1000L));
/*      */ 
/*  573 */     this.blockInvalidateLimit = conf.getInt("dfs.block.invalidate.limit", this.blockInvalidateLimit);
/*      */ 
/*  575 */     LOG.info(new StringBuilder().append("dfs.block.invalidate.limit=").append(this.blockInvalidateLimit).toString());
/*      */ 
/*  577 */     this.accessTimePrecision = conf.getLong("dfs.access.time.precision", 0L);
/*  578 */     this.allowBrokenAppend = conf.getBoolean("dfs.support.broken.append", false);
/*  579 */     if (conf.getBoolean("dfs.support.append", false)) {
/*  580 */       LOG.warn("The dfs.support.append option is in your configuration, however append is not supported. This configuration option is no longer required to enable sync");
/*      */     }
/*      */ 
/*  584 */     this.durableSync = conf.getBoolean("dfs.durable.sync", true);
/*  585 */     if (!this.durableSync) {
/*  586 */       LOG.warn("Durable sync disabled. Beware data loss when running programs like HBase that require durable sync!");
/*      */     }
/*      */ 
/*  589 */     this.isAccessTokenEnabled = conf.getBoolean("dfs.block.access.token.enable", false);
/*      */ 
/*  591 */     if (this.isAccessTokenEnabled) {
/*  592 */       this.accessKeyUpdateInterval = (conf.getLong("dfs.block.access.key.update.interval", 600L) * 60L * 1000L);
/*      */ 
/*  594 */       this.accessTokenLifetime = (conf.getLong("dfs.block.access.token.lifetime", 600L) * 60L * 1000L);
/*      */     }
/*      */ 
/*  597 */     LOG.info(new StringBuilder().append("isAccessTokenEnabled=").append(this.isAccessTokenEnabled).append(" accessKeyUpdateInterval=").append(this.accessKeyUpdateInterval / 60000L).append(" min(s), accessTokenLifetime=").append(this.accessTokenLifetime / 60000L).append(" min(s)").toString());
/*      */ 
/*  603 */     this.avoidStaleDataNodesForRead = conf.getBoolean("dfs.namenode.avoid.read.stale.datanode", false);
/*      */ 
/*  606 */     this.avoidStaleDataNodesForWrite = conf.getBoolean("dfs.namenode.avoid.write.stale.datanode", false);
/*      */ 
/*  609 */     this.staleInterval = getStaleIntervalFromConf(conf, this.heartbeatExpireInterval);
/*  610 */     this.ratioUseStaleDataNodesForWrite = getRatioUseStaleNodesForWriteFromConf(conf);
/*      */ 
/*  613 */     if ((this.avoidStaleDataNodesForWrite) && (this.staleInterval < this.heartbeatRecheckInterval)) {
/*  614 */       this.heartbeatRecheckInterval = this.staleInterval;
/*  615 */       LOG.info(new StringBuilder().append("Setting heartbeat recheck interval to ").append(this.staleInterval).append(" since ").append("dfs.namenode.stale.datanode.interval").append(" is less than ").append("dfs.namenode.heartbeat.recheck-interval").toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   private static float getRatioUseStaleNodesForWriteFromConf(Configuration conf)
/*      */   {
/*  623 */     float ratioUseStaleDataNodesForWrite = conf.getFloat("dfs.namenode.write.stale.datanode.ratio", 0.5F);
/*      */ 
/*  626 */     if ((ratioUseStaleDataNodesForWrite > 0.0F) && (ratioUseStaleDataNodesForWrite <= 1.0F))
/*      */     {
/*  628 */       return ratioUseStaleDataNodesForWrite;
/*      */     }
/*  630 */     throw new IllegalArgumentException(new StringBuilder().append("dfs.namenode.write.stale.datanode.ratio = '").append(ratioUseStaleDataNodesForWrite).append("' is invalid. It should be a positive non-zero float value,").append(" not greater than 1.0f").toString());
/*      */   }
/*      */ 
/*      */   private static long getStaleIntervalFromConf(Configuration conf, long heartbeatExpireInterval)
/*      */   {
/*  640 */     long staleInterval = conf.getLong("dfs.namenode.stale.datanode.interval", 30000L);
/*      */ 
/*  643 */     if (staleInterval <= 0L) {
/*  644 */       throw new IllegalArgumentException(new StringBuilder().append("dfs.namenode.stale.datanode.interval = '").append(staleInterval).append("' is invalid. It should be a positive non-zero value").toString());
/*      */     }
/*      */ 
/*  649 */     long heartbeatIntervalSeconds = conf.getLong("dfs.heartbeat.interval", 3L);
/*      */ 
/*  654 */     long minStaleInterval = conf.getInt("dfs.namenode.stale.datanode.minimum.interval", 3) * heartbeatIntervalSeconds * 1000L;
/*      */ 
/*  658 */     if (staleInterval < minStaleInterval) {
/*  659 */       LOG.warn(new StringBuilder().append("The given interval for marking stale datanode = ").append(staleInterval).append(", which is less than ").append(3).append(" heartbeat intervals. This may cause too frequent changes of ").append("stale states of DataNodes since a heartbeat msg may be missing ").append("due to temporary short-term failures. Reset stale interval to ").append(minStaleInterval).toString());
/*      */ 
/*  666 */       staleInterval = minStaleInterval;
/*      */     }
/*  668 */     if (staleInterval > heartbeatExpireInterval) {
/*  669 */       LOG.warn(new StringBuilder().append("The given interval for marking stale datanode = ").append(staleInterval).append(", which is larger than heartbeat expire interval ").append(heartbeatExpireInterval).toString());
/*      */     }
/*      */ 
/*  673 */     return staleInterval;
/*      */   }
/*      */ 
/*      */   protected PermissionStatus getUpgradePermission()
/*      */   {
/*  681 */     return this.defaultPermission;
/*      */   }
/*      */ 
/*      */   public static FSNamesystem getFSNamesystem()
/*      */   {
/*  688 */     return fsNamesystemObject;
/*      */   }
/*      */ 
/*      */   synchronized NamespaceInfo getNamespaceInfo() {
/*  692 */     return new NamespaceInfo(this.dir.fsImage.getNamespaceID(), this.dir.fsImage.getCTime(), getDistributedUpgradeVersion());
/*      */   }
/*      */ 
/*      */   public void close()
/*      */   {
/*  703 */     this.fsRunning = false;
/*      */     try {
/*  705 */       if (this.pendingReplications != null) this.pendingReplications.stop();
/*  706 */       if (this.hbthread != null) this.hbthread.interrupt();
/*  707 */       if (this.replthread != null) this.replthread.interrupt();
/*  708 */       if (this.dnthread != null) this.dnthread.interrupt();
/*  709 */       if (this.smmthread != null) this.smmthread.interrupt();
/*  710 */       if (this.dtSecretManager != null) this.dtSecretManager.stopThreads(); 
/*      */     }
/*  712 */     catch (Exception e) { LOG.warn("Exception shutting down FSNamesystem", e);
/*      */     } finally
/*      */     {
/*      */       try {
/*  716 */         if (this.lmthread != null) {
/*  717 */           this.lmthread.interrupt();
/*  718 */           this.lmthread.join(3000L);
/*      */         }
/*  720 */         this.dir.close();
/*  721 */         this.blocksMap.close();
/*      */       } catch (InterruptedException ie) {
/*      */       } catch (IOException ie) {
/*  724 */         LOG.error("Error closing FSDirectory", ie);
/*  725 */         IOUtils.cleanup(LOG, new Closeable[] { this.dir });
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   boolean isRunning()
/*      */   {
/*  732 */     return this.fsRunning;
/*      */   }
/*      */ 
/*      */   void metaSave(String filename)
/*      */     throws IOException
/*      */   {
/*  739 */     checkSuperuserPrivilege();
/*  740 */     synchronized (this) {
/*  741 */       File file = new File(System.getProperty("hadoop.log.dir"), filename);
/*  742 */       PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(file, true)));
/*      */ 
/*  745 */       long totalInodes = this.dir.totalInodes();
/*  746 */       long totalBlocks = getBlocksTotal();
/*      */ 
/*  748 */       ArrayList live = new ArrayList();
/*  749 */       ArrayList dead = new ArrayList();
/*  750 */       DFSNodesStatus(live, dead);
/*      */ 
/*  752 */       String str = new StringBuilder().append(totalInodes).append(" files and directories, ").append(totalBlocks).append(" blocks = ").append(totalInodes + totalBlocks).append(" total").toString();
/*      */ 
/*  754 */       out.println(str);
/*  755 */       out.println(new StringBuilder().append("Live Datanodes: ").append(live.size()).toString());
/*  756 */       out.println(new StringBuilder().append("Dead Datanodes: ").append(dead.size()).toString());
/*      */ 
/*  761 */       synchronized (this.neededReplications) {
/*  762 */         out.println(new StringBuilder().append("Metasave: Blocks waiting for replication: ").append(this.neededReplications.size()).toString());
/*      */ 
/*  764 */         for (Block block : this.neededReplications) {
/*  765 */           List containingNodes = new ArrayList();
/*  766 */           NumberReplicas numReplicas = new NumberReplicas();
/*      */ 
/*  768 */           chooseSourceDatanode(block, containingNodes, numReplicas);
/*  769 */           int usableReplicas = numReplicas.liveReplicas() + numReplicas.decommissionedReplicas();
/*      */ 
/*  772 */           if ((block instanceof BlocksMap.BlockInfo)) {
/*  773 */             String fileName = FSDirectory.getFullPathName(((BlocksMap.BlockInfo)block).getINode());
/*      */ 
/*  775 */             out.print(new StringBuilder().append(fileName).append(": ").toString());
/*      */           }
/*      */ 
/*  779 */           out.print(new StringBuilder().append(block).append(usableReplicas > 0 ? "" : " MISSING").append(" (replicas:").append(" l: ").append(numReplicas.liveReplicas()).append(" d: ").append(numReplicas.decommissionedReplicas()).append(" c: ").append(numReplicas.corruptReplicas()).append(" e: ").append(numReplicas.excessReplicas()).append(") ").toString());
/*      */ 
/*  785 */           Collection corruptNodes = this.corruptReplicas.getNodes(block);
/*      */ 
/*  788 */           Iterator jt = this.blocksMap.nodeIterator(block);
/*  789 */           while (jt.hasNext()) {
/*  790 */             DatanodeDescriptor node = (DatanodeDescriptor)jt.next();
/*  791 */             String state = "";
/*  792 */             if ((corruptNodes != null) && (corruptNodes.contains(node)))
/*  793 */               state = "(corrupt)";
/*  794 */             else if ((node.isDecommissioned()) || (node.isDecommissionInProgress()))
/*      */             {
/*  796 */               state = "(decommissioned)";
/*      */             }
/*  798 */             out.print(new StringBuilder().append(" ").append(node).append(state).append(" : ").toString());
/*      */           }
/*  800 */           out.println("");
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  807 */       this.pendingReplications.metaSave(out);
/*      */ 
/*  812 */       dumpRecentInvalidateSets(out);
/*      */ 
/*  817 */       datanodeDump(out);
/*      */ 
/*  819 */       out.flush();
/*  820 */       out.close();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setBalancerBandwidth(long bandwidth)
/*      */     throws IOException
/*      */   {
/*  839 */     checkSuperuserPrivilege();
/*  840 */     synchronized (this.datanodeMap) {
/*  841 */       for (DatanodeDescriptor nodeInfo : this.datanodeMap.values())
/*  842 */         nodeInfo.setBalancerBandwidth(bandwidth);
/*      */     }
/*      */   }
/*      */ 
/*      */   long getDefaultBlockSize()
/*      */   {
/*  848 */     return this.defaultBlockSize;
/*      */   }
/*      */ 
/*      */   long getAccessTimePrecision() {
/*  852 */     return this.accessTimePrecision;
/*      */   }
/*      */ 
/*      */   private boolean isAccessTimeSupported() {
/*  856 */     return this.accessTimePrecision > 0L;
/*      */   }
/*      */ 
/*      */   private int getReplication(Block block)
/*      */   {
/*  861 */     INodeFile fileINode = this.blocksMap.getINode(block);
/*  862 */     if (fileINode == null) {
/*  863 */       return 0;
/*      */     }
/*  865 */     assert (!fileINode.isDirectory()) : "Block cannot belong to a directory";
/*  866 */     return fileINode.getReplication();
/*      */   }
/*      */ 
/*      */   synchronized void updateNeededReplications(Block block, int curReplicasDelta, int expectedReplicasDelta)
/*      */   {
/*  872 */     NumberReplicas repl = countNodes(block);
/*  873 */     int curExpectedReplicas = getReplication(block);
/*  874 */     this.neededReplications.update(block, repl.liveReplicas(), repl.decommissionedReplicas(), curExpectedReplicas, curReplicasDelta, expectedReplicasDelta);
/*      */   }
/*      */ 
/*      */   BlocksWithLocations getBlocks(DatanodeID datanode, long size)
/*      */     throws IOException
/*      */   {
/*  895 */     checkSuperuserPrivilege();
/*      */ 
/*  897 */     synchronized (this) {
/*  898 */       DatanodeDescriptor node = getDatanode(datanode);
/*  899 */       if (node == null) {
/*  900 */         NameNode.stateChangeLog.warn(new StringBuilder().append("BLOCK* NameSystem.getBlocks: Asking for blocks from an unrecorded node ").append(datanode.getName()).toString());
/*      */ 
/*  904 */         throw new IllegalArgumentException(new StringBuilder().append("Unexpected exception.  Got getBlocks message for datanode ").append(datanode.getName()).append(", but there is no info for it").toString());
/*      */       }
/*      */ 
/*  909 */       int numBlocks = node.numBlocks();
/*  910 */       if (numBlocks == 0) {
/*  911 */         return new BlocksWithLocations(new BlocksWithLocations.BlockWithLocations[0]);
/*      */       }
/*  913 */       Iterator iter = node.getBlockIterator();
/*  914 */       int startBlock = this.r.nextInt(numBlocks);
/*      */ 
/*  916 */       for (int i = 0; i < startBlock; i++) {
/*  917 */         iter.next();
/*      */       }
/*  919 */       List results = new ArrayList();
/*  920 */       long totalSize = 0L;
/*  921 */       while ((totalSize < size) && (iter.hasNext())) {
/*  922 */         totalSize += addBlock((Block)iter.next(), results);
/*      */       }
/*  924 */       if (totalSize < size) {
/*  925 */         iter = node.getBlockIterator();
/*  926 */         for (int i = 0; (i < startBlock) && (totalSize < size); i++) {
/*  927 */           totalSize += addBlock((Block)iter.next(), results);
/*      */         }
/*      */       }
/*      */ 
/*  931 */       return new BlocksWithLocations((BlocksWithLocations.BlockWithLocations[])results.toArray(new BlocksWithLocations.BlockWithLocations[results.size()]));
/*      */     }
/*      */   }
/*      */ 
/*      */   ExportedBlockKeys getBlockKeys()
/*      */   {
/*  942 */     return this.isAccessTokenEnabled ? this.accessTokenHandler.exportKeys() : ExportedBlockKeys.DUMMY_KEYS;
/*      */   }
/*      */ 
/*      */   private long addBlock(Block block, List<BlocksWithLocations.BlockWithLocations> results)
/*      */   {
/*  951 */     ArrayList machineSet = new ArrayList(this.blocksMap.numNodes(block));
/*      */ 
/*  953 */     Iterator it = this.blocksMap.nodeIterator(block);
/*  954 */     while (it.hasNext()) {
/*  955 */       String storageID = ((DatanodeDescriptor)it.next()).getStorageID();
/*      */ 
/*  957 */       Collection blocks = (Collection)this.recentInvalidateSets.get(storageID);
/*  958 */       if ((blocks == null) || (!blocks.contains(block))) {
/*  959 */         machineSet.add(storageID);
/*      */       }
/*      */     }
/*  962 */     if (machineSet.size() == 0) {
/*  963 */       return 0L;
/*      */     }
/*  965 */     results.add(new BlocksWithLocations.BlockWithLocations(block, (String[])machineSet.toArray(new String[machineSet.size()])));
/*      */ 
/*  967 */     return block.getNumBytes();
/*      */   }
/*      */ 
/*      */   public void setPermission(String src, FsPermission permission)
/*      */     throws IOException
/*      */   {
/*  982 */     FSPermissionChecker pc = new FSPermissionChecker(this.fsOwnerShortUserName, this.supergroup);
/*      */ 
/*  984 */     synchronized (this) {
/*  985 */       if (isInSafeMode())
/*  986 */         throw new SafeModeException(new StringBuilder().append("Cannot set permission for ").append(src).toString(), this.safeMode);
/*  987 */       checkOwner(pc, src);
/*  988 */       this.dir.setPermission(src, permission);
/*      */     }
/*  990 */     getEditLog().logSync();
/*  991 */     if ((auditLog.isInfoEnabled()) && (isExternalInvocation())) {
/*  992 */       HdfsFileStatus stat = this.dir.getFileInfo(src);
/*  993 */       logAuditEvent(UserGroupInformation.getCurrentUser(), Server.getRemoteIp(), "setPermission", src, null, stat);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setOwner(String src, String username, String group)
/*      */     throws IOException
/*      */   {
/* 1005 */     FSPermissionChecker pc = new FSPermissionChecker(this.fsOwnerShortUserName, this.supergroup);
/*      */ 
/* 1007 */     synchronized (this) {
/* 1008 */       if (isInSafeMode())
/* 1009 */         throw new SafeModeException(new StringBuilder().append("Cannot set owner for ").append(src).toString(), this.safeMode);
/* 1010 */       checkOwner(pc, src);
/* 1011 */       if (!pc.isSuperUser()) {
/* 1012 */         if ((username != null) && (!pc.getUser().equals(username))) {
/* 1013 */           throw new AccessControlException("Non-super user cannot change owner");
/*      */         }
/* 1015 */         if ((group != null) && (!pc.containsGroup(group))) {
/* 1016 */           throw new AccessControlException(new StringBuilder().append("User does not belong to ").append(group).toString());
/*      */         }
/*      */       }
/* 1019 */       this.dir.setOwner(src, username, group);
/*      */     }
/* 1021 */     getEditLog().logSync();
/* 1022 */     if ((auditLog.isInfoEnabled()) && (isExternalInvocation())) {
/* 1023 */       HdfsFileStatus stat = this.dir.getFileInfo(src);
/* 1024 */       logAuditEvent(UserGroupInformation.getCurrentUser(), Server.getRemoteIp(), "setOwner", src, null, stat);
/*      */     }
/*      */   }
/*      */ 
/*      */   LocatedBlocks getBlockLocations(String clientMachine, String src, long offset, long length)
/*      */     throws IOException
/*      */   {
/* 1037 */     LocatedBlocks blocks = getBlockLocations(src, offset, length, true, true, true);
/*      */     Node client;
/*      */     DFSUtil.StaleComparator comparator;
/* 1039 */     if (blocks != null)
/*      */     {
/* 1045 */       client = this.host2DataNodeMap.getDatanodeByHost(clientMachine);
/*      */ 
/* 1047 */       if (client == null) {
/* 1048 */         List hosts = new ArrayList(1);
/* 1049 */         hosts.add(clientMachine);
/* 1050 */         String rName = (String)this.dnsToSwitchMapping.resolve(hosts).get(0);
/* 1051 */         if (rName != null) {
/* 1052 */           client = new NodeBase(clientMachine, rName);
/*      */         }
/*      */       }
/* 1055 */       comparator = null;
/* 1056 */       if (this.avoidStaleDataNodesForRead) {
/* 1057 */         comparator = new DFSUtil.StaleComparator(this.staleInterval);
/*      */       }
/*      */ 
/* 1060 */       for (LocatedBlock b : blocks.getLocatedBlocks()) {
/* 1061 */         this.clusterMap.pseudoSortByDistance(client, b.getLocations());
/* 1062 */         if (this.avoidStaleDataNodesForRead) {
/* 1063 */           Arrays.sort(b.getLocations(), comparator);
/*      */         }
/*      */       }
/*      */     }
/* 1067 */     return blocks;
/*      */   }
/*      */ 
/*      */   public LocatedBlocks getBlockLocations(String src, long offset, long length)
/*      */     throws IOException
/*      */   {
/* 1076 */     return getBlockLocations(src, offset, length, false, true, true);
/*      */   }
/*      */ 
/*      */   public LocatedBlocks getBlockLocations(String src, long offset, long length, boolean doAccessTime, boolean needBlockToken, boolean checkSafeMode)
/*      */     throws IOException
/*      */   {
/* 1086 */     if (this.isPermissionEnabled) {
/* 1087 */       FSPermissionChecker pc = getPermissionChecker();
/* 1088 */       checkPathAccess(pc, src, FsAction.READ);
/*      */     }
/*      */ 
/* 1091 */     if (offset < 0L) {
/* 1092 */       throw new IOException(new StringBuilder().append("Negative offset is not supported. File: ").append(src).toString());
/*      */     }
/* 1094 */     if (length < 0L) {
/* 1095 */       throw new IOException(new StringBuilder().append("Negative length is not supported. File: ").append(src).toString());
/*      */     }
/* 1097 */     LocatedBlocks ret = getBlockLocationsInternal(src, offset, length, 2147483647, doAccessTime, needBlockToken);
/*      */ 
/* 1099 */     if ((auditLog.isInfoEnabled()) && (isExternalInvocation())) {
/* 1100 */       logAuditEvent(UserGroupInformation.getCurrentUser(), Server.getRemoteIp(), "open", src, null, null);
/*      */     }
/*      */ 
/* 1104 */     if ((checkSafeMode) && (isInSafeMode())) {
/* 1105 */       for (LocatedBlock b : ret.getLocatedBlocks())
/*      */       {
/* 1107 */         if ((b.getLocations() == null) || (b.getLocations().length == 0)) {
/* 1108 */           throw new SafeModeException(new StringBuilder().append("Zero blocklocations for ").append(src).toString(), this.safeMode);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1113 */     return ret;
/*      */   }
/*      */ 
/*      */   private synchronized LocatedBlocks getBlockLocationsInternal(String src, long offset, long length, int nrBlocksToReturn, boolean doAccessTime, boolean needBlockToken)
/*      */     throws IOException
/*      */   {
/* 1123 */     INodeFile inode = this.dir.getFileINode(src);
/* 1124 */     if (inode == null) {
/* 1125 */       return null;
/*      */     }
/* 1127 */     if ((doAccessTime) && (isAccessTimeSupported())) {
/* 1128 */       this.dir.setTimes(src, inode, -1L, now(), false);
/*      */     }
/* 1130 */     Block[] blocks = inode.getBlocks();
/* 1131 */     if (blocks == null) {
/* 1132 */       return null;
/*      */     }
/* 1134 */     if (blocks.length == 0) {
/* 1135 */       return inode.createLocatedBlocks(new ArrayList(blocks.length));
/*      */     }
/*      */ 
/* 1138 */     List results = new ArrayList(blocks.length);
/*      */ 
/* 1140 */     int curBlk = 0;
/* 1141 */     long curPos = 0L; long blkSize = 0L;
/* 1142 */     int nrBlocks = blocks[0].getNumBytes() == 0L ? 0 : blocks.length;
/* 1143 */     for (curBlk = 0; curBlk < nrBlocks; curBlk++) {
/* 1144 */       blkSize = blocks[curBlk].getNumBytes();
/* 1145 */       assert (blkSize > 0L) : "Block of size 0";
/* 1146 */       if (curPos + blkSize > offset) {
/*      */         break;
/*      */       }
/* 1149 */       curPos += blkSize;
/*      */     }
/*      */ 
/* 1152 */     if ((nrBlocks > 0) && (curBlk == nrBlocks)) {
/* 1153 */       return null;
/*      */     }
/* 1155 */     long endOff = offset + length;
/*      */     do
/*      */     {
/* 1159 */       int numNodes = this.blocksMap.numNodes(blocks[curBlk]);
/* 1160 */       int numCorruptNodes = countNodes(blocks[curBlk]).corruptReplicas();
/* 1161 */       int numCorruptReplicas = this.corruptReplicas.numCorruptReplicas(blocks[curBlk]);
/* 1162 */       if (numCorruptNodes != numCorruptReplicas) {
/* 1163 */         LOG.warn(new StringBuilder().append("Inconsistent number of corrupt replicas for ").append(blocks[curBlk]).append("blockMap has ").append(numCorruptNodes).append(" but corrupt replicas map has ").append(numCorruptReplicas).toString());
/*      */       }
/*      */ 
/* 1167 */       DatanodeDescriptor[] machineSet = null;
/* 1168 */       boolean blockCorrupt = false;
/* 1169 */       if ((inode.isUnderConstruction()) && (curBlk == blocks.length - 1) && (this.blocksMap.numNodes(blocks[curBlk]) == 0))
/*      */       {
/* 1172 */         INodeFileUnderConstruction cons = (INodeFileUnderConstruction)inode;
/* 1173 */         machineSet = cons.getTargets();
/* 1174 */         blockCorrupt = false;
/*      */       } else {
/* 1176 */         blockCorrupt = numCorruptNodes == numNodes;
/* 1177 */         int numMachineSet = blockCorrupt ? numNodes : numNodes - numCorruptNodes;
/*      */ 
/* 1179 */         machineSet = new DatanodeDescriptor[numMachineSet];
/* 1180 */         if (numMachineSet > 0) {
/* 1181 */           numNodes = 0;
/* 1182 */           Iterator it = this.blocksMap.nodeIterator(blocks[curBlk]);
/* 1183 */           while (it.hasNext()) {
/* 1184 */             DatanodeDescriptor dn = (DatanodeDescriptor)it.next();
/* 1185 */             boolean replicaCorrupt = this.corruptReplicas.isReplicaCorrupt(blocks[curBlk], dn);
/* 1186 */             if ((blockCorrupt) || ((!blockCorrupt) && (!replicaCorrupt)))
/* 1187 */               machineSet[(numNodes++)] = dn;
/*      */           }
/*      */         }
/*      */       }
/* 1191 */       LocatedBlock b = new LocatedBlock(blocks[curBlk], machineSet, curPos, blockCorrupt);
/*      */ 
/* 1193 */       if ((this.isAccessTokenEnabled) && (needBlockToken)) {
/* 1194 */         b.setBlockToken(this.accessTokenHandler.generateToken(b.getBlock(), EnumSet.of(BlockTokenSecretManager.AccessMode.READ)));
/*      */       }
/*      */ 
/* 1198 */       results.add(b);
/* 1199 */       curPos += blocks[curBlk].getNumBytes();
/* 1200 */       curBlk++;
/*      */     }
/*      */ 
/* 1203 */     while ((curPos < endOff) && (curBlk < blocks.length) && (results.size() < nrBlocksToReturn));
/*      */ 
/* 1205 */     return inode.createLocatedBlocks(results);
/*      */   }
/*      */ 
/*      */   void concat(String target, String[] srcs)
/*      */     throws IOException
/*      */   {
/* 1221 */     if (LOG.isDebugEnabled()) {
/* 1222 */       LOG.debug(new StringBuilder().append("concat ").append(Arrays.toString(srcs)).append(" to ").append(target).toString());
/*      */     }
/*      */ 
/* 1227 */     if (target.isEmpty()) {
/* 1228 */       throw new IllegalArgumentException("Target file name is empty");
/*      */     }
/* 1230 */     if ((srcs == null) || (srcs.length == 0)) {
/* 1231 */       throw new IllegalArgumentException("No sources given");
/*      */     }
/*      */ 
/* 1235 */     String trgParent = target.substring(0, target.lastIndexOf(47));
/*      */ 
/* 1237 */     for (String s : srcs) {
/* 1238 */       String srcParent = s.substring(0, s.lastIndexOf(47));
/* 1239 */       if (!srcParent.equals(trgParent)) {
/* 1240 */         throw new IllegalArgumentException("Sources and target are not in the same directory");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1245 */     FSPermissionChecker pc = getPermissionChecker();
/* 1246 */     HdfsFileStatus resultingStat = null;
/* 1247 */     synchronized (this) {
/* 1248 */       if (isInSafeMode()) {
/* 1249 */         throw new SafeModeException(new StringBuilder().append("Cannot concat ").append(target).toString(), this.safeMode);
/*      */       }
/* 1251 */       concatInternal(pc, target, srcs);
/* 1252 */       if ((auditLog.isInfoEnabled()) && (isExternalInvocation())) {
/* 1253 */         resultingStat = this.dir.getFileInfo(target);
/*      */       }
/*      */     }
/* 1256 */     getEditLog().logSync();
/* 1257 */     if ((auditLog.isInfoEnabled()) && (isExternalInvocation()))
/* 1258 */       logAuditEvent(UserGroupInformation.getLoginUser(), Server.getRemoteIp(), "concat", Arrays.toString(srcs), target, resultingStat);
/*      */   }
/*      */ 
/*      */   private void concatInternal(FSPermissionChecker pc, String target, String[] srcs)
/*      */     throws IOException
/*      */   {
/* 1269 */     if (this.isPermissionEnabled) {
/* 1270 */       checkPathAccess(pc, target, FsAction.WRITE);
/*      */ 
/* 1273 */       for (String aSrc : srcs) {
/* 1274 */         checkPathAccess(pc, aSrc, FsAction.READ);
/* 1275 */         checkParentAccess(pc, aSrc, FsAction.WRITE);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1280 */     Set si = new HashSet();
/*      */ 
/* 1286 */     INodeFile trgInode = this.dir.getFileINode(target);
/* 1287 */     if (trgInode.isUnderConstruction()) {
/* 1288 */       throw new IllegalArgumentException(new StringBuilder().append("concat: target file ").append(target).append(" is under construction").toString());
/*      */     }
/*      */ 
/* 1292 */     if (trgInode.blocks.length == 0) {
/* 1293 */       throw new IllegalArgumentException(new StringBuilder().append("concat: target file ").append(target).append(" is empty").toString());
/*      */     }
/*      */ 
/* 1297 */     long blockSize = trgInode.getPreferredBlockSize();
/*      */ 
/* 1300 */     BlocksMap.BlockInfo last = trgInode.blocks[(trgInode.blocks.length - 1)];
/* 1301 */     if (blockSize != last.getNumBytes()) {
/* 1302 */       throw new IllegalArgumentException(new StringBuilder().append("The last block in ").append(target).append(" is not full; last block size = ").append(last.getNumBytes()).append(" but file block size = ").append(blockSize).toString());
/*      */     }
/*      */ 
/* 1307 */     si.add(trgInode);
/* 1308 */     short repl = trgInode.getReplication();
/*      */ 
/* 1311 */     boolean endSrc = false;
/* 1312 */     for (int i = 0; i < srcs.length; i++) {
/* 1313 */       String src = srcs[i];
/* 1314 */       if (i == srcs.length - 1) {
/* 1315 */         endSrc = true;
/*      */       }
/* 1317 */       INodeFile srcInode = this.dir.getFileINode(src);
/* 1318 */       if ((src.isEmpty()) || (srcInode.isUnderConstruction()) || (srcInode.blocks.length == 0))
/*      */       {
/* 1321 */         throw new IllegalArgumentException(new StringBuilder().append("concat: source file ").append(src).append(" is invalid or empty or underConstruction").toString());
/*      */       }
/*      */ 
/* 1326 */       if (repl != srcInode.getReplication()) {
/* 1327 */         throw new IllegalArgumentException(new StringBuilder().append("concat: the source file ").append(src).append(" and the target file ").append(target).append(" should have the same replication: source replication is ").append(srcInode.getReplication()).append(" but target replication is ").append(repl).toString());
/*      */       }
/*      */ 
/* 1337 */       BlocksMap.BlockInfo[] srcBlocks = srcInode.getBlocks();
/* 1338 */       int idx = srcBlocks.length - 1;
/* 1339 */       if (endSrc)
/* 1340 */         idx = srcBlocks.length - 2;
/* 1341 */       if ((idx >= 0) && (srcBlocks[idx].getNumBytes() != blockSize)) {
/* 1342 */         throw new IllegalArgumentException(new StringBuilder().append("concat: the soruce file ").append(src).append(" and the target file ").append(target).append(" should have the same blocks sizes: target block size is ").append(blockSize).append(" but the size of source block ").append(idx).append(" is ").append(srcBlocks[idx].getNumBytes()).toString());
/*      */       }
/*      */ 
/* 1349 */       si.add(srcInode);
/*      */     }
/*      */ 
/* 1353 */     if (si.size() < srcs.length + 1)
/*      */     {
/* 1355 */       throw new IllegalArgumentException("concat: at least two of the source files are the same");
/*      */     }
/*      */ 
/* 1359 */     if (NameNode.stateChangeLog.isDebugEnabled()) {
/* 1360 */       NameNode.stateChangeLog.debug(new StringBuilder().append("DIR* NameSystem.concat: ").append(Arrays.toString(srcs)).append(" to ").append(target).toString());
/*      */     }
/*      */ 
/* 1364 */     this.dir.concat(target, srcs);
/*      */   }
/*      */ 
/*      */   public void setTimes(String src, long mtime, long atime)
/*      */     throws IOException
/*      */   {
/* 1373 */     if ((!isAccessTimeSupported()) && (atime != -1L)) {
/* 1374 */       throw new IOException("Access time for hdfs is not configured.  Please set dfs.access.time.precision configuration parameter");
/*      */     }
/*      */ 
/* 1377 */     FSPermissionChecker pc = getPermissionChecker();
/* 1378 */     synchronized (this) {
/* 1379 */       if (isInSafeMode()) {
/* 1380 */         throw new SafeModeException(new StringBuilder().append("Cannot set accesstimes  for ").append(src).toString(), this.safeMode);
/*      */       }
/*      */ 
/* 1386 */       if (this.isPermissionEnabled) {
/* 1387 */         checkPathAccess(pc, src, FsAction.WRITE);
/*      */       }
/* 1389 */       INodeFile inode = this.dir.getFileINode(src);
/* 1390 */       if (inode != null) {
/* 1391 */         this.dir.setTimes(src, inode, mtime, atime, true);
/* 1392 */         if ((auditLog.isInfoEnabled()) && (isExternalInvocation())) {
/* 1393 */           HdfsFileStatus stat = this.dir.getFileInfo(src);
/* 1394 */           logAuditEvent(UserGroupInformation.getCurrentUser(), Server.getRemoteIp(), "setTimes", src, null, stat);
/*      */         }
/*      */       }
/*      */       else {
/* 1398 */         throw new FileNotFoundException(new StringBuilder().append("File ").append(src).append(" does not exist").toString());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean setReplication(String src, short replication)
/*      */     throws IOException
/*      */   {
/* 1418 */     boolean status = setReplicationInternal(src, replication);
/* 1419 */     getEditLog().logSync();
/* 1420 */     if ((status) && (auditLog.isInfoEnabled()) && (isExternalInvocation())) {
/* 1421 */       logAuditEvent(UserGroupInformation.getCurrentUser(), Server.getRemoteIp(), "setReplication", src, null, null);
/*      */     }
/*      */ 
/* 1425 */     return status;
/*      */   }
/*      */ 
/*      */   private boolean setReplicationInternal(String src, short replication)
/*      */     throws IOException
/*      */   {
/* 1431 */     FSPermissionChecker pc = getPermissionChecker();
/* 1432 */     synchronized (this) {
/* 1433 */       if (isInSafeMode()) {
/* 1434 */         throw new SafeModeException(new StringBuilder().append("Cannot set replication for ").append(src).toString(), this.safeMode);
/*      */       }
/* 1436 */       verifyReplication(src, replication, null);
/* 1437 */       if (this.isPermissionEnabled) {
/* 1438 */         checkPathAccess(pc, src, FsAction.WRITE);
/*      */       }
/*      */ 
/* 1441 */       int[] oldReplication = new int[1];
/*      */ 
/* 1443 */       Block[] fileBlocks = this.dir.setReplication(src, replication, oldReplication);
/* 1444 */       if (fileBlocks == null)
/* 1445 */         return false;
/* 1446 */       int oldRepl = oldReplication[0];
/* 1447 */       if (oldRepl == replication) {
/* 1448 */         return true;
/*      */       }
/*      */ 
/* 1451 */       for (int idx = 0; idx < fileBlocks.length; idx++) {
/* 1452 */         updateNeededReplications(fileBlocks[idx], 0, replication - oldRepl);
/*      */       }
/* 1454 */       if (oldRepl > replication)
/*      */       {
/* 1456 */         LOG.info(new StringBuilder().append("Reducing replication for ").append(src).append(". New replication is ").append(replication).toString());
/*      */ 
/* 1458 */         for (int idx = 0; idx < fileBlocks.length; idx++)
/* 1459 */           processOverReplicatedBlock(fileBlocks[idx], replication, null, null);
/*      */       } else {
/* 1461 */         LOG.info(new StringBuilder().append("Increasing replication for ").append(src).append(". New replication is ").append(replication).toString());
/*      */       }
/*      */     }
/*      */ 
/* 1465 */     return true;
/*      */   }
/*      */ 
/*      */   long getPreferredBlockSize(String filename) throws IOException {
/* 1469 */     if (this.isPermissionEnabled) {
/* 1470 */       FSPermissionChecker pc = getPermissionChecker();
/* 1471 */       checkTraverse(pc, filename);
/*      */     }
/* 1473 */     return this.dir.getPreferredBlockSize(filename);
/*      */   }
/*      */ 
/*      */   private void verifyReplication(String src, short replication, String clientName)
/*      */     throws IOException
/*      */   {
/* 1484 */     String text = new StringBuilder().append("file ").append(src).append(clientName != null ? new StringBuilder().append(" on client ").append(clientName).toString() : "").append(".\n").append("Requested replication ").append(replication).toString();
/*      */ 
/* 1489 */     if (replication > this.maxReplication) {
/* 1490 */       throw new IOException(new StringBuilder().append(text).append(" exceeds maximum ").append(this.maxReplication).toString());
/*      */     }
/* 1492 */     if (replication < this.minReplication)
/* 1493 */       throw new IOException(new StringBuilder().append(text).append(" is less than the required minimum ").append(this.minReplication).toString());
/*      */   }
/*      */ 
/*      */   private void verifyParentDir(String src)
/*      */     throws FileAlreadyExistsException, FileNotFoundException
/*      */   {
/* 1502 */     Path parent = new Path(src).getParent();
/* 1503 */     if (parent != null) {
/* 1504 */       INode[] pathINodes = this.dir.getExistingPathINodes(parent.toString());
/* 1505 */       if (pathINodes[(pathINodes.length - 1)] == null) {
/* 1506 */         throw new FileNotFoundException(new StringBuilder().append("Parent directory doesn't exist: ").append(parent.toString()).toString());
/*      */       }
/* 1508 */       if (!pathINodes[(pathINodes.length - 1)].isDirectory())
/* 1509 */         throw new FileAlreadyExistsException(new StringBuilder().append("Parent path is not a directory: ").append(parent.toString()).toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   void startFile(String src, PermissionStatus permissions, String holder, String clientMachine, boolean overwrite, boolean createParent, short replication, long blockSize)
/*      */     throws IOException
/*      */   {
/* 1527 */     startFileInternal(src, permissions, holder, clientMachine, overwrite, false, createParent, replication, blockSize);
/*      */ 
/* 1529 */     getEditLog().logSync();
/* 1530 */     if ((auditLog.isInfoEnabled()) && (isExternalInvocation())) {
/* 1531 */       HdfsFileStatus stat = this.dir.getFileInfo(src);
/* 1532 */       logAuditEvent(UserGroupInformation.getCurrentUser(), Server.getRemoteIp(), "create", src, null, stat);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void startFileInternal(String src, PermissionStatus permissions, String holder, String clientMachine, boolean overwrite, boolean append, boolean createParent, short replication, long blockSize)
/*      */     throws IOException
/*      */   {
/* 1548 */     if (NameNode.stateChangeLog.isDebugEnabled()) {
/* 1549 */       NameNode.stateChangeLog.debug(new StringBuilder().append("DIR* startFile: src=").append(src).append(", holder=").append(holder).append(", clientMachine=").append(clientMachine).append(", createParent=").append(createParent).append(", replication=").append(replication).append(", overwrite=").append(overwrite).append(", append=").append(append).toString());
/*      */     }
/*      */ 
/* 1558 */     FSPermissionChecker pc = getPermissionChecker();
/* 1559 */     synchronized (this) {
/* 1560 */       if (isInSafeMode())
/* 1561 */         throw new SafeModeException(new StringBuilder().append("Cannot create ").append(src).toString(), this.safeMode);
/* 1562 */       if (!DFSUtil.isValidName(src)) {
/* 1563 */         throw new IOException(new StringBuilder().append("Invalid name: ").append(src).toString());
/*      */       }
/*      */ 
/* 1567 */       boolean pathExists = this.dir.exists(src);
/* 1568 */       if ((pathExists) && (this.dir.isDir(src))) {
/* 1569 */         throw new IOException(new StringBuilder().append("Cannot create ").append(src).append("; already exists as a directory").toString());
/*      */       }
/*      */ 
/* 1572 */       if (this.isPermissionEnabled) {
/* 1573 */         if ((append) || ((overwrite) && (pathExists)))
/* 1574 */           checkPathAccess(pc, src, FsAction.WRITE);
/*      */         else {
/* 1576 */           checkAncestorAccess(pc, src, FsAction.WRITE);
/*      */         }
/*      */       }
/*      */ 
/* 1580 */       if (!createParent) {
/* 1581 */         verifyParentDir(src);
/*      */       }
/*      */       try
/*      */       {
/* 1585 */         INode myFile = this.dir.getFileINode(src);
/* 1586 */         recoverLeaseInternal(myFile, src, holder, clientMachine, false);
/*      */         try
/*      */         {
/* 1589 */           verifyReplication(src, replication, clientMachine);
/*      */         } catch (IOException e) {
/* 1591 */           throw new IOException(new StringBuilder().append("failed to create ").append(e.getMessage()).toString());
/*      */         }
/* 1593 */         if (append) {
/* 1594 */           if (myFile == null) {
/* 1595 */             throw new FileNotFoundException(new StringBuilder().append("failed to append to non-existent ").append(src).append(" on client ").append(clientMachine).toString());
/*      */           }
/* 1597 */           if (myFile.isDirectory()) {
/* 1598 */             throw new IOException(new StringBuilder().append("failed to append to directory ").append(src).append(" on client ").append(clientMachine).toString());
/*      */           }
/*      */         }
/* 1601 */         else if (!this.dir.isValidToCreate(src)) {
/* 1602 */           if (overwrite)
/* 1603 */             delete(src, true);
/*      */           else {
/* 1605 */             throw new IOException(new StringBuilder().append("failed to create file ").append(src).append(" on client ").append(clientMachine).append(" either because the filename is invalid or the file exists").toString());
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1611 */         DatanodeDescriptor clientNode = this.host2DataNodeMap.getDatanodeByHost(clientMachine);
/*      */ 
/* 1614 */         if (append)
/*      */         {
/* 1619 */           INodeFile node = (INodeFile)myFile;
/* 1620 */           INodeFileUnderConstruction cons = new INodeFileUnderConstruction(node.getLocalNameBytes(), node.getReplication(), node.getModificationTime(), node.getPreferredBlockSize(), node.getBlocks(), node.getPermissionStatus(), holder, clientMachine, clientNode);
/*      */ 
/* 1625 */           this.dir.replaceNode(src, node, cons);
/* 1626 */           this.leaseManager.addLease(cons.clientName, src);
/*      */         }
/*      */         else
/*      */         {
/* 1632 */           checkFsObjectLimit();
/*      */ 
/* 1635 */           long genstamp = nextGenerationStamp();
/* 1636 */           INodeFileUnderConstruction newNode = this.dir.addFile(src, permissions, replication, blockSize, holder, clientMachine, clientNode, genstamp);
/*      */ 
/* 1639 */           if (newNode == null) {
/* 1640 */             throw new IOException("DIR* startFile: Unable to add to namespace");
/*      */           }
/* 1642 */           this.leaseManager.addLease(newNode.clientName, src);
/* 1643 */           if (NameNode.stateChangeLog.isDebugEnabled())
/* 1644 */             NameNode.stateChangeLog.debug(new StringBuilder().append("DIR* startFile: add ").append(src).append(" to namespace for ").append(holder).toString());
/*      */         }
/*      */       }
/*      */       catch (IOException ie)
/*      */       {
/* 1649 */         NameNode.stateChangeLog.warn(new StringBuilder().append("DIR* startFile: ").append(ie.getMessage()).toString());
/*      */ 
/* 1651 */         throw ie;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   boolean isFileClosed(String src)
/*      */     throws AccessControlException, IOException
/*      */   {
/* 1661 */     FSPermissionChecker pc = getPermissionChecker();
/* 1662 */     synchronized (this) {
/* 1663 */       if (this.isPermissionEnabled) {
/* 1664 */         checkTraverse(pc, src);
/*      */       }
/* 1666 */       INode inode = this.dir.getFileINode(src);
/* 1667 */       if (inode == null) {
/* 1668 */         throw new FileNotFoundException(new StringBuilder().append("File not found ").append(src).toString());
/*      */       }
/*      */ 
/* 1671 */       return !inode.isUnderConstruction();
/*      */     }
/*      */   }
/*      */ 
/*      */   boolean recoverLease(String src, String holder, String clientMachine)
/*      */     throws IOException
/*      */   {
/* 1688 */     FSPermissionChecker pc = getPermissionChecker();
/* 1689 */     synchronized (this) {
/* 1690 */       if (isInSafeMode()) {
/* 1691 */         throw new SafeModeException(new StringBuilder().append("Cannot recover the lease of ").append(src).toString(), this.safeMode);
/*      */       }
/*      */ 
/* 1694 */       if (!DFSUtil.isValidName(src)) {
/* 1695 */         throw new IOException(new StringBuilder().append("Invalid name: ").append(src).toString());
/*      */       }
/*      */ 
/* 1698 */       INode inode = this.dir.getFileINode(src);
/* 1699 */       if (inode == null) {
/* 1700 */         throw new FileNotFoundException(new StringBuilder().append("File not found ").append(src).toString());
/*      */       }
/*      */ 
/* 1703 */       if (!inode.isUnderConstruction()) {
/* 1704 */         return true;
/*      */       }
/* 1706 */       if (this.isPermissionEnabled) {
/* 1707 */         checkPathAccess(pc, src, FsAction.WRITE);
/*      */       }
/*      */ 
/* 1710 */       recoverLeaseInternal(inode, src, holder, clientMachine, true);
/*      */     }
/* 1712 */     return false;
/*      */   }
/*      */ 
/*      */   private void recoverLeaseInternal(INode fileInode, String src, String holder, String clientMachine, boolean force)
/*      */     throws IOException
/*      */   {
/* 1718 */     if ((fileInode != null) && (fileInode.isUnderConstruction())) {
/* 1719 */       INodeFileUnderConstruction pendingFile = (INodeFileUnderConstruction)fileInode;
/*      */ 
/* 1724 */       LeaseManager.Lease lease = this.leaseManager.getLease(holder);
/*      */ 
/* 1729 */       if ((!force) && (lease != null)) {
/* 1730 */         LeaseManager.Lease leaseFile = this.leaseManager.getLeaseByPath(src);
/* 1731 */         if ((leaseFile != null) && (leaseFile.equals(lease))) {
/* 1732 */           throw new AlreadyBeingCreatedException(new StringBuilder().append("failed to create file ").append(src).append(" for ").append(holder).append(" on client ").append(clientMachine).append(" because current leaseholder is trying to recreate file").toString());
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1741 */       lease = this.leaseManager.getLease(pendingFile.clientName);
/* 1742 */       if (lease == null) {
/* 1743 */         throw new AlreadyBeingCreatedException(new StringBuilder().append("failed to create file ").append(src).append(" for ").append(holder).append(" on client ").append(clientMachine).append(" because pendingCreates is non-null but no leases found").toString());
/*      */       }
/*      */ 
/* 1748 */       if (force)
/*      */       {
/* 1751 */         LOG.info(new StringBuilder().append("recoverLease: recover lease ").append(lease).append(", src=").append(src).append(" from client ").append(pendingFile.clientName).toString());
/*      */ 
/* 1753 */         internalReleaseLeaseOne(lease, src);
/*      */       }
/*      */       else
/*      */       {
/* 1759 */         if (lease.expiredSoftLimit()) {
/* 1760 */           LOG.info(new StringBuilder().append("startFile: recover lease ").append(lease).append(", src=").append(src).append(" from client ").append(pendingFile.clientName).toString());
/*      */ 
/* 1762 */           internalReleaseLease(lease, src);
/*      */         }
/* 1764 */         throw new AlreadyBeingCreatedException(new StringBuilder().append("failed to create file ").append(src).append(" for ").append(holder).append(" on client ").append(clientMachine).append(", because this file is already being created by ").append(pendingFile.getClientName()).append(" on ").append(pendingFile.getClientMachine()).toString());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   LocatedBlock appendFile(String src, String holder, String clientMachine)
/*      */     throws IOException
/*      */   {
/* 1780 */     if (!this.allowBrokenAppend) {
/* 1781 */       throw new IOException("Append is not supported. Please see the dfs.support.append configuration parameter");
/*      */     }
/*      */ 
/* 1784 */     startFileInternal(src, null, holder, clientMachine, false, true, false, (short)this.maxReplication, 0L);
/*      */ 
/* 1786 */     getEditLog().logSync();
/*      */ 
/* 1793 */     LocatedBlock lb = null;
/* 1794 */     synchronized (this)
/*      */     {
/* 1797 */       INodeFileUnderConstruction file = checkLease(src, holder);
/*      */ 
/* 1799 */       Block[] blocks = file.getBlocks();
/* 1800 */       if ((blocks != null) && (blocks.length > 0)) {
/* 1801 */         Block last = blocks[(blocks.length - 1)];
/* 1802 */         BlocksMap.BlockInfo storedBlock = this.blocksMap.getStoredBlock(last);
/* 1803 */         if (file.getPreferredBlockSize() > storedBlock.getNumBytes()) {
/* 1804 */           long fileLength = file.computeContentSummary().getLength();
/* 1805 */           DatanodeDescriptor[] targets = new DatanodeDescriptor[this.blocksMap.numNodes(last)];
/* 1806 */           Iterator it = this.blocksMap.nodeIterator(last);
/* 1807 */           for (int i = 0; (it != null) && (it.hasNext()); i++) {
/* 1808 */             targets[i] = ((DatanodeDescriptor)it.next());
/*      */           }
/*      */ 
/* 1811 */           for (int i = 0; i < targets.length; i++) {
/* 1812 */             targets[i].removeBlock(storedBlock);
/*      */           }
/*      */ 
/* 1815 */           file.setLastBlock(storedBlock, targets);
/*      */ 
/* 1817 */           lb = new LocatedBlock(last, targets, fileLength - storedBlock.getNumBytes());
/*      */ 
/* 1819 */           if (this.isAccessTokenEnabled) {
/* 1820 */             lb.setBlockToken(this.accessTokenHandler.generateToken(lb.getBlock(), EnumSet.of(BlockTokenSecretManager.AccessMode.WRITE)));
/*      */           }
/*      */ 
/* 1825 */           updateNeededReplications(last, 0, 0);
/*      */ 
/* 1830 */           for (DatanodeDescriptor dd : targets) {
/* 1831 */             String datanodeId = dd.getStorageID();
/* 1832 */             Collection v = (Collection)this.recentInvalidateSets.get(datanodeId);
/* 1833 */             if ((v != null) && (v.remove(last))) {
/* 1834 */               if (v.isEmpty()) {
/* 1835 */                 this.recentInvalidateSets.remove(datanodeId);
/*      */               }
/* 1837 */               this.pendingDeletionBlocksCount -= 1L;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1843 */     if ((lb != null) && 
/* 1844 */       (NameNode.stateChangeLog.isDebugEnabled())) {
/* 1845 */       NameNode.stateChangeLog.debug(new StringBuilder().append("DIR* appendFile: ").append(src).append(" for ").append(holder).append(" at ").append(clientMachine).append(" block ").append(lb.getBlock()).append(" block size ").append(lb.getBlock().getNumBytes()).toString());
/*      */     }
/*      */ 
/* 1852 */     if ((auditLog.isInfoEnabled()) && (isExternalInvocation())) {
/* 1853 */       logAuditEvent(UserGroupInformation.getCurrentUser(), Server.getRemoteIp(), "append", src, null, null);
/*      */     }
/*      */ 
/* 1857 */     return lb;
/*      */   }
/*      */ 
/*      */   public LocatedBlock getAdditionalBlock(String src, String clientName)
/*      */     throws IOException
/*      */   {
/* 1866 */     return getAdditionalBlock(src, clientName, null);
/*      */   }
/*      */ 
/*      */   public LocatedBlock getAdditionalBlock(String src, String clientName, HashMap<Node, Node> excludedNodes)
/*      */     throws IOException
/*      */   {
/* 1886 */     DatanodeDescriptor clientNode = null;
/* 1887 */     Block newBlock = null;
/*      */ 
/* 1889 */     NameNode.stateChangeLog.debug(new StringBuilder().append("BLOCK* getAdditionalBlock: ").append(src).append(" for ").append(clientName).toString());
/*      */     long fileLength;
/*      */     long blockSize;
/*      */     int replication;
/* 1892 */     synchronized (this) {
/* 1893 */       if (isInSafeMode()) {
/* 1894 */         throw new SafeModeException(new StringBuilder().append("Cannot add block to ").append(src).toString(), this.safeMode);
/*      */       }
/*      */ 
/* 1897 */       checkFsObjectLimit();
/*      */ 
/* 1899 */       INodeFileUnderConstruction pendingFile = checkLease(src, clientName);
/*      */ 
/* 1904 */       if (!checkFileProgress(pendingFile, false)) {
/* 1905 */         throw new NotReplicatedYetException(new StringBuilder().append("Not replicated yet:").append(src).toString());
/*      */       }
/* 1907 */       fileLength = pendingFile.computeContentSummary().getLength();
/* 1908 */       blockSize = pendingFile.getPreferredBlockSize();
/* 1909 */       clientNode = pendingFile.getClientNode();
/* 1910 */       replication = pendingFile.getReplication();
/*      */     }
/*      */ 
/* 1914 */     DatanodeDescriptor[] targets = this.replicator.chooseTarget(src, replication, clientNode, excludedNodes, blockSize);
/*      */ 
/* 1919 */     if (targets.length < this.minReplication) {
/* 1920 */       throw new IOException(new StringBuilder().append("File ").append(src).append(" could only be replicated to ").append(targets.length).append(" nodes, instead of ").append(this.minReplication).toString());
/*      */     }
/*      */ 
/* 1926 */     synchronized (this) {
/* 1927 */       if (isInSafeMode()) {
/* 1928 */         throw new SafeModeException(new StringBuilder().append("Cannot add block to ").append(src).toString(), this.safeMode);
/*      */       }
/* 1930 */       INode[] pathINodes = this.dir.getExistingPathINodes(src);
/* 1931 */       int inodesLen = pathINodes.length;
/* 1932 */       checkLease(src, clientName, pathINodes[(inodesLen - 1)]);
/* 1933 */       INodeFileUnderConstruction pendingFile = (INodeFileUnderConstruction)pathINodes[(inodesLen - 1)];
/*      */ 
/* 1936 */       if (!checkFileProgress(pendingFile, false)) {
/* 1937 */         throw new NotReplicatedYetException(new StringBuilder().append("Not replicated yet:").append(src).toString());
/*      */       }
/*      */ 
/* 1941 */       newBlock = allocateBlock(src, pathINodes);
/* 1942 */       pendingFile.setTargets(targets);
/*      */ 
/* 1944 */       for (DatanodeDescriptor dn : targets) {
/* 1945 */         dn.incBlocksScheduled();
/*      */       }
/* 1947 */       this.dir.persistBlocks(src, pendingFile);
/*      */     }
/* 1949 */     if (this.persistBlocks) {
/* 1950 */       getEditLog().logSync();
/*      */     }
/*      */ 
/* 1954 */     LocatedBlock b = new LocatedBlock(newBlock, targets, fileLength);
/* 1955 */     if (this.isAccessTokenEnabled) {
/* 1956 */       b.setBlockToken(this.accessTokenHandler.generateToken(b.getBlock(), EnumSet.of(BlockTokenSecretManager.AccessMode.WRITE)));
/*      */     }
/*      */ 
/* 1959 */     return b;
/*      */   }
/*      */ 
/*      */   public synchronized boolean abandonBlock(Block b, String src, String holder)
/*      */     throws IOException
/*      */   {
/* 1970 */     NameNode.stateChangeLog.debug(new StringBuilder().append("BLOCK* abandonBlock: ").append(b).append("of ").append(src).toString());
/* 1971 */     if (isInSafeMode()) {
/* 1972 */       throw new SafeModeException(new StringBuilder().append("Cannot abandon ").append(b).append(" for ").append(src).toString(), this.safeMode);
/*      */     }
/*      */ 
/* 1975 */     INodeFileUnderConstruction file = checkLease(src, holder);
/* 1976 */     this.dir.removeBlock(src, file, b);
/* 1977 */     NameNode.stateChangeLog.debug(new StringBuilder().append("BLOCK* abandonBlock: ").append(b).append(" is removed from pendingCreates").toString());
/*      */ 
/* 1979 */     this.dir.persistBlocks(src, file);
/* 1980 */     if (this.persistBlocks) {
/* 1981 */       getEditLog().logSync();
/*      */     }
/* 1983 */     return true;
/*      */   }
/*      */ 
/*      */   private INodeFileUnderConstruction checkLease(String src, String holder)
/*      */     throws IOException
/*      */   {
/* 1989 */     INodeFile file = this.dir.getFileINode(src);
/* 1990 */     checkLease(src, holder, file);
/* 1991 */     return (INodeFileUnderConstruction)file;
/*      */   }
/*      */ 
/*      */   private void checkLease(String src, String holder, INode file)
/*      */     throws IOException
/*      */   {
/* 1997 */     if ((file == null) || (file.isDirectory())) {
/* 1998 */       LeaseManager.Lease lease = this.leaseManager.getLease(holder);
/* 1999 */       throw new LeaseExpiredException(new StringBuilder().append("No lease on ").append(src).append(" File does not exist. ").append(lease != null ? lease.toString() : new StringBuilder().append("Holder ").append(holder).append(" does not have any open files").toString()).toString());
/*      */     }
/*      */ 
/* 2005 */     if (!file.isUnderConstruction()) {
/* 2006 */       LeaseManager.Lease lease = this.leaseManager.getLease(holder);
/* 2007 */       throw new LeaseExpiredException(new StringBuilder().append("No lease on ").append(src).append(" File is not open for writing. ").append(lease != null ? lease.toString() : new StringBuilder().append("Holder ").append(holder).append(" does not have any open files").toString()).toString());
/*      */     }
/*      */ 
/* 2013 */     INodeFileUnderConstruction pendingFile = (INodeFileUnderConstruction)file;
/* 2014 */     if ((holder != null) && (!pendingFile.getClientName().equals(holder)))
/* 2015 */       throw new LeaseExpiredException(new StringBuilder().append("Lease mismatch on ").append(src).append(" owned by ").append(pendingFile.getClientName()).append(" but is accessed by ").append(holder).toString());
/*      */   }
/*      */ 
/*      */   public CompleteFileStatus completeFile(String src, String holder)
/*      */     throws IOException
/*      */   {
/* 2033 */     CompleteFileStatus status = completeFileInternal(src, holder);
/* 2034 */     getEditLog().logSync();
/* 2035 */     return status;
/*      */   }
/*      */ 
/*      */   private synchronized CompleteFileStatus completeFileInternal(String src, String holder)
/*      */     throws IOException
/*      */   {
/* 2041 */     NameNode.stateChangeLog.debug(new StringBuilder().append("DIR* completeFile: ").append(src).append(" for ").append(holder).toString());
/* 2042 */     if (isInSafeMode()) {
/* 2043 */       throw new SafeModeException(new StringBuilder().append("Cannot complete ").append(src).toString(), this.safeMode);
/*      */     }
/* 2045 */     INodeFileUnderConstruction pendingFile = checkLease(src, holder);
/* 2046 */     Block[] fileBlocks = this.dir.getFileBlocks(src);
/*      */ 
/* 2048 */     if (fileBlocks == null) {
/* 2049 */       NameNode.stateChangeLog.warn(new StringBuilder().append("DIR* completeFile: failed to complete ").append(src).append(" because dir.getFileBlocks() is null,").append(" pending from ").append(pendingFile.getClientMachine()).toString());
/*      */ 
/* 2053 */       return CompleteFileStatus.OPERATION_FAILED;
/*      */     }
/*      */ 
/* 2056 */     if (!checkFileProgress(pendingFile, true)) {
/* 2057 */       return CompleteFileStatus.STILL_WAITING;
/*      */     }
/*      */ 
/* 2060 */     finalizeINodeFileUnderConstruction(src, pendingFile);
/*      */ 
/* 2062 */     NameNode.stateChangeLog.info(new StringBuilder().append("DIR* completeFile: ").append(src).append(" is closed by ").append(holder).toString());
/*      */ 
/* 2064 */     return CompleteFileStatus.COMPLETE_SUCCESS;
/*      */   }
/*      */ 
/*      */   private void checkReplicationFactor(INodeFile file)
/*      */   {
/* 2072 */     int numExpectedReplicas = file.getReplication();
/* 2073 */     Block[] pendingBlocks = file.getBlocks();
/* 2074 */     int nrBlocks = pendingBlocks.length;
/* 2075 */     for (int i = 0; i < nrBlocks; i++)
/*      */     {
/* 2077 */       NumberReplicas number = countNodes(pendingBlocks[i]);
/* 2078 */       if (number.liveReplicas() < numExpectedReplicas)
/* 2079 */         this.neededReplications.add(pendingBlocks[i], number.liveReplicas(), number.decommissionedReplicas, numExpectedReplicas);
/*      */     }
/*      */   }
/*      */ 
/*      */   private Block allocateBlock(String src, INode[] inodes)
/*      */     throws IOException
/*      */   {
/* 2097 */     Block b = new Block(randBlockId.nextLong(), 0L, 0L);
/* 2098 */     while (isValidBlock(b)) {
/* 2099 */       b.setBlockId(randBlockId.nextLong());
/*      */     }
/* 2101 */     b.setGenerationStamp(getGenerationStamp());
/* 2102 */     b = this.dir.addBlock(src, inodes, b);
/* 2103 */     NameNode.stateChangeLog.info(new StringBuilder().append("BLOCK* allocateBlock: ").append(src).append(". ").append(b).toString());
/*      */ 
/* 2105 */     return b;
/*      */   }
/*      */ 
/*      */   synchronized boolean checkFileProgress(INodeFile v, boolean checkall)
/*      */   {
/* 2114 */     if (checkall)
/*      */     {
/* 2118 */       for (Block block : v.getBlocks()) {
/* 2119 */         if (this.blocksMap.numNodes(block) < this.minReplication) {
/* 2120 */           return false;
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 2127 */       Block b = v.getPenultimateBlock();
/* 2128 */       if ((b != null) && 
/* 2129 */         (this.blocksMap.numNodes(b) < this.minReplication)) {
/* 2130 */         return false;
/*      */       }
/*      */     }
/*      */ 
/* 2134 */     return true;
/*      */   }
/*      */ 
/*      */   void removeFromInvalidates(String storageID)
/*      */   {
/* 2142 */     Collection blocks = (Collection)this.recentInvalidateSets.remove(storageID);
/* 2143 */     if (blocks != null)
/* 2144 */       this.pendingDeletionBlocksCount -= blocks.size();
/*      */   }
/*      */ 
/*      */   void addToInvalidates(Block b, DatanodeInfo dn, boolean log)
/*      */   {
/* 2156 */     addToInvalidatesNoLog(b, dn);
/* 2157 */     if (log)
/* 2158 */       NameNode.stateChangeLog.info(new StringBuilder().append("BLOCK* addToInvalidates: ").append(b.getBlockName()).append(" to ").append(dn.getName()).toString());
/*      */   }
/*      */ 
/*      */   void addToInvalidates(Block b, DatanodeInfo dn)
/*      */   {
/* 2173 */     addToInvalidates(b, dn, true);
/*      */   }
/*      */ 
/*      */   void addToInvalidatesNoLog(Block b, DatanodeInfo n)
/*      */   {
/* 2183 */     Collection invalidateSet = (Collection)this.recentInvalidateSets.get(n.getStorageID());
/* 2184 */     if (invalidateSet == null) {
/* 2185 */       invalidateSet = new HashSet();
/* 2186 */       this.recentInvalidateSets.put(n.getStorageID(), invalidateSet);
/*      */     }
/* 2188 */     if (invalidateSet.add(b))
/* 2189 */       this.pendingDeletionBlocksCount += 1L;
/*      */   }
/*      */ 
/*      */   private void addToInvalidates(Block b)
/*      */   {
/* 2198 */     StringBuilder datanodes = new StringBuilder();
/* 2199 */     Iterator it = this.blocksMap.nodeIterator(b);
/* 2200 */     while (it.hasNext()) {
/* 2201 */       DatanodeDescriptor node = (DatanodeDescriptor)it.next();
/* 2202 */       addToInvalidates(b, node, false);
/* 2203 */       datanodes.append(node.getName()).append(" ");
/*      */     }
/* 2205 */     if (datanodes.length() != 0)
/* 2206 */       NameNode.stateChangeLog.info(new StringBuilder().append("BLOCK* addToInvalidates: ").append(b.getBlockName()).append(" to ").append(datanodes.toString()).toString());
/*      */   }
/*      */ 
/*      */   private synchronized void dumpRecentInvalidateSets(PrintWriter out)
/*      */   {
/* 2215 */     int size = this.recentInvalidateSets.values().size();
/* 2216 */     out.println(new StringBuilder().append("Metasave: Blocks ").append(this.pendingDeletionBlocksCount).append(" waiting deletion from ").append(size).append(" datanodes").toString());
/*      */ 
/* 2218 */     if (size == 0) {
/* 2219 */       return;
/*      */     }
/* 2221 */     for (Map.Entry entry : this.recentInvalidateSets.entrySet()) {
/* 2222 */       Collection blocks = (Collection)entry.getValue();
/* 2223 */       if (blocks.size() > 0)
/* 2224 */         out.println(new StringBuilder().append(((DatanodeDescriptor)this.datanodeMap.get(entry.getKey())).getName()).append(blocks).toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void markBlockAsCorrupt(Block blk, DatanodeInfo dn)
/*      */     throws IOException
/*      */   {
/* 2236 */     DatanodeDescriptor node = getDatanode(dn);
/* 2237 */     if (node == null) {
/* 2238 */       throw new IOException(new StringBuilder().append("Cannot mark block").append(blk.getBlockName()).append(" as corrupt because datanode ").append(dn.getName()).append(" does not exist. ").toString());
/*      */     }
/*      */ 
/* 2243 */     BlocksMap.BlockInfo storedBlockInfo = this.blocksMap.getStoredBlock(blk);
/* 2244 */     if (storedBlockInfo == null)
/*      */     {
/* 2249 */       NameNode.stateChangeLog.info(new StringBuilder().append("BLOCK markBlockAsCorrupt: ").append(blk).append(" could not be marked ").append("as corrupt as it does not exists in ").append("blocksMap").toString());
/*      */     }
/*      */     else
/*      */     {
/* 2254 */       INodeFile inode = storedBlockInfo.getINode();
/* 2255 */       if (inode == null) {
/* 2256 */         NameNode.stateChangeLog.info(new StringBuilder().append("BLOCK markBlockAsCorrupt: ").append(blk).append(" could not be marked ").append("as corrupt as it does not belong to ").append("any file").toString());
/*      */ 
/* 2260 */         addToInvalidates(storedBlockInfo, node);
/* 2261 */         return;
/*      */       }
/*      */ 
/* 2264 */       this.corruptReplicas.addToCorruptReplicasMap(storedBlockInfo, node);
/* 2265 */       if (countNodes(storedBlockInfo).liveReplicas() > inode.getReplication())
/*      */       {
/* 2267 */         invalidateBlock(storedBlockInfo, node);
/*      */       }
/*      */       else
/* 2270 */         updateNeededReplications(storedBlockInfo, -1, 0);
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized void invalidateBlock(Block blk, DatanodeInfo dn)
/*      */     throws IOException
/*      */   {
/* 2280 */     NameNode.stateChangeLog.info(new StringBuilder().append("DIR* invalidateBlock: ").append(blk).append(" on ").append(dn.getName()).toString());
/*      */ 
/* 2283 */     DatanodeDescriptor node = getDatanode(dn);
/* 2284 */     if (node == null) {
/* 2285 */       throw new IOException(new StringBuilder().append("Cannot invalidate ").append(blk).append(" because datanode ").append(dn.getName()).append(" does not exist").toString());
/*      */     }
/*      */ 
/* 2292 */     int count = countNodes(blk).liveReplicas();
/* 2293 */     if (count > 1) {
/* 2294 */       addToInvalidates(blk, dn);
/* 2295 */       removeStoredBlock(blk, node);
/* 2296 */       NameNode.stateChangeLog.debug(new StringBuilder().append("BLOCK* invalidateBlocks: ").append(blk).append(" on ").append(dn.getName()).append(" listed for deletion").toString());
/*      */     }
/*      */     else
/*      */     {
/* 2300 */       NameNode.stateChangeLog.info(new StringBuilder().append("BLOCK* invalidateBlocks: ").append(blk).append(" on ").append(dn.getName()).append(" is the only copy and was not deleted").toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean renameTo(String src, String dst)
/*      */     throws IOException
/*      */   {
/* 2319 */     boolean status = renameToInternal(src, dst);
/* 2320 */     getEditLog().logSync();
/* 2321 */     if ((status) && (auditLog.isInfoEnabled()) && (isExternalInvocation())) {
/* 2322 */       HdfsFileStatus stat = this.dir.getFileInfo(dst);
/* 2323 */       logAuditEvent(UserGroupInformation.getCurrentUser(), Server.getRemoteIp(), "rename", src, dst, stat);
/*      */     }
/*      */ 
/* 2327 */     return status;
/*      */   }
/*      */ 
/*      */   private boolean renameToInternal(String src, String dst) throws IOException
/*      */   {
/* 2332 */     NameNode.stateChangeLog.debug(new StringBuilder().append("DIR* renameTo: ").append(src).append(" to ").append(dst).toString());
/* 2333 */     FSPermissionChecker pc = getPermissionChecker();
/* 2334 */     synchronized (this) {
/* 2335 */       if (isInSafeMode())
/* 2336 */         throw new SafeModeException(new StringBuilder().append("Cannot rename ").append(src).toString(), this.safeMode);
/* 2337 */       if (!DFSUtil.isValidName(dst)) {
/* 2338 */         throw new IOException(new StringBuilder().append("Invalid name: ").append(dst).toString());
/*      */       }
/*      */ 
/* 2341 */       if (this.isPermissionEnabled)
/*      */       {
/* 2344 */         String actualdst = this.dir.isDir(dst) ? new StringBuilder().append(dst).append("/").append(new Path(src).getName()).toString() : dst;
/*      */ 
/* 2346 */         checkParentAccess(pc, src, FsAction.WRITE);
/* 2347 */         checkAncestorAccess(pc, actualdst, FsAction.WRITE);
/*      */       }
/*      */ 
/* 2350 */       HdfsFileStatus dinfo = this.dir.getFileInfo(dst);
/* 2351 */       if (this.dir.renameTo(src, dst)) {
/* 2352 */         changeLease(src, dst, dinfo);
/* 2353 */         return true;
/*      */       }
/*      */     }
/* 2356 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean delete(String src, boolean recursive)
/*      */     throws IOException
/*      */   {
/* 2364 */     if ((!recursive) && (!this.dir.isDirEmpty(src))) {
/* 2365 */       throw new IOException(new StringBuilder().append(src).append(" is non empty").toString());
/*      */     }
/* 2367 */     if (NameNode.stateChangeLog.isDebugEnabled()) {
/* 2368 */       NameNode.stateChangeLog.debug(new StringBuilder().append("DIR* delete: ").append(src).toString());
/*      */     }
/* 2370 */     boolean status = deleteInternal(src, true);
/* 2371 */     if ((status) && (auditLog.isInfoEnabled()) && (isExternalInvocation())) {
/* 2372 */       logAuditEvent(UserGroupInformation.getCurrentUser(), Server.getRemoteIp(), "delete", src, null, null);
/*      */     }
/*      */ 
/* 2376 */     return status;
/*      */   }
/*      */ 
/*      */   private boolean deleteInternal(String src, boolean enforcePermission)
/*      */     throws IOException
/*      */   {
/* 2390 */     FSPermissionChecker pc = getPermissionChecker();
/* 2391 */     ArrayList collectedBlocks = new ArrayList();
/* 2392 */     synchronized (this) {
/* 2393 */       if (isInSafeMode()) {
/* 2394 */         throw new SafeModeException(new StringBuilder().append("Cannot delete ").append(src).toString(), this.safeMode);
/*      */       }
/* 2396 */       if ((enforcePermission) && (this.isPermissionEnabled)) {
/* 2397 */         checkPermission(pc, src, false, null, FsAction.WRITE, null, FsAction.ALL);
/*      */       }
/*      */ 
/* 2401 */       if (!this.dir.delete(src, collectedBlocks)) {
/* 2402 */         return false;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2407 */     getEditLog().logSync();
/* 2408 */     removeBlocks(collectedBlocks);
/* 2409 */     collectedBlocks.clear();
/* 2410 */     if (NameNode.stateChangeLog.isDebugEnabled()) {
/* 2411 */       NameNode.stateChangeLog.debug(new StringBuilder().append("DIR* delete: ").append(src).append(" is removed").toString());
/*      */     }
/*      */ 
/* 2414 */     return true;
/*      */   }
/*      */ 
/*      */   private void removeBlocks(List<Block> blocks)
/*      */   {
/* 2419 */     int start = 0;
/* 2420 */     int end = 0;
/* 2421 */     while (start < blocks.size()) {
/* 2422 */       end = BLOCK_DELETION_INCREMENT + start;
/* 2423 */       end = end > blocks.size() ? blocks.size() : end;
/* 2424 */       synchronized (this) {
/* 2425 */         for (int i = start; i < end; i++) {
/* 2426 */           Block b = (Block)blocks.get(i);
/* 2427 */           this.blocksMap.removeINode(b);
/* 2428 */           this.corruptReplicas.removeFromCorruptReplicasMap(b);
/*      */ 
/* 2430 */           if (this.pendingReplications != null) {
/* 2431 */             this.pendingReplications.remove(b);
/*      */           }
/* 2433 */           addToInvalidates(b);
/*      */         }
/*      */       }
/* 2436 */       start = end;
/*      */     }
/*      */   }
/*      */ 
/*      */   void removePathAndBlocks(String src, List<Block> blocks) {
/* 2441 */     this.leaseManager.removeLeaseWithPrefixPath(src);
/* 2442 */     if (blocks == null) {
/* 2443 */       return;
/*      */     }
/* 2445 */     removeBlocks(blocks);
/*      */   }
/*      */ 
/*      */   HdfsFileStatus getFileInfo(String src)
/*      */     throws IOException
/*      */   {
/* 2455 */     FSPermissionChecker pc = getPermissionChecker();
/* 2456 */     synchronized (this) {
/* 2457 */       if (this.isPermissionEnabled) {
/* 2458 */         checkTraverse(pc, src);
/*      */       }
/* 2460 */       return this.dir.getFileInfo(src);
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean mkdirs(String src, PermissionStatus permissions)
/*      */     throws IOException
/*      */   {
/* 2469 */     boolean status = mkdirsInternal(src, permissions);
/* 2470 */     getEditLog().logSync();
/* 2471 */     if ((status) && (auditLog.isInfoEnabled()) && (isExternalInvocation())) {
/* 2472 */       HdfsFileStatus stat = this.dir.getFileInfo(src);
/* 2473 */       logAuditEvent(UserGroupInformation.getCurrentUser(), Server.getRemoteIp(), "mkdirs", src, null, stat);
/*      */     }
/*      */ 
/* 2477 */     return status;
/*      */   }
/*      */ 
/*      */   private boolean mkdirsInternal(String src, PermissionStatus permissions)
/*      */     throws IOException
/*      */   {
/* 2485 */     NameNode.stateChangeLog.debug(new StringBuilder().append("DIR* mkdirs: ").append(src).toString());
/* 2486 */     FSPermissionChecker pc = getPermissionChecker();
/* 2487 */     synchronized (this) {
/* 2488 */       if (this.isPermissionEnabled) {
/* 2489 */         checkTraverse(pc, src);
/*      */       }
/* 2491 */       if (this.dir.isDir(src))
/*      */       {
/* 2494 */         return true;
/*      */       }
/* 2496 */       if (isInSafeMode())
/* 2497 */         throw new SafeModeException(new StringBuilder().append("Cannot create directory ").append(src).toString(), this.safeMode);
/* 2498 */       if (!DFSUtil.isValidName(src)) {
/* 2499 */         throw new IOException(new StringBuilder().append("Invalid directory name: ").append(src).toString());
/*      */       }
/* 2501 */       if (this.isPermissionEnabled) {
/* 2502 */         checkAncestorAccess(pc, src, FsAction.WRITE);
/*      */       }
/*      */ 
/* 2508 */       checkFsObjectLimit();
/*      */ 
/* 2510 */       if (!this.dir.mkdirs(src, permissions, false, now())) {
/* 2511 */         throw new IOException(new StringBuilder().append("Invalid directory name: ").append(src).toString());
/*      */       }
/* 2513 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   ContentSummary getContentSummary(String src) throws IOException {
/* 2518 */     FSPermissionChecker pc = getPermissionChecker();
/* 2519 */     synchronized (this) {
/* 2520 */       if (this.isPermissionEnabled) {
/* 2521 */         checkPermission(pc, src, false, null, null, null, FsAction.READ_EXECUTE);
/*      */       }
/* 2523 */       return this.dir.getContentSummary(src);
/*      */     }
/*      */   }
/*      */ 
/*      */   void setQuota(String path, long nsQuota, long dsQuota)
/*      */     throws IOException
/*      */   {
/* 2533 */     checkSuperuserPrivilege();
/* 2534 */     synchronized (this) {
/* 2535 */       if (isInSafeMode()) {
/* 2536 */         throw new SafeModeException(new StringBuilder().append("Cannot set quota on ").append(path).toString(), this.safeMode);
/*      */       }
/* 2538 */       this.dir.setQuota(path, nsQuota, dsQuota);
/*      */     }
/* 2540 */     getEditLog().logSync();
/*      */   }
/*      */ 
/*      */   void fsync(String src, String clientName)
/*      */     throws IOException
/*      */   {
/* 2550 */     NameNode.stateChangeLog.info(new StringBuilder().append("BLOCK* fsync: ").append(src).append(" for ").append(clientName).toString());
/*      */ 
/* 2552 */     synchronized (this) {
/* 2553 */       if (isInSafeMode()) {
/* 2554 */         throw new SafeModeException(new StringBuilder().append("Cannot fsync ").append(src).toString(), this.safeMode);
/*      */       }
/* 2556 */       INodeFileUnderConstruction pendingFile = checkLease(src, clientName);
/* 2557 */       this.dir.persistBlocks(src, pendingFile);
/*      */     }
/* 2559 */     getEditLog().logSync();
/*      */   }
/*      */ 
/*      */   void internalReleaseLease(LeaseManager.Lease lease, String src)
/*      */     throws IOException
/*      */   {
/* 2568 */     if (lease.hasPath())
/*      */     {
/* 2571 */       String[] leasePaths = new String[lease.getPaths().size()];
/* 2572 */       lease.getPaths().toArray(leasePaths);
/* 2573 */       for (String p : leasePaths)
/* 2574 */         internalReleaseLeaseOne(lease, p);
/*      */     }
/*      */     else {
/* 2577 */       internalReleaseLeaseOne(lease, src);
/*      */     }
/*      */   }
/*      */ 
/*      */   void internalReleaseLeaseOne(LeaseManager.Lease lease, String src)
/*      */     throws IOException
/*      */   {
/* 2587 */     assert (Thread.holdsLock(this));
/*      */ 
/* 2589 */     LOG.info(new StringBuilder().append("Recovering lease=").append(lease).append(", src=").append(src).toString());
/*      */ 
/* 2591 */     INodeFile iFile = this.dir.getFileINode(src);
/* 2592 */     if (iFile == null) {
/* 2593 */       String message = new StringBuilder().append("DIR* internalReleaseCreate: attempt to release a create lock on ").append(src).append(" file does not exist").toString();
/*      */ 
/* 2596 */       NameNode.stateChangeLog.warn(message);
/* 2597 */       throw new IOException(message);
/*      */     }
/* 2599 */     if (!iFile.isUnderConstruction()) {
/* 2600 */       String message = new StringBuilder().append("DIR* internalReleaseCreate: attempt to release a create lock on ").append(src).append(" but file is already closed").toString();
/*      */ 
/* 2603 */       NameNode.stateChangeLog.warn(message);
/* 2604 */       throw new IOException(message);
/*      */     }
/*      */ 
/* 2607 */     INodeFileUnderConstruction pendingFile = (INodeFileUnderConstruction)iFile;
/*      */ 
/* 2612 */     if ((pendingFile.getTargets() == null) || (pendingFile.getTargets().length == 0))
/*      */     {
/* 2614 */       if (pendingFile.getBlocks().length == 0) {
/* 2615 */         finalizeINodeFileUnderConstruction(src, pendingFile);
/* 2616 */         NameNode.stateChangeLog.warn(new StringBuilder().append("BLOCK* internalReleaseLease: No blocks found, lease removed for ").append(src).toString());
/*      */ 
/* 2618 */         return;
/*      */       }
/*      */ 
/* 2622 */       Block[] blocks = pendingFile.getBlocks();
/* 2623 */       Block last = blocks[(blocks.length - 1)];
/* 2624 */       DatanodeDescriptor[] targets = new DatanodeDescriptor[this.blocksMap.numNodes(last)];
/*      */ 
/* 2626 */       Iterator it = this.blocksMap.nodeIterator(last);
/* 2627 */       for (int i = 0; (it != null) && (it.hasNext()); i++) {
/* 2628 */         targets[i] = ((DatanodeDescriptor)it.next());
/*      */       }
/* 2630 */       pendingFile.setTargets(targets);
/*      */     }
/*      */ 
/* 2633 */     pendingFile.assignPrimaryDatanode();
/* 2634 */     LeaseManager.Lease reassignedLease = reassignLease(lease, src, "NN_Recovery", pendingFile);
/*      */ 
/* 2636 */     this.leaseManager.renewLease(reassignedLease);
/*      */   }
/*      */ 
/*      */   private LeaseManager.Lease reassignLease(LeaseManager.Lease lease, String src, String newHolder, INodeFileUnderConstruction pendingFile)
/*      */   {
/* 2641 */     if (newHolder == null)
/* 2642 */       return lease;
/* 2643 */     pendingFile.setClientName(newHolder);
/* 2644 */     return this.leaseManager.reassignLease(lease, src, newHolder);
/*      */   }
/*      */ 
/*      */   private void finalizeINodeFileUnderConstruction(String src, INodeFileUnderConstruction pendingFile)
/*      */     throws IOException
/*      */   {
/* 2650 */     NameNode.stateChangeLog.info(new StringBuilder().append("Removing lease on  ").append(src).append(" from client ").append(pendingFile.clientName).toString());
/*      */ 
/* 2652 */     this.leaseManager.removeLease(pendingFile.clientName, src);
/*      */ 
/* 2656 */     INodeFile newFile = pendingFile.convertToInodeFile();
/* 2657 */     this.dir.replaceNode(src, pendingFile, newFile);
/*      */ 
/* 2660 */     this.dir.closeFile(src, newFile);
/*      */ 
/* 2662 */     checkReplicationFactor(newFile);
/*      */   }
/*      */ 
/*      */   public void commitBlockSynchronization(Block lastblock, long newgenerationstamp, long newlength, boolean closeFile, boolean deleteblock, DatanodeID[] newtargets)
/*      */     throws IOException
/*      */   {
/* 2669 */     LOG.info(new StringBuilder().append("commitBlockSynchronization(lastblock=").append(lastblock).append(", newgenerationstamp=").append(newgenerationstamp).append(", newlength=").append(newlength).append(", newtargets=").append(Arrays.asList(newtargets)).append(", closeFile=").append(closeFile).append(", deleteBlock=").append(deleteblock).append(")").toString());
/*      */ 
/* 2676 */     String src = null;
/*      */     try {
/* 2678 */       synchronized (this) {
/* 2679 */         if (isInSafeMode()) {
/* 2680 */           throw new SafeModeException(new StringBuilder().append("Cannot commitBlockSynchronization ").append(lastblock).toString(), this.safeMode);
/*      */         }
/*      */ 
/* 2683 */         BlocksMap.BlockInfo oldblockinfo = this.blocksMap.getStoredBlock(lastblock);
/* 2684 */         if (oldblockinfo == null) {
/* 2685 */           throw new IOException(new StringBuilder().append("Block (=").append(lastblock).append(") not found").toString());
/*      */         }
/* 2687 */         INodeFile iFile = oldblockinfo.getINode();
/* 2688 */         if (!iFile.isUnderConstruction()) {
/* 2689 */           throw new IOException(new StringBuilder().append("Unexpected block (=").append(lastblock).append(") since the file (=").append(iFile.getLocalName()).append(") is not under construction").toString());
/*      */         }
/*      */ 
/* 2693 */         INodeFileUnderConstruction pendingFile = (INodeFileUnderConstruction)iFile;
/*      */ 
/* 2698 */         this.blocksMap.removeBlock(oldblockinfo);
/*      */ 
/* 2700 */         if (deleteblock) {
/* 2701 */           pendingFile.removeBlock(lastblock);
/*      */         }
/*      */         else {
/* 2704 */           lastblock.set(lastblock.getBlockId(), newlength, newgenerationstamp);
/* 2705 */           BlocksMap.BlockInfo newblockinfo = this.blocksMap.addINode(lastblock, pendingFile);
/*      */ 
/* 2710 */           DatanodeDescriptor[] descriptors = null;
/* 2711 */           List descriptorsList = new ArrayList(newtargets.length);
/*      */ 
/* 2713 */           for (int i = 0; i < newtargets.length; i++) {
/* 2714 */             DatanodeDescriptor node = (DatanodeDescriptor)this.datanodeMap.get(newtargets[i].getStorageID());
/*      */ 
/* 2716 */             if (node != null) {
/* 2717 */               if (closeFile)
/*      */               {
/* 2722 */                 node.addBlock(newblockinfo);
/*      */               }
/* 2724 */               descriptorsList.add(node);
/*      */             } else {
/* 2726 */               LOG.error(new StringBuilder().append("commitBlockSynchronization included a target DN ").append(newtargets[i]).append(" which is not known to NN. Ignoring").toString());
/*      */             }
/*      */           }
/*      */ 
/* 2730 */           if (!descriptorsList.isEmpty()) {
/* 2731 */             descriptors = (DatanodeDescriptor[])descriptorsList.toArray(new DatanodeDescriptor[0]);
/*      */           }
/*      */ 
/* 2734 */           pendingFile.setLastBlock(newblockinfo, descriptors);
/*      */         }
/*      */ 
/* 2739 */         src = this.leaseManager.findPath(pendingFile);
/* 2740 */         if (!closeFile) {
/* 2741 */           if (this.durableSync) {
/* 2742 */             this.dir.persistBlocks(src, pendingFile);
/*      */           }
/* 2744 */           LOG.info(new StringBuilder().append("commitBlockSynchronization(").append(lastblock).append(") successful").toString());
/*      */ 
/* 2752 */           if ((closeFile) || (this.durableSync))
/* 2753 */             getEditLog().logSync();
/*      */           return;
/*      */         }
/* 2749 */         finalizeINodeFileUnderConstruction(src, pendingFile);
/*      */       }
/*      */     } finally {
/* 2752 */       if ((closeFile) || (this.durableSync)) {
/* 2753 */         getEditLog().logSync();
/*      */       }
/*      */     }
/* 2756 */     if (closeFile)
/* 2757 */       LOG.info(new StringBuilder().append("commitBlockSynchronization(newblock=").append(lastblock).append(", file=").append(src).append(", newgenerationstamp=").append(newgenerationstamp).append(", newlength=").append(newlength).append(", newtargets=").append(Arrays.asList(newtargets)).append(") successful").toString());
/*      */   }
/*      */ 
/*      */   synchronized void renewLease(String holder)
/*      */     throws IOException
/*      */   {
/* 2770 */     if (isInSafeMode())
/* 2771 */       throw new SafeModeException(new StringBuilder().append("Cannot renew lease for ").append(holder).toString(), this.safeMode);
/* 2772 */     this.leaseManager.renewLease(holder);
/*      */   }
/*      */ 
/*      */   public DirectoryListing getListing(String src, byte[] startAfter)
/*      */     throws IOException
/*      */   {
/* 2784 */     FSPermissionChecker pc = getPermissionChecker();
/* 2785 */     synchronized (this) {
/* 2786 */       if (this.isPermissionEnabled) {
/* 2787 */         if (this.dir.isDir(src))
/* 2788 */           checkPathAccess(pc, src, FsAction.READ_EXECUTE);
/*      */         else {
/* 2790 */           checkTraverse(pc, src);
/*      */         }
/*      */       }
/* 2793 */       if ((auditLog.isInfoEnabled()) && (isExternalInvocation())) {
/* 2794 */         logAuditEvent(UserGroupInformation.getCurrentUser(), Server.getRemoteIp(), "listStatus", src, null, null);
/*      */       }
/*      */ 
/* 2797 */       return this.dir.getListing(src, startAfter);
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void registerDatanode(DatanodeRegistration nodeReg)
/*      */     throws IOException
/*      */   {
/* 2831 */     String dnAddress = Server.getRemoteAddress();
/* 2832 */     if (dnAddress == null)
/*      */     {
/* 2835 */       dnAddress = nodeReg.getHost();
/*      */     }
/*      */ 
/* 2839 */     if (!verifyNodeRegistration(nodeReg, dnAddress)) {
/* 2840 */       throw new DisallowedDatanodeException(nodeReg);
/*      */     }
/*      */ 
/* 2843 */     String hostName = nodeReg.getHost();
/*      */ 
/* 2846 */     DatanodeID dnReg = new DatanodeID(new StringBuilder().append(dnAddress).append(":").append(nodeReg.getPort()).toString(), nodeReg.getStorageID(), nodeReg.getInfoPort(), nodeReg.getIpcPort());
/*      */ 
/* 2850 */     nodeReg.updateRegInfo(dnReg);
/* 2851 */     nodeReg.exportedKeys = getBlockKeys();
/*      */ 
/* 2853 */     NameNode.stateChangeLog.info(new StringBuilder().append("BLOCK* registerDatanode: node registration from ").append(nodeReg.getName()).append(" storage ").append(nodeReg.getStorageID()).toString());
/*      */ 
/* 2858 */     DatanodeDescriptor nodeS = (DatanodeDescriptor)this.datanodeMap.get(nodeReg.getStorageID());
/* 2859 */     DatanodeDescriptor nodeN = this.host2DataNodeMap.getDatanodeByName(nodeReg.getName());
/*      */ 
/* 2861 */     if ((nodeN != null) && (nodeN != nodeS)) {
/* 2862 */       NameNode.LOG.info(new StringBuilder().append("BLOCK* registerDatanode: node from name: ").append(nodeN.getName()).toString());
/*      */ 
/* 2866 */       removeDatanode(nodeN);
/*      */ 
/* 2868 */       wipeDatanode(nodeN);
/* 2869 */       nodeN = null;
/*      */     }
/*      */ 
/* 2872 */     if (nodeS != null) {
/* 2873 */       if (nodeN == nodeS)
/*      */       {
/* 2877 */         NameNode.stateChangeLog.debug("BLOCK* registerDatanode: node restarted");
/*      */       }
/*      */       else
/*      */       {
/* 2889 */         NameNode.stateChangeLog.info(new StringBuilder().append("BLOCK* registerDatanode: node ").append(nodeS.getName()).append(" is replaced by ").append(nodeReg.getName()).append(" with the same storageID ").append(nodeReg.getStorageID()).toString());
/*      */       }
/*      */ 
/* 2896 */       this.clusterMap.remove(nodeS);
/* 2897 */       nodeS.updateRegInfo(nodeReg);
/* 2898 */       nodeS.setHostName(hostName);
/*      */ 
/* 2901 */       resolveNetworkLocation(nodeS);
/* 2902 */       this.clusterMap.add(nodeS);
/*      */ 
/* 2905 */       synchronized (this.heartbeats) {
/* 2906 */         if (!this.heartbeats.contains(nodeS)) {
/* 2907 */           this.heartbeats.add(nodeS);
/*      */ 
/* 2909 */           nodeS.updateHeartbeat(0L, 0L, 0L, 0);
/* 2910 */           nodeS.isAlive = true;
/*      */         }
/*      */       }
/* 2913 */       return;
/*      */     }
/*      */ 
/* 2917 */     if (nodeReg.getStorageID().equals(""))
/*      */     {
/* 2920 */       nodeReg.storageID = newStorageID();
/* 2921 */       NameNode.stateChangeLog.debug(new StringBuilder().append("BLOCK* registerDatanode: new storageID ").append(nodeReg.getStorageID()).append(" assigned").toString());
/*      */     }
/*      */ 
/* 2926 */     DatanodeDescriptor nodeDescr = new DatanodeDescriptor(nodeReg, "/default-rack", hostName);
/*      */ 
/* 2928 */     resolveNetworkLocation(nodeDescr);
/* 2929 */     unprotectedAddDatanode(nodeDescr);
/* 2930 */     this.clusterMap.add(nodeDescr);
/*      */ 
/* 2933 */     synchronized (this.heartbeats) {
/* 2934 */       this.heartbeats.add(nodeDescr);
/* 2935 */       nodeDescr.isAlive = true;
/*      */     }
/*      */ 
/* 2940 */     if (this.safeMode != null)
/* 2941 */       this.safeMode.checkMode();
/*      */   }
/*      */ 
/*      */   private void resolveNetworkLocation(DatanodeDescriptor node)
/*      */   {
/* 2948 */     List names = new ArrayList(1);
/* 2949 */     if ((this.dnsToSwitchMapping instanceof CachedDNSToSwitchMapping))
/*      */     {
/* 2951 */       names.add(node.getHost());
/*      */     }
/*      */     else {
/* 2954 */       String hostName = node.getHostName();
/* 2955 */       int colon = hostName.indexOf(":");
/* 2956 */       hostName = colon == -1 ? hostName : hostName.substring(0, colon);
/* 2957 */       names.add(hostName);
/*      */     }
/*      */ 
/* 2961 */     List rName = this.dnsToSwitchMapping.resolve(names);
/*      */     String networkLocation;
/*      */     String networkLocation;
/* 2963 */     if (rName == null) {
/* 2964 */       LOG.error(new StringBuilder().append("The resolve call returned null! Using /default-rack for host ").append(names).toString());
/*      */ 
/* 2966 */       networkLocation = "/default-rack";
/*      */     } else {
/* 2968 */       networkLocation = (String)rName.get(0);
/*      */     }
/* 2970 */     node.setNetworkLocation(networkLocation);
/*      */   }
/*      */ 
/*      */   public String getRegistrationID()
/*      */   {
/* 2981 */     return Storage.getRegistrationID(this.dir.fsImage);
/*      */   }
/*      */ 
/*      */   private String newStorageID()
/*      */   {
/* 2993 */     String newID = null;
/* 2994 */     while (newID == null) {
/* 2995 */       newID = new StringBuilder().append("DS").append(Integer.toString(this.r.nextInt())).toString();
/* 2996 */       if (this.datanodeMap.get(newID) != null)
/* 2997 */         newID = null;
/*      */     }
/* 2999 */     return newID;
/*      */   }
/*      */ 
/*      */   private boolean isDatanodeDead(DatanodeDescriptor node) {
/* 3003 */     return node.getLastUpdate() < now() - this.heartbeatExpireInterval;
/*      */   }
/*      */ 
/*      */   private void setDatanodeDead(DatanodeDescriptor node)
/*      */   {
/* 3008 */     node.setLastUpdate(0L);
/*      */   }
/*      */ 
/*      */   DatanodeCommand[] handleHeartbeat(DatanodeRegistration nodeReg, long capacity, long dfsUsed, long remaining, int xceiverCount, int xmitsInProgress)
/*      */     throws IOException
/*      */   {
/* 3025 */     DatanodeCommand cmd = null;
/* 3026 */     synchronized (this.heartbeats) {
/* 3027 */       synchronized (this.datanodeMap) {
/* 3028 */         DatanodeDescriptor nodeinfo = null;
/*      */         try {
/* 3030 */           nodeinfo = getDatanode(nodeReg);
/*      */         } catch (UnregisteredDatanodeException e) {
/* 3032 */           return new DatanodeCommand[] { DatanodeCommand.REGISTER };
/*      */         }
/*      */ 
/* 3036 */         if ((nodeinfo != null) && (shouldNodeShutdown(nodeinfo))) {
/* 3037 */           setDatanodeDead(nodeinfo);
/* 3038 */           throw new DisallowedDatanodeException(nodeinfo);
/*      */         }
/*      */ 
/* 3041 */         if ((nodeinfo == null) || (!nodeinfo.isAlive)) {
/* 3042 */           return new DatanodeCommand[] { DatanodeCommand.REGISTER };
/*      */         }
/*      */ 
/* 3045 */         updateStats(nodeinfo, false);
/* 3046 */         nodeinfo.updateHeartbeat(capacity, dfsUsed, remaining, xceiverCount);
/* 3047 */         updateStats(nodeinfo, true);
/*      */ 
/* 3050 */         cmd = nodeinfo.getLeaseRecoveryCommand(2147483647);
/* 3051 */         if (cmd != null) {
/* 3052 */           return new DatanodeCommand[] { cmd };
/*      */         }
/*      */ 
/* 3055 */         ArrayList cmds = new ArrayList();
/*      */ 
/* 3057 */         cmd = nodeinfo.getReplicationCommand(this.maxReplicationStreams - xmitsInProgress);
/*      */ 
/* 3059 */         if (cmd != null) {
/* 3060 */           cmds.add(cmd);
/*      */         }
/*      */ 
/* 3063 */         cmd = nodeinfo.getInvalidateBlocks(this.blockInvalidateLimit);
/* 3064 */         if (cmd != null) {
/* 3065 */           cmds.add(cmd);
/*      */         }
/*      */ 
/* 3068 */         if ((this.isAccessTokenEnabled) && (nodeinfo.needKeyUpdate)) {
/* 3069 */           cmds.add(new KeyUpdateCommand(this.accessTokenHandler.exportKeys()));
/* 3070 */           nodeinfo.needKeyUpdate = false;
/*      */         }
/*      */ 
/* 3073 */         if (nodeinfo.getBalancerBandwidth() > 0L) {
/* 3074 */           cmds.add(new BalancerBandwidthCommand(nodeinfo.getBalancerBandwidth()));
/*      */ 
/* 3076 */           nodeinfo.setBalancerBandwidth(0L);
/*      */         }
/* 3078 */         if (!cmds.isEmpty()) {
/* 3079 */           return (DatanodeCommand[])cmds.toArray(new DatanodeCommand[cmds.size()]);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 3085 */     cmd = getDistributedUpgradeCommand();
/* 3086 */     if (cmd != null) {
/* 3087 */       return new DatanodeCommand[] { cmd };
/*      */     }
/* 3089 */     return null;
/*      */   }
/*      */ 
/*      */   private void updateStats(DatanodeDescriptor node, boolean isAdded)
/*      */   {
/* 3096 */     assert (Thread.holdsLock(this.heartbeats));
/* 3097 */     if (isAdded) {
/* 3098 */       this.capacityTotal += node.getCapacity();
/* 3099 */       this.capacityUsed += node.getDfsUsed();
/* 3100 */       this.capacityRemaining += node.getRemaining();
/* 3101 */       this.totalLoad += node.getXceiverCount();
/*      */     } else {
/* 3103 */       this.capacityTotal -= node.getCapacity();
/* 3104 */       this.capacityUsed -= node.getDfsUsed();
/* 3105 */       this.capacityRemaining -= node.getRemaining();
/* 3106 */       this.totalLoad -= node.getXceiverCount();
/*      */     }
/*      */   }
/*      */ 
/*      */   void updateAccessKey()
/*      */     throws IOException
/*      */   {
/* 3114 */     this.accessTokenHandler.updateKeys();
/* 3115 */     synchronized (this.heartbeats) {
/* 3116 */       for (DatanodeDescriptor nodeInfo : this.heartbeats)
/* 3117 */         nodeInfo.needKeyUpdate = true;
/*      */     }
/*      */   }
/*      */ 
/*      */   public int computeDatanodeWork()
/*      */     throws IOException
/*      */   {
/* 3250 */     int replicationWorkFound = 0;
/* 3251 */     int invalidationWorkFound = 0;
/* 3252 */     int blocksToProcess = 0;
/* 3253 */     int nodesToProcess = 0;
/*      */ 
/* 3256 */     if (isInSafeMode()) {
/* 3257 */       this.replmon.replicateQueueStats.checkRestart();
/* 3258 */       this.replmon.invalidateQueueStats.checkRestart();
/* 3259 */       return 0;
/*      */     }
/* 3261 */     synchronized (this.heartbeats) {
/* 3262 */       blocksToProcess = this.heartbeats.size() * this.blocksReplWorkMultiplier;
/*      */ 
/* 3264 */       nodesToProcess = (int)Math.ceil(this.heartbeats.size() * this.blocksInvalidateWorkPct);
/*      */     }
/*      */ 
/* 3268 */     this.replmon.replicateQueueStats.startCycle(blocksToProcess);
/* 3269 */     replicationWorkFound = computeReplicationWork(blocksToProcess);
/* 3270 */     this.replmon.replicateQueueStats.endCycle(replicationWorkFound);
/*      */ 
/* 3273 */     synchronized (this) {
/* 3274 */       this.pendingReplicationBlocksCount = this.pendingReplications.size();
/* 3275 */       this.underReplicatedBlocksCount = this.neededReplications.size();
/* 3276 */       this.scheduledReplicationBlocksCount = replicationWorkFound;
/* 3277 */       this.corruptReplicaBlocksCount = this.corruptReplicas.size();
/*      */     }
/*      */ 
/* 3280 */     this.replmon.invalidateQueueStats.startCycle(nodesToProcess);
/* 3281 */     invalidationWorkFound = computeInvalidateWork(nodesToProcess);
/* 3282 */     this.replmon.invalidateQueueStats.endCycle(invalidationWorkFound);
/*      */ 
/* 3284 */     return replicationWorkFound + invalidationWorkFound;
/*      */   }
/*      */ 
/*      */   int computeInvalidateWork(int nodesToProcess)
/*      */   {
/* 3293 */     int numOfNodes = 0;
/*      */     ArrayList keyArray;
/* 3295 */     synchronized (this) {
/* 3296 */       numOfNodes = this.recentInvalidateSets.size();
/*      */ 
/* 3298 */       keyArray = new ArrayList(this.recentInvalidateSets.keySet());
/*      */     }
/* 3300 */     nodesToProcess = Math.min(numOfNodes, nodesToProcess);
/*      */ 
/* 3304 */     int remainingNodes = numOfNodes - nodesToProcess;
/* 3305 */     if (nodesToProcess < remainingNodes)
/* 3306 */       for (int i = 0; i < nodesToProcess; i++) {
/* 3307 */         int keyIndex = this.r.nextInt(numOfNodes - i) + i;
/* 3308 */         Collections.swap(keyArray, keyIndex, i);
/*      */       }
/*      */     else {
/* 3311 */       for (int i = 0; i < remainingNodes; i++) {
/* 3312 */         int keyIndex = this.r.nextInt(numOfNodes - i);
/* 3313 */         Collections.swap(keyArray, keyIndex, numOfNodes - i - 1);
/*      */       }
/*      */     }
/*      */ 
/* 3317 */     int blockCnt = 0;
/* 3318 */     for (int nodeCnt = 0; nodeCnt < nodesToProcess; nodeCnt++) {
/* 3319 */       blockCnt += invalidateWorkForOneNode((String)keyArray.get(nodeCnt));
/*      */     }
/* 3321 */     return blockCnt;
/*      */   }
/*      */ 
/*      */   private int computeReplicationWork(int blocksToProcess)
/*      */     throws IOException
/*      */   {
/* 3336 */     if (this.stallReplicationWork) {
/* 3337 */       return 0;
/*      */     }
/*      */ 
/* 3341 */     List blocksToReplicate = chooseUnderReplicatedBlocks(blocksToProcess);
/*      */ 
/* 3345 */     int scheduledReplicationCount = 0;
/* 3346 */     for (int i = 0; i < blocksToReplicate.size(); i++) {
/* 3347 */       for (Block block : (List)blocksToReplicate.get(i)) {
/* 3348 */         if (computeReplicationWorkForBlock(block, i)) {
/* 3349 */           scheduledReplicationCount++;
/*      */         }
/*      */       }
/*      */     }
/* 3353 */     return scheduledReplicationCount;
/*      */   }
/*      */ 
/*      */   synchronized List<List<Block>> chooseUnderReplicatedBlocks(int blocksToProcess)
/*      */   {
/* 3365 */     List blocksToReplicate = new ArrayList(3);
/*      */ 
/* 3367 */     for (int i = 0; i < 3; i++) {
/* 3368 */       blocksToReplicate.add(new ArrayList());
/*      */     }
/*      */ 
/* 3371 */     synchronized (this.neededReplications) {
/* 3372 */       if (this.neededReplications.size() == 0) {
/* 3373 */         this.missingBlocksInCurIter = 0L;
/* 3374 */         this.missingBlocksInPrevIter = 0L;
/* 3375 */         return blocksToReplicate;
/*      */       }
/*      */ 
/* 3379 */       UnderReplicatedBlocks.BlockIterator neededReplicationsIterator = this.neededReplications.iterator();
/*      */ 
/* 3381 */       for (int i = 0; (i < this.replIndex) && (neededReplicationsIterator.hasNext()); i++) {
/* 3382 */         neededReplicationsIterator.next();
/*      */       }
/*      */ 
/* 3386 */       blocksToProcess = Math.min(blocksToProcess, this.neededReplications.size());
/*      */ 
/* 3388 */       for (int blkCnt = 0; blkCnt < blocksToProcess; this.replIndex += 1) {
/* 3389 */         if (!neededReplicationsIterator.hasNext())
/*      */         {
/* 3391 */           this.replIndex = 0;
/* 3392 */           this.missingBlocksInPrevIter = this.missingBlocksInCurIter;
/* 3393 */           this.missingBlocksInCurIter = 0L;
/* 3394 */           blocksToProcess = Math.min(blocksToProcess, this.neededReplications.size());
/* 3395 */           if (blkCnt >= blocksToProcess)
/*      */             break;
/* 3397 */           neededReplicationsIterator = this.neededReplications.iterator();
/*      */ 
/* 3399 */           assert (neededReplicationsIterator.hasNext()) : "neededReplications should not be empty";
/*      */         }
/*      */ 
/* 3402 */         Block block = neededReplicationsIterator.next();
/* 3403 */         int priority = neededReplicationsIterator.getPriority();
/* 3404 */         if ((priority < 0) || (priority >= blocksToReplicate.size()))
/* 3405 */           LOG.warn(new StringBuilder().append("Unexpected replication priority: ").append(priority).append(" ").append(block).toString());
/*      */         else
/* 3407 */           ((List)blocksToReplicate.get(priority)).add(block);
/* 3388 */         blkCnt++;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 3411 */     return blocksToReplicate;
/*      */   }
/*      */ 
/*      */   boolean computeReplicationWorkForBlock(Block block, int priority)
/*      */   {
/* 3425 */     INodeFile fileINode = null;
/*      */     int requiredReplication;
/*      */     List containingNodes;
/*      */     DatanodeDescriptor srcNode;
/*      */     int numEffectiveReplicas;
/* 3426 */     synchronized (this) {
/* 3427 */       synchronized (this.neededReplications)
/*      */       {
/* 3429 */         fileINode = this.blocksMap.getINode(block);
/*      */ 
/* 3431 */         if ((fileINode == null) || (fileINode.isUnderConstruction())) {
/* 3432 */           this.neededReplications.remove(block, priority);
/* 3433 */           this.replIndex -= 1;
/* 3434 */           return false;
/*      */         }
/* 3436 */         requiredReplication = fileINode.getReplication();
/*      */ 
/* 3439 */         containingNodes = new ArrayList();
/* 3440 */         NumberReplicas numReplicas = new NumberReplicas();
/* 3441 */         srcNode = chooseSourceDatanode(block, containingNodes, numReplicas);
/* 3442 */         if (numReplicas.liveReplicas() + numReplicas.decommissionedReplicas() <= 0)
/*      */         {
/* 3444 */           this.missingBlocksInCurIter += 1L;
/*      */         }
/* 3446 */         if (srcNode == null) {
/* 3447 */           return false;
/*      */         }
/*      */ 
/* 3450 */         numEffectiveReplicas = numReplicas.liveReplicas() + this.pendingReplications.getNumReplicas(block);
/*      */ 
/* 3452 */         if (numEffectiveReplicas >= requiredReplication) {
/* 3453 */           this.neededReplications.remove(block, priority);
/* 3454 */           this.replIndex -= 1;
/* 3455 */           NameNode.stateChangeLog.info(new StringBuilder().append("BLOCK* Removing ").append(block).append(" from neededReplications as it has enough replicas").toString());
/*      */ 
/* 3457 */           return false;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 3465 */     DatanodeDescriptor[] targets = this.replicator.chooseTarget(fileINode, requiredReplication - numEffectiveReplicas, srcNode, containingNodes, block.getNumBytes());
/*      */ 
/* 3468 */     if (targets.length == 0) {
/* 3469 */       return false;
/*      */     }
/* 3471 */     synchronized (this) {
/* 3472 */       synchronized (this.neededReplications)
/*      */       {
/* 3475 */         fileINode = this.blocksMap.getINode(block);
/*      */ 
/* 3477 */         if ((fileINode == null) || (fileINode.isUnderConstruction())) {
/* 3478 */           this.neededReplications.remove(block, priority);
/* 3479 */           this.replIndex -= 1;
/* 3480 */           return false;
/*      */         }
/* 3482 */         requiredReplication = fileINode.getReplication();
/*      */ 
/* 3485 */         NumberReplicas numReplicas = countNodes(block);
/* 3486 */         numEffectiveReplicas = numReplicas.liveReplicas() + this.pendingReplications.getNumReplicas(block);
/*      */ 
/* 3488 */         if (numEffectiveReplicas >= requiredReplication) {
/* 3489 */           this.neededReplications.remove(block, priority);
/* 3490 */           this.replIndex -= 1;
/* 3491 */           NameNode.stateChangeLog.info(new StringBuilder().append("BLOCK* Removing ").append(block).append(" from neededReplications as it has enough replicas").toString());
/*      */ 
/* 3493 */           return false;
/*      */         }
/*      */ 
/* 3497 */         srcNode.addBlockToBeReplicated(block, targets);
/*      */ 
/* 3499 */         for (DatanodeDescriptor dn : targets) {
/* 3500 */           dn.incBlocksScheduled();
/*      */         }
/*      */ 
/* 3506 */         this.pendingReplications.increment(block, targets.length);
/* 3507 */         NameNode.stateChangeLog.debug(new StringBuilder().append("BLOCK* ").append(block).append(" is moved from neededReplications to pendingReplications").toString());
/*      */ 
/* 3511 */         if (numEffectiveReplicas + targets.length >= requiredReplication) {
/* 3512 */           this.neededReplications.remove(block, priority);
/* 3513 */           this.replIndex -= 1;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 3518 */     if (NameNode.stateChangeLog.isInfoEnabled()) {
/* 3519 */       StringBuilder targetList = new StringBuilder("datanode(s)");
/* 3520 */       for (int k = 0; k < targets.length; k++) {
/* 3521 */         targetList.append(' ');
/* 3522 */         targetList.append(targets[k].getName());
/*      */       }
/* 3524 */       NameNode.stateChangeLog.info(new StringBuilder().append("BLOCK* ask ").append(srcNode.getName()).append(" to replicate ").append(block).append(" to ").append(targetList).toString());
/*      */ 
/* 3526 */       NameNode.stateChangeLog.debug(new StringBuilder().append("BLOCK* neededReplications = ").append(this.neededReplications.size()).append(" pendingReplications = ").append(this.pendingReplications.size()).toString());
/*      */     }
/*      */ 
/* 3531 */     return true;
/*      */   }
/*      */ 
/*      */   public DatanodeInfo chooseDatanode(String srcPath, String address, long blocksize)
/*      */   {
/* 3536 */     DatanodeDescriptor clientNode = this.host2DataNodeMap.getDatanodeByHost(address);
/*      */ 
/* 3538 */     if (clientNode != null) {
/* 3539 */       HashMap excludedNodes = null;
/* 3540 */       DatanodeDescriptor[] datanodes = this.replicator.chooseTarget(srcPath, 1, clientNode, excludedNodes, blocksize);
/*      */ 
/* 3542 */       if (datanodes.length > 0) {
/* 3543 */         return datanodes[0];
/*      */       }
/*      */     }
/* 3546 */     return null;
/*      */   }
/*      */ 
/*      */   private DatanodeDescriptor chooseSourceDatanode(Block block, List<DatanodeDescriptor> containingNodes, NumberReplicas numReplicas)
/*      */   {
/* 3566 */     containingNodes.clear();
/* 3567 */     DatanodeDescriptor srcNode = null;
/* 3568 */     int live = 0;
/* 3569 */     int decommissioned = 0;
/* 3570 */     int corrupt = 0;
/* 3571 */     int excess = 0;
/* 3572 */     Iterator it = this.blocksMap.nodeIterator(block);
/* 3573 */     Collection nodesCorrupt = this.corruptReplicas.getNodes(block);
/* 3574 */     while (it.hasNext()) {
/* 3575 */       DatanodeDescriptor node = (DatanodeDescriptor)it.next();
/* 3576 */       Collection excessBlocks = (Collection)this.excessReplicateMap.get(node.getStorageID());
/*      */ 
/* 3578 */       if ((nodesCorrupt != null) && (nodesCorrupt.contains(node)))
/* 3579 */         corrupt++;
/* 3580 */       else if ((node.isDecommissionInProgress()) || (node.isDecommissioned()))
/* 3581 */         decommissioned++;
/* 3582 */       else if ((excessBlocks != null) && (excessBlocks.contains(block)))
/* 3583 */         excess++;
/*      */       else {
/* 3585 */         live++;
/*      */       }
/* 3587 */       containingNodes.add(node);
/*      */ 
/* 3590 */       if (((nodesCorrupt == null) || (!nodesCorrupt.contains(node))) && 
/* 3592 */         (node.getNumberOfBlocksToBeReplicated() < this.maxReplicationStreams) && 
/* 3595 */         ((excessBlocks == null) || (!excessBlocks.contains(block))) && 
/* 3598 */         (!node.isDecommissioned()))
/*      */       {
/* 3601 */         if ((node.isDecommissionInProgress()) || (srcNode == null)) {
/* 3602 */           srcNode = node;
/*      */         }
/* 3605 */         else if (!srcNode.isDecommissionInProgress())
/*      */         {
/* 3610 */           if (this.r.nextBoolean())
/* 3611 */             srcNode = node; 
/*      */         }
/*      */       }
/*      */     }
/* 3613 */     if (numReplicas != null)
/* 3614 */       numReplicas.initialize(live, decommissioned, corrupt, excess);
/* 3615 */     return srcNode;
/*      */   }
/*      */ 
/*      */   private int invalidateWorkForOneNode(String nodeId)
/*      */   {
/* 3625 */     ArrayList blocksToInvalidate = new ArrayList(this.blockInvalidateLimit);
/*      */ 
/* 3627 */     DatanodeDescriptor dn = null;
/*      */ 
/* 3629 */     synchronized (this)
/*      */     {
/* 3631 */       if (isInSafeMode()) {
/* 3632 */         return 0;
/*      */       }
/* 3634 */       assert (nodeId != null);
/* 3635 */       dn = (DatanodeDescriptor)this.datanodeMap.get(nodeId);
/* 3636 */       if (dn == null) {
/* 3637 */         this.recentInvalidateSets.remove(nodeId);
/* 3638 */         return 0;
/*      */       }
/* 3640 */       Collection invalidateSet = (Collection)this.recentInvalidateSets.get(nodeId);
/* 3641 */       if (invalidateSet == null) {
/* 3642 */         return 0;
/*      */       }
/*      */ 
/* 3646 */       Iterator it = invalidateSet.iterator();
/* 3647 */       for (int blkCount = 0; (blkCount < this.blockInvalidateLimit) && (it.hasNext()); 
/* 3648 */         blkCount++) {
/* 3649 */         blocksToInvalidate.add(it.next());
/* 3650 */         it.remove();
/*      */       }
/*      */ 
/* 3654 */       if (!it.hasNext()) {
/* 3655 */         this.recentInvalidateSets.remove(nodeId);
/*      */       }
/*      */ 
/* 3658 */       dn.addBlocksToBeInvalidated(blocksToInvalidate);
/* 3659 */       this.pendingDeletionBlocksCount -= blocksToInvalidate.size();
/*      */     }
/*      */ 
/* 3662 */     if (NameNode.stateChangeLog.isInfoEnabled()) {
/* 3663 */       StringBuilder blockList = new StringBuilder();
/* 3664 */       for (Block blk : blocksToInvalidate) {
/* 3665 */         blockList.append(' ');
/* 3666 */         blockList.append(blk);
/*      */       }
/* 3668 */       NameNode.stateChangeLog.info(new StringBuilder().append("BLOCK* ask ").append(dn.getName()).append(" to delete ").append(blockList).toString());
/*      */     }
/*      */ 
/* 3671 */     return blocksToInvalidate.size();
/*      */   }
/*      */ 
/*      */   public void setNodeReplicationLimit(int limit) {
/* 3675 */     this.maxReplicationStreams = limit;
/*      */   }
/*      */ 
/*      */   void processPendingReplications()
/*      */   {
/* 3683 */     Block[] timedOutItems = this.pendingReplications.getTimedOutBlocks();
/* 3684 */     if (timedOutItems != null)
/* 3685 */       synchronized (this) {
/* 3686 */         for (int i = 0; i < timedOutItems.length; i++) {
/* 3687 */           NumberReplicas num = countNodes(timedOutItems[i]);
/* 3688 */           this.neededReplications.add(timedOutItems[i], num.liveReplicas(), num.decommissionedReplicas(), getReplication(timedOutItems[i]));
/*      */         }
/*      */       }
/*      */   }
/*      */ 
/*      */   public synchronized void removeDatanode(DatanodeID nodeID)
/*      */     throws IOException
/*      */   {
/* 3706 */     DatanodeDescriptor nodeInfo = getDatanode(nodeID);
/* 3707 */     if (nodeInfo != null)
/* 3708 */       removeDatanode(nodeInfo);
/*      */     else
/* 3710 */       NameNode.stateChangeLog.warn(new StringBuilder().append("BLOCK* removeDatanode: ").append(nodeID.getName()).append(" does not exist").toString());
/*      */   }
/*      */ 
/*      */   private void removeDatanode(DatanodeDescriptor nodeInfo)
/*      */   {
/* 3720 */     synchronized (this.heartbeats) {
/* 3721 */       if (nodeInfo.isAlive) {
/* 3722 */         updateStats(nodeInfo, false);
/* 3723 */         this.heartbeats.remove(nodeInfo);
/* 3724 */         nodeInfo.isAlive = false;
/*      */       }
/*      */     }
/*      */ 
/* 3728 */     for (Iterator it = nodeInfo.getBlockIterator(); it.hasNext(); ) {
/* 3729 */       removeStoredBlock((Block)it.next(), nodeInfo);
/*      */     }
/* 3731 */     unprotectedRemoveDatanode(nodeInfo);
/* 3732 */     this.clusterMap.remove(nodeInfo);
/*      */ 
/* 3734 */     if (this.safeMode != null)
/* 3735 */       this.safeMode.checkMode();
/*      */   }
/*      */ 
/*      */   void unprotectedRemoveDatanode(DatanodeDescriptor nodeDescr)
/*      */   {
/* 3740 */     nodeDescr.resetBlocks();
/* 3741 */     removeFromInvalidates(nodeDescr.getStorageID());
/* 3742 */     NameNode.stateChangeLog.debug(new StringBuilder().append("BLOCK* unprotectedRemoveDatanode: ").append(nodeDescr.getName()).append(" is out of service now").toString());
/*      */   }
/*      */ 
/*      */   void unprotectedAddDatanode(DatanodeDescriptor nodeDescr)
/*      */   {
/* 3752 */     this.host2DataNodeMap.remove((DatanodeDescriptor)this.datanodeMap.put(nodeDescr.getStorageID(), nodeDescr));
/*      */ 
/* 3754 */     this.host2DataNodeMap.add(nodeDescr);
/*      */ 
/* 3756 */     NameNode.stateChangeLog.debug(new StringBuilder().append("BLOCK* unprotectedAddDatanode: node ").append(nodeDescr.getName()).append(" is added to datanodeMap").toString());
/*      */   }
/*      */ 
/*      */   void wipeDatanode(DatanodeID nodeID)
/*      */     throws IOException
/*      */   {
/* 3767 */     String key = nodeID.getStorageID();
/* 3768 */     this.host2DataNodeMap.remove((DatanodeDescriptor)this.datanodeMap.remove(key));
/* 3769 */     NameNode.stateChangeLog.debug(new StringBuilder().append("BLOCK* wipeDatanode: ").append(nodeID.getName()).append(" storage ").append(key).append(" is removed from datanodeMap").toString());
/*      */   }
/*      */ 
/*      */   FSImage getFSImage()
/*      */   {
/* 3776 */     return this.dir.fsImage;
/*      */   }
/*      */ 
/*      */   FSEditLog getEditLog() {
/* 3780 */     return getFSImage().getEditLog();
/*      */   }
/*      */ 
/*      */   void heartbeatCheck()
/*      */   {
/* 3791 */     if (isInSafeMode())
/*      */     {
/* 3793 */       return;
/*      */     }
/* 3795 */     boolean allAlive = false;
/* 3796 */     while (!allAlive) {
/* 3797 */       boolean foundDead = false;
/* 3798 */       DatanodeID dead = null;
/*      */ 
/* 3800 */       int numOfStaleNodes = 0;
/*      */ 
/* 3804 */       synchronized (this.heartbeats) {
/* 3805 */         Iterator it = this.heartbeats.iterator();
/* 3806 */         while (it.hasNext()) {
/* 3807 */           DatanodeDescriptor nodeInfo = (DatanodeDescriptor)it.next();
/* 3808 */           if ((dead == null) && (isDatanodeDead(nodeInfo))) {
/* 3809 */             foundDead = true;
/* 3810 */             dead = nodeInfo;
/*      */           }
/* 3812 */           if (nodeInfo.isStale(this.staleInterval)) {
/* 3813 */             numOfStaleNodes++;
/*      */           }
/*      */         }
/*      */ 
/* 3817 */         setNumStaleNodes(numOfStaleNodes);
/*      */       }
/*      */ 
/* 3821 */       if (foundDead) {
/* 3822 */         synchronized (this) {
/* 3823 */           synchronized (this.heartbeats) {
/* 3824 */             synchronized (this.datanodeMap) {
/* 3825 */               DatanodeDescriptor nodeInfo = null;
/*      */               try {
/* 3827 */                 nodeInfo = getDatanode(dead);
/*      */               } catch (IOException e) {
/* 3829 */                 nodeInfo = null;
/*      */               }
/* 3831 */               if ((nodeInfo != null) && (isDatanodeDead(nodeInfo))) {
/* 3832 */                 NameNode.stateChangeLog.info(new StringBuilder().append("BLOCK* heartbeatCheck: lost heartbeat from ").append(nodeInfo.getName()).toString());
/*      */ 
/* 3834 */                 removeDatanode(nodeInfo);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 3840 */       allAlive = !foundDead;
/*      */     }
/*      */   }
/*      */ 
/*      */   private Block rejectAddStoredBlock(Block block, DatanodeDescriptor node, String msg)
/*      */   {
/* 3850 */     NameNode.stateChangeLog.info(new StringBuilder().append("BLOCK* addStoredBlock: addStoredBlock request received for ").append(block).append(" on ").append(node.getName()).append(" size ").append(block.getNumBytes()).append(" but was rejected: ").append(msg).toString());
/*      */ 
/* 3854 */     addToInvalidates(block, node);
/* 3855 */     return block;
/*      */   }
/*      */ 
/*      */   public synchronized void processBlocksBeingWrittenReport(DatanodeID nodeID, BlockListAsLongs blocksBeingWritten)
/*      */     throws IOException
/*      */   {
/* 3869 */     DatanodeDescriptor dataNode = getDatanode(nodeID);
/* 3870 */     if (dataNode == null) {
/* 3871 */       throw new IOException(new StringBuilder().append("ProcessReport from unregistered node: ").append(nodeID.getName()).toString());
/*      */     }
/*      */ 
/* 3876 */     if (shouldNodeShutdown(dataNode)) {
/* 3877 */       setDatanodeDead(dataNode);
/* 3878 */       throw new DisallowedDatanodeException(dataNode);
/*      */     }
/*      */ 
/* 3881 */     Block block = new Block();
/*      */ 
/* 3883 */     for (int i = 0; i < blocksBeingWritten.getNumberOfBlocks(); i++) {
/* 3884 */       block.set(blocksBeingWritten.getBlockId(i), blocksBeingWritten.getBlockLen(i), blocksBeingWritten.getBlockGenStamp(i));
/*      */ 
/* 3887 */       BlocksMap.BlockInfo storedBlock = this.blocksMap.getStoredBlockWithoutMatchingGS(block);
/*      */ 
/* 3889 */       if (storedBlock == null) {
/* 3890 */         rejectAddStoredBlock(new Block(block), dataNode, "Block not in blockMap with any generation stamp");
/*      */       }
/*      */       else
/*      */       {
/* 3895 */         INodeFile inode = storedBlock.getINode();
/* 3896 */         if (inode == null) {
/* 3897 */           rejectAddStoredBlock(new Block(block), dataNode, "Block does not correspond to any file");
/*      */         }
/*      */         else
/*      */         {
/* 3902 */           boolean underConstruction = inode.isUnderConstruction();
/* 3903 */           boolean isLastBlock = (inode.getLastBlock() != null) && (inode.getLastBlock().getBlockId() == block.getBlockId());
/*      */ 
/* 3907 */           if (!underConstruction) {
/* 3908 */             rejectAddStoredBlock(new Block(block), dataNode, "Reported as block being written but is a block of closed file");
/*      */           }
/* 3913 */           else if (!isLastBlock) {
/* 3914 */             rejectAddStoredBlock(new Block(block), dataNode, "Reported as block being written but not the last block of an under-construction file");
/*      */           }
/*      */           else
/*      */           {
/* 3920 */             INodeFileUnderConstruction pendingFile = (INodeFileUnderConstruction)inode;
/* 3921 */             pendingFile.addTarget(dataNode);
/* 3922 */             incrementSafeBlockCount(pendingFile.getTargets().length);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void processReport(DatanodeID nodeID, BlockListAsLongs newReport)
/*      */     throws IOException
/*      */   {
/* 3933 */     long startTime = now();
/* 3934 */     if (NameNode.stateChangeLog.isDebugEnabled()) {
/* 3935 */       NameNode.stateChangeLog.debug(new StringBuilder().append("BLOCK* processReport: from ").append(nodeID.getName()).append(" ").append(newReport.getNumberOfBlocks()).append(" blocks").toString());
/*      */     }
/*      */ 
/* 3939 */     DatanodeDescriptor node = getDatanode(nodeID);
/* 3940 */     if ((node == null) || (!node.isAlive)) {
/* 3941 */       throw new IOException(new StringBuilder().append("ProcessReport from dead or unregisterted node: ").append(nodeID.getName()).toString());
/*      */     }
/*      */ 
/* 3946 */     if (shouldNodeShutdown(node)) {
/* 3947 */       setDatanodeDead(node);
/* 3948 */       throw new DisallowedDatanodeException(node);
/*      */     }
/*      */ 
/* 3953 */     if ((isInStartupSafeMode()) && (!node.firstBlockReport())) {
/* 3954 */       NameNode.stateChangeLog.info(new StringBuilder().append("BLOCK* processReport: discarded non-initial block report from ").append(nodeID.getName()).append(" because namenode still in startup phase").toString());
/*      */ 
/* 3957 */       return;
/*      */     }
/*      */ 
/* 3964 */     Collection toAdd = new LinkedList();
/* 3965 */     Collection toRemove = new LinkedList();
/* 3966 */     Collection toInvalidate = new LinkedList();
/* 3967 */     node.reportDiff(this.blocksMap, newReport, toAdd, toRemove, toInvalidate);
/*      */ 
/* 3969 */     for (Block b : toRemove) {
/* 3970 */       removeStoredBlock(b, node);
/*      */     }
/* 3972 */     for (Block b : toAdd) {
/* 3973 */       addStoredBlock(b, node, null);
/*      */     }
/* 3975 */     for (Block b : toInvalidate) {
/* 3976 */       NameNode.stateChangeLog.info(new StringBuilder().append("BLOCK* processReport: ").append(b).append(" on ").append(node.getName()).append(" size ").append(b.getNumBytes()).append(" does not belong to any file").toString());
/*      */ 
/* 3979 */       addToInvalidates(b, node);
/*      */     }
/* 3981 */     long endTime = now();
/* 3982 */     NameNode.getNameNodeMetrics().addBlockReport(endTime - startTime);
/* 3983 */     NameNode.stateChangeLog.info(new StringBuilder().append("*BLOCK* processReport: from ").append(nodeID.getName()).append(", blocks: ").append(newReport.getNumberOfBlocks()).append(", processing time: ").append(endTime - startTime).append(" msecs").toString());
/*      */ 
/* 3986 */     node.processedBlockReport();
/*      */   }
/*      */ 
/*      */   synchronized Block addStoredBlock(Block block, DatanodeDescriptor node, DatanodeDescriptor delNodeHint)
/*      */   {
/* 3997 */     BlocksMap.BlockInfo storedBlock = this.blocksMap.getStoredBlock(block);
/* 3998 */     if (storedBlock == null)
/*      */     {
/* 4002 */       storedBlock = this.blocksMap.getStoredBlockWithoutMatchingGS(block);
/*      */ 
/* 4004 */       if (storedBlock == null) {
/* 4005 */         return rejectAddStoredBlock(block, node, "Block not in blockMap with any generation stamp");
/*      */       }
/*      */ 
/* 4010 */       INodeFile inode = storedBlock.getINode();
/* 4011 */       if (inode == null) {
/* 4012 */         return rejectAddStoredBlock(block, node, "Block does not correspond to any file");
/*      */       }
/*      */ 
/* 4017 */       boolean reportedOldGS = block.getGenerationStamp() < storedBlock.getGenerationStamp();
/* 4018 */       boolean reportedNewGS = block.getGenerationStamp() > storedBlock.getGenerationStamp();
/* 4019 */       boolean underConstruction = inode.isUnderConstruction();
/* 4020 */       boolean isLastBlock = (inode.getLastBlock() != null) && (inode.getLastBlock().getBlockId() == block.getBlockId());
/*      */ 
/* 4025 */       if ((reportedOldGS) && ((!underConstruction) || (!isLastBlock))) {
/* 4026 */         return rejectAddStoredBlock(block, node, new StringBuilder().append("Reported block has old generation stamp but is not the last block of an under-construction file. (current generation is ").append(storedBlock.getGenerationStamp()).append(")").toString());
/*      */       }
/*      */ 
/* 4037 */       if ((underConstruction) && (isLastBlock) && ((reportedOldGS) || (reportedNewGS))) {
/* 4038 */         NameNode.stateChangeLog.info(new StringBuilder().append("BLOCK* addStoredBlock: Targets updated: ").append(block).append(" on ").append(node.getName()).append(" is added as a target for ").append(storedBlock).append(" with size ").append(block.getNumBytes()).toString());
/*      */ 
/* 4041 */         ((INodeFileUnderConstruction)inode).addTarget(node);
/* 4042 */         return block;
/*      */       }
/*      */     }
/*      */ 
/* 4046 */     INodeFile fileINode = storedBlock.getINode();
/* 4047 */     if (fileINode == null) {
/* 4048 */       return rejectAddStoredBlock(block, node, "Block does not correspond to any file");
/*      */     }
/*      */ 
/* 4052 */     assert (storedBlock != null) : "Block must be stored by now";
/*      */ 
/* 4055 */     boolean added = node.addBlock(storedBlock);
/*      */ 
/* 4059 */     boolean blockUnderConstruction = false;
/* 4060 */     if (fileINode.isUnderConstruction()) {
/* 4061 */       Block last = fileINode.getLastBlock();
/* 4062 */       if (last == null)
/*      */       {
/* 4065 */         LOG.error(new StringBuilder().append("Null blocks for reported =").append(block).append(" stored=").append(storedBlock).append(" inode=").append(fileINode).toString());
/*      */ 
/* 4067 */         return block;
/*      */       }
/* 4069 */       blockUnderConstruction = last.equals(storedBlock);
/*      */     }
/*      */ 
/* 4073 */     if (block != storedBlock) {
/* 4074 */       if (block.getNumBytes() >= 0L) {
/* 4075 */         long cursize = storedBlock.getNumBytes();
/* 4076 */         INodeFile file = storedBlock.getINode();
/* 4077 */         if (cursize == 0L) {
/* 4078 */           storedBlock.setNumBytes(block.getNumBytes());
/* 4079 */         } else if (cursize != block.getNumBytes()) {
/* 4080 */           LOG.warn(new StringBuilder().append("Inconsistent size for ").append(block).append(" reported from ").append(node.getName()).append(" current size is ").append(cursize).append(" reported size is ").append(block.getNumBytes()).toString());
/*      */           try
/*      */           {
/* 4085 */             if ((cursize > block.getNumBytes()) && (!blockUnderConstruction))
/*      */             {
/* 4088 */               LOG.warn(new StringBuilder().append("Mark new replica ").append(block).append(" from ").append(node.getName()).append("as corrupt because its length is shorter than existing ones").toString());
/*      */ 
/* 4090 */               markBlockAsCorrupt(block, node);
/*      */             }
/*      */             else {
/* 4093 */               if (!blockUnderConstruction)
/*      */               {
/* 4095 */                 int numNodes = this.blocksMap.numNodes(block);
/* 4096 */                 int count = 0;
/* 4097 */                 DatanodeDescriptor[] nodes = new DatanodeDescriptor[numNodes];
/* 4098 */                 Iterator it = this.blocksMap.nodeIterator(block);
/* 4099 */                 while ((it != null) && (it.hasNext())) {
/* 4100 */                   DatanodeDescriptor dd = (DatanodeDescriptor)it.next();
/* 4101 */                   if (!dd.equals(node)) {
/* 4102 */                     nodes[(count++)] = dd;
/*      */                   }
/*      */                 }
/* 4105 */                 for (int j = 0; j < count; j++) {
/* 4106 */                   LOG.warn(new StringBuilder().append("Mark existing replica ").append(block).append(" from ").append(node.getName()).append(" as corrupt because its length is shorter than the new one").toString());
/*      */ 
/* 4111 */                   markBlockAsCorrupt(block, nodes[j]);
/*      */                 }
/*      */ 
/*      */               }
/*      */ 
/* 4117 */               storedBlock.setNumBytes(block.getNumBytes());
/*      */             }
/*      */           } catch (IOException e) {
/* 4120 */             LOG.warn(new StringBuilder().append("Error in deleting bad ").append(block).append(e).toString());
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 4125 */         long diff = file == null ? 0L : file.getPreferredBlockSize() - storedBlock.getNumBytes();
/*      */ 
/* 4128 */         if ((diff > 0L) && (file.isUnderConstruction()) && (cursize < storedBlock.getNumBytes())) {
/*      */           try
/*      */           {
/* 4131 */             String path = this.leaseManager.findPath((INodeFileUnderConstruction)file);
/*      */ 
/* 4133 */             this.dir.updateSpaceConsumed(path, 0L, -diff * file.getReplication());
/*      */           } catch (IOException e) {
/* 4135 */             LOG.warn(new StringBuilder().append("Unexpected exception while updating disk space : ").append(e.getMessage()).toString());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 4140 */       block = storedBlock;
/*      */     }
/* 4142 */     assert (storedBlock == block) : "Block must be stored by now";
/*      */ 
/* 4144 */     int curReplicaDelta = 0;
/*      */ 
/* 4146 */     if (added) {
/* 4147 */       curReplicaDelta = 1;
/*      */ 
/* 4153 */       if (!isInSafeMode())
/* 4154 */         NameNode.stateChangeLog.info(new StringBuilder().append("BLOCK* addStoredBlock: blockMap updated: ").append(node.getName()).append(" is added to ").append(block).append(" size ").append(block.getNumBytes()).toString());
/*      */     }
/*      */     else
/*      */     {
/* 4158 */       NameNode.stateChangeLog.warn(new StringBuilder().append("BLOCK* addStoredBlock: Redundant addStoredBlock request received for ").append(block).append(" on ").append(node.getName()).append(" size ").append(block.getNumBytes()).toString());
/*      */     }
/*      */ 
/* 4164 */     NumberReplicas num = countNodes(storedBlock);
/* 4165 */     int numLiveReplicas = num.liveReplicas();
/* 4166 */     int numCurrentReplica = numLiveReplicas + this.pendingReplications.getNumReplicas(block);
/*      */ 
/* 4170 */     incrementSafeBlockCount(numCurrentReplica);
/*      */ 
/* 4176 */     if (blockUnderConstruction) {
/* 4177 */       INodeFileUnderConstruction cons = (INodeFileUnderConstruction)fileINode;
/* 4178 */       cons.addTarget(node);
/* 4179 */       return block;
/*      */     }
/*      */ 
/* 4183 */     if (isInSafeMode()) {
/* 4184 */       return block;
/*      */     }
/*      */ 
/* 4187 */     short fileReplication = fileINode.getReplication();
/* 4188 */     if (numCurrentReplica >= fileReplication) {
/* 4189 */       this.neededReplications.remove(block, numCurrentReplica, num.decommissionedReplicas, fileReplication);
/*      */     }
/*      */     else {
/* 4192 */       updateNeededReplications(block, curReplicaDelta, 0);
/*      */     }
/* 4194 */     if (numCurrentReplica > fileReplication) {
/* 4195 */       processOverReplicatedBlock(block, fileReplication, node, delNodeHint);
/*      */     }
/*      */ 
/* 4199 */     int corruptReplicasCount = this.corruptReplicas.numCorruptReplicas(block);
/* 4200 */     int numCorruptNodes = num.corruptReplicas();
/* 4201 */     if (numCorruptNodes != corruptReplicasCount) {
/* 4202 */       LOG.warn(new StringBuilder().append("Inconsistent number of corrupt replicas for ").append(block).append("blockMap has ").append(numCorruptNodes).append(" but corrupt replicas map has ").append(corruptReplicasCount).toString());
/*      */     }
/*      */ 
/* 4206 */     if ((corruptReplicasCount > 0) && (numLiveReplicas >= fileReplication))
/* 4207 */       invalidateCorruptReplicas(block);
/* 4208 */     return block;
/*      */   }
/*      */ 
/*      */   void invalidateCorruptReplicas(Block blk)
/*      */   {
/* 4225 */     Collection nodes = this.corruptReplicas.getNodes(blk);
/* 4226 */     boolean gotException = false;
/* 4227 */     if (nodes == null) {
/* 4228 */       return;
/*      */     }
/*      */ 
/* 4231 */     nodes = new ArrayList(nodes);
/* 4232 */     NameNode.stateChangeLog.debug(new StringBuilder().append("NameNode.invalidateCorruptReplicas: invalidating corrupt replicas on ").append(nodes.size()).append("nodes").toString());
/*      */ 
/* 4234 */     for (Iterator it = nodes.iterator(); it.hasNext(); ) {
/* 4235 */       DatanodeDescriptor node = (DatanodeDescriptor)it.next();
/*      */       try {
/* 4237 */         invalidateBlock(blk, node);
/*      */       } catch (IOException e) {
/* 4239 */         NameNode.stateChangeLog.info(new StringBuilder().append("NameNode.invalidateCorruptReplicas error in deleting bad ").append(blk).append(" on ").append(node).append(e).toString());
/*      */ 
/* 4242 */         gotException = true;
/*      */       }
/*      */     }
/*      */ 
/* 4246 */     if (!gotException)
/* 4247 */       this.corruptReplicas.removeFromCorruptReplicasMap(blk);
/*      */   }
/*      */ 
/*      */   private synchronized void processMisReplicatedBlocks()
/*      */   {
/* 4255 */     long nrInvalid = 0L; long nrOverReplicated = 0L; long nrUnderReplicated = 0L;
/* 4256 */     this.neededReplications.clear();
/* 4257 */     for (BlocksMap.BlockInfo block : this.blocksMap.getBlocks()) {
/* 4258 */       INodeFile fileINode = block.getINode();
/* 4259 */       if (fileINode == null)
/*      */       {
/* 4261 */         nrInvalid += 1L;
/* 4262 */         addToInvalidates(block);
/*      */       }
/*      */       else
/*      */       {
/* 4266 */         short expectedReplication = fileINode.getReplication();
/* 4267 */         NumberReplicas num = countNodes(block);
/* 4268 */         int numCurrentReplica = num.liveReplicas();
/*      */ 
/* 4270 */         if (this.neededReplications.add(block, numCurrentReplica, num.decommissionedReplicas(), expectedReplication))
/*      */         {
/* 4274 */           nrUnderReplicated += 1L;
/*      */         }
/*      */ 
/* 4277 */         if (numCurrentReplica > expectedReplication)
/*      */         {
/* 4279 */           nrOverReplicated += 1L;
/* 4280 */           processOverReplicatedBlock(block, expectedReplication, null, null);
/*      */         }
/*      */       }
/*      */     }
/* 4283 */     LOG.info(new StringBuilder().append("Total number of blocks = ").append(this.blocksMap.size()).toString());
/* 4284 */     LOG.info(new StringBuilder().append("Number of invalid blocks = ").append(nrInvalid).toString());
/* 4285 */     LOG.info(new StringBuilder().append("Number of under-replicated blocks = ").append(nrUnderReplicated).toString());
/* 4286 */     LOG.info(new StringBuilder().append("Number of  over-replicated blocks = ").append(nrOverReplicated).toString());
/*      */   }
/*      */ 
/*      */   private void processOverReplicatedBlock(Block block, short replication, DatanodeDescriptor addedNode, DatanodeDescriptor delNodeHint)
/*      */   {
/* 4296 */     if (addedNode == delNodeHint) {
/* 4297 */       delNodeHint = null;
/*      */     }
/* 4299 */     Collection nonExcess = new ArrayList();
/* 4300 */     Collection corruptNodes = this.corruptReplicas.getNodes(block);
/* 4301 */     Iterator it = this.blocksMap.nodeIterator(block);
/* 4302 */     while (it.hasNext()) {
/* 4303 */       DatanodeDescriptor cur = (DatanodeDescriptor)it.next();
/* 4304 */       Collection excessBlocks = (Collection)this.excessReplicateMap.get(cur.getStorageID());
/* 4305 */       if (((excessBlocks == null) || (!excessBlocks.contains(block))) && 
/* 4306 */         (!cur.isDecommissionInProgress()) && (!cur.isDecommissioned()))
/*      */       {
/* 4308 */         if ((corruptNodes == null) || (!corruptNodes.contains(cur))) {
/* 4309 */           nonExcess.add(cur);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 4314 */     chooseExcessReplicates(nonExcess, block, replication, addedNode, delNodeHint);
/*      */   }
/*      */ 
/*      */   void chooseExcessReplicates(Collection<DatanodeDescriptor> nonExcess, Block b, short replication, DatanodeDescriptor addedNode, DatanodeDescriptor delNodeHint)
/*      */   {
/* 4336 */     INodeFile inode = this.blocksMap.getINode(b);
/*      */ 
/* 4338 */     Map rackMap = new HashMap();
/*      */ 
/* 4340 */     List moreThanOne = new ArrayList();
/* 4341 */     List exactlyOne = new ArrayList();
/*      */ 
/* 4346 */     this.replicator.splitNodesWithRack(nonExcess, rackMap, moreThanOne, exactlyOne);
/*      */ 
/* 4351 */     boolean firstOne = true;
/* 4352 */     while (nonExcess.size() - replication > 0) {
/* 4353 */       DatanodeInfo cur = null;
/*      */ 
/* 4356 */       if ((firstOne) && (delNodeHint != null) && (nonExcess.contains(delNodeHint)) && ((moreThanOne.contains(delNodeHint)) || ((addedNode != null) && (!moreThanOne.contains(addedNode)))))
/*      */       {
/* 4359 */         cur = delNodeHint;
/*      */       }
/* 4361 */       else cur = this.replicator.chooseReplicaToDelete(inode, b, replication, moreThanOne, exactlyOne);
/*      */ 
/* 4365 */       firstOne = false;
/*      */ 
/* 4367 */       this.replicator.adjustSetsWithChosenReplica(rackMap, moreThanOne, exactlyOne, cur);
/*      */ 
/* 4370 */       nonExcess.remove(cur);
/*      */ 
/* 4372 */       Collection excessBlocks = (Collection)this.excessReplicateMap.get(cur.getStorageID());
/* 4373 */       if (excessBlocks == null) {
/* 4374 */         excessBlocks = new TreeSet();
/* 4375 */         this.excessReplicateMap.put(cur.getStorageID(), excessBlocks);
/*      */       }
/* 4377 */       if (excessBlocks.add(b)) {
/* 4378 */         this.excessBlocksCount += 1L;
/* 4379 */         NameNode.stateChangeLog.debug(new StringBuilder().append("BLOCK* chooseExcessReplicates: (").append(cur.getName()).append(", ").append(b).append(") is added to excessReplicateMap").toString());
/*      */       }
/*      */ 
/* 4393 */       addToInvalidatesNoLog(b, cur);
/* 4394 */       NameNode.stateChangeLog.info(new StringBuilder().append("BLOCK* chooseExcessReplicates: (").append(cur.getName()).append(", ").append(b).append(") is added to recentInvalidateSets").toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   synchronized void removeStoredBlock(Block block, DatanodeDescriptor node)
/*      */   {
/* 4404 */     NameNode.stateChangeLog.debug(new StringBuilder().append("BLOCK* removeStoredBlock: ").append(block).append(" from ").append(node.getName()).toString());
/*      */ 
/* 4406 */     if (!this.blocksMap.removeNode(block, node)) {
/* 4407 */       NameNode.stateChangeLog.debug(new StringBuilder().append("BLOCK* removeStoredBlock: ").append(block).append(" has already been removed from node ").append(node).toString());
/*      */ 
/* 4409 */       return;
/*      */     }
/*      */ 
/* 4418 */     INode fileINode = this.blocksMap.getINode(block);
/* 4419 */     if (fileINode != null) {
/* 4420 */       decrementSafeBlockCount(block);
/* 4421 */       updateNeededReplications(block, -1, 0);
/*      */     }
/*      */ 
/* 4428 */     Collection excessBlocks = (Collection)this.excessReplicateMap.get(node.getStorageID());
/* 4429 */     if ((excessBlocks != null) && 
/* 4430 */       (excessBlocks.remove(block))) {
/* 4431 */       this.excessBlocksCount -= 1L;
/* 4432 */       NameNode.stateChangeLog.debug(new StringBuilder().append("BLOCK* removeStoredBlock: ").append(block).append(" is removed from excessBlocks").toString());
/*      */ 
/* 4434 */       if (excessBlocks.size() == 0) {
/* 4435 */         this.excessReplicateMap.remove(node.getStorageID());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 4441 */     this.corruptReplicas.removeFromCorruptReplicasMap(block, node);
/*      */   }
/*      */ 
/*      */   public synchronized void blockReceived(DatanodeID nodeID, Block block, String delHint)
/*      */     throws IOException
/*      */   {
/* 4451 */     DatanodeDescriptor node = getDatanode(nodeID);
/* 4452 */     if ((node == null) || (!node.isAlive)) {
/* 4453 */       NameNode.stateChangeLog.warn(new StringBuilder().append("BLOCK* blockReceived: ").append(block).append(" is received from dead or unregistered node ").append(nodeID.getName()).toString());
/*      */ 
/* 4455 */       throw new IOException(new StringBuilder().append("Got blockReceived message from unregistered or dead node ").append(block).toString());
/*      */     }
/*      */ 
/* 4459 */     if (NameNode.stateChangeLog.isDebugEnabled()) {
/* 4460 */       NameNode.stateChangeLog.debug(new StringBuilder().append("BLOCK* blockReceived: ").append(block).append(" is received from ").append(nodeID.getName()).toString());
/*      */     }
/*      */ 
/* 4465 */     if (shouldNodeShutdown(node)) {
/* 4466 */       setDatanodeDead(node);
/* 4467 */       throw new DisallowedDatanodeException(node);
/*      */     }
/*      */ 
/* 4471 */     DatanodeDescriptor delHintNode = null;
/* 4472 */     if ((delHint != null) && (delHint.length() != 0)) {
/* 4473 */       delHintNode = (DatanodeDescriptor)this.datanodeMap.get(delHint);
/* 4474 */       if (delHintNode == null) {
/* 4475 */         NameNode.stateChangeLog.warn(new StringBuilder().append("BLOCK* blockReceived: ").append(block).append(" is expected to be removed from an unrecorded node ").append(delHint).toString());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 4485 */     this.pendingReplications.decrement(block);
/* 4486 */     addStoredBlock(block, node, delHintNode);
/*      */ 
/* 4489 */     node.decBlocksScheduled();
/*      */   }
/*      */ 
/*      */   public long getMissingBlocksCount()
/*      */   {
/* 4494 */     return Math.max(this.missingBlocksInPrevIter, this.missingBlocksInCurIter);
/*      */   }
/*      */ 
/*      */   long[] getStats() throws IOException {
/* 4498 */     checkSuperuserPrivilege();
/* 4499 */     synchronized (this.heartbeats) {
/* 4500 */       return new long[] { this.capacityTotal, this.capacityUsed, this.capacityRemaining, this.underReplicatedBlocksCount, this.corruptReplicaBlocksCount, getMissingBlocksCount() };
/*      */     }
/*      */   }
/*      */ 
/*      */   public long getCapacityTotal()
/*      */   {
/* 4512 */     synchronized (this.heartbeats) {
/* 4513 */       return this.capacityTotal;
/*      */     }
/*      */   }
/*      */ 
/*      */   public long getCapacityUsed()
/*      */   {
/* 4521 */     synchronized (this.heartbeats) {
/* 4522 */       return this.capacityUsed;
/*      */     }
/*      */   }
/*      */ 
/*      */   public float getCapacityUsedPercent()
/*      */   {
/* 4529 */     synchronized (this.heartbeats) {
/* 4530 */       if (this.capacityTotal <= 0L) {
/* 4531 */         return 100.0F;
/*      */       }
/*      */ 
/* 4534 */       return (float)this.capacityUsed * 100.0F / (float)this.capacityTotal;
/*      */     }
/*      */   }
/*      */ 
/*      */   public long getCapacityUsedNonDFS()
/*      */   {
/* 4542 */     long nonDFSUsed = 0L;
/* 4543 */     synchronized (this.heartbeats) {
/* 4544 */       nonDFSUsed = this.capacityTotal - this.capacityRemaining - this.capacityUsed;
/*      */     }
/* 4546 */     return nonDFSUsed < 0L ? 0L : nonDFSUsed;
/*      */   }
/*      */ 
/*      */   public long getCapacityRemaining()
/*      */   {
/* 4552 */     synchronized (this.heartbeats) {
/* 4553 */       return this.capacityRemaining;
/*      */     }
/*      */   }
/*      */ 
/*      */   public float getCapacityRemainingPercent()
/*      */   {
/* 4561 */     synchronized (this.heartbeats) {
/* 4562 */       if (this.capacityTotal <= 0L) {
/* 4563 */         return 0.0F;
/*      */       }
/*      */ 
/* 4566 */       return (float)this.capacityRemaining * 100.0F / (float)this.capacityTotal;
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getTotalLoad()
/*      */   {
/* 4573 */     synchronized (this.heartbeats) {
/* 4574 */       return this.totalLoad;
/*      */     }
/*      */   }
/*      */ 
/*      */   int getNumberOfDatanodes(FSConstants.DatanodeReportType type) {
/* 4579 */     return getDatanodeListForReport(type).size();
/*      */   }
/*      */ 
/*      */   public synchronized ArrayList<DatanodeDescriptor> getDatanodeListForReport(FSConstants.DatanodeReportType type)
/*      */   {
/* 4585 */     boolean listLiveNodes = (type == FSConstants.DatanodeReportType.ALL) || (type == FSConstants.DatanodeReportType.LIVE);
/*      */ 
/* 4587 */     boolean listDeadNodes = (type == FSConstants.DatanodeReportType.ALL) || (type == FSConstants.DatanodeReportType.DEAD);
/*      */ 
/* 4590 */     HashMap mustList = new HashMap();
/*      */ 
/* 4592 */     if (listDeadNodes)
/*      */     {
/* 4594 */       Iterator it = this.hostsReader.getHosts().iterator();
/* 4595 */       while (it.hasNext()) {
/* 4596 */         mustList.put(it.next(), "");
/*      */       }
/* 4598 */       Iterator it = this.hostsReader.getExcludedHosts().iterator();
/* 4599 */       while (it.hasNext()) {
/* 4600 */         mustList.put(it.next(), "");
/*      */       }
/*      */     }
/*      */ 
/* 4604 */     ArrayList nodes = null;
/*      */ 
/* 4606 */     synchronized (this.datanodeMap) {
/* 4607 */       nodes = new ArrayList(this.datanodeMap.size() + mustList.size());
/*      */ 
/* 4610 */       Iterator it = this.datanodeMap.values().iterator();
/* 4611 */       while (it.hasNext()) {
/* 4612 */         DatanodeDescriptor dn = (DatanodeDescriptor)it.next();
/* 4613 */         boolean isDead = isDatanodeDead(dn);
/* 4614 */         if (((isDead) && (listDeadNodes)) || ((!isDead) && (listLiveNodes))) {
/* 4615 */           nodes.add(dn);
/*      */         }
/*      */ 
/* 4618 */         mustList.remove(dn.getName());
/* 4619 */         mustList.remove(dn.getHost());
/* 4620 */         mustList.remove(dn.getHostName());
/*      */       }
/*      */     }
/*      */     Iterator it;
/* 4624 */     if (listDeadNodes) {
/* 4625 */       for (it = mustList.keySet().iterator(); it.hasNext(); ) {
/* 4626 */         DatanodeDescriptor dn = new DatanodeDescriptor(new DatanodeID((String)it.next()));
/*      */ 
/* 4628 */         dn.setLastUpdate(0L);
/* 4629 */         nodes.add(dn);
/*      */       }
/*      */     }
/*      */ 
/* 4633 */     return nodes;
/*      */   }
/*      */ 
/*      */   public DatanodeInfo[] datanodeReport(FSConstants.DatanodeReportType type) throws AccessControlException
/*      */   {
/* 4638 */     checkSuperuserPrivilege();
/*      */ 
/* 4640 */     synchronized (this) {
/* 4641 */       ArrayList results = getDatanodeListForReport(type);
/* 4642 */       DatanodeInfo[] arr = new DatanodeInfo[results.size()];
/* 4643 */       for (int i = 0; i < arr.length; i++) {
/* 4644 */         arr[i] = new DatanodeInfo((DatanodeInfo)results.get(i));
/*      */       }
/* 4646 */       return arr;
/*      */     }
/*      */   }
/*      */ 
/*      */   void saveNamespace()
/*      */     throws AccessControlException, IOException
/*      */   {
/* 4659 */     checkSuperuserPrivilege();
/* 4660 */     synchronized (this) {
/* 4661 */       if (!isInSafeMode()) {
/* 4662 */         throw new IOException("Safe mode should be turned ON in order to create namespace image");
/*      */       }
/*      */ 
/* 4665 */       getFSImage().saveNamespace(true);
/* 4666 */       LOG.info("New namespace image has been created");
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void DFSNodesStatus(ArrayList<DatanodeDescriptor> live, ArrayList<DatanodeDescriptor> dead)
/*      */   {
/* 4675 */     ArrayList results = getDatanodeListForReport(FSConstants.DatanodeReportType.ALL);
/*      */ 
/* 4677 */     for (Iterator it = results.iterator(); it.hasNext(); ) {
/* 4678 */       DatanodeDescriptor node = (DatanodeDescriptor)it.next();
/* 4679 */       if (isDatanodeDead(node))
/* 4680 */         dead.add(node);
/*      */       else
/* 4682 */         live.add(node);
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized void datanodeDump(PrintWriter out)
/*      */   {
/*      */     Iterator it;
/* 4690 */     synchronized (this.datanodeMap) {
/* 4691 */       out.println(new StringBuilder().append("Metasave: Number of datanodes: ").append(this.datanodeMap.size()).toString());
/* 4692 */       for (it = this.datanodeMap.values().iterator(); it.hasNext(); ) {
/* 4693 */         DatanodeDescriptor node = (DatanodeDescriptor)it.next();
/* 4694 */         out.println(node.dumpDatanode());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void startDecommission(DatanodeDescriptor node)
/*      */     throws IOException
/*      */   {
/* 4705 */     if ((!node.isDecommissionInProgress()) && (!node.isDecommissioned())) {
/* 4706 */       LOG.info(new StringBuilder().append("Start Decommissioning node ").append(node.getName()).toString());
/* 4707 */       node.startDecommission();
/* 4708 */       node.decommissioningStatus.setStartTime(now());
/*      */ 
/* 4712 */       checkDecommissionStateInternal(node);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void stopDecommission(DatanodeDescriptor node)
/*      */     throws IOException
/*      */   {
/* 4721 */     LOG.info(new StringBuilder().append("Stop Decommissioning node ").append(node.getName()).toString());
/* 4722 */     node.stopDecommission();
/*      */   }
/*      */ 
/*      */   public DatanodeInfo getDataNodeInfo(String name)
/*      */   {
/* 4728 */     return (DatanodeInfo)this.datanodeMap.get(name);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public InetSocketAddress getDFSNameNodeAddress()
/*      */   {
/* 4736 */     return this.nameNodeAddress;
/*      */   }
/*      */ 
/*      */   public Date getStartTime()
/*      */   {
/* 4742 */     return new Date(this.systemStart);
/*      */   }
/*      */   short getMaxReplication() {
/* 4745 */     return (short)this.maxReplication; } 
/* 4746 */   short getMinReplication() { return (short)this.minReplication; } 
/* 4747 */   short getDefaultReplication() { return (short)this.defaultReplication; } 
/*      */   public void stallReplicationWork() {
/* 4749 */     this.stallReplicationWork = true; } 
/* 4750 */   public void restartReplicationWork() { this.stallReplicationWork = false; }
/*      */ 
/*      */ 
/*      */   private NumberReplicas countNodes(Block b, Iterator<DatanodeDescriptor> nodeIter)
/*      */   {
/* 4797 */     int count = 0;
/* 4798 */     int live = 0;
/* 4799 */     int corrupt = 0;
/* 4800 */     int excess = 0;
/* 4801 */     Collection nodesCorrupt = this.corruptReplicas.getNodes(b);
/* 4802 */     while (nodeIter.hasNext()) {
/* 4803 */       DatanodeDescriptor node = (DatanodeDescriptor)nodeIter.next();
/* 4804 */       if ((nodesCorrupt != null) && (nodesCorrupt.contains(node))) {
/* 4805 */         corrupt++;
/*      */       }
/* 4807 */       else if ((node.isDecommissionInProgress()) || (node.isDecommissioned())) {
/* 4808 */         count++;
/*      */       }
/*      */       else {
/* 4811 */         Collection blocksExcess = (Collection)this.excessReplicateMap.get(node.getStorageID());
/*      */ 
/* 4813 */         if ((blocksExcess != null) && (blocksExcess.contains(b)))
/* 4814 */           excess++;
/*      */         else {
/* 4816 */           live++;
/*      */         }
/*      */       }
/*      */     }
/* 4820 */     return new NumberReplicas(live, count, corrupt, excess);
/*      */   }
/*      */ 
/*      */   NumberReplicas countNodes(Block b)
/*      */   {
/* 4827 */     return countNodes(b, this.blocksMap.nodeIterator(b));
/*      */   }
/*      */ 
/*      */   private void logBlockReplicationInfo(Block block, DatanodeDescriptor srcNode, NumberReplicas num)
/*      */   {
/* 4832 */     int curReplicas = num.liveReplicas();
/* 4833 */     int curExpectedReplicas = getReplication(block);
/* 4834 */     INode fileINode = this.blocksMap.getINode(block);
/* 4835 */     Iterator nodeIter = this.blocksMap.nodeIterator(block);
/* 4836 */     StringBuffer nodeList = new StringBuffer();
/* 4837 */     while (nodeIter.hasNext()) {
/* 4838 */       DatanodeDescriptor node = (DatanodeDescriptor)nodeIter.next();
/* 4839 */       nodeList.append(node.name);
/* 4840 */       nodeList.append(" ");
/*      */     }
/* 4842 */     LOG.info(new StringBuilder().append("Block: ").append(block).append(", Expected Replicas: ").append(curExpectedReplicas).append(", live replicas: ").append(curReplicas).append(", corrupt replicas: ").append(num.corruptReplicas()).append(", decommissioned replicas: ").append(num.decommissionedReplicas()).append(", excess replicas: ").append(num.excessReplicas()).append(", Is Open File: ").append(fileINode.isUnderConstruction()).append(", Datanodes having this block: ").append(nodeList).append(", Current Datanode: ").append(srcNode.name).append(", Is current datanode decommissioning: ").append(srcNode.isDecommissionInProgress()).toString());
/*      */   }
/*      */ 
/*      */   private boolean isReplicationInProgress(DatanodeDescriptor srcNode)
/*      */   {
/* 4859 */     boolean status = false;
/* 4860 */     int underReplicatedBlocks = 0;
/* 4861 */     int decommissionOnlyReplicas = 0;
/* 4862 */     int underReplicatedInOpenFiles = 0;
/*      */ 
/* 4864 */     for (Iterator i = srcNode.getBlockIterator(); i.hasNext(); ) {
/* 4865 */       Block block = (Block)i.next();
/* 4866 */       INode fileINode = this.blocksMap.getINode(block);
/*      */ 
/* 4868 */       if (fileINode != null) {
/* 4869 */         NumberReplicas num = countNodes(block);
/* 4870 */         int curReplicas = num.liveReplicas();
/* 4871 */         int curExpectedReplicas = getReplication(block);
/* 4872 */         if (curExpectedReplicas > curReplicas)
/*      */         {
/* 4874 */           if (!status) {
/* 4875 */             status = true;
/* 4876 */             logBlockReplicationInfo(block, srcNode, num);
/*      */           }
/* 4878 */           underReplicatedBlocks++;
/* 4879 */           if ((curReplicas == 0) && (num.decommissionedReplicas() > 0)) {
/* 4880 */             decommissionOnlyReplicas++;
/*      */           }
/* 4882 */           if (fileINode.isUnderConstruction()) {
/* 4883 */             underReplicatedInOpenFiles++;
/*      */           }
/*      */ 
/* 4886 */           if ((!this.neededReplications.contains(block)) && (this.pendingReplications.getNumReplicas(block) == 0))
/*      */           {
/* 4893 */             this.neededReplications.add(block, curReplicas, num.decommissionedReplicas(), curExpectedReplicas);
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 4901 */     srcNode.decommissioningStatus.set(underReplicatedBlocks, decommissionOnlyReplicas, underReplicatedInOpenFiles);
/*      */ 
/* 4904 */     return status;
/*      */   }
/*      */ 
/*      */   boolean checkDecommissionStateInternal(DatanodeDescriptor node)
/*      */   {
/* 4916 */     if ((node.isDecommissionInProgress()) && 
/* 4917 */       (!isReplicationInProgress(node))) {
/* 4918 */       node.setDecommissioned();
/* 4919 */       LOG.info(new StringBuilder().append("Decommission complete for node ").append(node.getName()).toString());
/*      */     }
/*      */ 
/* 4922 */     if (node.isDecommissioned()) {
/* 4923 */       return true;
/*      */     }
/* 4925 */     return false;
/*      */   }
/*      */ 
/*      */   private boolean inHostsList(DatanodeID node, String ipAddr)
/*      */   {
/* 4932 */     Set hostsList = this.hostsReader.getHosts();
/* 4933 */     return (hostsList.isEmpty()) || ((ipAddr != null) && (hostsList.contains(ipAddr))) || (hostsList.contains(node.getHost())) || (hostsList.contains(node.getName())) || (((node instanceof DatanodeInfo)) && (hostsList.contains(((DatanodeInfo)node).getHostName())));
/*      */   }
/*      */ 
/*      */   private boolean inExcludedHostsList(DatanodeID node, String ipAddr)
/*      */   {
/* 4942 */     Set excludeList = this.hostsReader.getExcludedHosts();
/* 4943 */     return ((ipAddr != null) && (excludeList.contains(ipAddr))) || (excludeList.contains(node.getHost())) || (excludeList.contains(node.getName())) || (((node instanceof DatanodeInfo)) && (excludeList.contains(((DatanodeInfo)node).getHostName())));
/*      */   }
/*      */ 
/*      */   public void refreshNodes(Configuration conf)
/*      */     throws IOException
/*      */   {
/* 4960 */     checkSuperuserPrivilege();
/*      */ 
/* 4963 */     if (conf == null)
/* 4964 */       conf = new Configuration();
/* 4965 */     this.hostsReader.updateFileNames(conf.get("dfs.hosts", ""), conf.get("dfs.hosts.exclude", ""));
/*      */ 
/* 4967 */     this.hostsReader.refresh();
/* 4968 */     synchronized (this) {
/* 4969 */       Iterator it = this.datanodeMap.values().iterator();
/* 4970 */       while (it.hasNext()) {
/* 4971 */         DatanodeDescriptor node = (DatanodeDescriptor)it.next();
/*      */ 
/* 4973 */         if (!inHostsList(node, null)) {
/* 4974 */           node.setDecommissioned();
/*      */         }
/* 4976 */         else if (inExcludedHostsList(node, null)) {
/* 4977 */           if ((!node.isDecommissionInProgress()) && (!node.isDecommissioned()))
/*      */           {
/* 4979 */             startDecommission(node);
/*      */           }
/*      */         }
/* 4982 */         else if ((node.isDecommissionInProgress()) || (node.isDecommissioned()))
/*      */         {
/* 4984 */           stopDecommission(node);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   void finalizeUpgrade()
/*      */     throws IOException
/*      */   {
/* 4994 */     checkSuperuserPrivilege();
/* 4995 */     synchronized (this) {
/* 4996 */       getFSImage().finalizeUpgrade();
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized boolean verifyNodeRegistration(DatanodeRegistration nodeReg, String ipAddr)
/*      */     throws IOException
/*      */   {
/* 5010 */     if (!inHostsList(nodeReg, ipAddr)) {
/* 5011 */       return false;
/*      */     }
/* 5013 */     if (inExcludedHostsList(nodeReg, ipAddr)) {
/* 5014 */       DatanodeDescriptor node = getDatanode(nodeReg);
/* 5015 */       if (node == null) {
/* 5016 */         throw new IOException(new StringBuilder().append("verifyNodeRegistration: unknown datanode ").append(nodeReg.getName()).toString());
/*      */       }
/*      */ 
/* 5019 */       if (!checkDecommissionStateInternal(node)) {
/* 5020 */         startDecommission(node);
/*      */       }
/*      */     }
/* 5023 */     return true;
/*      */   }
/*      */ 
/*      */   private boolean shouldNodeShutdown(DatanodeDescriptor node)
/*      */   {
/* 5033 */     return node.isDecommissioned();
/*      */   }
/*      */ 
/*      */   public DatanodeDescriptor getDatanode(DatanodeID nodeID)
/*      */     throws IOException
/*      */   {
/* 5044 */     UnregisteredDatanodeException e = null;
/* 5045 */     DatanodeDescriptor node = (DatanodeDescriptor)this.datanodeMap.get(nodeID.getStorageID());
/* 5046 */     if (node == null)
/* 5047 */       return null;
/* 5048 */     if (!node.getName().equals(nodeID.getName())) {
/* 5049 */       e = new UnregisteredDatanodeException(nodeID, node);
/* 5050 */       NameNode.stateChangeLog.fatal(new StringBuilder().append("BLOCK* getDatanode: ").append(e.getLocalizedMessage()).toString());
/*      */ 
/* 5052 */       throw e;
/*      */     }
/* 5054 */     return node;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   private DatanodeDescriptor getDatanodeByIndex(int index)
/*      */   {
/* 5060 */     int i = 0;
/* 5061 */     for (DatanodeDescriptor node : this.datanodeMap.values()) {
/* 5062 */       if (i == index) {
/* 5063 */         return node;
/*      */       }
/* 5065 */       i++;
/*      */     }
/* 5067 */     return null;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public String randomDataNode() {
/* 5072 */     int size = this.datanodeMap.size();
/* 5073 */     int index = 0;
/* 5074 */     if (size != 0) {
/* 5075 */       index = this.r.nextInt(size);
/* 5076 */       for (int i = 0; i < size; i++) {
/* 5077 */         DatanodeDescriptor d = getDatanodeByIndex(index);
/* 5078 */         if ((d != null) && (!d.isDecommissioned()) && (!isDatanodeDead(d)) && (!d.isDecommissionInProgress()))
/*      */         {
/* 5080 */           return new StringBuilder().append(d.getHost()).append(":").append(d.getInfoPort()).toString();
/*      */         }
/* 5082 */         index = (index + 1) % size;
/*      */       }
/*      */     }
/* 5085 */     return null;
/*      */   }
/*      */ 
/*      */   public DatanodeDescriptor getRandomDatanode() {
/* 5089 */     return (DatanodeDescriptor)this.clusterMap.chooseRandom("");
/*      */   }
/*      */ 
/*      */   static long now()
/*      */   {
/* 5480 */     return System.currentTimeMillis();
/*      */   }
/*      */ 
/*      */   boolean setSafeMode(FSConstants.SafeModeAction action) throws IOException {
/* 5484 */     if (action != FSConstants.SafeModeAction.SAFEMODE_GET) {
/* 5485 */       checkSuperuserPrivilege();
/* 5486 */       switch (2.$SwitchMap$org$apache$hadoop$hdfs$protocol$FSConstants$SafeModeAction[action.ordinal()]) {
/*      */       case 1:
/* 5488 */         leaveSafeMode(false);
/* 5489 */         break;
/*      */       case 2:
/* 5491 */         enterSafeMode();
/*      */       }
/*      */     }
/*      */ 
/* 5495 */     return isInSafeMode();
/*      */   }
/*      */ 
/*      */   boolean isInSafeMode()
/*      */   {
/* 5503 */     if (this.safeMode == null)
/* 5504 */       return false;
/* 5505 */     return this.safeMode.isOn();
/*      */   }
/*      */ 
/*      */   synchronized boolean isInStartupSafeMode()
/*      */   {
/* 5512 */     if (this.safeMode == null)
/* 5513 */       return false;
/* 5514 */     return (this.safeMode.isOn()) && (!this.safeMode.isManual());
/*      */   }
/*      */ 
/*      */   void incrementSafeBlockCount(int replication)
/*      */   {
/* 5522 */     if (this.safeMode == null)
/* 5523 */       return;
/* 5524 */     this.safeMode.incrementSafeBlockCount((short)replication);
/*      */   }
/*      */ 
/*      */   void decrementSafeBlockCount(Block b)
/*      */   {
/* 5531 */     if (this.safeMode == null)
/* 5532 */       return;
/* 5533 */     this.safeMode.decrementSafeBlockCount((short)countNodes(b).liveReplicas());
/*      */   }
/*      */ 
/*      */   void setBlockTotal()
/*      */   {
/* 5540 */     if (this.safeMode == null)
/* 5541 */       return;
/* 5542 */     this.safeMode.setBlockTotal((int)getSafeBlockCount());
/*      */   }
/*      */ 
/*      */   public long getBlocksTotal()
/*      */   {
/* 5549 */     return this.blocksMap.size();
/*      */   }
/*      */ 
/*      */   private long getSafeBlockCount()
/*      */   {
/* 5566 */     long numExcludedBlocks = 0L;
/* 5567 */     for (LeaseManager.Lease lease : this.leaseManager.getSortedLeases())
/* 5568 */       for (String path : lease.getPaths()) {
/* 5569 */         INode node = this.dir.getFileINode(path);
/* 5570 */         if (node == null) {
/* 5571 */           LOG.error(new StringBuilder().append("Found a lease for nonexisting file: ").append(path).toString());
/*      */         }
/* 5574 */         else if (!node.isUnderConstruction()) {
/* 5575 */           LOG.error(new StringBuilder().append("Found a lease for file that is not under construction:").append(path).toString());
/*      */         }
/*      */         else
/*      */         {
/* 5579 */           INodeFileUnderConstruction cons = (INodeFileUnderConstruction)node;
/* 5580 */           BlocksMap.BlockInfo[] blocks = cons.getBlocks();
/* 5581 */           if ((blocks != null) && (blocks.length != 0))
/*      */           {
/* 5585 */             if (blocks[(blocks.length - 1)].getNumBytes() == 0L)
/* 5586 */               numExcludedBlocks += 1L;
/*      */           }
/*      */         }
/*      */       }
/* 5590 */     LOG.info(new StringBuilder().append("Number of blocks excluded by safe block count: ").append(numExcludedBlocks).append(" total blocks: ").append(getBlocksTotal()).append(" and thus the safe blocks: ").append(getBlocksTotal() - numExcludedBlocks).toString());
/*      */ 
/* 5595 */     return getBlocksTotal() - numExcludedBlocks;
/*      */   }
/*      */ 
/*      */   synchronized void enterSafeMode()
/*      */     throws IOException
/*      */   {
/* 5603 */     if (!isInSafeMode()) {
/* 5604 */       this.safeMode = new SafeModeInfo(null);
/* 5605 */       return;
/*      */     }
/* 5607 */     this.safeMode.setManual();
/* 5608 */     getEditLog().logSync();
/* 5609 */     NameNode.stateChangeLog.info(new StringBuilder().append("STATE* Safe mode is ON. ").append(this.safeMode.getTurnOffTip()).toString());
/*      */   }
/*      */ 
/*      */   synchronized void leaveSafeMode(boolean checkForUpgrades)
/*      */     throws SafeModeException
/*      */   {
/* 5618 */     if (!isInSafeMode()) {
/* 5619 */       NameNode.stateChangeLog.info("STATE* Safe mode is already OFF.");
/* 5620 */       return;
/*      */     }
/* 5622 */     if (getDistributedUpgradeState()) {
/* 5623 */       throw new SafeModeException("Distributed upgrade is in progress", this.safeMode);
/*      */     }
/* 5625 */     this.safeMode.leave(checkForUpgrades);
/*      */   }
/*      */ 
/*      */   public String getSafeModeTip() {
/* 5629 */     if (!isInSafeMode())
/* 5630 */       return "";
/* 5631 */     return this.safeMode.getTurnOffTip();
/*      */   }
/*      */ 
/*      */   long getEditLogSize() throws IOException {
/* 5635 */     return getEditLog().getEditLogSize();
/*      */   }
/*      */ 
/*      */   synchronized CheckpointSignature rollEditLog() throws IOException {
/* 5639 */     checkSuperuserPrivilege();
/* 5640 */     synchronized (this) {
/* 5641 */       if (isInSafeMode()) {
/* 5642 */         throw new SafeModeException("Log not rolled", this.safeMode);
/*      */       }
/* 5644 */       LOG.info(new StringBuilder().append("Roll Edit Log from ").append(Server.getRemoteAddress()).toString());
/* 5645 */       return getFSImage().rollEditLog();
/*      */     }
/*      */   }
/*      */ 
/*      */   synchronized void rollFSImage() throws IOException {
/* 5650 */     if (isInSafeMode()) {
/* 5651 */       throw new SafeModeException("Checkpoint not created", this.safeMode);
/*      */     }
/*      */ 
/* 5654 */     LOG.info(new StringBuilder().append("Roll FSImage from ").append(Server.getRemoteAddress()).toString());
/* 5655 */     getFSImage().rollFSImage();
/*      */   }
/*      */ 
/*      */   private boolean isValidBlock(Block b)
/*      */   {
/* 5662 */     return this.blocksMap.getINode(b) != null;
/*      */   }
/*      */ 
/*      */   UpgradeStatusReport distributedUpgradeProgress(FSConstants.UpgradeAction action)
/*      */     throws IOException
/*      */   {
/* 5670 */     return this.upgradeManager.distributedUpgradeProgress(action);
/*      */   }
/*      */ 
/*      */   UpgradeCommand processDistributedUpgradeCommand(UpgradeCommand comm) throws IOException {
/* 5674 */     return this.upgradeManager.processUpgradeCommand(comm);
/*      */   }
/*      */ 
/*      */   int getDistributedUpgradeVersion() {
/* 5678 */     return this.upgradeManager.getUpgradeVersion();
/*      */   }
/*      */ 
/*      */   UpgradeCommand getDistributedUpgradeCommand() throws IOException {
/* 5682 */     return this.upgradeManager.getBroadcastCommand();
/*      */   }
/*      */ 
/*      */   boolean getDistributedUpgradeState() {
/* 5686 */     return this.upgradeManager.getUpgradeState();
/*      */   }
/*      */ 
/*      */   short getDistributedUpgradeStatus() {
/* 5690 */     return this.upgradeManager.getUpgradeStatus();
/*      */   }
/*      */ 
/*      */   boolean startDistributedUpgradeIfNeeded() throws IOException {
/* 5694 */     return this.upgradeManager.startUpgrade();
/*      */   }
/*      */ 
/*      */   PermissionStatus createFsOwnerPermissions(FsPermission permission) {
/* 5698 */     return new PermissionStatus(this.fsOwner.getShortUserName(), this.supergroup, permission);
/*      */   }
/*      */ 
/*      */   private FSPermissionChecker getPermissionChecker()
/*      */     throws AccessControlException
/*      */   {
/* 5707 */     return this.isPermissionEnabled ? new FSPermissionChecker(this.fsOwnerShortUserName, this.supergroup) : null;
/*      */   }
/*      */ 
/*      */   private void checkOwner(FSPermissionChecker pc, String path)
/*      */     throws AccessControlException
/*      */   {
/* 5713 */     checkPermission(pc, path, true, null, null, null, null);
/*      */   }
/*      */ 
/*      */   private void checkPathAccess(FSPermissionChecker pc, String path, FsAction access)
/*      */     throws AccessControlException
/*      */   {
/* 5719 */     checkPermission(pc, path, false, null, null, access, null);
/*      */   }
/*      */ 
/*      */   private void checkParentAccess(FSPermissionChecker pc, String path, FsAction access)
/*      */     throws AccessControlException
/*      */   {
/* 5725 */     checkPermission(pc, path, false, null, access, null, null);
/*      */   }
/*      */ 
/*      */   private void checkAncestorAccess(FSPermissionChecker pc, String path, FsAction access)
/*      */     throws AccessControlException
/*      */   {
/* 5731 */     checkPermission(pc, path, false, access, null, null, null);
/*      */   }
/*      */ 
/*      */   private void checkTraverse(FSPermissionChecker pc, String path) throws AccessControlException
/*      */   {
/* 5736 */     checkPermission(pc, path, false, null, null, null, null);
/*      */   }
/*      */ 
/*      */   private void checkSuperuserPrivilege() throws AccessControlException {
/* 5740 */     if (this.isPermissionEnabled) {
/* 5741 */       FSPermissionChecker pc = getPermissionChecker();
/* 5742 */       pc.checkSuperuserPrivilege();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void checkPermission(FSPermissionChecker pc, String path, boolean doCheckOwner, FsAction ancestorAccess, FsAction parentAccess, FsAction access, FsAction subAccess)
/*      */     throws AccessControlException
/*      */   {
/* 5755 */     if (!pc.isSuperUser()) {
/* 5756 */       this.dir.waitForReady();
/* 5757 */       synchronized (this) {
/* 5758 */         pc.checkPermission(path, this.dir.rootDir, doCheckOwner, ancestorAccess, parentAccess, access, subAccess);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   void checkFsObjectLimit()
/*      */     throws IOException
/*      */   {
/* 5769 */     if ((this.maxFsObjects != 0L) && (this.maxFsObjects <= this.dir.totalInodes() + getBlocksTotal()))
/*      */     {
/* 5771 */       throw new IOException(new StringBuilder().append("Exceeded the configured number of objects ").append(this.maxFsObjects).append(" in the filesystem.").toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   long getMaxObjects()
/*      */   {
/* 5780 */     return this.maxFsObjects;
/*      */   }
/*      */ 
/*      */   public long getFilesTotal() {
/* 5784 */     return this.dir.totalInodes();
/*      */   }
/*      */ 
/*      */   public long getPendingReplicationBlocks() {
/* 5788 */     return this.pendingReplicationBlocksCount;
/*      */   }
/*      */ 
/*      */   public long getUnderReplicatedBlocks() {
/* 5792 */     return this.underReplicatedBlocksCount;
/*      */   }
/*      */ 
/*      */   public long getCorruptReplicaBlocks()
/*      */   {
/* 5797 */     return this.corruptReplicaBlocksCount;
/*      */   }
/*      */ 
/*      */   public long getScheduledReplicationBlocks() {
/* 5801 */     return this.scheduledReplicationBlocksCount;
/*      */   }
/*      */ 
/*      */   public long getPendingDeletionBlocks() {
/* 5805 */     return this.pendingDeletionBlocksCount;
/*      */   }
/*      */ 
/*      */   public long getExcessBlocks() {
/* 5809 */     return this.excessBlocksCount;
/*      */   }
/*      */ 
/*      */   public synchronized int getBlockCapacity() {
/* 5813 */     return this.blocksMap.getCapacity();
/*      */   }
/*      */ 
/*      */   public String getFSState() {
/* 5817 */     return isInSafeMode() ? "safeMode" : "Operational";
/*      */   }
/*      */ 
/*      */   void registerMBean(Configuration conf)
/*      */   {
/*      */     try
/*      */     {
/* 5835 */       StandardMBean bean = new StandardMBean(this, FSNamesystemMBean.class);
/* 5836 */       this.mbeanName = MBeans.register("NameNode", "FSNamesystemState", bean);
/*      */     } catch (NotCompliantMBeanException e) {
/* 5838 */       e.printStackTrace();
/*      */     }
/* 5840 */     this.mxBean = MBeans.register("NameNode", "NameNodeInfo", this);
/*      */ 
/* 5842 */     LOG.info("Registered FSNamesystemStateMBean and NameNodeMXBean");
/*      */   }
/*      */ 
/*      */   public void shutdown()
/*      */   {
/* 5849 */     if (this.mbeanName != null) {
/* 5850 */       MBeans.unregister(this.mbeanName);
/*      */     }
/* 5852 */     if (this.mxBean != null) {
/* 5853 */       MBeans.unregister(this.mxBean);
/*      */     }
/* 5855 */     if (this.dir != null)
/* 5856 */       this.dir.shutdown();
/*      */   }
/*      */ 
/*      */   public int numLiveDataNodes()
/*      */   {
/* 5866 */     int numLive = 0;
/* 5867 */     synchronized (this.datanodeMap) {
/* 5868 */       Iterator it = this.datanodeMap.values().iterator();
/* 5869 */       while (it.hasNext()) {
/* 5870 */         DatanodeDescriptor dn = (DatanodeDescriptor)it.next();
/* 5871 */         if (!isDatanodeDead(dn)) {
/* 5872 */           numLive++;
/*      */         }
/*      */       }
/*      */     }
/* 5876 */     return numLive;
/*      */   }
/*      */ 
/*      */   public int numDeadDataNodes()
/*      */   {
/* 5885 */     int numDead = 0;
/* 5886 */     synchronized (this.datanodeMap) {
/* 5887 */       Iterator it = this.datanodeMap.values().iterator();
/* 5888 */       while (it.hasNext()) {
/* 5889 */         DatanodeDescriptor dn = (DatanodeDescriptor)it.next();
/* 5890 */         if (isDatanodeDead(dn)) {
/* 5891 */           numDead++;
/*      */         }
/*      */       }
/*      */     }
/* 5895 */     return numDead;
/*      */   }
/*      */ 
/*      */   public void setGenerationStamp(long stamp)
/*      */   {
/* 5902 */     this.generationStamp.setStamp(stamp);
/*      */   }
/*      */ 
/*      */   public long getGenerationStamp()
/*      */   {
/* 5909 */     return this.generationStamp.getStamp();
/*      */   }
/*      */ 
/*      */   private long nextGenerationStamp()
/*      */   {
/* 5916 */     long gs = this.generationStamp.nextStamp();
/* 5917 */     getEditLog().logGenerationStamp(gs);
/* 5918 */     return gs;
/*      */   }
/*      */ 
/*      */   synchronized long nextGenerationStampForBlock(Block block, boolean fromNN)
/*      */     throws IOException
/*      */   {
/* 5930 */     if (isInSafeMode()) {
/* 5931 */       throw new SafeModeException(new StringBuilder().append("Cannot get nextGenStamp for ").append(block).toString(), this.safeMode);
/*      */     }
/* 5933 */     BlocksMap.BlockInfo storedBlock = this.blocksMap.getStoredBlock(block);
/* 5934 */     if (storedBlock == null) {
/* 5935 */       BlocksMap.BlockInfo match = this.blocksMap.getStoredBlock(block.getWithWildcardGS());
/*      */ 
/* 5937 */       String msg = match == null ? new StringBuilder().append(block).append(" is missing").toString() : new StringBuilder().append(block).append(" has out of date GS ").append(block.getGenerationStamp()).append(" found ").append(match.getGenerationStamp()).append(", may already be committed").toString();
/*      */ 
/* 5942 */       LOG.info(msg);
/* 5943 */       throw new IOException(msg);
/*      */     }
/* 5945 */     INodeFile fileINode = storedBlock.getINode();
/* 5946 */     if (!fileINode.isUnderConstruction()) {
/* 5947 */       String msg = new StringBuilder().append(block).append(" is already commited, !fileINode.isUnderConstruction().").toString();
/* 5948 */       LOG.info(msg);
/* 5949 */       throw new IOException(msg);
/*      */     }
/*      */ 
/* 5953 */     if ((!fromNN) && ("NN_Recovery".equals(this.leaseManager.getLeaseByPath(FSDirectory.getFullPathName(fileINode)).getHolder())))
/*      */     {
/* 5955 */       String msg = new StringBuilder().append(block).append("is being recovered by NameNode, ignoring the request from a client").toString();
/*      */ 
/* 5957 */       LOG.info(msg);
/* 5958 */       throw new IOException(msg);
/*      */     }
/* 5960 */     if (!((INodeFileUnderConstruction)fileINode).setLastRecoveryTime(now())) {
/* 5961 */       String msg = new StringBuilder().append(block).append(" is already being recovered, ignoring this request.").toString();
/* 5962 */       LOG.info(msg);
/* 5963 */       throw new IOException(msg);
/*      */     }
/* 5965 */     return nextGenerationStamp();
/*      */   }
/*      */ 
/*      */   void changeLease(String src, String dst, HdfsFileStatus dinfo)
/*      */     throws IOException
/*      */   {
/* 5976 */     boolean destinationExisted = true;
/* 5977 */     if (dinfo == null)
/* 5978 */       destinationExisted = false;
/*      */     String replaceBy;
/*      */     String overwrite;
/*      */     String replaceBy;
/* 5981 */     if ((destinationExisted) && (dinfo.isDir())) {
/* 5982 */       Path spath = new Path(src);
/* 5983 */       Path parent = spath.getParent();
/*      */       String overwrite;
/*      */       String overwrite;
/* 5984 */       if (isRoot(parent))
/* 5985 */         overwrite = parent.toString();
/*      */       else {
/* 5987 */         overwrite = new StringBuilder().append(parent.toString()).append("/").toString();
/*      */       }
/* 5989 */       replaceBy = new StringBuilder().append(dst).append("/").toString();
/*      */     } else {
/* 5991 */       overwrite = src;
/* 5992 */       replaceBy = dst;
/*      */     }
/*      */ 
/* 5995 */     this.leaseManager.changeLease(src, dst, overwrite, replaceBy);
/*      */   }
/*      */ 
/*      */   private boolean isRoot(Path path) {
/* 5999 */     return path.getParent() == null;
/*      */   }
/*      */ 
/*      */   void saveFilesUnderConstruction(DataOutputStream out)
/*      */     throws IOException
/*      */   {
/* 6006 */     synchronized (this.leaseManager) {
/* 6007 */       out.writeInt(this.leaseManager.countPath());
/*      */ 
/* 6009 */       for (LeaseManager.Lease lease : this.leaseManager.getSortedLeases())
/* 6010 */         for (String path : lease.getPaths())
/*      */         {
/* 6012 */           INode node = this.dir.getFileINode(path);
/* 6013 */           if (node == null) {
/* 6014 */             throw new IOException(new StringBuilder().append("saveLeases found path ").append(path).append(" but no matching entry in namespace.").toString());
/*      */           }
/*      */ 
/* 6017 */           if (!node.isUnderConstruction()) {
/* 6018 */             throw new IOException(new StringBuilder().append("saveLeases found path ").append(path).append(" but is not under construction.").toString());
/*      */           }
/*      */ 
/* 6021 */           INodeFileUnderConstruction cons = (INodeFileUnderConstruction)node;
/* 6022 */           FSImage.writeINodeUnderConstruction(out, cons, path);
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized ArrayList<DatanodeDescriptor> getDecommissioningNodes()
/*      */   {
/* 6029 */     ArrayList decommissioningNodes = new ArrayList();
/* 6030 */     ArrayList results = getDatanodeListForReport(FSConstants.DatanodeReportType.LIVE);
/* 6031 */     for (Iterator it = results.iterator(); it.hasNext(); ) {
/* 6032 */       DatanodeDescriptor node = (DatanodeDescriptor)it.next();
/* 6033 */       if (node.isDecommissionInProgress()) {
/* 6034 */         decommissioningNodes.add(node);
/*      */       }
/*      */     }
/* 6037 */     return decommissioningNodes;
/*      */   }
/*      */ 
/*      */   private DelegationTokenSecretManager createDelegationTokenSecretManager(Configuration conf)
/*      */   {
/* 6046 */     return new DelegationTokenSecretManager(conf.getLong("dfs.namenode.delegation.key.update-interval", 86400000L), conf.getLong("dfs.namenode.delegation.token.max-lifetime", 604800000L), conf.getLong("dfs.namenode.delegation.token.renew-interval", 86400000L), DELEGATION_TOKEN_REMOVER_SCAN_INTERVAL, this);
/*      */   }
/*      */ 
/*      */   public DelegationTokenSecretManager getDelegationTokenSecretManager()
/*      */   {
/* 6060 */     return this.dtSecretManager;
/*      */   }
/*      */ 
/*      */   public Token<DelegationTokenIdentifier> getDelegationToken(Text renewer)
/*      */     throws IOException
/*      */   {
/* 6070 */     if (isInSafeMode()) {
/* 6071 */       throw new SafeModeException("Cannot issue delegation token", this.safeMode);
/*      */     }
/* 6073 */     if (!isAllowedDelegationTokenOp()) {
/* 6074 */       throw new IOException("Delegation Token can be issued only with kerberos or web authentication");
/*      */     }
/*      */ 
/* 6077 */     if ((this.dtSecretManager == null) || (!this.dtSecretManager.isRunning())) {
/* 6078 */       LOG.warn("trying to get DT with no secret manager running");
/* 6079 */       return null;
/*      */     }
/*      */ 
/* 6082 */     UserGroupInformation ugi = UserGroupInformation.getCurrentUser();
/* 6083 */     String user = ugi.getUserName();
/* 6084 */     Text owner = new Text(user);
/* 6085 */     Text realUser = null;
/* 6086 */     if (ugi.getRealUser() != null) {
/* 6087 */       realUser = new Text(ugi.getRealUser().getUserName());
/*      */     }
/* 6089 */     DelegationTokenIdentifier dtId = new DelegationTokenIdentifier(owner, renewer, realUser);
/*      */ 
/* 6091 */     Token token = new Token(dtId, this.dtSecretManager);
/*      */ 
/* 6093 */     long expiryTime = this.dtSecretManager.getTokenExpiryTime(dtId);
/* 6094 */     logGetDelegationToken(dtId, expiryTime);
/* 6095 */     return token;
/*      */   }
/*      */ 
/*      */   public long renewDelegationToken(Token<DelegationTokenIdentifier> token)
/*      */     throws SecretManager.InvalidToken, IOException
/*      */   {
/* 6107 */     if (isInSafeMode()) {
/* 6108 */       throw new SafeModeException("Cannot renew delegation token", this.safeMode);
/*      */     }
/* 6110 */     if (!isAllowedDelegationTokenOp()) {
/* 6111 */       throw new IOException("Delegation Token can be renewed only with kerberos or web authentication");
/*      */     }
/*      */ 
/* 6114 */     String renewer = UserGroupInformation.getCurrentUser().getShortUserName();
/* 6115 */     long expiryTime = this.dtSecretManager.renewToken(token, renewer);
/* 6116 */     DelegationTokenIdentifier id = new DelegationTokenIdentifier();
/* 6117 */     ByteArrayInputStream buf = new ByteArrayInputStream(token.getIdentifier());
/* 6118 */     DataInputStream in = new DataInputStream(buf);
/* 6119 */     id.readFields(in);
/* 6120 */     logRenewDelegationToken(id, expiryTime);
/* 6121 */     return expiryTime;
/*      */   }
/*      */ 
/*      */   public void cancelDelegationToken(Token<DelegationTokenIdentifier> token)
/*      */     throws IOException
/*      */   {
/* 6131 */     if (isInSafeMode()) {
/* 6132 */       throw new SafeModeException("Cannot cancel delegation token", this.safeMode);
/*      */     }
/* 6134 */     String canceller = UserGroupInformation.getCurrentUser().getUserName();
/* 6135 */     DelegationTokenIdentifier id = (DelegationTokenIdentifier)this.dtSecretManager.cancelToken(token, canceller);
/*      */ 
/* 6137 */     logCancelDelegationToken(id);
/*      */   }
/*      */ 
/*      */   void saveSecretManagerState(DataOutputStream out)
/*      */     throws IOException
/*      */   {
/* 6144 */     this.dtSecretManager.saveSecretManagerState(out);
/*      */   }
/*      */ 
/*      */   void loadSecretManagerState(DataInputStream in)
/*      */     throws IOException
/*      */   {
/* 6151 */     this.dtSecretManager.loadSecretManagerState(in);
/*      */   }
/*      */ 
/*      */   private void logGetDelegationToken(DelegationTokenIdentifier id, long expiryTime)
/*      */     throws IOException
/*      */   {
/* 6162 */     synchronized (this) {
/* 6163 */       getEditLog().logGetDelegationToken(id, expiryTime);
/*      */     }
/* 6165 */     getEditLog().logSync();
/*      */   }
/*      */ 
/*      */   private void logRenewDelegationToken(DelegationTokenIdentifier id, long expiryTime)
/*      */     throws IOException
/*      */   {
/* 6176 */     synchronized (this) {
/* 6177 */       getEditLog().logRenewDelegationToken(id, expiryTime);
/*      */     }
/* 6179 */     getEditLog().logSync();
/*      */   }
/*      */ 
/*      */   private void logCancelDelegationToken(DelegationTokenIdentifier id)
/*      */     throws IOException
/*      */   {
/* 6190 */     synchronized (this) {
/* 6191 */       getEditLog().logCancelDelegationToken(id);
/*      */     }
/* 6193 */     getEditLog().logSync();
/*      */   }
/*      */ 
/*      */   public void logUpdateMasterKey(DelegationKey key)
/*      */     throws IOException
/*      */   {
/* 6202 */     synchronized (this) {
/* 6203 */       getEditLog().logUpdateMasterKey(key);
/*      */     }
/* 6205 */     getEditLog().logSync();
/*      */   }
/*      */ 
/*      */   private boolean isAllowedDelegationTokenOp()
/*      */     throws IOException
/*      */   {
/* 6213 */     UserGroupInformation.AuthenticationMethod authMethod = getConnectionAuthenticationMethod();
/* 6214 */     if ((UserGroupInformation.isSecurityEnabled()) && (authMethod != UserGroupInformation.AuthenticationMethod.KERBEROS) && (authMethod != UserGroupInformation.AuthenticationMethod.KERBEROS_SSL) && (authMethod != UserGroupInformation.AuthenticationMethod.CERTIFICATE))
/*      */     {
/* 6218 */       return false;
/*      */     }
/* 6220 */     return true;
/*      */   }
/*      */ 
/*      */   private UserGroupInformation.AuthenticationMethod getConnectionAuthenticationMethod()
/*      */     throws IOException
/*      */   {
/* 6230 */     UserGroupInformation ugi = UserGroupInformation.getCurrentUser();
/* 6231 */     UserGroupInformation.AuthenticationMethod authMethod = ugi.getAuthenticationMethod();
/* 6232 */     if (authMethod == UserGroupInformation.AuthenticationMethod.PROXY) {
/* 6233 */       authMethod = ugi.getRealUser().getAuthenticationMethod();
/*      */     }
/* 6235 */     return authMethod;
/*      */   }
/*      */ 
/*      */   public String getHostName()
/*      */   {
/* 6240 */     return this.nameNodeHostName;
/*      */   }
/*      */ 
/*      */   public String getVersion()
/*      */   {
/* 6245 */     return new StringBuilder().append(VersionInfo.getVersion()).append(", r").append(VersionInfo.getRevision()).toString();
/*      */   }
/*      */ 
/*      */   public long getUsed()
/*      */   {
/* 6250 */     return getCapacityUsed();
/*      */   }
/*      */ 
/*      */   public long getFree()
/*      */   {
/* 6255 */     return getCapacityRemaining();
/*      */   }
/*      */ 
/*      */   public long getTotal()
/*      */   {
/* 6260 */     return getCapacityTotal();
/*      */   }
/*      */ 
/*      */   public String getSafemode()
/*      */   {
/* 6265 */     if (!isInSafeMode())
/* 6266 */       return "";
/* 6267 */     return new StringBuilder().append("Safe mode is ON.").append(getSafeModeTip()).toString();
/*      */   }
/*      */ 
/*      */   public boolean isUpgradeFinalized()
/*      */   {
/* 6272 */     return getFSImage().isUpgradeFinalized();
/*      */   }
/*      */ 
/*      */   public long getNonDfsUsedSpace()
/*      */   {
/* 6277 */     return getCapacityUsedNonDFS();
/*      */   }
/*      */ 
/*      */   public float getPercentUsed()
/*      */   {
/* 6282 */     return getCapacityUsedPercent();
/*      */   }
/*      */ 
/*      */   public float getPercentRemaining()
/*      */   {
/* 6287 */     return getCapacityRemainingPercent();
/*      */   }
/*      */ 
/*      */   public long getTotalBlocks()
/*      */   {
/* 6292 */     return getBlocksTotal();
/*      */   }
/*      */ 
/*      */   public long getTotalFiles()
/*      */   {
/* 6297 */     return getFilesTotal();
/*      */   }
/*      */ 
/*      */   public int getThreads()
/*      */   {
/* 6302 */     return ManagementFactory.getThreadMXBean().getThreadCount();
/*      */   }
/*      */ 
/*      */   public String getLiveNodes()
/*      */   {
/* 6311 */     Map info = new HashMap();
/* 6312 */     ArrayList aliveNodeList = getDatanodeListForReport(FSConstants.DatanodeReportType.LIVE);
/*      */ 
/* 6314 */     for (DatanodeDescriptor node : aliveNodeList) {
/* 6315 */       Map innerinfo = new HashMap();
/* 6316 */       innerinfo.put("lastContact", Long.valueOf(getLastContact(node)));
/* 6317 */       innerinfo.put("usedSpace", Long.valueOf(getDfsUsed(node)));
/* 6318 */       info.put(node.getHostName(), innerinfo);
/*      */     }
/* 6320 */     return JSON.toString(info);
/*      */   }
/*      */ 
/*      */   public String getDeadNodes()
/*      */   {
/* 6329 */     Map info = new HashMap();
/* 6330 */     ArrayList deadNodeList = getDatanodeListForReport(FSConstants.DatanodeReportType.DEAD);
/*      */ 
/* 6332 */     removeDecomNodeFromDeadList(deadNodeList);
/* 6333 */     for (DatanodeDescriptor node : deadNodeList) {
/* 6334 */       Map innerinfo = new HashMap();
/* 6335 */       innerinfo.put("lastContact", Long.valueOf(getLastContact(node)));
/* 6336 */       info.put(node.getHostName(), innerinfo);
/*      */     }
/* 6338 */     return JSON.toString(info);
/*      */   }
/*      */ 
/*      */   public String getDecomNodes()
/*      */   {
/* 6347 */     Map info = new HashMap();
/* 6348 */     ArrayList decomNodeList = getDecommissioningNodes();
/*      */ 
/* 6350 */     for (DatanodeDescriptor node : decomNodeList) {
/* 6351 */       Map innerinfo = new HashMap();
/* 6352 */       innerinfo.put("underReplicatedBlocks", Integer.valueOf(node.decommissioningStatus.getUnderReplicatedBlocks()));
/*      */ 
/* 6354 */       innerinfo.put("decommissionOnlyReplicas", Integer.valueOf(node.decommissioningStatus.getDecommissionOnlyReplicas()));
/*      */ 
/* 6356 */       innerinfo.put("underReplicateInOpenFiles", Integer.valueOf(node.decommissioningStatus.getUnderReplicatedInOpenFiles()));
/*      */ 
/* 6358 */       info.put(node.getHostName(), innerinfo);
/*      */     }
/* 6360 */     return JSON.toString(info);
/*      */   }
/*      */ 
/*      */   public String getNameDirStatuses()
/*      */   {
/* 6365 */     Map statusMap = new HashMap();
/*      */ 
/* 6368 */     Map activeDirs = new HashMap();
/* 6369 */     Iterator it = getFSImage().dirIterator();
/* 6370 */     while (it.hasNext()) {
/* 6371 */       Storage.StorageDirectory st = (Storage.StorageDirectory)it.next();
/* 6372 */       activeDirs.put(st.getRoot(), st.getStorageDirType());
/*      */     }
/* 6374 */     statusMap.put("active", activeDirs);
/*      */ 
/* 6376 */     List removedStorageDirs = getFSImage().getRemovedStorageDirs();
/*      */ 
/* 6378 */     Map failedDirs = new HashMap();
/* 6379 */     for (Storage.StorageDirectory st : removedStorageDirs) {
/* 6380 */       failedDirs.put(st.getRoot(), st.getStorageDirType());
/*      */     }
/* 6382 */     statusMap.put("failed", failedDirs);
/*      */ 
/* 6384 */     return JSON.toString(statusMap);
/*      */   }
/*      */ 
/*      */   private long getLastContact(DatanodeDescriptor alivenode) {
/* 6388 */     return (System.currentTimeMillis() - alivenode.getLastUpdate()) / 1000L;
/*      */   }
/*      */ 
/*      */   private long getDfsUsed(DatanodeDescriptor alivenode) {
/* 6392 */     return alivenode.getDfsUsed();
/*      */   }
/*      */ 
/*      */   private static int roundBytesToGBytes(long bytes) {
/* 6396 */     return Math.round((float)bytes / 1.073742E+009F);
/*      */   }
/*      */ 
/*      */   public void getMetrics(MetricsBuilder builder, boolean all)
/*      */   {
/* 6401 */     builder.addRecord("FSNamesystem").setContext("dfs").addGauge("FilesTotal", "", getFilesTotal()).addGauge("BlocksTotal", "", getBlocksTotal()).addGauge("CapacityTotalGB", "", roundBytesToGBytes(getCapacityTotal())).addGauge("CapacityUsedGB", "", roundBytesToGBytes(getCapacityUsed())).addGauge("CapacityRemainingGB", "", roundBytesToGBytes(getCapacityRemaining())).addGauge("CapacityTotal", "", getCapacityTotal()).addGauge("CapacityUsed", "", getCapacityUsed()).addGauge("CapacityRemaining", "", getCapacityRemaining()).addGauge("CapacityUsedNonDFS", "", getNonDfsUsedSpace()).addGauge("TotalLoad", "", getTotalLoad()).addGauge("CorruptBlocks", "", getCorruptReplicaBlocks()).addGauge("ExcessBlocks", "", getExcessBlocks()).addGauge("PendingDeletionBlocks", "", getPendingDeletionBlocks()).addGauge("PendingReplicationBlocks", "", getPendingReplicationBlocks()).addGauge("UnderReplicatedBlocks", "", getUnderReplicatedBlocks()).addGauge("ScheduledReplicationBlocks", "", getScheduledReplicationBlocks()).addGauge("MissingBlocks", "", getMissingBlocksCount()).addGauge("BlockCapacity", "", getBlockCapacity()).addGauge("StaleDataNodes", "Number of datanodes marked stale due to delayed heartbeat", getNumStaleNodes());
/*      */   }
/*      */ 
/*      */   private void registerWith(MetricsSystem ms)
/*      */   {
/* 6430 */     ms.register("FSNamesystemMetrics", "FSNamesystem metrics", this);
/*      */   }
/*      */ 
/*      */   private boolean isExternalInvocation()
/*      */   {
/* 6440 */     return Server.getRemoteIp() != null;
/*      */   }
/*      */ 
/*      */   void logFsckEvent(String src, InetAddress remoteAddress)
/*      */     throws IOException
/*      */   {
/* 6447 */     if (auditLog.isInfoEnabled())
/* 6448 */       logAuditEvent(UserGroupInformation.getCurrentUser(), remoteAddress, "fsck", src, null, null);
/*      */   }
/*      */ 
/*      */   void removeDecomNodeFromDeadList(ArrayList<DatanodeDescriptor> dead)
/*      */   {
/* 6463 */     if (this.hostsReader.getHosts().isEmpty()) {
/* 6464 */       return;
/*      */     }
/* 6466 */     for (Iterator it = dead.iterator(); it.hasNext(); ) {
/* 6467 */       DatanodeDescriptor node = (DatanodeDescriptor)it.next();
/* 6468 */       if ((!inHostsList(node, null)) && (!inExcludedHostsList(node, null)) && (node.isDecommissioned()))
/*      */       {
/* 6474 */         it.remove();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/* 6481 */     return new StringBuilder().append(getClass().getSimpleName()).append(": ").append(this.host2DataNodeMap).toString();
/*      */   }
/*      */ 
/*      */   void setNumStaleNodes(int numStaleNodes)
/*      */   {
/* 6491 */     this.numStaleNodes = numStaleNodes;
/*      */   }
/*      */ 
/*      */   public int getNumStaleNodes()
/*      */   {
/* 6499 */     return this.numStaleNodes;
/*      */   }
/*      */ 
/*      */   public boolean shouldAvoidStaleDataNodesForWrite()
/*      */   {
/* 6512 */     return (this.avoidStaleDataNodesForWrite) && (this.numStaleNodes <= this.heartbeats.size() * this.ratioUseStaleDataNodesForWrite);
/*      */   }
/*      */ 
/*      */   private Collection<CorruptFileBlockInfo> getCorruptFileBlocks()
/*      */   {
/* 6543 */     ArrayList corruptFiles = new ArrayList();
/*      */ 
/* 6545 */     for (Block blk : this.neededReplications.getCorruptQueue()) {
/* 6546 */       INode inode = this.blocksMap.getINode(blk);
/* 6547 */       if ((inode != null) && (countNodes(blk).liveReplicas() == 0)) {
/* 6548 */         String filePath = inode.getFullPathName();
/* 6549 */         CorruptFileBlockInfo info = new CorruptFileBlockInfo(filePath, blk);
/* 6550 */         corruptFiles.add(info);
/* 6551 */         if (corruptFiles.size() >= this.maxCorruptFilesReturned) {
/*      */           break;
/*      */         }
/*      */       }
/*      */     }
/* 6556 */     return corruptFiles;
/*      */   }
/*      */ 
/*      */   synchronized Collection<CorruptFileBlockInfo> listCorruptFileBlocks()
/*      */     throws AccessControlException, IOException
/*      */   {
/* 6567 */     checkSuperuserPrivilege();
/* 6568 */     return getCorruptFileBlocks();
/*      */   }
/*      */ 
/*      */   static class CorruptFileBlockInfo
/*      */   {
/*      */     String path;
/*      */     Block block;
/*      */ 
/*      */     public CorruptFileBlockInfo(String p, Block b)
/*      */     {
/* 6527 */       this.path = p;
/* 6528 */       this.block = b;
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 6533 */       return this.block.getBlockName() + "\t" + this.path;
/*      */     }
/*      */   }
/*      */ 
/*      */   class SafeModeMonitor
/*      */     implements Runnable
/*      */   {
/*      */     private static final long recheckInterval = 1000L;
/*      */ 
/*      */     SafeModeMonitor()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/* 5457 */       while ((FSNamesystem.this.fsRunning) && (FSNamesystem.this.safeMode != null) && (!FSNamesystem.this.safeMode.canLeave()))
/*      */         try {
/* 5459 */           Thread.sleep(1000L);
/*      */         }
/*      */         catch (InterruptedException ie)
/*      */         {
/*      */         }
/*      */       try {
/* 5465 */         FSNamesystem.this.leaveSafeMode(true);
/*      */       } catch (SafeModeException es) {
/* 5467 */         String msg = "SafeModeMonitor may not run during distributed upgrade.";
/* 5468 */         if (!$assertionsDisabled) throw new AssertionError(msg);
/* 5469 */         throw new RuntimeException(msg, es);
/*      */       }
/* 5471 */       FSNamesystem.this.smmthread = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   class SafeModeInfo
/*      */   {
/*      */     private double threshold;
/*      */     private int datanodeThreshold;
/*      */     private int extension;
/*      */     private int safeReplication;
/* 5131 */     private long reached = -1L;
/*      */     int blockTotal;
/*      */     private int blockSafe;
/* 5137 */     private long lastStatusReport = 0L;
/*      */ 
/*      */     SafeModeInfo(Configuration conf)
/*      */     {
/* 5146 */       this.threshold = conf.getFloat("dfs.safemode.threshold.pct", 0.95F);
/* 5147 */       this.datanodeThreshold = conf.getInt("dfs.namenode.safemode.min.datanodes", 0);
/*      */ 
/* 5150 */       this.extension = conf.getInt("dfs.safemode.extension", 0);
/* 5151 */       this.safeReplication = conf.getInt("dfs.replication.min", 1);
/* 5152 */       this.blockTotal = 0;
/* 5153 */       this.blockSafe = 0;
/*      */ 
/* 5155 */       FSNamesystem.LOG.info("dfs.safemode.threshold.pct          = " + this.threshold);
/* 5156 */       FSNamesystem.LOG.info("dfs.namenode.safemode.min.datanodes = " + this.datanodeThreshold);
/* 5157 */       FSNamesystem.LOG.info("dfs.safemode.extension              = " + this.extension);
/*      */     }
/*      */ 
/*      */     private SafeModeInfo()
/*      */     {
/* 5169 */       this.threshold = 1.5D;
/* 5170 */       this.datanodeThreshold = 2147483647;
/* 5171 */       this.extension = 2147483647;
/* 5172 */       this.safeReplication = 32768;
/* 5173 */       this.blockTotal = -1;
/* 5174 */       this.blockSafe = -1;
/* 5175 */       this.reached = -1L;
/* 5176 */       enter();
/* 5177 */       reportStatus("STATE* Safe mode is ON", true);
/*      */     }
/*      */ 
/*      */     synchronized boolean isOn()
/*      */     {
/*      */       try
/*      */       {
/* 5187 */         if ((!$assertionsDisabled) && (!isConsistent())) throw new AssertionError(" SafeMode: Inconsistent filesystem state: Total num of blocks, active blocks, or total safe blocks don't match"); 
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/* 5190 */         System.err.print(StringUtils.stringifyException(e));
/*      */       }
/* 5192 */       return this.reached >= 0L;
/*      */     }
/*      */ 
/*      */     void enter()
/*      */     {
/* 5199 */       this.reached = 0L;
/*      */     }
/*      */ 
/*      */     synchronized void leave(boolean checkForUpgrades)
/*      */     {
/* 5209 */       if (checkForUpgrades)
/*      */       {
/* 5211 */         boolean needUpgrade = false;
/*      */         try {
/* 5213 */           needUpgrade = FSNamesystem.this.startDistributedUpgradeIfNeeded();
/*      */         } catch (IOException e) {
/* 5215 */           FSNamesystem.LOG.error(StringUtils.stringifyException(e));
/*      */         }
/* 5217 */         if (needUpgrade)
/*      */         {
/* 5219 */           FSNamesystem.this.safeMode = new SafeModeInfo(FSNamesystem.this);
/* 5220 */           return;
/*      */         }
/*      */       }
/*      */ 
/* 5224 */       long startTimeMisReplicatedScan = FSNamesystem.now();
/* 5225 */       FSNamesystem.this.processMisReplicatedBlocks();
/* 5226 */       NameNode.stateChangeLog.info("STATE* Safe mode termination scan for invalid, over- and under-replicated blocks completed in " + (FSNamesystem.now() - startTimeMisReplicatedScan) + " msec");
/*      */ 
/* 5231 */       long timeInSafemode = FSNamesystem.now() - FSNamesystem.this.systemStart;
/* 5232 */       NameNode.stateChangeLog.info("STATE* Leaving safe mode after " + timeInSafemode / 1000L + " secs");
/*      */ 
/* 5234 */       NameNode.getNameNodeMetrics().setSafeModeTime(timeInSafemode);
/*      */ 
/* 5236 */       if (this.reached >= 0L) {
/* 5237 */         NameNode.stateChangeLog.info("STATE* Safe mode is OFF");
/*      */       }
/* 5239 */       this.reached = -1L;
/* 5240 */       FSNamesystem.this.safeMode = null;
/* 5241 */       NameNode.stateChangeLog.info("STATE* Network topology has " + FSNamesystem.this.clusterMap.getNumOfRacks() + " racks and " + FSNamesystem.this.clusterMap.getNumOfLeaves() + " datanodes");
/*      */ 
/* 5244 */       NameNode.stateChangeLog.info("STATE* UnderReplicatedBlocks has " + FSNamesystem.this.neededReplications.size() + " blocks");
/*      */     }
/*      */ 
/*      */     synchronized boolean canLeave()
/*      */     {
/* 5255 */       if (this.reached == 0L)
/* 5256 */         return false;
/* 5257 */       if (FSNamesystem.now() - this.reached < this.extension) {
/* 5258 */         reportStatus("STATE* Safe mode ON", false);
/* 5259 */         return false;
/*      */       }
/* 5261 */       return !needEnter();
/*      */     }
/*      */ 
/*      */     boolean needEnter()
/*      */     {
/* 5269 */       return (getSafeBlockRatio() < this.threshold) || (FSNamesystem.this.numLiveDataNodes() < this.datanodeThreshold);
/*      */     }
/*      */ 
/*      */     private float getSafeBlockRatio()
/*      */     {
/* 5278 */       return this.blockTotal == 0 ? 1.0F : this.blockSafe / this.blockTotal;
/*      */     }
/*      */ 
/*      */     private void checkMode()
/*      */     {
/* 5285 */       if (needEnter()) {
/* 5286 */         enter();
/* 5287 */         reportStatus("STATE* Safe mode ON", false);
/* 5288 */         return;
/*      */       }
/*      */ 
/* 5291 */       if ((!isOn()) || (this.extension <= 0) || (this.threshold <= 0.0D))
/*      */       {
/* 5293 */         leave(true);
/* 5294 */         return;
/*      */       }
/* 5296 */       if (this.reached > 0L) {
/* 5297 */         reportStatus("STATE* Safe mode ON", false);
/* 5298 */         return;
/*      */       }
/*      */ 
/* 5301 */       this.reached = FSNamesystem.now();
/* 5302 */       FSNamesystem.this.smmthread = new Daemon(new FSNamesystem.SafeModeMonitor(FSNamesystem.this));
/* 5303 */       FSNamesystem.this.smmthread.start();
/* 5304 */       reportStatus("STATE* Safe mode extension entered", true);
/*      */     }
/*      */ 
/*      */     synchronized void setBlockTotal(int total)
/*      */     {
/* 5311 */       this.blockTotal = total;
/* 5312 */       checkMode();
/*      */     }
/*      */ 
/*      */     synchronized void incrementSafeBlockCount(short replication)
/*      */     {
/* 5321 */       if (replication == this.safeReplication)
/* 5322 */         this.blockSafe += 1;
/* 5323 */       checkMode();
/*      */     }
/*      */ 
/*      */     synchronized void decrementSafeBlockCount(short replication)
/*      */     {
/* 5332 */       if (replication == this.safeReplication - 1)
/* 5333 */         this.blockSafe -= 1;
/* 5334 */       checkMode();
/*      */     }
/*      */ 
/*      */     boolean isManual()
/*      */     {
/* 5341 */       return this.extension == 2147483647;
/*      */     }
/*      */ 
/*      */     void setManual()
/*      */     {
/* 5348 */       this.extension = 2147483647;
/*      */     }
/*      */ 
/*      */     String getTurnOffTip()
/*      */     {
/* 5355 */       String leaveMsg = "Safe mode will be turned off automatically";
/* 5356 */       if (this.reached < 0L)
/* 5357 */         return "Safe mode is OFF";
/* 5358 */       if (isManual()) {
/* 5359 */         if (FSNamesystem.this.getDistributedUpgradeState()) {
/* 5360 */           return leaveMsg + " upon completion of " + "the distributed upgrade: upgrade progress = " + FSNamesystem.this.getDistributedUpgradeStatus() + "%";
/*      */         }
/*      */ 
/* 5363 */         leaveMsg = "Use \"hadoop dfsadmin -safemode leave\" to turn safe mode off";
/*      */       }
/* 5365 */       if (this.blockTotal < 0) {
/* 5366 */         return leaveMsg + ".";
/*      */       }
/* 5368 */       int numLive = FSNamesystem.this.numLiveDataNodes();
/* 5369 */       String msg = "";
/* 5370 */       if (this.reached == 0L) {
/* 5371 */         if (getSafeBlockRatio() < this.threshold) {
/* 5372 */           msg = msg + String.format("The reported blocks is only %d but the threshold is %.4f and the total blocks %d.", new Object[] { Integer.valueOf(this.blockSafe), Double.valueOf(this.threshold), Integer.valueOf(this.blockTotal) });
/*      */         }
/*      */ 
/* 5377 */         if (numLive < this.datanodeThreshold) {
/* 5378 */           if (!"".equals(msg)) {
/* 5379 */             msg = msg + "\n";
/*      */           }
/* 5381 */           msg = msg + String.format("The number of live datanodes %d needs an additional %d live datanodes to reach the minimum number %d.", new Object[] { Integer.valueOf(numLive), Integer.valueOf(this.datanodeThreshold - numLive), Integer.valueOf(this.datanodeThreshold) });
/*      */         }
/*      */ 
/* 5386 */         msg = msg + " " + leaveMsg;
/*      */       } else {
/* 5388 */         msg = String.format("The reported blocks %d has reached the threshold %.4f of total blocks %d.", new Object[] { Integer.valueOf(this.blockSafe), Double.valueOf(this.threshold), Integer.valueOf(this.blockTotal) });
/*      */ 
/* 5392 */         if (this.datanodeThreshold > 0) {
/* 5393 */           msg = msg + String.format(" The number of live datanodes %d has reached the minimum number %d.", new Object[] { Integer.valueOf(numLive), Integer.valueOf(this.datanodeThreshold) });
/*      */         }
/*      */ 
/* 5397 */         msg = msg + " " + leaveMsg;
/*      */       }
/* 5399 */       if ((this.reached == 0L) || (isManual())) {
/* 5400 */         return msg + ".";
/*      */       }
/*      */ 
/* 5403 */       return msg + " in " + Math.abs(this.reached + this.extension - FSNamesystem.now()) / 1000L + " seconds.";
/*      */     }
/*      */ 
/*      */     private void reportStatus(String msg, boolean rightNow)
/*      */     {
/* 5411 */       long curTime = FSNamesystem.now();
/* 5412 */       if ((!rightNow) && (curTime - this.lastStatusReport < 20000L))
/* 5413 */         return;
/* 5414 */       NameNode.stateChangeLog.info(msg + " \n" + getTurnOffTip());
/* 5415 */       this.lastStatusReport = curTime;
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 5422 */       String resText = "Current safe block ratio = " + getSafeBlockRatio() + ". Target threshold = " + this.threshold + ". Minimal replication = " + this.safeReplication + ".";
/*      */ 
/* 5426 */       if (this.reached > 0L)
/* 5427 */         resText = resText + " Threshold was reached " + new Date(this.reached) + ".";
/* 5428 */       return resText;
/*      */     }
/*      */ 
/*      */     boolean isConsistent()
/*      */       throws IOException
/*      */     {
/* 5436 */       if ((this.blockTotal == -1) && (this.blockSafe == -1)) {
/* 5437 */         return true;
/*      */       }
/* 5439 */       int activeBlocks = FSNamesystem.this.blocksMap.size() - (int)FSNamesystem.this.pendingDeletionBlocksCount;
/* 5440 */       return (this.blockTotal == activeBlocks) || ((this.blockSafe >= 0) && (this.blockSafe <= this.blockTotal));
/*      */     }
/*      */   }
/*      */ 
/*      */   static class NumberReplicas
/*      */   {
/*      */     private int liveReplicas;
/*      */     private int decommissionedReplicas;
/*      */     private int corruptReplicas;
/*      */     private int excessReplicas;
/*      */ 
/*      */     NumberReplicas()
/*      */     {
/* 4763 */       initialize(0, 0, 0, 0);
/*      */     }
/*      */ 
/*      */     NumberReplicas(int live, int decommissioned, int corrupt, int excess) {
/* 4767 */       initialize(live, decommissioned, corrupt, excess);
/*      */     }
/*      */ 
/*      */     void initialize(int live, int decommissioned, int corrupt, int excess) {
/* 4771 */       this.liveReplicas = live;
/* 4772 */       this.decommissionedReplicas = decommissioned;
/* 4773 */       this.corruptReplicas = corrupt;
/* 4774 */       this.excessReplicas = excess;
/*      */     }
/*      */ 
/*      */     int liveReplicas() {
/* 4778 */       return this.liveReplicas;
/*      */     }
/*      */     int decommissionedReplicas() {
/* 4781 */       return this.decommissionedReplicas;
/*      */     }
/*      */     int corruptReplicas() {
/* 4784 */       return this.corruptReplicas;
/*      */     }
/*      */     int excessReplicas() {
/* 4787 */       return this.excessReplicas;
/*      */     }
/*      */   }
/*      */ 
/*      */   class ReplicationMonitor
/*      */     implements Runnable
/*      */   {
/*      */     ReplicateQueueProcessingStats replicateQueueStats;
/*      */     InvalidateQueueProcessingStats invalidateQueueStats;
/*      */ 
/*      */     ReplicationMonitor()
/*      */     {
/* 3157 */       this.replicateQueueStats = new ReplicateQueueProcessingStats();
/*      */ 
/* 3159 */       this.invalidateQueueStats = new InvalidateQueueProcessingStats();
/*      */     }
/*      */ 
/*      */     public void run() {
/* 3163 */       while (FSNamesystem.this.fsRunning)
/*      */         try {
/* 3165 */           FSNamesystem.this.computeDatanodeWork();
/* 3166 */           FSNamesystem.this.processPendingReplications();
/* 3167 */           Thread.sleep(FSNamesystem.this.replicationRecheckInterval);
/*      */         } catch (InterruptedException ie) {
/* 3169 */           FSNamesystem.LOG.warn("ReplicationMonitor thread received InterruptedException" + ie);
/* 3170 */           break;
/*      */         } catch (IOException ie) {
/* 3172 */           FSNamesystem.LOG.warn("ReplicationMonitor thread received exception. " + ie + " " + StringUtils.stringifyException(ie));
/*      */         }
/*      */         catch (Throwable t) {
/* 3175 */           FSNamesystem.LOG.warn("ReplicationMonitor thread received Runtime exception. " + t + " " + StringUtils.stringifyException(t));
/*      */ 
/* 3177 */           Runtime.getRuntime().exit(-1);
/*      */         }
/*      */     }
/*      */ 
/*      */     private class InvalidateQueueProcessingStats extends QueueProcessingStatistics
/*      */     {
/*      */       InvalidateQueueProcessingStats()
/*      */       {
/* 3219 */         super("blocks", FSNamesystem.LOG);
/*      */       }
/*      */ 
/*      */       public boolean preCheckIsLastCycle(int maxWorkToProcess)
/*      */       {
/* 3225 */         return false;
/*      */       }
/*      */ 
/*      */       public boolean postCheckIsLastCycle(int workFound)
/*      */       {
/* 3231 */         return FSNamesystem.this.recentInvalidateSets.isEmpty();
/*      */       }
/*      */     }
/*      */ 
/*      */     private class ReplicateQueueProcessingStats extends QueueProcessingStatistics
/*      */     {
/*      */       ReplicateQueueProcessingStats()
/*      */       {
/* 3199 */         super("blocks", FSNamesystem.LOG);
/*      */       }
/*      */ 
/*      */       public boolean preCheckIsLastCycle(int maxWorkToProcess)
/*      */       {
/* 3205 */         return maxWorkToProcess >= FSNamesystem.this.neededReplications.size();
/*      */       }
/*      */ 
/*      */       public boolean postCheckIsLastCycle(int workFound)
/*      */       {
/* 3211 */         return false;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   class HeartbeatMonitor
/*      */     implements Runnable
/*      */   {
/*      */     private long lastHeartbeatCheck;
/*      */     private long lastAccessKeyUpdate;
/*      */ 
/*      */     HeartbeatMonitor()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/* 3131 */       while (FSNamesystem.this.fsRunning) {
/*      */         try {
/* 3133 */           long now = FSNamesystem.now();
/* 3134 */           if (this.lastHeartbeatCheck + FSNamesystem.this.heartbeatRecheckInterval < now) {
/* 3135 */             FSNamesystem.this.heartbeatCheck();
/* 3136 */             this.lastHeartbeatCheck = now;
/*      */           }
/* 3138 */           if ((FSNamesystem.this.isAccessTokenEnabled) && (this.lastAccessKeyUpdate + FSNamesystem.this.accessKeyUpdateInterval < now)) {
/* 3139 */             FSNamesystem.this.updateAccessKey();
/* 3140 */             this.lastAccessKeyUpdate = now;
/*      */           }
/*      */         } catch (Exception e) {
/* 3143 */           FSNamesystem.LOG.error(StringUtils.stringifyException(e));
/*      */         }
/*      */         try {
/* 3146 */           Thread.sleep(5000L);
/*      */         }
/*      */         catch (InterruptedException ie)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static enum CompleteFileStatus
/*      */   {
/* 2027 */     OPERATION_FAILED, 
/* 2028 */     STILL_WAITING, 
/* 2029 */     COMPLETE_SUCCESS;
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.FSNamesystem
 * JD-Core Version:    0.6.1
 */
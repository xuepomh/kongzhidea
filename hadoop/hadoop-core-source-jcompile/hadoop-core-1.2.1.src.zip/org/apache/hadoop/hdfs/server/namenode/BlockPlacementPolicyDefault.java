/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.classification.InterfaceAudience.Private;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlock;
/*     */ import org.apache.hadoop.net.NetworkTopology;
/*     */ import org.apache.hadoop.net.Node;
/*     */ import org.apache.hadoop.net.NodeBase;
/*     */ 
/*     */ @InterfaceAudience.Private
/*     */ public class BlockPlacementPolicyDefault extends BlockPlacementPolicy
/*     */ {
/*     */   protected boolean considerLoad;
/*     */   protected NetworkTopology clusterMap;
/*     */   private FSClusterStats stats;
/*     */   private long staleInterval;
/*     */ 
/*     */   BlockPlacementPolicyDefault(Configuration conf, FSClusterStats stats, NetworkTopology clusterMap)
/*     */   {
/*  57 */     initialize(conf, stats, clusterMap);
/*     */   }
/*     */ 
/*     */   BlockPlacementPolicyDefault()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void initialize(Configuration conf, FSClusterStats stats, NetworkTopology clusterMap)
/*     */   {
/*  66 */     this.considerLoad = conf.getBoolean("dfs.namenode.replication.considerLoad", true);
/*     */ 
/*  68 */     this.stats = stats;
/*  69 */     this.clusterMap = clusterMap;
/*  70 */     this.staleInterval = conf.getLong("dfs.namenode.stale.datanode.interval", 30000L);
/*     */   }
/*     */ 
/*     */   public DatanodeDescriptor[] chooseTarget(String srcPath, int numOfReplicas, DatanodeDescriptor writer, List<DatanodeDescriptor> chosenNodes, long blocksize)
/*     */   {
/*  81 */     return chooseTarget(numOfReplicas, writer, chosenNodes, null, blocksize);
/*     */   }
/*     */ 
/*     */   public DatanodeDescriptor[] chooseTarget(String srcPath, int numOfReplicas, DatanodeDescriptor writer, List<DatanodeDescriptor> chosenNodes, HashMap<Node, Node> excludedNodes, long blocksize)
/*     */   {
/*  91 */     return chooseTarget(numOfReplicas, writer, chosenNodes, excludedNodes, blocksize);
/*     */   }
/*     */ 
/*     */   public DatanodeDescriptor[] chooseTarget(FSInodeInfo srcInode, int numOfReplicas, DatanodeDescriptor writer, List<DatanodeDescriptor> chosenNodes, long blocksize)
/*     */   {
/* 102 */     return chooseTarget(numOfReplicas, writer, chosenNodes, null, blocksize);
/*     */   }
/*     */ 
/*     */   DatanodeDescriptor[] chooseTarget(int numOfReplicas, DatanodeDescriptor writer, List<DatanodeDescriptor> chosenNodes, HashMap<Node, Node> excludedNodes, long blocksize)
/*     */   {
/* 113 */     if ((numOfReplicas == 0) || (this.clusterMap.getNumOfLeaves() == 0)) {
/* 114 */       return new DatanodeDescriptor[0];
/*     */     }
/*     */ 
/* 117 */     if (excludedNodes == null) {
/* 118 */       excludedNodes = new HashMap();
/*     */     }
/*     */ 
/* 121 */     int clusterSize = this.clusterMap.getNumOfLeaves();
/* 122 */     int totalNumOfReplicas = chosenNodes.size() + numOfReplicas;
/* 123 */     if (totalNumOfReplicas > clusterSize) {
/* 124 */       numOfReplicas -= totalNumOfReplicas - clusterSize;
/* 125 */       totalNumOfReplicas = clusterSize;
/*     */     }
/*     */ 
/* 128 */     int maxNodesPerRack = (totalNumOfReplicas - 1) / this.clusterMap.getNumOfRacks() + 2;
/*     */ 
/* 131 */     List results = new ArrayList(chosenNodes);
/*     */ 
/* 133 */     for (DatanodeDescriptor node : chosenNodes)
/*     */     {
/* 135 */       addToExcludedNodes(node, excludedNodes);
/* 136 */       adjustExcludedNodes(excludedNodes, node);
/*     */     }
/*     */ 
/* 139 */     if (!this.clusterMap.contains(writer)) {
/* 140 */       writer = null;
/*     */     }
/*     */ 
/* 143 */     boolean avoidStaleNodes = (this.stats != null) && (this.stats.shouldAvoidStaleDataNodesForWrite());
/*     */ 
/* 145 */     DatanodeDescriptor localNode = chooseTarget(numOfReplicas, writer, excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */ 
/* 148 */     results.removeAll(chosenNodes);
/*     */ 
/* 151 */     return getPipeline(writer == null ? localNode : writer, (DatanodeDescriptor[])results.toArray(new DatanodeDescriptor[results.size()]));
/*     */   }
/*     */ 
/*     */   private DatanodeDescriptor chooseTarget(int numOfReplicas, DatanodeDescriptor writer, HashMap<Node, Node> excludedNodes, long blocksize, int maxNodesPerRack, List<DatanodeDescriptor> results, boolean avoidStaleNodes)
/*     */   {
/* 161 */     if ((numOfReplicas == 0) || (this.clusterMap.getNumOfLeaves() == 0)) {
/* 162 */       return writer;
/*     */     }
/* 164 */     int totalReplicasExpected = numOfReplicas + results.size();
/*     */ 
/* 166 */     int numOfResults = results.size();
/* 167 */     boolean newBlock = numOfResults == 0;
/* 168 */     if ((writer == null) && (!newBlock)) {
/* 169 */       writer = (DatanodeDescriptor)results.get(0);
/*     */     }
/*     */ 
/* 173 */     HashMap oldExcludedNodes = avoidStaleNodes ? new HashMap(excludedNodes) : null;
/*     */     try
/*     */     {
/* 177 */       if (numOfResults == 0) {
/* 178 */         writer = chooseLocalNode(writer, excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */ 
/* 180 */         numOfReplicas--; if (numOfReplicas == 0) {
/* 181 */           return writer;
/*     */         }
/*     */       }
/* 184 */       if (numOfResults <= 1) {
/* 185 */         chooseRemoteRack(1, (DatanodeDescriptor)results.get(0), excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */ 
/* 187 */         numOfReplicas--; if (numOfReplicas == 0) {
/* 188 */           return writer;
/*     */         }
/*     */       }
/* 191 */       if (numOfResults <= 2) {
/* 192 */         if (this.clusterMap.isOnSameRack((Node)results.get(0), (Node)results.get(1))) {
/* 193 */           chooseRemoteRack(1, (DatanodeDescriptor)results.get(0), excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */         }
/* 195 */         else if (newBlock) {
/* 196 */           chooseLocalRack((DatanodeDescriptor)results.get(1), excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */         }
/*     */         else {
/* 199 */           chooseLocalRack(writer, excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */         }
/*     */ 
/* 202 */         numOfReplicas--; if (numOfReplicas == 0) {
/* 203 */           return writer;
/*     */         }
/*     */       }
/* 206 */       chooseRandom(numOfReplicas, "", excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */     }
/*     */     catch (BlockPlacementPolicy.NotEnoughReplicasException e) {
/* 209 */       FSNamesystem.LOG.warn("Not able to place enough replicas, still in need of " + (totalReplicasExpected - results.size()) + " to reach " + totalReplicasExpected + "\n" + e.getMessage());
/*     */ 
/* 213 */       if (avoidStaleNodes)
/*     */       {
/* 220 */         for (Node node : results) {
/* 221 */           oldExcludedNodes.put(node, node);
/*     */         }
/*     */ 
/* 225 */         numOfReplicas = totalReplicasExpected - results.size();
/* 226 */         return chooseTarget(numOfReplicas, writer, oldExcludedNodes, blocksize, maxNodesPerRack, results, false);
/*     */       }
/*     */     }
/*     */ 
/* 230 */     return writer;
/*     */   }
/*     */ 
/*     */   protected DatanodeDescriptor chooseLocalNode(DatanodeDescriptor localMachine, HashMap<Node, Node> excludedNodes, long blocksize, int maxNodesPerRack, List<DatanodeDescriptor> results, boolean avoidStaleNodes)
/*     */     throws BlockPlacementPolicy.NotEnoughReplicasException
/*     */   {
/* 243 */     if (localMachine == null) {
/* 244 */       return chooseRandom("", excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */     }
/*     */ 
/* 248 */     Node oldNode = (Node)excludedNodes.put(localMachine, localMachine);
/* 249 */     if ((oldNode == null) && 
/* 250 */       (isGoodTarget(localMachine, blocksize, maxNodesPerRack, false, results, avoidStaleNodes)))
/*     */     {
/* 252 */       results.add(localMachine);
/*     */ 
/* 254 */       addToExcludedNodes(localMachine, excludedNodes);
/* 255 */       return localMachine;
/*     */     }
/*     */ 
/* 260 */     return chooseLocalRack(localMachine, excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */   }
/*     */ 
/*     */   protected int addToExcludedNodes(DatanodeDescriptor localMachine, HashMap<Node, Node> excludedNodes)
/*     */   {
/* 271 */     Node node = (Node)excludedNodes.put(localMachine, localMachine);
/* 272 */     return node == null ? 1 : 0;
/*     */   }
/*     */ 
/*     */   protected DatanodeDescriptor chooseLocalRack(DatanodeDescriptor localMachine, HashMap<Node, Node> excludedNodes, long blocksize, int maxNodesPerRack, List<DatanodeDescriptor> results, boolean avoidStaleNodes)
/*     */     throws BlockPlacementPolicy.NotEnoughReplicasException
/*     */   {
/* 287 */     if (localMachine == null) {
/* 288 */       return chooseRandom("", excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 294 */       return chooseRandom(localMachine.getNetworkLocation(), excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */     }
/*     */     catch (BlockPlacementPolicy.NotEnoughReplicasException e1)
/*     */     {
/* 298 */       DatanodeDescriptor newLocal = null;
/* 299 */       Iterator iter = results.iterator();
/* 300 */       while (iter.hasNext()) {
/* 301 */         DatanodeDescriptor nextNode = (DatanodeDescriptor)iter.next();
/* 302 */         if (nextNode != localMachine) {
/* 303 */           newLocal = nextNode;
/* 304 */           break;
/*     */         }
/*     */       }
/* 307 */       if (newLocal != null) {
/*     */         try {
/* 309 */           return chooseRandom(newLocal.getNetworkLocation(), excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */         }
/*     */         catch (BlockPlacementPolicy.NotEnoughReplicasException e2)
/*     */         {
/* 313 */           return chooseRandom("", excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 318 */     return chooseRandom("", excludedNodes, blocksize, maxNodesPerRack, results, avoidStaleNodes);
/*     */   }
/*     */ 
/*     */   protected void chooseRemoteRack(int numOfReplicas, DatanodeDescriptor localMachine, HashMap<Node, Node> excludedNodes, long blocksize, int maxReplicasPerRack, List<DatanodeDescriptor> results, boolean avoidStaleNodes)
/*     */     throws BlockPlacementPolicy.NotEnoughReplicasException
/*     */   {
/* 337 */     int oldNumOfReplicas = results.size();
/*     */     try
/*     */     {
/* 340 */       chooseRandom(numOfReplicas, "~" + localMachine.getNetworkLocation(), excludedNodes, blocksize, maxReplicasPerRack, results, avoidStaleNodes);
/*     */     }
/*     */     catch (BlockPlacementPolicy.NotEnoughReplicasException e)
/*     */     {
/* 344 */       chooseRandom(numOfReplicas - (results.size() - oldNumOfReplicas), localMachine.getNetworkLocation(), excludedNodes, blocksize, maxReplicasPerRack, results, avoidStaleNodes);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected DatanodeDescriptor chooseRandom(String nodes, HashMap<Node, Node> excludedNodes, long blocksize, int maxNodesPerRack, List<DatanodeDescriptor> results, boolean avoidStaleNodes)
/*     */     throws BlockPlacementPolicy.NotEnoughReplicasException
/*     */   {
/* 360 */     int numOfAvailableNodes = this.clusterMap.countNumOfAvailableNodes(nodes, excludedNodes.keySet());
/*     */ 
/* 362 */     while (numOfAvailableNodes > 0) {
/* 363 */       DatanodeDescriptor chosenNode = (DatanodeDescriptor)this.clusterMap.chooseRandom(nodes);
/*     */ 
/* 366 */       Node oldNode = (Node)excludedNodes.put(chosenNode, chosenNode);
/* 367 */       if (oldNode == null) {
/* 368 */         numOfAvailableNodes--;
/* 369 */         if (isGoodTarget(chosenNode, blocksize, maxNodesPerRack, results, avoidStaleNodes))
/*     */         {
/* 371 */           results.add(chosenNode);
/*     */ 
/* 373 */           addToExcludedNodes(chosenNode, excludedNodes);
/* 374 */           adjustExcludedNodes(excludedNodes, chosenNode);
/* 375 */           return chosenNode;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 380 */     throw new BlockPlacementPolicy.NotEnoughReplicasException("Not able to place enough replicas");
/*     */   }
/*     */ 
/*     */   protected void chooseRandom(int numOfReplicas, String nodes, HashMap<Node, Node> excludedNodes, long blocksize, int maxNodesPerRack, List<DatanodeDescriptor> results, boolean avoidStaleNodes)
/*     */     throws BlockPlacementPolicy.NotEnoughReplicasException
/*     */   {
/* 395 */     int numOfAvailableNodes = this.clusterMap.countNumOfAvailableNodes(nodes, excludedNodes.keySet());
/*     */ 
/* 397 */     while ((numOfReplicas > 0) && (numOfAvailableNodes > 0)) {
/* 398 */       DatanodeDescriptor chosenNode = (DatanodeDescriptor)this.clusterMap.chooseRandom(nodes);
/*     */ 
/* 400 */       Node oldNode = (Node)excludedNodes.put(chosenNode, chosenNode);
/* 401 */       if (oldNode == null) {
/* 402 */         numOfAvailableNodes--;
/*     */ 
/* 404 */         if (isGoodTarget(chosenNode, blocksize, maxNodesPerRack, results, avoidStaleNodes))
/*     */         {
/* 406 */           numOfReplicas--;
/* 407 */           results.add(chosenNode);
/*     */ 
/* 409 */           int newExcludedNodes = addToExcludedNodes(chosenNode, excludedNodes);
/* 410 */           numOfAvailableNodes -= newExcludedNodes;
/* 411 */           adjustExcludedNodes(excludedNodes, chosenNode);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 416 */     if (numOfReplicas > 0)
/* 417 */       throw new BlockPlacementPolicy.NotEnoughReplicasException("Not able to place enough replicas");
/*     */   }
/*     */ 
/*     */   protected void adjustExcludedNodes(HashMap<Node, Node> excludedNodes, Node chosenNode)
/*     */   {
/*     */   }
/*     */ 
/*     */   private boolean isGoodTarget(DatanodeDescriptor node, long blockSize, int maxTargetPerLoc, List<DatanodeDescriptor> results, boolean avoidStaleNodes)
/*     */   {
/* 444 */     return isGoodTarget(node, blockSize, maxTargetPerLoc, this.considerLoad, results, avoidStaleNodes);
/*     */   }
/*     */ 
/*     */   protected boolean isGoodTarget(DatanodeDescriptor node, long blockSize, int maxTargetPerLoc, boolean considerLoad, List<DatanodeDescriptor> results, boolean avoidStaleNodes)
/*     */   {
/* 469 */     Log logr = FSNamesystem.LOG;
/*     */ 
/* 471 */     if ((node.isDecommissionInProgress()) || (node.isDecommissioned())) {
/* 472 */       logr.debug("Node " + NodeBase.getPath(node) + " is not chosen because the node is (being) decommissioned");
/*     */ 
/* 474 */       return false;
/*     */     }
/*     */ 
/* 477 */     if ((avoidStaleNodes) && 
/* 478 */       (node.isStale(this.staleInterval))) {
/* 479 */       logr.debug("Node " + NodeBase.getPath(node) + " is not chosen because the node is (being) stale");
/*     */ 
/* 481 */       return false;
/*     */     }
/*     */ 
/* 485 */     long remaining = node.getRemaining() - node.getBlocksScheduled() * blockSize;
/*     */ 
/* 488 */     if (blockSize * 5L > remaining) {
/* 489 */       logr.debug("Node " + NodeBase.getPath(node) + " is not chosen because the node does not have enough space");
/*     */ 
/* 491 */       return false;
/*     */     }
/*     */ 
/* 495 */     if (considerLoad) {
/* 496 */       double avgLoad = 0.0D;
/* 497 */       int size = this.clusterMap.getNumOfLeaves();
/* 498 */       if ((size != 0) && (this.stats != null)) {
/* 499 */         avgLoad = this.stats.getTotalLoad() / size;
/*     */       }
/* 501 */       if (node.getXceiverCount() > 2.0D * avgLoad) {
/* 502 */         logr.debug("Node " + NodeBase.getPath(node) + " is not chosen because the node is too busy");
/*     */ 
/* 504 */         return false;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 509 */     String rackname = node.getNetworkLocation();
/* 510 */     int counter = 1;
/* 511 */     Iterator iter = results.iterator();
/* 512 */     while (iter.hasNext()) {
/* 513 */       Node result = (Node)iter.next();
/* 514 */       if (rackname.equals(result.getNetworkLocation())) {
/* 515 */         counter++;
/*     */       }
/*     */     }
/* 518 */     if (counter > maxTargetPerLoc) {
/* 519 */       logr.debug("Node " + NodeBase.getPath(node) + " is not chosen because the rack has too many chosen nodes");
/*     */ 
/* 521 */       return false;
/*     */     }
/* 523 */     return true;
/*     */   }
/*     */ 
/*     */   private DatanodeDescriptor[] getPipeline(DatanodeDescriptor writer, DatanodeDescriptor[] nodes)
/*     */   {
/* 534 */     if (nodes.length == 0) return nodes;
/*     */ 
/* 536 */     synchronized (this.clusterMap) {
/* 537 */       int index = 0;
/* 538 */       if ((writer == null) || (!this.clusterMap.contains(writer))) {
/* 539 */         writer = nodes[0];
/*     */       }
/* 541 */       for (; index < nodes.length; index++) {
/* 542 */         DatanodeDescriptor shortestNode = nodes[index];
/* 543 */         int shortestDistance = this.clusterMap.getDistance(writer, shortestNode);
/* 544 */         int shortestIndex = index;
/* 545 */         for (int i = index + 1; i < nodes.length; i++) {
/* 546 */           DatanodeDescriptor currentNode = nodes[i];
/* 547 */           int currentDistance = this.clusterMap.getDistance(writer, currentNode);
/* 548 */           if (shortestDistance > currentDistance) {
/* 549 */             shortestDistance = currentDistance;
/* 550 */             shortestNode = currentNode;
/* 551 */             shortestIndex = i;
/*     */           }
/*     */         }
/*     */ 
/* 555 */         if (index != shortestIndex) {
/* 556 */           nodes[shortestIndex] = nodes[index];
/* 557 */           nodes[index] = shortestNode;
/*     */         }
/* 559 */         writer = shortestNode;
/*     */       }
/*     */     }
/* 562 */     return nodes;
/*     */   }
/*     */ 
/*     */   public int verifyBlockPlacement(String srcPath, LocatedBlock lBlk, int minRacks)
/*     */   {
/* 569 */     DatanodeInfo[] locs = lBlk.getLocations();
/* 570 */     if (locs == null)
/* 571 */       locs = new DatanodeInfo[0];
/* 572 */     int numRacks = this.clusterMap.getNumOfRacks();
/* 573 */     if (numRacks <= 1)
/* 574 */       return 0;
/* 575 */     minRacks = Math.min(minRacks, numRacks);
/*     */ 
/* 578 */     Set racks = new TreeSet();
/* 579 */     for (DatanodeInfo dn : locs)
/* 580 */       racks.add(dn.getNetworkLocation());
/* 581 */     return minRacks - racks.size();
/*     */   }
/*     */ 
/*     */   public DatanodeDescriptor chooseReplicaToDelete(FSInodeInfo inode, Block block, short replicationFactor, Collection<DatanodeDescriptor> first, Collection<DatanodeDescriptor> second)
/*     */   {
/* 590 */     long minSpace = 9223372036854775807L;
/* 591 */     DatanodeDescriptor cur = null;
/*     */ 
/* 595 */     Iterator iter = pickupReplicaSet(first, second);
/*     */ 
/* 598 */     while (iter.hasNext()) {
/* 599 */       DatanodeDescriptor node = (DatanodeDescriptor)iter.next();
/* 600 */       long free = node.getRemaining();
/* 601 */       if (minSpace > free) {
/* 602 */         minSpace = free;
/* 603 */         cur = node;
/*     */       }
/*     */     }
/* 606 */     return cur;
/*     */   }
/*     */ 
/*     */   protected Iterator<DatanodeDescriptor> pickupReplicaSet(Collection<DatanodeDescriptor> first, Collection<DatanodeDescriptor> second)
/*     */   {
/* 618 */     Iterator iter = first.isEmpty() ? second.iterator() : first.iterator();
/*     */ 
/* 620 */     return iter;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.BlockPlacementPolicyDefault
 * JD-Core Version:    0.6.1
 */
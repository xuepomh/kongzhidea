/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Iterator;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.hdfs.util.GSet;
/*     */ import org.apache.hadoop.hdfs.util.LightWeightGSet;
/*     */ import org.apache.hadoop.hdfs.util.LightWeightGSet.LinkedElement;
/*     */ 
/*     */ class BlocksMap
/*     */ {
/*     */   private final int capacity;
/*     */   private GSet<Block, BlockInfo> blocks;
/*     */ 
/*     */   BlocksMap(int initialCapacity, float loadFactor)
/*     */   {
/* 319 */     this.capacity = LightWeightGSet.computeCapacity(2.0D, "BlocksMap");
/* 320 */     this.blocks = new LightWeightGSet(this.capacity);
/*     */   }
/*     */ 
/*     */   void close() {
/* 324 */     this.blocks.clear();
/*     */   }
/*     */ 
/*     */   private BlockInfo checkBlockInfo(Block b, int replication)
/*     */   {
/* 331 */     BlockInfo info = (BlockInfo)this.blocks.get(b);
/* 332 */     if (info == null) {
/* 333 */       info = new BlockInfo(b, replication);
/* 334 */       this.blocks.put(info);
/*     */     }
/* 336 */     return info;
/*     */   }
/*     */ 
/*     */   INodeFile getINode(Block b) {
/* 340 */     BlockInfo info = (BlockInfo)this.blocks.get(b);
/* 341 */     return info != null ? info.inode : null;
/*     */   }
/*     */ 
/*     */   BlockInfo addINode(Block b, INodeFile iNode)
/*     */   {
/* 348 */     BlockInfo info = checkBlockInfo(b, iNode.getReplication());
/* 349 */     info.inode = iNode;
/* 350 */     return info;
/*     */   }
/*     */ 
/*     */   void removeINode(Block b)
/*     */   {
/* 359 */     BlockInfo info = (BlockInfo)this.blocks.get(b);
/* 360 */     if (info != null) {
/* 361 */       info.inode = null;
/* 362 */       if (info.getDatanode(0) == null)
/* 363 */         this.blocks.remove(b);
/*     */     }
/*     */   }
/*     */ 
/*     */   void removeBlock(BlockInfo blockInfo)
/*     */   {
/* 374 */     if (blockInfo == null)
/* 375 */       return;
/* 376 */     blockInfo.inode = null;
/* 377 */     for (int idx = blockInfo.numNodes() - 1; idx >= 0; idx--) {
/* 378 */       DatanodeDescriptor dn = blockInfo.getDatanode(idx);
/* 379 */       dn.removeBlock(blockInfo);
/*     */     }
/* 381 */     this.blocks.remove(blockInfo);
/*     */   }
/*     */ 
/*     */   BlockInfo getStoredBlock(Block b)
/*     */   {
/* 386 */     return (BlockInfo)this.blocks.get(b);
/*     */   }
/*     */ 
/*     */   BlockInfo getStoredBlockWithoutMatchingGS(Block b)
/*     */   {
/* 391 */     return (BlockInfo)this.blocks.get(new Block(b.getBlockId()));
/*     */   }
/*     */ 
/*     */   Iterator<DatanodeDescriptor> nodeIterator(Block b)
/*     */   {
/* 396 */     return new NodeIterator((BlockInfo)this.blocks.get(b));
/*     */   }
/*     */ 
/*     */   int numNodes(Block b)
/*     */   {
/* 401 */     BlockInfo info = (BlockInfo)this.blocks.get(b);
/* 402 */     return info == null ? 0 : info.numNodes();
/*     */   }
/*     */ 
/*     */   boolean addNode(Block b, DatanodeDescriptor node, int replication)
/*     */   {
/* 409 */     BlockInfo info = checkBlockInfo(b, replication);
/*     */ 
/* 411 */     return node.addBlock(info);
/*     */   }
/*     */ 
/*     */   boolean removeNode(Block b, DatanodeDescriptor node)
/*     */   {
/* 420 */     BlockInfo info = (BlockInfo)this.blocks.get(b);
/* 421 */     if (info == null) {
/* 422 */       return false;
/*     */     }
/*     */ 
/* 425 */     boolean removed = node.removeBlock(info);
/*     */ 
/* 427 */     if ((info.getDatanode(0) == null) && (info.inode == null))
/*     */     {
/* 429 */       this.blocks.remove(b);
/*     */     }
/* 431 */     return removed;
/*     */   }
/*     */ 
/*     */   int size() {
/* 435 */     return this.blocks.size();
/*     */   }
/*     */ 
/*     */   Iterable<BlockInfo> getBlocks() {
/* 439 */     return this.blocks;
/*     */   }
/*     */ 
/*     */   boolean contains(Block block)
/*     */   {
/* 445 */     return this.blocks.contains(block);
/*     */   }
/*     */ 
/*     */   boolean contains(Block block, DatanodeDescriptor datanode)
/*     */   {
/* 452 */     BlockInfo info = (BlockInfo)this.blocks.get(block);
/* 453 */     if (info == null) {
/* 454 */       return false;
/*     */     }
/* 456 */     if (-1 == info.findDatanode(datanode)) {
/* 457 */       return false;
/*     */     }
/* 459 */     return true;
/*     */   }
/*     */ 
/*     */   public int getCapacity()
/*     */   {
/* 464 */     return this.capacity;
/*     */   }
/*     */ 
/*     */   private static class NodeIterator
/*     */     implements Iterator<DatanodeDescriptor>
/*     */   {
/*     */     private BlocksMap.BlockInfo blockInfo;
/* 292 */     private int nextIdx = 0;
/*     */ 
/*     */     NodeIterator(BlocksMap.BlockInfo blkInfo) {
/* 295 */       this.blockInfo = blkInfo;
/*     */     }
/*     */ 
/*     */     public boolean hasNext() {
/* 299 */       return (this.blockInfo != null) && (this.nextIdx < BlocksMap.BlockInfo.access$000(this.blockInfo)) && (this.blockInfo.getDatanode(this.nextIdx) != null);
/*     */     }
/*     */ 
/*     */     public DatanodeDescriptor next()
/*     */     {
/* 304 */       return this.blockInfo.getDatanode(this.nextIdx++);
/*     */     }
/*     */ 
/*     */     public void remove() {
/* 308 */       throw new UnsupportedOperationException("Sorry. can't remove.");
/*     */     }
/*     */   }
/*     */ 
/*     */   static class BlockInfo extends Block
/*     */     implements LightWeightGSet.LinkedElement
/*     */   {
/*     */     private INodeFile inode;
/*     */     private LightWeightGSet.LinkedElement nextLinkedElement;
/*     */     private Object[] triplets;
/*     */ 
/*     */     BlockInfo(Block blk, int replication)
/*     */     {
/*  53 */       super();
/*  54 */       this.triplets = new Object[3 * replication];
/*  55 */       this.inode = null;
/*     */     }
/*     */ 
/*     */     INodeFile getINode() {
/*  59 */       return this.inode;
/*     */     }
/*     */ 
/*     */     void setINode(INodeFile inode) {
/*  63 */       this.inode = inode;
/*     */     }
/*     */ 
/*     */     DatanodeDescriptor getDatanode(int index) {
/*  67 */       assert (this.triplets != null) : "BlockInfo is not initialized";
/*  68 */       assert ((index >= 0) && (index * 3 < this.triplets.length)) : "Index is out of bound";
/*  69 */       DatanodeDescriptor node = (DatanodeDescriptor)this.triplets[(index * 3)];
/*     */ 
/*  72 */       assert ((node == null) || (DatanodeDescriptor.class.getName().equals(node.getClass().getName()))) : ("DatanodeDescriptor is expected at " + index * 3);
/*  73 */       return node;
/*     */     }
/*     */ 
/*     */     BlockInfo getPrevious(int index) {
/*  77 */       assert (this.triplets != null) : "BlockInfo is not initialized";
/*  78 */       assert ((index >= 0) && (index * 3 + 1 < this.triplets.length)) : "Index is out of bound";
/*  79 */       BlockInfo info = (BlockInfo)this.triplets[(index * 3 + 1)];
/*     */ 
/*  82 */       assert ((info == null) || (BlockInfo.class.getName().equals(info.getClass().getName()))) : ("BlockInfo is expected at " + index * 3);
/*  83 */       return info;
/*     */     }
/*     */ 
/*     */     BlockInfo getNext(int index) {
/*  87 */       assert (this.triplets != null) : "BlockInfo is not initialized";
/*  88 */       assert ((index >= 0) && (index * 3 + 2 < this.triplets.length)) : "Index is out of bound";
/*  89 */       BlockInfo info = (BlockInfo)this.triplets[(index * 3 + 2)];
/*     */ 
/*  92 */       assert ((info == null) || (BlockInfo.class.getName().equals(info.getClass().getName()))) : ("BlockInfo is expected at " + index * 3);
/*  93 */       return info;
/*     */     }
/*     */ 
/*     */     void setDatanode(int index, DatanodeDescriptor node) {
/*  97 */       assert (this.triplets != null) : "BlockInfo is not initialized";
/*  98 */       assert ((index >= 0) && (index * 3 < this.triplets.length)) : "Index is out of bound";
/*  99 */       this.triplets[(index * 3)] = node;
/*     */     }
/*     */ 
/*     */     void setPrevious(int index, BlockInfo to) {
/* 103 */       assert (this.triplets != null) : "BlockInfo is not initialized";
/* 104 */       assert ((index >= 0) && (index * 3 + 1 < this.triplets.length)) : "Index is out of bound";
/* 105 */       this.triplets[(index * 3 + 1)] = to;
/*     */     }
/*     */ 
/*     */     void setNext(int index, BlockInfo to) {
/* 109 */       assert (this.triplets != null) : "BlockInfo is not initialized";
/* 110 */       assert ((index >= 0) && (index * 3 + 2 < this.triplets.length)) : "Index is out of bound";
/* 111 */       this.triplets[(index * 3 + 2)] = to;
/*     */     }
/*     */ 
/*     */     private int getCapacity() {
/* 115 */       assert (this.triplets != null) : "BlockInfo is not initialized";
/* 116 */       assert (this.triplets.length % 3 == 0) : "Malformed BlockInfo";
/* 117 */       return this.triplets.length / 3;
/*     */     }
/*     */ 
/*     */     private int ensureCapacity(int num)
/*     */     {
/* 125 */       assert (this.triplets != null) : "BlockInfo is not initialized";
/* 126 */       int last = numNodes();
/* 127 */       if (this.triplets.length >= (last + num) * 3) {
/* 128 */         return last;
/*     */       }
/*     */ 
/* 131 */       Object[] old = this.triplets;
/* 132 */       this.triplets = new Object[(last + num) * 3];
/* 133 */       for (int i = 0; i < last * 3; i++) {
/* 134 */         this.triplets[i] = old[i];
/*     */       }
/* 136 */       return last;
/*     */     }
/*     */ 
/*     */     int numNodes()
/*     */     {
/* 143 */       assert (this.triplets != null) : "BlockInfo is not initialized";
/* 144 */       assert (this.triplets.length % 3 == 0) : "Malformed BlockInfo";
/* 145 */       for (int idx = getCapacity() - 1; idx >= 0; idx--) {
/* 146 */         if (getDatanode(idx) != null)
/* 147 */           return idx + 1;
/*     */       }
/* 149 */       return 0;
/*     */     }
/*     */ 
/*     */     boolean addNode(DatanodeDescriptor node)
/*     */     {
/* 156 */       if (findDatanode(node) >= 0) {
/* 157 */         return false;
/*     */       }
/* 159 */       int lastNode = ensureCapacity(1);
/* 160 */       setDatanode(lastNode, node);
/* 161 */       setNext(lastNode, null);
/* 162 */       setPrevious(lastNode, null);
/* 163 */       return true;
/*     */     }
/*     */ 
/*     */     boolean removeNode(DatanodeDescriptor node)
/*     */     {
/* 170 */       int dnIndex = findDatanode(node);
/* 171 */       if (dnIndex < 0) {
/* 172 */         return false;
/*     */       }
/* 174 */       assert ((getPrevious(dnIndex) == null) && (getNext(dnIndex) == null)) : "Block is still in the list and must be removed first.";
/*     */ 
/* 176 */       int lastNode = numNodes() - 1;
/*     */ 
/* 178 */       setDatanode(dnIndex, getDatanode(lastNode));
/* 179 */       setNext(dnIndex, getNext(lastNode));
/* 180 */       setPrevious(dnIndex, getPrevious(lastNode));
/*     */ 
/* 182 */       setDatanode(lastNode, null);
/* 183 */       setNext(lastNode, null);
/* 184 */       setPrevious(lastNode, null);
/* 185 */       return true;
/*     */     }
/*     */ 
/*     */     int findDatanode(DatanodeDescriptor dn)
/*     */     {
/* 194 */       int len = getCapacity();
/* 195 */       for (int idx = 0; idx < len; idx++) {
/* 196 */         DatanodeDescriptor cur = getDatanode(idx);
/* 197 */         if (cur == dn)
/* 198 */           return idx;
/* 199 */         if (cur == null)
/*     */           break;
/*     */       }
/* 202 */       return -1;
/*     */     }
/*     */ 
/*     */     BlockInfo listInsert(BlockInfo head, DatanodeDescriptor dn)
/*     */     {
/* 212 */       int dnIndex = findDatanode(dn);
/* 213 */       assert (dnIndex >= 0) : "Data node is not found: current";
/*     */ 
/* 215 */       assert ((getPrevious(dnIndex) == null) && (getNext(dnIndex) == null)) : "Block is already in the list and cannot be inserted.";
/* 216 */       setPrevious(dnIndex, null);
/* 217 */       setNext(dnIndex, head);
/* 218 */       if (head != null)
/* 219 */         head.setPrevious(head.findDatanode(dn), this);
/* 220 */       return this;
/*     */     }
/*     */ 
/*     */     BlockInfo listRemove(BlockInfo head, DatanodeDescriptor dn)
/*     */     {
/* 232 */       if (head == null)
/* 233 */         return null;
/* 234 */       int dnIndex = findDatanode(dn);
/* 235 */       if (dnIndex < 0) {
/* 236 */         return head;
/*     */       }
/* 238 */       BlockInfo next = getNext(dnIndex);
/* 239 */       BlockInfo prev = getPrevious(dnIndex);
/* 240 */       setNext(dnIndex, null);
/* 241 */       setPrevious(dnIndex, null);
/* 242 */       if (prev != null)
/* 243 */         prev.setNext(prev.findDatanode(dn), next);
/* 244 */       if (next != null)
/* 245 */         next.setPrevious(next.findDatanode(dn), prev);
/* 246 */       if (this == head)
/* 247 */         head = next;
/* 248 */       return head;
/*     */     }
/*     */ 
/*     */     int listCount(DatanodeDescriptor dn) {
/* 252 */       int count = 0;
/* 253 */       for (BlockInfo cur = this; cur != null; 
/* 254 */         cur = cur.getNext(cur.findDatanode(dn)))
/* 255 */         count++;
/* 256 */       return count;
/*     */     }
/*     */ 
/*     */     boolean listIsConsistent(DatanodeDescriptor dn)
/*     */     {
/* 261 */       int count = 0;
/*     */ 
/* 263 */       BlockInfo cur = this;
/* 264 */       while (cur != null) {
/* 265 */         BlockInfo next = cur.getNext(cur.findDatanode(dn));
/* 266 */         if (next != null) {
/* 267 */           BlockInfo nextPrev = next.getPrevious(next.findDatanode(dn));
/* 268 */           if (cur != nextPrev) {
/* 269 */             System.out.println("Inconsistent list: cur->next->prev != cur");
/* 270 */             return false;
/*     */           }
/*     */         }
/* 273 */         cur = next;
/* 274 */         count++;
/*     */       }
/* 276 */       return true;
/*     */     }
/*     */ 
/*     */     public LightWeightGSet.LinkedElement getNext()
/*     */     {
/* 281 */       return this.nextLinkedElement;
/*     */     }
/*     */ 
/*     */     public void setNext(LightWeightGSet.LinkedElement next)
/*     */     {
/* 286 */       this.nextLinkedElement = next;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.BlocksMap
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.security.DigestInputStream;
/*     */ import java.security.MessageDigest;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.hdfs.protocol.FSConstants;
/*     */ import org.apache.hadoop.hdfs.util.DataTransferThrottler;
/*     */ import org.apache.hadoop.io.MD5Hash;
/*     */ import org.apache.hadoop.security.SecurityUtil;
/*     */ 
/*     */ class TransferFsImage
/*     */   implements FSConstants
/*     */ {
/*  41 */   private static final Log LOG = LogFactory.getLog(TransferFsImage.class);
/*     */   private boolean isGetImage;
/*     */   private boolean isGetEdit;
/*     */   private boolean isPutImage;
/*     */   private int remoteport;
/*     */   private String machineName;
/*     */   private CheckpointSignature token;
/*  48 */   private MD5Hash newChecksum = null;
/*     */ 
/*     */   public TransferFsImage(Map<String, String[]> pmap, HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException
/*     */   {
/*  62 */     this.isGetImage = (this.isGetEdit = this.isPutImage = 0);
/*  63 */     this.remoteport = 0;
/*  64 */     this.machineName = null;
/*  65 */     this.token = null;
/*  66 */     this.newChecksum = null;
/*     */ 
/*  68 */     for (Iterator it = pmap.keySet().iterator(); it.hasNext(); ) {
/*  69 */       String key = (String)it.next();
/*  70 */       if (key.equals("getimage"))
/*  71 */         this.isGetImage = true;
/*  72 */       else if (key.equals("getedit"))
/*  73 */         this.isGetEdit = true;
/*  74 */       else if (key.equals("putimage"))
/*  75 */         this.isPutImage = true;
/*  76 */       else if (key.equals("port"))
/*  77 */         this.remoteport = new Integer(((String[])pmap.get("port"))[0]).intValue();
/*  78 */       else if (key.equals("machine"))
/*  79 */         this.machineName = ((String[])pmap.get("machine"))[0];
/*  80 */       else if (key.equals("token"))
/*  81 */         this.token = new CheckpointSignature(((String[])pmap.get("token"))[0]);
/*  82 */       else if (key.equals("newChecksum")) {
/*  83 */         this.newChecksum = new MD5Hash(((String[])pmap.get("newChecksum"))[0]);
/*     */       }
/*     */     }
/*     */ 
/*  87 */     int numGets = (this.isGetImage ? 1 : 0) + (this.isGetEdit ? 1 : 0);
/*  88 */     if ((numGets > 1) || ((numGets == 0) && (!this.isPutImage)))
/*  89 */       throw new IOException("Illegal parameters to TransferFsImage");
/*     */   }
/*     */ 
/*     */   boolean getEdit()
/*     */   {
/*  94 */     return this.isGetEdit;
/*     */   }
/*     */ 
/*     */   boolean getImage() {
/*  98 */     return this.isGetImage;
/*     */   }
/*     */ 
/*     */   boolean putImage() {
/* 102 */     return this.isPutImage;
/*     */   }
/*     */ 
/*     */   CheckpointSignature getToken() {
/* 106 */     return this.token;
/*     */   }
/*     */ 
/*     */   MD5Hash getNewChecksum()
/*     */   {
/* 114 */     return this.newChecksum;
/*     */   }
/*     */ 
/*     */   String getInfoServer() throws IOException {
/* 118 */     if ((this.machineName == null) || (this.remoteport == 0)) {
/* 119 */       throw new IOException("MachineName and port undefined");
/*     */     }
/* 121 */     return this.machineName + ":" + this.remoteport;
/*     */   }
/*     */ 
/*     */   static void getFileServer(OutputStream outstream, File localfile, DataTransferThrottler throttler)
/*     */     throws IOException
/*     */   {
/* 131 */     byte[] buf = new byte[BUFFER_SIZE];
/* 132 */     FileInputStream infile = null;
/*     */     try {
/* 134 */       infile = new FileInputStream(localfile);
/* 135 */       if ((SecondaryNameNode.ErrorSimulator.getErrorSimulation(2)) && (localfile.getAbsolutePath().contains("secondary")))
/*     */       {
/* 138 */         throw new IOException("If this exception is not caught by the name-node fs image will be truncated.");
/*     */       }
/*     */ 
/* 141 */       int num = 1;
/* 142 */       while (num > 0) {
/* 143 */         num = infile.read(buf);
/* 144 */         if (num <= 0) {
/*     */           break;
/*     */         }
/* 147 */         outstream.write(buf, 0, num);
/* 148 */         if (throttler != null)
/* 149 */           throttler.throttle(num);
/*     */       }
/*     */     }
/*     */     finally {
/* 153 */       if (infile != null)
/* 154 */         infile.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   static MD5Hash getFileClient(String fsName, String id, File[] localPath, boolean getChecksum)
/*     */     throws IOException
/*     */   {
/* 167 */     byte[] buf = new byte[BUFFER_SIZE];
/*     */ 
/* 169 */     String str = NameNode.getHttpUriScheme() + "://" + fsName + "/getimage?" + id;
/* 170 */     LOG.info("Opening connection to " + str);
/*     */ 
/* 174 */     URL url = new URL(str);
/*     */ 
/* 176 */     URLConnection connection = SecurityUtil.openSecureHttpConnection(url);
/* 177 */     InputStream stream = connection.getInputStream();
/* 178 */     MessageDigest digester = null;
/* 179 */     if (getChecksum) {
/* 180 */       digester = MD5Hash.getDigester();
/* 181 */       stream = new DigestInputStream(stream, digester);
/*     */     }
/* 183 */     FileOutputStream[] output = null;
/*     */     try
/*     */     {
/* 186 */       if (localPath != null) {
/* 187 */         output = new FileOutputStream[localPath.length];
/* 188 */         for (int i = 0; i < output.length; i++) {
/* 189 */           output[i] = new FileOutputStream(localPath[i]);
/*     */         }
/*     */       }
/* 192 */       int num = 1;
/* 193 */       while (num > 0) {
/* 194 */         num = stream.read(buf);
/* 195 */         if ((num > 0) && (localPath != null))
/* 196 */           for (int i = 0; i < output.length; i++)
/* 197 */             output[i].write(buf, 0, num);
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       int i;
/* 202 */       stream.close();
/* 203 */       if (output != null) {
/* 204 */         for (int i = 0; i < output.length; i++) {
/* 205 */           if (output[i] != null) {
/* 206 */             output[i].close();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 211 */     return digester == null ? null : new MD5Hash(digester.digest());
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.TransferFsImage
 * JD-Core Version:    0.6.1
 */
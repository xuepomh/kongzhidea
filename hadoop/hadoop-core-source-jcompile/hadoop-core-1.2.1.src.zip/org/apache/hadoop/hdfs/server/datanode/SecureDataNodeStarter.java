/*     */ package org.apache.hadoop.hdfs.server.datanode;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.ServerSocket;
/*     */ import java.nio.channels.ServerSocketChannel;
/*     */ import org.apache.commons.daemon.Daemon;
/*     */ import org.apache.commons.daemon.DaemonContext;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.http.HttpServer;
/*     */ import org.mortbay.jetty.nio.SelectChannelConnector;
/*     */ 
/*     */ public class SecureDataNodeStarter
/*     */   implements Daemon
/*     */ {
/*     */   private String[] args;
/*     */   private SecureResources resources;
/*     */ 
/*     */   public void init(DaemonContext context)
/*     */     throws Exception
/*     */   {
/*  60 */     System.err.println("Initializing secure datanode resources");
/*     */ 
/*  62 */     Configuration conf = new Configuration();
/*  63 */     if (!conf.get("hadoop.security.authentication").equals("kerberos")) {
/*  64 */       throw new RuntimeException("Cannot start secure datanode in unsecure cluster");
/*     */     }
/*     */ 
/*  67 */     this.args = context.getArguments();
/*     */ 
/*  70 */     InetSocketAddress socAddr = DataNode.getStreamingAddr(conf);
/*  71 */     int socketWriteTimeout = conf.getInt("dfs.datanode.socket.write.timeout", 480000);
/*     */ 
/*  74 */     ServerSocket ss = socketWriteTimeout > 0 ? ServerSocketChannel.open().socket() : new ServerSocket();
/*     */ 
/*  76 */     ss.bind(socAddr, 0);
/*     */ 
/*  79 */     if (ss.getLocalPort() != socAddr.getPort()) {
/*  80 */       throw new RuntimeException("Unable to bind on specified streaming port in secure context. Needed " + socAddr.getPort() + ", got " + ss.getLocalPort());
/*     */     }
/*     */ 
/*  84 */     SelectChannelConnector listener = (SelectChannelConnector)HttpServer.createDefaultChannelConnector();
/*     */ 
/*  86 */     InetSocketAddress infoSocAddr = DataNode.getInfoAddr(conf);
/*  87 */     listener.setHost(infoSocAddr.getHostName());
/*  88 */     listener.setPort(infoSocAddr.getPort());
/*     */ 
/*  90 */     listener.open();
/*  91 */     if (listener.getPort() != infoSocAddr.getPort()) {
/*  92 */       throw new RuntimeException("Unable to bind on specified info port in secure context. Needed " + socAddr.getPort() + ", got " + ss.getLocalPort());
/*     */     }
/*     */ 
/*  95 */     if ((ss.getLocalPort() >= 1023) || (listener.getPort() >= 1023)) {
/*  96 */       throw new RuntimeException("Cannot start secure datanode on non-privileged  ports. (streaming port = " + ss + " ) (http listener port = " + listener.getConnection() + "). Exiting.");
/*     */     }
/*     */ 
/* 100 */     System.err.println("Successfully obtained privileged resources (streaming port = " + ss + " ) (http listener port = " + listener.getConnection() + ")");
/*     */ 
/* 103 */     this.resources = new SecureResources(ss, listener);
/*     */   }
/*     */ 
/*     */   public void start() throws Exception
/*     */   {
/* 108 */     System.err.println("Starting regular datanode initialization");
/* 109 */     DataNode.secureMain(this.args, this.resources);
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void stop()
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   public static class SecureResources
/*     */   {
/*     */     private final ServerSocket streamingSocket;
/*     */     private final SelectChannelConnector listener;
/*     */ 
/*     */     public SecureResources(ServerSocket streamingSocket, SelectChannelConnector listener)
/*     */     {
/*  46 */       this.streamingSocket = streamingSocket;
/*  47 */       this.listener = listener;
/*     */     }
/*     */     public ServerSocket getStreamingSocket() {
/*  50 */       return this.streamingSocket;
/*     */     }
/*  52 */     public SelectChannelConnector getListener() { return this.listener; }
/*     */ 
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.SecureDataNodeStarter
 * JD-Core Version:    0.6.1
 */
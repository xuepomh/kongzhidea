/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.SortedMap;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class LeaseManager
/*     */ {
/*  58 */   public static final Log LOG = LogFactory.getLog(LeaseManager.class);
/*     */   private final FSNamesystem fsnamesystem;
/*  62 */   private long softLimit = 60000L;
/*  63 */   private long hardLimit = 3600000L;
/*     */ 
/*  69 */   private SortedMap<String, Lease> leases = new TreeMap();
/*     */ 
/*  71 */   private SortedSet<Lease> sortedLeases = new TreeSet();
/*     */ 
/*  77 */   private SortedMap<String, Lease> sortedLeasesByPath = new TreeMap();
/*     */ 
/*  79 */   LeaseManager(FSNamesystem fsnamesystem) { this.fsnamesystem = fsnamesystem; }
/*     */ 
/*     */   Lease getLease(String holder) {
/*  82 */     return (Lease)this.leases.get(holder);
/*     */   }
/*     */   SortedSet<Lease> getSortedLeases() {
/*  85 */     return this.sortedLeases;
/*     */   }
/*     */   public Lease getLeaseByPath(String src) {
/*  88 */     return (Lease)this.sortedLeasesByPath.get(src);
/*     */   }
/*     */   public synchronized int countLease() {
/*  91 */     return this.sortedLeases.size();
/*     */   }
/*     */ 
/*     */   synchronized int countPath() {
/*  95 */     int count = 0;
/*  96 */     for (Lease lease : this.sortedLeases) {
/*  97 */       count += lease.getPaths().size();
/*     */     }
/*  99 */     return count;
/*     */   }
/*     */ 
/*     */   synchronized Lease addLease(String holder, String src)
/*     */   {
/* 106 */     Lease lease = getLease(holder);
/* 107 */     if (lease == null) {
/* 108 */       lease = new Lease(holder, null);
/* 109 */       this.leases.put(holder, lease);
/* 110 */       this.sortedLeases.add(lease);
/*     */     } else {
/* 112 */       renewLease(lease);
/*     */     }
/* 114 */     this.sortedLeasesByPath.put(src, lease);
/* 115 */     lease.paths.add(src);
/* 116 */     return lease;
/*     */   }
/*     */ 
/*     */   synchronized void removeLease(Lease lease, String src)
/*     */   {
/* 123 */     this.sortedLeasesByPath.remove(src);
/* 124 */     if (!lease.removePath(src)) {
/* 125 */       LOG.error(src + " not found in lease.paths (=" + lease.paths + ")");
/*     */     }
/*     */ 
/* 128 */     if (!lease.hasPath()) {
/* 129 */       this.leases.remove(lease.holder);
/* 130 */       if (!this.sortedLeases.remove(lease))
/* 131 */         LOG.error(lease + " not found in sortedLeases");
/*     */     }
/*     */   }
/*     */ 
/*     */   synchronized Lease reassignLease(Lease lease, String src, String newHolder)
/*     */   {
/* 140 */     assert (newHolder != null) : "new lease holder is null";
/* 141 */     if (lease != null) {
/* 142 */       removeLease(lease, src);
/*     */     }
/* 144 */     return addLease(newHolder, src);
/*     */   }
/*     */ 
/*     */   synchronized void removeLease(String holder, String src)
/*     */   {
/* 151 */     Lease lease = getLease(holder);
/* 152 */     if (lease != null)
/* 153 */       removeLease(lease, src);
/*     */   }
/*     */ 
/*     */   synchronized String findPath(INodeFileUnderConstruction pendingFile)
/*     */     throws IOException
/*     */   {
/* 162 */     Lease lease = getLease(pendingFile.clientName);
/* 163 */     if (lease != null) {
/* 164 */       String src = lease.findPath(pendingFile);
/* 165 */       if (src != null) {
/* 166 */         return src;
/*     */       }
/*     */     }
/* 169 */     throw new IOException("pendingFile (=" + pendingFile + ") not found." + "(lease=" + lease + ")");
/*     */   }
/*     */ 
/*     */   synchronized void renewLease(String holder)
/*     */   {
/* 177 */     renewLease(getLease(holder));
/*     */   }
/*     */   synchronized void renewLease(Lease lease) {
/* 180 */     if (lease != null) {
/* 181 */       this.sortedLeases.remove(lease);
/* 182 */       lease.renew();
/* 183 */       this.sortedLeases.add(lease);
/*     */     }
/*     */   }
/*     */ 
/*     */   synchronized void changeLease(String src, String dst, String overwrite, String replaceBy)
/*     */   {
/* 295 */     if (LOG.isDebugEnabled()) {
/* 296 */       LOG.debug(getClass().getSimpleName() + ".changelease: " + " src=" + src + ", dest=" + dst + ", overwrite=" + overwrite + ", replaceBy=" + replaceBy);
/*     */     }
/*     */ 
/* 302 */     int len = overwrite.length();
/* 303 */     for (Map.Entry entry : findLeaseWithPrefixPath(src, this.sortedLeasesByPath)) {
/* 304 */       String oldpath = (String)entry.getKey();
/* 305 */       Lease lease = (Lease)entry.getValue();
/*     */ 
/* 307 */       String newpath = replaceBy + oldpath.substring(len);
/* 308 */       if (LOG.isDebugEnabled()) {
/* 309 */         LOG.debug("changeLease: replacing " + oldpath + " with " + newpath);
/*     */       }
/* 311 */       lease.replacePath(oldpath, newpath);
/* 312 */       this.sortedLeasesByPath.remove(oldpath);
/* 313 */       this.sortedLeasesByPath.put(newpath, lease);
/*     */     }
/*     */   }
/*     */ 
/*     */   synchronized void removeLeaseWithPrefixPath(String prefix) {
/* 318 */     for (Map.Entry entry : findLeaseWithPrefixPath(prefix, this.sortedLeasesByPath)) {
/* 319 */       if (LOG.isDebugEnabled()) {
/* 320 */         LOG.debug(LeaseManager.class.getSimpleName() + ".removeLeaseWithPrefixPath: entry=" + entry);
/*     */       }
/*     */ 
/* 323 */       removeLease((Lease)entry.getValue(), (String)entry.getKey());
/*     */     }
/*     */   }
/*     */ 
/*     */   private static List<Map.Entry<String, Lease>> findLeaseWithPrefixPath(String prefix, SortedMap<String, Lease> path2lease)
/*     */   {
/* 329 */     if (LOG.isDebugEnabled()) {
/* 330 */       LOG.debug(LeaseManager.class.getSimpleName() + ".findLease: prefix=" + prefix);
/*     */     }
/*     */ 
/* 333 */     List entries = new ArrayList();
/* 334 */     int srclen = prefix.length();
/*     */ 
/* 336 */     for (Map.Entry entry : path2lease.tailMap(prefix).entrySet()) {
/* 337 */       String p = (String)entry.getKey();
/* 338 */       if (!p.startsWith(prefix)) {
/* 339 */         return entries;
/*     */       }
/* 341 */       if ((p.length() == srclen) || (p.charAt(srclen) == '/')) {
/* 342 */         entries.add(entry);
/*     */       }
/*     */     }
/* 345 */     return entries;
/*     */   }
/*     */ 
/*     */   public void setLeasePeriod(long softLimit, long hardLimit) {
/* 349 */     this.softLimit = softLimit;
/* 350 */     this.hardLimit = hardLimit;
/*     */   }
/*     */ 
/*     */   synchronized void checkLeases()
/*     */   {
/*     */     Lease oldest;
/* 380 */     while (this.sortedLeases.size() > 0) {
/* 381 */       oldest = (Lease)this.sortedLeases.first();
/* 382 */       if (!oldest.expiredHardLimit()) {
/* 383 */         return;
/*     */       }
/*     */ 
/* 386 */       LOG.info("Lease " + oldest + " has expired hard limit");
/*     */ 
/* 388 */       List removing = new ArrayList();
/*     */ 
/* 393 */       String[] leasePaths = new String[oldest.getPaths().size()];
/* 394 */       oldest.getPaths().toArray(leasePaths);
/* 395 */       for (String p : leasePaths) {
/*     */         try {
/* 397 */           this.fsnamesystem.internalReleaseLeaseOne(oldest, p);
/*     */         } catch (IOException e) {
/* 399 */           LOG.error("Cannot release the path " + p + " in the lease " + oldest, e);
/* 400 */           removing.add(p);
/*     */         }
/*     */       }
/*     */ 
/* 404 */       for (String p : removing)
/* 405 */         removeLease(oldest, p);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized String toString()
/*     */   {
/* 412 */     return getClass().getSimpleName() + "= {" + "\n leases=" + this.leases + "\n sortedLeases=" + this.sortedLeases + "\n sortedLeasesByPath=" + this.sortedLeasesByPath + "\n}";
/*     */   }
/*     */ 
/*     */   class Monitor
/*     */     implements Runnable
/*     */   {
/* 358 */     final String name = getClass().getSimpleName();
/*     */ 
/*     */     Monitor() {
/*     */     }
/* 362 */     public void run() { while (LeaseManager.this.fsnamesystem.isRunning()) {
/* 363 */         synchronized (LeaseManager.this.fsnamesystem) {
/* 364 */           LeaseManager.this.checkLeases();
/*     */         }
/*     */         try
/*     */         {
/* 368 */           Thread.sleep(2000L);
/*     */         } catch (InterruptedException ie) {
/* 370 */           if (LeaseManager.LOG.isDebugEnabled())
/* 371 */             LeaseManager.LOG.debug(this.name + " is interrupted", ie);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   class Lease
/*     */     implements Comparable<Lease>
/*     */   {
/*     */     private final String holder;
/*     */     private long lastUpdate;
/* 197 */     private final Collection<String> paths = new TreeSet();
/*     */ 
/*     */     private Lease(String holder)
/*     */     {
/* 201 */       this.holder = holder;
/* 202 */       renew();
/*     */     }
/*     */ 
/*     */     public String getHolder()
/*     */     {
/* 207 */       return this.holder;
/*     */     }
/*     */ 
/*     */     private void renew()
/*     */     {
/* 212 */       this.lastUpdate = FSNamesystem.now();
/*     */     }
/*     */ 
/*     */     public boolean expiredHardLimit()
/*     */     {
/* 217 */       return FSNamesystem.now() - this.lastUpdate > LeaseManager.this.hardLimit;
/*     */     }
/*     */ 
/*     */     public boolean expiredSoftLimit()
/*     */     {
/* 222 */       return FSNamesystem.now() - this.lastUpdate > LeaseManager.this.softLimit;
/*     */     }
/*     */ 
/*     */     private String findPath(INodeFileUnderConstruction pendingFile)
/*     */     {
/* 229 */       for (String src : this.paths) {
/* 230 */         if (LeaseManager.this.fsnamesystem.dir.getFileINode(src) == pendingFile) {
/* 231 */           return src;
/*     */         }
/*     */       }
/* 234 */       return null;
/*     */     }
/*     */ 
/*     */     boolean hasPath() {
/* 238 */       return !this.paths.isEmpty();
/*     */     }
/*     */     boolean removePath(String src) {
/* 241 */       return this.paths.remove(src);
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 246 */       return "[Lease.  Holder: " + this.holder + ", pendingcreates: " + this.paths.size() + "]";
/*     */     }
/*     */ 
/*     */     public int compareTo(Lease o)
/*     */     {
/* 252 */       Lease l1 = this;
/* 253 */       Lease l2 = o;
/* 254 */       long lu1 = l1.lastUpdate;
/* 255 */       long lu2 = l2.lastUpdate;
/* 256 */       if (lu1 < lu2)
/* 257 */         return -1;
/* 258 */       if (lu1 > lu2) {
/* 259 */         return 1;
/*     */       }
/* 261 */       return l1.holder.compareTo(l2.holder);
/*     */     }
/*     */ 
/*     */     public boolean equals(Object o)
/*     */     {
/* 267 */       if (!(o instanceof Lease)) {
/* 268 */         return false;
/*     */       }
/* 270 */       Lease obj = (Lease)o;
/* 271 */       if ((this.lastUpdate == obj.lastUpdate) && (this.holder.equals(obj.holder)))
/*     */       {
/* 273 */         return true;
/*     */       }
/* 275 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 280 */       return this.holder.hashCode();
/*     */     }
/*     */ 
/*     */     Collection<String> getPaths() {
/* 284 */       return this.paths;
/*     */     }
/*     */ 
/*     */     void replacePath(String oldpath, String newpath) {
/* 288 */       this.paths.remove(oldpath);
/* 289 */       this.paths.add(newpath);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.LeaseManager
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.server.namenode;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.hadoop.hdfs.server.common.HdfsConstants.NodeType;
/*    */ import org.apache.hadoop.hdfs.server.common.UpgradeObject;
/*    */ import org.apache.hadoop.hdfs.server.protocol.UpgradeCommand;
/*    */ 
/*    */ public abstract class UpgradeObjectNamenode extends UpgradeObject
/*    */ {
/*    */   public abstract UpgradeCommand processUpgradeCommand(UpgradeCommand paramUpgradeCommand)
/*    */     throws IOException;
/*    */ 
/*    */   public HdfsConstants.NodeType getType()
/*    */   {
/* 47 */     return HdfsConstants.NodeType.NAME_NODE;
/*    */   }
/*    */ 
/*    */   public UpgradeCommand startUpgrade()
/*    */     throws IOException
/*    */   {
/* 54 */     return new UpgradeCommand(101, getVersion(), (short)0);
/*    */   }
/*    */ 
/*    */   protected FSNamesystem getFSNamesystem()
/*    */   {
/* 59 */     return FSNamesystem.getFSNamesystem();
/*    */   }
/*    */ 
/*    */   public void forceProceed() throws IOException
/*    */   {
/* 64 */     NameNode.LOG.info("forceProceed() is not defined for the upgrade. " + getDescription());
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.UpgradeObjectNamenode
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.server.common;
/*    */ 
/*    */ public class StorageInfo
/*    */ {
/*    */   public int layoutVersion;
/*    */   public int namespaceID;
/*    */   public long cTime;
/*    */ 
/*    */   public StorageInfo()
/*    */   {
/* 32 */     this(0, 0, 0L);
/*    */   }
/*    */ 
/*    */   public StorageInfo(int layoutV, int nsID, long cT) {
/* 36 */     this.layoutVersion = layoutV;
/* 37 */     this.namespaceID = nsID;
/* 38 */     this.cTime = cT;
/*    */   }
/*    */ 
/*    */   public StorageInfo(StorageInfo from) {
/* 42 */     setStorageInfo(from);
/*    */   }
/*    */   public int getLayoutVersion() {
/* 45 */     return this.layoutVersion; } 
/* 46 */   public int getNamespaceID() { return this.namespaceID; } 
/* 47 */   public long getCTime() { return this.cTime; }
/*    */ 
/*    */   public void setStorageInfo(StorageInfo from) {
/* 50 */     this.layoutVersion = from.layoutVersion;
/* 51 */     this.namespaceID = from.namespaceID;
/* 52 */     this.cTime = from.cTime;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.common.StorageInfo
 * JD-Core Version:    0.6.1
 */
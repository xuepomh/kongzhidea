package org.apache.hadoop.hdfs.server.datanode;

public abstract interface DataNodeMXBean
{
  public abstract String getHostName();

  public abstract String getVersion();

  public abstract String getRpcPort();

  public abstract String getHttpPort();

  public abstract String getNamenodeAddress();

  public abstract String getVolumeInfo();

  public abstract int getXceiverCount();
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.DataNodeMXBean
 * JD-Core Version:    0.6.1
 */
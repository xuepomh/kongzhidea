/*    */ package org.apache.hadoop.hdfs.server.common;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import org.apache.hadoop.util.StringUtils;
/*    */ 
/*    */ public class InconsistentFSStateException extends IOException
/*    */ {
/*    */   public InconsistentFSStateException(File dir, String descr)
/*    */   {
/* 32 */     super("Directory " + getFilePath(dir) + " is in an inconsistent state: " + descr);
/*    */   }
/*    */ 
/*    */   public InconsistentFSStateException(File dir, String descr, Throwable ex)
/*    */   {
/* 37 */     this(dir, descr + "\n" + StringUtils.stringifyException(ex));
/*    */   }
/*    */ 
/*    */   private static String getFilePath(File dir) {
/*    */     try {
/* 42 */       return dir.getCanonicalPath(); } catch (IOException e) {
/*    */     }
/* 44 */     return dir.getPath();
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.common.InconsistentFSStateException
 * JD-Core Version:    0.6.1
 */
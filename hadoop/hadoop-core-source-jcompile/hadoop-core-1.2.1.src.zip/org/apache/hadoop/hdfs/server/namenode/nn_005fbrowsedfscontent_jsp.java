/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.jsp.JspFactory;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.SkipPageException;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenIdentifier;
/*     */ import org.apache.hadoop.io.Text;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.token.Token;
/*     */ import org.apache.hadoop.util.ServletUtil;
/*     */ import org.apache.jasper.runtime.HttpJspBase;
/*     */ import org.apache.jasper.runtime.JspSourceDependent;
/*     */ import org.apache.jasper.runtime.ResourceInjector;
/*     */ 
/*     */ public final class nn_005fbrowsedfscontent_jsp extends HttpJspBase
/*     */   implements JspSourceDependent
/*     */ {
/*  95 */   private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();
/*     */   private static Vector _jspx_dependants;
/*     */   private ResourceInjector _jspx_resourceInjector;
/*     */ 
/*     */   static String getDelegationToken(NameNode nn, final UserGroupInformation ugi, HttpServletRequest request, Configuration conf)
/*     */     throws IOException, InterruptedException
/*     */   {
/*  48 */     Token token = (Token)ugi.doAs(new PrivilegedExceptionAction()
/*     */     {
/*     */       public Token<DelegationTokenIdentifier> run()
/*     */         throws IOException
/*     */       {
/*  53 */         return this.val$nn.getDelegationToken(new Text(ugi.getUserName()));
/*     */       }
/*     */     });
/*  56 */     return token.encodeToUrlString();
/*     */   }
/*     */ 
/*     */   public void redirectToRandomDataNode(ServletContext context, HttpServletRequest request, HttpServletResponse resp)
/*     */     throws IOException, InterruptedException
/*     */   {
/*  64 */     Configuration conf = (Configuration)context.getAttribute("current.conf");
/*  65 */     NameNode nn = (NameNode)context.getAttribute("name.node");
/*  66 */     UserGroupInformation ugi = JspHelper.getUGI(context, request, conf);
/*  67 */     String tokenString = null;
/*  68 */     if (UserGroupInformation.isSecurityEnabled()) {
/*  69 */       tokenString = getDelegationToken(nn, ugi, request, conf);
/*     */     }
/*  71 */     FSNamesystem fsn = nn.getNamesystem();
/*  72 */     String datanode = fsn.randomDataNode();
/*     */     String nodeToRedirect;
/*     */     String nodeToRedirect;
/*     */     int redirectPort;
/*  76 */     if (datanode != null) {
/*  77 */       int redirectPort = Integer.parseInt(datanode.substring(datanode.indexOf(':') + 1));
/*     */ 
/*  79 */       nodeToRedirect = datanode.substring(0, datanode.indexOf(':'));
/*     */     }
/*     */     else {
/*  82 */       nodeToRedirect = nn.getHttpAddress().getHostName();
/*  83 */       redirectPort = nn.getHttpAddress().getPort();
/*     */     }
/*  85 */     String fqdn = InetAddress.getByName(nodeToRedirect).getCanonicalHostName();
/*  86 */     String redirectLocation = new StringBuilder().append("http://").append(fqdn).append(":").append(redirectPort).append("/browseDirectory.jsp?namenodeInfoPort=").append(nn.getHttpAddress().getPort()).append("&dir=/").append(tokenString == null ? "" : JspHelper.getDelegationTokenUrlParam(tokenString)).toString();
/*     */ 
/*  92 */     resp.sendRedirect(redirectLocation);
/*     */   }
/*     */ 
/*     */   public Object getDependants()
/*     */   {
/* 102 */     return _jspx_dependants;
/*     */   }
/*     */ 
/*     */   public void _jspService(HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException, ServletException
/*     */   {
/* 108 */     PageContext pageContext = null;
/* 109 */     HttpSession session = null;
/* 110 */     ServletContext application = null;
/* 111 */     ServletConfig config = null;
/* 112 */     JspWriter out = null;
/* 113 */     Object page = this;
/* 114 */     JspWriter _jspx_out = null;
/* 115 */     PageContext _jspx_page_context = null;
/*     */     try
/*     */     {
/* 118 */       response.setContentType("text/html; charset=UTF-8");
/* 119 */       pageContext = _jspxFactory.getPageContext(this, request, response, null, true, 8192, true);
/*     */ 
/* 121 */       _jspx_page_context = pageContext;
/* 122 */       application = pageContext.getServletContext();
/* 123 */       config = pageContext.getServletConfig();
/* 124 */       session = pageContext.getSession();
/* 125 */       out = pageContext.getOut();
/* 126 */       _jspx_out = out;
/* 127 */       this._jspx_resourceInjector = ((ResourceInjector)application.getAttribute("com.sun.appserv.jsp.resource.injector"));
/*     */ 
/* 129 */       out.write(10);
/* 130 */       out.write(10);
/* 131 */       out.write("\n\n<!DOCTYPE html>\n<html>\n\n<title></title>\n\n<body>\n");
/*     */ 
/* 133 */       redirectToRandomDataNode(application, request, response);
/*     */ 
/* 135 */       out.write("\n<hr>\n\n<h2>Local logs</h2>\n<a href=\"/logs/\">Log</a> directory\n\n");
/*     */ 
/* 137 */       out.println(ServletUtil.htmlFooter());
/*     */ 
/* 139 */       out.write(10);
/*     */     } catch (Throwable t) {
/* 141 */       if (!(t instanceof SkipPageException)) {
/* 142 */         out = _jspx_out;
/* 143 */         if ((out != null) && (out.getBufferSize() != 0))
/* 144 */           out.clearBuffer();
/* 145 */         if (_jspx_page_context != null) _jspx_page_context.handlePageException(t); 
/*     */       }
/*     */     }
/* 148 */     finally { _jspxFactory.releasePageContext(_jspx_page_context); }
/*     */ 
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.nn_005fbrowsedfscontent_jsp
 * JD-Core Version:    0.6.1
 */
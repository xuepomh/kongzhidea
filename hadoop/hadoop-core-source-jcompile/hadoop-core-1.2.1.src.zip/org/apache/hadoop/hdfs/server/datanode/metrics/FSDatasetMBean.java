package org.apache.hadoop.hdfs.server.datanode.metrics;

import java.io.IOException;

public abstract interface FSDatasetMBean
{
  public abstract long getDfsUsed()
    throws IOException;

  public abstract long getCapacity()
    throws IOException;

  public abstract long getRemaining()
    throws IOException;

  public abstract String getStorageInfo();
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.metrics.FSDatasetMBean
 * JD-Core Version:    0.6.1
 */
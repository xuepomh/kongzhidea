/*    */ package org.apache.hadoop.hdfs.server.common;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.SortedSet;
/*    */ import org.apache.hadoop.hdfs.server.protocol.UpgradeCommand;
/*    */ 
/*    */ public abstract class UpgradeManager
/*    */ {
/* 33 */   protected SortedSet<Upgradeable> currentUpgrades = null;
/* 34 */   protected boolean upgradeState = false;
/* 35 */   protected int upgradeVersion = 0;
/* 36 */   protected UpgradeCommand broadcastCommand = null;
/*    */ 
/*    */   public synchronized UpgradeCommand getBroadcastCommand() {
/* 39 */     return this.broadcastCommand;
/*    */   }
/*    */ 
/*    */   public boolean getUpgradeState() {
/* 43 */     return this.upgradeState;
/*    */   }
/*    */ 
/*    */   public int getUpgradeVersion() {
/* 47 */     return this.upgradeVersion;
/*    */   }
/*    */ 
/*    */   public void setUpgradeState(boolean uState, int uVersion) {
/* 51 */     this.upgradeState = uState;
/* 52 */     this.upgradeVersion = uVersion;
/*    */   }
/*    */ 
/*    */   public SortedSet<Upgradeable> getDistributedUpgrades() throws IOException {
/* 56 */     return UpgradeObjectCollection.getDistributedUpgrades(getUpgradeVersion(), getType());
/*    */   }
/*    */ 
/*    */   public short getUpgradeStatus()
/*    */   {
/* 61 */     if (this.currentUpgrades == null)
/* 62 */       return 100;
/* 63 */     return ((Upgradeable)this.currentUpgrades.first()).getUpgradeStatus();
/*    */   }
/*    */ 
/*    */   public boolean initializeUpgrade() throws IOException {
/* 67 */     this.currentUpgrades = getDistributedUpgrades();
/* 68 */     if (this.currentUpgrades == null)
/*    */     {
/* 70 */       setUpgradeState(false, -41);
/* 71 */       return false;
/*    */     }
/* 73 */     Upgradeable curUO = (Upgradeable)this.currentUpgrades.first();
/*    */ 
/* 75 */     setUpgradeState(true, curUO.getVersion());
/* 76 */     return true;
/*    */   }
/*    */ 
/*    */   public boolean isUpgradeCompleted() {
/* 80 */     if (this.currentUpgrades == null) {
/* 81 */       return true;
/*    */     }
/* 83 */     return false;
/*    */   }
/*    */ 
/*    */   public abstract HdfsConstants.NodeType getType();
/*    */ 
/*    */   public abstract boolean startUpgrade()
/*    */     throws IOException;
/*    */ 
/*    */   public abstract void completeUpgrade()
/*    */     throws IOException;
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.common.UpgradeManager
 * JD-Core Version:    0.6.1
 */
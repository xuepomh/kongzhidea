/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import javax.net.SocketFactory;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.MD5MD5CRC32FileChecksum;
/*     */ import org.apache.hadoop.hdfs.DFSClient;
/*     */ import org.apache.hadoop.hdfs.protocol.ClientProtocol;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeID;
/*     */ import org.apache.hadoop.hdfs.server.datanode.DataNode;
/*     */ import org.apache.hadoop.net.NetUtils;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.znerd.xmlenc.XMLOutputter;
/*     */ 
/*     */ public class FileChecksumServlets
/*     */ {
/*     */   public static class GetServlet extends DfsServlet
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */       throws ServletException, IOException
/*     */     {
/*  82 */       PrintWriter out = response.getWriter();
/*  83 */       String filename = getFilename(request, response);
/*  84 */       XMLOutputter xml = new XMLOutputter(out, "UTF-8");
/*  85 */       xml.declaration();
/*     */ 
/*  87 */       final Configuration conf = new Configuration(DataNode.getDataNode().getConf());
/*  88 */       int socketTimeout = conf.getInt("dfs.socket.timeout", 60000);
/*  89 */       SocketFactory socketFactory = NetUtils.getSocketFactory(conf, ClientProtocol.class);
/*     */       try
/*     */       {
/*  92 */         ClientProtocol nnproxy = (ClientProtocol)getUGI(request, conf).doAs(new PrivilegedExceptionAction()
/*     */         {
/*     */           public ClientProtocol run() throws IOException
/*     */           {
/*  96 */             return DFSClient.createNamenode(conf);
/*     */           }
/*     */         });
/* 100 */         MD5MD5CRC32FileChecksum checksum = DFSClient.getFileChecksum(filename, nnproxy, socketFactory, socketTimeout);
/*     */ 
/* 102 */         MD5MD5CRC32FileChecksum.write(xml, checksum);
/*     */       } catch (IOException ioe) {
/* 104 */         writeXml(ioe, filename, xml);
/*     */       } catch (InterruptedException e) {
/* 106 */         writeXml(e, filename, xml);
/*     */       }
/* 108 */       xml.endDocument();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class RedirectServlet extends DfsServlet
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */       throws ServletException, IOException
/*     */     {
/*  55 */       ServletContext context = getServletContext();
/*  56 */       Configuration conf = (Configuration)context.getAttribute("current.conf");
/*  57 */       UserGroupInformation ugi = getUGI(request, conf);
/*  58 */       String tokenString = request.getParameter("delegation");
/*  59 */       NameNode namenode = (NameNode)context.getAttribute("name.node");
/*  60 */       DatanodeID datanode = namenode.getNamesystem().getRandomDatanode();
/*     */       try {
/*  62 */         URI uri = createRedirectUri("/getFileChecksum", ugi, datanode, request, tokenString);
/*     */ 
/*  64 */         response.sendRedirect(uri.toURL().toString());
/*     */       } catch (URISyntaxException e) {
/*  66 */         throw new ServletException(e);
/*     */       }
/*     */       catch (IOException e) {
/*  69 */         response.sendError(400, e.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.FileChecksumServlets
 * JD-Core Version:    0.6.1
 */
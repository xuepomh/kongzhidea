/*     */ package org.apache.hadoop.hdfs.server.protocol;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.WritableFactories;
/*     */ import org.apache.hadoop.io.WritableFactory;
/*     */ 
/*     */ public class BalancerBandwidthCommand extends DatanodeCommand
/*     */ {
/*     */   public static final int BBC_VERSION = 1;
/*     */   private static final long BBC_DEFAULTBANDWIDTH = 0L;
/*     */   private long bandwidth;
/*  49 */   private int version = 1;
/*     */ 
/*     */   BalancerBandwidthCommand()
/*     */   {
/*  55 */     this(0L);
/*     */   }
/*     */ 
/*     */   public BalancerBandwidthCommand(long bandwidth)
/*     */   {
/*  64 */     super(8);
/*  65 */     this.bandwidth = bandwidth;
/*     */   }
/*     */ 
/*     */   public int getBalancerBandwidthVersion()
/*     */   {
/*  74 */     return this.version;
/*     */   }
/*     */ 
/*     */   public long getBalancerBandwidthValue()
/*     */   {
/*  83 */     return this.bandwidth;
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/* 103 */     super.write(out);
/* 104 */     out.writeInt(this.version);
/* 105 */     out.writeLong(this.bandwidth);
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in)
/*     */     throws IOException
/*     */   {
/* 114 */     super.readFields(in);
/* 115 */     this.version = in.readInt();
/* 116 */     this.bandwidth = in.readLong();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  90 */     WritableFactories.setFactory(BalancerBandwidthCommand.class, new WritableFactory() {
/*     */       public Writable newInstance() {
/*  92 */         return new BalancerBandwidthCommand();
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.protocol.BalancerBandwidthCommand
 * JD-Core Version:    0.6.1
 */
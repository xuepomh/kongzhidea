/*    */ package org.apache.hadoop.hdfs.server.namenode;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import java.security.PrivilegedExceptionAction;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ import org.apache.hadoop.fs.ContentSummary;
/*    */ import org.apache.hadoop.hdfs.protocol.ClientProtocol;
/*    */ import org.apache.hadoop.security.UserGroupInformation;
/*    */ import org.znerd.xmlenc.XMLOutputter;
/*    */ 
/*    */ public class ContentSummaryServlet extends DfsServlet
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public void doGet(final HttpServletRequest request, final HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 43 */     Configuration conf = (Configuration)getServletContext().getAttribute("current.conf");
/*    */ 
/* 45 */     UserGroupInformation ugi = getUGI(request, conf);
/*    */     try {
/* 47 */       ugi.doAs(new PrivilegedExceptionAction()
/*    */       {
/*    */         public Void run() throws Exception {
/* 50 */           String path = request.getPathInfo();
/*    */ 
/* 52 */           PrintWriter out = response.getWriter();
/* 53 */           XMLOutputter xml = new XMLOutputter(out, "UTF-8");
/* 54 */           xml.declaration();
/*    */           try
/*    */           {
/* 57 */             ClientProtocol nnproxy = ContentSummaryServlet.this.createNameNodeProxy();
/* 58 */             ContentSummary cs = nnproxy.getContentSummary(path);
/*    */ 
/* 61 */             xml.startTag(ContentSummary.class.getName());
/* 62 */             if (cs != null) {
/* 63 */               xml.attribute("length", "" + cs.getLength());
/* 64 */               xml.attribute("fileCount", "" + cs.getFileCount());
/* 65 */               xml.attribute("directoryCount", "" + cs.getDirectoryCount());
/* 66 */               xml.attribute("quota", "" + cs.getQuota());
/* 67 */               xml.attribute("spaceConsumed", "" + cs.getSpaceConsumed());
/* 68 */               xml.attribute("spaceQuota", "" + cs.getSpaceQuota());
/*    */             }
/* 70 */             xml.endTag();
/*    */           } catch (IOException ioe) {
/* 72 */             ContentSummaryServlet.this.writeXml(ioe, path, xml);
/*    */           }
/* 74 */           xml.endDocument();
/* 75 */           return null;
/*    */         } } );
/*    */     }
/*    */     catch (InterruptedException e) {
/* 79 */       throw new IOException(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.ContentSummaryServlet
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs.server.datanode;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.classification.InterfaceAudience.Private;
/*     */ import org.apache.hadoop.classification.InterfaceStability.Evolving;
/*     */ import org.apache.hadoop.io.IOUtils;
/*     */ import org.apache.hadoop.util.DataChecksum;
/*     */ 
/*     */ @InterfaceAudience.Private
/*     */ @InterfaceStability.Evolving
/*     */ public class BlockMetadataHeader
/*     */ {
/*     */   static final short METADATA_VERSION = 1;
/*     */   private short version;
/*  50 */   private DataChecksum checksum = null;
/*     */ 
/*     */   BlockMetadataHeader(short version, DataChecksum checksum) {
/*  53 */     this.checksum = checksum;
/*  54 */     this.version = version;
/*     */   }
/*     */ 
/*     */   public short getVersion()
/*     */   {
/*  59 */     return this.version;
/*     */   }
/*     */ 
/*     */   public DataChecksum getChecksum()
/*     */   {
/*  64 */     return this.checksum;
/*     */   }
/*     */ 
/*     */   public static BlockMetadataHeader readHeader(DataInputStream in)
/*     */     throws IOException
/*     */   {
/*  75 */     return readHeader(in.readShort(), in);
/*     */   }
/*     */ 
/*     */   static BlockMetadataHeader readHeader(File file)
/*     */     throws IOException
/*     */   {
/*  87 */     DataInputStream in = null;
/*     */     try {
/*  89 */       in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)));
/*     */ 
/*  91 */       return readHeader(in);
/*     */     } finally {
/*  93 */       IOUtils.closeStream(in);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static BlockMetadataHeader readHeader(short version, DataInputStream in)
/*     */     throws IOException
/*     */   {
/* 100 */     DataChecksum checksum = DataChecksum.newDataChecksum(in);
/* 101 */     return new BlockMetadataHeader(version, checksum);
/*     */   }
/*     */ 
/*     */   private static void writeHeader(DataOutputStream out, BlockMetadataHeader header)
/*     */     throws IOException
/*     */   {
/* 114 */     out.writeShort(header.getVersion());
/* 115 */     header.getChecksum().writeHeader(out);
/*     */   }
/*     */ 
/*     */   static void writeHeader(DataOutputStream out, DataChecksum checksum)
/*     */     throws IOException
/*     */   {
/* 126 */     writeHeader(out, new BlockMetadataHeader((short)1, checksum));
/*     */   }
/*     */ 
/*     */   static int getHeaderSize()
/*     */   {
/* 133 */     return 2 + DataChecksum.getChecksumHeaderSize();
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.BlockMetadataHeader
 * JD-Core Version:    0.6.1
 */
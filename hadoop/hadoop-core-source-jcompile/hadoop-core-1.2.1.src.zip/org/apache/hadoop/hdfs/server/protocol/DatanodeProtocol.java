package org.apache.hadoop.hdfs.server.protocol;

import java.io.IOException;
import org.apache.hadoop.hdfs.protocol.Block;
import org.apache.hadoop.hdfs.protocol.DatanodeID;
import org.apache.hadoop.hdfs.protocol.LocatedBlock;
import org.apache.hadoop.ipc.VersionedProtocol;
import org.apache.hadoop.security.KerberosInfo;

@KerberosInfo(serverPrincipal="dfs.namenode.kerberos.principal", clientPrincipal="dfs.datanode.kerberos.principal")
public abstract interface DatanodeProtocol extends VersionedProtocol
{
  public static final long versionID = 26L;
  public static final int NOTIFY = 0;
  public static final int DISK_ERROR = 1;
  public static final int INVALID_BLOCK = 2;
  public static final int FATAL_DISK_ERROR = 3;
  public static final int DNA_UNKNOWN = 0;
  public static final int DNA_TRANSFER = 1;
  public static final int DNA_INVALIDATE = 2;
  public static final int DNA_SHUTDOWN = 3;
  public static final int DNA_REGISTER = 4;
  public static final int DNA_FINALIZE = 5;
  public static final int DNA_RECOVERBLOCK = 6;
  public static final int DNA_ACCESSKEYUPDATE = 7;
  public static final int DNA_BALANCERBANDWIDTHUPDATE = 8;

  public abstract DatanodeRegistration register(DatanodeRegistration paramDatanodeRegistration)
    throws IOException;

  public abstract DatanodeCommand[] sendHeartbeat(DatanodeRegistration paramDatanodeRegistration, long paramLong1, long paramLong2, long paramLong3, int paramInt1, int paramInt2)
    throws IOException;

  public abstract DatanodeCommand blockReport(DatanodeRegistration paramDatanodeRegistration, long[] paramArrayOfLong)
    throws IOException;

  public abstract void blocksBeingWrittenReport(DatanodeRegistration paramDatanodeRegistration, long[] paramArrayOfLong)
    throws IOException;

  public abstract void blockReceived(DatanodeRegistration paramDatanodeRegistration, Block[] paramArrayOfBlock, String[] paramArrayOfString)
    throws IOException;

  public abstract void errorReport(DatanodeRegistration paramDatanodeRegistration, int paramInt, String paramString)
    throws IOException;

  public abstract NamespaceInfo versionRequest()
    throws IOException;

  public abstract UpgradeCommand processUpgradeCommand(UpgradeCommand paramUpgradeCommand)
    throws IOException;

  public abstract void reportBadBlocks(LocatedBlock[] paramArrayOfLocatedBlock)
    throws IOException;

  public abstract long nextGenerationStamp(Block paramBlock, boolean paramBoolean)
    throws IOException;

  public abstract void commitBlockSynchronization(Block paramBlock, long paramLong1, long paramLong2, boolean paramBoolean1, boolean paramBoolean2, DatanodeID[] paramArrayOfDatanodeID)
    throws IOException;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.protocol.DatanodeProtocol
 * JD-Core Version:    0.6.1
 */
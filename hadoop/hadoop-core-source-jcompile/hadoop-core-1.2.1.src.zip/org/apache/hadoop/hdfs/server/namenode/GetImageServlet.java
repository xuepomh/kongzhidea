/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.security.Principal;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.hdfs.util.DataTransferThrottler;
/*     */ import org.apache.hadoop.io.MD5Hash;
/*     */ import org.apache.hadoop.security.SecurityUtil;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ public class GetImageServlet extends HttpServlet
/*     */ {
/*     */   private static final long serialVersionUID = -7669068179452648952L;
/*  52 */   private static final Log LOG = LogFactory.getLog(GetImageServlet.class);
/*     */ 
/*  58 */   private Object fsImageTransferLock = new Object();
/*     */ 
/*     */   public void doGet(HttpServletRequest request, final HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  64 */     Map pmap = request.getParameterMap();
/*     */     try {
/*  66 */       ServletContext context = getServletContext();
/*  67 */       final FSImage nnImage = (FSImage)context.getAttribute("name.system.image");
/*  68 */       final TransferFsImage ff = new TransferFsImage(pmap, request, response);
/*  69 */       final Configuration conf = (Configuration)getServletContext().getAttribute("current.conf");
/*     */ 
/*  71 */       if ((UserGroupInformation.isSecurityEnabled()) && (!isValidRequestor(request.getUserPrincipal().getName(), conf)))
/*     */       {
/*  73 */         response.sendError(403, "Only Namenode and Secondary Namenode may access this servlet");
/*     */ 
/*  75 */         LOG.warn("Received non-NN/SNN request for image or edits from " + request.getUserPrincipal().getName() + " at " + request.getRemoteHost());
/*     */       }
/*     */       else
/*     */       {
/*  80 */         UserGroupInformation.getCurrentUser().doAs(new Object()
/*     */         {
/*     */           public Void run() throws Exception
/*     */           {
/*  84 */             if (ff.getImage())
/*     */             {
/*  86 */               TransferFsImage.getFileServer(response.getOutputStream(), nnImage.getFsImageName(), GetImageServlet.this.getThrottler(conf));
/*     */             }
/*  88 */             else if (ff.getEdit())
/*     */             {
/*  90 */               TransferFsImage.getFileServer(response.getOutputStream(), nnImage.getFsEditName(), GetImageServlet.this.getThrottler(conf));
/*     */             }
/*  92 */             else if (ff.putImage()) {
/*  93 */               synchronized (GetImageServlet.this.fsImageTransferLock) {
/*  94 */                 final MD5Hash expectedChecksum = ff.getNewChecksum();
/*     */ 
/*  96 */                 nnImage.validateCheckpointUpload(ff.getToken());
/*  97 */                 reloginIfNecessary().doAs(new PrivilegedExceptionAction()
/*     */                 {
/*     */                   public Void run() throws Exception {
/* 100 */                     MD5Hash actualChecksum = TransferFsImage.getFileClient(GetImageServlet.1.this.val$ff.getInfoServer(), "getimage=1", GetImageServlet.1.this.val$nnImage.getFsImageNameCheckpoint(), true);
/*     */ 
/* 102 */                     GetImageServlet.LOG.info("Downloaded new fsimage with checksum: " + actualChecksum);
/* 103 */                     if (!actualChecksum.equals(expectedChecksum)) {
/* 104 */                       throw new IOException("Actual checksum of transferred fsimage: " + actualChecksum + " does not match expected checksum: " + expectedChecksum);
/*     */                     }
/*     */ 
/* 108 */                     return null;
/*     */                   }
/*     */                 });
/* 111 */                 nnImage.checkpointUploadDone();
/*     */               }
/*     */             }
/* 114 */             return null;
/*     */           }
/*     */ 
/*     */           private UserGroupInformation reloginIfNecessary()
/*     */             throws IOException
/*     */           {
/* 122 */             return UserGroupInformation.loginUserFromKeytabAndReturnUGI(SecurityUtil.getServerPrincipal(conf.get("dfs.namenode.kerberos.principal"), NameNode.getAddress(conf).getHostName()), conf.get("dfs.namenode.keytab.file"));
/*     */           }
/*     */ 
/*     */         });
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 132 */       String errMsg = "GetImage failed. " + StringUtils.stringifyException(t);
/* 133 */       response.sendError(410, errMsg);
/* 134 */       throw new IOException(errMsg);
/*     */     } finally {
/* 136 */       response.getOutputStream().close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private final DataTransferThrottler getThrottler(Configuration conf)
/*     */   {
/* 146 */     long transferBandwidth = conf.getLong("dfs.image.transfer.bandwidthPerSec", 0L);
/*     */ 
/* 149 */     DataTransferThrottler throttler = null;
/* 150 */     if (transferBandwidth > 0L) {
/* 151 */       throttler = new DataTransferThrottler(transferBandwidth);
/*     */     }
/* 153 */     return throttler;
/*     */   }
/*     */ 
/*     */   private boolean isValidRequestor(String remoteUser, Configuration conf) throws IOException
/*     */   {
/* 158 */     if (remoteUser == null) {
/* 159 */       LOG.warn("Received null remoteUser while authorizing access to getImage servlet");
/* 160 */       return false;
/*     */     }
/*     */ 
/* 163 */     String[] validRequestors = { SecurityUtil.getServerPrincipal(conf.get("dfs.namenode.kerberos.principal"), NameNode.getAddress(conf).getHostName()), SecurityUtil.getServerPrincipal(conf.get("dfs.secondary.namenode.kerberos.principal"), SecondaryNameNode.getHttpAddress(conf).getHostName()) };
/*     */ 
/* 170 */     for (String v : validRequestors) {
/* 171 */       if ((v != null) && (v.equals(remoteUser))) {
/* 172 */         LOG.info("GetImageServlet allowing: " + remoteUser);
/* 173 */         return true;
/*     */       }
/*     */     }
/* 176 */     LOG.info("GetImageServlet rejecting: " + remoteUser);
/* 177 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.GetImageServlet
 * JD-Core Version:    0.6.1
 */
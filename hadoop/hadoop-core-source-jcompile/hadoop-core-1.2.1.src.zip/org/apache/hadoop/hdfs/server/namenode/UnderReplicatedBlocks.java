/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.TreeSet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ 
/*     */ class UnderReplicatedBlocks
/*     */   implements Iterable<Block>
/*     */ {
/*     */   static final int LEVEL = 3;
/*     */   public static final int QUEUE_WITH_CORRUPT_BLOCKS = 2;
/*  31 */   private List<TreeSet<Block>> priorityQueues = new ArrayList();
/*     */ 
/*     */   UnderReplicatedBlocks()
/*     */   {
/*  35 */     for (int i = 0; i < 3; i++)
/*  36 */       this.priorityQueues.add(new TreeSet());
/*     */   }
/*     */ 
/*     */   void clear()
/*     */   {
/*  44 */     for (int i = 0; i < 3; i++)
/*  45 */       ((TreeSet)this.priorityQueues.get(i)).clear();
/*     */   }
/*     */ 
/*     */   synchronized int size()
/*     */   {
/*  51 */     int size = 0;
/*  52 */     for (int i = 0; i < 3; i++) {
/*  53 */       size += ((TreeSet)this.priorityQueues.get(i)).size();
/*     */     }
/*  55 */     return size;
/*     */   }
/*     */ 
/*     */   synchronized boolean contains(Block block)
/*     */   {
/*  60 */     for (TreeSet set : this.priorityQueues) {
/*  61 */       if (set.contains(block)) return true;
/*     */     }
/*  63 */     return false;
/*     */   }
/*     */ 
/*     */   private int getPriority(Block block, int curReplicas, int decommissionedReplicas, int expectedReplicas)
/*     */   {
/*  75 */     if ((curReplicas < 0) || (curReplicas >= expectedReplicas))
/*  76 */       return 3;
/*  77 */     if (curReplicas == 0)
/*     */     {
/*  80 */       if (decommissionedReplicas > 0) {
/*  81 */         return 0;
/*     */       }
/*  83 */       return 2;
/*  84 */     }if (curReplicas == 1)
/*  85 */       return 0;
/*  86 */     if (curReplicas * 3 < expectedReplicas) {
/*  87 */       return 1;
/*     */     }
/*  89 */     return 2;
/*     */   }
/*     */ 
/*     */   synchronized boolean add(Block block, int curReplicas, int decomissionedReplicas, int expectedReplicas)
/*     */   {
/* 103 */     if ((curReplicas < 0) || (expectedReplicas <= curReplicas)) {
/* 104 */       return false;
/*     */     }
/* 106 */     int priLevel = getPriority(block, curReplicas, decomissionedReplicas, expectedReplicas);
/*     */ 
/* 108 */     if ((priLevel != 3) && (((TreeSet)this.priorityQueues.get(priLevel)).add(block))) {
/* 109 */       NameNode.stateChangeLog.debug("BLOCK* NameSystem.UnderReplicationBlock.add:" + block + " has only " + curReplicas + " replicas and need " + expectedReplicas + " replicas so is added to neededReplications" + " at priority level " + priLevel);
/*     */ 
/* 116 */       return true;
/*     */     }
/* 118 */     return false;
/*     */   }
/*     */ 
/*     */   synchronized boolean remove(Block block, int oldReplicas, int decommissionedReplicas, int oldExpectedReplicas)
/*     */   {
/* 126 */     int priLevel = getPriority(block, oldReplicas, decommissionedReplicas, oldExpectedReplicas);
/*     */ 
/* 129 */     return remove(block, priLevel);
/*     */   }
/*     */ 
/*     */   boolean remove(Block block, int priLevel)
/*     */   {
/* 134 */     if ((priLevel >= 0) && (priLevel < 3) && (((TreeSet)this.priorityQueues.get(priLevel)).remove(block)))
/*     */     {
/* 136 */       NameNode.stateChangeLog.debug("BLOCK* NameSystem.UnderReplicationBlock.remove: Removing block " + block + " from priority queue " + priLevel);
/*     */ 
/* 140 */       return true;
/*     */     }
/* 142 */     for (int i = 0; i < 3; i++) {
/* 143 */       if ((i != priLevel) && (((TreeSet)this.priorityQueues.get(i)).remove(block))) {
/* 144 */         NameNode.stateChangeLog.debug("BLOCK* NameSystem.UnderReplicationBlock.remove: Removing block " + block + " from priority queue " + i);
/*     */ 
/* 148 */         return true;
/*     */       }
/*     */     }
/*     */ 
/* 152 */     return false;
/*     */   }
/*     */ 
/*     */   synchronized void update(Block block, int curReplicas, int decommissionedReplicas, int curExpectedReplicas, int curReplicasDelta, int expectedReplicasDelta)
/*     */   {
/* 160 */     int oldReplicas = curReplicas - curReplicasDelta;
/* 161 */     int oldExpectedReplicas = curExpectedReplicas - expectedReplicasDelta;
/* 162 */     int curPri = getPriority(block, curReplicas, decommissionedReplicas, curExpectedReplicas);
/* 163 */     int oldPri = getPriority(block, oldReplicas, decommissionedReplicas, oldExpectedReplicas);
/* 164 */     NameNode.stateChangeLog.debug("UnderReplicationBlocks.update " + block + " curReplicas " + curReplicas + " curExpectedReplicas " + curExpectedReplicas + " oldReplicas " + oldReplicas + " oldExpectedReplicas  " + oldExpectedReplicas + " curPri  " + curPri + " oldPri  " + oldPri);
/*     */ 
/* 172 */     if ((oldPri != 3) && (oldPri != curPri)) {
/* 173 */       remove(block, oldPri);
/*     */     }
/* 175 */     if ((curPri != 3) && (((TreeSet)this.priorityQueues.get(curPri)).add(block)))
/* 176 */       NameNode.stateChangeLog.debug("BLOCK* NameSystem.UnderReplicationBlock.update:" + block + " has only " + curReplicas + " replicas and need " + curExpectedReplicas + " replicas so is added to neededReplications" + " at priority level " + curPri);
/*     */   }
/*     */ 
/*     */   public synchronized BlockIterator iterator()
/*     */   {
/* 188 */     return new BlockIterator();
/*     */   }
/*     */ 
/*     */   private synchronized Iterable<Block> getQueue(int priority)
/*     */   {
/* 193 */     if ((priority < 0) || (priority >= 3)) {
/* 194 */       return null;
/*     */     }
/* 196 */     return (Iterable)this.priorityQueues.get(priority);
/*     */   }
/*     */ 
/*     */   Iterable<Block> getCorruptQueue()
/*     */   {
/* 204 */     return getQueue(2);
/*     */   }
/*     */ 
/*     */   class BlockIterator
/*     */     implements Iterator<Block>
/*     */   {
/*     */     private int level;
/* 209 */     private List<Iterator<Block>> iterators = new ArrayList();
/*     */ 
/*     */     BlockIterator() {
/* 212 */       this.level = 0;
/* 213 */       for (int i = 0; i < 3; i++)
/* 214 */         this.iterators.add(((TreeSet)UnderReplicatedBlocks.this.priorityQueues.get(i)).iterator());
/*     */     }
/*     */ 
/*     */     private void update()
/*     */     {
/* 219 */       while ((this.level < 2) && (!((Iterator)this.iterators.get(this.level)).hasNext()))
/* 220 */         this.level += 1;
/*     */     }
/*     */ 
/*     */     public Block next()
/*     */     {
/* 225 */       update();
/* 226 */       return (Block)((Iterator)this.iterators.get(this.level)).next();
/*     */     }
/*     */ 
/*     */     public boolean hasNext() {
/* 230 */       update();
/* 231 */       return ((Iterator)this.iterators.get(this.level)).hasNext();
/*     */     }
/*     */ 
/*     */     public void remove() {
/* 235 */       ((Iterator)this.iterators.get(this.level)).remove();
/*     */     }
/*     */ 
/*     */     public int getPriority() {
/* 239 */       return this.level;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.UnderReplicatedBlocks
 * JD-Core Version:    0.6.1
 */
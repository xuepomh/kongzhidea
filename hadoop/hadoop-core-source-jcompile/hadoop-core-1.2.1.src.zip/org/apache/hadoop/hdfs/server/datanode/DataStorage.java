/*     */ package org.apache.hadoop.hdfs.server.datanode;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.channels.FileLock;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.fs.HardLink;
/*     */ import org.apache.hadoop.fs.HardLink.LinkStats;
/*     */ import org.apache.hadoop.hdfs.server.common.HdfsConstants.NodeType;
/*     */ import org.apache.hadoop.hdfs.server.common.HdfsConstants.StartupOption;
/*     */ import org.apache.hadoop.hdfs.server.common.InconsistentFSStateException;
/*     */ import org.apache.hadoop.hdfs.server.common.Storage;
/*     */ import org.apache.hadoop.hdfs.server.common.Storage.StorageDirectory;
/*     */ import org.apache.hadoop.hdfs.server.common.Storage.StorageState;
/*     */ import org.apache.hadoop.hdfs.server.common.StorageInfo;
/*     */ import org.apache.hadoop.hdfs.server.protocol.NamespaceInfo;
/*     */ import org.apache.hadoop.io.IOUtils;
/*     */ import org.apache.hadoop.util.Daemon;
/*     */ 
/*     */ public class DataStorage extends Storage
/*     */ {
/*     */   static final String BLOCK_SUBDIR_PREFIX = "subdir";
/*     */   static final String BLOCK_FILE_PREFIX = "blk_";
/*     */   static final String COPY_FILE_PREFIX = "dncp_";
/*     */   private String storageID;
/* 465 */   private static final Pattern PRE_GENSTAMP_META_FILE_PATTERN = Pattern.compile("(.*blk_[-]*\\d+)\\.meta$");
/*     */ 
/*     */   DataStorage()
/*     */   {
/*  60 */     super(HdfsConstants.NodeType.DATA_NODE);
/*  61 */     this.storageID = "";
/*     */   }
/*     */ 
/*     */   DataStorage(int nsID, long cT, String strgID) {
/*  65 */     super(HdfsConstants.NodeType.DATA_NODE, nsID, cT);
/*  66 */     this.storageID = strgID;
/*     */   }
/*     */ 
/*     */   public DataStorage(StorageInfo storageInfo, String strgID) {
/*  70 */     super(HdfsConstants.NodeType.DATA_NODE, storageInfo);
/*  71 */     this.storageID = strgID;
/*     */   }
/*     */ 
/*     */   public String getStorageID() {
/*  75 */     return this.storageID;
/*     */   }
/*     */ 
/*     */   void setStorageID(String newStorageID) {
/*  79 */     this.storageID = newStorageID;
/*     */   }
/*     */ 
/*     */   void recoverTransitionRead(NamespaceInfo nsInfo, Collection<File> dataDirs, HdfsConstants.StartupOption startOpt)
/*     */     throws IOException
/*     */   {
/*  98 */     assert (-41 == nsInfo.getLayoutVersion()) : "Data-node and name-node layout versions must be the same.";
/*     */ 
/* 103 */     this.storageID = "";
/* 104 */     this.storageDirs = new ArrayList(dataDirs.size());
/* 105 */     ArrayList dataDirStates = new ArrayList(dataDirs.size());
/* 106 */     for (Iterator it = dataDirs.iterator(); it.hasNext(); ) { File dataDir = (File)it.next();
/* 108 */       Storage.StorageDirectory sd = new Storage.StorageDirectory(this, dataDir);
/*     */       Storage.StorageState curState;
/*     */       try { curState = sd.analyzeStorage(startOpt);
/*     */ 
/* 113 */         switch (5.$SwitchMap$org$apache$hadoop$hdfs$server$common$Storage$StorageState[curState.ordinal()]) {
/*     */         case 1:
/* 115 */           break;
/*     */         case 2:
/* 118 */           LOG.info("Storage directory " + dataDir + " does not exist");
/* 119 */           it.remove();
/* 120 */           break;
/*     */         case 3:
/* 122 */           LOG.info("Storage directory " + dataDir + " is not formatted");
/* 123 */           LOG.info("Formatting ...");
/* 124 */           format(sd, nsInfo);
/* 125 */           break;
/*     */         default:
/* 127 */           sd.doRecover(curState);
/*     */         }
/*     */       } catch (IOException ioe) {
/* 130 */         sd.unlock();
/* 131 */         throw ioe;
/*     */       }
/*     */ 
/* 134 */       addStorageDir(sd);
/* 135 */       dataDirStates.add(curState);
/*     */     }
/*     */ 
/* 138 */     if (dataDirs.size() == 0) {
/* 139 */       throw new IOException("All specified directories are not accessible or do not exist.");
/*     */     }
/*     */ 
/* 146 */     for (int idx = 0; idx < getNumStorageDirs(); idx++) {
/* 147 */       doTransition(getStorageDir(idx), nsInfo, startOpt);
/*     */ 
/* 149 */       assert (getLayoutVersion() == nsInfo.getLayoutVersion()) : "Data-node and name-node layout versions must be the same.";
/*     */ 
/* 151 */       assert (getCTime() == nsInfo.getCTime()) : "Data-node and name-node CTimes must be the same.";
/*     */     }
/*     */ 
/* 155 */     writeAll();
/*     */   }
/*     */ 
/*     */   void format(Storage.StorageDirectory sd, NamespaceInfo nsInfo) throws IOException {
/* 159 */     sd.clearDirectory();
/* 160 */     this.layoutVersion = -41;
/* 161 */     this.namespaceID = nsInfo.getNamespaceID();
/* 162 */     this.cTime = 0L;
/*     */ 
/* 164 */     sd.write();
/*     */   }
/*     */ 
/*     */   protected void setFields(Properties props, Storage.StorageDirectory sd)
/*     */     throws IOException
/*     */   {
/* 170 */     super.setFields(props, sd);
/* 171 */     props.setProperty("storageID", this.storageID);
/*     */   }
/*     */ 
/*     */   protected void getFields(Properties props, Storage.StorageDirectory sd)
/*     */     throws IOException
/*     */   {
/* 177 */     super.getFields(props, sd);
/* 178 */     String ssid = props.getProperty("storageID");
/* 179 */     if ((ssid == null) || ((!"".equals(this.storageID)) && (!"".equals(ssid)) && (!this.storageID.equals(ssid))))
/*     */     {
/* 182 */       throw new InconsistentFSStateException(sd.getRoot(), "has incompatible storage Id.");
/*     */     }
/* 184 */     if ("".equals(this.storageID))
/* 185 */       this.storageID = ssid;
/*     */   }
/*     */ 
/*     */   public boolean isConversionNeeded(Storage.StorageDirectory sd) throws IOException {
/* 189 */     File oldF = new File(sd.getRoot(), "storage");
/* 190 */     if (!oldF.exists()) {
/* 191 */       return false;
/*     */     }
/*     */ 
/* 194 */     RandomAccessFile oldFile = new RandomAccessFile(oldF, "rws");
/* 195 */     FileLock oldLock = oldFile.getChannel().tryLock();
/*     */     try {
/* 197 */       oldFile.seek(0L);
/* 198 */       int oldVersion = oldFile.readInt();
/* 199 */       if (oldVersion < -3)
/* 200 */         return false;
/*     */     } finally {
/* 202 */       oldLock.release();
/* 203 */       oldFile.close();
/*     */     }
/* 205 */     return true;
/*     */   }
/*     */ 
/*     */   private void doTransition(Storage.StorageDirectory sd, NamespaceInfo nsInfo, HdfsConstants.StartupOption startOpt)
/*     */     throws IOException
/*     */   {
/* 225 */     if (startOpt == HdfsConstants.StartupOption.ROLLBACK)
/* 226 */       doRollback(sd, nsInfo);
/* 227 */     sd.read();
/* 228 */     checkVersionUpgradable(this.layoutVersion);
/*     */ 
/* 230 */     assert (this.layoutVersion >= -41) : "Future version is not allowed";
/* 231 */     if (getNamespaceID() != nsInfo.getNamespaceID()) {
/* 232 */       throw new IOException("Incompatible namespaceIDs in " + sd.getRoot().getCanonicalPath() + ": namenode namespaceID = " + nsInfo.getNamespaceID() + "; datanode namespaceID = " + getNamespaceID());
/*     */     }
/*     */ 
/* 236 */     if ((this.layoutVersion == -41) && (this.cTime == nsInfo.getCTime()))
/*     */     {
/* 238 */       return;
/*     */     }
/* 240 */     verifyDistributedUpgradeProgress(nsInfo);
/* 241 */     if ((this.layoutVersion > -41) || (this.cTime < nsInfo.getCTime()))
/*     */     {
/* 243 */       doUpgrade(sd, nsInfo);
/* 244 */       return;
/*     */     }
/*     */ 
/* 248 */     throw new IOException("Datanode state: LV = " + getLayoutVersion() + " CTime = " + getCTime() + " is newer than the namespace state: LV = " + nsInfo.getLayoutVersion() + " CTime = " + nsInfo.getCTime());
/*     */   }
/*     */ 
/*     */   void doUpgrade(Storage.StorageDirectory sd, NamespaceInfo nsInfo)
/*     */     throws IOException
/*     */   {
/* 265 */     LOG.info("Upgrading storage directory " + sd.getRoot() + ".\n   old LV = " + getLayoutVersion() + "; old CTime = " + getCTime() + ".\n   new LV = " + nsInfo.getLayoutVersion() + "; new CTime = " + nsInfo.getCTime());
/*     */ 
/* 271 */     HardLink hardLink = new HardLink();
/*     */ 
/* 273 */     File curDir = sd.getCurrentDir();
/* 274 */     File prevDir = sd.getPreviousDir();
/* 275 */     assert (curDir.exists()) : "Current directory must exist.";
/*     */ 
/* 277 */     if (prevDir.exists())
/* 278 */       deleteDir(prevDir);
/* 279 */     File tmpDir = sd.getPreviousTmp();
/* 280 */     assert (!tmpDir.exists()) : "previous.tmp directory must not exist.";
/*     */ 
/* 282 */     rename(curDir, tmpDir);
/*     */ 
/* 284 */     linkBlocks(tmpDir, curDir, getLayoutVersion(), hardLink);
/*     */ 
/* 286 */     this.layoutVersion = -41;
/*     */ 
/* 288 */     assert (this.namespaceID == nsInfo.getNamespaceID()) : "Data-node and name-node layout versions must be the same.";
/* 289 */     this.cTime = nsInfo.getCTime();
/* 290 */     sd.write();
/*     */ 
/* 292 */     rename(tmpDir, prevDir);
/* 293 */     LOG.info(hardLink.linkStats.report());
/* 294 */     LOG.info("Upgrade of " + sd.getRoot() + " is complete");
/*     */   }
/*     */ 
/*     */   void doRollback(Storage.StorageDirectory sd, NamespaceInfo nsInfo)
/*     */     throws IOException
/*     */   {
/* 300 */     File prevDir = sd.getPreviousDir();
/*     */ 
/* 302 */     if (!prevDir.exists())
/* 303 */       return;
/* 304 */     DataStorage prevInfo = new DataStorage();
/*     */     DataStorage tmp28_26 = prevInfo; tmp28_26.getClass(); Storage.StorageDirectory prevSD = new Storage.StorageDirectory(tmp28_26, sd.getRoot());
/* 306 */     prevSD.read(prevSD.getPreviousVersionFile());
/*     */ 
/* 310 */     if ((prevInfo.getLayoutVersion() < -41) || (prevInfo.getCTime() > nsInfo.getCTime()))
/*     */     {
/* 312 */       throw new InconsistentFSStateException(prevSD.getRoot(), "Cannot rollback to a newer state.\nDatanode previous state: LV = " + prevInfo.getLayoutVersion() + " CTime = " + prevInfo.getCTime() + " is newer than the namespace state: LV = " + nsInfo.getLayoutVersion() + " CTime = " + nsInfo.getCTime());
/*     */     }
/*     */ 
/* 317 */     LOG.info("Rolling back storage directory " + sd.getRoot() + ".\n   target LV = " + nsInfo.getLayoutVersion() + "; target CTime = " + nsInfo.getCTime());
/*     */ 
/* 320 */     File tmpDir = sd.getRemovedTmp();
/* 321 */     assert (!tmpDir.exists()) : "removed.tmp directory must not exist.";
/*     */ 
/* 323 */     File curDir = sd.getCurrentDir();
/* 324 */     assert (curDir.exists()) : "Current directory must exist.";
/* 325 */     rename(curDir, tmpDir);
/*     */ 
/* 327 */     rename(prevDir, curDir);
/*     */ 
/* 329 */     deleteDir(tmpDir);
/* 330 */     LOG.info("Rollback of " + sd.getRoot() + " is complete");
/*     */   }
/*     */ 
/*     */   void doFinalize(Storage.StorageDirectory sd) throws IOException {
/* 334 */     File prevDir = sd.getPreviousDir();
/* 335 */     if (!prevDir.exists())
/* 336 */       return;
/* 337 */     final String dataDirPath = sd.getRoot().getCanonicalPath();
/* 338 */     LOG.info("Finalizing upgrade for storage directory " + dataDirPath + ".\n   cur LV = " + getLayoutVersion() + "; cur CTime = " + getCTime());
/*     */ 
/* 342 */     assert (sd.getCurrentDir().exists()) : "Current directory must exist.";
/* 343 */     final File tmpDir = sd.getFinalizedTmp();
/*     */ 
/* 345 */     rename(prevDir, tmpDir);
/*     */ 
/* 348 */     new Daemon(new Runnable() {
/*     */       public void run() {
/*     */         try {
/* 351 */           DataStorage.deleteDir(tmpDir);
/*     */         } catch (IOException ex) {
/* 353 */           Storage.LOG.error("Finalize upgrade for " + dataDirPath + " failed", ex);
/*     */         }
/* 355 */         Storage.LOG.info("Finalize upgrade for " + dataDirPath + " is complete");
/*     */       }
/* 357 */       public String toString() { return "Finalize " + dataDirPath; }
/*     */ 
/*     */     }).start();
/*     */   }
/*     */ 
/*     */   void finalizeUpgrade()
/*     */     throws IOException
/*     */   {
/* 362 */     for (Iterator it = this.storageDirs.iterator(); it.hasNext(); )
/* 363 */       doFinalize((Storage.StorageDirectory)it.next());
/*     */   }
/*     */ 
/*     */   static void linkBlocks(File from, File to, int oldLV, HardLink hl)
/*     */     throws IOException
/*     */   {
/* 369 */     if (!from.isDirectory()) {
/* 370 */       if (from.getName().startsWith("dncp_")) {
/* 371 */         IOUtils.copyBytes(new FileInputStream(from), new FileOutputStream(to), 16384, true);
/*     */ 
/* 373 */         hl.linkStats.countPhysicalFileCopies += 1;
/*     */       }
/*     */       else
/*     */       {
/* 377 */         if (oldLV >= -13)
/*     */         {
/* 379 */           to = new File(convertMetatadataFileName(to.getAbsolutePath()));
/*     */         }
/*     */ 
/* 382 */         HardLink.createHardLink(from, to);
/* 383 */         hl.linkStats.countSingleLinks += 1;
/*     */       }
/* 385 */       return;
/*     */     }
/*     */ 
/* 388 */     hl.linkStats.countDirs += 1;
/*     */ 
/* 390 */     if (!to.mkdir()) {
/* 391 */       throw new IOException("Cannot create directory " + to);
/*     */     }
/*     */ 
/* 395 */     if (oldLV >= -13) {
/* 396 */       String[] blockNames = from.list(new FilenameFilter() {
/*     */         public boolean accept(File dir, String name) {
/* 398 */           return (name.startsWith("subdir")) || (name.startsWith("blk_")) || (name.startsWith("dncp_"));
/*     */         }
/*     */       });
/* 403 */       if (blockNames.length == 0)
/* 404 */         hl.linkStats.countEmptyDirs += 1;
/*     */       else {
/* 406 */         for (int i = 0; i < blockNames.length; i++) {
/* 407 */           linkBlocks(new File(from, blockNames[i]), new File(to, blockNames[i]), oldLV, hl);
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 413 */       String[] blockNames = from.list(new FilenameFilter() {
/*     */         public boolean accept(File dir, String name) {
/* 415 */           return name.startsWith("blk_");
/*     */         }
/*     */       });
/* 419 */       if (blockNames.length > 0) {
/* 420 */         HardLink.createHardLinkMult(from, blockNames, to);
/* 421 */         hl.linkStats.countMultLinks += 1;
/* 422 */         hl.linkStats.countFilesMultLinks += blockNames.length;
/*     */       } else {
/* 424 */         hl.linkStats.countEmptyDirs += 1;
/*     */       }
/*     */ 
/* 428 */       String[] otherNames = from.list(new FilenameFilter() {
/*     */         public boolean accept(File dir, String name) {
/* 430 */           return (name.startsWith("subdir")) || (name.startsWith("dncp_"));
/*     */         }
/*     */       });
/* 434 */       for (int i = 0; i < otherNames.length; i++)
/* 435 */         linkBlocks(new File(from, otherNames[i]), new File(to, otherNames[i]), oldLV, hl);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void corruptPreUpgradeStorage(File rootDir) throws IOException
/*     */   {
/* 441 */     File oldF = new File(rootDir, "storage");
/* 442 */     if (oldF.exists()) {
/* 443 */       return;
/*     */     }
/* 445 */     if (!oldF.createNewFile())
/* 446 */       throw new IOException("Cannot create file " + oldF);
/* 447 */     RandomAccessFile oldFile = new RandomAccessFile(oldF, "rws");
/*     */     try
/*     */     {
/* 450 */       writeCorruptedData(oldFile);
/*     */     } finally {
/* 452 */       oldFile.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void verifyDistributedUpgradeProgress(NamespaceInfo nsInfo)
/*     */     throws IOException
/*     */   {
/* 459 */     UpgradeManagerDatanode um = DataNode.getDataNode().upgradeManager;
/* 460 */     assert (um != null) : "DataNode.upgradeManager is null.";
/* 461 */     um.setUpgradeState(false, getLayoutVersion());
/* 462 */     um.initializeUpgrade(nsInfo);
/*     */   }
/*     */ 
/*     */   private static String convertMetatadataFileName(String oldFileName)
/*     */   {
/* 474 */     Matcher matcher = PRE_GENSTAMP_META_FILE_PATTERN.matcher(oldFileName);
/* 475 */     if (matcher.matches())
/*     */     {
/* 477 */       return FSDataset.getMetaFileName(matcher.group(1), 0L);
/*     */     }
/*     */ 
/* 480 */     return oldFileName;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.DataStorage
 * JD-Core Version:    0.6.1
 */
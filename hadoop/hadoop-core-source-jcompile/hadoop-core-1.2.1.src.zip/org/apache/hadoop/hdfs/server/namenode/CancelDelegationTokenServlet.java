/*    */ package org.apache.hadoop.hdfs.server.namenode;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.security.PrivilegedExceptionAction;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ import org.apache.hadoop.security.UserGroupInformation;
/*    */ import org.apache.hadoop.security.token.Token;
/*    */ 
/*    */ public class CancelDelegationTokenServlet extends DfsServlet
/*    */ {
/* 40 */   private static final Log LOG = LogFactory.getLog(CancelDelegationTokenServlet.class);
/*    */   public static final String PATH_SPEC = "/cancelDelegationToken";
/*    */   public static final String TOKEN = "token";
/*    */ 
/*    */   protected void doGet(HttpServletRequest req, HttpServletResponse resp)
/*    */     throws ServletException, IOException
/*    */   {
/* 48 */     ServletContext context = getServletContext();
/* 49 */     Configuration conf = (Configuration)context.getAttribute("current.conf");
/*    */     UserGroupInformation ugi;
/*    */     try
/*    */     {
/* 52 */       ugi = getUGI(req, conf);
/*    */     } catch (IOException ioe) {
/* 54 */       LOG.info("Request for token received with no authentication from " + req.getRemoteAddr(), ioe);
/*    */ 
/* 56 */       resp.sendError(403, "Unable to identify or authenticate user");
/*    */ 
/* 58 */       return;
/*    */     }
/* 60 */     final NameNode nn = (NameNode)context.getAttribute("name.node");
/* 61 */     String tokenString = req.getParameter("token");
/* 62 */     if (tokenString == null) {
/* 63 */       resp.sendError(300, "Token to renew not specified");
/*    */     }
/*    */ 
/* 66 */     final Token token = new Token();
/*    */ 
/* 68 */     token.decodeFromUrlString(tokenString);
/*    */     try
/*    */     {
/* 71 */       ugi.doAs(new PrivilegedExceptionAction() {
/*    */         public Void run() throws Exception {
/* 73 */           nn.cancelDelegationToken(token);
/* 74 */           return null;
/*    */         } } );
/*    */     }
/*    */     catch (Exception e) {
/* 78 */       LOG.info("Exception while cancelling token. Re-throwing. ", e);
/* 79 */       resp.sendError(500, e.getMessage());
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.CancelDelegationTokenServlet
 * JD-Core Version:    0.6.1
 */
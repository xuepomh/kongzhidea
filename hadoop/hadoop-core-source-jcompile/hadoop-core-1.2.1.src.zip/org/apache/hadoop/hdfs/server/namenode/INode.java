/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.apache.hadoop.fs.ContentSummary;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.fs.permission.PermissionStatus;
/*     */ import org.apache.hadoop.hdfs.DFSUtil;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlock;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlocks;
/*     */ 
/*     */ abstract class INode
/*     */   implements Comparable<byte[]>, FSInodeInfo
/*     */ {
/*     */   protected byte[] name;
/*     */   protected INodeDirectory parent;
/*     */   protected long modificationTime;
/*     */   protected long accessTime;
/*     */   private long permission;
/*     */ 
/*     */   protected INode()
/*     */   {
/*  88 */     this.name = null;
/*  89 */     this.parent = null;
/*  90 */     this.modificationTime = 0L;
/*  91 */     this.accessTime = 0L;
/*     */   }
/*     */ 
/*     */   INode(PermissionStatus permissions, long mTime, long atime) {
/*  95 */     this.name = null;
/*  96 */     this.parent = null;
/*  97 */     this.modificationTime = mTime;
/*  98 */     setAccessTime(atime);
/*  99 */     setPermissionStatus(permissions);
/*     */   }
/*     */ 
/*     */   protected INode(String name, PermissionStatus permissions) {
/* 103 */     this(permissions, 0L, 0L);
/* 104 */     setLocalName(name);
/*     */   }
/*     */ 
/*     */   INode(INode other)
/*     */   {
/* 112 */     setLocalName(other.getLocalName());
/* 113 */     this.parent = other.getParent();
/* 114 */     setPermissionStatus(other.getPermissionStatus());
/* 115 */     setModificationTime(other.getModificationTime());
/* 116 */     setAccessTime(other.getAccessTime());
/*     */   }
/*     */ 
/*     */   boolean isRoot()
/*     */   {
/* 123 */     return this.name.length == 0;
/*     */   }
/*     */ 
/*     */   protected void setPermissionStatus(PermissionStatus ps)
/*     */   {
/* 128 */     setUser(ps.getUserName());
/* 129 */     setGroup(ps.getGroupName());
/* 130 */     setPermission(ps.getPermission());
/*     */   }
/*     */ 
/*     */   protected PermissionStatus getPermissionStatus() {
/* 134 */     return new PermissionStatus(getUserName(), getGroupName(), getFsPermission());
/*     */   }
/*     */ 
/*     */   private synchronized void updatePermissionStatus(PermissionStatusFormat f, long n) {
/* 138 */     this.permission = f.combine(n, this.permission);
/*     */   }
/*     */ 
/*     */   public String getUserName() {
/* 142 */     int n = (int)PermissionStatusFormat.USER.retrieve(this.permission);
/* 143 */     return SerialNumberManager.INSTANCE.getUser(n);
/*     */   }
/*     */ 
/*     */   protected void setUser(String user) {
/* 147 */     int n = SerialNumberManager.INSTANCE.getUserSerialNumber(user);
/* 148 */     updatePermissionStatus(PermissionStatusFormat.USER, n);
/*     */   }
/*     */ 
/*     */   public String getGroupName() {
/* 152 */     int n = (int)PermissionStatusFormat.GROUP.retrieve(this.permission);
/* 153 */     return SerialNumberManager.INSTANCE.getGroup(n);
/*     */   }
/*     */ 
/*     */   protected void setGroup(String group) {
/* 157 */     int n = SerialNumberManager.INSTANCE.getGroupSerialNumber(group);
/* 158 */     updatePermissionStatus(PermissionStatusFormat.GROUP, n);
/*     */   }
/*     */ 
/*     */   public FsPermission getFsPermission() {
/* 162 */     return new FsPermission((short)(int)PermissionStatusFormat.MODE.retrieve(this.permission));
/*     */   }
/*     */ 
/*     */   protected short getFsPermissionShort() {
/* 166 */     return (short)(int)PermissionStatusFormat.MODE.retrieve(this.permission);
/*     */   }
/*     */ 
/*     */   protected void setPermission(FsPermission permission) {
/* 170 */     updatePermissionStatus(PermissionStatusFormat.MODE, permission.toShort());
/*     */   }
/*     */ 
/*     */   public abstract boolean isDirectory();
/*     */ 
/*     */   abstract int collectSubtreeBlocksAndClear(List<Block> paramList);
/*     */ 
/*     */   public final ContentSummary computeContentSummary()
/*     */   {
/* 186 */     long[] a = computeContentSummary(new long[] { 0L, 0L, 0L, 0L });
/* 187 */     return new ContentSummary(a[0], a[1], a[2], getNsQuota(), a[3], getDsQuota());
/*     */   }
/*     */ 
/*     */   abstract long[] computeContentSummary(long[] paramArrayOfLong);
/*     */ 
/*     */   long getNsQuota()
/*     */   {
/* 201 */     return -1L;
/*     */   }
/*     */ 
/*     */   long getDsQuota() {
/* 205 */     return -1L;
/*     */   }
/*     */ 
/*     */   boolean isQuotaSet() {
/* 209 */     return (getNsQuota() >= 0L) || (getDsQuota() >= 0L);
/*     */   }
/*     */ 
/*     */   abstract DirCounts spaceConsumedInTree(DirCounts paramDirCounts);
/*     */ 
/*     */   String getLocalName()
/*     */   {
/* 224 */     return DFSUtil.bytes2String(this.name);
/*     */   }
/*     */ 
/*     */   byte[] getLocalNameBytes()
/*     */   {
/* 232 */     return this.name;
/*     */   }
/*     */ 
/*     */   void setLocalName(String name)
/*     */   {
/* 239 */     this.name = DFSUtil.string2Bytes(name);
/*     */   }
/*     */ 
/*     */   void setLocalName(byte[] name)
/*     */   {
/* 246 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getFullPathName()
/*     */   {
/* 252 */     return FSDirectory.getFullPathName(this);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 257 */     return "\"" + getLocalName() + "\":" + getPermissionStatus();
/*     */   }
/*     */ 
/*     */   INodeDirectory getParent()
/*     */   {
/* 265 */     return this.parent;
/*     */   }
/*     */ 
/*     */   public long getModificationTime()
/*     */   {
/* 273 */     return this.modificationTime;
/*     */   }
/*     */ 
/*     */   void setModificationTime(long modtime)
/*     */   {
/* 280 */     assert (isDirectory());
/* 281 */     if (this.modificationTime <= modtime)
/* 282 */       this.modificationTime = modtime;
/*     */   }
/*     */ 
/*     */   void setModificationTimeForce(long modtime)
/*     */   {
/* 290 */     assert (!isDirectory());
/* 291 */     this.modificationTime = modtime;
/*     */   }
/*     */ 
/*     */   public long getAccessTime()
/*     */   {
/* 299 */     return this.accessTime;
/*     */   }
/*     */ 
/*     */   void setAccessTime(long atime)
/*     */   {
/* 306 */     this.accessTime = atime;
/*     */   }
/*     */ 
/*     */   boolean isUnderConstruction()
/*     */   {
/* 313 */     return false;
/*     */   }
/*     */ 
/*     */   static byte[][] getPathComponents(String path)
/*     */   {
/* 323 */     return getPathComponents(getPathNames(path));
/*     */   }
/*     */ 
/*     */   static byte[][] getPathComponents(String[] strings)
/*     */   {
/* 328 */     if (strings.length == 0) {
/* 329 */       return new byte[][] { null };
/*     */     }
/* 331 */     byte[][] bytes = new byte[strings.length][];
/* 332 */     for (int i = 0; i < strings.length; i++)
/* 333 */       bytes[i] = DFSUtil.string2Bytes(strings[i]);
/* 334 */     return bytes;
/*     */   }
/*     */ 
/*     */   static String[] getPathNames(String path)
/*     */   {
/* 343 */     if ((path == null) || (!path.startsWith("/"))) {
/* 344 */       return null;
/*     */     }
/* 346 */     return path.split("/");
/*     */   }
/*     */ 
/*     */   boolean removeNode() {
/* 350 */     if (this.parent == null) {
/* 351 */       return false;
/*     */     }
/*     */ 
/* 354 */     this.parent.removeChild(this);
/* 355 */     this.parent = null;
/* 356 */     return true;
/*     */   }
/*     */ 
/*     */   public int compareTo(byte[] o)
/*     */   {
/* 364 */     return compareBytes(this.name, o);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o) {
/* 368 */     if (!(o instanceof INode)) {
/* 369 */       return false;
/*     */     }
/* 371 */     return Arrays.equals(this.name, ((INode)o).name);
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 375 */     return Arrays.hashCode(this.name);
/*     */   }
/*     */ 
/*     */   static int compareBytes(byte[] a1, byte[] a2)
/*     */   {
/* 388 */     if (a1 == a2)
/* 389 */       return 0;
/* 390 */     int len1 = a1 == null ? 0 : a1.length;
/* 391 */     int len2 = a2 == null ? 0 : a2.length;
/* 392 */     int n = Math.min(len1, len2);
/*     */ 
/* 394 */     for (int i = 0; i < n; i++) {
/* 395 */       byte b1 = a1[i];
/* 396 */       byte b2 = a2[i];
/* 397 */       if (b1 != b2)
/* 398 */         return b1 - b2;
/*     */     }
/* 400 */     return len1 - len2;
/*     */   }
/*     */ 
/*     */   LocatedBlocks createLocatedBlocks(List<LocatedBlock> blocks)
/*     */   {
/* 405 */     return new LocatedBlocks(computeContentSummary().getLength(), blocks, isUnderConstruction());
/*     */   }
/*     */ 
/*     */   private static enum PermissionStatusFormat
/*     */   {
/*  64 */     MODE(0, 16), 
/*  65 */     GROUP(MODE.OFFSET + MODE.LENGTH, 25), 
/*  66 */     USER(GROUP.OFFSET + GROUP.LENGTH, 23);
/*     */ 
/*     */     final int OFFSET;
/*     */     final int LENGTH;
/*     */     final long MASK;
/*     */ 
/*  73 */     private PermissionStatusFormat(int offset, int length) { this.OFFSET = offset;
/*  74 */       this.LENGTH = length;
/*  75 */       this.MASK = (-1L >>> 64 - this.LENGTH << this.OFFSET); }
/*     */ 
/*     */     long retrieve(long record)
/*     */     {
/*  79 */       return (record & this.MASK) >>> this.OFFSET;
/*     */     }
/*     */ 
/*     */     long combine(long bits, long record) {
/*  83 */       return record & (this.MASK ^ 0xFFFFFFFF) | bits << this.OFFSET;
/*     */     }
/*     */   }
/*     */ 
/*     */   static class DirCounts
/*     */   {
/*  46 */     long nsCount = 0L;
/*  47 */     long dsCount = 0L;
/*     */ 
/*     */     long getNsCount()
/*     */     {
/*  51 */       return this.nsCount;
/*     */     }
/*     */ 
/*     */     long getDsCount() {
/*  55 */       return this.dsCount;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.INode
 * JD-Core Version:    0.6.1
 */
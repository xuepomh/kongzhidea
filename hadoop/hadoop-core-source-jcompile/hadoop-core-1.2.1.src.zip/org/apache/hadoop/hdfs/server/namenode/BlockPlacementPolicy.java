/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.hadoop.classification.InterfaceAudience.Private;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlock;
/*     */ import org.apache.hadoop.net.NetworkTopology;
/*     */ import org.apache.hadoop.net.Node;
/*     */ import org.apache.hadoop.util.ReflectionUtils;
/*     */ 
/*     */ @InterfaceAudience.Private
/*     */ public abstract class BlockPlacementPolicy
/*     */ {
/*     */   abstract DatanodeDescriptor[] chooseTarget(String paramString, int paramInt, DatanodeDescriptor paramDatanodeDescriptor, List<DatanodeDescriptor> paramList, long paramLong);
/*     */ 
/*     */   public abstract DatanodeDescriptor[] chooseTarget(String paramString, int paramInt, DatanodeDescriptor paramDatanodeDescriptor, List<DatanodeDescriptor> paramList, HashMap<Node, Node> paramHashMap, long paramLong);
/*     */ 
/*     */   DatanodeDescriptor[] chooseTarget(FSInodeInfo srcInode, int numOfReplicas, DatanodeDescriptor writer, List<DatanodeDescriptor> chosenNodes, long blocksize)
/*     */   {
/* 106 */     return chooseTarget(srcInode.getFullPathName(), numOfReplicas, writer, chosenNodes, blocksize);
/*     */   }
/*     */ 
/*     */   public abstract int verifyBlockPlacement(String paramString, LocatedBlock paramLocatedBlock, int paramInt);
/*     */ 
/*     */   public abstract DatanodeDescriptor chooseReplicaToDelete(FSInodeInfo paramFSInodeInfo, Block paramBlock, short paramShort, Collection<DatanodeDescriptor> paramCollection1, Collection<DatanodeDescriptor> paramCollection2);
/*     */ 
/*     */   protected abstract void initialize(Configuration paramConfiguration, FSClusterStats paramFSClusterStats, NetworkTopology paramNetworkTopology);
/*     */ 
/*     */   public static BlockPlacementPolicy getInstance(Configuration conf, FSClusterStats stats, NetworkTopology clusterMap)
/*     */   {
/* 165 */     Class replicatorClass = conf.getClass("dfs.block.replicator.classname", BlockPlacementPolicyDefault.class, BlockPlacementPolicy.class);
/*     */ 
/* 169 */     BlockPlacementPolicy replicator = (BlockPlacementPolicy)ReflectionUtils.newInstance(replicatorClass, conf);
/*     */ 
/* 171 */     replicator.initialize(conf, stats, clusterMap);
/* 172 */     return replicator;
/*     */   }
/*     */ 
/*     */   DatanodeDescriptor[] chooseTarget(String srcPath, int numOfReplicas, DatanodeDescriptor writer, long blocksize)
/*     */   {
/* 191 */     return chooseTarget(srcPath, numOfReplicas, writer, new ArrayList(), blocksize);
/*     */   }
/*     */ 
/*     */   public DatanodeDescriptor[] chooseTarget(String srcPath, int numOfReplicas, DatanodeDescriptor writer, HashMap<Node, Node> excludedNodes, long blocksize)
/*     */   {
/* 214 */     return chooseTarget(srcPath, numOfReplicas, writer, new ArrayList(), excludedNodes, blocksize);
/*     */   }
/*     */ 
/*     */   public void adjustSetsWithChosenReplica(Map<String, List<DatanodeDescriptor>> rackMap, List<DatanodeDescriptor> moreThanOne, List<DatanodeDescriptor> exactlyOne, DatanodeInfo cur)
/*     */   {
/* 234 */     String rack = getRack(cur);
/* 235 */     List datanodes = (List)rackMap.get(rack);
/* 236 */     datanodes.remove(cur);
/* 237 */     if (datanodes.isEmpty()) {
/* 238 */       rackMap.remove(rack);
/*     */     }
/* 240 */     if (moreThanOne.remove(cur)) {
/* 241 */       if (datanodes.size() == 1) {
/* 242 */         moreThanOne.remove(datanodes.get(0));
/* 243 */         exactlyOne.add(datanodes.get(0));
/*     */       }
/*     */     }
/* 246 */     else exactlyOne.remove(cur);
/*     */   }
/*     */ 
/*     */   protected String getRack(DatanodeInfo datanode)
/*     */   {
/* 256 */     return datanode.getNetworkLocation();
/*     */   }
/*     */ 
/*     */   public void splitNodesWithRack(Collection<DatanodeDescriptor> dataNodes, Map<String, List<DatanodeDescriptor>> rackMap, List<DatanodeDescriptor> moreThanOne, List<DatanodeDescriptor> exactlyOne)
/*     */   {
/* 273 */     for (DatanodeDescriptor node : dataNodes) {
/* 274 */       String rackName = getRack(node);
/* 275 */       List datanodeList = (List)rackMap.get(rackName);
/* 276 */       if (datanodeList == null) {
/* 277 */         datanodeList = new ArrayList();
/* 278 */         rackMap.put(rackName, datanodeList);
/*     */       }
/* 280 */       datanodeList.add(node);
/*     */     }
/*     */ 
/* 284 */     for (List datanodeList : rackMap.values())
/* 285 */       if (datanodeList.size() == 1)
/*     */       {
/* 287 */         exactlyOne.add(datanodeList.get(0));
/*     */       }
/*     */       else
/* 290 */         moreThanOne.addAll(datanodeList);
/*     */   }
/*     */ 
/*     */   @InterfaceAudience.Private
/*     */   public static class NotEnoughReplicasException extends Exception
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     NotEnoughReplicasException(String msg)
/*     */     {
/*  41 */       super();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.BlockPlacementPolicy
 * JD-Core Version:    0.6.1
 */
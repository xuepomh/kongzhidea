/*    */ package org.apache.hadoop.hdfs.server.namenode;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.InetSocketAddress;
/*    */ import java.util.Collection;
/*    */ import java.util.Vector;
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import javax.servlet.jsp.JspFactory;
/*    */ import javax.servlet.jsp.JspWriter;
/*    */ import javax.servlet.jsp.PageContext;
/*    */ import javax.servlet.jsp.SkipPageException;
/*    */ import org.apache.hadoop.util.ServletUtil;
/*    */ import org.apache.jasper.runtime.HttpJspBase;
/*    */ import org.apache.jasper.runtime.JspSourceDependent;
/*    */ import org.apache.jasper.runtime.ResourceInjector;
/*    */ 
/*    */ public final class corrupt_005ffiles_jsp extends HttpJspBase
/*    */   implements JspSourceDependent
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 18 */   private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();
/*    */   private static Vector _jspx_dependants;
/*    */   private ResourceInjector _jspx_resourceInjector;
/*    */ 
/*    */   public Object getDependants()
/*    */   {
/* 25 */     return _jspx_dependants;
/*    */   }
/*    */ 
/*    */   public void _jspService(HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException, ServletException
/*    */   {
/* 31 */     PageContext pageContext = null;
/* 32 */     HttpSession session = null;
/* 33 */     ServletContext application = null;
/* 34 */     ServletConfig config = null;
/* 35 */     JspWriter out = null;
/* 36 */     Object page = this;
/* 37 */     JspWriter _jspx_out = null;
/* 38 */     PageContext _jspx_page_context = null;
/*    */     try
/*    */     {
/* 41 */       response.setContentType("text/html; charset=UTF-8");
/* 42 */       pageContext = _jspxFactory.getPageContext(this, request, response, null, true, 8192, true);
/*    */ 
/* 44 */       _jspx_page_context = pageContext;
/* 45 */       application = pageContext.getServletContext();
/* 46 */       config = pageContext.getServletConfig();
/* 47 */       session = pageContext.getSession();
/* 48 */       out = pageContext.getOut();
/* 49 */       _jspx_out = out;
/* 50 */       this._jspx_resourceInjector = ((ResourceInjector)application.getAttribute("com.sun.appserv.jsp.resource.injector"));
/*    */ 
/* 52 */       out.write(10);
/*    */ 
/* 72 */       out.write(10);
/* 73 */       out.write(10);
/* 74 */       out.write(10);
/*    */ 
/* 76 */       NameNode nn = (NameNode)application.getAttribute("name.node");
/* 77 */       FSNamesystem fsn = nn.getNamesystem();
/*    */ 
/* 79 */       String namenodeLabel = nn.getNameNodeAddress().getHostName() + ":" + nn.getNameNodeAddress().getPort();
/*    */ 
/* 81 */       Collection corruptFileBlocks = fsn.listCorruptFileBlocks();
/*    */ 
/* 83 */       int corruptFileCount = corruptFileBlocks.size();
/*    */ 
/* 86 */       out.write("\n\n<html>\n<link rel=\"stylesheet\" type=\"text/css\" href=\"/static/hadoop.css\">\n<title>Hadoop ");
/* 87 */       out.print(namenodeLabel);
/* 88 */       out.write("</title>\n<body>\n<h1>'");
/* 89 */       out.print(namenodeLabel);
/* 90 */       out.write("'</h1>\n");
/* 91 */       out.print(JspHelper.getVersionTable(fsn));
/* 92 */       out.write("\n<br>\n<b><a href=\"/nn_browsedfscontent.jsp\">Browse the filesystem</a></b>\n<br>\n<b><a href=\"/logs/\">");
/* 93 */       out.print(namenodeLabel);
/* 94 */       out.write(" Logs</a></b>\n<br>\n<b><a href=/dfshealth.jsp> Go back to DFS home</a></b>\n<hr>\n<h3>Reported Corrupt Files</h3>\n");
/*    */ 
/* 96 */       if (corruptFileCount == 0)
/*    */       {
/* 98 */         out.write("\n    <i>No missing blocks found at the moment.</i> <br>\n    Please run fsck for a thorough health analysis.\n");
/*    */       }
/*    */       else {
/* 101 */         for (FSNamesystem.CorruptFileBlockInfo c : corruptFileBlocks) {
/* 102 */           String currentFileBlock = c.toString();
/*    */ 
/* 104 */           out.write("\n      ");
/* 105 */           out.print(currentFileBlock);
/* 106 */           out.write("<br>\n");
/*    */         }
/*    */ 
/* 110 */         out.write("\n    <p>\n      <b>Total:</b> At least ");
/* 111 */         out.print(corruptFileCount);
/* 112 */         out.write(" corrupt file(s)\n    </p>\n");
/*    */       }
/*    */ 
/* 116 */       out.write(10);
/* 117 */       out.write(10);
/*    */ 
/* 119 */       out.println(ServletUtil.htmlFooter());
/*    */ 
/* 121 */       out.write(10);
/*    */     } catch (Throwable t) {
/* 123 */       if (!(t instanceof SkipPageException)) {
/* 124 */         out = _jspx_out;
/* 125 */         if ((out != null) && (out.getBufferSize() != 0))
/* 126 */           out.clearBuffer();
/* 127 */         if (_jspx_page_context != null) _jspx_page_context.handlePageException(t); 
/*    */       }
/*    */     }
/* 130 */     finally { _jspxFactory.releasePageContext(_jspx_page_context); }
/*    */ 
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.corrupt_005ffiles_jsp
 * JD-Core Version:    0.6.1
 */
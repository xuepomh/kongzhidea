/*      */ package org.apache.hadoop.hdfs.server.balancer;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.DataInput;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutput;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.net.InetAddress;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.Socket;
/*      */ import java.text.DateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.EnumSet;
/*      */ import java.util.Formatter;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ExecutionException;
/*      */ import java.util.concurrent.ExecutorService;
/*      */ import java.util.concurrent.Executors;
/*      */ import java.util.concurrent.Future;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.apache.hadoop.conf.Configuration;
/*      */ import org.apache.hadoop.fs.FileSystem;
/*      */ import org.apache.hadoop.fs.Path;
/*      */ import org.apache.hadoop.hdfs.DFSClient;
/*      */ import org.apache.hadoop.hdfs.protocol.AlreadyBeingCreatedException;
/*      */ import org.apache.hadoop.hdfs.protocol.Block;
/*      */ import org.apache.hadoop.hdfs.protocol.ClientProtocol;
/*      */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*      */ import org.apache.hadoop.hdfs.protocol.FSConstants;
/*      */ import org.apache.hadoop.hdfs.protocol.FSConstants.DatanodeReportType;
/*      */ import org.apache.hadoop.hdfs.security.token.block.BlockTokenSecretManager;
/*      */ import org.apache.hadoop.hdfs.security.token.block.BlockTokenSecretManager.AccessMode;
/*      */ import org.apache.hadoop.hdfs.security.token.block.ExportedBlockKeys;
/*      */ import org.apache.hadoop.hdfs.server.common.Util;
/*      */ import org.apache.hadoop.hdfs.server.namenode.BlockPlacementPolicy;
/*      */ import org.apache.hadoop.hdfs.server.namenode.BlockPlacementPolicyDefault;
/*      */ import org.apache.hadoop.hdfs.server.namenode.NameNode;
/*      */ import org.apache.hadoop.hdfs.server.namenode.UnsupportedActionException;
/*      */ import org.apache.hadoop.hdfs.server.protocol.BlocksWithLocations;
/*      */ import org.apache.hadoop.hdfs.server.protocol.BlocksWithLocations.BlockWithLocations;
/*      */ import org.apache.hadoop.hdfs.server.protocol.NamenodeProtocol;
/*      */ import org.apache.hadoop.io.IOUtils;
/*      */ import org.apache.hadoop.io.Text;
/*      */ import org.apache.hadoop.io.Writable;
/*      */ import org.apache.hadoop.io.retry.RetryPolicies;
/*      */ import org.apache.hadoop.io.retry.RetryPolicy;
/*      */ import org.apache.hadoop.io.retry.RetryProxy;
/*      */ import org.apache.hadoop.ipc.RPC;
/*      */ import org.apache.hadoop.ipc.RemoteException;
/*      */ import org.apache.hadoop.net.NetUtils;
/*      */ import org.apache.hadoop.net.NetworkTopology;
/*      */ import org.apache.hadoop.net.Node;
/*      */ import org.apache.hadoop.security.UserGroupInformation;
/*      */ import org.apache.hadoop.security.token.Token;
/*      */ import org.apache.hadoop.util.Daemon;
/*      */ import org.apache.hadoop.util.StringUtils;
/*      */ import org.apache.hadoop.util.Tool;
/*      */ import org.apache.hadoop.util.ToolRunner;
/*      */ 
/*      */ public class Balancer
/*      */   implements Tool
/*      */ {
/*  187 */   private static final Log LOG = LogFactory.getLog(Balancer.class.getName());
/*      */   private static final long MAX_BLOCKS_SIZE_TO_FETCH = 2147483648L;
/*      */   public static final int MAX_NUM_CONCURRENT_MOVES = 5;
/*      */   public static final int MAX_NO_PENDING_BLOCK_ITERATIONS = 5;
/*      */   private Configuration conf;
/*  200 */   private double threshold = 10.0D;
/*      */   private NamenodeProtocol namenode;
/*      */   private ClientProtocol client;
/*      */   private FileSystem fs;
/*      */   private boolean isBlockTokenEnabled;
/*      */   private boolean shouldRun;
/*      */   private long keyUpdaterInterval;
/*      */   private BlockTokenSecretManager blockTokenSecretManager;
/*  208 */   private Daemon keyupdaterthread = null;
/*  209 */   private static final Random rnd = new Random();
/*      */ 
/*  212 */   private Collection<Source> overUtilizedDatanodes = new LinkedList();
/*      */ 
/*  214 */   private Collection<Source> aboveAvgUtilizedDatanodes = new LinkedList();
/*      */ 
/*  216 */   private Collection<BalancerDatanode> belowAvgUtilizedDatanodes = new LinkedList();
/*      */ 
/*  218 */   private Collection<BalancerDatanode> underUtilizedDatanodes = new LinkedList();
/*      */ 
/*  221 */   private Collection<Source> sources = new HashSet();
/*      */ 
/*  223 */   private Collection<BalancerDatanode> targets = new HashSet();
/*      */ 
/*  226 */   private Map<Block, BalancerBlock> globalBlockList = new HashMap();
/*      */ 
/*  228 */   private MovedBlocks movedBlocks = new MovedBlocks(null);
/*  229 */   private Map<String, BalancerDatanode> datanodes = new HashMap();
/*      */   private NetworkTopology cluster;
/*  234 */   private double avgUtilization = 0.0D;
/*      */   private static final int MOVER_THREAD_POOL_SIZE = 1000;
/*  237 */   private final ExecutorService moverExecutor = Executors.newFixedThreadPool(1000);
/*      */   private static final int DISPATCHER_THREAD_POOL_SIZE = 200;
/*  240 */   private final ExecutorService dispatcherExecutor = Executors.newFixedThreadPool(200);
/*      */ 
/* 1083 */   static final Matcher SAME_NODE_GROUP = new Matcher()
/*      */   {
/*      */     public boolean match(NetworkTopology cluster, Node left, Node right) {
/* 1086 */       return cluster.isOnSameNodeGroup(left, right);
/*      */     }
/* 1083 */   };
/*      */ 
/* 1091 */   static final Matcher SAME_RACK = new Matcher()
/*      */   {
/*      */     public boolean match(NetworkTopology cluster, Node left, Node right) {
/* 1094 */       return cluster.isOnSameRack(left, right);
/*      */     }
/* 1091 */   };
/*      */ 
/* 1099 */   static final Matcher ANY_OTHER = new Matcher()
/*      */   {
/*      */     public boolean match(NetworkTopology cluster, Node left, Node right) {
/* 1102 */       return left != right;
/*      */     }
/* 1099 */   };
/*      */ 
/* 1236 */   private BytesMoved bytesMoved = new BytesMoved(null);
/* 1237 */   private int notChangedIterations = 0;
/*      */ 
/* 1269 */   private static long blockMoveWaitTime = 30000L;
/*      */   public static final int SUCCESS = 1;
/*      */   public static final int ALREADY_RUNNING = -1;
/*      */   public static final int NO_MOVE_BLOCK = -2;
/*      */   public static final int NO_MOVE_PROGRESS = -3;
/*      */   public static final int IO_EXCEPTION = -4;
/*      */   public static final int ILLEGAL_ARGS = -5;
/* 1603 */   private Path BALANCER_ID_PATH = new Path("/system/balancer.id");
/*      */ 
/*      */   private static double getUtilization(DatanodeInfo datanode)
/*      */   {
/*  496 */     return datanode.getDfsUsed() / datanode.getCapacity() * 100.0D;
/*      */   }
/*      */ 
/*      */   private void checkReplicationPolicyCompatibility(Configuration conf)
/*      */     throws UnsupportedActionException
/*      */   {
/*  810 */     if (!(BlockPlacementPolicy.getInstance(conf, null, null) instanceof BlockPlacementPolicyDefault))
/*      */     {
/*  812 */       throw new UnsupportedActionException("Balancer without BlockPlacementPolicyDefault");
/*      */     }
/*      */   }
/*      */ 
/*      */   Balancer(Configuration conf)
/*      */     throws UnsupportedActionException
/*      */   {
/*  819 */     checkReplicationPolicyCompatibility(conf);
/*  820 */     setConf(conf);
/*      */   }
/*      */ 
/*      */   Balancer(Configuration conf, double threshold)
/*      */     throws UnsupportedActionException
/*      */   {
/*  826 */     checkReplicationPolicyCompatibility(conf);
/*  827 */     setConf(conf);
/*  828 */     this.threshold = threshold;
/*      */   }
/*      */ 
/*      */   public static void main(String[] args)
/*      */   {
/*      */     try
/*      */     {
/*  837 */       Configuration conf = new Configuration();
/*  838 */       System.exit(ToolRunner.run(conf, new Balancer(conf), args));
/*      */     } catch (Throwable e) {
/*  840 */       LOG.error(StringUtils.stringifyException(e));
/*  841 */       System.exit(-1);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void printUsage()
/*      */   {
/*  847 */     System.out.println("Usage: java Balancer");
/*  848 */     System.out.println("          [-threshold <threshold>]\tpercentage of disk capacity");
/*      */   }
/*      */ 
/*      */   private double parseArgs(String[] args)
/*      */   {
/*  854 */     double threshold = 0.0D;
/*  855 */     int argsLen = args == null ? 0 : args.length;
/*  856 */     if (argsLen == 0) {
/*  857 */       threshold = 10.0D;
/*      */     } else {
/*  859 */       if ((argsLen != 2) || (!"-threshold".equalsIgnoreCase(args[0]))) {
/*  860 */         printUsage();
/*  861 */         throw new IllegalArgumentException(Arrays.toString(args));
/*      */       }
/*      */       try {
/*  864 */         threshold = Double.parseDouble(args[1]);
/*  865 */         if ((threshold < 0.0D) || (threshold > 100.0D)) {
/*  866 */           throw new NumberFormatException();
/*      */         }
/*  868 */         LOG.info(new StringBuilder().append("Using a threshold of ").append(threshold).toString());
/*      */       } catch (NumberFormatException e) {
/*  870 */         System.err.println(new StringBuilder().append("Expect a double parameter in the range of [0, 100]: ").append(args[1]).toString());
/*      */ 
/*  872 */         printUsage();
/*  873 */         throw e;
/*      */       }
/*      */     }
/*      */ 
/*  877 */     return threshold;
/*      */   }
/*      */ 
/*      */   private void init(double threshold)
/*      */     throws IOException
/*      */   {
/*  886 */     this.threshold = threshold;
/*  887 */     this.namenode = createNamenode(this.conf);
/*  888 */     this.client = DFSClient.createNamenode(this.conf);
/*  889 */     this.fs = FileSystem.get(this.conf);
/*  890 */     ExportedBlockKeys keys = this.namenode.getBlockKeys();
/*  891 */     this.isBlockTokenEnabled = keys.isBlockTokenEnabled();
/*  892 */     if (this.isBlockTokenEnabled) {
/*  893 */       long blockKeyUpdateInterval = keys.getKeyUpdateInterval();
/*  894 */       long blockTokenLifetime = keys.getTokenLifetime();
/*  895 */       LOG.info(new StringBuilder().append("Block token params received from NN: keyUpdateInterval=").append(blockKeyUpdateInterval / 60000L).append(" min(s), tokenLifetime=").append(blockTokenLifetime / 60000L).append(" min(s)").toString());
/*      */ 
/*  898 */       this.blockTokenSecretManager = new BlockTokenSecretManager(false, blockKeyUpdateInterval, blockTokenLifetime);
/*      */ 
/*  900 */       this.blockTokenSecretManager.setKeys(keys);
/*      */ 
/*  905 */       this.keyUpdaterInterval = (blockKeyUpdateInterval / 4L);
/*  906 */       LOG.info(new StringBuilder().append("Balancer will update its block keys every ").append(this.keyUpdaterInterval / 60000L).append(" minute(s)").toString());
/*      */ 
/*  908 */       this.keyupdaterthread = new Daemon(new BlockKeyUpdater());
/*  909 */       this.shouldRun = true;
/*  910 */       this.keyupdaterthread.start();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static NamenodeProtocol createNamenode(Configuration conf)
/*      */     throws IOException
/*      */   {
/*  938 */     InetSocketAddress nameNodeAddr = NameNode.getServiceAddress(conf, true);
/*  939 */     RetryPolicy timeoutPolicy = RetryPolicies.exponentialBackoffRetry(5, 200L, TimeUnit.MILLISECONDS);
/*      */ 
/*  941 */     Map exceptionToPolicyMap = new HashMap();
/*      */ 
/*  943 */     RetryPolicy methodPolicy = RetryPolicies.retryByException(timeoutPolicy, exceptionToPolicyMap);
/*      */ 
/*  945 */     Map methodNameToPolicyMap = new HashMap();
/*      */ 
/*  947 */     methodNameToPolicyMap.put("getBlocks", methodPolicy);
/*  948 */     methodNameToPolicyMap.put("getAccessKeys", methodPolicy);
/*      */ 
/*  950 */     UserGroupInformation ugi = UserGroupInformation.getCurrentUser();
/*      */ 
/*  952 */     return (NamenodeProtocol)RetryProxy.create(NamenodeProtocol.class, RPC.getProxy(NamenodeProtocol.class, 3L, nameNodeAddr, ugi, conf, NetUtils.getDefaultSocketFactory(conf)), methodNameToPolicyMap);
/*      */   }
/*      */ 
/*      */   private static void shuffleArray(DatanodeInfo[] datanodes)
/*      */   {
/*  965 */     for (int i = datanodes.length; i > 1; i--) {
/*  966 */       int randomIndex = rnd.nextInt(i);
/*  967 */       DatanodeInfo tmp = datanodes[randomIndex];
/*  968 */       datanodes[randomIndex] = datanodes[(i - 1)];
/*  969 */       datanodes[(i - 1)] = tmp;
/*      */     }
/*      */   }
/*      */ 
/*      */   private long initNodes()
/*      */     throws IOException
/*      */   {
/*  977 */     return initNodes(this.client.getDatanodeReport(FSConstants.DatanodeReportType.LIVE));
/*      */   }
/*      */ 
/*      */   private long initNodes(DatanodeInfo[] datanodes)
/*      */   {
/*  995 */     long totalCapacity = 0L; long totalUsedSpace = 0L;
/*  996 */     for (DatanodeInfo datanode : datanodes)
/*  997 */       if ((!datanode.isDecommissioned()) && (!datanode.isDecommissionInProgress()))
/*      */       {
/* 1000 */         totalCapacity += datanode.getCapacity();
/* 1001 */         totalUsedSpace += datanode.getDfsUsed();
/*      */       }
/* 1003 */     this.avgUtilization = (totalUsedSpace / totalCapacity * 100.0D);
/*      */ 
/* 1010 */     long overLoadedBytes = 0L; long underLoadedBytes = 0L;
/* 1011 */     shuffleArray(datanodes);
/* 1012 */     for (DatanodeInfo datanode : datanodes) {
/* 1013 */       if ((!datanode.isDecommissioned()) && (!datanode.isDecommissionInProgress()))
/*      */       {
/* 1016 */         this.cluster.add(datanode);
/*      */         BalancerDatanode datanodeS;
/* 1018 */         if (getUtilization(datanode) > this.avgUtilization) {
/* 1019 */           BalancerDatanode datanodeS = new Source(datanode, this.avgUtilization, this.threshold, null);
/* 1020 */           if (isAboveAvgUtilized(datanodeS)) {
/* 1021 */             this.aboveAvgUtilizedDatanodes.add((Source)datanodeS);
/*      */           }
/*      */           else {
/* 1024 */             assert (isOverUtilized(datanodeS)) : new StringBuilder().append(datanodeS.getName()).append("is not an overUtilized node").toString();
/* 1025 */             this.overUtilizedDatanodes.add((Source)datanodeS);
/* 1026 */             overLoadedBytes += ()((datanodeS.utilization - this.avgUtilization - this.threshold) * datanodeS.datanode.getCapacity() / 100.0D);
/*      */           }
/*      */         }
/*      */         else {
/* 1030 */           datanodeS = new BalancerDatanode(datanode, this.avgUtilization, this.threshold, null);
/* 1031 */           if (isBelowAvgUtilized(datanodeS)) {
/* 1032 */             this.belowAvgUtilizedDatanodes.add(datanodeS);
/*      */           }
/*      */           else {
/* 1035 */             assert (isUnderUtilized(datanodeS)) : new StringBuilder().append(datanodeS.getName()).append("is not an underUtilized node").toString();
/* 1036 */             this.underUtilizedDatanodes.add(datanodeS);
/* 1037 */             underLoadedBytes += ()((this.avgUtilization - this.threshold - datanodeS.utilization) * datanodeS.datanode.getCapacity() / 100.0D);
/*      */           }
/*      */         }
/*      */ 
/* 1041 */         this.datanodes.put(datanode.getStorageID(), datanodeS);
/*      */       }
/*      */     }
/*      */ 
/* 1045 */     logImbalancedNodes();
/*      */ 
/* 1050 */     assert (this.datanodes.size() == this.overUtilizedDatanodes.size() + this.underUtilizedDatanodes.size() + this.aboveAvgUtilizedDatanodes.size() + this.belowAvgUtilizedDatanodes.size()) : "Mismatched number of datanodes";
/*      */ 
/* 1053 */     return Math.max(overLoadedBytes, underLoadedBytes);
/*      */   }
/*      */ 
/*      */   private void logImbalancedNodes()
/*      */   {
/* 1058 */     StringBuilder msg = new StringBuilder();
/* 1059 */     msg.append(this.overUtilizedDatanodes.size());
/* 1060 */     msg.append(" over utilized nodes:");
/* 1061 */     for (Source node : this.overUtilizedDatanodes) {
/* 1062 */       msg.append(" ");
/* 1063 */       msg.append(node.getName());
/*      */     }
/* 1065 */     LOG.info(msg);
/* 1066 */     msg = new StringBuilder();
/* 1067 */     msg.append(this.underUtilizedDatanodes.size());
/* 1068 */     msg.append(" under utilized nodes: ");
/* 1069 */     for (BalancerDatanode node : this.underUtilizedDatanodes) {
/* 1070 */       msg.append(" ");
/* 1071 */       msg.append(node.getName());
/*      */     }
/* 1073 */     LOG.info(msg);
/*      */   }
/*      */ 
/*      */   private long chooseNodes()
/*      */   {
/* 1114 */     if (this.cluster.isNodeGroupAware()) {
/* 1115 */       chooseNodes(SAME_NODE_GROUP);
/*      */     }
/*      */ 
/* 1119 */     chooseNodes(SAME_RACK);
/*      */ 
/* 1121 */     chooseNodes(ANY_OTHER);
/*      */ 
/* 1127 */     assert (this.datanodes.size() == this.overUtilizedDatanodes.size() + this.underUtilizedDatanodes.size() + this.aboveAvgUtilizedDatanodes.size() + this.belowAvgUtilizedDatanodes.size() + this.sources.size() + this.targets.size()) : "Mismatched number of datanodes";
/*      */ 
/* 1129 */     long bytesToMove = 0L;
/* 1130 */     for (Source src : this.sources) {
/* 1131 */       bytesToMove += src.scheduledSize;
/*      */     }
/* 1133 */     return bytesToMove;
/*      */   }
/*      */ 
/*      */   private void chooseNodes(Matcher matcher)
/*      */   {
/* 1141 */     chooseDatanodes(this.overUtilizedDatanodes, this.underUtilizedDatanodes, matcher);
/*      */ 
/* 1148 */     chooseDatanodes(this.overUtilizedDatanodes, this.belowAvgUtilizedDatanodes, matcher);
/*      */ 
/* 1155 */     chooseDatanodes(this.underUtilizedDatanodes, this.aboveAvgUtilizedDatanodes, matcher);
/*      */   }
/*      */ 
/*      */   private <D extends BalancerDatanode, C extends BalancerDatanode> void chooseDatanodes(Collection<D> datanodes, Collection<C> candidates, Matcher matcher)
/*      */   {
/* 1166 */     for (Iterator i = datanodes.iterator(); i.hasNext(); ) {
/* 1167 */       BalancerDatanode datanode = (BalancerDatanode)i.next();
/* 1168 */       while (chooseForOneDatanode(datanode, candidates, matcher));
/* 1169 */       if (!datanode.hasSpaceForScheduling())
/* 1170 */         i.remove();
/*      */     }
/*      */   }
/*      */ 
/*      */   private <C extends BalancerDatanode> boolean chooseForOneDatanode(BalancerDatanode dn, Collection<C> candidates, Matcher matcher)
/*      */   {
/* 1181 */     Iterator i = candidates.iterator();
/* 1182 */     BalancerDatanode chosen = chooseCandidate(dn, i, matcher);
/*      */ 
/* 1184 */     if (chosen == null) {
/* 1185 */       return false;
/*      */     }
/* 1187 */     if ((dn instanceof Source))
/* 1188 */       matchSourceWithTargetToMove((Source)dn, chosen);
/*      */     else {
/* 1190 */       matchSourceWithTargetToMove((Source)chosen, dn);
/*      */     }
/* 1192 */     if (!chosen.hasSpaceForScheduling()) {
/* 1193 */       i.remove();
/*      */     }
/* 1195 */     return true;
/*      */   }
/*      */ 
/*      */   private void matchSourceWithTargetToMove(Source source, BalancerDatanode target)
/*      */   {
/* 1200 */     long size = Math.min(source.availableSizeToMove(), target.availableSizeToMove());
/* 1201 */     NodeTask nodeTask = new NodeTask(target, size, null);
/* 1202 */     source.addNodeTask(nodeTask);
/* 1203 */     target.incScheduledSize(nodeTask.getSize());
/* 1204 */     this.sources.add(source);
/* 1205 */     this.targets.add(target);
/* 1206 */     LOG.info(new StringBuilder().append("Decided to move ").append(StringUtils.byteDesc(size)).append(" bytes from ").append(source.datanode.getName()).append(" to ").append(target.datanode.getName()).toString());
/*      */   }
/*      */ 
/*      */   private <D extends BalancerDatanode, C extends BalancerDatanode> C chooseCandidate(D dn, Iterator<C> candidates, Matcher matcher)
/*      */   {
/* 1213 */     if (dn.hasSpaceForScheduling()) {
/* 1214 */       while (candidates.hasNext()) {
/* 1215 */         BalancerDatanode c = (BalancerDatanode)candidates.next();
/* 1216 */         if (!c.hasSpaceForScheduling())
/* 1217 */           candidates.remove();
/* 1218 */         else if (matcher.match(this.cluster, dn.getDatanode(), c.getDatanode())) {
/* 1219 */           return c;
/*      */         }
/*      */       }
/*      */     }
/* 1223 */     return null; } 
/*      */   private long dispatchBlockMoves() throws InterruptedException { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 10	org/apache/hadoop/hdfs/server/balancer/Balancer:bytesMoved	Lorg/apache/hadoop/hdfs/server/balancer/Balancer$BytesMoved;
/*      */     //   4: invokestatic 199	org/apache/hadoop/hdfs/server/balancer/Balancer$BytesMoved:access$4700	(Lorg/apache/hadoop/hdfs/server/balancer/Balancer$BytesMoved;)J
/*      */     //   7: lstore_1
/*      */     //   8: aload_0
/*      */     //   9: getfield 37	org/apache/hadoop/hdfs/server/balancer/Balancer:sources	Ljava/util/Collection;
/*      */     //   12: invokeinterface 159 1 0
/*      */     //   17: anewarray 200	java/util/concurrent/Future
/*      */     //   20: astore_3
/*      */     //   21: iconst_0
/*      */     //   22: istore 4
/*      */     //   24: aload_0
/*      */     //   25: getfield 37	org/apache/hadoop/hdfs/server/balancer/Balancer:sources	Ljava/util/Collection;
/*      */     //   28: invokeinterface 164 1 0
/*      */     //   33: astore 5
/*      */     //   35: aload 5
/*      */     //   37: invokeinterface 165 1 0
/*      */     //   42: ifeq +49 -> 91
/*      */     //   45: aload 5
/*      */     //   47: invokeinterface 166 1 0
/*      */     //   52: checkcast 139	org/apache/hadoop/hdfs/server/balancer/Balancer$Source
/*      */     //   55: astore 6
/*      */     //   57: aload_3
/*      */     //   58: iload 4
/*      */     //   60: iinc 4 1
/*      */     //   63: aload_0
/*      */     //   64: getfield 45	org/apache/hadoop/hdfs/server/balancer/Balancer:dispatcherExecutor	Ljava/util/concurrent/ExecutorService;
/*      */     //   67: new 201	org/apache/hadoop/hdfs/server/balancer/Balancer$Source$BlockMoveDispatcher
/*      */     //   70: dup
/*      */     //   71: aload 6
/*      */     //   73: dup
/*      */     //   74: invokevirtual 202	java/lang/Object:getClass	()Ljava/lang/Class;
/*      */     //   77: pop
/*      */     //   78: aconst_null
/*      */     //   79: invokespecial 203	org/apache/hadoop/hdfs/server/balancer/Balancer$Source$BlockMoveDispatcher:<init>	(Lorg/apache/hadoop/hdfs/server/balancer/Balancer$Source;Lorg/apache/hadoop/hdfs/server/balancer/Balancer$1;)V
/*      */     //   82: invokeinterface 204 2 0
/*      */     //   87: aastore
/*      */     //   88: goto -53 -> 35
/*      */     //   91: aload_3
/*      */     //   92: astore 5
/*      */     //   94: aload 5
/*      */     //   96: arraylength
/*      */     //   97: istore 6
/*      */     //   99: iconst_0
/*      */     //   100: istore 7
/*      */     //   102: iload 7
/*      */     //   104: iload 6
/*      */     //   106: if_icmpge +44 -> 150
/*      */     //   109: aload 5
/*      */     //   111: iload 7
/*      */     //   113: aaload
/*      */     //   114: astore 8
/*      */     //   116: aload 8
/*      */     //   118: invokeinterface 205 1 0
/*      */     //   123: pop
/*      */     //   124: goto +20 -> 144
/*      */     //   127: astore 9
/*      */     //   129: getstatic 12	org/apache/hadoop/hdfs/server/balancer/Balancer:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   132: ldc 207
/*      */     //   134: aload 9
/*      */     //   136: invokevirtual 208	java/util/concurrent/ExecutionException:getCause	()Ljava/lang/Throwable;
/*      */     //   139: invokeinterface 209 3 0
/*      */     //   144: iinc 7 1
/*      */     //   147: goto -45 -> 102
/*      */     //   150: aload_0
/*      */     //   151: invokespecial 210	org/apache/hadoop/hdfs/server/balancer/Balancer:waitForMoveCompletion	()V
/*      */     //   154: aload_0
/*      */     //   155: getfield 10	org/apache/hadoop/hdfs/server/balancer/Balancer:bytesMoved	Lorg/apache/hadoop/hdfs/server/balancer/Balancer$BytesMoved;
/*      */     //   158: invokestatic 199	org/apache/hadoop/hdfs/server/balancer/Balancer$BytesMoved:access$4700	(Lorg/apache/hadoop/hdfs/server/balancer/Balancer$BytesMoved;)J
/*      */     //   161: lload_1
/*      */     //   162: lsub
/*      */     //   163: lreturn
/*      */     //
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   116	124	127	java/util/concurrent/ExecutionException } 
/* 1273 */   static void setBlockMoveWaitTime(long time) { blockMoveWaitTime = time; }
/*      */ 
/*      */ 
/*      */   private void waitForMoveCompletion()
/*      */   {
/*      */     boolean shouldWait;
/*      */     do
/*      */     {
/* 1282 */       shouldWait = false;
/* 1283 */       for (BalancerDatanode target : this.targets) {
/* 1284 */         if (!target.isPendingQEmpty()) {
/* 1285 */           shouldWait = true;
/*      */         }
/*      */       }
/* 1288 */       if (shouldWait)
/*      */         try {
/* 1290 */           Thread.sleep(blockMoveWaitTime);
/*      */         } catch (InterruptedException ignored) {
/*      */         }
/*      */     }
/* 1294 */     while (shouldWait);
/*      */   }
/*      */ 
/*      */   private boolean isGoodBlockCandidate(Source source, BalancerDatanode target, BalancerBlock block)
/*      */   {
/* 1363 */     if (this.movedBlocks.contains(block)) {
/* 1364 */       return false;
/*      */     }
/* 1366 */     if (block.isLocatedOnDatanode(target)) {
/* 1367 */       return false;
/*      */     }
/*      */ 
/* 1370 */     if ((this.cluster.isNodeGroupAware()) && (isOnSameNodeGroupWithReplicas(target, block, source)))
/*      */     {
/* 1372 */       return false;
/*      */     }
/*      */ 
/* 1375 */     boolean goodBlock = false;
/* 1376 */     if (this.cluster.isOnSameRack(source.getDatanode(), target.getDatanode()))
/*      */     {
/* 1378 */       goodBlock = true;
/*      */     } else {
/* 1380 */       boolean notOnSameRack = true;
/* 1381 */       synchronized (block) {
/* 1382 */         for (BalancerDatanode loc : block.locations) {
/* 1383 */           if (this.cluster.isOnSameRack(loc.datanode, target.datanode)) {
/* 1384 */             notOnSameRack = false;
/* 1385 */             break;
/*      */           }
/*      */         }
/*      */       }
/* 1389 */       if (notOnSameRack)
/*      */       {
/* 1391 */         goodBlock = true;
/*      */       }
/*      */       else {
/* 1394 */         for (BalancerDatanode loc : block.locations) {
/* 1395 */           if ((loc != source) && (this.cluster.isOnSameRack(loc.datanode, source.datanode)))
/*      */           {
/* 1397 */             goodBlock = true;
/* 1398 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1403 */     return goodBlock;
/*      */   }
/*      */ 
/*      */   private boolean isOnSameNodeGroupWithReplicas(BalancerDatanode target, BalancerBlock block, Source source)
/*      */   {
/* 1419 */     for (BalancerDatanode loc : block.locations) {
/* 1420 */       if ((loc != source) && (this.cluster.isOnSameNodeGroup(loc.getDatanode(), target.getDatanode())))
/*      */       {
/* 1422 */         return true;
/*      */       }
/*      */     }
/* 1425 */     return false;
/*      */   }
/*      */ 
/*      */   private void resetData()
/*      */   {
/* 1430 */     this.cluster = NetworkTopology.getInstance(this.conf);
/* 1431 */     this.overUtilizedDatanodes.clear();
/* 1432 */     this.aboveAvgUtilizedDatanodes.clear();
/* 1433 */     this.belowAvgUtilizedDatanodes.clear();
/* 1434 */     this.underUtilizedDatanodes.clear();
/* 1435 */     this.datanodes.clear();
/* 1436 */     this.sources.clear();
/* 1437 */     this.targets.clear();
/* 1438 */     this.avgUtilization = 0.0D;
/* 1439 */     cleanGlobalBlockList();
/* 1440 */     this.movedBlocks.cleanup();
/*      */   }
/*      */ 
/*      */   private void cleanGlobalBlockList()
/*      */   {
/* 1447 */     Iterator globalBlockListIterator = this.globalBlockList.keySet().iterator();
/* 1448 */     while (globalBlockListIterator.hasNext()) {
/* 1449 */       Block block = (Block)globalBlockListIterator.next();
/* 1450 */       if (!this.movedBlocks.contains(block))
/* 1451 */         globalBlockListIterator.remove();
/*      */     }
/*      */   }
/*      */ 
/*      */   private boolean isOverUtilized(BalancerDatanode datanode)
/*      */   {
/* 1458 */     return datanode.utilization > this.avgUtilization + this.threshold;
/*      */   }
/*      */ 
/*      */   private boolean isAboveAvgUtilized(BalancerDatanode datanode)
/*      */   {
/* 1464 */     return (datanode.utilization <= this.avgUtilization + this.threshold) && (datanode.utilization > this.avgUtilization);
/*      */   }
/*      */ 
/*      */   private boolean isUnderUtilized(BalancerDatanode datanode)
/*      */   {
/* 1470 */     return datanode.utilization < this.avgUtilization - this.threshold;
/*      */   }
/*      */ 
/*      */   private boolean isBelowAvgUtilized(BalancerDatanode datanode)
/*      */   {
/* 1476 */     return (datanode.utilization >= this.avgUtilization - this.threshold) && (datanode.utilization < this.avgUtilization);
/*      */   }
/*      */ 
/*      */   public int run(String[] args)
/*      */     throws Exception
/*      */   {
/* 1492 */     long startTime = Util.now();
/* 1493 */     OutputStream out = null;
/*      */     try
/*      */     {
/* 1496 */       init(parseArgs(args));
/*      */ 
/* 1501 */       out = checkAndMarkRunningBalancer();
/* 1502 */       if (out == null) {
/* 1503 */         System.out.println("Another balancer is running. Exiting...");
/* 1504 */         return -1;
/*      */       }
/*      */ 
/* 1507 */       Formatter formatter = new Formatter(System.out);
/* 1508 */       System.out.println("Time Stamp               Iteration#  Bytes Already Moved  Bytes Left To Move  Bytes Being Moved");
/* 1509 */       iterations = 0;
/*      */       while (true)
/*      */       {
/* 1513 */         resetData();
/*      */ 
/* 1518 */         long bytesLeftToMove = initNodes();
/* 1519 */         if (bytesLeftToMove == 0L) {
/* 1520 */           System.out.println("The cluster is balanced. Exiting...");
/* 1521 */           return 1;
/*      */         }
/* 1523 */         LOG.info(new StringBuilder().append("Need to move ").append(StringUtils.byteDesc(bytesLeftToMove)).append(" bytes to make the cluster balanced").toString());
/*      */ 
/* 1532 */         long bytesToMove = chooseNodes();
/*      */         int k;
/* 1533 */         if (bytesToMove == 0L) {
/* 1534 */           System.out.println("No block can be moved. Exiting...");
/* 1535 */           return -2;
/*      */         }
/* 1537 */         LOG.info(new StringBuilder().append("Will move ").append(StringUtils.byteDesc(bytesToMove)).append("bytes in this iteration").toString());
/*      */ 
/* 1541 */         formatter.format("%-24s %10d  %19s  %18s  %17s\n", new Object[] { DateFormat.getDateTimeInstance().format(new Date()), Integer.valueOf(iterations), StringUtils.byteDesc(this.bytesMoved.get()), StringUtils.byteDesc(bytesLeftToMove), StringUtils.byteDesc(bytesToMove) });
/*      */ 
/* 1555 */         if (dispatchBlockMoves() > 0L) {
/* 1556 */           this.notChangedIterations = 0;
/*      */         } else {
/* 1558 */           this.notChangedIterations += 1;
/* 1559 */           if (this.notChangedIterations >= 5) {
/* 1560 */             System.out.println("No block has been moved for 5 iterations. Exiting...");
/*      */ 
/* 1562 */             return -3;
/*      */           }
/*      */         }
/*      */         try
/*      */         {
/* 1567 */           Thread.sleep(2L * this.conf.getLong("dfs.heartbeat.interval", 3L));
/*      */         }
/*      */         catch (InterruptedException ignored) {
/*      */         }
/* 1571 */         iterations++;
/*      */       }
/*      */     } catch (IllegalArgumentException ae) {
/* 1574 */       return -5;
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/*      */       int iterations;
/* 1576 */       System.out.println(new StringBuilder().append("Received an IO exception: ").append(e.getMessage()).append(" . Exiting...").toString());
/*      */ 
/* 1578 */       return -4;
/*      */     }
/*      */     finally {
/* 1581 */       this.dispatcherExecutor.shutdownNow();
/* 1582 */       this.moverExecutor.shutdownNow();
/*      */ 
/* 1584 */       this.shouldRun = false;
/*      */       try {
/* 1586 */         if (this.keyupdaterthread != null) this.keyupdaterthread.interrupt(); 
/*      */       }
/* 1588 */       catch (Exception e) { LOG.warn("Exception shutting down access key updater thread", e); }
/*      */ 
/*      */ 
/* 1591 */       IOUtils.closeStream(out);
/* 1592 */       if (this.fs != null)
/*      */         try {
/* 1594 */           this.fs.delete(this.BALANCER_ID_PATH, true);
/*      */         }
/*      */         catch (IOException ignored) {
/*      */         }
/* 1598 */       System.out.println(new StringBuilder().append("Balancing took ").append(time2Str(Util.now() - startTime)).toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   private OutputStream checkAndMarkRunningBalancer()
/*      */     throws IOException
/*      */   {
/*      */     try
/*      */     {
/* 1620 */       DataOutputStream out = this.fs.create(this.BALANCER_ID_PATH);
/* 1621 */       out.writeBytes(InetAddress.getLocalHost().getHostName());
/* 1622 */       out.flush();
/* 1623 */       return out;
/*      */     } catch (RemoteException e) {
/* 1625 */       if (AlreadyBeingCreatedException.class.getName().equals(e.getClassName())) {
/* 1626 */         return null;
/*      */       }
/* 1628 */       throw e;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static String time2Str(long elapsedTime)
/*      */   {
/* 1636 */     double time = elapsedTime;
/*      */     String unit;
/*      */     String unit;
/* 1637 */     if (elapsedTime < 1000L) {
/* 1638 */       unit = "milliseconds";
/* 1639 */     } else if (elapsedTime < 60000L) {
/* 1640 */       String unit = "seconds";
/* 1641 */       time /= 1000.0D;
/* 1642 */     } else if (elapsedTime < 3600000L) {
/* 1643 */       String unit = "minutes";
/* 1644 */       time /= 60000.0D;
/*      */     } else {
/* 1646 */       unit = "hours";
/* 1647 */       time /= 3600000.0D;
/*      */     }
/*      */ 
/* 1650 */     return new StringBuilder().append(time).append(" ").append(unit).toString();
/*      */   }
/*      */ 
/*      */   public Configuration getConf()
/*      */   {
/* 1655 */     return this.conf;
/*      */   }
/*      */ 
/*      */   public void setConf(Configuration conf)
/*      */   {
/* 1660 */     this.conf = conf;
/* 1661 */     this.cluster = NetworkTopology.getInstance(conf);
/* 1662 */     this.movedBlocks.setWinWidth(conf);
/*      */   }
/*      */ 
/*      */   private static class MovedBlocks
/*      */   {
/* 1305 */     private long lastCleanupTime = System.currentTimeMillis();
/* 1306 */     private static long winWidth = 5400000L;
/*      */     private static final int CUR_WIN = 0;
/*      */     private static final int OLD_WIN = 1;
/*      */     private static final int NUM_WINS = 2;
/* 1310 */     private final List<HashMap<Block, Balancer.BalancerBlock>> movedBlocks = new ArrayList(2);
/*      */ 
/*      */     private MovedBlocks()
/*      */     {
/* 1315 */       this.movedBlocks.add(new HashMap());
/* 1316 */       this.movedBlocks.add(new HashMap());
/*      */     }
/*      */ 
/*      */     private void setWinWidth(Configuration conf)
/*      */     {
/* 1321 */       winWidth = conf.getLong("dfs.balancer.movedWinWidth", 5400000L);
/*      */     }
/*      */ 
/*      */     private synchronized void add(Balancer.BalancerBlock block)
/*      */     {
/* 1327 */       ((HashMap)this.movedBlocks.get(0)).put(Balancer.BalancerBlock.access$1300(block), block);
/*      */     }
/*      */ 
/*      */     private synchronized boolean contains(Balancer.BalancerBlock block)
/*      */     {
/* 1332 */       return contains(Balancer.BalancerBlock.access$1300(block));
/*      */     }
/*      */ 
/*      */     private synchronized boolean contains(Block block)
/*      */     {
/* 1337 */       return (((HashMap)this.movedBlocks.get(0)).containsKey(block)) || (((HashMap)this.movedBlocks.get(1)).containsKey(block));
/*      */     }
/*      */ 
/*      */     private synchronized void cleanup()
/*      */     {
/* 1343 */       long curTime = System.currentTimeMillis();
/*      */ 
/* 1345 */       if (this.lastCleanupTime + winWidth <= curTime)
/*      */       {
/* 1347 */         this.movedBlocks.set(1, this.movedBlocks.get(0));
/* 1348 */         this.movedBlocks.set(0, new HashMap());
/* 1349 */         this.lastCleanupTime = curTime;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class BytesMoved
/*      */   {
/* 1227 */     private long bytesMoved = 0L;
/*      */ 
/* 1229 */     private synchronized void inc(long bytes) { this.bytesMoved += bytes; }
/*      */ 
/*      */     private long get()
/*      */     {
/* 1233 */       return this.bytesMoved;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static abstract interface Matcher
/*      */   {
/*      */     public abstract boolean match(NetworkTopology paramNetworkTopology, Node paramNode1, Node paramNode2);
/*      */   }
/*      */ 
/*      */   class BlockKeyUpdater
/*      */     implements Runnable
/*      */   {
/*      */     BlockKeyUpdater()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/*  920 */       while (Balancer.this.shouldRun) {
/*      */         try {
/*  922 */           Balancer.this.blockTokenSecretManager.setKeys(Balancer.this.namenode.getBlockKeys());
/*      */         } catch (Exception e) {
/*  924 */           Balancer.LOG.error(StringUtils.stringifyException(e));
/*      */         }
/*      */         try {
/*  927 */           Thread.sleep(Balancer.this.keyUpdaterInterval);
/*      */         }
/*      */         catch (InterruptedException ie)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private class Source extends Balancer.BalancerDatanode
/*      */   {
/*  612 */     private ArrayList<Balancer.NodeTask> nodeTasks = new ArrayList(2);
/*  613 */     private long blocksToReceive = 0L;
/*      */ 
/*  618 */     private List<Balancer.BalancerBlock> srcBlockList = new ArrayList();
/*      */     private static final int SOURCE_BLOCK_LIST_MIN_SIZE = 5;
/*      */     private static final long MAX_ITERATION_TIME = 1200000L;
/*      */ 
/*      */     private Source(DatanodeInfo node, double avgUtil, double threshold)
/*      */     {
/*  623 */       super(avgUtil, threshold, null);
/*      */     }
/*      */ 
/*      */     private void addNodeTask(Balancer.NodeTask task)
/*      */     {
/*  629 */       assert (Balancer.NodeTask.access$2500(task) != this) : ("Source and target are the same " + this.datanode.getName());
/*  630 */       incScheduledSize(Balancer.NodeTask.access$2600(task));
/*  631 */       this.nodeTasks.add(task);
/*      */     }
/*      */ 
/*      */     private Iterator<Balancer.BalancerBlock> getBlockIterator()
/*      */     {
/*  636 */       return this.srcBlockList.iterator();
/*      */     }
/*      */ 
/*      */     private long getBlockList()
/*      */       throws IOException
/*      */     {
/*  644 */       BlocksWithLocations.BlockWithLocations[] newBlocks = Balancer.this.namenode.getBlocks(this.datanode, Math.min(2147483648L, this.blocksToReceive)).getBlocks();
/*      */ 
/*  646 */       long bytesReceived = 0L;
/*  647 */       for (BlocksWithLocations.BlockWithLocations blk : newBlocks) {
/*  648 */         bytesReceived += blk.getBlock().getNumBytes();
/*      */ 
/*  650 */         synchronized (Balancer.this.globalBlockList) {
/*  651 */           Balancer.BalancerBlock block = (Balancer.BalancerBlock)Balancer.this.globalBlockList.get(blk.getBlock());
/*  652 */           if (block == null) {
/*  653 */             block = new Balancer.BalancerBlock(blk.getBlock(), null);
/*  654 */             Balancer.this.globalBlockList.put(blk.getBlock(), block);
/*      */           } else {
/*  656 */             Balancer.BalancerBlock.access$3000(block);
/*      */           }
/*      */ 
/*  659 */           synchronized (block)
/*      */           {
/*  661 */             for (String location : blk.getDatanodes()) {
/*  662 */               Balancer.BalancerDatanode datanode = (Balancer.BalancerDatanode)Balancer.this.datanodes.get(location);
/*  663 */               if (datanode != null) {
/*  664 */                 Balancer.BalancerBlock.access$3200(block, datanode);
/*      */               }
/*      */             }
/*      */           }
/*  668 */           if ((!this.srcBlockList.contains(block)) && (isGoodBlockCandidate(block)))
/*      */           {
/*  670 */             this.srcBlockList.add(block);
/*      */           }
/*      */         }
/*      */       }
/*  674 */       return bytesReceived;
/*      */     }
/*      */ 
/*      */     private boolean isGoodBlockCandidate(Balancer.BalancerBlock block)
/*      */     {
/*  679 */       for (Balancer.NodeTask nodeTask : this.nodeTasks) {
/*  680 */         if (Balancer.this.isGoodBlockCandidate(this, Balancer.NodeTask.access$2500(nodeTask), block)) {
/*  681 */           return true;
/*      */         }
/*      */       }
/*  684 */       return false;
/*      */     }
/*      */ 
/*      */     private Balancer.PendingBlockMove chooseNextBlockToMove()
/*      */     {
/*  695 */       for (Iterator tasks = this.nodeTasks.iterator(); tasks.hasNext(); ) {
/*  696 */         Balancer.NodeTask task = (Balancer.NodeTask)tasks.next();
/*  697 */         Balancer.BalancerDatanode target = Balancer.NodeTask.access$3300(task);
/*  698 */         Balancer.PendingBlockMove pendingBlock = new Balancer.PendingBlockMove(Balancer.this, null);
/*  699 */         if (Balancer.BalancerDatanode.access$1000(target, pendingBlock))
/*      */         {
/*  701 */           Balancer.PendingBlockMove.access$3502(pendingBlock, this);
/*  702 */           Balancer.PendingBlockMove.access$1902(pendingBlock, target);
/*  703 */           if (Balancer.PendingBlockMove.access$3600(pendingBlock)) {
/*  704 */             long blockSize = Balancer.BalancerBlock.access$700(Balancer.PendingBlockMove.access$1700(pendingBlock));
/*  705 */             this.scheduledSize -= blockSize;
/*  706 */             Balancer.NodeTask.access$3722(task, blockSize);
/*  707 */             if (Balancer.NodeTask.access$3700(task) == 0L) {
/*  708 */               tasks.remove();
/*      */             }
/*  710 */             return pendingBlock;
/*      */           }
/*      */ 
/*  713 */           Balancer.BalancerDatanode.access$1400(target, pendingBlock);
/*      */         }
/*      */       }
/*      */ 
/*  717 */       return null;
/*      */     }
/*      */ 
/*      */     private void filterMovedBlocks()
/*      */     {
/*  722 */       Iterator blocks = getBlockIterator();
/*  723 */       while (blocks.hasNext())
/*  724 */         if (Balancer.this.movedBlocks.contains((Balancer.BalancerBlock)blocks.next()))
/*  725 */           blocks.remove();
/*      */     }
/*      */ 
/*      */     private boolean shouldFetchMoreBlocks()
/*      */     {
/*  733 */       return (this.srcBlockList.size() < 5) && (this.blocksToReceive > 0L);
/*      */     }
/*      */ 
/*      */     private void dispatchBlocks()
/*      */     {
/*  748 */       long startTime = Util.now();
/*  749 */       this.blocksToReceive = (2L * this.scheduledSize);
/*  750 */       boolean isTimeUp = false;
/*  751 */       int noPendingBlockIteration = 0;
/*  752 */       while ((!isTimeUp) && (this.scheduledSize > 0L) && ((!this.srcBlockList.isEmpty()) || (this.blocksToReceive > 0L)))
/*      */       {
/*  754 */         Balancer.PendingBlockMove pendingBlock = chooseNextBlockToMove();
/*  755 */         if (pendingBlock != null)
/*      */         {
/*  757 */           Balancer.PendingBlockMove.access$3900(pendingBlock);
/*      */         }
/*      */         else
/*      */         {
/*  765 */           filterMovedBlocks();
/*  766 */           if (shouldFetchMoreBlocks())
/*      */           {
/*      */             try {
/*  769 */               this.blocksToReceive -= getBlockList();
/*      */             }
/*      */             catch (IOException e) {
/*  772 */               Balancer.LOG.warn(StringUtils.stringifyException(e));
/*  773 */               return;
/*      */             }
/*      */           }
/*      */           else {
/*  777 */             noPendingBlockIteration++;
/*      */ 
/*  780 */             if (noPendingBlockIteration >= 5) {
/*  781 */               this.scheduledSize = 0L;
/*      */             }
/*      */ 
/*  786 */             if (Util.now() - startTime > 1200000L) {
/*  787 */               isTimeUp = true;
/*      */             }
/*      */             else
/*      */             {
/*      */               try
/*      */               {
/*  795 */                 synchronized (Balancer.this) {
/*  796 */                   Balancer.this.wait(1000L);
/*      */                 }
/*      */               }
/*      */               catch (InterruptedException ignored)
/*      */               {
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     private class BlockMoveDispatcher
/*      */       implements Runnable
/*      */     {
/*      */       private BlockMoveDispatcher()
/*      */       {
/*      */       }
/*      */ 
/*      */       public void run()
/*      */       {
/*  608 */         Balancer.Source.this.dispatchBlocks();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class BalancerDatanode
/*      */     implements Writable
/*      */   {
/*      */     private static final long MAX_SIZE_TO_MOVE = 10737418240L;
/*      */     protected DatanodeInfo datanode;
/*      */     private double utilization;
/*      */     protected long maxSizeToMove;
/*  505 */     protected long scheduledSize = 0L;
/*      */ 
/*  507 */     private List<Balancer.PendingBlockMove> pendingBlocks = new ArrayList(5);
/*      */ 
/*      */     private BalancerDatanode(DatanodeInfo node, double avgUtil, double threshold)
/*      */     {
/*  515 */       this.datanode = node;
/*  516 */       this.utilization = Balancer.getUtilization(node);
/*      */ 
/*  518 */       if ((this.utilization >= avgUtil + threshold) || (this.utilization <= avgUtil - threshold))
/*      */       {
/*  520 */         this.maxSizeToMove = ()(threshold * this.datanode.getCapacity() / 100.0D);
/*      */       }
/*  522 */       else this.maxSizeToMove = ()(Math.abs(avgUtil - this.utilization) * this.datanode.getCapacity() / 100.0D);
/*      */ 
/*  525 */       if (this.utilization < avgUtil) {
/*  526 */         this.maxSizeToMove = Math.min(this.datanode.getRemaining(), this.maxSizeToMove);
/*      */       }
/*  528 */       this.maxSizeToMove = Math.min(10737418240L, this.maxSizeToMove);
/*      */     }
/*      */ 
/*      */     protected DatanodeInfo getDatanode()
/*      */     {
/*  533 */       return this.datanode;
/*      */     }
/*      */ 
/*      */     protected String getName()
/*      */     {
/*  538 */       return this.datanode.getName();
/*      */     }
/*      */ 
/*      */     protected String getStorageID()
/*      */     {
/*  543 */       return this.datanode.getStorageID();
/*      */     }
/*      */ 
/*      */     protected boolean hasSpaceForScheduling()
/*      */     {
/*  548 */       return this.scheduledSize < this.maxSizeToMove;
/*      */     }
/*      */ 
/*      */     protected long availableSizeToMove()
/*      */     {
/*  553 */       return this.maxSizeToMove - this.scheduledSize;
/*      */     }
/*      */ 
/*      */     protected void incScheduledSize(long size)
/*      */     {
/*  558 */       this.scheduledSize += size;
/*      */     }
/*      */ 
/*      */     private synchronized boolean isPendingQNotFull()
/*      */     {
/*  563 */       if (this.pendingBlocks.size() < 5) {
/*  564 */         return true;
/*      */       }
/*  566 */       return false;
/*      */     }
/*      */ 
/*      */     private synchronized boolean isPendingQEmpty()
/*      */     {
/*  571 */       return this.pendingBlocks.isEmpty();
/*      */     }
/*      */ 
/*      */     private synchronized boolean addPendingBlock(Balancer.PendingBlockMove pendingBlock)
/*      */     {
/*  577 */       if (isPendingQNotFull()) {
/*  578 */         return this.pendingBlocks.add(pendingBlock);
/*      */       }
/*  580 */       return false;
/*      */     }
/*      */ 
/*      */     private synchronized boolean removePendingBlock(Balancer.PendingBlockMove pendingBlock)
/*      */     {
/*  586 */       return this.pendingBlocks.remove(pendingBlock);
/*      */     }
/*      */ 
/*      */     public void readFields(DataInput in)
/*      */       throws IOException
/*      */     {
/*  592 */       this.datanode.readFields(in);
/*      */     }
/*      */ 
/*      */     public void write(DataOutput out) throws IOException
/*      */     {
/*  597 */       this.datanode.write(out);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class NodeTask
/*      */   {
/*      */     private Balancer.BalancerDatanode datanode;
/*      */     private long size;
/*      */ 
/*      */     private NodeTask(Balancer.BalancerDatanode datanode, long size)
/*      */     {
/*  479 */       this.datanode = datanode;
/*  480 */       this.size = size;
/*      */     }
/*      */ 
/*      */     private Balancer.BalancerDatanode getDatanode()
/*      */     {
/*  485 */       return this.datanode;
/*      */     }
/*      */ 
/*      */     private long getSize()
/*      */     {
/*  490 */       return this.size;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class BalancerBlock
/*      */   {
/*      */     private Block block;
/*  422 */     private List<Balancer.BalancerDatanode> locations = new ArrayList(3);
/*      */ 
/*      */     private BalancerBlock(Block block)
/*      */     {
/*  427 */       this.block = block;
/*      */     }
/*      */ 
/*      */     private synchronized void clearLocations()
/*      */     {
/*  432 */       this.locations.clear();
/*      */     }
/*      */ 
/*      */     private synchronized void addLocation(Balancer.BalancerDatanode datanode)
/*      */     {
/*  437 */       if (!this.locations.contains(datanode))
/*  438 */         this.locations.add(datanode);
/*      */     }
/*      */ 
/*      */     private synchronized boolean isLocatedOnDatanode(Balancer.BalancerDatanode datanode)
/*      */     {
/*  445 */       return this.locations.contains(datanode);
/*      */     }
/*      */ 
/*      */     private synchronized List<Balancer.BalancerDatanode> getLocations()
/*      */     {
/*  450 */       return this.locations;
/*      */     }
/*      */ 
/*      */     private Block getBlock()
/*      */     {
/*  455 */       return this.block;
/*      */     }
/*      */ 
/*      */     private long getBlockId()
/*      */     {
/*  460 */       return this.block.getBlockId();
/*      */     }
/*      */ 
/*      */     private long getNumBytes()
/*      */     {
/*  465 */       return this.block.getNumBytes();
/*      */     }
/*      */   }
/*      */ 
/*      */   private class PendingBlockMove
/*      */   {
/*      */     private Balancer.BalancerBlock block;
/*      */     private Balancer.Source source;
/*      */     private Balancer.BalancerDatanode proxySource;
/*      */     private Balancer.BalancerDatanode target;
/*      */ 
/*      */     private PendingBlockMove()
/*      */     {
/*      */     }
/*      */ 
/*      */     private boolean chooseBlockAndProxy()
/*      */     {
/*  261 */       Iterator blocks = this.source.getBlockIterator();
/*  262 */       while (blocks.hasNext()) {
/*  263 */         if (markMovedIfGoodBlock((Balancer.BalancerBlock)blocks.next())) {
/*  264 */           blocks.remove();
/*  265 */           return true;
/*      */         }
/*      */       }
/*  268 */       return false;
/*      */     }
/*      */ 
/*      */     private boolean markMovedIfGoodBlock(Balancer.BalancerBlock block)
/*      */     {
/*  278 */       synchronized (block) {
/*  279 */         synchronized (Balancer.this.movedBlocks) {
/*  280 */           if (Balancer.this.isGoodBlockCandidate(this.source, this.target, block)) {
/*  281 */             this.block = block;
/*  282 */             if (chooseProxySource()) {
/*  283 */               Balancer.this.movedBlocks.add(block);
/*  284 */               if (Balancer.LOG.isDebugEnabled()) {
/*  285 */                 Balancer.LOG.debug("Decided to move block " + block.getBlockId() + " with a length of " + StringUtils.byteDesc(block.getNumBytes()) + " bytes from " + this.source.getName() + " to " + this.target.getName() + " using proxy source " + this.proxySource.getName());
/*      */               }
/*      */ 
/*  291 */               return true;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*  296 */       return false;
/*      */     }
/*      */ 
/*      */     private boolean chooseProxySource()
/*      */     {
/*  305 */       for (Balancer.BalancerDatanode loc : this.block.getLocations()) {
/*  306 */         if ((Balancer.this.cluster.isOnSameRack(loc.getDatanode(), this.target.getDatanode())) && 
/*  307 */           (loc.addPendingBlock(this))) {
/*  308 */           this.proxySource = loc;
/*  309 */           return true;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  314 */       for (Balancer.BalancerDatanode loc : this.block.getLocations()) {
/*  315 */         if (loc.addPendingBlock(this)) {
/*  316 */           this.proxySource = loc;
/*  317 */           return true;
/*      */         }
/*      */       }
/*  320 */       return false;
/*      */     }
/*      */ 
/*      */     private void dispatch()
/*      */     {
/*  326 */       Socket sock = new Socket();
/*  327 */       DataOutputStream out = null;
/*  328 */       DataInputStream in = null;
/*      */       try {
/*  330 */         sock.connect(NetUtils.createSocketAddr(this.target.datanode.getName()), 60000);
/*      */ 
/*  332 */         sock.setKeepAlive(true);
/*  333 */         out = new DataOutputStream(new BufferedOutputStream(sock.getOutputStream(), FSConstants.BUFFER_SIZE));
/*      */ 
/*  335 */         sendRequest(out);
/*  336 */         in = new DataInputStream(new BufferedInputStream(sock.getInputStream(), FSConstants.BUFFER_SIZE));
/*      */ 
/*  338 */         receiveResponse(in);
/*  339 */         Balancer.this.bytesMoved.inc(Balancer.BalancerBlock.access$700(this.block));
/*  340 */         Balancer.LOG.info("Moving block " + this.block.getBlock().getBlockId() + " from " + this.source.getName() + " to " + this.target.getName() + " through " + this.proxySource.getName() + " is succeeded.");
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/*  345 */         Balancer.LOG.warn("Error moving block " + this.block.getBlockId() + " from " + this.source.getName() + " to " + this.target.getName() + " through " + this.proxySource.getName() + ": " + e.getMessage());
/*      */       }
/*      */       finally
/*      */       {
/*  351 */         IOUtils.closeStream(out);
/*  352 */         IOUtils.closeStream(in);
/*  353 */         IOUtils.closeSocket(sock);
/*      */ 
/*  355 */         this.proxySource.removePendingBlock(this);
/*  356 */         synchronized (this.target) {
/*  357 */           this.target.removePendingBlock(this);
/*      */         }
/*      */ 
/*  360 */         synchronized (this) {
/*  361 */           reset();
/*      */         }
/*  363 */         synchronized (Balancer.this) {
/*  364 */           Balancer.this.notifyAll();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     private void sendRequest(DataOutputStream out) throws IOException
/*      */     {
/*  371 */       out.writeShort(17);
/*  372 */       out.writeByte(83);
/*  373 */       out.writeLong(this.block.getBlock().getBlockId());
/*  374 */       out.writeLong(this.block.getBlock().getGenerationStamp());
/*  375 */       Text.writeString(out, this.source.getStorageID());
/*  376 */       this.proxySource.write(out);
/*  377 */       Token accessToken = BlockTokenSecretManager.DUMMY_TOKEN;
/*  378 */       if (Balancer.this.isBlockTokenEnabled) {
/*  379 */         accessToken = Balancer.this.blockTokenSecretManager.generateToken(null, this.block.getBlock(), EnumSet.of(BlockTokenSecretManager.AccessMode.REPLACE, BlockTokenSecretManager.AccessMode.COPY));
/*      */       }
/*      */ 
/*  383 */       accessToken.write(out);
/*  384 */       out.flush();
/*      */     }
/*      */ 
/*      */     private void receiveResponse(DataInputStream in) throws IOException
/*      */     {
/*  389 */       short status = in.readShort();
/*  390 */       if (status != 0) {
/*  391 */         if (status == 5)
/*  392 */           throw new IOException("block move failed due to access token error");
/*  393 */         throw new IOException("block move is failed");
/*      */       }
/*      */     }
/*      */ 
/*      */     private void reset()
/*      */     {
/*  399 */       this.block = null;
/*  400 */       this.source = null;
/*  401 */       this.proxySource = null;
/*  402 */       this.target = null;
/*      */     }
/*      */ 
/*      */     private void scheduleBlockMove()
/*      */     {
/*  407 */       Balancer.this.moverExecutor.execute(new Runnable() {
/*      */         public void run() {
/*  409 */           if (Balancer.LOG.isDebugEnabled()) {
/*  410 */             Balancer.LOG.debug("Starting moving " + Balancer.PendingBlockMove.this.block.getBlockId() + " from " + Balancer.PendingBlockMove.this.proxySource.getName() + " to " + Balancer.PendingBlockMove.this.target.getName());
/*      */           }
/*      */ 
/*  413 */           Balancer.PendingBlockMove.this.dispatch();
/*      */         }
/*      */       });
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.balancer.Balancer
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs.server.datanode;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.jsp.JspFactory;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.SkipPageException;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.hdfs.DFSClient;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.hdfs.protocol.ClientProtocol;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlock;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlocks;
/*     */ import org.apache.hadoop.hdfs.server.namenode.JspHelper;
/*     */ import org.apache.hadoop.http.HtmlQuoting;
/*     */ import org.apache.hadoop.net.NetUtils;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.token.Token;
/*     */ import org.apache.hadoop.util.ServletUtil;
/*     */ import org.apache.jasper.runtime.HttpJspBase;
/*     */ import org.apache.jasper.runtime.JspSourceDependent;
/*     */ import org.apache.jasper.runtime.ResourceInjector;
/*     */ 
/*     */ public final class tail_jsp extends HttpJspBase
/*     */   implements JspSourceDependent
/*     */ {
/*  46 */   static JspHelper jspHelper = new JspHelper();
/*     */ 
/* 138 */   private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();
/*     */   private static Vector _jspx_dependants;
/*     */   private ResourceInjector _jspx_resourceInjector;
/*     */ 
/*     */   public void generateFileChunks(JspWriter out, HttpServletRequest req, Configuration conf)
/*     */     throws IOException, InterruptedException
/*     */   {
/*  51 */     long startOffset = 0L;
/*     */ 
/*  53 */     int chunkSizeToView = 0;
/*  54 */     String tokenString = req.getParameter("delegation");
/*  55 */     String referrer = req.getParameter("referrer");
/*  56 */     boolean noLink = false;
/*  57 */     if (referrer == null) {
/*  58 */       noLink = true;
/*     */     }
/*     */ 
/*  61 */     String filename = HtmlQuoting.unquoteHtmlChars(req.getParameter("filename"));
/*  62 */     if (filename == null) {
/*  63 */       out.print("Invalid input (file name absent)");
/*  64 */       return;
/*     */     }
/*     */ 
/*  67 */     String namenodeInfoPortStr = req.getParameter("namenodeInfoPort");
/*  68 */     int namenodeInfoPort = -1;
/*  69 */     if (namenodeInfoPortStr != null) {
/*  70 */       namenodeInfoPort = Integer.parseInt(namenodeInfoPortStr);
/*     */     }
/*  72 */     String chunkSizeToViewStr = req.getParameter("chunkSizeToView");
/*  73 */     if ((chunkSizeToViewStr != null) && (Integer.parseInt(chunkSizeToViewStr) > 0))
/*  74 */       chunkSizeToView = Integer.parseInt(chunkSizeToViewStr);
/*  75 */     else chunkSizeToView = JspHelper.getDefaultChunkSize(conf);
/*     */ 
/*  77 */     if (!noLink) {
/*  78 */       out.print("<h3>Tail of File: ");
/*  79 */       JspHelper.printPathWithLinks(HtmlQuoting.quoteHtmlChars(filename), out, namenodeInfoPort, tokenString);
/*     */ 
/*  81 */       out.print("</h3><hr>");
/*  82 */       out.print("<a href=\"" + referrer + "\">Go Back to File View</a><hr>");
/*     */     }
/*     */     else {
/*  85 */       out.print("<h3>" + HtmlQuoting.quoteHtmlChars(filename) + "</h3>");
/*     */     }
/*  87 */     out.print("<b>Chunk size to view (in bytes, up to file's DFS block size): </b>");
/*  88 */     out.print("<input type=\"text\" name=\"chunkSizeToView\" value=" + chunkSizeToView + " size=10 maxlength=10>");
/*     */ 
/*  90 */     out.print("&nbsp;&nbsp;<input type=\"submit\" name=\"submit\" value=\"Refresh\"><hr>");
/*  91 */     out.print("<input type=\"hidden\" name=\"filename\" value=\"" + HtmlQuoting.quoteHtmlChars(filename) + "\">");
/*     */ 
/*  93 */     out.print("<input type=\"hidden\" name=\"namenodeInfoPort\" value=\"" + namenodeInfoPort + "\">");
/*     */ 
/*  95 */     if (!noLink) {
/*  96 */       out.print("<input type=\"hidden\" name=\"referrer\" value=\"" + referrer + "\">");
/*     */     }
/*     */ 
/* 100 */     UserGroupInformation ugi = JspHelper.getUGI(req, conf);
/* 101 */     DFSClient dfs = JspHelper.getDFSClient(ugi, JspHelper.nameNodeAddr, conf);
/* 102 */     List blocks = dfs.namenode.getBlockLocations(filename, 0L, 9223372036854775807L).getLocatedBlocks();
/*     */ 
/* 105 */     if ((blocks == null) || (blocks.size() == 0)) {
/* 106 */       out.print("No datanodes contain blocks of file " + filename);
/* 107 */       dfs.close();
/* 108 */       return; } LocatedBlock lastBlk = (LocatedBlock)blocks.get(blocks.size() - 1);
/* 111 */     long blockSize = lastBlk.getBlock().getNumBytes();
/* 112 */     long blockId = lastBlk.getBlock().getBlockId();
/* 113 */     Token accessToken = lastBlk.getBlockToken();
/* 114 */     long genStamp = lastBlk.getBlock().getGenerationStamp();
/*     */     DatanodeInfo chosenNode;
/*     */     try { chosenNode = JspHelper.bestNode(lastBlk);
/*     */     } catch (IOException e) {
/* 119 */       out.print(e.toString());
/* 120 */       dfs.close();
/* 121 */       return;
/*     */     }
/* 123 */     InetSocketAddress addr = NetUtils.createSocketAddr(chosenNode.getName());
/*     */ 
/* 125 */     if (blockSize >= chunkSizeToView)
/* 126 */       startOffset = blockSize - chunkSizeToView;
/* 127 */     else startOffset = 0L;
/*     */ 
/* 129 */     out.print("<textarea cols=\"100\" rows=\"25\" wrap=\"virtual\" style=\"width:100%\" READONLY>");
/* 130 */     jspHelper.streamBlockInAscii(addr, blockId, accessToken, genStamp, blockSize, startOffset, chunkSizeToView, out, conf);
/*     */ 
/* 133 */     out.print("</textarea>");
/* 134 */     dfs.close();
/*     */   }
/*     */ 
/*     */   public Object getDependants()
/*     */   {
/* 145 */     return _jspx_dependants;
/*     */   }
/*     */ 
/*     */   public void _jspService(HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException, ServletException
/*     */   {
/* 151 */     PageContext pageContext = null;
/* 152 */     HttpSession session = null;
/* 153 */     ServletContext application = null;
/* 154 */     ServletConfig config = null;
/* 155 */     JspWriter out = null;
/* 156 */     Object page = this;
/* 157 */     JspWriter _jspx_out = null;
/* 158 */     PageContext _jspx_page_context = null;
/*     */     try
/*     */     {
/* 161 */       response.setContentType("text/html; charset=UTF-8");
/* 162 */       pageContext = _jspxFactory.getPageContext(this, request, response, null, true, 8192, true);
/*     */ 
/* 164 */       _jspx_page_context = pageContext;
/* 165 */       application = pageContext.getServletContext();
/* 166 */       config = pageContext.getServletConfig();
/* 167 */       session = pageContext.getSession();
/* 168 */       out = pageContext.getOut();
/* 169 */       _jspx_out = out;
/* 170 */       this._jspx_resourceInjector = ((ResourceInjector)application.getAttribute("com.sun.appserv.jsp.resource.injector"));
/*     */ 
/* 172 */       out.write("\n\n\n");
/* 173 */       out.write("\n\n\n\n<!DOCTYPE html>\n<html>\n<head>\n");
/* 174 */       JspHelper.createTitle(out, request, request.getParameter("filename"));
/* 175 */       out.write("\n</head>\n<body>\n<form action=\"/tail.jsp\" method=\"GET\">\n");
/*     */ 
/* 177 */       Configuration conf = (Configuration)application.getAttribute("current.conf");
/*     */ 
/* 179 */       generateFileChunks(out, request, conf);
/*     */ 
/* 181 */       out.write("\n</form>\n<hr>\n\n<h2>Local logs</h2>\n<a href=\"/logs/\">Log</a> directory\n\n");
/*     */ 
/* 183 */       out.println(ServletUtil.htmlFooter());
/*     */ 
/* 185 */       out.write(10);
/*     */     } catch (Throwable t) {
/* 187 */       if (!(t instanceof SkipPageException)) {
/* 188 */         out = _jspx_out;
/* 189 */         if ((out != null) && (out.getBufferSize() != 0))
/* 190 */           out.clearBuffer();
/* 191 */         if (_jspx_page_context != null) _jspx_page_context.handlePageException(t); 
/*     */       }
/*     */     }
/* 194 */     finally { _jspxFactory.releasePageContext(_jspx_page_context); }
/*     */ 
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.tail_jsp
 * JD-Core Version:    0.6.1
 */
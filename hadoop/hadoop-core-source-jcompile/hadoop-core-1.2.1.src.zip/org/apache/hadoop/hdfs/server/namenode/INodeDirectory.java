/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.fs.permission.FsAction;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.fs.permission.PermissionStatus;
/*     */ import org.apache.hadoop.hdfs.DFSUtil;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ 
/*     */ class INodeDirectory extends INode
/*     */ {
/*     */   protected static final int DEFAULT_FILES_PER_DIRECTORY = 5;
/*     */   static final String ROOT_NAME = "";
/*     */   private List<INode> children;
/*     */ 
/*     */   INodeDirectory(String name, PermissionStatus permissions)
/*     */   {
/*  41 */     super(name, permissions);
/*  42 */     this.children = null;
/*     */   }
/*     */ 
/*     */   public INodeDirectory(PermissionStatus permissions, long mTime) {
/*  46 */     super(permissions, mTime, 0L);
/*  47 */     this.children = null;
/*     */   }
/*     */ 
/*     */   INodeDirectory(byte[] localName, PermissionStatus permissions, long mTime)
/*     */   {
/*  52 */     this(permissions, mTime);
/*  53 */     this.name = localName;
/*     */   }
/*     */ 
/*     */   INodeDirectory(INodeDirectory other)
/*     */   {
/*  61 */     super(other);
/*  62 */     this.children = other.getChildren();
/*     */   }
/*     */ 
/*     */   public boolean isDirectory()
/*     */   {
/*  69 */     return true;
/*     */   }
/*     */ 
/*     */   INode removeChild(INode node) {
/*  73 */     assert (this.children != null);
/*  74 */     int low = Collections.binarySearch(this.children, node.name);
/*  75 */     if (low >= 0) {
/*  76 */       return (INode)this.children.remove(low);
/*     */     }
/*  78 */     return null;
/*     */   }
/*     */ 
/*     */   void replaceChild(INode newChild)
/*     */   {
/*  87 */     if (this.children == null) {
/*  88 */       throw new IllegalArgumentException("The directory is empty");
/*     */     }
/*  90 */     int low = Collections.binarySearch(this.children, newChild.name);
/*  91 */     if (low >= 0)
/*  92 */       this.children.set(low, newChild);
/*     */     else
/*  94 */       throw new IllegalArgumentException("No child exists to be replaced");
/*     */   }
/*     */ 
/*     */   INode getChild(String name)
/*     */   {
/*  99 */     return getChildINode(DFSUtil.string2Bytes(name));
/*     */   }
/*     */ 
/*     */   private INode getChildINode(byte[] name) {
/* 103 */     if (this.children == null) {
/* 104 */       return null;
/*     */     }
/* 106 */     int low = Collections.binarySearch(this.children, name);
/* 107 */     if (low >= 0) {
/* 108 */       return (INode)this.children.get(low);
/*     */     }
/* 110 */     return null;
/*     */   }
/*     */ 
/*     */   private INode getNode(byte[][] components)
/*     */   {
/* 116 */     INode[] inode = new INode[1];
/* 117 */     getExistingPathINodes(components, inode);
/* 118 */     return inode[0];
/*     */   }
/*     */ 
/*     */   INode getNode(String path)
/*     */   {
/* 125 */     return getNode(getPathComponents(path));
/*     */   }
/*     */ 
/*     */   int getExistingPathINodes(byte[][] components, INode[] existing)
/*     */   {
/* 164 */     assert (compareBytes(this.name, components[0]) == 0) : ("Incorrect name " + getLocalName() + " expected " + components[0]);
/*     */ 
/* 166 */     INode curNode = this;
/* 167 */     int count = 0;
/* 168 */     int index = existing.length - components.length;
/* 169 */     if (index > 0)
/* 170 */       index = 0;
/* 171 */     while ((count < components.length) && (curNode != null)) {
/* 172 */       if (index >= 0)
/* 173 */         existing[index] = curNode;
/* 174 */       if ((!curNode.isDirectory()) || (count == components.length - 1))
/*     */         break;
/* 176 */       INodeDirectory parentDir = (INodeDirectory)curNode;
/* 177 */       curNode = parentDir.getChildINode(components[(count + 1)]);
/* 178 */       count++;
/* 179 */       index++;
/*     */     }
/* 181 */     return count;
/*     */   }
/*     */ 
/*     */   INode[] getExistingPathINodes(String path)
/*     */   {
/* 198 */     byte[][] components = getPathComponents(path);
/* 199 */     INode[] inodes = new INode[components.length];
/*     */ 
/* 201 */     getExistingPathINodes(components, inodes);
/*     */ 
/* 203 */     return inodes;
/*     */   }
/*     */ 
/*     */   <T extends INode> T addChild(T node, boolean inheritPermission)
/*     */   {
/* 215 */     if (inheritPermission) {
/* 216 */       FsPermission p = getFsPermission();
/*     */ 
/* 218 */       if (!p.getUserAction().implies(FsAction.WRITE_EXECUTE)) {
/* 219 */         p = new FsPermission(p.getUserAction().or(FsAction.WRITE_EXECUTE), p.getGroupAction(), p.getOtherAction());
/*     */       }
/*     */ 
/* 222 */       node.setPermission(p);
/*     */     }
/*     */ 
/* 225 */     if (this.children == null) {
/* 226 */       this.children = new ArrayList(5);
/*     */     }
/* 228 */     int low = Collections.binarySearch(this.children, node.name);
/* 229 */     if (low >= 0)
/* 230 */       return null;
/* 231 */     node.parent = this;
/* 232 */     this.children.add(-low - 1, node);
/*     */ 
/* 234 */     setModificationTime(node.getModificationTime());
/* 235 */     if (node.getGroupName() == null) {
/* 236 */       node.setGroup(getGroupName());
/*     */     }
/* 238 */     return node;
/*     */   }
/*     */ 
/*     */   int nextChild(byte[] name)
/*     */   {
/* 248 */     if (name.length == 0) {
/* 249 */       return 0;
/*     */     }
/* 251 */     int nextPos = Collections.binarySearch(this.children, name) + 1;
/* 252 */     if (nextPos >= 0) {
/* 253 */       return nextPos;
/*     */     }
/* 255 */     return -nextPos;
/*     */   }
/*     */ 
/*     */   <T extends INode> T addNode(String path, T newNode)
/*     */     throws FileNotFoundException
/*     */   {
/* 263 */     return addNode(path, newNode, false);
/*     */   }
/*     */ 
/*     */   <T extends INode> T addNode(String path, T newNode, boolean inheritPermission)
/*     */     throws FileNotFoundException
/*     */   {
/* 278 */     if (addToParent(path, newNode, null, inheritPermission) == null)
/* 279 */       return null;
/* 280 */     return newNode;
/*     */   }
/*     */ 
/*     */   <T extends INode> INodeDirectory addToParent(String path, T newNode, INodeDirectory parent, boolean inheritPermission)
/*     */     throws FileNotFoundException
/*     */   {
/* 298 */     byte[][] pathComponents = getPathComponents(path);
/* 299 */     assert (pathComponents != null) : ("Incorrect path " + path);
/* 300 */     int pathLen = pathComponents.length;
/* 301 */     if (pathLen < 2)
/* 302 */       return null;
/* 303 */     if (parent == null)
/*     */     {
/* 305 */       INode[] inodes = new INode[2];
/* 306 */       getExistingPathINodes(pathComponents, inodes);
/* 307 */       INode inode = inodes[0];
/* 308 */       if (inode == null) {
/* 309 */         throw new FileNotFoundException("Parent path does not exist: " + path);
/*     */       }
/* 311 */       if (!inode.isDirectory()) {
/* 312 */         throw new FileNotFoundException("Parent path is not a directory: " + path);
/*     */       }
/* 314 */       parent = (INodeDirectory)inode;
/*     */     }
/*     */ 
/* 317 */     newNode.name = pathComponents[(pathLen - 1)];
/* 318 */     if (parent.addChild(newNode, inheritPermission) == null)
/* 319 */       return null;
/* 320 */     return parent;
/*     */   }
/*     */ 
/*     */   INode.DirCounts spaceConsumedInTree(INode.DirCounts counts)
/*     */   {
/* 325 */     counts.nsCount += 1L;
/* 326 */     if (this.children != null) {
/* 327 */       for (INode child : this.children) {
/* 328 */         child.spaceConsumedInTree(counts);
/*     */       }
/*     */     }
/* 331 */     return counts;
/*     */   }
/*     */ 
/*     */   long[] computeContentSummary(long[] summary)
/*     */   {
/* 338 */     assert (4 == summary.length);
/* 339 */     long[] subtreeSummary = { 0L, 0L, 0L, 0L };
/* 340 */     if (this.children != null) {
/* 341 */       for (INode child : this.children) {
/* 342 */         child.computeContentSummary(subtreeSummary);
/*     */       }
/*     */     }
/* 345 */     if ((this instanceof INodeDirectoryWithQuota))
/*     */     {
/* 347 */       INodeDirectoryWithQuota node = (INodeDirectoryWithQuota)this;
/* 348 */       long space = node.diskspaceConsumed();
/* 349 */       assert ((-1L == node.getDsQuota()) || (space == subtreeSummary[3]));
/* 350 */       if ((-1L != node.getDsQuota()) && (space != subtreeSummary[3])) {
/* 351 */         NameNode.LOG.warn("Inconsistent diskspace for directory " + getLocalName() + ". Cached: " + space + " Computed: " + subtreeSummary[3]);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 357 */     for (int i = 0; i < summary.length; i++) {
/* 358 */       summary[i] += subtreeSummary[i];
/*     */     }
/*     */ 
/* 361 */     summary[2] += 1L;
/* 362 */     return summary;
/*     */   }
/*     */ 
/*     */   List<INode> getChildren()
/*     */   {
/* 368 */     return this.children == null ? new ArrayList() : this.children;
/*     */   }
/*     */   List<INode> getChildrenRaw() {
/* 371 */     return this.children;
/*     */   }
/*     */ 
/*     */   int collectSubtreeBlocksAndClear(List<Block> v) {
/* 375 */     int total = 1;
/* 376 */     if (this.children == null) {
/* 377 */       return total;
/*     */     }
/* 379 */     for (INode child : this.children) {
/* 380 */       total += child.collectSubtreeBlocksAndClear(v);
/*     */     }
/* 382 */     this.parent = null;
/* 383 */     this.children = null;
/* 384 */     return total;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.INodeDirectory
 * JD-Core Version:    0.6.1
 */
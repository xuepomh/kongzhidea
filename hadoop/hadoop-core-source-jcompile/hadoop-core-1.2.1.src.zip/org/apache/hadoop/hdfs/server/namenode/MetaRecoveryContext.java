/*    */ package org.apache.hadoop.hdfs.server.namenode;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public final class MetaRecoveryContext
/*    */ {
/* 28 */   public static final Log LOG = LogFactory.getLog(MetaRecoveryContext.class.getName());
/*    */   private int force;
/*    */   public static final int FORCE_NONE = 0;
/*    */   public static final int FORCE_FIRST_CHOICE = 1;
/*    */   public static final int FORCE_ALL = 2;
/*    */ 
/*    */   public MetaRecoveryContext(int force)
/*    */   {
/* 35 */     this.force = force;
/*    */   }
/*    */ 
/*    */   public String ask(String prompt, String firstChoice, String[] choices)
/*    */     throws IOException
/*    */   {
/*    */     while (true)
/*    */     {
/* 49 */       LOG.error(prompt);
/* 50 */       if (this.force > 0) {
/* 51 */         LOG.info(new StringBuilder().append("Automatically choosing ").append(firstChoice).toString());
/* 52 */         return firstChoice;
/*    */       }
/* 54 */       StringBuilder responseBuilder = new StringBuilder();
/*    */       while (true) {
/* 56 */         int c = System.in.read();
/* 57 */         if ((c == -1) || (c == 13) || (c == 10)) {
/*    */           break;
/*    */         }
/* 60 */         responseBuilder.append((char)c);
/*    */       }
/* 62 */       String response = responseBuilder.toString();
/* 63 */       if (response.equalsIgnoreCase(firstChoice)) {
/* 64 */         return firstChoice;
/*    */       }
/* 66 */       for (String c : choices) {
/* 67 */         if (response.equalsIgnoreCase(c)) {
/* 68 */           return c;
/*    */         }
/*    */       }
/* 71 */       LOG.error("I'm sorry, I cannot understand your response.\n");
/*    */     }
/*    */   }
/*    */ 
/*    */   public void quit() {
/* 76 */     LOG.error("Exiting on user request.");
/* 77 */     System.exit(0);
/*    */   }
/*    */ 
/*    */   public static void editLogLoaderPrompt(String prompt, MetaRecoveryContext recovery)
/*    */     throws IOException
/*    */   {
/* 83 */     if (recovery == null) {
/* 84 */       throw new IOException(prompt);
/*    */     }
/* 86 */     LOG.error(prompt);
/* 87 */     String answer = recovery.ask("\nEnter 's' to stop reading the edit log here, abandoning any later edits.\nEnter 'q' to quit without saving.\n(s/q)", "s", new String[] { "q" });
/*    */ 
/* 92 */     if (answer.equals("s")) {
/* 93 */       LOG.error("We will stop reading the edits log here.  NOTE: Some edits have been lost!");
/*    */ 
/* 95 */       return;
/* 96 */     }if (answer.equals("q"))
/* 97 */       recovery.quit();
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.MetaRecoveryContext
 * JD-Core Version:    0.6.1
 */
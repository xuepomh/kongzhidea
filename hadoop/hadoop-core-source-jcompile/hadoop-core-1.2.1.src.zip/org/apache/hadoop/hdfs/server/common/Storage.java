/*     */ package org.apache.hadoop.hdfs.server.common;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileDescriptor;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.channels.FileLock;
/*     */ import java.nio.channels.OverlappingFileLockException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.fs.FileUtil;
/*     */ import org.apache.hadoop.io.UTF8;
/*     */ 
/*     */ public abstract class Storage extends StorageInfo
/*     */ {
/*  58 */   public static final Log LOG = LogFactory.getLog(Storage.class.getName());
/*     */   protected static final int LAST_PRE_UPGRADE_LAYOUT_VERSION = -3;
/*     */   public static final int LAST_UPGRADABLE_LAYOUT_VERSION = -7;
/*     */   protected static final String LAST_UPGRADABLE_HADOOP_VERSION = "Hadoop-0.14";
/*     */   public static final int PRE_GENERATIONSTAMP_LAYOUT_VERSION = -13;
/*  74 */   public static final int[] LAYOUT_VERSIONS_203 = { -19, -31 };
/*     */   private static final String STORAGE_FILE_LOCK = "in_use.lock";
/*     */   protected static final String STORAGE_FILE_VERSION = "VERSION";
/*     */   public static final String STORAGE_DIR_CURRENT = "current";
/*     */   private static final String STORAGE_DIR_PREVIOUS = "previous";
/*     */   private static final String STORAGE_TMP_REMOVED = "removed.tmp";
/*     */   private static final String STORAGE_TMP_PREVIOUS = "previous.tmp";
/*     */   private static final String STORAGE_TMP_FINALIZED = "finalized.tmp";
/*     */   private static final String STORAGE_TMP_LAST_CKPT = "lastcheckpoint.tmp";
/*     */   private static final String STORAGE_PREVIOUS_CKPT = "previous.checkpoint";
/*     */   private HdfsConstants.NodeType storageType;
/* 110 */   protected List<StorageDirectory> storageDirs = new ArrayList();
/*     */ 
/*     */   public Iterator<StorageDirectory> dirIterator()
/*     */   {
/* 164 */     return dirIterator(null);
/*     */   }
/*     */ 
/*     */   public Iterator<StorageDirectory> dirIterator(StorageDirType dirType)
/*     */   {
/* 173 */     return new DirIterator(dirType);
/*     */   }
/*     */ 
/*     */   protected Storage(HdfsConstants.NodeType type)
/*     */   {
/* 657 */     this.storageType = type;
/*     */   }
/*     */ 
/*     */   protected Storage(HdfsConstants.NodeType type, int nsID, long cT) {
/* 661 */     super(-41, nsID, cT);
/* 662 */     this.storageType = type;
/*     */   }
/*     */ 
/*     */   protected Storage(HdfsConstants.NodeType type, StorageInfo storageInfo) {
/* 666 */     super(storageInfo);
/* 667 */     this.storageType = type;
/*     */   }
/*     */ 
/*     */   public int getNumStorageDirs() {
/* 671 */     return this.storageDirs.size();
/*     */   }
/*     */ 
/*     */   public StorageDirectory getStorageDir(int idx) {
/* 675 */     return (StorageDirectory)this.storageDirs.get(idx);
/*     */   }
/*     */ 
/*     */   protected void addStorageDir(StorageDirectory sd) {
/* 679 */     this.storageDirs.add(sd);
/*     */   }
/*     */ 
/*     */   public abstract boolean isConversionNeeded(StorageDirectory paramStorageDirectory)
/*     */     throws IOException;
/*     */ 
/*     */   private void checkConversionNeeded(StorageDirectory sd)
/*     */     throws IOException
/*     */   {
/* 689 */     if (isConversionNeeded(sd))
/*     */     {
/* 691 */       checkVersionUpgradable(0);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static void checkVersionUpgradable(int oldVersion)
/*     */     throws IOException
/*     */   {
/* 703 */     if (oldVersion > -7) {
/* 704 */       String msg = new StringBuilder().append("*********** Upgrade is not supported from this older version of storage to the current version. Please upgrade to Hadoop-0.14 or a later version and then upgrade to current version. Old layout version is ").append(oldVersion == 0 ? "'too old'" : new StringBuilder().append("").append(oldVersion).toString()).append(" and latest layout version this software version can").append(" upgrade from is ").append(-7).append(". ************").toString();
/*     */ 
/* 713 */       LOG.error(msg);
/* 714 */       throw new IOException(msg);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void getFields(Properties props, StorageDirectory sd)
/*     */     throws IOException
/*     */   {
/* 730 */     String sv = props.getProperty("layoutVersion");
/* 731 */     String st = props.getProperty("storageType");
/* 732 */     String sid = props.getProperty("namespaceID");
/* 733 */     String sct = props.getProperty("cTime");
/* 734 */     if ((sv == null) || (st == null) || (sid == null) || (sct == null)) {
/* 735 */       throw new InconsistentFSStateException(sd.root, "file VERSION is invalid.");
/*     */     }
/* 737 */     int rv = Integer.parseInt(sv);
/* 738 */     HdfsConstants.NodeType rt = HdfsConstants.NodeType.valueOf(st);
/* 739 */     int rid = Integer.parseInt(sid);
/* 740 */     long rct = Long.parseLong(sct);
/* 741 */     if ((!this.storageType.equals(rt)) || ((this.namespaceID != 0) && (rid != 0) && (this.namespaceID != rid)))
/*     */     {
/* 743 */       throw new InconsistentFSStateException(sd.root, "is incompatible with others.");
/*     */     }
/* 745 */     if (rv < -41) {
/* 746 */       throw new IncorrectVersionException(rv, new StringBuilder().append("storage directory ").append(sd.root.getCanonicalPath()).toString());
/*     */     }
/* 748 */     this.layoutVersion = rv;
/* 749 */     this.storageType = rt;
/* 750 */     this.namespaceID = rid;
/* 751 */     this.cTime = rct;
/*     */   }
/*     */ 
/*     */   protected void setFields(Properties props, StorageDirectory sd)
/*     */     throws IOException
/*     */   {
/* 764 */     props.setProperty("layoutVersion", String.valueOf(this.layoutVersion));
/* 765 */     props.setProperty("storageType", this.storageType.toString());
/* 766 */     props.setProperty("namespaceID", String.valueOf(this.namespaceID));
/* 767 */     props.setProperty("cTime", String.valueOf(this.cTime));
/*     */   }
/*     */ 
/*     */   public static void rename(File from, File to) throws IOException {
/* 771 */     if (!from.renameTo(to))
/* 772 */       throw new IOException(new StringBuilder().append("Failed to rename ").append(from.getCanonicalPath()).append(" to ").append(to.getCanonicalPath()).toString());
/*     */   }
/*     */ 
/*     */   protected static void deleteDir(File dir) throws IOException
/*     */   {
/* 777 */     if (!FileUtil.fullyDelete(dir))
/* 778 */       throw new IOException(new StringBuilder().append("Failed to delete ").append(dir.getCanonicalPath()).toString());
/*     */   }
/*     */ 
/*     */   public void writeAll()
/*     */     throws IOException
/*     */   {
/* 786 */     this.layoutVersion = -41;
/* 787 */     for (Iterator it = this.storageDirs.iterator(); it.hasNext(); )
/* 788 */       ((StorageDirectory)it.next()).write();
/*     */   }
/*     */ 
/*     */   public void unlockAll()
/*     */     throws IOException
/*     */   {
/* 797 */     for (Iterator it = this.storageDirs.iterator(); it.hasNext(); )
/* 798 */       ((StorageDirectory)it.next()).unlock();
/*     */   }
/*     */ 
/*     */   public boolean isLockSupported(int idx)
/*     */     throws IOException
/*     */   {
/* 811 */     StorageDirectory sd = (StorageDirectory)this.storageDirs.get(idx);
/* 812 */     FileLock firstLock = null;
/* 813 */     FileLock secondLock = null;
/*     */     try {
/* 815 */       firstLock = sd.lock;
/*     */       boolean bool;
/* 816 */       if (firstLock == null) {
/* 817 */         firstLock = sd.tryLock();
/* 818 */         if (firstLock == null)
/* 819 */           return true;
/*     */       }
/* 821 */       secondLock = sd.tryLock();
/* 822 */       if (secondLock == null)
/* 823 */         return true;
/*     */     } finally {
/* 825 */       if ((firstLock != null) && (firstLock != sd.lock)) {
/* 826 */         firstLock.release();
/* 827 */         firstLock.channel().close();
/*     */       }
/* 829 */       if (secondLock != null) {
/* 830 */         secondLock.release();
/* 831 */         secondLock.channel().close();
/*     */       }
/*     */     }
/* 834 */     return false;
/*     */   }
/*     */ 
/*     */   public static String getRegistrationID(StorageInfo storage) {
/* 838 */     return new StringBuilder().append("NS-").append(Integer.toString(storage.getNamespaceID())).append("-").append(Integer.toString(storage.getLayoutVersion())).append("-").append(Long.toString(storage.getCTime())).toString();
/*     */   }
/*     */ 
/*     */   protected abstract void corruptPreUpgradeStorage(File paramFile)
/*     */     throws IOException;
/*     */ 
/*     */   protected void writeCorruptedData(RandomAccessFile file)
/*     */     throws IOException
/*     */   {
/* 847 */     String messageForPreUpgradeVersion = "\nThis file is INTENTIONALLY CORRUPTED so that versions\nof Hadoop prior to 0.13 (which are incompatible\nwith this directory layout) will fail to start.\n";
/*     */ 
/* 852 */     file.seek(0L);
/* 853 */     file.writeInt(-41);
/* 854 */     UTF8.writeString(file, "");
/* 855 */     file.writeBytes("\nThis file is INTENTIONALLY CORRUPTED so that versions\nof Hadoop prior to 0.13 (which are incompatible\nwith this directory layout) will fail to start.\n");
/* 856 */     file.getFD().sync();
/*     */   }
/*     */ 
/*     */   public static boolean is203LayoutVersion(int layoutVersion) {
/* 860 */     for (int lv : LAYOUT_VERSIONS_203) {
/* 861 */       if (lv == layoutVersion) {
/* 862 */         return true;
/*     */       }
/*     */     }
/* 865 */     return false;
/*     */   }
/*     */ 
/*     */   public class StorageDirectory
/*     */   {
/*     */     File root;
/*     */     FileLock lock;
/*     */     Storage.StorageDirType dirType;
/*     */ 
/*     */     public StorageDirectory(File dir)
/*     */     {
/* 186 */       this(dir, null);
/*     */     }
/*     */ 
/*     */     public StorageDirectory(File dir, Storage.StorageDirType dirType) {
/* 190 */       this.root = dir;
/* 191 */       this.lock = null;
/* 192 */       this.dirType = dirType;
/*     */     }
/*     */ 
/*     */     public File getRoot()
/*     */     {
/* 199 */       return this.root;
/*     */     }
/*     */ 
/*     */     public Storage.StorageDirType getStorageDirType()
/*     */     {
/* 206 */       return this.dirType;
/*     */     }
/*     */ 
/*     */     public void read()
/*     */       throws IOException
/*     */     {
/* 215 */       read(getVersionFile());
/*     */     }
/*     */ 
/*     */     public void read(File from) throws IOException {
/* 219 */       RandomAccessFile file = new RandomAccessFile(from, "rws");
/* 220 */       FileInputStream in = null;
/*     */       try {
/* 222 */         in = new FileInputStream(file.getFD());
/* 223 */         file.seek(0L);
/* 224 */         Properties props = new Properties();
/* 225 */         props.load(in);
/* 226 */         Storage.this.getFields(props, this);
/*     */       } finally {
/* 228 */         if (in != null) {
/* 229 */           in.close();
/*     */         }
/* 231 */         file.close();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void write()
/*     */       throws IOException
/*     */     {
/* 241 */       Storage.this.corruptPreUpgradeStorage(this.root);
/* 242 */       write(getVersionFile());
/*     */     }
/*     */ 
/*     */     public void write(File to) throws IOException {
/* 246 */       Properties props = new Properties();
/* 247 */       Storage.this.setFields(props, this);
/* 248 */       RandomAccessFile file = new RandomAccessFile(to, "rws");
/* 249 */       FileOutputStream out = null;
/*     */       try {
/* 251 */         file.seek(0L);
/* 252 */         out = new FileOutputStream(file.getFD());
/*     */ 
/* 257 */         props.store(out, null);
/*     */ 
/* 266 */         file.setLength(out.getChannel().position());
/*     */       } finally {
/* 268 */         if (out != null) {
/* 269 */           out.close();
/*     */         }
/* 271 */         file.close();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void clearDirectory()
/*     */       throws IOException
/*     */     {
/* 289 */       File curDir = getCurrentDir();
/* 290 */       if ((curDir.exists()) && 
/* 291 */         (!FileUtil.fullyDelete(curDir)))
/* 292 */         throw new IOException("Cannot remove current directory: " + curDir);
/* 293 */       if (!curDir.mkdirs())
/* 294 */         throw new IOException("Cannot create directory " + curDir);
/*     */     }
/*     */ 
/*     */     public File getCurrentDir()
/*     */     {
/* 304 */       return new File(this.root, "current");
/*     */     }
/*     */ 
/*     */     public File getVersionFile()
/*     */     {
/* 324 */       return new File(new File(this.root, "current"), "VERSION");
/*     */     }
/*     */ 
/*     */     public File getPreviousVersionFile()
/*     */     {
/* 333 */       return new File(new File(this.root, "previous"), "VERSION");
/*     */     }
/*     */ 
/*     */     public File getPreviousDir()
/*     */     {
/* 343 */       return new File(this.root, "previous");
/*     */     }
/*     */ 
/*     */     public File getPreviousTmp()
/*     */     {
/* 357 */       return new File(this.root, "previous.tmp");
/*     */     }
/*     */ 
/*     */     public File getRemovedTmp()
/*     */     {
/* 371 */       return new File(this.root, "removed.tmp");
/*     */     }
/*     */ 
/*     */     public File getFinalizedTmp()
/*     */     {
/* 384 */       return new File(this.root, "finalized.tmp");
/*     */     }
/*     */ 
/*     */     public File getLastCheckpointTmp()
/*     */     {
/* 398 */       return new File(this.root, "lastcheckpoint.tmp");
/*     */     }
/*     */ 
/*     */     public File getPreviousCheckpoint()
/*     */     {
/* 411 */       return new File(this.root, "previous.checkpoint");
/*     */     }
/*     */ 
/*     */     public Storage.StorageState analyzeStorage(HdfsConstants.StartupOption startOpt)
/*     */       throws IOException
/*     */     {
/* 425 */       assert (this.root != null) : "root is null";
/* 426 */       String rootPath = this.root.getCanonicalPath();
/*     */       try {
/* 428 */         if (!this.root.exists())
/*     */         {
/* 430 */           if (startOpt != HdfsConstants.StartupOption.FORMAT) {
/* 431 */             Storage.LOG.info("Storage directory " + rootPath + " does not exist");
/* 432 */             return Storage.StorageState.NON_EXISTENT;
/*     */           }
/* 434 */           Storage.LOG.info(rootPath + " does not exist. Creating...");
/* 435 */           if (!this.root.mkdirs()) {
/* 436 */             throw new IOException("Cannot create directory " + rootPath);
/*     */           }
/*     */         }
/* 439 */         if (!this.root.isDirectory()) {
/* 440 */           Storage.LOG.info(rootPath + "is not a directory");
/* 441 */           return Storage.StorageState.NON_EXISTENT;
/*     */         }
/* 443 */         if (!this.root.canWrite()) {
/* 444 */           Storage.LOG.info("Cannot access storage directory " + rootPath);
/* 445 */           return Storage.StorageState.NON_EXISTENT;
/*     */         }
/*     */       } catch (SecurityException ex) {
/* 448 */         Storage.LOG.info("Cannot access storage directory " + rootPath, ex);
/* 449 */         return Storage.StorageState.NON_EXISTENT;
/*     */       }
/*     */ 
/* 452 */       lock();
/*     */ 
/* 454 */       if (startOpt == HdfsConstants.StartupOption.FORMAT)
/* 455 */         return Storage.StorageState.NOT_FORMATTED;
/* 456 */       if (startOpt != HdfsConstants.StartupOption.IMPORT)
/*     */       {
/* 458 */         Storage.this.checkConversionNeeded(this);
/*     */       }
/*     */ 
/* 462 */       File versionFile = getVersionFile();
/* 463 */       boolean hasCurrent = versionFile.exists();
/*     */ 
/* 466 */       boolean hasPrevious = getPreviousDir().exists();
/* 467 */       boolean hasPreviousTmp = getPreviousTmp().exists();
/* 468 */       boolean hasRemovedTmp = getRemovedTmp().exists();
/* 469 */       boolean hasFinalizedTmp = getFinalizedTmp().exists();
/* 470 */       boolean hasCheckpointTmp = getLastCheckpointTmp().exists();
/*     */ 
/* 472 */       if ((!hasPreviousTmp) && (!hasRemovedTmp) && (!hasFinalizedTmp) && (!hasCheckpointTmp))
/*     */       {
/* 475 */         if (hasCurrent)
/* 476 */           return Storage.StorageState.NORMAL;
/* 477 */         if (hasPrevious) {
/* 478 */           throw new InconsistentFSStateException(this.root, "version file in current directory is missing.");
/*     */         }
/* 480 */         return Storage.StorageState.NOT_FORMATTED;
/*     */       }
/*     */ 
/* 483 */       if ((hasPreviousTmp ? 1 : 0) + (hasRemovedTmp ? 1 : 0) + (hasFinalizedTmp ? 1 : 0) + (hasCheckpointTmp ? 1 : 0) > 1)
/*     */       {
/* 486 */         throw new InconsistentFSStateException(this.root, "too many temporary directories.");
/*     */       }
/*     */ 
/* 490 */       if (hasCheckpointTmp) {
/* 491 */         return hasCurrent ? Storage.StorageState.COMPLETE_CHECKPOINT : Storage.StorageState.RECOVER_CHECKPOINT;
/*     */       }
/*     */ 
/* 495 */       if (hasFinalizedTmp) {
/* 496 */         if (hasPrevious) {
/* 497 */           throw new InconsistentFSStateException(this.root, "previous and finalized.tmpcannot exist together.");
/*     */         }
/*     */ 
/* 500 */         return Storage.StorageState.COMPLETE_FINALIZE;
/*     */       }
/*     */ 
/* 503 */       if (hasPreviousTmp) {
/* 504 */         if (hasPrevious) {
/* 505 */           throw new InconsistentFSStateException(this.root, "previous and previous.tmp cannot exist together.");
/*     */         }
/*     */ 
/* 508 */         if (hasCurrent)
/* 509 */           return Storage.StorageState.COMPLETE_UPGRADE;
/* 510 */         return Storage.StorageState.RECOVER_UPGRADE;
/*     */       }
/*     */ 
/* 513 */       assert (hasRemovedTmp) : "hasRemovedTmp must be true";
/* 514 */       if (!(hasCurrent ^ hasPrevious)) {
/* 515 */         throw new InconsistentFSStateException(this.root, "one and only one directory current or previous must be present when removed.tmp exists.");
/*     */       }
/*     */ 
/* 520 */       if (hasCurrent)
/* 521 */         return Storage.StorageState.COMPLETE_ROLLBACK;
/* 522 */       return Storage.StorageState.RECOVER_ROLLBACK;
/*     */     }
/*     */ 
/*     */     public void doRecover(Storage.StorageState curState)
/*     */       throws IOException
/*     */     {
/* 532 */       File curDir = getCurrentDir();
/* 533 */       String rootPath = this.root.getCanonicalPath();
/* 534 */       switch (Storage.1.$SwitchMap$org$apache$hadoop$hdfs$server$common$Storage$StorageState[curState.ordinal()]) {
/*     */       case 1:
/* 536 */         Storage.LOG.info("Completing previous upgrade for storage directory " + rootPath);
/*     */ 
/* 538 */         Storage.rename(getPreviousTmp(), getPreviousDir());
/* 539 */         return;
/*     */       case 2:
/* 541 */         Storage.LOG.info("Recovering storage directory " + rootPath + " from previous upgrade");
/*     */ 
/* 543 */         if (curDir.exists())
/* 544 */           Storage.deleteDir(curDir);
/* 545 */         Storage.rename(getPreviousTmp(), curDir);
/* 546 */         return;
/*     */       case 3:
/* 548 */         Storage.LOG.info("Completing previous rollback for storage directory " + rootPath);
/*     */ 
/* 550 */         Storage.deleteDir(getRemovedTmp());
/* 551 */         return;
/*     */       case 4:
/* 553 */         Storage.LOG.info("Recovering storage directory " + rootPath + " from previous rollback");
/*     */ 
/* 555 */         Storage.rename(getRemovedTmp(), curDir);
/* 556 */         return;
/*     */       case 5:
/* 558 */         Storage.LOG.info("Completing previous finalize for storage directory " + rootPath);
/*     */ 
/* 560 */         Storage.deleteDir(getFinalizedTmp());
/* 561 */         return;
/*     */       case 6:
/* 563 */         Storage.LOG.info("Completing previous checkpoint for storage directory " + rootPath);
/*     */ 
/* 565 */         File prevCkptDir = getPreviousCheckpoint();
/* 566 */         if (prevCkptDir.exists())
/* 567 */           Storage.deleteDir(prevCkptDir);
/* 568 */         Storage.rename(getLastCheckpointTmp(), prevCkptDir);
/* 569 */         return;
/*     */       case 7:
/* 571 */         Storage.LOG.info("Recovering storage directory " + rootPath + " from failed checkpoint");
/*     */ 
/* 573 */         if (curDir.exists())
/* 574 */           Storage.deleteDir(curDir);
/* 575 */         Storage.rename(getLastCheckpointTmp(), curDir);
/* 576 */         return;
/*     */       }
/* 578 */       throw new IOException("Unexpected FS state: " + curState);
/*     */     }
/*     */ 
/*     */     public void lock()
/*     */       throws IOException
/*     */     {
/* 594 */       this.lock = tryLock();
/* 595 */       if (this.lock == null) {
/* 596 */         String msg = "Cannot lock storage " + this.root + ". The directory is already locked.";
/*     */ 
/* 598 */         Storage.LOG.info(msg);
/* 599 */         throw new IOException(msg);
/*     */       }
/*     */     }
/*     */ 
/*     */     FileLock tryLock()
/*     */       throws IOException
/*     */     {
/* 611 */       boolean deletionHookAdded = false;
/* 612 */       File lockF = new File(this.root, "in_use.lock");
/* 613 */       if (!lockF.exists()) {
/* 614 */         lockF.deleteOnExit();
/* 615 */         deletionHookAdded = true;
/*     */       }
/* 617 */       RandomAccessFile file = new RandomAccessFile(lockF, "rws");
/* 618 */       FileLock res = null;
/*     */       try {
/* 620 */         res = file.getChannel().tryLock();
/*     */       } catch (OverlappingFileLockException oe) {
/* 622 */         file.close();
/* 623 */         return null;
/*     */       } catch (IOException e) {
/* 625 */         Storage.LOG.error("Cannot create lock on " + lockF, e);
/* 626 */         file.close();
/* 627 */         throw e;
/*     */       }
/* 629 */       if ((res != null) && (!deletionHookAdded))
/*     */       {
/* 633 */         lockF.deleteOnExit();
/*     */       }
/* 635 */       return res;
/*     */     }
/*     */ 
/*     */     public void unlock()
/*     */       throws IOException
/*     */     {
/* 644 */       if (this.lock == null)
/* 645 */         return;
/* 646 */       this.lock.release();
/* 647 */       this.lock.channel().close();
/* 648 */       this.lock = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class DirIterator
/*     */     implements Iterator<Storage.StorageDirectory>
/*     */   {
/*     */     Storage.StorageDirType dirType;
/*     */     int prevIndex;
/*     */     int nextIndex;
/*     */ 
/*     */     DirIterator(Storage.StorageDirType dirType)
/*     */     {
/* 118 */       this.dirType = dirType;
/* 119 */       this.nextIndex = 0;
/* 120 */       this.prevIndex = 0;
/*     */     }
/*     */ 
/*     */     public boolean hasNext() {
/* 124 */       if ((Storage.this.storageDirs.isEmpty()) || (this.nextIndex >= Storage.this.storageDirs.size()))
/* 125 */         return false;
/* 126 */       if (this.dirType != null) {
/* 127 */         while ((this.nextIndex < Storage.this.storageDirs.size()) && 
/* 128 */           (!Storage.this.getStorageDir(this.nextIndex).getStorageDirType().isOfType(this.dirType)))
/*     */         {
/* 130 */           this.nextIndex += 1;
/*     */         }
/* 132 */         if (this.nextIndex >= Storage.this.storageDirs.size())
/* 133 */           return false;
/*     */       }
/* 135 */       return true;
/*     */     }
/*     */ 
/*     */     public Storage.StorageDirectory next() {
/* 139 */       Storage.StorageDirectory sd = Storage.this.getStorageDir(this.nextIndex);
/* 140 */       this.prevIndex = this.nextIndex;
/* 141 */       this.nextIndex += 1;
/* 142 */       if (this.dirType != null) {
/* 143 */         while ((this.nextIndex < Storage.this.storageDirs.size()) && 
/* 144 */           (!Storage.this.getStorageDir(this.nextIndex).getStorageDirType().isOfType(this.dirType)))
/*     */         {
/* 146 */           this.nextIndex += 1;
/*     */         }
/*     */       }
/* 149 */       return sd;
/*     */     }
/*     */ 
/*     */     public void remove() {
/* 153 */       this.nextIndex = this.prevIndex;
/* 154 */       Storage.this.storageDirs.remove(this.prevIndex);
/* 155 */       hasNext();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface StorageDirType
/*     */   {
/*     */     public abstract StorageDirType getStorageDirType();
/*     */ 
/*     */     public abstract boolean isOfType(StorageDirType paramStorageDirType);
/*     */   }
/*     */ 
/*     */   public static enum StorageState
/*     */   {
/*  87 */     NON_EXISTENT, 
/*  88 */     NOT_FORMATTED, 
/*  89 */     COMPLETE_UPGRADE, 
/*  90 */     RECOVER_UPGRADE, 
/*  91 */     COMPLETE_FINALIZE, 
/*  92 */     COMPLETE_ROLLBACK, 
/*  93 */     RECOVER_ROLLBACK, 
/*  94 */     COMPLETE_CHECKPOINT, 
/*  95 */     RECOVER_CHECKPOINT, 
/*  96 */     NORMAL;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.common.Storage
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.fs.permission.FsAction;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.security.AccessControlException;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ 
/*     */ class PermissionChecker
/*     */ {
/*  32 */   static final Log LOG = LogFactory.getLog(UserGroupInformation.class);
/*     */   private final UserGroupInformation ugi;
/*     */   final String user;
/*  36 */   private final Set<String> groups = new HashSet();
/*     */   final boolean isSuper;
/*     */ 
/*     */   PermissionChecker(String fsOwner, String supergroup)
/*     */     throws AccessControlException
/*     */   {
/*     */     try
/*     */     {
/*  42 */       this.ugi = UserGroupInformation.getCurrentUser();
/*     */     } catch (IOException e) {
/*  44 */       throw new AccessControlException(e);
/*     */     }
/*  46 */     if (LOG.isDebugEnabled()) {
/*  47 */       LOG.debug("ugi=" + this.ugi);
/*     */     }
/*     */ 
/*  50 */     this.user = this.ugi.getShortUserName();
/*  51 */     this.groups.addAll(Arrays.asList(this.ugi.getGroupNames()));
/*  52 */     this.isSuper = ((this.user.equals(fsOwner)) || (this.groups.contains(supergroup)));
/*     */   }
/*     */   boolean containsGroup(String group) {
/*  55 */     return this.groups.contains(group);
/*     */   }
/*     */ 
/*     */   public static void checkSuperuserPrivilege(UserGroupInformation owner, String supergroup)
/*     */     throws AccessControlException
/*     */   {
/*  66 */     PermissionChecker checker = new PermissionChecker(owner.getShortUserName(), supergroup);
/*     */ 
/*  68 */     if (!checker.isSuper)
/*  69 */       throw new AccessControlException("Access denied for user " + checker.user + ". Superuser privilege is required");
/*     */   }
/*     */ 
/*     */   void checkPermission(String path, INodeDirectory root, boolean doCheckOwner, FsAction ancestorAccess, FsAction parentAccess, FsAction access, FsAction subAccess)
/*     */     throws AccessControlException
/*     */   {
/* 106 */     if (LOG.isDebugEnabled()) {
/* 107 */       LOG.debug("ACCESS CHECK: " + this + ", doCheckOwner=" + doCheckOwner + ", ancestorAccess=" + ancestorAccess + ", parentAccess=" + parentAccess + ", access=" + access + ", subAccess=" + subAccess);
/*     */     }
/*     */ 
/* 115 */     synchronized (root) {
/* 116 */       INode[] inodes = root.getExistingPathINodes(path);
/* 117 */       int ancestorIndex = inodes.length - 2;
/* 118 */       while ((ancestorIndex >= 0) && (inodes[ancestorIndex] == null))
/* 119 */         ancestorIndex--;
/* 120 */       checkTraverse(inodes, ancestorIndex);
/*     */ 
/* 122 */       if ((ancestorAccess != null) && (inodes.length > 1)) {
/* 123 */         check(inodes, ancestorIndex, ancestorAccess);
/*     */       }
/* 125 */       if ((parentAccess != null) && (inodes.length > 1)) {
/* 126 */         check(inodes, inodes.length - 2, parentAccess);
/*     */       }
/* 128 */       if (access != null) {
/* 129 */         check(inodes[(inodes.length - 1)], access);
/*     */       }
/* 131 */       if (subAccess != null) {
/* 132 */         checkSubAccess(inodes[(inodes.length - 1)], subAccess);
/*     */       }
/* 134 */       if (doCheckOwner)
/* 135 */         checkOwner(inodes[(inodes.length - 1)]);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkOwner(INode inode) throws AccessControlException
/*     */   {
/* 141 */     if ((inode != null) && (this.user.equals(inode.getUserName()))) {
/* 142 */       return;
/*     */     }
/* 144 */     throw new AccessControlException("Permission denied");
/*     */   }
/*     */ 
/*     */   private void checkTraverse(INode[] inodes, int last) throws AccessControlException
/*     */   {
/* 149 */     for (int j = 0; j <= last; j++)
/* 150 */       check(inodes[j], FsAction.EXECUTE);
/*     */   }
/*     */ 
/*     */   private void checkSubAccess(INode inode, FsAction access)
/*     */     throws AccessControlException
/*     */   {
/* 156 */     if ((inode == null) || (!inode.isDirectory())) {
/* 157 */       return;
/*     */     }
/*     */ 
/* 160 */     Stack directories = new Stack();
/* 161 */     for (directories.push((INodeDirectory)inode); !directories.isEmpty(); ) {
/* 162 */       INodeDirectory d = (INodeDirectory)directories.pop();
/* 163 */       check(d, access);
/*     */ 
/* 165 */       for (INode child : d.getChildren())
/* 166 */         if (child.isDirectory())
/* 167 */           directories.push((INodeDirectory)child);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void check(INode[] inodes, int i, FsAction access)
/*     */     throws AccessControlException
/*     */   {
/* 175 */     check(i >= 0 ? inodes[i] : null, access);
/*     */   }
/*     */ 
/*     */   private void check(INode inode, FsAction access) throws AccessControlException
/*     */   {
/* 180 */     if (inode == null) {
/* 181 */       return;
/*     */     }
/* 183 */     FsPermission mode = inode.getFsPermission();
/*     */ 
/* 185 */     if (this.user.equals(inode.getUserName())) {
/* 186 */       if (!mode.getUserAction().implies(access));
/*     */     }
/* 188 */     else if (this.groups.contains(inode.getGroupName()))
/*     */     {
/* 189 */       if (!mode.getGroupAction().implies(access));
/*     */     }
/* 192 */     else if (mode.getOtherAction().implies(access)) return;
/*     */ 
/* 194 */     throw new AccessControlException("Permission denied: user=" + this.user + ", access=" + access + ", inode=" + inode);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.PermissionChecker
 * JD-Core Version:    0.6.1
 */
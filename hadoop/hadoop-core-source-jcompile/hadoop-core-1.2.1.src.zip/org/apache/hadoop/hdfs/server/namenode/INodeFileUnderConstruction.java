/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.fs.permission.PermissionStatus;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ 
/*     */ class INodeFileUnderConstruction extends INodeFile
/*     */ {
/*     */   String clientName;
/*     */   private final String clientMachine;
/*     */   private final DatanodeDescriptor clientNode;
/*  34 */   private int primaryNodeIndex = -1;
/*  35 */   private DatanodeDescriptor[] targets = null;
/*  36 */   private long lastRecoveryTime = 0L;
/*     */ 
/*     */   INodeFileUnderConstruction(PermissionStatus permissions, short replication, long preferredBlockSize, long modTime, String clientName, String clientMachine, DatanodeDescriptor clientNode)
/*     */   {
/*  45 */     super(permissions.applyUMask(UMASK), 0, replication, modTime, modTime, preferredBlockSize);
/*     */ 
/*  47 */     this.clientName = clientName;
/*  48 */     this.clientMachine = clientMachine;
/*  49 */     this.clientNode = clientNode;
/*     */   }
/*     */ 
/*     */   public INodeFileUnderConstruction(byte[] name, short blockReplication, long modificationTime, long preferredBlockSize, BlocksMap.BlockInfo[] blocks, PermissionStatus perm, String clientName, String clientMachine, DatanodeDescriptor clientNode)
/*     */   {
/*  61 */     super(perm, blocks, blockReplication, modificationTime, modificationTime, preferredBlockSize);
/*     */ 
/*  63 */     setLocalName(name);
/*  64 */     this.clientName = clientName;
/*  65 */     this.clientMachine = clientMachine;
/*  66 */     this.clientNode = clientNode;
/*     */   }
/*     */ 
/*     */   String getClientName() {
/*  70 */     return this.clientName;
/*     */   }
/*     */ 
/*     */   void setClientName(String newName) {
/*  74 */     this.clientName = newName;
/*     */   }
/*     */ 
/*     */   String getClientMachine() {
/*  78 */     return this.clientMachine;
/*     */   }
/*     */ 
/*     */   DatanodeDescriptor getClientNode() {
/*  82 */     return this.clientNode;
/*     */   }
/*     */ 
/*     */   boolean isUnderConstruction()
/*     */   {
/*  90 */     return true;
/*     */   }
/*     */ 
/*     */   DatanodeDescriptor[] getTargets() {
/*  94 */     return this.targets;
/*     */   }
/*     */ 
/*     */   void setTargets(DatanodeDescriptor[] targets) {
/*  98 */     this.targets = targets;
/*  99 */     this.primaryNodeIndex = -1;
/*     */   }
/*     */ 
/*     */   void addTarget(DatanodeDescriptor node)
/*     */   {
/* 106 */     if (this.targets == null) {
/* 107 */       this.targets = new DatanodeDescriptor[0];
/*     */     }
/*     */ 
/* 110 */     for (int j = 0; j < this.targets.length; j++) {
/* 111 */       if (this.targets[j].equals(node)) {
/* 112 */         return;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 117 */     DatanodeDescriptor[] newt = new DatanodeDescriptor[this.targets.length + 1];
/* 118 */     for (int i = 0; i < this.targets.length; i++) {
/* 119 */       newt[i] = this.targets[i];
/*     */     }
/* 121 */     newt[this.targets.length] = node;
/* 122 */     this.targets = newt;
/* 123 */     this.primaryNodeIndex = -1;
/*     */   }
/*     */ 
/*     */   INodeFile convertToInodeFile()
/*     */   {
/* 131 */     INodeFile obj = new INodeFile(getPermissionStatus(), getBlocks(), getReplication(), getModificationTime(), getModificationTime(), getPreferredBlockSize());
/*     */ 
/* 137 */     return obj;
/*     */   }
/*     */ 
/*     */   void removeBlock(Block oldblock)
/*     */     throws IOException
/*     */   {
/* 146 */     if (this.blocks == null) {
/* 147 */       throw new IOException("Trying to delete non-existant block " + oldblock);
/*     */     }
/* 149 */     int size_1 = this.blocks.length - 1;
/* 150 */     if (!this.blocks[size_1].equals(oldblock)) {
/* 151 */       throw new IOException("Trying to delete non-last block " + oldblock);
/*     */     }
/*     */ 
/* 155 */     BlocksMap.BlockInfo[] newlist = new BlocksMap.BlockInfo[size_1];
/* 156 */     System.arraycopy(this.blocks, 0, newlist, 0, size_1);
/* 157 */     this.blocks = newlist;
/*     */ 
/* 160 */     this.targets = null;
/*     */   }
/*     */ 
/*     */   synchronized void setLastBlock(BlocksMap.BlockInfo newblock, DatanodeDescriptor[] newtargets) throws IOException
/*     */   {
/* 165 */     if ((this.blocks == null) || (this.blocks.length == 0)) {
/* 166 */       throw new IOException("Trying to update non-existant block (newblock=" + newblock + ")");
/*     */     }
/*     */ 
/* 169 */     BlocksMap.BlockInfo oldLast = this.blocks[(this.blocks.length - 1)];
/* 170 */     if (oldLast.getBlockId() != newblock.getBlockId())
/*     */     {
/* 173 */       NameNode.stateChangeLog.error("Trying to commit block synchronization for an internal block on inode=" + this + " newblock=" + newblock + " oldLast=" + oldLast);
/*     */ 
/* 177 */       throw new IOException("Trying to update an internal block of pending file " + this);
/*     */     }
/*     */ 
/* 181 */     if (oldLast.getGenerationStamp() > newblock.getGenerationStamp()) {
/* 182 */       NameNode.stateChangeLog.warn("Updating last block " + oldLast + " of inode " + "under construction " + this + " with a block that " + "has an older generation stamp: " + newblock);
/*     */     }
/*     */ 
/* 188 */     this.blocks[(this.blocks.length - 1)] = newblock;
/* 189 */     setTargets(newtargets);
/* 190 */     this.lastRecoveryTime = 0L;
/*     */   }
/*     */ 
/*     */   void assignPrimaryDatanode()
/*     */   {
/* 199 */     if (this.targets.length == 0) {
/* 200 */       NameNode.stateChangeLog.warn("BLOCK* INodeFileUnderConstruction.initLeaseRecovery: No blocks found, lease removed.");
/*     */     }
/*     */ 
/* 205 */     int previous = this.primaryNodeIndex;
/*     */ 
/* 207 */     for (int i = 1; i <= this.targets.length; i++) {
/* 208 */       int j = (previous + i) % this.targets.length;
/* 209 */       if (this.targets[j].isAlive) {
/* 210 */         DatanodeDescriptor primary = this.targets[(this.primaryNodeIndex = j)];
/* 211 */         primary.addBlockToBeRecovered(this.blocks[(this.blocks.length - 1)], this.targets);
/* 212 */         NameNode.stateChangeLog.info("BLOCK* " + this.blocks[(this.blocks.length - 1)] + " recovery started, primary=" + primary);
/*     */ 
/* 214 */         return;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   synchronized boolean setLastRecoveryTime(long now)
/*     */   {
/* 224 */     boolean expired = now - this.lastRecoveryTime > 10000L;
/* 225 */     if (expired) {
/* 226 */       this.lastRecoveryTime = now;
/*     */     }
/* 228 */     return expired;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.INodeFileUnderConstruction
 * JD-Core Version:    0.6.1
 */
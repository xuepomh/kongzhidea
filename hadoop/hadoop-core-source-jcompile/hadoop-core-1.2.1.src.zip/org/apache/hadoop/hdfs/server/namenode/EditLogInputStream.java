package org.apache.hadoop.hdfs.server.namenode;

import java.io.IOException;
import java.io.InputStream;

abstract class EditLogInputStream extends InputStream
{
  abstract String getName();

  public abstract int available()
    throws IOException;

  public abstract int read()
    throws IOException;

  public abstract int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException;

  public abstract void close()
    throws IOException;

  abstract long length()
    throws IOException;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.EditLogInputStream
 * JD-Core Version:    0.6.1
 */
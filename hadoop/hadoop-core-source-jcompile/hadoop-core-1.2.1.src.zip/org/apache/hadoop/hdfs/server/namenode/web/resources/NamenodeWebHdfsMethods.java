/*     */ package org.apache.hadoop.hdfs.server.namenode.web.resources;
/*     */ 
/*     */ import com.sun.jersey.spi.container.ResourceFilters;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.security.Principal;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.ws.rs.Consumes;
/*     */ import javax.ws.rs.DELETE;
/*     */ import javax.ws.rs.DefaultValue;
/*     */ import javax.ws.rs.GET;
/*     */ import javax.ws.rs.POST;
/*     */ import javax.ws.rs.PUT;
/*     */ import javax.ws.rs.PathParam;
/*     */ import javax.ws.rs.Produces;
/*     */ import javax.ws.rs.QueryParam;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.core.Response;
/*     */ import javax.ws.rs.core.Response.ResponseBuilder;
/*     */ import javax.ws.rs.core.StreamingOutput;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.ContentSummary;
/*     */ import org.apache.hadoop.fs.FileStatus;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.hdfs.protocol.DirectoryListing;
/*     */ import org.apache.hadoop.hdfs.protocol.HdfsFileStatus;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlocks;
/*     */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenSecretManager;
/*     */ import org.apache.hadoop.hdfs.server.namenode.FSNamesystem;
/*     */ import org.apache.hadoop.hdfs.server.namenode.JspHelper;
/*     */ import org.apache.hadoop.hdfs.server.namenode.NameNode;
/*     */ import org.apache.hadoop.hdfs.web.JsonUtil;
/*     */ import org.apache.hadoop.hdfs.web.ParamFilter;
/*     */ import org.apache.hadoop.hdfs.web.WebHdfsFileSystem;
/*     */ import org.apache.hadoop.hdfs.web.resources.AccessTimeParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.BlockSizeParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.BufferSizeParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.ConcatSourcesParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.DelegationParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.DeleteOpParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.DeleteOpParam.Op;
/*     */ import org.apache.hadoop.hdfs.web.resources.DestinationParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.DoAsParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.GetOpParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.GetOpParam.Op;
/*     */ import org.apache.hadoop.hdfs.web.resources.GroupParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.HttpOpParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.HttpOpParam.Op;
/*     */ import org.apache.hadoop.hdfs.web.resources.LengthParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.ModificationTimeParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.OffsetParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.OverwriteParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.OwnerParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.Param;
/*     */ import org.apache.hadoop.hdfs.web.resources.PermissionParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.PostOpParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.PostOpParam.Op;
/*     */ import org.apache.hadoop.hdfs.web.resources.PutOpParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.PutOpParam.Op;
/*     */ import org.apache.hadoop.hdfs.web.resources.RecursiveParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.RenewerParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.ReplicationParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.TokenArgumentParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.UriFsPathParam;
/*     */ import org.apache.hadoop.hdfs.web.resources.UserParam;
/*     */ import org.apache.hadoop.security.Credentials;
/*     */ import org.apache.hadoop.security.SecurityUtil;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.token.Token;
/*     */ import org.apache.hadoop.security.token.TokenIdentifier;
/*     */ 
/*     */ @javax.ws.rs.Path("")
/*     */ @ResourceFilters({ParamFilter.class})
/*     */ public class NamenodeWebHdfsMethods
/*     */ {
/* 101 */   public static final Log LOG = LogFactory.getLog(NamenodeWebHdfsMethods.class);
/*     */ 
/* 103 */   private static final UriFsPathParam ROOT = new UriFsPathParam("");
/*     */ 
/* 105 */   private static final ThreadLocal<String> REMOTE_ADDRESS = new ThreadLocal();
/*     */ 
/*     */   @Context
/*     */   private ServletContext context;
/*     */ 
/*     */   @Context
/*     */   private HttpServletRequest request;
/*     */ 
/*     */   @Context
/*     */   private HttpServletResponse response;
/*     */ 
/* 109 */   public static String getRemoteAddress() { return (String)REMOTE_ADDRESS.get(); }
/*     */ 
/*     */ 
/*     */   static void setRemoteAddress(String remoteAddress)
/*     */   {
/* 114 */     REMOTE_ADDRESS.set(remoteAddress);
/*     */   }
/*     */ 
/*     */   private void init(UserGroupInformation ugi, DelegationParam delegation, UserParam username, DoAsParam doAsUser, UriFsPathParam path, HttpOpParam<?> op, Param<?, ?>[] parameters)
/*     */     throws IOException
/*     */   {
/* 126 */     if (LOG.isTraceEnabled()) {
/* 127 */       LOG.trace("HTTP " + ((HttpOpParam.Op)op.getValue()).getType() + ": " + op + ", " + path + ", ugi=" + ugi + ", " + username + ", " + doAsUser + Param.toSortedString(", ", parameters));
/*     */     }
/*     */ 
/* 133 */     this.response.setContentType(null);
/*     */   }
/*     */ 
/*     */   static DatanodeInfo chooseDatanode(NameNode namenode, String path, HttpOpParam.Op op, long openOffset, long blocksize)
/*     */     throws IOException
/*     */   {
/* 139 */     FSNamesystem ns = namenode.getNamesystem();
/*     */ 
/* 141 */     if (op == PutOpParam.Op.CREATE)
/*     */     {
/* 143 */       DatanodeInfo dn = ns.chooseDatanode(path, getRemoteAddress(), blocksize);
/* 144 */       if (dn != null)
/* 145 */         return dn;
/*     */     }
/* 147 */     else if ((op == GetOpParam.Op.OPEN) || (op == GetOpParam.Op.GETFILECHECKSUM) || (op == PostOpParam.Op.APPEND))
/*     */     {
/* 151 */       HdfsFileStatus status = namenode.getFileInfo(path);
/* 152 */       if (status == null) {
/* 153 */         throw new FileNotFoundException("File " + path + " not found.");
/*     */       }
/* 155 */       long len = status.getLen();
/* 156 */       if ((op == GetOpParam.Op.OPEN) && (
/* 157 */         (openOffset < 0L) || ((openOffset >= len) && (len > 0L)))) {
/* 158 */         throw new IOException("Offset=" + openOffset + " out of the range [0, " + len + "); " + op + ", path=" + path);
/*     */       }
/*     */ 
/* 163 */       if (len > 0L) {
/* 164 */         long offset = op == GetOpParam.Op.OPEN ? openOffset : len - 1L;
/* 165 */         LocatedBlocks locations = namenode.getBlockLocations(path, offset, 1L);
/*     */ 
/* 167 */         int count = locations.locatedBlockCount();
/* 168 */         if (count > 0) {
/* 169 */           return JspHelper.bestNode(locations.get(0));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 174 */     return ns.getRandomDatanode();
/*     */   }
/*     */ 
/*     */   private Token<? extends TokenIdentifier> generateDelegationToken(NameNode namenode, UserGroupInformation ugi, String renewer)
/*     */     throws IOException
/*     */   {
/* 180 */     Credentials c = DelegationTokenSecretManager.createCredentials(namenode, ugi, renewer != null ? renewer : ugi.getShortUserName());
/*     */ 
/* 182 */     Token t = (Token)c.getAllTokens().iterator().next();
/* 183 */     t.setKind(WebHdfsFileSystem.TOKEN_KIND);
/* 184 */     SecurityUtil.setTokenService(t, namenode.getHttpAddress());
/* 185 */     return t;
/*     */   }
/*     */ 
/*     */   private URI redirectURI(NameNode namenode, UserGroupInformation ugi, DelegationParam delegation, UserParam username, DoAsParam doAsUser, String path, HttpOpParam.Op op, long openOffset, long blocksize, Param<?, ?>[] parameters)
/*     */     throws URISyntaxException, IOException
/*     */   {
/* 194 */     DatanodeInfo dn = chooseDatanode(namenode, path, op, openOffset, blocksize);
/*     */     String delegationQuery;
/*     */     String delegationQuery;
/* 198 */     if (!UserGroupInformation.isSecurityEnabled())
/*     */     {
/* 200 */       delegationQuery = Param.toSortedString("&", new Param[] { doAsUser, username });
/*     */     }
/*     */     else
/*     */     {
/*     */       String delegationQuery;
/* 201 */       if (delegation.getValue() != null)
/*     */       {
/* 203 */         delegationQuery = "&" + delegation;
/*     */       }
/*     */       else {
/* 206 */         Token t = generateDelegationToken(namenode, ugi, this.request.getUserPrincipal().getName());
/*     */ 
/* 208 */         delegationQuery = "&" + new DelegationParam(t.encodeToUrlString());
/*     */       }
/*     */     }
/* 210 */     String query = op.toQueryString() + delegationQuery + Param.toSortedString("&", parameters);
/*     */ 
/* 212 */     String uripath = "/webhdfs/v1" + path;
/*     */ 
/* 214 */     URI uri = new URI("http", null, dn.getHostName(), dn.getInfoPort(), uripath, query, null);
/*     */ 
/* 216 */     if (LOG.isTraceEnabled()) {
/* 217 */       LOG.trace("redirectURI=" + uri);
/*     */     }
/* 219 */     return uri;
/*     */   }
/*     */ 
/*     */   @PUT
/*     */   @javax.ws.rs.Path("/")
/*     */   @Consumes({"*/*"})
/*     */   @Produces({"application/octet-stream", "application/json"})
/*     */   public Response putRoot(@Context UserGroupInformation ugi, @QueryParam("delegation") @DefaultValue("") DelegationParam delegation, @QueryParam("user.name") @DefaultValue("") UserParam username, @QueryParam("doas") @DefaultValue("") DoAsParam doAsUser, @QueryParam("op") @DefaultValue("null") PutOpParam op, @QueryParam("destination") @DefaultValue("") DestinationParam destination, @QueryParam("owner") @DefaultValue("") OwnerParam owner, @QueryParam("group") @DefaultValue("") GroupParam group, @QueryParam("permission") @DefaultValue("null") PermissionParam permission, @QueryParam("overwrite") @DefaultValue("false") OverwriteParam overwrite, @QueryParam("buffersize") @DefaultValue("null") BufferSizeParam bufferSize, @QueryParam("replication") @DefaultValue("null") ReplicationParam replication, @QueryParam("blocksize") @DefaultValue("null") BlockSizeParam blockSize, @QueryParam("modificationtime") @DefaultValue("-1") ModificationTimeParam modificationTime, @QueryParam("accesstime") @DefaultValue("-1") AccessTimeParam accessTime, @QueryParam("token") @DefaultValue("") TokenArgumentParam delegationTokenArgument)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 260 */     return put(ugi, delegation, username, doAsUser, ROOT, op, destination, owner, group, permission, overwrite, bufferSize, replication, blockSize, modificationTime, accessTime, delegationTokenArgument);
/*     */   }
/*     */ 
/*     */   @PUT
/*     */   @javax.ws.rs.Path("{path:.*}")
/*     */   @Consumes({"*/*"})
/*     */   @Produces({"application/octet-stream", "application/json"})
/*     */   public Response put(@Context final UserGroupInformation ugi, @QueryParam("delegation") @DefaultValue("") final DelegationParam delegation, @QueryParam("user.name") @DefaultValue("") final UserParam username, @QueryParam("doas") @DefaultValue("") final DoAsParam doAsUser, @PathParam("path") final UriFsPathParam path, @QueryParam("op") @DefaultValue("null") final PutOpParam op, @QueryParam("destination") @DefaultValue("") final DestinationParam destination, @QueryParam("owner") @DefaultValue("") final OwnerParam owner, @QueryParam("group") @DefaultValue("") final GroupParam group, @QueryParam("permission") @DefaultValue("null") final PermissionParam permission, @QueryParam("overwrite") @DefaultValue("false") final OverwriteParam overwrite, @QueryParam("buffersize") @DefaultValue("null") final BufferSizeParam bufferSize, @QueryParam("replication") @DefaultValue("null") final ReplicationParam replication, @QueryParam("blocksize") @DefaultValue("null") final BlockSizeParam blockSize, @QueryParam("modificationtime") @DefaultValue("-1") final ModificationTimeParam modificationTime, @QueryParam("accesstime") @DefaultValue("-1") final AccessTimeParam accessTime, @QueryParam("token") @DefaultValue("") final TokenArgumentParam delegationTokenArgument)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 305 */     init(ugi, delegation, username, doAsUser, path, op, new Param[] { destination, owner, group, permission, overwrite, bufferSize, replication, blockSize, modificationTime, accessTime, delegationTokenArgument });
/*     */ 
/* 309 */     return (Response)ugi.doAs(new PrivilegedExceptionAction()
/*     */     {
/*     */       public Response run() throws IOException, URISyntaxException {
/* 312 */         NamenodeWebHdfsMethods.REMOTE_ADDRESS.set(NamenodeWebHdfsMethods.this.request.getRemoteAddr());
/*     */         try
/*     */         {
/* 315 */           String fullpath = path.getAbsolutePath();
/* 316 */           Configuration conf = (Configuration)NamenodeWebHdfsMethods.this.context.getAttribute("current.conf");
/* 317 */           NameNode namenode = (NameNode)NamenodeWebHdfsMethods.this.context.getAttribute("name.node");
/*     */           Response localResponse3;
/*     */           boolean b;
/*     */           long expiryTime;
/* 319 */           switch (NamenodeWebHdfsMethods.6.$SwitchMap$org$apache$hadoop$hdfs$web$resources$PutOpParam$Op[((PutOpParam.Op)op.getValue()).ordinal()])
/*     */           {
/*     */           case 1:
/* 322 */             URI uri = NamenodeWebHdfsMethods.this.redirectURI(namenode, ugi, delegation, username, doAsUser, fullpath, (HttpOpParam.Op)op.getValue(), -1L, blockSize.getValue(conf), new Param[] { permission, overwrite, bufferSize, replication, blockSize });
/*     */ 
/* 325 */             return Response.temporaryRedirect(uri).type("application/octet-stream").build();
/*     */           case 2:
/* 329 */             boolean b = namenode.mkdirs(fullpath, permission.getFsPermission());
/* 330 */             String js = JsonUtil.toJsonString("boolean", Boolean.valueOf(b));
/* 331 */             return Response.ok(js).type("application/json").build();
/*     */           case 3:
/* 335 */             boolean b = namenode.rename(fullpath, (String)destination.getValue());
/* 336 */             String js = JsonUtil.toJsonString("boolean", Boolean.valueOf(b));
/* 337 */             return Response.ok(js).type("application/json").build();
/*     */           case 4:
/* 341 */             b = namenode.setReplication(fullpath, replication.getValue(conf));
/* 342 */             String js = JsonUtil.toJsonString("boolean", Boolean.valueOf(b));
/* 343 */             return Response.ok(js).type("application/json").build();
/*     */           case 5:
/* 347 */             if ((owner.getValue() == null) && (group.getValue() == null)) {
/* 348 */               throw new IllegalArgumentException("Both owner and group are empty.");
/*     */             }
/*     */ 
/* 351 */             namenode.setOwner(fullpath, (String)owner.getValue(), (String)group.getValue());
/* 352 */             return Response.ok().type("application/octet-stream").build();
/*     */           case 6:
/* 356 */             namenode.setPermission(fullpath, permission.getFsPermission());
/* 357 */             return Response.ok().type("application/octet-stream").build();
/*     */           case 7:
/* 361 */             namenode.setTimes(fullpath, ((Long)modificationTime.getValue()).longValue(), ((Long)accessTime.getValue()).longValue());
/* 362 */             return Response.ok().type("application/octet-stream").build();
/*     */           case 8:
/* 366 */             Token token = new Token();
/* 367 */             token.decodeFromUrlString((String)delegationTokenArgument.getValue());
/* 368 */             expiryTime = namenode.renewDelegationToken(token);
/* 369 */             String js = JsonUtil.toJsonString("long", Long.valueOf(expiryTime));
/* 370 */             return Response.ok(js).type("application/json").build();
/*     */           case 9:
/* 374 */             Token token = new Token();
/* 375 */             token.decodeFromUrlString((String)delegationTokenArgument.getValue());
/* 376 */             namenode.cancelDelegationToken(token);
/* 377 */             return Response.ok().type("application/octet-stream").build();
/*     */           }
/*     */ 
/* 380 */           throw new UnsupportedOperationException(op + " is not supported");
/*     */         }
/*     */         finally
/*     */         {
/* 384 */           NamenodeWebHdfsMethods.REMOTE_ADDRESS.set(null);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   @POST
/*     */   @javax.ws.rs.Path("/")
/*     */   @Consumes({"*/*"})
/*     */   @Produces({"application/octet-stream", "application/json"})
/*     */   public Response postRoot(@Context UserGroupInformation ugi, @QueryParam("delegation") @DefaultValue("") DelegationParam delegation, @QueryParam("user.name") @DefaultValue("") UserParam username, @QueryParam("doas") @DefaultValue("") DoAsParam doAsUser, @QueryParam("op") @DefaultValue("null") PostOpParam op, @QueryParam("sources") @DefaultValue("") ConcatSourcesParam concatSrcs, @QueryParam("buffersize") @DefaultValue("null") BufferSizeParam bufferSize)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 410 */     return post(ugi, delegation, username, doAsUser, ROOT, op, concatSrcs, bufferSize);
/*     */   }
/*     */ 
/*     */   @POST
/*     */   @javax.ws.rs.Path("{path:.*}")
/*     */   @Consumes({"*/*"})
/*     */   @Produces({"application/octet-stream", "application/json"})
/*     */   public Response post(@Context final UserGroupInformation ugi, @QueryParam("delegation") @DefaultValue("") final DelegationParam delegation, @QueryParam("user.name") @DefaultValue("") final UserParam username, @QueryParam("doas") @DefaultValue("") final DoAsParam doAsUser, @PathParam("path") final UriFsPathParam path, @QueryParam("op") @DefaultValue("null") final PostOpParam op, @QueryParam("sources") @DefaultValue("") final ConcatSourcesParam concatSrcs, @QueryParam("buffersize") @DefaultValue("null") final BufferSizeParam bufferSize)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 435 */     init(ugi, delegation, username, doAsUser, path, op, new Param[] { concatSrcs, bufferSize });
/*     */ 
/* 437 */     return (Response)ugi.doAs(new PrivilegedExceptionAction()
/*     */     {
/*     */       public Response run() throws IOException, URISyntaxException {
/* 440 */         NamenodeWebHdfsMethods.REMOTE_ADDRESS.set(NamenodeWebHdfsMethods.this.request.getRemoteAddr());
/*     */         try
/*     */         {
/* 443 */           String fullpath = path.getAbsolutePath();
/* 444 */           NameNode namenode = (NameNode)NamenodeWebHdfsMethods.this.context.getAttribute("name.node");
/*     */           URI uri;
/* 446 */           switch (NamenodeWebHdfsMethods.6.$SwitchMap$org$apache$hadoop$hdfs$web$resources$PostOpParam$Op[((PostOpParam.Op)op.getValue()).ordinal()])
/*     */           {
/*     */           case 1:
/* 449 */             uri = NamenodeWebHdfsMethods.this.redirectURI(namenode, ugi, delegation, username, doAsUser, fullpath, (HttpOpParam.Op)op.getValue(), -1L, -1L, new Param[] { bufferSize });
/*     */ 
/* 451 */             return Response.temporaryRedirect(uri).type("application/octet-stream").build();
/*     */           case 2:
/* 455 */             namenode.concat(fullpath, concatSrcs.getAbsolutePaths());
/* 456 */             return Response.ok().build();
/*     */           }
/*     */ 
/* 459 */           throw new UnsupportedOperationException(op + " is not supported");
/*     */         }
/*     */         finally
/*     */         {
/* 463 */           NamenodeWebHdfsMethods.REMOTE_ADDRESS.set(null);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   @GET
/*     */   @javax.ws.rs.Path("/")
/*     */   @Produces({"application/octet-stream", "application/json"})
/*     */   public Response getRoot(@Context UserGroupInformation ugi, @QueryParam("delegation") @DefaultValue("") DelegationParam delegation, @QueryParam("user.name") @DefaultValue("") UserParam username, @QueryParam("doas") @DefaultValue("") DoAsParam doAsUser, @QueryParam("op") @DefaultValue("null") GetOpParam op, @QueryParam("offset") @DefaultValue("0") OffsetParam offset, @QueryParam("length") @DefaultValue("null") LengthParam length, @QueryParam("renewer") @DefaultValue("null") RenewerParam renewer, @QueryParam("buffersize") @DefaultValue("null") BufferSizeParam bufferSize)
/*     */     throws IOException, URISyntaxException, InterruptedException
/*     */   {
/* 492 */     return get(ugi, delegation, username, doAsUser, ROOT, op, offset, length, renewer, bufferSize);
/*     */   }
/*     */ 
/*     */   @GET
/*     */   @javax.ws.rs.Path("{path:.*}")
/*     */   @Produces({"application/octet-stream", "application/json"})
/*     */   public Response get(@Context final UserGroupInformation ugi, @QueryParam("delegation") @DefaultValue("") final DelegationParam delegation, @QueryParam("user.name") @DefaultValue("") final UserParam username, @QueryParam("doas") @DefaultValue("") final DoAsParam doAsUser, @PathParam("path") final UriFsPathParam path, @QueryParam("op") @DefaultValue("null") final GetOpParam op, @QueryParam("offset") @DefaultValue("0") final OffsetParam offset, @QueryParam("length") @DefaultValue("null") final LengthParam length, @QueryParam("renewer") @DefaultValue("null") final RenewerParam renewer, @QueryParam("buffersize") @DefaultValue("null") final BufferSizeParam bufferSize)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 521 */     init(ugi, delegation, username, doAsUser, path, op, new Param[] { offset, length, renewer, bufferSize });
/*     */ 
/* 524 */     return (Response)ugi.doAs(new PrivilegedExceptionAction()
/*     */     {
/*     */       public Response run() throws IOException, URISyntaxException {
/* 527 */         NamenodeWebHdfsMethods.REMOTE_ADDRESS.set(NamenodeWebHdfsMethods.this.request.getRemoteAddr());
/*     */         try
/*     */         {
/* 530 */           NameNode namenode = (NameNode)NamenodeWebHdfsMethods.this.context.getAttribute("name.node");
/* 531 */           String fullpath = path.getAbsolutePath();
/*     */           Long lengthValue;
/*     */           Object js;
/*     */           Object js;
/*     */           Object js;
/* 533 */           switch (NamenodeWebHdfsMethods.6.$SwitchMap$org$apache$hadoop$hdfs$web$resources$GetOpParam$Op[((GetOpParam.Op)op.getValue()).ordinal()])
/*     */           {
/*     */           case 1:
/* 536 */             URI uri = NamenodeWebHdfsMethods.this.redirectURI(namenode, ugi, delegation, username, doAsUser, fullpath, (HttpOpParam.Op)op.getValue(), ((Long)offset.getValue()).longValue(), -1L, new Param[] { offset, length, bufferSize });
/*     */ 
/* 538 */             return Response.temporaryRedirect(uri).type("application/octet-stream").build();
/*     */           case 2:
/* 542 */             long offsetValue = ((Long)offset.getValue()).longValue();
/* 543 */             lengthValue = (Long)length.getValue();
/* 544 */             LocatedBlocks locatedblocks = namenode.getBlockLocations(fullpath, offsetValue, lengthValue != null ? lengthValue.longValue() : 9223372036854775807L);
/*     */ 
/* 546 */             String js = JsonUtil.toJsonString(locatedblocks);
/* 547 */             return Response.ok(js).type("application/json").build();
/*     */           case 3:
/* 551 */             HdfsFileStatus status = namenode.getFileInfo(fullpath);
/* 552 */             if (status == null) {
/* 553 */               throw new FileNotFoundException("File does not exist: " + fullpath);
/*     */             }
/*     */ 
/* 556 */             js = JsonUtil.toJsonString(status, true);
/* 557 */             return Response.ok(js).type("application/json").build();
/*     */           case 4:
/* 561 */             StreamingOutput streaming = NamenodeWebHdfsMethods.getListingStream(namenode, fullpath);
/* 562 */             return Response.ok(streaming).type("application/json").build();
/*     */           case 5:
/* 566 */             ContentSummary contentsummary = namenode.getContentSummary(fullpath);
/* 567 */             js = JsonUtil.toJsonString(contentsummary);
/* 568 */             return Response.ok(js).type("application/json").build();
/*     */           case 6:
/* 572 */             URI uri = NamenodeWebHdfsMethods.this.redirectURI(namenode, ugi, delegation, username, doAsUser, fullpath, (HttpOpParam.Op)op.getValue(), -1L, -1L, new Param[0]);
/*     */ 
/* 574 */             return Response.temporaryRedirect(uri).type("application/octet-stream").build();
/*     */           case 7:
/* 578 */             if (delegation.getValue() != null) {
/* 579 */               throw new IllegalArgumentException(delegation.getName() + " parameter is not null.");
/*     */             }
/*     */ 
/* 582 */             Token token = NamenodeWebHdfsMethods.this.generateDelegationToken(namenode, ugi, (String)renewer.getValue());
/*     */ 
/* 584 */             js = JsonUtil.toJsonString(token);
/* 585 */             return Response.ok(js).type("application/json").build();
/*     */           case 8:
/* 589 */             String js = JsonUtil.toJsonString(org.apache.hadoop.fs.Path.class.getSimpleName(), WebHdfsFileSystem.getHomeDirectoryString(ugi));
/*     */ 
/* 592 */             return Response.ok(js).type("application/json").build();
/*     */           }
/*     */ 
/* 595 */           throw new UnsupportedOperationException(op + " is not supported");
/*     */         }
/*     */         finally
/*     */         {
/* 599 */           NamenodeWebHdfsMethods.REMOTE_ADDRESS.set(null);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   private static DirectoryListing getDirectoryListing(NameNode np, String p, byte[] startAfter) throws IOException
/*     */   {
/* 607 */     DirectoryListing listing = np.getListing(p, startAfter);
/* 608 */     if (listing == null) {
/* 609 */       throw new FileNotFoundException("File " + p + " does not exist.");
/*     */     }
/* 611 */     return listing;
/*     */   }
/*     */ 
/*     */   private static StreamingOutput getListingStream(final NameNode np, final String p) throws IOException
/*     */   {
/* 616 */     DirectoryListing first = getDirectoryListing(np, p, HdfsFileStatus.EMPTY_NAME);
/*     */ 
/* 619 */     return new StreamingOutput()
/*     */     {
/*     */       public void write(OutputStream outstream) throws IOException {
/* 622 */         PrintStream out = new PrintStream(outstream);
/* 623 */         out.println("{\"" + FileStatus.class.getSimpleName() + "es\":{\"" + FileStatus.class.getSimpleName() + "\":[");
/*     */ 
/* 626 */         HdfsFileStatus[] partial = this.val$first.getPartialListing();
/* 627 */         if (partial.length > 0) {
/* 628 */           out.print(JsonUtil.toJsonString(partial[0], false));
/*     */         }
/* 630 */         for (int i = 1; i < partial.length; i++) {
/* 631 */           out.println(',');
/* 632 */           out.print(JsonUtil.toJsonString(partial[i], false));
/*     */         }
/*     */ 
/* 635 */         for (DirectoryListing curr = this.val$first; curr.hasMore(); ) {
/* 636 */           curr = NamenodeWebHdfsMethods.getDirectoryListing(np, p, curr.getLastName());
/* 637 */           for (HdfsFileStatus s : curr.getPartialListing()) {
/* 638 */             out.println(',');
/* 639 */             out.print(JsonUtil.toJsonString(s, false));
/*     */           }
/*     */         }
/*     */ 
/* 643 */         out.println();
/* 644 */         out.println("]}}");
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   @DELETE
/*     */   @javax.ws.rs.Path("/")
/*     */   @Produces({"application/json"})
/*     */   public Response deleteRoot(@Context UserGroupInformation ugi, @QueryParam("delegation") @DefaultValue("") DelegationParam delegation, @QueryParam("user.name") @DefaultValue("") UserParam username, @QueryParam("doas") @DefaultValue("") DoAsParam doAsUser, @QueryParam("op") @DefaultValue("null") DeleteOpParam op, @QueryParam("recursive") @DefaultValue("false") RecursiveParam recursive)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 666 */     return delete(ugi, delegation, username, doAsUser, ROOT, op, recursive);
/*     */   }
/*     */ 
/*     */   @DELETE
/*     */   @javax.ws.rs.Path("{path:.*}")
/*     */   @Produces({"application/json"})
/*     */   public Response delete(@Context UserGroupInformation ugi, @QueryParam("delegation") @DefaultValue("") DelegationParam delegation, @QueryParam("user.name") @DefaultValue("") UserParam username, @QueryParam("doas") @DefaultValue("") DoAsParam doAsUser, @PathParam("path") final UriFsPathParam path, @QueryParam("op") @DefaultValue("null") final DeleteOpParam op, @QueryParam("recursive") @DefaultValue("false") final RecursiveParam recursive)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 688 */     init(ugi, delegation, username, doAsUser, path, op, new Param[] { recursive });
/*     */ 
/* 690 */     return (Response)ugi.doAs(new PrivilegedExceptionAction()
/*     */     {
/*     */       public Response run() throws IOException {
/* 693 */         NamenodeWebHdfsMethods.REMOTE_ADDRESS.set(NamenodeWebHdfsMethods.this.request.getRemoteAddr());
/*     */         try
/*     */         {
/* 696 */           NameNode namenode = (NameNode)NamenodeWebHdfsMethods.this.context.getAttribute("name.node");
/* 697 */           String fullpath = path.getAbsolutePath();
/*     */ 
/* 699 */           switch (NamenodeWebHdfsMethods.6.$SwitchMap$org$apache$hadoop$hdfs$web$resources$DeleteOpParam$Op[((DeleteOpParam.Op)op.getValue()).ordinal()])
/*     */           {
/*     */           case 1:
/* 702 */             boolean b = namenode.delete(fullpath, ((Boolean)recursive.getValue()).booleanValue());
/* 703 */             String js = JsonUtil.toJsonString("boolean", Boolean.valueOf(b));
/* 704 */             return Response.ok(js).type("application/json").build();
/*     */           }
/*     */ 
/* 707 */           throw new UnsupportedOperationException(op + " is not supported");
/*     */         }
/*     */         finally
/*     */         {
/* 711 */           NamenodeWebHdfsMethods.REMOTE_ADDRESS.set(null);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.web.resources.NamenodeWebHdfsMethods
 * JD-Core Version:    0.6.1
 */
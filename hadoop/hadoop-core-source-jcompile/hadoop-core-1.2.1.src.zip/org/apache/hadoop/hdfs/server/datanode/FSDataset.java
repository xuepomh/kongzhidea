/*      */ package org.apache.hadoop.hdfs.server.datanode;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.FilenameFilter;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.RandomAccessFile;
/*      */ import java.nio.channels.FileChannel;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import java.util.TreeSet;
/*      */ import javax.management.NotCompliantMBeanException;
/*      */ import javax.management.ObjectName;
/*      */ import javax.management.StandardMBean;
/*      */ import org.apache.hadoop.conf.Configuration;
/*      */ import org.apache.hadoop.fs.DF;
/*      */ import org.apache.hadoop.fs.DU;
/*      */ import org.apache.hadoop.fs.FileUtil;
/*      */ import org.apache.hadoop.hdfs.protocol.Block;
/*      */ import org.apache.hadoop.hdfs.protocol.BlockLocalPathInfo;
/*      */ import org.apache.hadoop.hdfs.protocol.FSConstants;
/*      */ import org.apache.hadoop.hdfs.server.common.Storage.StorageDirectory;
/*      */ import org.apache.hadoop.hdfs.server.datanode.metrics.FSDatasetMBean;
/*      */ import org.apache.hadoop.hdfs.server.protocol.BlockRecoveryInfo;
/*      */ import org.apache.hadoop.hdfs.server.protocol.InterDatanodeProtocol;
/*      */ import org.apache.hadoop.metrics2.util.MBeans;
/*      */ import org.apache.hadoop.util.DataChecksum;
/*      */ import org.apache.hadoop.util.DiskChecker;
/*      */ import org.apache.hadoop.util.DiskChecker.DiskErrorException;
/*      */ import org.apache.hadoop.util.DiskChecker.DiskOutOfSpaceException;
/*      */ 
/*      */ public class FSDataset
/*      */   implements FSConstants, FSDatasetInterface
/*      */ {
/*      */   public static final String METADATA_EXTENSION = ".meta";
/*  793 */   public static final int METADATA_EXTENSION_LENGTH = ".meta".length();
/*      */   public static final short METADATA_VERSION = 1;
/*      */   FSVolumeSet volumes;
/*  942 */   private HashMap<Block, ActiveFile> ongoingCreates = new HashMap();
/*  943 */   private int maxBlocksPerDir = 0;
/*  944 */   HashMap<Block, DatanodeBlockInfo> volumeMap = new HashMap();
/*  945 */   static Random random = new Random();
/*      */   private int validVolsRequired;
/*      */   FSDatasetAsyncDiskService asyncDiskService;
/*      */   private final AsyncBlockReport asyncBlockReport;
/*      */   private static final String DISK_ERROR = "Possible disk error on file creation: ";
/*      */   private ObjectName mbeanName;
/* 2064 */   private Random rand = new Random();
/*      */ 
/*      */   static long getGenerationStampFromFile(File[] listdir, File blockFile)
/*      */   {
/*   72 */     String blockNamePrefix = new StringBuilder().append(blockFile.getName()).append("_").toString();
/*      */ 
/*   76 */     for (int j = 0; j < listdir.length; j++) {
/*   77 */       String path = listdir[j].getName();
/*   78 */       if (path.startsWith(blockNamePrefix))
/*      */       {
/*   81 */         if (path.endsWith(".meta"))
/*      */         {
/*   85 */           String metaPart = path.substring(blockNamePrefix.length(), path.length() - METADATA_EXTENSION_LENGTH);
/*      */ 
/*   87 */           return Long.parseLong(metaPart);
/*      */         }
/*      */       }
/*      */     }
/*   89 */     DataNode.LOG.warn(new StringBuilder().append("Block ").append(blockFile).append(" does not have a metafile!").toString());
/*      */ 
/*   91 */     return 0L;
/*      */   }
/*      */ 
/*      */   static String getMetaFileName(String blockFileName, long genStamp)
/*      */   {
/*  847 */     return new StringBuilder().append(blockFileName).append("_").append(genStamp).append(".meta").toString();
/*      */   }
/*      */ 
/*      */   static File getMetaFile(File f, Block b) {
/*  851 */     return new File(getMetaFileName(f.getAbsolutePath(), b.getGenerationStamp()));
/*      */   }
/*      */ 
/*      */   protected File getMetaFile(Block b) throws IOException {
/*  855 */     return getMetaFile(getBlockFile(b), b);
/*      */   }
/*      */ 
/*      */   public static File findMetaFile(File blockFile) throws IOException
/*      */   {
/*  860 */     final String prefix = new StringBuilder().append(blockFile.getName()).append("_").toString();
/*  861 */     File parent = blockFile.getParentFile();
/*  862 */     File[] matches = parent.listFiles(new FilenameFilter() {
/*      */       public boolean accept(File dir, String name) {
/*  864 */         return (dir.equals(this.val$parent)) && (name.startsWith(prefix)) && (name.endsWith(".meta"));
/*      */       }
/*      */     });
/*  869 */     if ((matches == null) || (matches.length == 0)) {
/*  870 */       throw new IOException(new StringBuilder().append("Meta file not found, blockFile=").append(blockFile).toString());
/*      */     }
/*  872 */     if (matches.length > 1) {
/*  873 */       throw new IOException(new StringBuilder().append("Found more than one meta files: ").append(Arrays.asList(matches)).toString());
/*      */     }
/*      */ 
/*  876 */     return matches[0];
/*      */   }
/*      */ 
/*      */   private static long parseGenerationStamp(File blockFile, File metaFile)
/*      */     throws IOException
/*      */   {
/*  882 */     String metaname = metaFile.getName();
/*  883 */     String gs = metaname.substring(blockFile.getName().length() + 1, metaname.length() - ".meta".length());
/*      */     try
/*      */     {
/*  886 */       return Long.parseLong(gs);
/*      */     } catch (NumberFormatException nfe) {
/*  888 */       throw ((IOException)new IOException(new StringBuilder().append("blockFile=").append(blockFile).append(", metaFile=").append(metaFile).toString()).initCause(nfe));
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized File findBlockFile(long blockId)
/*      */   {
/*  895 */     Block b = new Block(blockId);
/*  896 */     File blockfile = null;
/*  897 */     ActiveFile activefile = (ActiveFile)this.ongoingCreates.get(b);
/*  898 */     if (activefile != null) {
/*  899 */       blockfile = activefile.file;
/*      */     }
/*  901 */     if (blockfile == null) {
/*  902 */       blockfile = getFile(b);
/*      */     }
/*  904 */     if ((blockfile == null) && 
/*  905 */       (DataNode.LOG.isDebugEnabled())) {
/*  906 */       DataNode.LOG.debug(new StringBuilder().append("ongoingCreates=").append(this.ongoingCreates).toString());
/*  907 */       DataNode.LOG.debug(new StringBuilder().append("volumeMap=").append(this.volumeMap).toString());
/*      */     }
/*      */ 
/*  910 */     return blockfile;
/*      */   }
/*      */ 
/*      */   public synchronized Block getStoredBlock(long blkid) throws IOException
/*      */   {
/*  915 */     File blockfile = findBlockFile(blkid);
/*  916 */     if (blockfile == null) {
/*  917 */       return null;
/*      */     }
/*  919 */     File metafile = findMetaFile(blockfile);
/*  920 */     Block block = new Block(blkid);
/*  921 */     return new Block(blkid, getVisibleLength(block), parseGenerationStamp(blockfile, metafile));
/*      */   }
/*      */ 
/*      */   public boolean metaFileExists(Block b) throws IOException
/*      */   {
/*  926 */     return getMetaFile(b).exists();
/*      */   }
/*      */ 
/*      */   public long getMetaDataLength(Block b) throws IOException {
/*  930 */     File checksumFile = getMetaFile(b);
/*  931 */     return checksumFile.length();
/*      */   }
/*      */ 
/*      */   public FSDatasetInterface.MetaDataInputStream getMetaDataInputStream(Block b) throws IOException
/*      */   {
/*  936 */     File checksumFile = getMetaFile(b);
/*  937 */     return new FSDatasetInterface.MetaDataInputStream(new FileInputStream(checksumFile), checksumFile.length());
/*      */   }
/*      */ 
/*      */   public FSDataset(DataStorage storage, Configuration conf)
/*      */     throws IOException
/*      */   {
/*  956 */     this.maxBlocksPerDir = conf.getInt("dfs.datanode.numblocks", 64);
/*      */ 
/*  960 */     int volFailuresTolerated = conf.getInt("dfs.datanode.failed.volumes.tolerated", 0);
/*      */ 
/*  964 */     String[] dataDirs = conf.getStrings("dfs.data.dir");
/*      */ 
/*  966 */     int volsConfigured = 0;
/*      */ 
/*  968 */     if (dataDirs != null) {
/*  969 */       volsConfigured = dataDirs.length;
/*      */     }
/*  971 */     int volsFailed = volsConfigured - storage.getNumStorageDirs();
/*      */ 
/*  973 */     if ((volsFailed < 0) || (volsFailed > volFailuresTolerated))
/*      */     {
/*  975 */       throw new DiskChecker.DiskErrorException(new StringBuilder().append("Invalid value for volsFailed : ").append(volsFailed).append(" , Volumes tolerated : ").append(volFailuresTolerated).toString());
/*      */     }
/*      */ 
/*  979 */     this.validVolsRequired = (volsConfigured - volFailuresTolerated);
/*      */ 
/*  981 */     if ((this.validVolsRequired < 1) || (this.validVolsRequired > storage.getNumStorageDirs()))
/*      */     {
/*  983 */       throw new DiskChecker.DiskErrorException(new StringBuilder().append("Invalid value for validVolsRequired : ").append(this.validVolsRequired).append(" , Current valid volumes: ").append(storage.getNumStorageDirs()).toString());
/*      */     }
/*      */ 
/*  987 */     FSVolume[] volArray = new FSVolume[storage.getNumStorageDirs()];
/*  988 */     for (int idx = 0; idx < storage.getNumStorageDirs(); idx++) {
/*  989 */       volArray[idx] = new FSVolume(storage.getStorageDir(idx).getCurrentDir(), conf);
/*      */     }
/*  991 */     this.volumes = new FSVolumeSet(volArray);
/*  992 */     this.volumes.getVolumeMap(this.volumeMap);
/*  993 */     this.asyncBlockReport = new AsyncBlockReport(this);
/*  994 */     this.asyncBlockReport.start();
/*  995 */     File[] roots = new File[storage.getNumStorageDirs()];
/*  996 */     for (int idx = 0; idx < storage.getNumStorageDirs(); idx++) {
/*  997 */       roots[idx] = storage.getStorageDir(idx).getCurrentDir();
/*      */     }
/*  999 */     this.asyncDiskService = new FSDatasetAsyncDiskService(roots);
/* 1000 */     registerMBean(storage.getStorageID());
/*      */   }
/*      */ 
/*      */   public long getDfsUsed()
/*      */     throws IOException
/*      */   {
/* 1007 */     return this.volumes.getDfsUsed();
/*      */   }
/*      */ 
/*      */   public boolean hasEnoughResource()
/*      */   {
/* 1014 */     return this.volumes.numberOfVolumes() >= this.validVolsRequired;
/*      */   }
/*      */ 
/*      */   public long getCapacity()
/*      */     throws IOException
/*      */   {
/* 1021 */     return this.volumes.getCapacity();
/*      */   }
/*      */ 
/*      */   public long getRemaining()
/*      */     throws IOException
/*      */   {
/* 1028 */     return this.volumes.getRemaining();
/*      */   }
/*      */ 
/*      */   public long getLength(Block b)
/*      */     throws IOException
/*      */   {
/* 1035 */     return getBlockFile(b).length();
/*      */   }
/*      */ 
/*      */   public synchronized long getVisibleLength(Block b) throws IOException
/*      */   {
/* 1040 */     ActiveFile activeFile = (ActiveFile)this.ongoingCreates.get(b);
/*      */ 
/* 1042 */     if (activeFile != null) {
/* 1043 */       return activeFile.getVisibleLength();
/*      */     }
/* 1045 */     return getLength(b);
/*      */   }
/*      */ 
/*      */   public synchronized void setVisibleLength(Block b, long length)
/*      */     throws IOException
/*      */   {
/* 1052 */     ActiveFile activeFile = (ActiveFile)this.ongoingCreates.get(b);
/*      */ 
/* 1054 */     if (activeFile != null)
/* 1055 */       activeFile.setVisibleLength(length);
/*      */     else
/* 1057 */       throw new IOException(String.format("block %s is not being written to", new Object[] { b }));
/*      */   }
/*      */ 
/*      */   public File getBlockFile(Block b)
/*      */     throws IOException
/*      */   {
/* 1067 */     File f = validateBlockFile(b);
/* 1068 */     if (f == null) {
/* 1069 */       if (InterDatanodeProtocol.LOG.isDebugEnabled()) {
/* 1070 */         InterDatanodeProtocol.LOG.debug(new StringBuilder().append("b=").append(b).append(", volumeMap=").append(this.volumeMap).toString());
/*      */       }
/* 1072 */       throw new IOException(new StringBuilder().append("Block ").append(b).append(" is not valid.").toString());
/*      */     }
/* 1074 */     return f;
/*      */   }
/*      */ 
/*      */   public BlockLocalPathInfo getBlockLocalPathInfo(Block block)
/*      */     throws IOException
/*      */   {
/* 1080 */     File datafile = getBlockFile(block);
/* 1081 */     File metafile = getMetaFile(datafile, block);
/* 1082 */     BlockLocalPathInfo info = new BlockLocalPathInfo(block, datafile.getAbsolutePath(), metafile.getAbsolutePath());
/*      */ 
/* 1084 */     return info;
/*      */   }
/*      */ 
/*      */   public InputStream getBlockInputStream(Block b) throws IOException {
/* 1088 */     File f = getBlockFileNoExistsCheck(b);
/*      */     try {
/* 1090 */       return new FileInputStream(f); } catch (FileNotFoundException fnfe) {
/*      */     }
/* 1092 */     throw new IOException(new StringBuilder().append("Block ").append(b).append(" is not valid. ").append("Expected block file at ").append(f).append(" does not exist.").toString());
/*      */   }
/*      */ 
/*      */   private File getBlockFileNoExistsCheck(Block b)
/*      */     throws IOException
/*      */   {
/* 1103 */     File f = getFile(b);
/* 1104 */     if (f == null) {
/* 1105 */       throw new IOException(new StringBuilder().append("Block ").append(b).append(" is not valid").toString());
/*      */     }
/* 1107 */     return f;
/*      */   }
/*      */ 
/*      */   public InputStream getBlockInputStream(Block b, long seekOffset) throws IOException {
/* 1112 */     File blockFile = getBlockFileNoExistsCheck(b);
/*      */     RandomAccessFile blockInFile;
/*      */     try {
/* 1115 */       blockInFile = new RandomAccessFile(blockFile, "r");
/*      */     } catch (FileNotFoundException fnfe) {
/* 1117 */       throw new IOException(new StringBuilder().append("Block ").append(b).append(" is not valid. ").append("Expected block file at ").append(blockFile).append(" does not exist.").toString());
/*      */     }
/*      */ 
/* 1121 */     if (seekOffset > 0L) {
/* 1122 */       blockInFile.seek(seekOffset);
/*      */     }
/* 1124 */     return new FileInputStream(blockInFile.getFD());
/*      */   }
/*      */ 
/*      */   public synchronized FSDatasetInterface.BlockInputStreams getTmpInputStreams(Block b, long blkOffset, long ckoff)
/*      */     throws IOException
/*      */   {
/* 1133 */     DatanodeBlockInfo info = (DatanodeBlockInfo)this.volumeMap.get(b);
/* 1134 */     if (info == null) {
/* 1135 */       throw new IOException(new StringBuilder().append("Block ").append(b).append(" does not exist in volumeMap.").toString());
/*      */     }
/* 1137 */     FSVolume v = info.getVolume();
/* 1138 */     File blockFile = info.getFile();
/* 1139 */     if (blockFile == null) {
/* 1140 */       blockFile = v.getTmpFile(b);
/*      */     }
/* 1142 */     RandomAccessFile blockInFile = new RandomAccessFile(blockFile, "r");
/* 1143 */     if (blkOffset > 0L) {
/* 1144 */       blockInFile.seek(blkOffset);
/*      */     }
/* 1146 */     File metaFile = getMetaFile(blockFile, b);
/* 1147 */     RandomAccessFile metaInFile = new RandomAccessFile(metaFile, "r");
/* 1148 */     if (ckoff > 0L) {
/* 1149 */       metaInFile.seek(ckoff);
/*      */     }
/* 1151 */     return new FSDatasetInterface.BlockInputStreams(new FileInputStream(blockInFile.getFD()), new FileInputStream(metaInFile.getFD()));
/*      */   }
/*      */ 
/*      */   private FSDatasetInterface.BlockWriteStreams createBlockWriteStreams(File f, File metafile) throws IOException
/*      */   {
/* 1156 */     return new FSDatasetInterface.BlockWriteStreams(new FileOutputStream(new RandomAccessFile(f, "rw").getFD()), new FileOutputStream(new RandomAccessFile(metafile, "rw").getFD()));
/*      */   }
/*      */ 
/*      */   public boolean detachBlock(Block block, int numLinks)
/*      */     throws IOException
/*      */   {
/* 1171 */     DatanodeBlockInfo info = null;
/*      */ 
/* 1173 */     synchronized (this) {
/* 1174 */       info = (DatanodeBlockInfo)this.volumeMap.get(block);
/*      */     }
/* 1176 */     return info.detachBlock(block, numLinks);
/*      */   }
/*      */ 
/*      */   private static <T> void updateBlockMap(Map<Block, T> blockmap, Block oldblock, Block newblock) throws IOException
/*      */   {
/* 1181 */     if (blockmap.containsKey(oldblock)) {
/* 1182 */       Object value = blockmap.remove(oldblock);
/* 1183 */       blockmap.put(newblock, value);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void updateBlock(Block oldblock, Block newblock) throws IOException
/*      */   {
/* 1189 */     if (oldblock.getBlockId() != newblock.getBlockId()) {
/* 1190 */       throw new IOException(new StringBuilder().append("Cannot update oldblock (=").append(oldblock).append(") to newblock (=").append(newblock).append(").").toString());
/*      */     }
/*      */ 
/* 1197 */     boolean isValidUpdate = (newblock.getGenerationStamp() > oldblock.getGenerationStamp()) || ((newblock.getGenerationStamp() == oldblock.getGenerationStamp()) && (newblock.getNumBytes() == oldblock.getNumBytes()));
/*      */ 
/* 1202 */     if (!isValidUpdate) {
/* 1203 */       throw new IOException(new StringBuilder().append("Cannot update oldblock=").append(oldblock).append(" to newblock=").append(newblock).append(" since generation stamps must ").append("increase, or else length must not change.").toString());
/*      */     }
/*      */ 
/*      */     while (true)
/*      */     {
/* 1211 */       List threads = tryUpdateBlock(oldblock, newblock);
/* 1212 */       if (threads == null) {
/* 1213 */         return;
/*      */       }
/*      */ 
/* 1216 */       interruptAndJoinThreads(threads);
/*      */     }
/*      */   }
/*      */ 
/*      */   private boolean interruptAndJoinThreads(List<Thread> threads)
/*      */   {
/* 1227 */     for (Thread t : threads) {
/* 1228 */       t.interrupt();
/*      */     }
/* 1230 */     for (Thread t : threads) {
/*      */       try {
/* 1232 */         t.join();
/*      */       } catch (InterruptedException e) {
/* 1234 */         DataNode.LOG.warn(new StringBuilder().append("interruptOngoingCreates: t=").append(t).toString(), e);
/* 1235 */         return false;
/*      */       }
/*      */     }
/* 1238 */     return true;
/*      */   }
/*      */ 
/*      */   private synchronized ArrayList<Thread> getActiveThreads(Block block)
/*      */   {
/* 1248 */     ActiveFile activefile = (ActiveFile)this.ongoingCreates.get(block);
/* 1249 */     if ((activefile != null) && (!activefile.threads.isEmpty()))
/*      */     {
/* 1251 */       for (Iterator i = activefile.threads.iterator(); i.hasNext(); ) {
/* 1252 */         Thread t = (Thread)i.next();
/* 1253 */         if (!t.isAlive()) {
/* 1254 */           i.remove();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1259 */       if (!activefile.threads.isEmpty()) {
/* 1260 */         return new ArrayList(activefile.threads);
/*      */       }
/*      */     }
/* 1263 */     return null;
/*      */   }
/*      */ 
/*      */   private synchronized List<Thread> tryUpdateBlock(Block oldblock, Block newblock)
/*      */     throws IOException
/*      */   {
/* 1276 */     ArrayList activeThreads = getActiveThreads(oldblock);
/* 1277 */     if (activeThreads != null) {
/* 1278 */       return activeThreads;
/*      */     }
/*      */ 
/* 1282 */     File blockFile = findBlockFile(oldblock.getBlockId());
/* 1283 */     if (blockFile == null) {
/* 1284 */       throw new IOException(new StringBuilder().append("Block ").append(oldblock).append(" does not exist.").toString());
/*      */     }
/*      */ 
/* 1287 */     File oldMetaFile = findMetaFile(blockFile);
/* 1288 */     long oldgs = parseGenerationStamp(blockFile, oldMetaFile);
/*      */ 
/* 1293 */     if (oldgs > newblock.getGenerationStamp()) {
/* 1294 */       throw new IOException(new StringBuilder().append("Cannot update block (id=").append(newblock.getBlockId()).append(") generation stamp from ").append(oldgs).append(" to ").append(newblock.getGenerationStamp()).toString());
/*      */     }
/*      */ 
/* 1300 */     if (newblock.getNumBytes() > oldblock.getNumBytes()) {
/* 1301 */       throw new IOException(new StringBuilder().append("Cannot update block file (=").append(blockFile).append(") length from ").append(oldblock.getNumBytes()).append(" to ").append(newblock.getNumBytes()).toString());
/*      */     }
/*      */ 
/* 1308 */     File tmpMetaFile = new File(oldMetaFile.getParent(), new StringBuilder().append(oldMetaFile.getName()).append("_tmp").append(newblock.getGenerationStamp()).toString());
/*      */ 
/* 1310 */     if (!oldMetaFile.renameTo(tmpMetaFile)) {
/* 1311 */       throw new IOException(new StringBuilder().append("Cannot rename block meta file to ").append(tmpMetaFile).toString());
/*      */     }
/*      */ 
/* 1314 */     if (newblock.getNumBytes() < oldblock.getNumBytes()) {
/* 1315 */       truncateBlock(blockFile, tmpMetaFile, oldblock.getNumBytes(), newblock.getNumBytes());
/*      */     }
/*      */ 
/* 1319 */     File newMetaFile = getMetaFile(blockFile, newblock);
/* 1320 */     if (!tmpMetaFile.renameTo(newMetaFile)) {
/* 1321 */       throw new IOException(new StringBuilder().append("Cannot rename tmp meta file to ").append(newMetaFile).toString());
/*      */     }
/*      */ 
/* 1324 */     updateBlockMap(this.ongoingCreates, oldblock, newblock);
/* 1325 */     updateBlockMap(this.volumeMap, oldblock, newblock);
/*      */ 
/* 1329 */     validateBlockMetadata(newblock);
/* 1330 */     return null;
/*      */   }
/*      */ 
/*      */   static void truncateBlock(File blockFile, File metaFile, long oldlen, long newlen) throws IOException
/*      */   {
/* 1335 */     if (newlen == oldlen) {
/* 1336 */       return;
/*      */     }
/* 1338 */     if (newlen > oldlen) {
/* 1339 */       throw new IOException(new StringBuilder().append("Cannot truncate block to from oldlen (=").append(oldlen).append(") to newlen (=").append(newlen).append(")").toString());
/*      */     }
/*      */ 
/* 1343 */     if (newlen == 0L)
/*      */     {
/* 1346 */       RandomAccessFile blockRAF = new RandomAccessFile(blockFile, "rw");
/*      */       try
/*      */       {
/* 1349 */         blockRAF.setLength(newlen);
/*      */       } finally {
/* 1351 */         blockRAF.close();
/*      */       }
/*      */ 
/* 1354 */       RandomAccessFile metaRAF = new RandomAccessFile(metaFile, "rw");
/*      */       try {
/* 1356 */         metaRAF.setLength(BlockMetadataHeader.getHeaderSize());
/*      */       } finally {
/* 1358 */         metaRAF.close();
/*      */       }
/* 1360 */       return;
/*      */     }
/* 1362 */     DataChecksum dcs = BlockMetadataHeader.readHeader(metaFile).getChecksum();
/* 1363 */     int checksumsize = dcs.getChecksumSize();
/* 1364 */     int bpc = dcs.getBytesPerChecksum();
/* 1365 */     long newChunkCount = (newlen - 1L) / bpc + 1L;
/* 1366 */     long newmetalen = BlockMetadataHeader.getHeaderSize() + newChunkCount * checksumsize;
/* 1367 */     long lastchunkoffset = (newChunkCount - 1L) * bpc;
/* 1368 */     int lastchunksize = (int)(newlen - lastchunkoffset);
/* 1369 */     byte[] b = new byte[Math.max(lastchunksize, checksumsize)];
/*      */ 
/* 1371 */     RandomAccessFile blockRAF = new RandomAccessFile(blockFile, "rw");
/*      */     try
/*      */     {
/* 1374 */       blockRAF.setLength(newlen);
/*      */ 
/* 1377 */       blockRAF.seek(lastchunkoffset);
/* 1378 */       blockRAF.readFully(b, 0, lastchunksize);
/*      */     } finally {
/* 1380 */       blockRAF.close();
/*      */     }
/*      */ 
/* 1384 */     dcs.update(b, 0, lastchunksize);
/* 1385 */     dcs.writeValue(b, 0, false);
/*      */ 
/* 1388 */     RandomAccessFile metaRAF = new RandomAccessFile(metaFile, "rw");
/*      */     try {
/* 1390 */       metaRAF.setLength(newmetalen);
/* 1391 */       metaRAF.seek(newmetalen - checksumsize);
/* 1392 */       metaRAF.write(b, 0, checksumsize);
/*      */     } finally {
/* 1394 */       metaRAF.close();
/*      */     }
/*      */   }
/*      */ 
/*      */   static IOException getCauseIfDiskError(IOException ioe)
/*      */   {
/* 1405 */     if ((ioe.getMessage() != null) && (ioe.getMessage().startsWith("Possible disk error on file creation: "))) {
/* 1406 */       return (IOException)ioe.getCause();
/*      */     }
/* 1408 */     return null;
/*      */   }
/*      */ 
/*      */   public FSDatasetInterface.BlockWriteStreams writeToBlock(Block b, boolean isRecovery, boolean replicationRequest)
/*      */     throws IOException
/*      */   {
/* 1426 */     if (isValidBlock(b)) {
/* 1427 */       if (!isRecovery) {
/* 1428 */         throw new BlockAlreadyExistsException(new StringBuilder().append("Block ").append(b).append(" is valid, and cannot be written to.").toString());
/*      */       }
/*      */ 
/* 1435 */       detachBlock(b, 1);
/*      */     }
/* 1437 */     long blockSize = b.getNumBytes();
/*      */ 
/* 1442 */     File f = null;
/* 1443 */     List threads = null;
/* 1444 */     synchronized (this)
/*      */     {
/* 1448 */       ActiveFile activeFile = (ActiveFile)this.ongoingCreates.get(b);
/* 1449 */       if (activeFile != null) {
/* 1450 */         f = activeFile.file;
/* 1451 */         threads = activeFile.threads;
/*      */ 
/* 1453 */         if (!isRecovery) {
/* 1454 */           throw new BlockAlreadyExistsException(new StringBuilder().append("Block ").append(b).append(" has already been started (though not completed), and thus cannot be created.").toString());
/*      */         }
/*      */ 
/* 1457 */         for (Thread thread : threads) {
/* 1458 */           thread.interrupt();
/*      */         }
/*      */ 
/* 1461 */         this.ongoingCreates.remove(b);
/*      */       }
/* 1463 */       FSVolume v = null;
/* 1464 */       if (!isRecovery) {
/* 1465 */         v = this.volumes.getNextVolume(blockSize);
/*      */ 
/* 1467 */         f = createTmpFile(v, b, replicationRequest);
/* 1468 */       } else if (f != null) {
/* 1469 */         DataNode.LOG.info(new StringBuilder().append("Reopen already-open Block for append ").append(b).toString());
/*      */ 
/* 1471 */         v = ((DatanodeBlockInfo)this.volumeMap.get(b)).getVolume();
/* 1472 */         this.volumeMap.put(b, new DatanodeBlockInfo(v, f));
/*      */       }
/*      */       else {
/* 1475 */         DataNode.LOG.info(new StringBuilder().append("Reopen for append ").append(b).toString());
/* 1476 */         v = ((DatanodeBlockInfo)this.volumeMap.get(b)).getVolume();
/* 1477 */         f = createTmpFile(v, b, replicationRequest);
/* 1478 */         File blkfile = getBlockFile(b);
/* 1479 */         File oldmeta = getMetaFile(b);
/* 1480 */         File newmeta = getMetaFile(f, b);
/*      */ 
/* 1483 */         DataNode.LOG.debug(new StringBuilder().append("Renaming ").append(oldmeta).append(" to ").append(newmeta).toString());
/* 1484 */         if (!oldmeta.renameTo(newmeta)) {
/* 1485 */           throw new IOException(new StringBuilder().append("Block ").append(b).append(" reopen failed. ").append(" Unable to move meta file  ").append(oldmeta).append(" to tmp dir ").append(newmeta).toString());
/*      */         }
/*      */ 
/* 1491 */         DataNode.LOG.debug(new StringBuilder().append("Renaming ").append(blkfile).append(" to ").append(f).toString());
/* 1492 */         if (!blkfile.renameTo(f)) {
/* 1493 */           if (!f.delete()) {
/* 1494 */             throw new IOException(new StringBuilder().append(b).append(" reopen failed. ").append(" Unable to remove file ").append(f).toString());
/*      */           }
/*      */ 
/* 1497 */           if (!blkfile.renameTo(f)) {
/* 1498 */             throw new IOException(new StringBuilder().append(b).append(" reopen failed. ").append(" Unable to move block file ").append(blkfile).append(" to tmp dir ").append(f).toString());
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1504 */       if (f == null) {
/* 1505 */         DataNode.LOG.warn(new StringBuilder().append(b).append(" reopen failed. Unable to locate tmp file").toString());
/* 1506 */         throw new IOException(new StringBuilder().append("Block ").append(b).append(" reopen failed ").append(" Unable to locate tmp file.").toString());
/*      */       }
/*      */ 
/* 1512 */       if (replicationRequest)
/* 1513 */         this.volumeMap.put(b, new DatanodeBlockInfo(v));
/*      */       else {
/* 1515 */         this.volumeMap.put(b, new DatanodeBlockInfo(v, f));
/*      */       }
/* 1517 */       this.ongoingCreates.put(b, new ActiveFile(f, threads));
/*      */     }
/*      */     try
/*      */     {
/* 1521 */       if (threads != null)
/* 1522 */         for (Thread thread : threads)
/* 1523 */           thread.join();
/*      */     }
/*      */     catch (InterruptedException e)
/*      */     {
/* 1527 */       throw new IOException("Recovery waiting for thread interrupted.");
/*      */     }
/*      */ 
/* 1535 */     File metafile = getMetaFile(f, b);
/* 1536 */     DataNode.LOG.debug(new StringBuilder().append("writeTo blockfile is ").append(f).append(" of size ").append(f.length()).toString());
/* 1537 */     DataNode.LOG.debug(new StringBuilder().append("writeTo metafile is ").append(metafile).append(" of size ").append(metafile.length()).toString());
/* 1538 */     return createBlockWriteStreams(f, metafile);
/*      */   }
/*      */ 
/*      */   public long getChannelPosition(Block b, FSDatasetInterface.BlockWriteStreams streams)
/*      */     throws IOException
/*      */   {
/* 1547 */     FileOutputStream file = (FileOutputStream)streams.dataOut;
/* 1548 */     return file.getChannel().position();
/*      */   }
/*      */ 
/*      */   public void setChannelPosition(Block b, FSDatasetInterface.BlockWriteStreams streams, long dataOffset, long ckOffset)
/*      */     throws IOException
/*      */   {
/* 1558 */     FileOutputStream file = (FileOutputStream)streams.dataOut;
/* 1559 */     if (file.getChannel().size() < dataOffset) {
/* 1560 */       String msg = new StringBuilder().append("Trying to change block file offset of block ").append(b).append(" file ").append(((DatanodeBlockInfo)this.volumeMap.get(b)).getVolume().getTmpFile(b)).append(" to ").append(dataOffset).append(" but actual size of file is ").append(file.getChannel().size()).toString();
/*      */ 
/* 1565 */       throw new IOException(msg);
/*      */     }
/* 1567 */     file.getChannel().position(dataOffset);
/* 1568 */     file = (FileOutputStream)streams.checksumOut;
/* 1569 */     file.getChannel().position(ckOffset);
/*      */   }
/*      */ 
/*      */   synchronized File createTmpFile(FSVolume vol, Block blk, boolean replicationRequest) throws IOException
/*      */   {
/* 1574 */     if (vol == null) {
/* 1575 */       vol = ((DatanodeBlockInfo)this.volumeMap.get(blk)).getVolume();
/* 1576 */       if (vol == null) {
/* 1577 */         throw new IOException(new StringBuilder().append("Could not find volume for block ").append(blk).toString());
/*      */       }
/*      */     }
/* 1580 */     return vol.createTmpFile(blk, replicationRequest);
/*      */   }
/*      */ 
/*      */   public void finalizeBlock(Block b)
/*      */     throws IOException
/*      */   {
/* 1594 */     finalizeBlockInternal(b, false);
/*      */   }
/*      */ 
/*      */   public void finalizeBlockIfNeeded(Block b) throws IOException
/*      */   {
/* 1599 */     finalizeBlockInternal(b, true);
/*      */   }
/*      */ 
/*      */   private synchronized void finalizeBlockInternal(Block b, boolean reFinalizeOk)
/*      */     throws IOException
/*      */   {
/* 1607 */     ActiveFile activeFile = (ActiveFile)this.ongoingCreates.get(b);
/* 1608 */     if (activeFile == null) {
/* 1609 */       if (reFinalizeOk) {
/* 1610 */         return;
/*      */       }
/* 1612 */       throw new IOException(new StringBuilder().append("Block ").append(b).append(" is already finalized.").toString());
/*      */     }
/*      */ 
/* 1615 */     File f = activeFile.file;
/* 1616 */     if ((f == null) || (!f.exists())) {
/* 1617 */       throw new IOException(new StringBuilder().append("No temporary file ").append(f).append(" for block ").append(b).toString());
/*      */     }
/* 1619 */     FSVolume v = ((DatanodeBlockInfo)this.volumeMap.get(b)).getVolume();
/* 1620 */     if (v == null) {
/* 1621 */       throw new IOException(new StringBuilder().append("No volume for temporary file ").append(f).append(" for block ").append(b).toString());
/*      */     }
/*      */ 
/* 1625 */     File dest = null;
/* 1626 */     dest = v.addBlock(b, f);
/* 1627 */     this.volumeMap.put(b, new DatanodeBlockInfo(v, dest));
/* 1628 */     this.ongoingCreates.remove(b);
/*      */   }
/*      */ 
/*      */   private synchronized boolean isFinalized(Block b)
/*      */   {
/* 1636 */     FSVolume v = ((DatanodeBlockInfo)this.volumeMap.get(b)).getVolume();
/* 1637 */     if (v == null) {
/* 1638 */       DataNode.LOG.warn(new StringBuilder().append("No volume for block ").append(b).toString());
/* 1639 */       return false;
/*      */     }
/* 1641 */     ActiveFile activeFile = (ActiveFile)this.ongoingCreates.get(b);
/* 1642 */     if (activeFile == null) {
/* 1643 */       return true;
/*      */     }
/* 1645 */     File f = activeFile.file;
/* 1646 */     if ((f == null) || (!f.exists()))
/*      */     {
/* 1648 */       DataNode.LOG.warn(new StringBuilder().append("No temporary file ").append(f).append(" for block ").append(b).toString());
/*      */     }
/* 1650 */     return false;
/*      */   }
/*      */ 
/*      */   public synchronized void unfinalizeBlock(Block b)
/*      */     throws IOException
/*      */   {
/* 1658 */     ActiveFile activefile = (ActiveFile)this.ongoingCreates.remove(b);
/* 1659 */     if (activefile == null) {
/* 1660 */       return;
/*      */     }
/* 1662 */     this.volumeMap.remove(b);
/*      */ 
/* 1665 */     if (delBlockFromDisk(activefile.file, getMetaFile(activefile.file, b), b))
/* 1666 */       DataNode.LOG.warn(new StringBuilder().append("Block ").append(b).append(" unfinalized and removed. ").toString());
/*      */   }
/*      */ 
/*      */   private boolean delBlockFromDisk(File blockFile, File metaFile, Block b)
/*      */   {
/* 1678 */     if (blockFile == null) {
/* 1679 */       DataNode.LOG.warn(new StringBuilder().append("No file exists for block: ").append(b).toString());
/* 1680 */       return true;
/*      */     }
/*      */ 
/* 1683 */     if (!blockFile.delete()) {
/* 1684 */       DataNode.LOG.warn(new StringBuilder().append("Not able to delete the block file: ").append(blockFile).toString());
/* 1685 */       return false;
/*      */     }
/* 1687 */     if ((metaFile != null) && (!metaFile.delete())) {
/* 1688 */       DataNode.LOG.warn(new StringBuilder().append("Not able to delete the meta block file: ").append(metaFile).toString());
/*      */ 
/* 1690 */       return false;
/*      */     }
/*      */ 
/* 1693 */     return true;
/*      */   }
/*      */ 
/*      */   public Block[] getBlocksBeingWrittenReport()
/*      */   {
/* 1700 */     TreeSet blockSet = new TreeSet();
/* 1701 */     this.volumes.getBlocksBeingWrittenInfo(blockSet);
/* 1702 */     Block[] blockTable = new Block[blockSet.size()];
/* 1703 */     int i = 0;
/* 1704 */     for (Iterator it = blockSet.iterator(); it.hasNext(); i++) {
/* 1705 */       blockTable[i] = ((Block)it.next());
/*      */     }
/* 1707 */     return blockTable;
/*      */   }
/*      */ 
/*      */   public void requestAsyncBlockReport()
/*      */   {
/* 1712 */     this.asyncBlockReport.request();
/*      */   }
/*      */ 
/*      */   public boolean isAsyncBlockReportReady()
/*      */   {
/* 1717 */     return this.asyncBlockReport.isReady();
/*      */   }
/*      */ 
/*      */   public Block[] retrieveAsyncBlockReport()
/*      */   {
/* 1722 */     HashMap seenOnDisk = this.asyncBlockReport.getAndReset();
/* 1723 */     return reconcileRoughBlockScan(seenOnDisk);
/*      */   }
/*      */ 
/*      */   public Block[] getBlockReport()
/*      */   {
/* 1731 */     long st = System.currentTimeMillis();
/* 1732 */     HashMap seenOnDisk = roughBlockScan();
/*      */ 
/* 1735 */     DataNode.LOG.info(new StringBuilder().append("Generated rough (lockless) block report in ").append(System.currentTimeMillis() - st).append(" ms").toString());
/*      */ 
/* 1737 */     return reconcileRoughBlockScan(seenOnDisk);
/*      */   }
/*      */ 
/*      */   private Block[] reconcileRoughBlockScan(HashMap<Block, File> seenOnDisk)
/*      */   {
/*      */     Set blockReport;
/* 1742 */     synchronized (this) {
/* 1743 */       long st = System.currentTimeMillis();
/*      */ 
/* 1745 */       reconcileRoughBlockScan(seenOnDisk, this.volumeMap, this.ongoingCreates);
/* 1746 */       if (DataNode.LOG.isDebugEnabled()) {
/* 1747 */         DataNode.LOG.debug(new StringBuilder().append("Reconciled block report with current state in ").append(System.currentTimeMillis() - st).append("ms").toString());
/*      */       }
/*      */ 
/* 1751 */       blockReport = seenOnDisk.keySet();
/*      */     }
/*      */ 
/* 1754 */     return (Block[])blockReport.toArray(new Block[0]);
/*      */   }
/*      */ 
/*      */   HashMap<Block, File> roughBlockScan()
/*      */   {
/*      */     int expectedNumBlocks;
/* 1764 */     synchronized (this) {
/* 1765 */       expectedNumBlocks = this.volumeMap.size();
/*      */     }
/* 1767 */     HashMap seenOnDisk = new HashMap(expectedNumBlocks, 1.1F);
/*      */ 
/* 1769 */     this.volumes.scanBlockFilesInconsistent(seenOnDisk);
/* 1770 */     return seenOnDisk;
/*      */   }
/*      */ 
/*      */   static void reconcileRoughBlockScan(Map<Block, File> seenOnDisk, Map<Block, DatanodeBlockInfo> volumeMap, Map<Block, ActiveFile> ongoingCreates)
/*      */   {
/* 1778 */     int numDeletedAfterScan = 0;
/* 1779 */     int numAddedAfterScan = 0;
/* 1780 */     int numOngoingIgnored = 0;
/*      */ 
/* 1784 */     Iterator iter = seenOnDisk.entrySet().iterator();
/* 1785 */     while (iter.hasNext()) {
/* 1786 */       Map.Entry entry = (Map.Entry)iter.next();
/* 1787 */       Block b = (Block)entry.getKey();
/*      */ 
/* 1789 */       if ((!volumeMap.containsKey(b)) || (ongoingCreates.containsKey(b))) {
/* 1790 */         File blockFile = (File)entry.getValue();
/* 1791 */         File metaFile = getMetaFile(blockFile, b);
/* 1792 */         if ((!blockFile.exists()) || (!metaFile.exists()))
/*      */         {
/* 1796 */           iter.remove();
/* 1797 */           numDeletedAfterScan++;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1804 */     for (Map.Entry entry : volumeMap.entrySet()) {
/* 1805 */       Block b = (Block)entry.getKey();
/* 1806 */       if (ongoingCreates.containsKey(b))
/*      */       {
/* 1808 */         numOngoingIgnored++;
/*      */       }
/*      */       else {
/* 1811 */         DatanodeBlockInfo info = (DatanodeBlockInfo)entry.getValue();
/* 1812 */         if ((!seenOnDisk.containsKey(b)) && (info.getFile().exists()))
/*      */         {
/* 1814 */           Block toAdd = new Block(b.getBlockId(), info.getFile().length(), b.getGenerationStamp());
/*      */ 
/* 1816 */           seenOnDisk.put(toAdd, info.getFile());
/* 1817 */           numAddedAfterScan++;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1824 */     if (numDeletedAfterScan + numAddedAfterScan + numOngoingIgnored > 0)
/* 1825 */       DataNode.LOG.info(new StringBuilder().append("Reconciled asynchronous block scan with filesystem. ").append(numDeletedAfterScan).append(" blocks concurrently deleted during scan, ").append(numAddedAfterScan).append(" blocks concurrently added during scan, ").append(numOngoingIgnored).append(" ongoing creations ignored").toString());
/*      */   }
/*      */ 
/*      */   public boolean isValidBlock(Block b)
/*      */   {
/* 1836 */     File f = null;
/*      */     try {
/* 1838 */       f = validateBlockFile(b);
/*      */     } catch (IOException e) {
/* 1840 */       org.mortbay.log.Log.warn(new StringBuilder().append("Block ").append(b).append(" is not valid:").toString(), e);
/*      */     }
/* 1842 */     return f != null ? isFinalized(b) : false;
/*      */   }
/*      */ 
/*      */   File validateBlockFile(Block b)
/*      */     throws IOException
/*      */   {
/* 1850 */     File f = getFile(b);
/*      */ 
/* 1852 */     if (f != null) {
/* 1853 */       if (f.exists()) {
/* 1854 */         return f;
/*      */       }
/*      */ 
/* 1857 */       DataNode datanode = DataNode.getDataNode();
/* 1858 */       datanode.checkDiskError();
/*      */     }
/*      */ 
/* 1861 */     if (InterDatanodeProtocol.LOG.isDebugEnabled()) {
/* 1862 */       InterDatanodeProtocol.LOG.debug(new StringBuilder().append("b=").append(b).append(", f=").append(f).toString());
/*      */     }
/* 1864 */     return null;
/*      */   }
/*      */ 
/*      */   public synchronized void validateBlockMetadata(Block b) throws IOException
/*      */   {
/* 1869 */     DatanodeBlockInfo info = (DatanodeBlockInfo)this.volumeMap.get(b);
/* 1870 */     if (info == null) {
/* 1871 */       throw new IOException(new StringBuilder().append("Block ").append(b).append(" does not exist in volumeMap.").toString());
/*      */     }
/* 1873 */     FSVolume v = info.getVolume();
/* 1874 */     File tmp = v.getTmpFile(b);
/* 1875 */     File f = getFile(b);
/* 1876 */     if (f == null) {
/* 1877 */       f = tmp;
/*      */     }
/* 1879 */     if (f == null) {
/* 1880 */       throw new IOException(new StringBuilder().append("Block ").append(b).append(" does not exist on disk.").toString());
/*      */     }
/* 1882 */     if (!f.exists()) {
/* 1883 */       throw new IOException(new StringBuilder().append("Block ").append(b).append(" block file ").append(f).append(" does not exist on disk.").toString());
/*      */     }
/*      */ 
/* 1887 */     if (b.getNumBytes() != f.length()) {
/* 1888 */       throw new IOException(new StringBuilder().append("Block ").append(b).append(" length is ").append(b.getNumBytes()).append(" does not match block file length ").append(f.length()).toString());
/*      */     }
/*      */ 
/* 1893 */     File meta = getMetaFile(f, b);
/* 1894 */     if (meta == null) {
/* 1895 */       throw new IOException(new StringBuilder().append("Block ").append(b).append(" metafile does not exist.").toString());
/*      */     }
/*      */ 
/* 1898 */     if (!meta.exists()) {
/* 1899 */       throw new IOException(new StringBuilder().append("Block ").append(b).append(" metafile ").append(meta).append(" does not exist on disk.").toString());
/*      */     }
/*      */ 
/* 1903 */     if (meta.length() == 0L) {
/* 1904 */       throw new IOException(new StringBuilder().append("Block ").append(b).append(" metafile ").append(meta).append(" is empty.").toString());
/*      */     }
/* 1906 */     long stamp = parseGenerationStamp(f, meta);
/* 1907 */     if (stamp != b.getGenerationStamp()) {
/* 1908 */       throw new IOException(new StringBuilder().append("Block ").append(b).append(" genstamp is ").append(b.getGenerationStamp()).append(" does not match meta file stamp ").append(stamp).toString());
/*      */     }
/*      */ 
/* 1914 */     DataChecksum dcs = BlockMetadataHeader.readHeader(meta).getChecksum();
/* 1915 */     int checksumsize = dcs.getChecksumSize();
/* 1916 */     long actual = meta.length() - BlockMetadataHeader.getHeaderSize();
/* 1917 */     long numChunksInMeta = actual / checksumsize;
/* 1918 */     if (actual % checksumsize != 0L) {
/* 1919 */       throw new IOException(new StringBuilder().append("Block ").append(b).append(" has a checksum file of size ").append(meta.length()).append(" but it does not align with checksum size of ").append(checksumsize).toString());
/*      */     }
/*      */ 
/* 1924 */     int bpc = dcs.getBytesPerChecksum();
/* 1925 */     long minDataSize = (numChunksInMeta - 1L) * bpc;
/* 1926 */     long maxDataSize = numChunksInMeta * bpc;
/* 1927 */     if ((f.length() > maxDataSize) || (f.length() <= minDataSize))
/* 1928 */       throw new IOException(new StringBuilder().append("Block ").append(b).append(" is of size ").append(f.length()).append(" but has ").append(numChunksInMeta + 1L).append(" checksums and each checksum size is ").append(checksumsize).append(" bytes.").toString());
/*      */   }
/*      */ 
/*      */   public void invalidate(Block[] invalidBlks)
/*      */     throws IOException
/*      */   {
/* 1945 */     boolean error = false;
/* 1946 */     for (int i = 0; i < invalidBlks.length; i++) {
/* 1947 */       File f = null;
/*      */       FSVolume v;
/* 1949 */       synchronized (this) {
/* 1950 */         f = getFile(invalidBlks[i]);
/* 1951 */         DatanodeBlockInfo dinfo = (DatanodeBlockInfo)this.volumeMap.get(invalidBlks[i]);
/* 1952 */         if (dinfo == null) {
/* 1953 */           DataNode.LOG.warn(new StringBuilder().append("Unexpected error trying to delete block ").append(invalidBlks[i]).append(". BlockInfo not found in volumeMap.").toString());
/*      */ 
/* 1956 */           error = true;
/* 1957 */           continue;
/*      */         }
/* 1959 */         v = dinfo.getVolume();
/* 1960 */         if (f == null) {
/* 1961 */           DataNode.LOG.warn(new StringBuilder().append("Unexpected error trying to delete block ").append(invalidBlks[i]).append(". Block not found in blockMap.").append(v == null ? " " : " Block found in volumeMap.").toString());
/*      */ 
/* 1965 */           error = true;
/* 1966 */           continue;
/*      */         }
/* 1968 */         if (v == null) {
/* 1969 */           DataNode.LOG.warn(new StringBuilder().append("Unexpected error trying to delete block ").append(invalidBlks[i]).append(". No volume for this block.").append(" Block found in blockMap. ").append(f).append(".").toString());
/*      */ 
/* 1973 */           error = true;
/* 1974 */           continue;
/*      */         }
/* 1976 */         File parent = f.getParentFile();
/* 1977 */         if (parent == null) {
/* 1978 */           DataNode.LOG.warn(new StringBuilder().append("Unexpected error trying to delete block ").append(invalidBlks[i]).append(". Parent not found for file ").append(f).append(".").toString());
/*      */ 
/* 1981 */           error = true;
/* 1982 */           continue;
/*      */         }
/* 1984 */         v.clearPath(parent);
/* 1985 */         this.volumeMap.remove(invalidBlks[i]);
/*      */       }
/* 1987 */       File metaFile = getMetaFile(f, invalidBlks[i]);
/* 1988 */       long dfsBytes = f.length() + metaFile.length();
/*      */ 
/* 1991 */       this.asyncDiskService.deleteAsync(v, f, metaFile, dfsBytes, invalidBlks[i].toString());
/*      */     }
/* 1993 */     if (error)
/* 1994 */       throw new IOException("Error in deleting blocks.");
/*      */   }
/*      */ 
/*      */   public synchronized File getFile(Block b)
/*      */   {
/* 2002 */     DatanodeBlockInfo info = (DatanodeBlockInfo)this.volumeMap.get(b);
/* 2003 */     if (info != null) {
/* 2004 */       return info.getFile();
/*      */     }
/* 2006 */     return null;
/*      */   }
/*      */ 
/*      */   public void checkDataDir()
/*      */     throws DiskChecker.DiskErrorException
/*      */   {
/* 2016 */     long total_blocks = 0L; long removed_blocks = 0L;
/* 2017 */     List failed_vols = this.volumes.checkDirs();
/*      */ 
/* 2020 */     if (failed_vols == null) {
/* 2021 */       return;
/*      */     }
/*      */ 
/* 2025 */     long mlsec = System.currentTimeMillis();
/* 2026 */     synchronized (this) {
/* 2027 */       Iterator ib = this.volumeMap.keySet().iterator();
/*      */       Block b;
/*      */       FSVolume vol;
/* 2028 */       while (ib.hasNext()) {
/* 2029 */         b = (Block)ib.next();
/* 2030 */         total_blocks += 1L;
/*      */ 
/* 2032 */         vol = ((DatanodeBlockInfo)this.volumeMap.get(b)).getVolume();
/* 2033 */         for (FSVolume fv : failed_vols) {
/* 2034 */           if (vol == fv) {
/* 2035 */             DataNode.LOG.warn(new StringBuilder().append("removing block ").append(b.getBlockId()).append(" from vol ").append(vol.dataDir.dir.getAbsolutePath()).toString());
/*      */ 
/* 2037 */             ib.remove();
/* 2038 */             removed_blocks += 1L;
/* 2039 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 2044 */     mlsec = System.currentTimeMillis() - mlsec;
/* 2045 */     DataNode.LOG.warn(new StringBuilder().append(">>>>>>>>>>>>Removed ").append(removed_blocks).append(" out of ").append(total_blocks).append("(took ").append(mlsec).append(" millisecs)").toString());
/*      */ 
/* 2049 */     StringBuilder sb = new StringBuilder();
/* 2050 */     for (FSVolume fv : failed_vols) {
/* 2051 */       sb.append(new StringBuilder().append(fv.dataDir.dir.getAbsolutePath()).append(";").toString());
/*      */     }
/*      */ 
/* 2054 */     throw new DiskChecker.DiskErrorException(new StringBuilder().append("DataNode failed volumes:").append(sb).toString());
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/* 2060 */     return new StringBuilder().append("FSDataset{dirpath='").append(this.volumes).append("'}").toString();
/*      */   }
/*      */ 
/*      */   void registerMBean(String storageId)
/*      */   {
/*      */     String storageName;
/*      */     String storageName;
/* 2076 */     if ((storageId == null) || (storageId.equals("")))
/* 2077 */       storageName = new StringBuilder().append("UndefinedStorageId").append(this.rand.nextInt()).toString();
/*      */     else
/* 2079 */       storageName = storageId;
/*      */     try
/*      */     {
/* 2082 */       StandardMBean bean = new StandardMBean(this, FSDatasetMBean.class);
/* 2083 */       this.mbeanName = MBeans.register("DataNode", new StringBuilder().append("FSDatasetState-").append(storageName).toString(), bean);
/*      */     } catch (NotCompliantMBeanException e) {
/* 2085 */       e.printStackTrace();
/*      */     }
/*      */ 
/* 2088 */     DataNode.LOG.info("Registered FSDatasetStatusMBean");
/*      */   }
/*      */ 
/*      */   public void shutdown() {
/* 2092 */     if (this.mbeanName != null) {
/* 2093 */       MBeans.unregister(this.mbeanName);
/*      */     }
/* 2095 */     if (this.asyncBlockReport != null) {
/* 2096 */       this.asyncBlockReport.shutdown();
/*      */     }
/*      */ 
/* 2099 */     if (this.asyncDiskService != null) {
/* 2100 */       this.asyncDiskService.shutdown();
/*      */     }
/*      */ 
/* 2103 */     if (this.volumes != null)
/* 2104 */       for (FSVolume volume : this.volumes.volumes)
/* 2105 */         if (volume != null)
/* 2106 */           volume.dfsUsage.shutdown();
/*      */   }
/*      */ 
/*      */   public String getStorageInfo()
/*      */   {
/* 2113 */     return toString();
/*      */   }
/*      */ 
/*      */   synchronized Collection<VolumeInfo> getVolumeInfo()
/*      */   {
/* 2134 */     Collection info = new ArrayList();
/* 2135 */     synchronized (this.volumes.volumes) {
/* 2136 */       for (FSVolume volume : this.volumes.volumes) {
/* 2137 */         long used = 0L;
/*      */         try {
/* 2139 */           used = volume.getDfsUsed();
/*      */         } catch (IOException e) {
/* 2141 */           DataNode.LOG.warn(e.getMessage());
/*      */         }
/*      */ 
/* 2144 */         long free = 0L;
/*      */         try {
/* 2146 */           free = volume.getAvailable();
/*      */         } catch (IOException e) {
/* 2148 */           DataNode.LOG.warn(e.getMessage());
/*      */         }
/*      */ 
/* 2151 */         info.add(new VolumeInfo(volume.toString(), used, free, volume.getReserved()));
/*      */       }
/*      */ 
/* 2154 */       return info;
/*      */     }
/*      */   }
/*      */ 
/*      */   public BlockRecoveryInfo startBlockRecovery(long blockId)
/*      */     throws IOException
/*      */   {
/* 2161 */     Block stored = getStoredBlock(blockId);
/*      */ 
/* 2163 */     if (stored == null) {
/* 2164 */       return null;
/*      */     }
/*      */ 
/*      */     while (true)
/*      */     {
/* 2170 */       DataNode.LOG.debug(new StringBuilder().append("Interrupting active writer threads for block ").append(stored).toString());
/*      */ 
/* 2172 */       List activeThreads = getActiveThreads(stored);
/* 2173 */       if ((activeThreads == null) || 
/* 2174 */         (interruptAndJoinThreads(activeThreads))) {
/*      */         break;
/*      */       }
/*      */     }
/* 2178 */     synchronized (this) {
/* 2179 */       ActiveFile activeFile = (ActiveFile)this.ongoingCreates.get(stored);
/* 2180 */       boolean isRecovery = (activeFile != null) && (activeFile.wasRecoveredOnStartup);
/*      */ 
/* 2183 */       BlockRecoveryInfo info = new BlockRecoveryInfo(stored, isRecovery);
/*      */ 
/* 2185 */       if (DataNode.LOG.isDebugEnabled()) {
/* 2186 */         DataNode.LOG.debug(new StringBuilder().append("getBlockMetaDataInfo successful block=").append(stored).append(" length ").append(stored.getNumBytes()).append(" genstamp ").append(stored.getGenerationStamp()).toString());
/*      */       }
/*      */ 
/* 2193 */       validateBlockMetadata(stored);
/* 2194 */       return info;
/*      */     }
/*      */   }
/*      */ 
/*      */   static class AsyncBlockReport
/*      */     implements Runnable
/*      */   {
/*      */     private final Thread thread;
/*      */     private final FSDataset fsd;
/* 2208 */     boolean requested = false;
/* 2209 */     boolean shouldRun = true;
/* 2210 */     private HashMap<Block, File> scan = null;
/*      */ 
/*      */     AsyncBlockReport(FSDataset fsd) {
/* 2213 */       this.fsd = fsd;
/* 2214 */       this.thread = new Thread(this, "Async Block Report Generator");
/* 2215 */       this.thread.setDaemon(true);
/*      */     }
/*      */ 
/*      */     void start() {
/* 2219 */       this.thread.start();
/*      */     }
/*      */ 
/*      */     synchronized void shutdown() {
/* 2223 */       this.shouldRun = false;
/* 2224 */       this.thread.interrupt();
/*      */     }
/*      */ 
/*      */     synchronized boolean isReady() {
/* 2228 */       return this.scan != null;
/*      */     }
/*      */ 
/*      */     synchronized HashMap<Block, File> getAndReset() {
/* 2232 */       if (!isReady()) {
/* 2233 */         throw new IllegalStateException("report not ready!");
/*      */       }
/* 2235 */       HashMap ret = this.scan;
/* 2236 */       this.scan = null;
/* 2237 */       this.requested = false;
/* 2238 */       return ret;
/*      */     }
/*      */ 
/*      */     synchronized void request() {
/* 2242 */       this.requested = true;
/* 2243 */       notifyAll();
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/* 2248 */       while (this.shouldRun)
/*      */         try {
/* 2250 */           waitForReportRequest();
/* 2251 */           assert ((this.requested) && (this.scan == null));
/*      */ 
/* 2253 */           long st = System.currentTimeMillis();
/* 2254 */           HashMap result = this.fsd.roughBlockScan();
/* 2255 */           DataNode.LOG.info("Finished asynchronous block report scan in " + (System.currentTimeMillis() - st) + "ms");
/*      */ 
/* 2258 */           synchronized (this) {
/* 2259 */             assert (this.scan == null);
/* 2260 */             this.scan = result;
/*      */           }
/*      */         } catch (InterruptedException ie) {
/*      */         }
/*      */         catch (Throwable t) {
/* 2265 */           DataNode.LOG.error("Async Block Report thread caught exception", t);
/*      */           try
/*      */           {
/* 2269 */             Thread.sleep(2000L);
/*      */           }
/*      */           catch (InterruptedException e)
/*      */           {
/*      */           }
/*      */         }
/*      */     }
/*      */ 
/*      */     private synchronized void waitForReportRequest() throws InterruptedException {
/* 2278 */       while ((!this.requested) || (this.scan != null))
/* 2279 */         wait(5000L);
/*      */     }
/*      */   }
/*      */ 
/*      */   static class VolumeInfo
/*      */   {
/*      */     final String directory;
/*      */     final long usedSpace;
/*      */     final long freeSpace;
/*      */     final long reservedSpace;
/*      */ 
/*      */     VolumeInfo(String dir, long usedSpace, long freeSpace, long reservedSpace)
/*      */     {
/* 2126 */       this.directory = dir;
/* 2127 */       this.usedSpace = usedSpace;
/* 2128 */       this.freeSpace = freeSpace;
/* 2129 */       this.reservedSpace = reservedSpace;
/*      */     }
/*      */   }
/*      */ 
/*      */   static class ActiveFile
/*      */   {
/*      */     final File file;
/*  800 */     final List<Thread> threads = new ArrayList(2);
/*      */     private volatile long visibleLength;
/*      */     final boolean wasRecoveredOnStartup;
/*      */ 
/*      */     ActiveFile(File f, List<Thread> list)
/*      */     {
/*  810 */       this(f, false);
/*  811 */       if (list != null) {
/*  812 */         this.threads.addAll(list);
/*      */       }
/*  814 */       this.threads.add(Thread.currentThread());
/*      */     }
/*      */ 
/*      */     public static ActiveFile createStartupRecoveryFile(File f)
/*      */     {
/*  823 */       return new ActiveFile(f, true);
/*      */     }
/*      */ 
/*      */     private ActiveFile(File f, boolean recovery) {
/*  827 */       this.file = f;
/*  828 */       this.visibleLength = f.length();
/*  829 */       this.wasRecoveredOnStartup = recovery;
/*      */     }
/*      */ 
/*      */     public long getVisibleLength() {
/*  833 */       return this.visibleLength;
/*      */     }
/*      */ 
/*      */     public void setVisibleLength(long value) {
/*  837 */       this.visibleLength = value;
/*      */     }
/*      */ 
/*      */     public String toString() {
/*  841 */       return getClass().getSimpleName() + "(file=" + this.file + ", threads=" + this.threads + ")";
/*      */     }
/*      */   }
/*      */ 
/*      */   static class FSVolumeSet
/*      */   {
/*  641 */     FSDataset.FSVolume[] volumes = null;
/*  642 */     int curVolume = 0;
/*      */ 
/*      */     FSVolumeSet(FSDataset.FSVolume[] volumes) {
/*  645 */       this.volumes = volumes;
/*      */     }
/*      */ 
/*      */     private int numberOfVolumes() {
/*  649 */       return this.volumes.length;
/*      */     }
/*      */ 
/*      */     synchronized FSDataset.FSVolume getNextVolume(long blockSize) throws IOException
/*      */     {
/*  654 */       if (this.volumes.length < 1) {
/*  655 */         throw new DiskChecker.DiskOutOfSpaceException("No more available volumes");
/*      */       }
/*      */ 
/*  660 */       if (this.curVolume >= this.volumes.length) {
/*  661 */         this.curVolume = 0;
/*      */       }
/*      */ 
/*  664 */       int startVolume = this.curVolume;
/*      */       while (true)
/*      */       {
/*  667 */         FSDataset.FSVolume volume = this.volumes[this.curVolume];
/*  668 */         this.curVolume = ((this.curVolume + 1) % this.volumes.length);
/*  669 */         if (volume.getAvailable() > blockSize) return volume;
/*  670 */         if (this.curVolume == startVolume)
/*  671 */           throw new DiskChecker.DiskOutOfSpaceException("Insufficient space for an additional block");
/*      */       }
/*      */     }
/*      */ 
/*      */     long getDfsUsed() throws IOException
/*      */     {
/*  677 */       long dfsUsed = 0L;
/*  678 */       for (int idx = 0; idx < this.volumes.length; idx++) {
/*  679 */         dfsUsed += this.volumes[idx].getDfsUsed();
/*      */       }
/*  681 */       return dfsUsed;
/*      */     }
/*      */ 
/*      */     synchronized long getCapacity() throws IOException {
/*  685 */       long capacity = 0L;
/*  686 */       for (int idx = 0; idx < this.volumes.length; idx++) {
/*  687 */         capacity += this.volumes[idx].getCapacity();
/*      */       }
/*  689 */       return capacity;
/*      */     }
/*      */ 
/*      */     synchronized long getRemaining() throws IOException {
/*  693 */       long remaining = 0L;
/*  694 */       for (int idx = 0; idx < this.volumes.length; idx++) {
/*  695 */         remaining += this.volumes[idx].getAvailable();
/*      */       }
/*  697 */       return remaining;
/*      */     }
/*      */ 
/*      */     void scanBlockFilesInconsistent(Map<Block, File> results)
/*      */     {
/*      */       FSDataset.FSVolume[] volumesCopy;
/*  704 */       synchronized (this) {
/*  705 */         volumesCopy = (FSDataset.FSVolume[])Arrays.copyOf(this.volumes, this.volumes.length);
/*      */       }
/*      */ 
/*  708 */       for (FSDataset.FSVolume vol : volumesCopy)
/*  709 */         vol.scanBlockFilesInconsistent(results);
/*      */     }
/*      */ 
/*      */     synchronized void getVolumeMap(HashMap<Block, DatanodeBlockInfo> volumeMap)
/*      */     {
/*  714 */       for (int idx = 0; idx < this.volumes.length; idx++)
/*  715 */         this.volumes[idx].getVolumeMap(volumeMap);
/*      */     }
/*      */ 
/*      */     synchronized void getBlocksBeingWrittenInfo(TreeSet<Block> blockSet)
/*      */     {
/*  720 */       long startTime = System.currentTimeMillis();
/*      */ 
/*  722 */       for (int idx = 0; idx < this.volumes.length; idx++) {
/*  723 */         this.volumes[idx].getBlocksBeingWrittenInfo(blockSet);
/*      */       }
/*      */ 
/*  726 */       long scanTime = (System.currentTimeMillis() - startTime) / 1000L;
/*  727 */       DataNode.LOG.info("Finished generating blocks being written report for " + this.volumes.length + " volumes in " + scanTime + " seconds");
/*      */     }
/*      */ 
/*      */     synchronized List<FSDataset.FSVolume> checkDirs()
/*      */     {
/*  739 */       ArrayList removed_vols = null;
/*      */ 
/*  741 */       for (int idx = 0; idx < this.volumes.length; idx++) {
/*  742 */         FSDataset.FSVolume fsv = this.volumes[idx];
/*      */         try {
/*  744 */           fsv.checkDirs();
/*      */         } catch (DiskChecker.DiskErrorException e) {
/*  746 */           DataNode.LOG.warn("Removing failed volume " + fsv + ": ", e);
/*  747 */           if (removed_vols == null) {
/*  748 */             removed_vols = new ArrayList(1);
/*      */           }
/*  750 */           removed_vols.add(this.volumes[idx]);
/*  751 */           FSDataset.FSVolume.access$200(this.volumes[idx]).shutdown();
/*  752 */           this.volumes[idx] = null;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  757 */       int removed_size = removed_vols == null ? 0 : removed_vols.size();
/*  758 */       if (removed_size > 0) {
/*  759 */         FSDataset.FSVolume[] fsvs = new FSDataset.FSVolume[this.volumes.length - removed_size];
/*  760 */         int idx = 0; for (int idy = 0; idx < this.volumes.length; idx++) {
/*  761 */           if (this.volumes[idx] != null) {
/*  762 */             fsvs[idy] = this.volumes[idx];
/*  763 */             idy++;
/*      */           }
/*      */         }
/*  766 */         this.volumes = fsvs;
/*      */       }
/*  768 */       org.mortbay.log.Log.info("Completed FSVolumeSet.checkDirs. Removed=" + removed_size + " volumes. Current volumes: " + toString());
/*      */ 
/*  771 */       return removed_vols;
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/*  776 */       StringBuffer sb = new StringBuffer();
/*  777 */       for (int idx = 0; idx < this.volumes.length; idx++) {
/*  778 */         sb.append(this.volumes[idx].toString());
/*  779 */         if (idx != this.volumes.length - 1) sb.append(",");
/*      */       }
/*  781 */       return sb.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   class FSVolume
/*      */   {
/*      */     private File currentDir;
/*      */     private FSDataset.FSDir dataDir;
/*      */     private File tmpDir;
/*      */     private File blocksBeingWritten;
/*      */     private File detachDir;
/*      */     private DF usage;
/*      */     private DU dfsUsage;
/*      */     private long reserved;
/*      */ 
/*      */     FSVolume(File currentDir, Configuration conf)
/*      */       throws IOException
/*      */     {
/*  348 */       this.reserved = conf.getLong("dfs.datanode.du.reserved", 0L);
/*  349 */       this.dataDir = new FSDataset.FSDir(FSDataset.this, currentDir);
/*  350 */       this.currentDir = currentDir;
/*  351 */       boolean durableSync = conf.getBoolean("dfs.durable.sync", true);
/*  352 */       File parent = currentDir.getParentFile();
/*      */ 
/*  354 */       this.detachDir = new File(parent, "detach");
/*  355 */       if (this.detachDir.exists()) {
/*  356 */         recoverDetachedBlocks(currentDir, this.detachDir);
/*      */       }
/*      */ 
/*  362 */       this.tmpDir = new File(parent, "tmp");
/*  363 */       if (this.tmpDir.exists()) {
/*  364 */         FileUtil.fullyDelete(this.tmpDir);
/*      */       }
/*      */ 
/*  369 */       this.blocksBeingWritten = new File(parent, "blocksBeingWritten");
/*  370 */       if (this.blocksBeingWritten.exists()) {
/*  371 */         if (durableSync)
/*  372 */           recoverBlocksBeingWritten(this.blocksBeingWritten);
/*      */         else {
/*  374 */           FileUtil.fullyDelete(this.blocksBeingWritten);
/*      */         }
/*      */       }
/*      */ 
/*  378 */       if ((!this.blocksBeingWritten.mkdirs()) && 
/*  379 */         (!this.blocksBeingWritten.isDirectory())) {
/*  380 */         throw new IOException("Mkdirs failed to create " + this.blocksBeingWritten.toString());
/*      */       }
/*      */ 
/*  383 */       if ((!this.tmpDir.mkdirs()) && 
/*  384 */         (!this.tmpDir.isDirectory())) {
/*  385 */         throw new IOException("Mkdirs failed to create " + this.tmpDir.toString());
/*      */       }
/*      */ 
/*  388 */       if ((!this.detachDir.mkdirs()) && 
/*  389 */         (!this.detachDir.isDirectory())) {
/*  390 */         throw new IOException("Mkdirs failed to create " + this.detachDir.toString());
/*      */       }
/*      */ 
/*  393 */       this.usage = new DF(parent, conf);
/*  394 */       this.dfsUsage = new DU(parent, conf);
/*  395 */       this.dfsUsage.start();
/*      */     }
/*      */ 
/*      */     File getCurrentDir() {
/*  399 */       return this.currentDir;
/*      */     }
/*      */ 
/*      */     void decDfsUsed(long value)
/*      */     {
/*  405 */       synchronized (FSDataset.this) {
/*  406 */         this.dfsUsage.decDfsUsed(value);
/*      */       }
/*      */     }
/*      */ 
/*      */     long getDfsUsed() throws IOException {
/*  411 */       return this.dfsUsage.getUsed();
/*      */     }
/*      */ 
/*      */     long getCapacity() throws IOException {
/*  415 */       if (this.reserved > this.usage.getCapacity()) {
/*  416 */         return 0L;
/*      */       }
/*      */ 
/*  419 */       return this.usage.getCapacity() - this.reserved;
/*      */     }
/*      */ 
/*      */     long getAvailable() throws IOException {
/*  423 */       long remaining = getCapacity() - getDfsUsed();
/*  424 */       long available = this.usage.getAvailable();
/*  425 */       if (remaining > available) {
/*  426 */         remaining = available;
/*      */       }
/*  428 */       return remaining > 0L ? remaining : 0L;
/*      */     }
/*      */ 
/*      */     long getReserved() {
/*  432 */       return this.reserved;
/*      */     }
/*      */ 
/*      */     String getMount() throws IOException {
/*  436 */       return this.usage.getMount();
/*      */     }
/*      */ 
/*      */     File getDir() {
/*  440 */       return this.dataDir.dir;
/*      */     }
/*      */ 
/*      */     File createTmpFile(Block b, boolean replicationRequest)
/*      */       throws IOException
/*      */     {
/*  448 */       File f = null;
/*  449 */       if (!replicationRequest)
/*  450 */         f = new File(this.blocksBeingWritten, b.getBlockName());
/*      */       else {
/*  452 */         f = new File(this.tmpDir, b.getBlockName());
/*      */       }
/*  454 */       return createTmpFile(b, f);
/*      */     }
/*      */ 
/*      */     File getTmpFile(Block b)
/*      */       throws IOException
/*      */     {
/*  461 */       File f = new File(this.tmpDir, b.getBlockName());
/*  462 */       return f;
/*      */     }
/*      */ 
/*      */     File createDetachFile(Block b, String filename)
/*      */       throws IOException
/*      */     {
/*  470 */       File f = new File(this.detachDir, filename);
/*  471 */       return createTmpFile(b, f);
/*      */     }
/*      */ 
/*      */     private File createTmpFile(Block b, File f) throws IOException {
/*  475 */       if (f.exists()) {
/*  476 */         throw new IOException("Unexpected problem in creating temporary file for " + b + ".  File " + f + " should not be present, but is.");
/*      */       }
/*      */ 
/*  481 */       boolean fileCreated = false;
/*      */       try {
/*  483 */         fileCreated = f.createNewFile();
/*      */       } catch (IOException ioe) {
/*  485 */         DataNode.LOG.warn("createTmpFile failed for file " + f + " Block " + b);
/*  486 */         throw ((IOException)new IOException("Possible disk error on file creation: " + f).initCause(ioe));
/*      */       }
/*  488 */       if (!fileCreated) {
/*  489 */         throw new IOException("Unexpected problem in creating temporary file for " + b + ".  File " + f + " should be creatable, but is already present.");
/*      */       }
/*      */ 
/*  492 */       return f;
/*      */     }
/*      */ 
/*      */     File addBlock(Block b, File f) throws IOException {
/*  496 */       File blockFile = this.dataDir.addBlock(b, f);
/*  497 */       File metaFile = FSDataset.getMetaFile(blockFile, b);
/*  498 */       this.dfsUsage.incDfsUsed(b.getNumBytes() + metaFile.length());
/*  499 */       return blockFile;
/*      */     }
/*      */ 
/*      */     void checkDirs() throws DiskChecker.DiskErrorException {
/*  503 */       this.dataDir.checkDirTree();
/*  504 */       DiskChecker.checkDir(this.tmpDir);
/*  505 */       DiskChecker.checkDir(this.blocksBeingWritten);
/*      */     }
/*      */ 
/*      */     void scanBlockFilesInconsistent(Map<Block, File> results) {
/*  509 */       scanBlockFilesInconsistent(this.dataDir.dir, results);
/*      */     }
/*      */ 
/*      */     private void scanBlockFilesInconsistent(File dir, Map<Block, File> results)
/*      */     {
/*  524 */       File[] filesInDir = dir.listFiles();
/*  525 */       if (filesInDir != null)
/*  526 */         for (File f : filesInDir)
/*  527 */           if (Block.isBlockFilename(f)) {
/*  528 */             long blockLen = f.length();
/*  529 */             if ((blockLen != 0L) || (f.exists()))
/*      */             {
/*  534 */               long genStamp = FSDataset.getGenerationStampFromFile(filesInDir, f);
/*  535 */               Block b = new Block(f, blockLen, genStamp);
/*  536 */               results.put(b, f);
/*      */             } } else if (f.getName().startsWith("subdir"))
/*      */           {
/*  540 */             scanBlockFilesInconsistent(f, results);
/*      */           }
/*      */     }
/*      */ 
/*      */     void getBlocksBeingWrittenInfo(TreeSet<Block> blockSet)
/*      */     {
/*  547 */       if (this.blocksBeingWritten == null) {
/*  548 */         return;
/*      */       }
/*      */ 
/*  551 */       File[] blockFiles = this.blocksBeingWritten.listFiles();
/*  552 */       if (blockFiles == null) {
/*  553 */         return;
/*      */       }
/*      */ 
/*  556 */       for (int i = 0; i < blockFiles.length; i++)
/*  557 */         if (!blockFiles[i].isDirectory())
/*      */         {
/*  559 */           if (Block.isBlockFilename(blockFiles[i])) {
/*  560 */             long genStamp = FSDataset.getGenerationStampFromFile(blockFiles, blockFiles[i]);
/*      */ 
/*  562 */             Block block = new Block(blockFiles[i], blockFiles[i].length(), genStamp);
/*      */ 
/*  566 */             blockSet.add(block);
/*  567 */             if (DataNode.LOG.isDebugEnabled())
/*  568 */               DataNode.LOG.debug("recoverBlocksBeingWritten for " + block);
/*      */           }
/*      */         }
/*      */     }
/*      */ 
/*      */     void getVolumeMap(HashMap<Block, DatanodeBlockInfo> volumeMap)
/*      */     {
/*  576 */       this.dataDir.getVolumeMap(volumeMap, this);
/*      */     }
/*      */ 
/*      */     void clearPath(File f) {
/*  580 */       this.dataDir.clearPath(f);
/*      */     }
/*      */ 
/*      */     public String toString() {
/*  584 */       return this.dataDir.dir.getAbsolutePath();
/*      */     }
/*      */ 
/*      */     private void recoverBlocksBeingWritten(File bbw)
/*      */       throws IOException
/*      */     {
/*  593 */       FSDataset.FSDir fsd = new FSDataset.FSDir(FSDataset.this, bbw);
/*  594 */       TreeSet blockSet = new TreeSet();
/*  595 */       fsd.getBlockAndFileInfo(blockSet);
/*  596 */       for (FSDataset.BlockAndFile b : blockSet) {
/*  597 */         File f = b.pathfile;
/*  598 */         FSDataset.this.volumeMap.put(b.block, new DatanodeBlockInfo(this, f));
/*  599 */         FSDataset.this.ongoingCreates.put(b.block, FSDataset.ActiveFile.createStartupRecoveryFile(f));
/*  600 */         if (DataNode.LOG.isDebugEnabled())
/*  601 */           DataNode.LOG.debug("recoverBlocksBeingWritten for block " + b.block);
/*      */       }
/*      */     }
/*      */ 
/*      */     private void recoverDetachedBlocks(File dataDir, File dir)
/*      */       throws IOException
/*      */     {
/*  613 */       File[] contents = FileUtil.listFiles(dir);
/*  614 */       for (int i = 0; i < contents.length; i++) {
/*  615 */         if (!contents[i].isFile()) {
/*  616 */           throw new IOException("Found " + contents[i] + " in " + dir + " but it is not a file.");
/*      */         }
/*      */ 
/*  624 */         File blk = new File(dataDir, contents[i].getName());
/*  625 */         if (!blk.exists()) {
/*  626 */           if (!contents[i].renameTo(blk)) {
/*  627 */             throw new IOException("Unable to recover detached file " + contents[i]);
/*      */           }
/*      */ 
/*      */         }
/*  632 */         else if (!contents[i].delete())
/*  633 */           throw new IOException("Unable to cleanup detached file " + contents[i]);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   class FSDir
/*      */   {
/*      */     File dir;
/*  120 */     int numBlocks = 0;
/*      */     FSDir[] children;
/*  122 */     int lastChildIdx = 0;
/*      */ 
/*      */     public FSDir(File dir)
/*      */       throws IOException
/*      */     {
/*  127 */       this.dir = dir;
/*  128 */       this.children = null;
/*      */       File[] files;
/*  129 */       if (!dir.exists()) {
/*  130 */         if (!dir.mkdirs())
/*  131 */           throw new IOException(new StringBuilder().append("Mkdirs failed to create ").append(dir.toString()).toString());
/*      */       }
/*      */       else
/*      */       {
/*  135 */         files = FileUtil.listFiles(dir);
/*  136 */         int numChildren = 0;
/*  137 */         for (int idx = 0; idx < files.length; idx++) {
/*  138 */           if (files[idx].isDirectory())
/*  139 */             numChildren++;
/*  140 */           else if (Block.isBlockFilename(files[idx])) {
/*  141 */             this.numBlocks += 1;
/*      */           }
/*      */         }
/*  144 */         if (numChildren > 0) {
/*  145 */           this.children = new FSDir[numChildren];
/*  146 */           int curdir = 0;
/*  147 */           for (int idx = 0; idx < files.length; idx++)
/*  148 */             if (files[idx].isDirectory()) {
/*  149 */               this.children[curdir] = new FSDir(FSDataset.this, files[idx]);
/*  150 */               curdir++;
/*      */             }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public File addBlock(Block b, File src)
/*      */       throws IOException
/*      */     {
/*  159 */       File file = addBlock(b, src, false, false);
/*  160 */       return file != null ? file : addBlock(b, src, true, true);
/*      */     }
/*      */ 
/*      */     private File addBlock(Block b, File src, boolean createOk, boolean resetIdx) throws IOException
/*      */     {
/*  165 */       if (this.numBlocks < FSDataset.this.maxBlocksPerDir) {
/*  166 */         File dest = new File(this.dir, b.getBlockName());
/*  167 */         File metaData = FSDataset.getMetaFile(src, b);
/*  168 */         File newmeta = FSDataset.getMetaFile(dest, b);
/*  169 */         if ((!metaData.renameTo(newmeta)) || (!src.renameTo(dest)))
/*      */         {
/*  171 */           throw new IOException(new StringBuilder().append("could not move files for ").append(b).append(" from tmp to ").append(dest.getAbsolutePath()).toString());
/*      */         }
/*      */ 
/*  175 */         if (DataNode.LOG.isDebugEnabled()) {
/*  176 */           DataNode.LOG.debug(new StringBuilder().append("addBlock: Moved ").append(metaData).append(" to ").append(newmeta).toString());
/*  177 */           DataNode.LOG.debug(new StringBuilder().append("addBlock: Moved ").append(src).append(" to ").append(dest).toString());
/*      */         }
/*      */ 
/*  180 */         this.numBlocks += 1;
/*  181 */         return dest;
/*      */       }
/*      */ 
/*  184 */       if ((this.lastChildIdx < 0) && (resetIdx))
/*      */       {
/*  186 */         this.lastChildIdx = FSDataset.random.nextInt(this.children.length);
/*      */       }
/*      */ 
/*  189 */       if ((this.lastChildIdx >= 0) && (this.children != null))
/*      */       {
/*  191 */         for (int i = 0; i < this.children.length; i++) {
/*  192 */           int idx = (this.lastChildIdx + i) % this.children.length;
/*  193 */           File file = this.children[idx].addBlock(b, src, false, resetIdx);
/*  194 */           if (file != null) {
/*  195 */             this.lastChildIdx = idx;
/*  196 */             return file;
/*      */           }
/*      */         }
/*  199 */         this.lastChildIdx = -1;
/*      */       }
/*      */ 
/*  202 */       if (!createOk) {
/*  203 */         return null;
/*      */       }
/*      */ 
/*  206 */       if ((this.children == null) || (this.children.length == 0)) {
/*  207 */         this.children = new FSDir[FSDataset.this.maxBlocksPerDir];
/*  208 */         for (int idx = 0; idx < FSDataset.this.maxBlocksPerDir; idx++) {
/*  209 */           this.children[idx] = new FSDir(FSDataset.this, new File(this.dir, new StringBuilder().append("subdir").append(idx).toString()));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  214 */       this.lastChildIdx = FSDataset.random.nextInt(this.children.length);
/*  215 */       return this.children[this.lastChildIdx].addBlock(b, src, true, false);
/*      */     }
/*      */ 
/*      */     void getBlockAndFileInfo(TreeSet<FSDataset.BlockAndFile> blockSet)
/*      */     {
/*  224 */       if (this.children != null) {
/*  225 */         for (int i = 0; i < this.children.length; i++) {
/*  226 */           this.children[i].getBlockAndFileInfo(blockSet);
/*      */         }
/*      */       }
/*      */ 
/*  230 */       File[] blockFiles = this.dir.listFiles();
/*  231 */       for (int i = 0; i < blockFiles.length; i++)
/*  232 */         if (Block.isBlockFilename(blockFiles[i])) {
/*  233 */           long genStamp = FSDataset.getGenerationStampFromFile(blockFiles, blockFiles[i]);
/*  234 */           Block block = new Block(blockFiles[i], blockFiles[i].length(), genStamp);
/*  235 */           blockSet.add(new FSDataset.BlockAndFile(blockFiles[i].getAbsoluteFile(), block));
/*      */         }
/*      */     }
/*      */ 
/*      */     void getVolumeMap(HashMap<Block, DatanodeBlockInfo> volumeMap, FSDataset.FSVolume volume)
/*      */     {
/*  241 */       if (this.children != null) {
/*  242 */         for (int i = 0; i < this.children.length; i++) {
/*  243 */           this.children[i].getVolumeMap(volumeMap, volume);
/*      */         }
/*      */       }
/*      */ 
/*  247 */       File[] blockFiles = this.dir.listFiles();
/*  248 */       if (blockFiles != null)
/*  249 */         for (int i = 0; i < blockFiles.length; i++)
/*  250 */           if (Block.isBlockFilename(blockFiles[i])) {
/*  251 */             long genStamp = FSDataset.getGenerationStampFromFile(blockFiles, blockFiles[i]);
/*      */ 
/*  253 */             volumeMap.put(new Block(blockFiles[i], blockFiles[i].length(), genStamp), new DatanodeBlockInfo(volume, blockFiles[i]));
/*      */           }
/*      */     }
/*      */ 
/*      */     public void checkDirTree()
/*      */       throws DiskChecker.DiskErrorException
/*      */     {
/*  265 */       DiskChecker.checkDir(this.dir);
/*      */ 
/*  267 */       if (this.children != null)
/*  268 */         for (int i = 0; i < this.children.length; i++)
/*  269 */           this.children[i].checkDirTree();
/*      */     }
/*      */ 
/*      */     void clearPath(File f)
/*      */     {
/*  275 */       String root = this.dir.getAbsolutePath();
/*  276 */       String dir = f.getAbsolutePath();
/*  277 */       if (dir.startsWith(root)) {
/*  278 */         String[] dirNames = dir.substring(root.length()).split(new StringBuilder().append(File.separator).append("subdir").toString());
/*      */ 
/*  280 */         if (clearPath(f, dirNames, 1))
/*  281 */           return;
/*      */       }
/*  283 */       clearPath(f, null, -1);
/*      */     }
/*      */ 
/*      */     private boolean clearPath(File f, String[] dirNames, int idx)
/*      */     {
/*  295 */       if (((dirNames == null) || (idx == dirNames.length)) && (this.dir.compareTo(f) == 0))
/*      */       {
/*  297 */         this.numBlocks -= 1;
/*  298 */         return true;
/*      */       }
/*      */ 
/*  301 */       if (dirNames != null)
/*      */       {
/*  303 */         if ((idx > dirNames.length - 1) || (this.children == null))
/*  304 */           return false;
/*      */         int childIdx;
/*      */         try
/*      */         {
/*  308 */           childIdx = Integer.parseInt(dirNames[idx]);
/*      */         }
/*      */         catch (NumberFormatException ignored) {
/*  311 */           return false;
/*      */         }
/*  313 */         return (childIdx >= 0) && (childIdx < this.children.length) ? this.children[childIdx].clearPath(f, dirNames, idx + 1) : false;
/*      */       }
/*      */ 
/*  318 */       if (this.children != null) {
/*  319 */         for (int i = 0; i < this.children.length; i++) {
/*  320 */           if (this.children[i].clearPath(f, null, -1)) {
/*  321 */             return true;
/*      */           }
/*      */         }
/*      */       }
/*  325 */       return false;
/*      */     }
/*      */ 
/*      */     public String toString() {
/*  329 */       return new StringBuilder().append("FSDir{dir=").append(this.dir).append(", children=").append(this.children == null ? null : Arrays.asList(this.children)).append("}").toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   static class BlockAndFile
/*      */     implements Comparable<BlockAndFile>
/*      */   {
/*      */     final Block block;
/*      */     final File pathfile;
/*      */ 
/*      */     BlockAndFile(File fullpathname, Block block)
/*      */     {
/*  104 */       this.pathfile = fullpathname;
/*  105 */       this.block = block;
/*      */     }
/*      */ 
/*      */     public int compareTo(BlockAndFile o)
/*      */     {
/*  110 */       return this.block.compareTo(o.block);
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.FSDataset
 * JD-Core Version:    0.6.1
 */
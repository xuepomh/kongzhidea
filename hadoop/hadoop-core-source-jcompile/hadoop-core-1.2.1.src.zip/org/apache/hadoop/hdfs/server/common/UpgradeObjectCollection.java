/*     */ package org.apache.hadoop.hdfs.server.common;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ public class UpgradeObjectCollection
/*     */ {
/*     */   static SortedSet<UOSignature> upgradeTable;
/*     */ 
/*     */   static final void initialize()
/*     */   {
/* 103 */     upgradeTable = new TreeSet();
/*     */   }
/*     */ 
/*     */   static void registerUpgrade(Upgradeable uo)
/*     */   {
/* 108 */     upgradeTable.add(new UOSignature(uo));
/*     */   }
/*     */ 
/*     */   public static SortedSet<Upgradeable> getDistributedUpgrades(int versionFrom, HdfsConstants.NodeType type)
/*     */     throws IOException
/*     */   {
/* 114 */     assert (-41 <= versionFrom) : ("Incorrect version " + versionFrom + ". Expected to be <= " + -41);
/*     */ 
/* 116 */     SortedSet upgradeObjects = new TreeSet();
/* 117 */     for (UOSignature sig : upgradeTable)
/* 118 */       if (sig.getVersion() >= -41)
/*     */       {
/* 120 */         if (sig.getVersion() > versionFrom)
/*     */           break;
/* 122 */         if (sig.getType() == type)
/*     */         {
/* 124 */           upgradeObjects.add(sig.instantiate());
/*     */         }
/*     */       }
/* 126 */     if (upgradeObjects.size() == 0)
/* 127 */       return null;
/* 128 */     return upgradeObjects;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  34 */     initialize();
/*     */   }
/*     */ 
/*     */   static class UOSignature implements Comparable<UOSignature> {
/*     */     int version;
/*     */     HdfsConstants.NodeType type;
/*     */     String className;
/*     */ 
/*     */     UOSignature(Upgradeable uo) {
/*  45 */       this.version = uo.getVersion();
/*  46 */       this.type = uo.getType();
/*  47 */       this.className = uo.getClass().getCanonicalName();
/*     */     }
/*     */ 
/*     */     int getVersion() {
/*  51 */       return this.version;
/*     */     }
/*     */ 
/*     */     HdfsConstants.NodeType getType() {
/*  55 */       return this.type;
/*     */     }
/*     */ 
/*     */     String getClassName() {
/*  59 */       return this.className;
/*     */     }
/*     */ 
/*     */     Upgradeable instantiate() throws IOException {
/*     */       try {
/*  64 */         return (Upgradeable)Class.forName(getClassName()).newInstance();
/*     */       } catch (ClassNotFoundException e) {
/*  66 */         throw new IOException(StringUtils.stringifyException(e));
/*     */       } catch (InstantiationException e) {
/*  68 */         throw new IOException(StringUtils.stringifyException(e));
/*     */       } catch (IllegalAccessException e) {
/*  70 */         throw new IOException(StringUtils.stringifyException(e));
/*     */       }
/*     */     }
/*     */ 
/*     */     public int compareTo(UOSignature o) {
/*  75 */       if (this.version != o.version)
/*  76 */         return this.version < o.version ? -1 : 1;
/*  77 */       int res = getType().toString().compareTo(o.getType().toString());
/*  78 */       if (res != 0)
/*  79 */         return res;
/*  80 */       return this.className.compareTo(o.className);
/*     */     }
/*     */ 
/*     */     public boolean equals(Object o) {
/*  84 */       if (!(o instanceof UOSignature)) {
/*  85 */         return false;
/*     */       }
/*  87 */       return compareTo((UOSignature)o) == 0;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/*  91 */       return this.version ^ (this.type == null ? 0 : this.type.hashCode()) ^ (this.className == null ? 0 : this.className.hashCode());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.common.UpgradeObjectCollection
 * JD-Core Version:    0.6.1
 */
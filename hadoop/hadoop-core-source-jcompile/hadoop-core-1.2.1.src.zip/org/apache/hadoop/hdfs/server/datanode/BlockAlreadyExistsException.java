/*    */ package org.apache.hadoop.hdfs.server.datanode;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ class BlockAlreadyExistsException extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public BlockAlreadyExistsException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public BlockAlreadyExistsException(String msg)
/*    */   {
/* 36 */     super(msg);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.BlockAlreadyExistsException
 * JD-Core Version:    0.6.1
 */
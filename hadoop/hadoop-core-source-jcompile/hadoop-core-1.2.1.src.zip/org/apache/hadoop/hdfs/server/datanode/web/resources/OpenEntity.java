/*    */ package org.apache.hadoop.hdfs.server.datanode.web.resources;
/*    */ 
/*    */ import java.io.Closeable;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Type;
/*    */ import javax.ws.rs.core.MediaType;
/*    */ import javax.ws.rs.core.MultivaluedMap;
/*    */ import javax.ws.rs.ext.MessageBodyWriter;
/*    */ import javax.ws.rs.ext.Provider;
/*    */ import org.apache.hadoop.hdfs.DFSClient;
/*    */ import org.apache.hadoop.hdfs.DFSClient.DFSDataInputStream;
/*    */ import org.apache.hadoop.io.IOUtils;
/*    */ 
/*    */ public class OpenEntity
/*    */ {
/*    */   private final DFSClient.DFSDataInputStream in;
/*    */   private final long length;
/*    */   private final DFSClient dfsclient;
/*    */ 
/*    */   OpenEntity(DFSClient.DFSDataInputStream in, long length, DFSClient dfsclient)
/*    */   {
/* 44 */     this.in = in;
/* 45 */     this.length = length;
/* 46 */     this.dfsclient = dfsclient;
/*    */   }
/*    */ 
/*    */   @Provider
/*    */   public static class Writer
/*    */     implements MessageBodyWriter<OpenEntity>
/*    */   {
/*    */     public boolean isWriteable(Class<?> clazz, Type genericType, Annotation[] annotations, MediaType mediaType)
/*    */     {
/* 58 */       return (clazz == OpenEntity.class) && (MediaType.APPLICATION_OCTET_STREAM_TYPE.isCompatible(mediaType));
/*    */     }
/*    */ 
/*    */     public long getSize(OpenEntity e, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType)
/*    */     {
/* 65 */       return e.length;
/*    */     }
/*    */ 
/*    */     public void writeTo(OpenEntity e, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream out)
/*    */       throws IOException
/*    */     {
/*    */       try
/*    */       {
/* 74 */         IOUtils.copyBytes(e.in, out, e.length, 4096, false);
/*    */       } finally {
/* 76 */         IOUtils.cleanup(DatanodeWebHdfsMethods.LOG, new Closeable[] { e.in });
/* 77 */         IOUtils.cleanup(DatanodeWebHdfsMethods.LOG, new Closeable[] { e.dfsclient });
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.datanode.web.resources.OpenEntity
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs.server.namenode;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Random;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ 
/*     */ class Host2NodesMap
/*     */ {
/*  25 */   private HashMap<String, DatanodeDescriptor[]> map = new HashMap();
/*     */ 
/*  27 */   private Random r = new Random();
/*  28 */   private ReadWriteLock hostmapLock = new ReentrantReadWriteLock();
/*     */ 
/*     */   boolean contains(DatanodeDescriptor node)
/*     */   {
/*  32 */     if (node == null) {
/*  33 */       return false;
/*     */     }
/*     */ 
/*  36 */     String host = node.getHost();
/*  37 */     this.hostmapLock.readLock().lock();
/*     */     try {
/*  39 */       DatanodeDescriptor[] nodes = (DatanodeDescriptor[])this.map.get(host);
/*  40 */       if (nodes != null) {
/*  41 */         for (DatanodeDescriptor containedNode : nodes)
/*  42 */           if (node == containedNode)
/*  43 */             return true;
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*  48 */       this.hostmapLock.readLock().unlock();
/*     */     }
/*  50 */     return false;
/*     */   }
/*     */ 
/*     */   boolean add(DatanodeDescriptor node)
/*     */   {
/*  57 */     this.hostmapLock.writeLock().lock();
/*     */     try {
/*  59 */       if ((node == null) || (contains(node))) {
/*  60 */         return false;
/*     */       }
/*     */ 
/*  63 */       String host = node.getHost();
/*  64 */       DatanodeDescriptor[] nodes = (DatanodeDescriptor[])this.map.get(host);
/*     */       DatanodeDescriptor[] newNodes;
/*  66 */       if (nodes == null) {
/*  67 */         DatanodeDescriptor[] newNodes = new DatanodeDescriptor[1];
/*  68 */         newNodes[0] = node;
/*     */       } else {
/*  70 */         newNodes = new DatanodeDescriptor[nodes.length + 1];
/*  71 */         System.arraycopy(nodes, 0, newNodes, 0, nodes.length);
/*  72 */         newNodes[nodes.length] = node;
/*     */       }
/*  74 */       this.map.put(host, newNodes);
/*  75 */       return true;
/*     */     } finally {
/*  77 */       this.hostmapLock.writeLock().unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   boolean remove(DatanodeDescriptor node)
/*     */   {
/*  85 */     if (node == null) {
/*  86 */       return false;
/*     */     }
/*     */ 
/*  89 */     String host = node.getHost();
/*  90 */     this.hostmapLock.writeLock().lock();
/*     */     try
/*     */     {
/*  93 */       DatanodeDescriptor[] nodes = (DatanodeDescriptor[])this.map.get(host);
/*     */       boolean bool1;
/*  94 */       if (nodes == null) {
/*  95 */         return false;
/*     */       }
/*  97 */       if (nodes.length == 1) {
/*  98 */         if (nodes[0] == node) {
/*  99 */           this.map.remove(host);
/* 100 */           return true;
/*     */         }
/* 102 */         return false;
/*     */       }
/*     */ 
/* 106 */       int i = 0;
/* 107 */       while ((i < nodes.length) && 
/* 108 */         (nodes[i] != node)) {
/* 107 */         i++;
/*     */       }
/*     */ 
/* 112 */       if (i == nodes.length) {
/* 113 */         return false;
/*     */       }
/*     */ 
/* 116 */       DatanodeDescriptor[] newNodes = new DatanodeDescriptor[nodes.length - 1];
/* 117 */       System.arraycopy(nodes, 0, newNodes, 0, i);
/* 118 */       System.arraycopy(nodes, i + 1, newNodes, i, nodes.length - i - 1);
/* 119 */       this.map.put(host, newNodes);
/* 120 */       return true;
/*     */     }
/*     */     finally {
/* 123 */       this.hostmapLock.writeLock().unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   DatanodeDescriptor getDatanodeByHost(String host)
/*     */   {
/* 131 */     if (host == null) {
/* 132 */       return null;
/*     */     }
/*     */ 
/* 135 */     this.hostmapLock.readLock().lock();
/*     */     try {
/* 137 */       DatanodeDescriptor[] nodes = (DatanodeDescriptor[])this.map.get(host);
/*     */       DatanodeDescriptor localDatanodeDescriptor;
/* 139 */       if (nodes == null) {
/* 140 */         return null;
/*     */       }
/*     */ 
/* 143 */       if (nodes.length == 1) {
/* 144 */         return nodes[0];
/*     */       }
/*     */ 
/* 147 */       return nodes[this.r.nextInt(nodes.length)];
/*     */     } finally {
/* 149 */       this.hostmapLock.readLock().unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public DatanodeDescriptor getDatanodeByName(String name)
/*     */   {
/* 159 */     if (name == null) {
/* 160 */       return null;
/*     */     }
/*     */ 
/* 163 */     int colon = name.indexOf(":");
/*     */     String host;
/*     */     String host;
/* 165 */     if (colon < 0)
/* 166 */       host = name;
/*     */     else {
/* 168 */       host = name.substring(0, colon);
/*     */     }
/*     */ 
/* 171 */     this.hostmapLock.readLock().lock();
/*     */     try {
/* 173 */       DatanodeDescriptor[] nodes = (DatanodeDescriptor[])this.map.get(host);
/*     */ 
/* 175 */       if (nodes == null) {
/* 176 */         return null;
/*     */       }
/* 178 */       for (DatanodeDescriptor containedNode : nodes) {
/* 179 */         if (name.equals(containedNode.getName())) {
/* 180 */           return containedNode;
/*     */         }
/*     */       }
/* 183 */       return null;
/*     */     } finally {
/* 185 */       this.hostmapLock.readLock().unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 191 */     StringBuilder b = new StringBuilder(getClass().getSimpleName()).append("[");
/*     */ 
/* 193 */     for (Map.Entry e : this.map.entrySet()) {
/* 194 */       b.append(new StringBuilder().append("\n  ").append((String)e.getKey()).append(" => ").append(Arrays.asList((Object[])e.getValue())).toString());
/*     */     }
/* 196 */     return b.append("\n]").toString();
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.server.namenode.Host2NodesMap
 * JD-Core Version:    0.6.1
 */
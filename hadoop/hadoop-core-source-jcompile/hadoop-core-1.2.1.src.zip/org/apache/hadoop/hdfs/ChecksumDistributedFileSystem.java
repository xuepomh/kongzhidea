/*     */ package org.apache.hadoop.hdfs;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.ChecksumFileSystem;
/*     */ import org.apache.hadoop.fs.FSDataInputStream;
/*     */ import org.apache.hadoop.fs.FileStatus;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.hdfs.protocol.FSConstants.SafeModeAction;
/*     */ import org.apache.hadoop.hdfs.protocol.FSConstants.UpgradeAction;
/*     */ import org.apache.hadoop.hdfs.server.common.UpgradeStatusReport;
/*     */ 
/*     */ public class ChecksumDistributedFileSystem extends ChecksumFileSystem
/*     */ {
/*     */   public ChecksumDistributedFileSystem()
/*     */   {
/*  40 */     super(new DistributedFileSystem());
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public ChecksumDistributedFileSystem(InetSocketAddress namenode, Configuration conf) throws IOException
/*     */   {
/*  46 */     super(new DistributedFileSystem(namenode, conf));
/*     */   }
/*     */ 
/*     */   DistributedFileSystem getDFS()
/*     */   {
/*  52 */     return (DistributedFileSystem)this.fs;
/*     */   }
/*     */ 
/*     */   public long getRawCapacity()
/*     */     throws IOException
/*     */   {
/*  58 */     return getDFS().getRawCapacity();
/*     */   }
/*     */ 
/*     */   public long getRawUsed()
/*     */     throws IOException
/*     */   {
/*  64 */     return getDFS().getRawUsed();
/*     */   }
/*     */ 
/*     */   public DatanodeInfo[] getDataNodeStats() throws IOException
/*     */   {
/*  69 */     return getDFS().getDataNodeStats();
/*     */   }
/*     */ 
/*     */   public boolean setSafeMode(FSConstants.SafeModeAction action)
/*     */     throws IOException
/*     */   {
/*  79 */     return getDFS().setSafeMode(action);
/*     */   }
/*     */ 
/*     */   public void refreshNodes()
/*     */     throws IOException
/*     */   {
/*  87 */     getDFS().refreshNodes();
/*     */   }
/*     */ 
/*     */   public void finalizeUpgrade()
/*     */     throws IOException
/*     */   {
/*  94 */     getDFS().finalizeUpgrade();
/*     */   }
/*     */ 
/*     */   public UpgradeStatusReport distributedUpgradeProgress(FSConstants.UpgradeAction action) throws IOException
/*     */   {
/*  99 */     return getDFS().distributedUpgradeProgress(action);
/*     */   }
/*     */ 
/*     */   public void metaSave(String pathname)
/*     */     throws IOException
/*     */   {
/* 106 */     getDFS().metaSave(pathname);
/*     */   }
/*     */ 
/*     */   public boolean reportChecksumFailure(Path f, FSDataInputStream in, long inPos, FSDataInputStream sums, long sumsPos)
/*     */   {
/* 117 */     return getDFS().reportChecksumFailure(f, in, inPos, sums, sumsPos);
/*     */   }
/*     */ 
/*     */   public FileStatus getFileStatus(Path f)
/*     */     throws IOException
/*     */   {
/* 126 */     return getDFS().getFileStatus(f);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.ChecksumDistributedFileSystem
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.SocketTimeoutException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.util.Daemon;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ class LeaseRenewer
/*     */ {
/*  70 */   static final Log LOG = LogFactory.getLog(LeaseRenewer.class);
/*     */   static final long LEASE_RENEWER_GRACE_DEFAULT = 60000L;
/*     */   static final long LEASE_RENEWER_SLEEP_DEFAULT = 1000L;
/* 160 */   private long emptyTime = 9223372036854775807L;
/*     */ 
/* 162 */   private long renewal = 30000L;
/*     */ 
/* 165 */   private Daemon daemon = null;
/*     */ 
/* 167 */   private int currentId = 0;
/*     */   private long gracePeriod;
/*     */   private long sleepPeriod;
/*     */   private final LeaseRenewer.Factory.Key factorykey;
/* 186 */   private final List<DFSClient> dfsclients = new ArrayList();
/*     */ 
/*     */   static LeaseRenewer getInstance(String authority, UserGroupInformation ugi, DFSClient dfsc)
/*     */     throws IOException
/*     */   {
/*  78 */     LeaseRenewer r = Factory.INSTANCE.get(authority, ugi);
/*  79 */     r.addClient(dfsc);
/*  80 */     return r;
/*     */   }
/*     */ 
/*     */   private LeaseRenewer(LeaseRenewer.Factory.Key factorykey)
/*     */   {
/* 189 */     this.factorykey = factorykey;
/* 190 */     unsyncSetGraceSleepPeriod(60000L);
/*     */   }
/*     */ 
/*     */   private synchronized long getRenewalTime()
/*     */   {
/* 195 */     return this.renewal;
/*     */   }
/*     */ 
/*     */   private synchronized void addClient(DFSClient dfsc)
/*     */   {
/* 200 */     for (DFSClient c : this.dfsclients) {
/* 201 */       if (c == dfsc)
/*     */       {
/* 203 */         return;
/*     */       }
/*     */     }
/*     */ 
/* 207 */     this.dfsclients.add(dfsc);
/*     */ 
/* 210 */     if (dfsc.hdfsTimeout > 0) {
/* 211 */       long half = dfsc.hdfsTimeout / 2;
/* 212 */       if (half < this.renewal)
/* 213 */         this.renewal = half;
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized boolean clientsRunning()
/*     */   {
/* 219 */     for (Iterator i = this.dfsclients.iterator(); i.hasNext(); ) {
/* 220 */       if (!((DFSClient)i.next()).clientRunning) {
/* 221 */         i.remove();
/*     */       }
/*     */     }
/* 224 */     return !this.dfsclients.isEmpty();
/*     */   }
/*     */ 
/*     */   private synchronized long getSleepPeriod() {
/* 228 */     return this.sleepPeriod;
/*     */   }
/*     */ 
/*     */   synchronized void setGraceSleepPeriod(long gracePeriod)
/*     */   {
/* 233 */     unsyncSetGraceSleepPeriod(gracePeriod);
/*     */   }
/*     */ 
/*     */   private void unsyncSetGraceSleepPeriod(long gracePeriod) {
/* 237 */     if (gracePeriod < 100L) {
/* 238 */       throw new IllegalArgumentException(new StringBuilder().append(gracePeriod).append(" = gracePeriod < 100ms is too small.").toString());
/*     */     }
/*     */ 
/* 241 */     this.gracePeriod = gracePeriod;
/* 242 */     long half = gracePeriod / 2L;
/* 243 */     this.sleepPeriod = (half < 1000L ? half : 1000L);
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 249 */     return this.dfsclients.isEmpty();
/*     */   }
/*     */ 
/*     */   synchronized boolean isRunning()
/*     */   {
/* 254 */     return (this.daemon != null) && (this.daemon.isAlive());
/*     */   }
/*     */ 
/*     */   private synchronized boolean isRenewerExpired()
/*     */   {
/* 259 */     return (this.emptyTime != 9223372036854775807L) && (System.currentTimeMillis() - this.emptyTime > this.gracePeriod);
/*     */   }
/*     */ 
/*     */   synchronized void put(String src, DFSClient.DFSOutputStream out, DFSClient dfsc)
/*     */   {
/* 265 */     if (dfsc.clientRunning) {
/* 266 */       if ((!isRunning()) || (isRenewerExpired()))
/*     */       {
/* 268 */         final int id = ++this.currentId;
/* 269 */         this.daemon = new Daemon(new Object()
/*     */         {
/*     */           public void run() {
/*     */             try {
/* 273 */               LeaseRenewer.this.run(id);
/*     */             } catch (InterruptedException e) {
/* 275 */               if (LeaseRenewer.LOG.isDebugEnabled())
/* 276 */                 LeaseRenewer.LOG.debug(LeaseRenewer.this.getClass().getSimpleName() + " is interrupted.", e);
/*     */             }
/*     */             finally
/*     */             {
/* 280 */               synchronized (LeaseRenewer.this) {
/* 281 */                 LeaseRenewer.Factory.INSTANCE.remove(LeaseRenewer.this);
/*     */               }
/*     */             }
/*     */           }
/*     */         });
/* 286 */         this.daemon.start();
/*     */       }
/* 288 */       dfsc.putFileBeingWritten(src, out);
/* 289 */       this.emptyTime = 9223372036854775807L;
/*     */     }
/*     */   }
/*     */ 
/*     */   void closeFile(String src, DFSClient dfsc)
/*     */   {
/* 295 */     dfsc.removeFileBeingWritten(src);
/*     */ 
/* 297 */     synchronized (this) {
/* 298 */       if (dfsc.isFilesBeingWrittenEmpty()) {
/* 299 */         this.dfsclients.remove(dfsc);
/*     */       }
/*     */ 
/* 302 */       if (this.emptyTime == 9223372036854775807L) {
/* 303 */         for (DFSClient c : this.dfsclients) {
/* 304 */           if (!c.isFilesBeingWrittenEmpty())
/*     */           {
/* 306 */             return;
/*     */           }
/*     */         }
/*     */ 
/* 310 */         this.emptyTime = System.currentTimeMillis();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   synchronized void closeClient(DFSClient dfsc)
/*     */   {
/* 317 */     this.dfsclients.remove(dfsc);
/* 318 */     if (this.dfsclients.isEmpty()) {
/* 319 */       if ((!isRunning()) || (isRenewerExpired())) {
/* 320 */         Factory.INSTANCE.remove(this);
/* 321 */         return;
/*     */       }
/* 323 */       if (this.emptyTime == 9223372036854775807L)
/*     */       {
/* 325 */         this.emptyTime = System.currentTimeMillis();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 330 */     if (this.renewal == dfsc.hdfsTimeout / 2) {
/* 331 */       long min = 60000L;
/* 332 */       for (DFSClient c : this.dfsclients) {
/* 333 */         if (c.hdfsTimeout > 0) {
/* 334 */           long half = c.hdfsTimeout;
/* 335 */           if (half < min) {
/* 336 */             min = half;
/*     */           }
/*     */         }
/*     */       }
/* 340 */       this.renewal = (min / 2L);
/*     */     }
/*     */   }
/*     */ 
/*     */   void interruptAndJoin() throws InterruptedException {
/* 345 */     Daemon daemonCopy = null;
/* 346 */     synchronized (this) {
/* 347 */       if (isRunning()) {
/* 348 */         this.daemon.interrupt();
/* 349 */         daemonCopy = this.daemon;
/*     */       }
/*     */     }
/*     */ 
/* 353 */     if (daemonCopy != null) {
/* 354 */       if (LOG.isDebugEnabled()) {
/* 355 */         LOG.debug("Wait for lease checker to terminate");
/*     */       }
/* 357 */       daemonCopy.join();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void renew()
/*     */     throws IOException
/*     */   {
/*     */     List copies;
/* 363 */     synchronized (this) {
/* 364 */       copies = new ArrayList(this.dfsclients);
/*     */     }
/*     */ 
/* 367 */     Collections.sort(copies, new Comparator()
/*     */     {
/*     */       public int compare(DFSClient left, DFSClient right) {
/* 370 */         return left.clientName.compareTo(right.clientName);
/*     */       }
/*     */     });
/* 373 */     String previousName = "";
/* 374 */     for (int i = 0; i < copies.size(); i++) {
/* 375 */       DFSClient c = (DFSClient)copies.get(i);
/*     */ 
/* 377 */       if (!c.clientName.equals(previousName))
/* 378 */         if (!c.renewLease()) {
/* 379 */           if (LOG.isDebugEnabled()) {
/* 380 */             LOG.debug(new StringBuilder().append("Did not renew lease for client ").append(c).toString());
/*     */           }
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 386 */           previousName = c.clientName;
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void run(int id)
/*     */     throws InterruptedException
/*     */   {
/* 396 */     for (long lastRenewed = System.currentTimeMillis(); !Thread.interrupted(); 
/* 397 */       Thread.sleep(getSleepPeriod())) {
/* 398 */       if (System.currentTimeMillis() - lastRenewed >= getRenewalTime()) {
/*     */         try {
/* 400 */           renew();
/* 401 */           lastRenewed = System.currentTimeMillis();
/*     */         } catch (SocketTimeoutException ie) {
/* 403 */           LOG.warn(new StringBuilder().append("Failed to renew lease for ").append(clientsString()).append(" for ").append(getRenewalTime() / 1000L).append(" seconds.  Aborting ...").toString(), ie);
/*     */ 
/* 405 */           synchronized (this) {
/* 406 */             for (DFSClient c : this.dfsclients) {
/* 407 */               c.abort();
/*     */             }
/*     */           }
/* 410 */           break;
/*     */         } catch (IOException ie) {
/* 412 */           LOG.warn(new StringBuilder().append("Failed to renew lease for ").append(clientsString()).append(" for ").append(getRenewalTime() / 1000L).append(" seconds.  Will retry shortly ...").toString(), ie);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 418 */       synchronized (this) {
/* 419 */         if ((id != this.currentId) || (isRenewerExpired()))
/*     */         {
/* 421 */           return;
/*     */         }
/*     */ 
/* 427 */         if ((!clientsRunning()) && (this.emptyTime == 9223372036854775807L))
/* 428 */           this.emptyTime = System.currentTimeMillis();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 436 */     String s = new StringBuilder().append(getClass().getSimpleName()).append(":").append(this.factorykey).toString();
/* 437 */     if (LOG.isTraceEnabled()) {
/* 438 */       return new StringBuilder().append(s).append(", clients=").append(clientsString()).append(", ").append(StringUtils.stringifyException(new Throwable("for testing"))).toString();
/*     */     }
/*     */ 
/* 441 */     return s;
/*     */   }
/*     */ 
/*     */   private synchronized String clientsString()
/*     */   {
/* 446 */     if (this.dfsclients.isEmpty()) {
/* 447 */       return "[]";
/*     */     }
/* 449 */     StringBuilder b = new StringBuilder("[").append(((DFSClient)this.dfsclients.get(0)).clientName);
/*     */ 
/* 451 */     for (int i = 1; i < this.dfsclients.size(); i++) {
/* 452 */       b.append(", ").append(((DFSClient)this.dfsclients.get(i)).clientName);
/*     */     }
/* 454 */     return b.append("]").toString();
/*     */   }
/*     */ 
/*     */   private static class Factory
/*     */   {
/*  89 */     private static final Factory INSTANCE = new Factory();
/*     */ 
/* 133 */     private final Map<Key, LeaseRenewer> renewers = new HashMap();
/*     */ 
/*     */     private synchronized LeaseRenewer get(String authority, UserGroupInformation ugi)
/*     */     {
/* 138 */       Key k = new Key(authority, ugi, null);
/* 139 */       LeaseRenewer r = (LeaseRenewer)this.renewers.get(k);
/* 140 */       if (r == null) {
/* 141 */         r = new LeaseRenewer(k, null);
/* 142 */         this.renewers.put(k, r);
/*     */       }
/* 144 */       return r;
/*     */     }
/*     */ 
/*     */     private synchronized void remove(LeaseRenewer r)
/*     */     {
/* 149 */       LeaseRenewer stored = (LeaseRenewer)this.renewers.get(r.factorykey);
/*     */ 
/* 151 */       if ((r == stored) && 
/* 152 */         (!r.clientsRunning()))
/* 153 */         this.renewers.remove(r.factorykey);
/*     */     }
/*     */ 
/*     */     private static class Key
/*     */     {
/*     */       final String authority;
/*     */       final UserGroupInformation ugi;
/*     */ 
/*     */       private Key(String authority, UserGroupInformation ugi)
/*     */       {
/*  98 */         if (authority == null)
/*  99 */           throw new IllegalArgumentException("authority == null");
/* 100 */         if (ugi == null) {
/* 101 */           throw new IllegalArgumentException("ugi == null");
/*     */         }
/*     */ 
/* 104 */         this.authority = authority;
/* 105 */         this.ugi = ugi;
/*     */       }
/*     */ 
/*     */       public int hashCode()
/*     */       {
/* 110 */         return this.authority.hashCode() ^ this.ugi.hashCode();
/*     */       }
/*     */ 
/*     */       public boolean equals(Object obj)
/*     */       {
/* 115 */         if (obj == this) {
/* 116 */           return true;
/*     */         }
/* 118 */         if ((obj != null) && ((obj instanceof Key))) {
/* 119 */           Key that = (Key)obj;
/* 120 */           return (this.authority.equals(that.authority)) && (this.ugi.equals(that.ugi));
/*     */         }
/*     */ 
/* 123 */         return false;
/*     */       }
/*     */ 
/*     */       public String toString()
/*     */       {
/* 128 */         return this.ugi.getShortUserName() + "@" + this.authority;
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.LeaseRenewer
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ import javax.net.ssl.SSLSession;
/*     */ import org.apache.hadoop.classification.InterfaceAudience.Private;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenIdentifier;
/*     */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenRenewer;
/*     */ import org.apache.hadoop.hdfs.tools.DelegationTokenFetcher;
/*     */ import org.apache.hadoop.io.Text;
/*     */ import org.apache.hadoop.security.SecurityUtil;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.token.Token;
/*     */ import org.apache.hadoop.security.token.delegation.AbstractDelegationTokenSelector;
/*     */ 
/*     */ public class HsftpFileSystem extends HftpFileSystem
/*     */ {
/*  48 */   public static final Text TOKEN_KIND = new Text("HSFTP delegation");
/*     */ 
/*  50 */   private static final DelegationTokenRenewer<HsftpFileSystem> dtRenewer = new DelegationTokenRenewer(HsftpFileSystem.class);
/*     */ 
/*  52 */   private static final HsftpDelegationTokenSelector hftpTokenSelector = new HsftpDelegationTokenSelector();
/*     */ 
/*     */   public void initialize(URI name, Configuration conf)
/*     */     throws IOException
/*     */   {
/*  57 */     super.initialize(name, conf);
/*  58 */     DelegationTokenFetcher.setupSsl(conf);
/*     */   }
/*     */ 
/*     */   protected int getDefaultPort()
/*     */   {
/*  64 */     return getConf().getInt("dfs.https.port", 50470);
/*     */   }
/*     */ 
/*     */   protected String getUnderlyingProtocol()
/*     */   {
/*  72 */     return "https";
/*     */   }
/*     */ 
/*     */   protected HttpURLConnection openConnection(String path, String query) throws IOException
/*     */   {
/*     */     try
/*     */     {
/*  79 */       query = updateQuery(query);
/*  80 */       URL url = new URI(getUnderlyingProtocol(), null, this.nnAddr.getHostName(), this.nnAddr.getPort(), path, query, null).toURL();
/*     */ 
/*  83 */       HttpsURLConnection conn = (HttpsURLConnection)url.openConnection();
/*     */ 
/*  85 */       conn.setHostnameVerifier(new DummyHostnameVerifier());
/*  86 */       return conn;
/*     */     } catch (URISyntaxException e) {
/*  88 */       throw ((IOException)new IOException().initCause(e));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Token<DelegationTokenIdentifier> selectHftpDelegationToken()
/*     */   {
/* 102 */     Text serviceName = SecurityUtil.buildTokenService(this.nnAddr);
/* 103 */     return hftpTokenSelector.selectToken(serviceName, this.ugi.getTokens());
/*     */   }
/*     */ 
/*     */   private static class HsftpDelegationTokenSelector extends AbstractDelegationTokenSelector<DelegationTokenIdentifier>
/*     */   {
/*     */     public HsftpDelegationTokenSelector()
/*     */     {
/* 123 */       super();
/*     */     }
/*     */   }
/*     */ 
/*     */   @InterfaceAudience.Private
/*     */   public static class TokenManager extends HftpFileSystem.TokenManager
/*     */   {
/*     */     public boolean handleKind(Text kind)
/*     */     {
/* 111 */       return kind.equals(HsftpFileSystem.TOKEN_KIND);
/*     */     }
/*     */ 
/*     */     protected String getUnderlyingProtocol() {
/* 115 */       return "https";
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static class DummyHostnameVerifier
/*     */     implements HostnameVerifier
/*     */   {
/*     */     public boolean verify(String hostname, SSLSession session)
/*     */     {
/*  97 */       return true;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.HsftpFileSystem
 * JD-Core Version:    0.6.1
 */
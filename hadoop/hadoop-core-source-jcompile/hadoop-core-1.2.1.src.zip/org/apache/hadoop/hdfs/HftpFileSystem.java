/*     */ package org.apache.hadoop.hdfs;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.TimeZone;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.classification.InterfaceAudience.Private;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.ContentSummary;
/*     */ import org.apache.hadoop.fs.FSDataInputStream;
/*     */ import org.apache.hadoop.fs.FSDataOutputStream;
/*     */ import org.apache.hadoop.fs.FSInputStream;
/*     */ import org.apache.hadoop.fs.FileChecksum;
/*     */ import org.apache.hadoop.fs.FileStatus;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.MD5MD5CRC32FileChecksum;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenIdentifier;
/*     */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenRenewer;
/*     */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenRenewer.Renewable;
/*     */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenSelector;
/*     */ import org.apache.hadoop.hdfs.server.namenode.JspHelper;
/*     */ import org.apache.hadoop.hdfs.tools.DelegationTokenFetcher;
/*     */ import org.apache.hadoop.io.Text;
/*     */ import org.apache.hadoop.ipc.RemoteException;
/*     */ import org.apache.hadoop.net.NetUtils;
/*     */ import org.apache.hadoop.security.Credentials;
/*     */ import org.apache.hadoop.security.SecurityUtil;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.token.Token;
/*     */ import org.apache.hadoop.security.token.TokenIdentifier;
/*     */ import org.apache.hadoop.security.token.TokenRenewer;
/*     */ import org.apache.hadoop.security.token.delegation.AbstractDelegationTokenSelector;
/*     */ import org.apache.hadoop.util.Progressable;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ import org.xml.sax.helpers.XMLReaderFactory;
/*     */ 
/*     */ public class HftpFileSystem extends FileSystem
/*     */   implements DelegationTokenRenewer.Renewable
/*     */ {
/*  79 */   private static final DelegationTokenRenewer<HftpFileSystem> dtRenewer = new DelegationTokenRenewer(HftpFileSystem.class);
/*     */ 
/*  86 */   public static final Text TOKEN_KIND = new Text("HFTP delegation");
/*     */   protected UserGroupInformation ugi;
/*     */   private boolean remoteIsInsecure;
/*     */   private URI hftpURI;
/*     */   protected InetSocketAddress nnAddr;
/*     */   public static final String HFTP_TIMEZONE = "UTC";
/*     */   public static final String HFTP_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ssZ";
/*     */   private Token<?> delegationToken;
/*     */   private boolean createdToken;
/*     */   private Token<?> renewToken;
/* 100 */   private static final HftpDelegationTokenSelector hftpTokenSelector = new HftpDelegationTokenSelector();
/*     */ 
/* 109 */   protected static final ThreadLocal<SimpleDateFormat> df = new ThreadLocal()
/*     */   {
/*     */     protected SimpleDateFormat initialValue() {
/* 112 */       return HftpFileSystem.getDateFormat();
/*     */     }
/* 109 */   };
/*     */ 
/*     */   public HftpFileSystem()
/*     */   {
/*  89 */     this.remoteIsInsecure = false;
/*     */ 
/*  98 */     this.createdToken = false;
/*     */   }
/*     */ 
/*     */   public static final SimpleDateFormat getDateFormat()
/*     */   {
/* 104 */     SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
/* 105 */     df.setTimeZone(TimeZone.getTimeZone("UTC"));
/* 106 */     return df;
/*     */   }
/*     */ 
/*     */   protected int getDefaultPort()
/*     */   {
/* 118 */     return getConf().getInt("dfs.http.port", 50070);
/*     */   }
/*     */ 
/*     */   protected InetSocketAddress getNamenodeAddr(URI uri)
/*     */   {
/* 124 */     return NetUtils.createSocketAddr(uri.getAuthority(), getDefaultPort());
/*     */   }
/*     */ 
/*     */   public String getCanonicalServiceName()
/*     */   {
/* 129 */     return SecurityUtil.buildTokenService(this.nnAddr).toString();
/*     */   }
/*     */ 
/*     */   public void initialize(URI name, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 135 */     setConf(conf);
/* 136 */     super.initialize(name, conf);
/* 137 */     this.ugi = UserGroupInformation.getCurrentUser();
/* 138 */     this.nnAddr = getNamenodeAddr(name);
/* 139 */     this.hftpURI = DFSUtil.createUri(name.getScheme(), this.nnAddr);
/*     */   }
/*     */ 
/*     */   protected void initDelegationToken() throws IOException
/*     */   {
/* 144 */     Token token = selectHftpDelegationToken();
/* 145 */     if (token == null) {
/* 146 */       token = selectHdfsDelegationToken();
/*     */     }
/*     */ 
/* 150 */     if (token == null) {
/* 151 */       token = getDelegationToken(null);
/* 152 */       this.createdToken = (token != null);
/*     */     }
/*     */ 
/* 156 */     if (token != null) {
/* 157 */       setDelegationToken(token);
/* 158 */       if (this.createdToken) {
/* 159 */         dtRenewer.addRenewAction(this);
/* 160 */         LOG.debug(new StringBuilder().append("Created new DT for ").append(token.getService()).toString());
/*     */       } else {
/* 162 */         LOG.debug(new StringBuilder().append("Found existing DT for ").append(token.getService()).toString());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Token<DelegationTokenIdentifier> selectHftpDelegationToken() {
/* 168 */     Text serviceName = SecurityUtil.buildTokenService(this.nnAddr);
/* 169 */     return hftpTokenSelector.selectToken(serviceName, this.ugi.getTokens());
/*     */   }
/*     */ 
/*     */   protected Token<DelegationTokenIdentifier> selectHdfsDelegationToken() {
/* 173 */     return DelegationTokenSelector.selectHdfsDelegationToken(this.nnAddr, this.ugi, getConf());
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 180 */     if (this.createdToken) {
/*     */       try {
/* 182 */         this.renewToken.cancel(getConf());
/*     */       } catch (InterruptedException ie) {
/* 184 */         throw new RuntimeException(ie);
/*     */       }
/*     */     }
/* 187 */     super.close();
/*     */   }
/*     */ 
/*     */   public Token<?> getRenewToken()
/*     */   {
/* 192 */     return this.renewToken;
/*     */   }
/*     */ 
/*     */   protected String getUnderlyingProtocol()
/*     */   {
/* 199 */     return "http";
/*     */   }
/*     */ 
/*     */   public <T extends TokenIdentifier> void setDelegationToken(Token<T> token)
/*     */   {
/* 204 */     this.renewToken = token;
/*     */ 
/* 207 */     this.delegationToken = new Token(token);
/*     */ 
/* 209 */     this.delegationToken.setKind(DelegationTokenIdentifier.HDFS_DELEGATION_KIND);
/*     */   }
/*     */ 
/*     */   public synchronized Token<?> getDelegationToken(final String renewer)
/*     */     throws IOException
/*     */   {
/* 220 */     this.ugi.checkTGTAndReloginFromKeytab();
/*     */     Credentials c;
/*     */     try
/*     */     {
/* 223 */       c = (Credentials)this.ugi.doAs(new PrivilegedExceptionAction() {
/*     */         public Credentials run() throws Exception {
/* 225 */           return DelegationTokenFetcher.getDTfromRemote(HftpFileSystem.this.getUnderlyingProtocol(), HftpFileSystem.this.nnAddr, renewer, HftpFileSystem.this.getConf());
/*     */         }
/*     */ 
/*     */       });
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 233 */       LOG.info(new StringBuilder().append("Couldn't get a delegation token from ").append(this.nnAddr).toString());
/* 234 */       LOG.debug("error was ", e);
/*     */ 
/* 236 */       this.remoteIsInsecure = true;
/* 237 */       return null;
/*     */     }
/* 239 */     Iterator i$ = c.getAllTokens().iterator(); if (i$.hasNext()) { Token t = (Token)i$.next();
/* 240 */       LOG.debug(new StringBuilder().append("Got dt for ").append(getUri()).append(";t.service=").append(t.getService()).toString());
/* 241 */       return t;
/*     */     }
/* 243 */     return null;
/*     */   }
/*     */ 
/*     */   public URI getUri()
/*     */   {
/* 248 */     return this.hftpURI;
/*     */   }
/*     */ 
/*     */   private String getUgiParameter()
/*     */   {
/* 257 */     StringBuilder ugiParamenter = new StringBuilder(this.ugi.getShortUserName());
/* 258 */     for (String g : this.ugi.getGroupNames()) {
/* 259 */       ugiParamenter.append(",");
/* 260 */       ugiParamenter.append(g);
/*     */     }
/* 262 */     return ugiParamenter.toString();
/*     */   }
/*     */ 
/*     */   static Void throwIOExceptionFromConnection(HttpURLConnection connection, IOException ioe)
/*     */     throws IOException
/*     */   {
/* 268 */     int code = connection.getResponseCode();
/* 269 */     String s = connection.getResponseMessage();
/* 270 */     throw (s == null ? ioe : new IOException(new StringBuilder().append(s).append(" (error code=").append(code).append(")").toString(), ioe));
/*     */   }
/*     */ 
/*     */   protected HttpURLConnection openConnection(String path, String query)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 282 */       query = updateQuery(query);
/* 283 */       URL url = new URI(getUnderlyingProtocol(), null, this.nnAddr.getHostName(), this.nnAddr.getPort(), path, query, null).toURL();
/*     */ 
/* 286 */       if (LOG.isTraceEnabled()) {
/* 287 */         LOG.trace(new StringBuilder().append("url=").append(url).toString());
/*     */       }
/* 289 */       return (HttpURLConnection)url.openConnection();
/*     */     } catch (URISyntaxException e) {
/* 291 */       throw ((IOException)new IOException().initCause(e));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String updateQuery(String query) throws IOException {
/* 296 */     String tokenString = null;
/* 297 */     if (UserGroupInformation.isSecurityEnabled()) {
/* 298 */       synchronized (this) {
/* 299 */         if ((this.delegationToken == null) && (!this.remoteIsInsecure)) {
/* 300 */           initDelegationToken();
/*     */         }
/* 302 */         if (this.delegationToken != null) {
/* 303 */           tokenString = this.delegationToken.encodeToUrlString();
/* 304 */           return new StringBuilder().append(query).append(JspHelper.getDelegationTokenUrlParam(tokenString)).toString();
/*     */         }
/*     */       }
/*     */     }
/* 308 */     return query;
/*     */   }
/*     */ 
/*     */   public FSDataInputStream open(Path f, int buffersize) throws IOException
/*     */   {
/* 313 */     HttpURLConnection connection = openConnection(new StringBuilder().append("/data").append(f.makeQualified(this).toUri().getPath()).toString(), new StringBuilder().append("ugi=").append(getUgiParameter()).toString());
/*     */     InputStream in;
/*     */     try
/*     */     {
/* 318 */       connection.setRequestMethod("GET");
/* 319 */       connection.connect();
/* 320 */       in = connection.getInputStream();
/*     */     } catch (IOException ioe) {
/* 322 */       int code = connection.getResponseCode();
/* 323 */       String s = connection.getResponseMessage();
/* 324 */       throw (s == null ? ioe : new IOException(new StringBuilder().append(s).append(" (error code=").append(code).append(")").toString(), ioe));
/*     */     }
/*     */ 
/* 328 */     String cl = connection.getHeaderField("Content-Length");
/* 329 */     final long filelength = cl == null ? -1L : Long.parseLong(cl);
/* 330 */     if (LOG.isDebugEnabled()) {
/* 331 */       LOG.debug(new StringBuilder().append("filelength = ").append(filelength).toString());
/*     */     }
/*     */ 
/* 334 */     return new FSDataInputStream(new FSInputStream() {
/* 335 */       long currentPos = 0L;
/*     */ 
/*     */       private void update(boolean isEOF, int n) throws IOException
/*     */       {
/* 339 */         if (!isEOF)
/* 340 */           this.currentPos += n;
/* 341 */         else if (this.currentPos < filelength)
/* 342 */           throw new IOException("Got EOF but byteread = " + this.currentPos + " < filelength = " + filelength);
/*     */       }
/*     */ 
/*     */       public int read() throws IOException
/*     */       {
/* 347 */         int b = this.val$in.read();
/* 348 */         update(b == -1, 1);
/* 349 */         return b;
/*     */       }
/*     */       public int read(byte[] b, int off, int len) throws IOException {
/* 352 */         int n = this.val$in.read(b, off, len);
/* 353 */         update(n == -1, n);
/* 354 */         return n;
/*     */       }
/*     */ 
/*     */       public void close() throws IOException {
/* 358 */         this.val$in.close();
/*     */       }
/*     */ 
/*     */       public void seek(long pos) throws IOException {
/* 362 */         throw new IOException("Can't seek!");
/*     */       }
/*     */       public long getPos() throws IOException {
/* 365 */         throw new IOException("Position unknown!");
/*     */       }
/*     */       public boolean seekToNewSource(long targetPos) throws IOException {
/* 368 */         return false;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public FileStatus[] listStatus(Path f)
/*     */     throws IOException
/*     */   {
/* 457 */     LsParser lsparser = new LsParser();
/* 458 */     return lsparser.listStatus(f);
/*     */   }
/*     */ 
/*     */   public FileStatus getFileStatus(Path f) throws IOException
/*     */   {
/* 463 */     LsParser lsparser = new LsParser();
/* 464 */     return lsparser.getFileStatus(f);
/*     */   }
/*     */ 
/*     */   public FileChecksum getFileChecksum(Path f)
/*     */     throws IOException
/*     */   {
/* 509 */     String s = makeQualified(f).toUri().getPath();
/* 510 */     return new ChecksumParser(null).getFileChecksum(s);
/*     */   }
/*     */ 
/*     */   public Path getWorkingDirectory()
/*     */   {
/* 515 */     return new Path("/").makeQualified(this);
/*     */   }
/*     */ 
/*     */   public void setWorkingDirectory(Path f)
/*     */   {
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream append(Path f, int bufferSize, Progressable progress) throws IOException
/*     */   {
/* 524 */     throw new IOException("Not supported");
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream create(Path f, FsPermission permission, boolean overwrite, int bufferSize, short replication, long blockSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 532 */     throw new IOException("Not supported");
/*     */   }
/*     */ 
/*     */   public boolean rename(Path src, Path dst) throws IOException
/*     */   {
/* 537 */     throw new IOException("Not supported");
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public boolean delete(Path f)
/*     */     throws IOException
/*     */   {
/* 546 */     throw new IOException("Not supported");
/*     */   }
/*     */ 
/*     */   public boolean delete(Path f, boolean recursive) throws IOException
/*     */   {
/* 551 */     throw new IOException("Not supported");
/*     */   }
/*     */ 
/*     */   public boolean mkdirs(Path f, FsPermission permission) throws IOException
/*     */   {
/* 556 */     throw new IOException("Not supported");
/*     */   }
/*     */ 
/*     */   private static ContentSummary toContentSummary(Attributes attrs)
/*     */     throws SAXException
/*     */   {
/* 616 */     String length = attrs.getValue("length");
/* 617 */     String fileCount = attrs.getValue("fileCount");
/* 618 */     String directoryCount = attrs.getValue("directoryCount");
/* 619 */     String quota = attrs.getValue("quota");
/* 620 */     String spaceConsumed = attrs.getValue("spaceConsumed");
/* 621 */     String spaceQuota = attrs.getValue("spaceQuota");
/*     */ 
/* 623 */     if ((length == null) || (fileCount == null) || (directoryCount == null) || (quota == null) || (spaceConsumed == null) || (spaceQuota == null))
/*     */     {
/* 629 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 633 */       return new ContentSummary(Long.parseLong(length), Long.parseLong(fileCount), Long.parseLong(directoryCount), Long.parseLong(quota), Long.parseLong(spaceConsumed), Long.parseLong(spaceQuota));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 641 */       throw new SAXException(new StringBuilder().append("Invalid attributes: length=").append(length).append(", fileCount=").append(fileCount).append(", directoryCount=").append(directoryCount).append(", quota=").append(quota).append(", spaceConsumed=").append(spaceConsumed).append(", spaceQuota=").append(spaceQuota).toString(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ContentSummary getContentSummary(Path f)
/*     */     throws IOException
/*     */   {
/* 652 */     String s = makeQualified(f).toUri().getPath();
/* 653 */     ContentSummary cs = new ContentSummaryParser(null).getContentSummary(s);
/* 654 */     return cs != null ? cs : super.getContentSummary(f);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  83 */     HttpURLConnection.setFollowRedirects(true);
/*     */   }
/*     */ 
/*     */   private static class HftpDelegationTokenSelector extends AbstractDelegationTokenSelector<DelegationTokenIdentifier>
/*     */   {
/*     */     public HftpDelegationTokenSelector()
/*     */     {
/* 708 */       super();
/*     */     }
/*     */   }
/*     */ 
/*     */   @InterfaceAudience.Private
/*     */   public static class TokenManager extends TokenRenewer
/*     */   {
/*     */     public boolean handleKind(Text kind)
/*     */     {
/* 662 */       return kind.equals(HftpFileSystem.TOKEN_KIND);
/*     */     }
/*     */ 
/*     */     public boolean isManaged(Token<?> token) throws IOException
/*     */     {
/* 667 */       return true;
/*     */     }
/*     */ 
/*     */     protected String getUnderlyingProtocol() {
/* 671 */       return "http";
/*     */     }
/*     */ 
/*     */     public long renew(Token<?> token, Configuration conf)
/*     */       throws IOException
/*     */     {
/* 679 */       UserGroupInformation.getLoginUser().checkTGTAndReloginFromKeytab();
/* 680 */       InetSocketAddress serviceAddr = SecurityUtil.getTokenServiceAddr(token);
/* 681 */       return DelegationTokenFetcher.renewDelegationToken(getUnderlyingProtocol(), serviceAddr, token, conf);
/*     */     }
/*     */ 
/*     */     public void cancel(Token<?> token, Configuration conf)
/*     */       throws IOException
/*     */     {
/* 693 */       UserGroupInformation.getLoginUser().checkTGTAndReloginFromKeytab();
/* 694 */       InetSocketAddress serviceAddr = SecurityUtil.getTokenServiceAddr(token);
/* 695 */       DelegationTokenFetcher.cancelDelegationToken(getUnderlyingProtocol(), serviceAddr, token, conf);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ContentSummaryParser extends DefaultHandler
/*     */   {
/*     */     private ContentSummary contentsummary;
/*     */ 
/*     */     private ContentSummaryParser()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void startElement(String ns, String localname, String qname, Attributes attrs)
/*     */       throws SAXException
/*     */     {
/* 568 */       if (!ContentSummary.class.getName().equals(qname)) {
/* 569 */         if (RemoteException.class.getSimpleName().equals(qname)) {
/* 570 */           throw new SAXException(RemoteException.valueOf(attrs));
/*     */         }
/* 572 */         throw new SAXException("Unrecognized entry: " + qname);
/*     */       }
/*     */ 
/* 575 */       this.contentsummary = HftpFileSystem.toContentSummary(attrs);
/*     */     }
/*     */ 
/*     */     private ContentSummary getContentSummary(String path)
/*     */       throws IOException
/*     */     {
/* 585 */       HttpURLConnection connection = HftpFileSystem.this.openConnection("/contentSummary" + path, "ugi=" + HftpFileSystem.this.getUgiParameter());
/*     */ 
/* 587 */       InputStream in = null;
/*     */       try {
/* 589 */         in = connection.getInputStream();
/*     */ 
/* 591 */         XMLReader xr = XMLReaderFactory.createXMLReader();
/* 592 */         xr.setContentHandler(this);
/* 593 */         xr.parse(new InputSource(in));
/*     */       }
/*     */       catch (FileNotFoundException fnfe) {
/* 596 */         return null;
/*     */       } catch (SAXException saxe) {
/* 598 */         Exception embedded = saxe.getException();
/* 599 */         if ((embedded != null) && ((embedded instanceof IOException))) {
/* 600 */           throw ((IOException)embedded);
/*     */         }
/* 602 */         throw new IOException("Invalid xml format", saxe);
/*     */       } finally {
/* 604 */         if (in != null) {
/* 605 */           in.close();
/*     */         }
/* 607 */         connection.disconnect();
/*     */       }
/* 609 */       return this.contentsummary;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ChecksumParser extends DefaultHandler
/*     */   {
/*     */     private FileChecksum filechecksum;
/*     */ 
/*     */     private ChecksumParser()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void startElement(String ns, String localname, String qname, Attributes attrs)
/*     */       throws SAXException
/*     */     {
/* 473 */       if (!MD5MD5CRC32FileChecksum.class.getName().equals(qname)) {
/* 474 */         if (RemoteException.class.getSimpleName().equals(qname)) {
/* 475 */           throw new SAXException(RemoteException.valueOf(attrs));
/*     */         }
/* 477 */         throw new SAXException("Unrecognized entry: " + qname);
/*     */       }
/*     */ 
/* 480 */       this.filechecksum = MD5MD5CRC32FileChecksum.valueOf(attrs);
/*     */     }
/*     */ 
/*     */     private FileChecksum getFileChecksum(String f) throws IOException {
/* 484 */       HttpURLConnection connection = HftpFileSystem.this.openConnection("/fileChecksum" + f, "ugi=" + HftpFileSystem.this.getUgiParameter());
/*     */       try
/*     */       {
/* 487 */         XMLReader xr = XMLReaderFactory.createXMLReader();
/* 488 */         xr.setContentHandler(this);
/*     */ 
/* 490 */         connection.setRequestMethod("GET");
/* 491 */         connection.connect();
/*     */ 
/* 493 */         xr.parse(new InputSource(connection.getInputStream()));
/*     */       } catch (SAXException e) {
/* 495 */         Exception embedded = e.getException();
/* 496 */         if ((embedded != null) && ((embedded instanceof IOException))) {
/* 497 */           throw ((IOException)embedded);
/*     */         }
/* 499 */         throw new IOException("invalid xml directory content", e);
/*     */       } finally {
/* 501 */         connection.disconnect();
/*     */       }
/* 503 */       return this.filechecksum;
/*     */     }
/*     */   }
/*     */ 
/*     */   class LsParser extends DefaultHandler
/*     */   {
/* 376 */     ArrayList<FileStatus> fslist = new ArrayList();
/*     */ 
/*     */     LsParser() {
/*     */     }
/* 380 */     public void startElement(String ns, String localname, String qname, Attributes attrs) throws SAXException { if ("listing".equals(qname)) return;
/* 381 */       if ((!"file".equals(qname)) && (!"directory".equals(qname))) {
/* 382 */         if (RemoteException.class.getSimpleName().equals(qname)) {
/* 383 */           throw new SAXException(RemoteException.valueOf(attrs));
/*     */         }
/* 385 */         throw new SAXException(new StringBuilder().append("Unrecognized entry: ").append(qname).toString());
/* 388 */       }
/*     */ long atime = 0L;
/*     */       long modif;
/*     */       try { SimpleDateFormat ldf = (SimpleDateFormat)HftpFileSystem.df.get();
/* 391 */         modif = ldf.parse(attrs.getValue("modified")).getTime();
/* 392 */         String astr = attrs.getValue("accesstime");
/* 393 */         if (astr != null)
/* 394 */           atime = ldf.parse(astr).getTime();
/*     */       } catch (ParseException e) {
/* 396 */         throw new SAXException(e);
/* 397 */       }FileStatus fs = "file".equals(qname) ? new FileStatus(Long.valueOf(attrs.getValue("size")).longValue(), false, Short.valueOf(attrs.getValue("replication")).shortValue(), Long.valueOf(attrs.getValue("blocksize")).longValue(), modif, atime, FsPermission.valueOf(attrs.getValue("permission")), attrs.getValue("owner"), attrs.getValue("group"), new Path(HftpFileSystem.this.getUri().toString(), attrs.getValue("path")).makeQualified(HftpFileSystem.this)) : new FileStatus(0L, true, 0, 0L, modif, atime, FsPermission.valueOf(attrs.getValue("permission")), attrs.getValue("owner"), attrs.getValue("group"), new Path(HftpFileSystem.this.getUri().toString(), attrs.getValue("path")).makeQualified(HftpFileSystem.this));
/*     */ 
/* 411 */       this.fslist.add(fs); }
/*     */ 
/*     */     private void fetchList(String path, boolean recur) throws IOException
/*     */     {
/*     */       try {
/* 416 */         XMLReader xr = XMLReaderFactory.createXMLReader();
/* 417 */         xr.setContentHandler(this);
/* 418 */         HttpURLConnection connection = HftpFileSystem.this.openConnection(new StringBuilder().append("/listPaths").append(path).toString(), new StringBuilder().append("ugi=").append(HftpFileSystem.this.getUgiParameter()).append(recur ? "&recursive=yes" : "").toString());
/*     */ 
/* 420 */         connection.setRequestMethod("GET");
/* 421 */         connection.connect();
/*     */ 
/* 423 */         InputStream resp = connection.getInputStream();
/* 424 */         xr.parse(new InputSource(resp));
/*     */       } catch (SAXException e) {
/* 426 */         Exception embedded = e.getException();
/* 427 */         if ((embedded != null) && ((embedded instanceof IOException))) {
/* 428 */           throw ((IOException)embedded);
/*     */         }
/* 430 */         throw new IOException("invalid xml directory content", e);
/*     */       }
/*     */     }
/*     */ 
/*     */     public FileStatus getFileStatus(Path f) throws IOException {
/* 435 */       fetchList(f.toUri().getPath(), false);
/* 436 */       if (this.fslist.size() == 0) {
/* 437 */         throw new FileNotFoundException(new StringBuilder().append("File does not exist: ").append(f).toString());
/*     */       }
/* 439 */       return (FileStatus)this.fslist.get(0);
/*     */     }
/*     */ 
/*     */     public FileStatus[] listStatus(Path f, boolean recur) throws IOException {
/* 443 */       fetchList(f.toUri().getPath(), recur);
/* 444 */       if ((this.fslist.size() > 0) && ((this.fslist.size() != 1) || (((FileStatus)this.fslist.get(0)).isDir()))) {
/* 445 */         this.fslist.remove(0);
/*     */       }
/* 447 */       return (FileStatus[])this.fslist.toArray(new FileStatus[0]);
/*     */     }
/*     */ 
/*     */     public FileStatus[] listStatus(Path f) throws IOException {
/* 451 */       return listStatus(f, false);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.HftpFileSystem
 * JD-Core Version:    0.6.1
 */
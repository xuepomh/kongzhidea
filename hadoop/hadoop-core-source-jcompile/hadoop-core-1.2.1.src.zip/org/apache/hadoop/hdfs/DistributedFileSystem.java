/*     */ package org.apache.hadoop.hdfs;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.BlockLocation;
/*     */ import org.apache.hadoop.fs.ContentSummary;
/*     */ import org.apache.hadoop.fs.FSDataInputStream;
/*     */ import org.apache.hadoop.fs.FSDataOutputStream;
/*     */ import org.apache.hadoop.fs.FileStatus;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.FileSystem.Statistics;
/*     */ import org.apache.hadoop.fs.MD5MD5CRC32FileChecksum;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.hdfs.protocol.DirectoryListing;
/*     */ import org.apache.hadoop.hdfs.protocol.FSConstants.DatanodeReportType;
/*     */ import org.apache.hadoop.hdfs.protocol.FSConstants.SafeModeAction;
/*     */ import org.apache.hadoop.hdfs.protocol.FSConstants.UpgradeAction;
/*     */ import org.apache.hadoop.hdfs.protocol.HdfsFileStatus;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlock;
/*     */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenIdentifier;
/*     */ import org.apache.hadoop.hdfs.server.common.UpgradeStatusReport;
/*     */ import org.apache.hadoop.hdfs.server.namenode.NameNode;
/*     */ import org.apache.hadoop.io.IOUtils;
/*     */ import org.apache.hadoop.io.Text;
/*     */ import org.apache.hadoop.security.AccessControlException;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.token.SecretManager.InvalidToken;
/*     */ import org.apache.hadoop.security.token.Token;
/*     */ import org.apache.hadoop.util.Progressable;
/*     */ 
/*     */ public class DistributedFileSystem extends FileSystem
/*     */ {
/*     */   private Path workingDir;
/*     */   private URI uri;
/*     */   DFSClient dfs;
/*  69 */   private boolean verifyChecksum = true;
/*     */ 
/*     */   public DistributedFileSystem()
/*     */   {
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public DistributedFileSystem(InetSocketAddress namenode, Configuration conf)
/*     */     throws IOException
/*     */   {
/*  82 */     initialize(NameNode.getUri(namenode), conf);
/*     */   }
/*     */   /** @deprecated */
/*     */   public String getName() {
/*  86 */     return this.uri.getAuthority();
/*     */   }
/*  88 */   public URI getUri() { return this.uri; }
/*     */ 
/*     */   public void initialize(URI uri, Configuration conf) throws IOException {
/*  91 */     super.initialize(uri, conf);
/*  92 */     setConf(conf);
/*     */ 
/*  94 */     String host = uri.getHost();
/*  95 */     if (host == null) {
/*  96 */       throw new IOException("Incomplete HDFS URI, no host: " + uri);
/*     */     }
/*     */ 
/*  99 */     InetSocketAddress namenode = NameNode.getAddress(uri.getAuthority());
/* 100 */     this.dfs = new DFSClient(namenode, conf, this.statistics);
/* 101 */     this.uri = URI.create(uri.getScheme() + "://" + uri.getAuthority());
/* 102 */     this.workingDir = getHomeDirectory();
/*     */   }
/*     */ 
/*     */   public Path getWorkingDirectory() {
/* 106 */     return this.workingDir;
/*     */   }
/*     */ 
/*     */   public long getDefaultBlockSize() {
/* 110 */     return this.dfs.getDefaultBlockSize();
/*     */   }
/*     */ 
/*     */   public short getDefaultReplication() {
/* 114 */     return this.dfs.getDefaultReplication();
/*     */   }
/*     */ 
/*     */   private Path makeAbsolute(Path f) {
/* 118 */     if (f.isAbsolute()) {
/* 119 */       return f;
/*     */     }
/* 121 */     return new Path(this.workingDir, f);
/*     */   }
/*     */ 
/*     */   public void setWorkingDirectory(Path dir)
/*     */   {
/* 126 */     String result = makeAbsolute(dir).toUri().getPath();
/* 127 */     if (!DFSUtil.isValidName(result)) {
/* 128 */       throw new IllegalArgumentException("Invalid DFS directory name " + result);
/*     */     }
/*     */ 
/* 131 */     this.workingDir = makeAbsolute(dir);
/*     */   }
/*     */ 
/*     */   public Path getHomeDirectory()
/*     */   {
/* 136 */     return new Path("/user/" + this.dfs.ugi.getShortUserName()).makeQualified(this);
/*     */   }
/*     */ 
/*     */   private String getPathName(Path file) {
/* 140 */     checkPath(file);
/* 141 */     String result = makeAbsolute(file).toUri().getPath();
/* 142 */     if (!DFSUtil.isValidName(result)) {
/* 143 */       throw new IllegalArgumentException("Pathname " + result + " from " + file + " is not a valid DFS filename.");
/*     */     }
/*     */ 
/* 146 */     return result;
/*     */   }
/*     */ 
/*     */   public BlockLocation[] getFileBlockLocations(FileStatus file, long start, long len)
/*     */     throws IOException
/*     */   {
/* 152 */     if (file == null) {
/* 153 */       return null;
/*     */     }
/* 155 */     this.statistics.incrementReadOps(1);
/* 156 */     return this.dfs.getBlockLocations(getPathName(file.getPath()), start, len);
/*     */   }
/*     */ 
/*     */   public void setVerifyChecksum(boolean verifyChecksum) {
/* 160 */     this.verifyChecksum = verifyChecksum;
/*     */   }
/*     */ 
/*     */   public FSDataInputStream open(Path f, int bufferSize) throws IOException {
/* 164 */     this.statistics.incrementReadOps(1);
/* 165 */     return new DFSClient.DFSDataInputStream(this.dfs.open(getPathName(f), bufferSize, this.verifyChecksum, this.statistics));
/*     */   }
/*     */ 
/*     */   public boolean isFileClosed(Path src)
/*     */     throws IOException
/*     */   {
/* 178 */     return this.dfs.isFileClosed(getPathName(src));
/*     */   }
/*     */ 
/*     */   public boolean recoverLease(Path f)
/*     */     throws IOException
/*     */   {
/* 189 */     return this.dfs.recoverLease(getPathName(f));
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream append(Path f, int bufferSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 195 */     this.statistics.incrementWriteOps(1);
/* 196 */     return this.dfs.append(getPathName(f), bufferSize, progress, this.statistics);
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream create(Path f, FsPermission permission, boolean overwrite, int bufferSize, short replication, long blockSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 204 */     this.statistics.incrementWriteOps(1);
/* 205 */     return new FSDataOutputStream(this.dfs.create(getPathName(f), permission, overwrite, true, replication, blockSize, progress, bufferSize), this.statistics);
/*     */   }
/*     */ 
/*     */   public FSDataOutputStream createNonRecursive(Path f, FsPermission permission, boolean overwrite, int bufferSize, short replication, long blockSize, Progressable progress)
/*     */     throws IOException
/*     */   {
/* 220 */     this.statistics.incrementWriteOps(1);
/* 221 */     return new FSDataOutputStream(this.dfs.create(getPathName(f), permission, overwrite, false, replication, blockSize, progress, bufferSize), this.statistics);
/*     */   }
/*     */ 
/*     */   public boolean setReplication(Path src, short replication)
/*     */     throws IOException
/*     */   {
/* 230 */     this.statistics.incrementWriteOps(1);
/* 231 */     return this.dfs.setReplication(getPathName(src), replication);
/*     */   }
/*     */ 
/*     */   public void concat(Path trg, Path[] psrcs)
/*     */     throws IOException
/*     */   {
/* 244 */     String[] srcs = new String[psrcs.length];
/* 245 */     for (int i = 0; i < psrcs.length; i++) {
/* 246 */       srcs[i] = getPathName(psrcs[i]);
/*     */     }
/* 248 */     this.statistics.incrementWriteOps(1);
/* 249 */     this.dfs.concat(getPathName(trg), srcs);
/*     */   }
/*     */ 
/*     */   public boolean rename(Path src, Path dst)
/*     */     throws IOException
/*     */   {
/* 256 */     this.statistics.incrementWriteOps(1);
/* 257 */     return this.dfs.rename(getPathName(src), getPathName(dst));
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public boolean delete(Path f)
/*     */     throws IOException
/*     */   {
/* 265 */     this.statistics.incrementWriteOps(1);
/* 266 */     return this.dfs.delete(getPathName(f));
/*     */   }
/*     */ 
/*     */   public boolean delete(Path f, boolean recursive)
/*     */     throws IOException
/*     */   {
/* 274 */     this.statistics.incrementWriteOps(1);
/* 275 */     return this.dfs.delete(getPathName(f), recursive);
/*     */   }
/*     */ 
/*     */   public ContentSummary getContentSummary(Path f) throws IOException
/*     */   {
/* 280 */     this.statistics.incrementReadOps(1);
/* 281 */     return this.dfs.getContentSummary(getPathName(f));
/*     */   }
/*     */ 
/*     */   public void setQuota(Path src, long namespaceQuota, long diskspaceQuota)
/*     */     throws IOException
/*     */   {
/* 289 */     this.dfs.setQuota(getPathName(src), namespaceQuota, diskspaceQuota);
/*     */   }
/*     */ 
/*     */   private FileStatus makeQualified(HdfsFileStatus f, Path parent) {
/* 293 */     return new FileStatus(f.getLen(), f.isDir(), f.getReplication(), f.getBlockSize(), f.getModificationTime(), f.getAccessTime(), f.getPermission(), f.getOwner(), f.getGroup(), f.getFullPath(parent).makeQualified(this));
/*     */   }
/*     */ 
/*     */   public FileStatus[] listStatus(Path p)
/*     */     throws IOException
/*     */   {
/* 310 */     String src = getPathName(p);
/*     */ 
/* 313 */     DirectoryListing thisListing = this.dfs.listPaths(src, HdfsFileStatus.EMPTY_NAME);
/*     */ 
/* 316 */     if (thisListing == null) {
/* 317 */       return null;
/*     */     }
/*     */ 
/* 320 */     HdfsFileStatus[] partialListing = thisListing.getPartialListing();
/* 321 */     if (!thisListing.hasMore()) {
/* 322 */       FileStatus[] stats = new FileStatus[partialListing.length];
/* 323 */       for (int i = 0; i < partialListing.length; i++) {
/* 324 */         stats[i] = makeQualified(partialListing[i], p);
/*     */       }
/* 326 */       this.statistics.incrementReadOps(1);
/* 327 */       return stats;
/*     */     }
/*     */ 
/* 332 */     int totalNumEntries = partialListing.length + thisListing.getRemainingEntries();
/*     */ 
/* 334 */     ArrayList listing = new ArrayList(totalNumEntries);
/*     */ 
/* 337 */     for (HdfsFileStatus fileStatus : partialListing) {
/* 338 */       listing.add(makeQualified(fileStatus, p));
/*     */     }
/* 340 */     this.statistics.incrementLargeReadOps(1);
/*     */     do
/*     */     {
/* 344 */       thisListing = this.dfs.listPaths(src, thisListing.getLastName());
/*     */ 
/* 346 */       if (thisListing == null) {
/* 347 */         return null;
/*     */       }
/*     */ 
/* 350 */       partialListing = thisListing.getPartialListing();
/* 351 */       for (HdfsFileStatus fileStatus : partialListing) {
/* 352 */         listing.add(makeQualified(fileStatus, p));
/*     */       }
/* 354 */       this.statistics.incrementLargeReadOps(1);
/* 355 */     }while (thisListing.hasMore());
/*     */ 
/* 357 */     return (FileStatus[])listing.toArray(new FileStatus[listing.size()]);
/*     */   }
/*     */ 
/*     */   public boolean mkdirs(Path f, FsPermission permission) throws IOException {
/* 361 */     this.statistics.incrementWriteOps(1);
/* 362 */     return this.dfs.mkdirs(getPathName(f), permission);
/*     */   }
/*     */ 
/*     */   public void close() throws IOException
/*     */   {
/*     */     try {
/* 368 */       super.processDeleteOnExit();
/* 369 */       this.dfs.close();
/*     */     } finally {
/* 371 */       super.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 376 */     return "DFS[" + this.dfs + "]";
/*     */   }
/*     */ 
/*     */   public DFSClient getClient() {
/* 380 */     return this.dfs;
/*     */   }
/*     */ 
/*     */   public DiskStatus getDiskStatus()
/*     */     throws IOException
/*     */   {
/* 408 */     return this.dfs.getDiskStatus();
/*     */   }
/*     */ 
/*     */   public long getRawCapacity()
/*     */     throws IOException
/*     */   {
/* 414 */     return this.dfs.totalRawCapacity();
/*     */   }
/*     */ 
/*     */   public long getRawUsed()
/*     */     throws IOException
/*     */   {
/* 420 */     return this.dfs.totalRawUsed();
/*     */   }
/*     */ 
/*     */   public long getMissingBlocksCount()
/*     */     throws IOException
/*     */   {
/* 430 */     return this.dfs.getMissingBlocksCount();
/*     */   }
/*     */ 
/*     */   public long getUnderReplicatedBlocksCount()
/*     */     throws IOException
/*     */   {
/* 439 */     return this.dfs.getUnderReplicatedBlocksCount();
/*     */   }
/*     */ 
/*     */   public long getCorruptBlocksCount()
/*     */     throws IOException
/*     */   {
/* 448 */     return this.dfs.getCorruptBlocksCount();
/*     */   }
/*     */ 
/*     */   public DatanodeInfo[] getDataNodeStats() throws IOException
/*     */   {
/* 453 */     return this.dfs.datanodeReport(FSConstants.DatanodeReportType.ALL);
/*     */   }
/*     */ 
/*     */   public boolean setSafeMode(FSConstants.SafeModeAction action)
/*     */     throws IOException
/*     */   {
/* 464 */     return this.dfs.setSafeMode(action);
/*     */   }
/*     */ 
/*     */   public void saveNamespace()
/*     */     throws AccessControlException, IOException
/*     */   {
/* 473 */     this.dfs.saveNamespace();
/*     */   }
/*     */ 
/*     */   public void refreshNodes()
/*     */     throws IOException
/*     */   {
/* 481 */     this.dfs.refreshNodes();
/*     */   }
/*     */ 
/*     */   public void finalizeUpgrade()
/*     */     throws IOException
/*     */   {
/* 489 */     this.dfs.finalizeUpgrade();
/*     */   }
/*     */ 
/*     */   public UpgradeStatusReport distributedUpgradeProgress(FSConstants.UpgradeAction action) throws IOException
/*     */   {
/* 494 */     return this.dfs.distributedUpgradeProgress(action);
/*     */   }
/*     */ 
/*     */   public void metaSave(String pathname)
/*     */     throws IOException
/*     */   {
/* 502 */     this.dfs.metaSave(pathname);
/*     */   }
/*     */ 
/*     */   public boolean reportChecksumFailure(Path f, FSDataInputStream in, long inPos, FSDataInputStream sums, long sumsPos)
/*     */   {
/* 514 */     LocatedBlock[] lblocks = new LocatedBlock[2];
/*     */ 
/* 517 */     DFSClient.DFSDataInputStream dfsIn = (DFSClient.DFSDataInputStream)in;
/* 518 */     Block dataBlock = dfsIn.getCurrentBlock();
/* 519 */     if (dataBlock == null) {
/* 520 */       LOG.error("Error: Current block in data stream is null! ");
/* 521 */       return false;
/*     */     }
/* 523 */     DatanodeInfo[] dataNode = { dfsIn.getCurrentDatanode() };
/* 524 */     lblocks[0] = new LocatedBlock(dataBlock, dataNode);
/* 525 */     LOG.info("Found checksum error in data stream at block=" + dataBlock + " on datanode=" + dataNode[0].getName());
/*     */ 
/* 530 */     DFSClient.DFSDataInputStream dfsSums = (DFSClient.DFSDataInputStream)sums;
/* 531 */     Block sumsBlock = dfsSums.getCurrentBlock();
/* 532 */     if (sumsBlock == null) {
/* 533 */       LOG.error("Error: Current block in checksum stream is null! ");
/* 534 */       return false;
/*     */     }
/* 536 */     DatanodeInfo[] sumsNode = { dfsSums.getCurrentDatanode() };
/* 537 */     lblocks[1] = new LocatedBlock(sumsBlock, sumsNode);
/* 538 */     LOG.info("Found checksum error in checksum stream at block=" + sumsBlock + " on datanode=" + sumsNode[0].getName());
/*     */ 
/* 543 */     this.dfs.reportChecksumFailure(f.toString(), lblocks);
/*     */ 
/* 545 */     return true;
/*     */   }
/*     */ 
/*     */   public FileStatus getFileStatus(Path f)
/*     */     throws IOException
/*     */   {
/* 553 */     this.statistics.incrementReadOps(1);
/* 554 */     HdfsFileStatus fi = this.dfs.getFileInfo(getPathName(f));
/* 555 */     if (fi != null) {
/* 556 */       return makeQualified(fi, f);
/*     */     }
/* 558 */     throw new FileNotFoundException("File does not exist: " + f);
/*     */   }
/*     */ 
/*     */   public MD5MD5CRC32FileChecksum getFileChecksum(Path f)
/*     */     throws IOException
/*     */   {
/* 564 */     this.statistics.incrementReadOps(1);
/* 565 */     return this.dfs.getFileChecksum(getPathName(f));
/*     */   }
/*     */ 
/*     */   public void setPermission(Path p, FsPermission permission)
/*     */     throws IOException
/*     */   {
/* 571 */     this.statistics.incrementWriteOps(1);
/* 572 */     this.dfs.setPermission(getPathName(p), permission);
/*     */   }
/*     */ 
/*     */   public void setOwner(Path p, String username, String groupname)
/*     */     throws IOException
/*     */   {
/* 578 */     if ((username == null) && (groupname == null)) {
/* 579 */       throw new IOException("username == null && groupname == null");
/*     */     }
/* 581 */     this.statistics.incrementWriteOps(1);
/* 582 */     this.dfs.setOwner(getPathName(p), username, groupname);
/*     */   }
/*     */ 
/*     */   public void setTimes(Path p, long mtime, long atime)
/*     */     throws IOException
/*     */   {
/* 588 */     this.statistics.incrementWriteOps(1);
/* 589 */     this.dfs.setTimes(getPathName(p), mtime, atime);
/*     */   }
/*     */ 
/*     */   protected int getDefaultPort()
/*     */   {
/* 594 */     return 8020;
/*     */   }
/*     */ 
/*     */   public Token<DelegationTokenIdentifier> getDelegationToken(String renewer)
/*     */     throws IOException
/*     */   {
/* 601 */     Token result = this.dfs.getDelegationToken(renewer == null ? null : new Text(renewer));
/*     */ 
/* 603 */     return result;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public Token<DelegationTokenIdentifier> getDelegationToken(Text renewer)
/*     */     throws IOException
/*     */   {
/* 622 */     return getDelegationToken(renewer.toString());
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public long renewDelegationToken(Token<DelegationTokenIdentifier> token)
/*     */     throws SecretManager.InvalidToken, IOException
/*     */   {
/*     */     try
/*     */     {
/* 636 */       return token.renew(getConf());
/*     */     } catch (InterruptedException ie) {
/* 638 */       throw new RuntimeException("Caught interrupted", ie);
/*     */     }
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void cancelDelegationToken(Token<DelegationTokenIdentifier> token)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 652 */       token.cancel(getConf());
/*     */     } catch (InterruptedException ie) {
/* 654 */       throw new RuntimeException("Caught interrupted", ie);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setBalancerBandwidth(long bandwidth)
/*     */     throws IOException
/*     */   {
/* 668 */     this.dfs.setBalancerBandwidth(bandwidth);
/*     */   }
/*     */ 
/*     */   public static boolean isHealthy(URI uri)
/*     */   {
/* 680 */     String scheme = uri.getScheme();
/* 681 */     if (!"hdfs".equalsIgnoreCase(scheme)) {
/* 682 */       throw new IllegalArgumentException("This scheme is not hdfs, uri=" + uri);
/*     */     }
/*     */ 
/* 685 */     Configuration conf = new Configuration();
/*     */ 
/* 687 */     conf.setBoolean(String.format("fs.%s.impl.disable.cache", new Object[] { scheme }), true);
/*     */ 
/* 689 */     conf.setBoolean("dfs.client.retry.policy.enabled", false);
/* 690 */     conf.setInt("ipc.client.connect.max.retries", 0);
/*     */ 
/* 692 */     DistributedFileSystem fs = null;
/*     */     try {
/* 694 */       fs = (DistributedFileSystem)FileSystem.get(uri, conf);
/* 695 */       boolean safemode = fs.setSafeMode(FSConstants.SafeModeAction.SAFEMODE_GET);
/* 696 */       if (LOG.isDebugEnabled()) {
/* 697 */         LOG.debug("Is namenode in safemode? " + safemode + "; uri=" + uri);
/*     */       }
/*     */ 
/* 700 */       fs.close();
/* 701 */       fs = null;
/* 702 */       return !safemode;
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */       boolean bool1;
/* 704 */       if (LOG.isDebugEnabled()) {
/* 705 */         LOG.debug("Got an exception for uri=" + uri, e);
/*     */       }
/* 707 */       return false;
/*     */     } finally {
/* 709 */       IOUtils.cleanup(LOG, new Closeable[] { fs });
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  72 */     Configuration.addDefaultResource("hdfs-default.xml");
/*  73 */     Configuration.addDefaultResource("hdfs-site.xml");
/*     */   }
/*     */ 
/*     */   public static class DiskStatus
/*     */   {
/*     */     private long capacity;
/*     */     private long dfsUsed;
/*     */     private long remaining;
/*     */ 
/*     */     public DiskStatus(long capacity, long dfsUsed, long remaining)
/*     */     {
/* 388 */       this.capacity = capacity;
/* 389 */       this.dfsUsed = dfsUsed;
/* 390 */       this.remaining = remaining;
/*     */     }
/*     */ 
/*     */     public long getCapacity() {
/* 394 */       return this.capacity;
/*     */     }
/*     */     public long getDfsUsed() {
/* 397 */       return this.dfsUsed;
/*     */     }
/*     */     public long getRemaining() {
/* 400 */       return this.remaining;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.DistributedFileSystem
 * JD-Core Version:    0.6.1
 */
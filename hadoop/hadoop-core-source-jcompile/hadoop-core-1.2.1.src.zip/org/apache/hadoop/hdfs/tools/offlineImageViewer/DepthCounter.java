/*    */ package org.apache.hadoop.hdfs.tools.offlineImageViewer;
/*    */ 
/*    */ import org.apache.hadoop.classification.InterfaceAudience.Private;
/*    */ import org.apache.hadoop.classification.InterfaceStability.Unstable;
/*    */ 
/*    */ @InterfaceAudience.Private
/*    */ @InterfaceStability.Unstable
/*    */ public class DepthCounter
/*    */ {
/* 30 */   private int depth = 0;
/*    */ 
/* 32 */   public void incLevel() { this.depth += 1; } 
/* 33 */   public void decLevel() { if (this.depth >= 1) this.depth -= 1;  } 
/* 34 */   public int getLevel() { return this.depth; }
/*    */ 
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.tools.offlineImageViewer.DepthCounter
 * JD-Core Version:    0.6.1
 */
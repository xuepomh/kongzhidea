/*    */ package org.apache.hadoop.hdfs.tools;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ import org.apache.hadoop.fs.FileSystem;
/*    */ import org.apache.hadoop.fs.Path;
/*    */ import org.apache.hadoop.hdfs.DistributedFileSystem;
/*    */ 
/*    */ public class HDFSConcat
/*    */ {
/*    */   private static final String def_uri = "hdfs://localhost:9000";
/*    */ 
/*    */   public static void main(String[] args)
/*    */     throws IOException
/*    */   {
/* 36 */     if (args.length < 2) {
/* 37 */       System.err.println("Usage HDFSConcat target srcs..");
/* 38 */       System.exit(0);
/*    */     }
/*    */ 
/* 41 */     Configuration conf = new Configuration();
/* 42 */     String uri = conf.get("fs.default.name", "hdfs://localhost:9000");
/* 43 */     Path path = new Path(uri);
/* 44 */     DistributedFileSystem dfs = (DistributedFileSystem)FileSystem.get(path.toUri(), conf);
/*    */ 
/* 47 */     Path[] srcs = new Path[args.length - 1];
/* 48 */     for (int i = 1; i < args.length; i++) {
/* 49 */       srcs[(i - 1)] = new Path(args[i]);
/*    */     }
/* 51 */     dfs.concat(new Path(args[0]), srcs);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.tools.HDFSConcat
 * JD-Core Version:    0.6.1
 */
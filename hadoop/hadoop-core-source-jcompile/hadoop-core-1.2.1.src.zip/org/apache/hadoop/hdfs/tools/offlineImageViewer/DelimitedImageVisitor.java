/*     */ package org.apache.hadoop.hdfs.tools.offlineImageViewer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ 
/*     */ class DelimitedImageVisitor extends TextWriterImageVisitor
/*     */ {
/*     */   private static final String defaultDelimiter = "\t";
/*  46 */   private final LinkedList<ImageVisitor.ImageElement> elemQ = new LinkedList();
/*  47 */   private long fileSize = 0L;
/*     */ 
/*  56 */   private final Collection<ImageVisitor.ImageElement> elementsToTrack = new ArrayList();
/*     */ 
/*  51 */   private final AbstractMap<ImageVisitor.ImageElement, String> elements = new HashMap();
/*     */   private final String delimiter;
/*     */ 
/*     */   public DelimitedImageVisitor(String filename)
/*     */     throws IOException
/*     */   {
/*  75 */     this(filename, false);
/*     */   }
/*     */ 
/*     */   public DelimitedImageVisitor(String outputFile, boolean printToScreen) throws IOException
/*     */   {
/*  80 */     this(outputFile, printToScreen, "\t");
/*     */   }
/*     */ 
/*     */   public DelimitedImageVisitor(String outputFile, boolean printToScreen, String delimiter) throws IOException
/*     */   {
/*  85 */     super(outputFile, printToScreen);
/*     */ 
/*  60 */     Collections.addAll(this.elementsToTrack, new ImageVisitor.ImageElement[] { ImageVisitor.ImageElement.INODE_PATH, ImageVisitor.ImageElement.REPLICATION, ImageVisitor.ImageElement.MODIFICATION_TIME, ImageVisitor.ImageElement.ACCESS_TIME, ImageVisitor.ImageElement.BLOCK_SIZE, ImageVisitor.ImageElement.NUM_BLOCKS, ImageVisitor.ImageElement.NUM_BYTES, ImageVisitor.ImageElement.NS_QUOTA, ImageVisitor.ImageElement.DS_QUOTA, ImageVisitor.ImageElement.PERMISSION_STRING, ImageVisitor.ImageElement.USER_NAME, ImageVisitor.ImageElement.GROUP_NAME });
/*     */ 
/*  86 */     this.delimiter = delimiter;
/*  87 */     reset();
/*     */   }
/*     */ 
/*     */   private void reset()
/*     */   {
/*  95 */     this.elements.clear();
/*  96 */     for (ImageVisitor.ImageElement e : this.elementsToTrack) {
/*  97 */       this.elements.put(e, null);
/*     */     }
/*  99 */     this.fileSize = 0L;
/*     */   }
/*     */ 
/*     */   void leaveEnclosingElement() throws IOException
/*     */   {
/* 104 */     ImageVisitor.ImageElement elem = (ImageVisitor.ImageElement)this.elemQ.pop();
/*     */ 
/* 107 */     if ((elem == ImageVisitor.ImageElement.INODE) || (elem == ImageVisitor.ImageElement.INODE_UNDER_CONSTRUCTION))
/*     */     {
/* 109 */       writeLine();
/* 110 */       write("\n");
/* 111 */       reset();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void writeLine()
/*     */     throws IOException
/*     */   {
/* 120 */     Iterator it = this.elementsToTrack.iterator();
/*     */ 
/* 122 */     while (it.hasNext()) {
/* 123 */       ImageVisitor.ImageElement e = (ImageVisitor.ImageElement)it.next();
/*     */ 
/* 125 */       String v = null;
/* 126 */       if (e == ImageVisitor.ImageElement.NUM_BYTES)
/* 127 */         v = String.valueOf(this.fileSize);
/*     */       else {
/* 129 */         v = (String)this.elements.get(e);
/*     */       }
/* 131 */       if (v != null) {
/* 132 */         write(v);
/*     */       }
/* 134 */       if (it.hasNext())
/* 135 */         write(this.delimiter);
/*     */     }
/*     */   }
/*     */ 
/*     */   void visit(ImageVisitor.ImageElement element, String value)
/*     */     throws IOException
/*     */   {
/* 142 */     if ((element == ImageVisitor.ImageElement.INODE_PATH) && (value.equals(""))) {
/* 143 */       value = "/";
/*     */     }
/*     */ 
/* 146 */     if (element == ImageVisitor.ImageElement.NUM_BYTES) {
/* 147 */       this.fileSize += Long.valueOf(value).longValue();
/*     */     }
/* 149 */     if ((this.elements.containsKey(element)) && (element != ImageVisitor.ImageElement.NUM_BYTES))
/* 150 */       this.elements.put(element, value);
/*     */   }
/*     */ 
/*     */   void visitEnclosingElement(ImageVisitor.ImageElement element)
/*     */     throws IOException
/*     */   {
/* 156 */     this.elemQ.push(element);
/*     */   }
/*     */ 
/*     */   void visitEnclosingElement(ImageVisitor.ImageElement element, ImageVisitor.ImageElement key, String value)
/*     */     throws IOException
/*     */   {
/* 163 */     if ((key == ImageVisitor.ImageElement.NUM_BLOCKS) && (this.elements.containsKey(ImageVisitor.ImageElement.NUM_BLOCKS)))
/*     */     {
/* 165 */       this.elements.put(key, value);
/*     */     }
/* 167 */     this.elemQ.push(element);
/*     */   }
/*     */ 
/*     */   void start()
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.tools.offlineImageViewer.DelimitedImageVisitor
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs.tools.offlineImageViewer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.LinkedList;
/*     */ 
/*     */ class FileDistributionVisitor extends TextWriterImageVisitor
/*     */ {
/*  52 */   private final LinkedList<ImageVisitor.ImageElement> elemS = new LinkedList();
/*     */   private static final long MAX_SIZE_DEFAULT = 137438953472L;
/*     */   private static final int INTERVAL_DEFAULT = 2097152;
/*     */   private int[] distribution;
/*     */   private long maxSize;
/*     */   private int step;
/*     */   private int totalFiles;
/*     */   private int totalDirectories;
/*     */   private int totalBlocks;
/*     */   private long totalSpace;
/*     */   private long maxFileSize;
/*     */   private FileContext current;
/*  69 */   private boolean inInode = false;
/*     */ 
/*     */   public FileDistributionVisitor(String filename, long maxSize, int step)
/*     */     throws IOException
/*     */   {
/*  84 */     super(filename, false);
/*  85 */     this.maxSize = (maxSize == 0L ? 137438953472L : maxSize);
/*  86 */     this.step = (step == 0 ? 2097152 : step);
/*  87 */     long numIntervals = this.maxSize / this.step;
/*  88 */     if (numIntervals >= 2147483647L)
/*  89 */       throw new IOException("Too many distribution intervals " + numIntervals);
/*  90 */     this.distribution = new int[1 + (int)numIntervals];
/*  91 */     this.totalFiles = 0;
/*  92 */     this.totalDirectories = 0;
/*  93 */     this.totalBlocks = 0;
/*  94 */     this.totalSpace = 0L;
/*  95 */     this.maxFileSize = 0L;
/*     */   }
/*     */ 
/*     */   void start() throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   void finish() throws IOException
/*     */   {
/* 104 */     write("Size\tNumFiles\n");
/* 105 */     for (int i = 0; i < this.distribution.length; i++)
/* 106 */       write(i * this.step + "\t" + this.distribution[i] + "\n");
/* 107 */     System.out.println("totalFiles = " + this.totalFiles);
/* 108 */     System.out.println("totalDirectories = " + this.totalDirectories);
/* 109 */     System.out.println("totalBlocks = " + this.totalBlocks);
/* 110 */     System.out.println("totalSpace = " + this.totalSpace);
/* 111 */     System.out.println("maxFileSize = " + this.maxFileSize);
/* 112 */     super.finish();
/*     */   }
/*     */ 
/*     */   void leaveEnclosingElement() throws IOException
/*     */   {
/* 117 */     ImageVisitor.ImageElement elem = (ImageVisitor.ImageElement)this.elemS.pop();
/*     */ 
/* 119 */     if ((elem != ImageVisitor.ImageElement.INODE) && (elem != ImageVisitor.ImageElement.INODE_UNDER_CONSTRUCTION))
/*     */     {
/* 121 */       return;
/* 122 */     }this.inInode = false;
/* 123 */     if (this.current.numBlocks < 0) {
/* 124 */       this.totalDirectories += 1;
/* 125 */       return;
/*     */     }
/* 127 */     this.totalFiles += 1;
/* 128 */     this.totalBlocks += this.current.numBlocks;
/* 129 */     this.totalSpace += this.current.fileSize * this.current.replication;
/* 130 */     if (this.maxFileSize < this.current.fileSize)
/* 131 */       this.maxFileSize = this.current.fileSize;
/*     */     int high;
/*     */     int high;
/* 133 */     if (this.current.fileSize > this.maxSize)
/* 134 */       high = this.distribution.length - 1;
/*     */     else
/* 136 */       high = (int)Math.ceil(this.current.fileSize / this.step);
/* 137 */     this.distribution[high] += 1;
/* 138 */     if (this.totalFiles % 1000000 == 1)
/* 139 */       System.out.println("Files processed: " + this.totalFiles + "  Current: " + this.current.path);
/*     */   }
/*     */ 
/*     */   void visit(ImageVisitor.ImageElement element, String value)
/*     */     throws IOException
/*     */   {
/* 145 */     if (this.inInode)
/* 146 */       switch (1.$SwitchMap$org$apache$hadoop$hdfs$tools$offlineImageViewer$ImageVisitor$ImageElement[element.ordinal()]) {
/*     */       case 1:
/* 148 */         this.current.path = (value.equals("") ? "/" : value);
/* 149 */         break;
/*     */       case 2:
/* 151 */         this.current.replication = Integer.valueOf(value).intValue();
/* 152 */         break;
/*     */       case 3:
/* 154 */         this.current.fileSize += Long.valueOf(value).longValue();
/* 155 */         break;
/*     */       }
/*     */   }
/*     */ 
/*     */   void visitEnclosingElement(ImageVisitor.ImageElement element)
/*     */     throws IOException
/*     */   {
/* 164 */     this.elemS.push(element);
/* 165 */     if ((element == ImageVisitor.ImageElement.INODE) || (element == ImageVisitor.ImageElement.INODE_UNDER_CONSTRUCTION))
/*     */     {
/* 167 */       this.current = new FileContext(null);
/* 168 */       this.inInode = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   void visitEnclosingElement(ImageVisitor.ImageElement element, ImageVisitor.ImageElement key, String value)
/*     */     throws IOException
/*     */   {
/* 175 */     this.elemS.push(element);
/* 176 */     if ((element == ImageVisitor.ImageElement.INODE) || (element == ImageVisitor.ImageElement.INODE_UNDER_CONSTRUCTION))
/*     */     {
/* 178 */       this.inInode = true;
/* 179 */     } else if (element == ImageVisitor.ImageElement.BLOCKS)
/* 180 */       this.current.numBlocks = Integer.parseInt(value);
/*     */   }
/*     */ 
/*     */   private static class FileContext
/*     */   {
/*     */     String path;
/*     */     long fileSize;
/*     */     int numBlocks;
/*     */     int replication;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.tools.offlineImageViewer.FileDistributionVisitor
 * JD-Core Version:    0.6.1
 */
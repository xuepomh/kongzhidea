/*     */ package org.apache.hadoop.hdfs.tools.offlineImageViewer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Date;
/*     */ 
/*     */ class IndentedImageVisitor extends TextWriterImageVisitor
/*     */ {
/*  37 */   private final DepthCounter dc = new DepthCounter();
/*     */ 
/*  95 */   private static final String[] indents = { "", "  ", "    ", "      ", "        ", "          ", "            " };
/*     */ 
/*     */   public IndentedImageVisitor(String filename)
/*     */     throws IOException
/*     */   {
/*  30 */     super(filename);
/*     */   }
/*     */ 
/*     */   public IndentedImageVisitor(String filename, boolean printToScreen) throws IOException {
/*  34 */     super(filename, printToScreen);
/*     */   }
/*     */ 
/*     */   void start() throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   void finish() throws IOException
/*     */   {
/*  43 */     super.finish();
/*     */   }
/*     */ 
/*     */   void finishAbnormally() throws IOException {
/*  47 */     System.out.println("*** Image processing finished abnormally.  Ending ***");
/*  48 */     super.finishAbnormally();
/*     */   }
/*     */ 
/*     */   void leaveEnclosingElement() throws IOException
/*     */   {
/*  53 */     this.dc.decLevel();
/*     */   }
/*     */ 
/*     */   void visit(ImageVisitor.ImageElement element, String value) throws IOException
/*     */   {
/*  58 */     printIndents();
/*  59 */     write(element + " = " + value + "\n");
/*     */   }
/*     */ 
/*     */   void visit(ImageVisitor.ImageElement element, long value) throws IOException
/*     */   {
/*  64 */     if ((element == ImageVisitor.ImageElement.DELEGATION_TOKEN_IDENTIFIER_EXPIRY_TIME) || (element == ImageVisitor.ImageElement.DELEGATION_TOKEN_IDENTIFIER_ISSUE_DATE) || (element == ImageVisitor.ImageElement.DELEGATION_TOKEN_IDENTIFIER_MAX_DATE))
/*     */     {
/*  67 */       visit(element, new Date(value).toString());
/*     */     }
/*  69 */     else visit(element, Long.toString(value));
/*     */   }
/*     */ 
/*     */   void visitEnclosingElement(ImageVisitor.ImageElement element)
/*     */     throws IOException
/*     */   {
/*  75 */     printIndents();
/*  76 */     write(element + "\n");
/*  77 */     this.dc.incLevel();
/*     */   }
/*     */ 
/*     */   void visitEnclosingElement(ImageVisitor.ImageElement element, ImageVisitor.ImageElement key, String value)
/*     */     throws IOException
/*     */   {
/*  85 */     printIndents();
/*  86 */     write(element + " [" + key + " = " + value + "]\n");
/*  87 */     this.dc.incLevel();
/*     */   }
/*     */ 
/*     */   private void printIndents()
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 104 */       write(indents[this.dc.getLevel()]);
/*     */     }
/*     */     catch (IndexOutOfBoundsException e) {
/* 107 */       for (int i = 0; i < this.dc.getLevel(); i++)
/* 108 */         write(" ");
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.tools.offlineImageViewer.IndentedImageVisitor
 * JD-Core Version:    0.6.1
 */
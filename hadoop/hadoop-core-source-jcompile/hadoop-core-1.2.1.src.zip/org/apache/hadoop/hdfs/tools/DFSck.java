/*     */ package org.apache.hadoop.hdfs.tools;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLEncoder;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.List;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.conf.Configured;
/*     */ import org.apache.hadoop.hdfs.server.namenode.NameNode;
/*     */ import org.apache.hadoop.security.Krb5AndCertsSslSocketConnector;
/*     */ import org.apache.hadoop.security.SecurityUtil;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.util.Tool;
/*     */ import org.apache.hadoop.util.ToolRunner;
/*     */ 
/*     */ public class DFSck extends Configured
/*     */   implements Tool
/*     */ {
/*     */   private final UserGroupInformation ugi;
/*     */ 
/*     */   public DFSck(Configuration conf)
/*     */     throws IOException
/*     */   {
/*  76 */     super(conf);
/*  77 */     this.ugi = UserGroupInformation.getCurrentUser();
/*     */   }
/*     */ 
/*     */   static void printUsage()
/*     */   {
/*  84 */     System.err.println("Usage: DFSck <path> [-move | -delete | -openforwrite] [-files [-blocks [-locations | -racks]]]");
/*  85 */     System.err.println("\t<path>\tstart checking from this path");
/*  86 */     System.err.println("\t-move\tmove corrupted files to /lost+found");
/*  87 */     System.err.println("\t-delete\tdelete corrupted files");
/*  88 */     System.err.println("\t-files\tprint out files being checked");
/*  89 */     System.err.println("\t-openforwrite\tprint out files opened for write");
/*  90 */     System.err.println("\t-blocks\tprint out block report");
/*  91 */     System.err.println("\t-locations\tprint out locations for every block");
/*  92 */     System.err.println("\t-racks\tprint out network topology for data-node locations");
/*  93 */     System.err.println("\t\tBy default fsck ignores files opened for write, use -openforwrite to report such files. They are usually  tagged CORRUPT or HEALTHY depending on their block allocation status");
/*     */ 
/*  97 */     ToolRunner.printGenericCommandUsage(System.err);
/*     */   }
/*     */ 
/*     */   public int run(final String[] args)
/*     */     throws IOException
/*     */   {
/* 103 */     if (args.length == 0) {
/* 104 */       printUsage();
/* 105 */       return -1;
/*     */     }
/*     */     try
/*     */     {
/* 109 */       return ((Integer)UserGroupInformation.getCurrentUser().doAs(new PrivilegedExceptionAction()
/*     */       {
/*     */         public Integer run() throws Exception
/*     */         {
/* 113 */           if (SecurityUtil.useKsslAuth()) {
/* 114 */             System.setProperty("https.cipherSuites", (String)Krb5AndCertsSslSocketConnector.KRB5_CIPHER_SUITES.get(0));
/*     */           }
/*     */ 
/* 118 */           StringBuffer url = new StringBuffer(NameNode.getHttpUriScheme() + "://");
/*     */ 
/* 120 */           url.append(NameNode.getInfoServer(DFSck.this.getConf())).append("/fsck?ugi=").append(DFSck.this.ugi.getShortUserName()).append("&path=");
/*     */ 
/* 123 */           String dir = "/";
/*     */ 
/* 125 */           for (int idx = 0; idx < args.length; idx++)
/* 126 */             if (!args[idx].startsWith("-")) { dir = args[idx]; break;
/*     */             }
/* 128 */           url.append(URLEncoder.encode(dir, "UTF-8"));
/* 129 */           for (int idx = 0; idx < args.length; idx++) {
/* 130 */             if (args[idx].equals("-move")) url.append("&move=1");
/* 131 */             else if (args[idx].equals("-delete")) url.append("&delete=1");
/* 132 */             else if (args[idx].equals("-files")) url.append("&files=1");
/* 133 */             else if (args[idx].equals("-openforwrite")) url.append("&openforwrite=1");
/* 134 */             else if (args[idx].equals("-blocks")) url.append("&blocks=1");
/* 135 */             else if (args[idx].equals("-locations")) url.append("&locations=1");
/* 136 */             else if (args[idx].equals("-racks")) url.append("&racks=1");
/*     */           }
/*     */ 
/* 139 */           URL path = new URL(url.toString());
/*     */ 
/* 141 */           URLConnection connection = SecurityUtil.openSecureHttpConnection(path);
/* 142 */           InputStream stream = connection.getInputStream();
/* 143 */           BufferedReader input = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
/*     */ 
/* 145 */           String line = null;
/* 146 */           String lastLine = null;
/* 147 */           int errCode = -1;
/*     */           try {
/* 149 */             while ((line = input.readLine()) != null) {
/* 150 */               System.out.println(line);
/* 151 */               lastLine = line;
/*     */             }
/*     */           } finally {
/* 154 */             input.close();
/*     */           }
/* 156 */           if (lastLine.endsWith("is HEALTHY"))
/* 157 */             errCode = 0;
/* 158 */           else if (lastLine.endsWith("is CORRUPT"))
/* 159 */             errCode = 1;
/* 160 */           else if (lastLine.endsWith("does not exist")) {
/* 161 */             errCode = 0;
/*     */           }
/* 163 */           return Integer.valueOf(errCode);
/*     */         }
/*     */       })).intValue();
/*     */     }
/*     */     catch (InterruptedException e)
/*     */     {
/* 167 */       throw new IOException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/* 179 */     int res = -1;
/* 180 */     if ((args.length == 0) || ("-files".equals(args[0])))
/* 181 */       printUsage();
/*     */     else
/* 183 */       res = ToolRunner.run(new DFSck(new Configuration()), args);
/* 184 */     System.exit(res);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  65 */     Configuration.addDefaultResource("hdfs-default.xml");
/*  66 */     Configuration.addDefaultResource("hdfs-site.xml");
/*     */ 
/* 172 */     Configuration.addDefaultResource("hdfs-default.xml");
/* 173 */     Configuration.addDefaultResource("hdfs-site.xml");
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.tools.DFSck
 * JD-Core Version:    0.6.1
 */
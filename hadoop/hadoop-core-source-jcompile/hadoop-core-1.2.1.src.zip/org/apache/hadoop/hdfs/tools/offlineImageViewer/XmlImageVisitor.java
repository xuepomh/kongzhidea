/*    */ package org.apache.hadoop.hdfs.tools.offlineImageViewer;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.LinkedList;
/*    */ 
/*    */ class XmlImageVisitor extends TextWriterImageVisitor
/*    */ {
/* 28 */   private final LinkedList<ImageVisitor.ImageElement> tagQ = new LinkedList();
/*    */ 
/*    */   public XmlImageVisitor(String filename) throws IOException
/*    */   {
/* 32 */     super(filename, false);
/*    */   }
/*    */ 
/*    */   public XmlImageVisitor(String filename, boolean printToScreen) throws IOException
/*    */   {
/* 37 */     super(filename, printToScreen);
/*    */   }
/*    */ 
/*    */   void finish() throws IOException
/*    */   {
/* 42 */     super.finish();
/*    */   }
/*    */ 
/*    */   void finishAbnormally() throws IOException
/*    */   {
/* 47 */     write("\n<!-- Error processing image file.  Exiting -->\n");
/* 48 */     super.finishAbnormally();
/*    */   }
/*    */ 
/*    */   void leaveEnclosingElement() throws IOException
/*    */   {
/* 53 */     if (this.tagQ.size() == 0) {
/* 54 */       throw new IOException("Tried to exit non-existent enclosing element in FSImage file");
/*    */     }
/*    */ 
/* 57 */     ImageVisitor.ImageElement element = (ImageVisitor.ImageElement)this.tagQ.pop();
/* 58 */     write("</" + element.toString() + ">\n");
/*    */   }
/*    */ 
/*    */   void start() throws IOException
/*    */   {
/* 63 */     write("<?xml version=\"1.0\" ?>\n");
/*    */   }
/*    */ 
/*    */   void visit(ImageVisitor.ImageElement element, String value) throws IOException
/*    */   {
/* 68 */     writeTag(element.toString(), value);
/*    */   }
/*    */ 
/*    */   void visitEnclosingElement(ImageVisitor.ImageElement element) throws IOException
/*    */   {
/* 73 */     write("<" + element.toString() + ">\n");
/* 74 */     this.tagQ.push(element);
/*    */   }
/*    */ 
/*    */   void visitEnclosingElement(ImageVisitor.ImageElement element, ImageVisitor.ImageElement key, String value)
/*    */     throws IOException
/*    */   {
/* 81 */     write("<" + element.toString() + " " + key + "=\"" + value + "\">\n");
/* 82 */     this.tagQ.push(element);
/*    */   }
/*    */ 
/*    */   private void writeTag(String tag, String value) throws IOException {
/* 86 */     write("<" + tag + ">" + value + "</" + tag + ">\n");
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.tools.offlineImageViewer.XmlImageVisitor
 * JD-Core Version:    0.6.1
 */
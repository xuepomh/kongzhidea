/*    */ package org.apache.hadoop.hdfs.tools.offlineImageViewer;
/*    */ 
/*    */ import java.io.DataInputStream;
/*    */ import java.io.IOException;
/*    */ import org.apache.hadoop.classification.InterfaceAudience.Private;
/*    */ 
/*    */ abstract interface ImageLoader
/*    */ {
/*    */   public abstract void loadImage(DataInputStream paramDataInputStream, ImageVisitor paramImageVisitor, boolean paramBoolean)
/*    */     throws IOException;
/*    */ 
/*    */   public abstract boolean canLoadVersion(int paramInt);
/*    */ 
/*    */   @InterfaceAudience.Private
/*    */   public static class LoaderFactory
/*    */   {
/*    */     public static ImageLoader getLoader(int version)
/*    */     {
/* 73 */       ImageLoader[] loaders = { new ImageLoaderCurrent() };
/*    */ 
/* 75 */       for (ImageLoader l : loaders) {
/* 76 */         if (l.canLoadVersion(version)) {
/* 77 */           return l;
/*    */         }
/*    */       }
/* 80 */       return null;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.tools.offlineImageViewer.ImageLoader
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs.tools;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.List;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.FsShell;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.fs.shell.Command;
/*     */ import org.apache.hadoop.fs.shell.CommandFormat;
/*     */ import org.apache.hadoop.hdfs.DFSClient;
/*     */ import org.apache.hadoop.hdfs.DistributedFileSystem;
/*     */ import org.apache.hadoop.hdfs.DistributedFileSystem.DiskStatus;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.hdfs.protocol.FSConstants.DatanodeReportType;
/*     */ import org.apache.hadoop.hdfs.protocol.FSConstants.SafeModeAction;
/*     */ import org.apache.hadoop.hdfs.protocol.FSConstants.UpgradeAction;
/*     */ import org.apache.hadoop.hdfs.server.common.UpgradeStatusReport;
/*     */ import org.apache.hadoop.hdfs.server.namenode.NameNode;
/*     */ import org.apache.hadoop.ipc.RPC;
/*     */ import org.apache.hadoop.ipc.RPC.VersionMismatch;
/*     */ import org.apache.hadoop.ipc.RemoteException;
/*     */ import org.apache.hadoop.net.NetUtils;
/*     */ import org.apache.hadoop.security.RefreshUserMappingsProtocol;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.authorize.RefreshAuthorizationPolicyProtocol;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ import org.apache.hadoop.util.StringUtils.TraditionalBinaryPrefix;
/*     */ import org.apache.hadoop.util.ToolRunner;
/*     */ 
/*     */ public class DFSAdmin extends FsShell
/*     */ {
/*     */   public DFSAdmin()
/*     */   {
/* 247 */     this(null);
/*     */   }
/*     */ 
/*     */   public DFSAdmin(Configuration conf)
/*     */   {
/* 254 */     super(conf);
/*     */   }
/*     */ 
/*     */   protected DistributedFileSystem getDFS() throws IOException {
/* 258 */     FileSystem fs = getFS();
/* 259 */     if (!(fs instanceof DistributedFileSystem)) {
/* 260 */       throw new IllegalArgumentException(new StringBuilder().append("FileSystem ").append(fs.getUri()).append(" is not a distributed file system").toString());
/*     */     }
/*     */ 
/* 263 */     return (DistributedFileSystem)fs;
/*     */   }
/*     */ 
/*     */   public void report()
/*     */     throws IOException
/*     */   {
/* 271 */     DistributedFileSystem dfs = getDFS();
/* 272 */     DistributedFileSystem.DiskStatus ds = dfs.getDiskStatus();
/* 273 */     long capacity = ds.getCapacity();
/* 274 */     long used = ds.getDfsUsed();
/* 275 */     long remaining = ds.getRemaining();
/* 276 */     long presentCapacity = used + remaining;
/* 277 */     boolean mode = dfs.setSafeMode(FSConstants.SafeModeAction.SAFEMODE_GET);
/* 278 */     UpgradeStatusReport status = dfs.distributedUpgradeProgress(FSConstants.UpgradeAction.GET_STATUS);
/*     */ 
/* 281 */     if (mode) {
/* 282 */       System.out.println("Safe mode is ON");
/*     */     }
/* 284 */     if (status != null) {
/* 285 */       System.out.println(status.getStatusText(false));
/*     */     }
/* 287 */     System.out.println(new StringBuilder().append("Configured Capacity: ").append(capacity).append(" (").append(StringUtils.byteDesc(capacity)).append(")").toString());
/*     */ 
/* 289 */     System.out.println(new StringBuilder().append("Present Capacity: ").append(presentCapacity).append(" (").append(StringUtils.byteDesc(presentCapacity)).append(")").toString());
/*     */ 
/* 291 */     System.out.println(new StringBuilder().append("DFS Remaining: ").append(remaining).append(" (").append(StringUtils.byteDesc(remaining)).append(")").toString());
/*     */ 
/* 293 */     System.out.println(new StringBuilder().append("DFS Used: ").append(used).append(" (").append(StringUtils.byteDesc(used)).append(")").toString());
/*     */ 
/* 295 */     System.out.println(new StringBuilder().append("DFS Used%: ").append(StringUtils.limitDecimalTo2(1.0D * used / presentCapacity * 100.0D)).append("%").toString());
/*     */ 
/* 304 */     System.out.println(new StringBuilder().append("Under replicated blocks: ").append(dfs.getUnderReplicatedBlocksCount()).toString());
/*     */ 
/* 306 */     System.out.println(new StringBuilder().append("Blocks with corrupt replicas: ").append(dfs.getCorruptBlocksCount()).toString());
/*     */ 
/* 308 */     System.out.println(new StringBuilder().append("Missing blocks: ").append(dfs.getMissingBlocksCount()).toString());
/*     */ 
/* 310 */     System.out.println();
/*     */ 
/* 312 */     System.out.println("-------------------------------------------------");
/*     */ 
/* 314 */     DatanodeInfo[] live = dfs.getClient().datanodeReport(FSConstants.DatanodeReportType.LIVE);
/*     */ 
/* 316 */     DatanodeInfo[] dead = dfs.getClient().datanodeReport(FSConstants.DatanodeReportType.DEAD);
/*     */ 
/* 318 */     System.out.println(new StringBuilder().append("Datanodes available: ").append(live.length).append(" (").append(live.length + dead.length).append(" total, ").append(dead.length).append(" dead)\n").toString());
/*     */ 
/* 321 */     for (DatanodeInfo dn : live) {
/* 322 */       System.out.println(dn.getDatanodeReport());
/* 323 */       System.out.println();
/*     */     }
/* 325 */     for (DatanodeInfo dn : dead) {
/* 326 */       System.out.println(dn.getDatanodeReport());
/* 327 */       System.out.println();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setSafeMode(String[] argv, int idx)
/*     */     throws IOException
/*     */   {
/* 339 */     if (idx != argv.length - 1) {
/* 340 */       printUsage("-safemode");
/* 341 */       return;
/*     */     }
/*     */ 
/* 344 */     Boolean waitExitSafe = Boolean.valueOf(false);
/*     */     FSConstants.SafeModeAction action;
/* 346 */     if ("leave".equalsIgnoreCase(argv[idx])) {
/* 347 */       action = FSConstants.SafeModeAction.SAFEMODE_LEAVE;
/*     */     }
/*     */     else
/*     */     {
/*     */       FSConstants.SafeModeAction action;
/* 348 */       if ("enter".equalsIgnoreCase(argv[idx])) {
/* 349 */         action = FSConstants.SafeModeAction.SAFEMODE_ENTER;
/*     */       }
/*     */       else
/*     */       {
/*     */         FSConstants.SafeModeAction action;
/* 350 */         if ("get".equalsIgnoreCase(argv[idx])) {
/* 351 */           action = FSConstants.SafeModeAction.SAFEMODE_GET;
/* 352 */         } else if ("wait".equalsIgnoreCase(argv[idx])) {
/* 353 */           FSConstants.SafeModeAction action = FSConstants.SafeModeAction.SAFEMODE_GET;
/* 354 */           waitExitSafe = Boolean.valueOf(true);
/*     */         } else {
/* 356 */           printUsage("-safemode");
/*     */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */     FSConstants.SafeModeAction action;
/* 359 */     DistributedFileSystem dfs = getDFS();
/* 360 */     boolean inSafeMode = dfs.setSafeMode(action);
/*     */ 
/* 366 */     if (waitExitSafe.booleanValue()) {
/* 367 */       while (inSafeMode) {
/*     */         try {
/* 369 */           Thread.sleep(5000L);
/*     */         } catch (InterruptedException e) {
/* 371 */           throw new IOException("Wait Interrupted");
/*     */         }
/* 373 */         inSafeMode = dfs.setSafeMode(action);
/*     */       }
/*     */     }
/*     */ 
/* 377 */     System.out.println(new StringBuilder().append("Safe mode is ").append(inSafeMode ? "ON" : "OFF").toString());
/*     */   }
/*     */ 
/*     */   public int saveNamespace()
/*     */     throws IOException
/*     */   {
/* 387 */     int exitCode = -1;
/*     */ 
/* 389 */     DistributedFileSystem dfs = getDFS();
/* 390 */     dfs.saveNamespace();
/* 391 */     exitCode = 0;
/*     */ 
/* 393 */     return exitCode;
/*     */   }
/*     */ 
/*     */   public int refreshNodes()
/*     */     throws IOException
/*     */   {
/* 403 */     int exitCode = -1;
/*     */ 
/* 405 */     DistributedFileSystem dfs = getDFS();
/* 406 */     dfs.refreshNodes();
/* 407 */     exitCode = 0;
/*     */ 
/* 409 */     return exitCode;
/*     */   }
/*     */ 
/*     */   public int setBalancerBandwidth(String[] argv, int idx)
/*     */     throws IOException
/*     */   {
/* 422 */     int exitCode = -1;
/*     */     long bandwidth;
/*     */     try
/*     */     {
/* 425 */       bandwidth = Long.parseLong(argv[idx]);
/*     */     } catch (NumberFormatException nfe) {
/* 427 */       System.err.println(new StringBuilder().append("NumberFormatException: ").append(nfe.getMessage()).toString());
/* 428 */       System.err.println("Usage: java DFSAdmin [-setBalancerBandwidth <bandwidth in bytes per second>]");
/*     */ 
/* 430 */       return exitCode;
/*     */     }
/*     */ 
/* 433 */     DistributedFileSystem dfs = getDFS();
/* 434 */     dfs.setBalancerBandwidth(bandwidth);
/* 435 */     exitCode = 0;
/*     */ 
/* 437 */     return exitCode;
/*     */   }
/*     */ 
/*     */   private void printHelp(String cmd) {
/* 441 */     String summary = "hadoop dfsadmin is the command to execute DFS administrative commands.\nThe full syntax is: \n\nhadoop dfsadmin [-report] [-safemode <enter | leave | get | wait>]\n\t[-saveNamespace]\n\t[-refreshNodes]\n\t[-setQuota <quota> <dirname>...<dirname>]\n\t[-clrQuota <dirname>...<dirname>]\n\t[-setSpaceQuota <quota> <dirname>...<dirname>]\n\t[-clrSpaceQuota <dirname>...<dirname>]\n\t[-refreshServiceAcl]\n\t[-refreshUserToGroupsMappings]\n\t[refreshSuperUserGroupsConfiguration]\n\t[-setBalancerBandwidth <bandwidth>]\n\t[-help [cmd]]\n";
/*     */ 
/* 456 */     String report = "-report: \tReports basic filesystem information and statistics.\n";
/*     */ 
/* 458 */     String safemode = "-safemode <enter|leave|get|wait>:  Safe mode maintenance command.\n\t\tSafe mode is a Namenode state in which it\n\t\t\t1.  does not accept changes to the name space (read-only)\n\t\t\t2.  does not replicate or delete blocks.\n\t\tSafe mode is entered automatically at Namenode startup, and\n\t\tleaves safe mode automatically when the configured minimum\n\t\tpercentage of blocks satisfies the minimum replication\n\t\tcondition.  Safe mode can also be entered manually, but then\n\t\tit can only be turned off manually as well.\n";
/*     */ 
/* 468 */     String saveNamespace = "-saveNamespace:\tSave current namespace into storage directories and reset edits log.\n\t\tRequires superuser permissions and safe mode.\n";
/*     */ 
/* 472 */     String refreshNodes = "-refreshNodes: \tUpdates the set of hosts allowed to connect to namenode.\n\n\t\tRe-reads the config file to update values defined by \n\t\tdfs.hosts and dfs.host.exclude and reads the \n\t\tentires (hostnames) in those files.\n\n\t\tEach entry not defined in dfs.hosts but in \n\t\tdfs.hosts.exclude is decommissioned. Each entry defined \n\t\tin dfs.hosts and also in dfs.host.exclude is stopped from \n\t\tdecommissioning if it has aleady been marked for decommission.\n\t\tEntires not present in both the lists are decommissioned.\n";
/*     */ 
/* 483 */     String finalizeUpgrade = "-finalizeUpgrade: Finalize upgrade of HDFS.\n\t\tDatanodes delete their previous version working directories,\n\t\tfollowed by Namenode doing the same.\n\t\tThis completes the upgrade process.\n";
/*     */ 
/* 488 */     String upgradeProgress = "-upgradeProgress <status|details|force>: \n\t\trequest current distributed upgrade status, \n\t\ta detailed status or force the upgrade to proceed.\n";
/*     */ 
/* 492 */     String metaSave = "-metasave <filename>: \tSave Namenode's primary data structures\n\t\tto <filename> in the directory specified by hadoop.log.dir property.\n\t\t<filename> will contain one line for each of the following\n\t\t\t1. Datanodes heart beating with Namenode\n\t\t\t2. Blocks waiting to be replicated\n\t\t\t3. Blocks currrently being replicated\n\t\t\t4. Blocks waiting to be deleted\n";
/*     */ 
/* 500 */     String refreshServiceAcl = "-refreshServiceAcl: Reload the service-level authorization policy file\n\t\tNamenode will reload the authorization policy file.\n";
/*     */ 
/* 503 */     String refreshUserToGroupsMappings = "-refreshUserToGroupsMappings: Refresh user-to-groups mappings\n";
/*     */ 
/* 506 */     String refreshSuperUserGroupsConfiguration = "-refreshSuperUserGroupsConfiguration: Refresh superuser proxy groups mappings\n";
/*     */ 
/* 509 */     String setBalancerBandwidth = "-setBalancerBandwidth <bandwidth>:\n\tChanges the network bandwidth used by each datanode during\n\tHDFS block balancing.\n\n\t\t<bandwidth> is the maximum number of bytes per second\n\t\tthat will be used by each datanode. This value overrides\n\t\tthe dfs.balance.bandwidthPerSec parameter.\n\n\t\t--- NOTE: The new value is not persistent on the DataNode.---\n";
/*     */ 
/* 517 */     String help = "-help [cmd]: \tDisplays help for the given command or all commands if none\n\t\tis specified.\n";
/*     */ 
/* 520 */     if ("report".equals(cmd)) {
/* 521 */       System.out.println(report);
/* 522 */     } else if ("safemode".equals(cmd)) {
/* 523 */       System.out.println(safemode);
/* 524 */     } else if ("saveNamespace".equals(cmd)) {
/* 525 */       System.out.println(saveNamespace);
/* 526 */     } else if ("refreshNodes".equals(cmd)) {
/* 527 */       System.out.println(refreshNodes);
/* 528 */     } else if ("finalizeUpgrade".equals(cmd)) {
/* 529 */       System.out.println(finalizeUpgrade);
/* 530 */     } else if ("upgradeProgress".equals(cmd)) {
/* 531 */       System.out.println(upgradeProgress);
/* 532 */     } else if ("metasave".equals(cmd)) {
/* 533 */       System.out.println(metaSave);
/* 534 */     } else if (SetQuotaCommand.matches(new StringBuilder().append("-").append(cmd).toString())) {
/* 535 */       System.out.println("-setQuota <quota> <dirname>...<dirname>: Set the quota <quota> for each directory <dirName>.\n\t\tThe directory quota is a long integer that puts a hard limit\n\t\ton the number of names in the directory tree\n\t\tBest effort for the directory, with faults reported if\n\t\t1. N is not a positive integer, or\n\t\t2. user is not an administrator, or\n\t\t3. the directory does not exist or is a file, or\n");
/* 536 */     } else if (ClearQuotaCommand.matches(new StringBuilder().append("-").append(cmd).toString())) {
/* 537 */       System.out.println("-clrQuota <dirname>...<dirname>: Clear the quota for each directory <dirName>.\n\t\tBest effort for the directory. with fault reported if\n\t\t1. the directory does not exist or is a file, or\n\t\t2. user is not an administrator.\n\t\tIt does not fault if the directory has no quota.");
/* 538 */     } else if (SetSpaceQuotaCommand.matches(new StringBuilder().append("-").append(cmd).toString())) {
/* 539 */       System.out.println("-setSpaceQuota <quota> <dirname>...<dirname>: Set the disk space quota <quota> for each directory <dirName>.\n\t\tThe space quota is a long integer that puts a hard limit\n\t\ton the total size of all the files under the directory tree.\n\t\tThe extra space required for replication is also counted. E.g.\n\t\ta 1GB file with replication of 3 consumes 3GB of the quota.\n\n\t\tQuota can also be speciefied with a binary prefix for terabytes,\n\t\tpetabytes etc (e.g. 50t is 50TB, 5m is 5MB, 3p is 3PB).\n\t\tBest effort for the directory, with faults reported if\n\t\t1. N is not a positive integer, or\n\t\t2. user is not an administrator, or\n\t\t3. the directory does not exist or is a file, or\n");
/* 540 */     } else if (ClearSpaceQuotaCommand.matches(new StringBuilder().append("-").append(cmd).toString())) {
/* 541 */       System.out.println("-clrSpaceQuota <dirname>...<dirname>: Clear the disk space quota for each directory <dirName>.\n\t\tBest effort for the directory. with fault reported if\n\t\t1. the directory does not exist or is a file, or\n\t\t2. user is not an administrator.\n\t\tIt does not fault if the directory has no quota.");
/* 542 */     } else if ("refreshServiceAcl".equals(cmd)) {
/* 543 */       System.out.println(refreshServiceAcl);
/* 544 */     } else if ("refreshUserToGroupsMappings".equals(cmd)) {
/* 545 */       System.out.println(refreshUserToGroupsMappings);
/* 546 */     } else if ("refreshSuperUserGroupsConfiguration".equals(cmd)) {
/* 547 */       System.out.println(refreshSuperUserGroupsConfiguration);
/* 548 */     } else if ("setBalancerBandwidth".equals(cmd)) {
/* 549 */       System.out.println(setBalancerBandwidth);
/* 550 */     } else if ("help".equals(cmd)) {
/* 551 */       System.out.println(help);
/*     */     } else {
/* 553 */       System.out.println(summary);
/* 554 */       System.out.println(report);
/* 555 */       System.out.println(safemode);
/* 556 */       System.out.println(saveNamespace);
/* 557 */       System.out.println(refreshNodes);
/* 558 */       System.out.println(finalizeUpgrade);
/* 559 */       System.out.println(upgradeProgress);
/* 560 */       System.out.println(metaSave);
/* 561 */       System.out.println("-setQuota <quota> <dirname>...<dirname>: Set the quota <quota> for each directory <dirName>.\n\t\tThe directory quota is a long integer that puts a hard limit\n\t\ton the number of names in the directory tree\n\t\tBest effort for the directory, with faults reported if\n\t\t1. N is not a positive integer, or\n\t\t2. user is not an administrator, or\n\t\t3. the directory does not exist or is a file, or\n");
/* 562 */       System.out.println("-clrQuota <dirname>...<dirname>: Clear the quota for each directory <dirName>.\n\t\tBest effort for the directory. with fault reported if\n\t\t1. the directory does not exist or is a file, or\n\t\t2. user is not an administrator.\n\t\tIt does not fault if the directory has no quota.");
/* 563 */       System.out.println("-setSpaceQuota <quota> <dirname>...<dirname>: Set the disk space quota <quota> for each directory <dirName>.\n\t\tThe space quota is a long integer that puts a hard limit\n\t\ton the total size of all the files under the directory tree.\n\t\tThe extra space required for replication is also counted. E.g.\n\t\ta 1GB file with replication of 3 consumes 3GB of the quota.\n\n\t\tQuota can also be speciefied with a binary prefix for terabytes,\n\t\tpetabytes etc (e.g. 50t is 50TB, 5m is 5MB, 3p is 3PB).\n\t\tBest effort for the directory, with faults reported if\n\t\t1. N is not a positive integer, or\n\t\t2. user is not an administrator, or\n\t\t3. the directory does not exist or is a file, or\n");
/* 564 */       System.out.println("-clrSpaceQuota <dirname>...<dirname>: Clear the disk space quota for each directory <dirName>.\n\t\tBest effort for the directory. with fault reported if\n\t\t1. the directory does not exist or is a file, or\n\t\t2. user is not an administrator.\n\t\tIt does not fault if the directory has no quota.");
/* 565 */       System.out.println(refreshServiceAcl);
/* 566 */       System.out.println(refreshUserToGroupsMappings);
/* 567 */       System.out.println(refreshSuperUserGroupsConfiguration);
/* 568 */       System.out.println(setBalancerBandwidth);
/* 569 */       System.out.println(help);
/* 570 */       System.out.println();
/* 571 */       ToolRunner.printGenericCommandUsage(System.out);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int finalizeUpgrade()
/*     */     throws IOException
/*     */   {
/* 583 */     DistributedFileSystem dfs = getDFS();
/* 584 */     dfs.finalizeUpgrade();
/*     */ 
/* 586 */     return 0;
/*     */   }
/*     */ 
/*     */   public int upgradeProgress(String[] argv, int idx)
/*     */     throws IOException
/*     */   {
/* 597 */     if (idx != argv.length - 1) {
/* 598 */       printUsage("-upgradeProgress");
/* 599 */       return -1;
/*     */     }
/*     */     FSConstants.UpgradeAction action;
/* 603 */     if ("status".equalsIgnoreCase(argv[idx])) {
/* 604 */       action = FSConstants.UpgradeAction.GET_STATUS;
/*     */     }
/*     */     else
/*     */     {
/*     */       FSConstants.UpgradeAction action;
/* 605 */       if ("details".equalsIgnoreCase(argv[idx])) {
/* 606 */         action = FSConstants.UpgradeAction.DETAILED_STATUS;
/*     */       }
/*     */       else
/*     */       {
/*     */         FSConstants.UpgradeAction action;
/* 607 */         if ("force".equalsIgnoreCase(argv[idx])) {
/* 608 */           action = FSConstants.UpgradeAction.FORCE_PROCEED;
/*     */         } else {
/* 610 */           printUsage("-upgradeProgress");
/* 611 */           return -1;
/*     */         }
/*     */       }
/*     */     }
/*     */     FSConstants.UpgradeAction action;
/* 614 */     DistributedFileSystem dfs = getDFS();
/* 615 */     UpgradeStatusReport status = dfs.distributedUpgradeProgress(action);
/* 616 */     String statusText = status == null ? "There are no upgrades in progress." : status.getStatusText(action == FSConstants.UpgradeAction.DETAILED_STATUS);
/*     */ 
/* 619 */     System.out.println(statusText);
/* 620 */     return 0;
/*     */   }
/*     */ 
/*     */   public int metaSave(String[] argv, int idx)
/*     */     throws IOException
/*     */   {
/* 632 */     String pathname = argv[idx];
/* 633 */     DistributedFileSystem dfs = getDFS();
/* 634 */     dfs.metaSave(pathname);
/* 635 */     System.out.println(new StringBuilder().append("Created file ").append(pathname).append(" on server ").append(dfs.getUri()).toString());
/*     */ 
/* 637 */     return 0;
/*     */   }
/*     */ 
/*     */   private static UserGroupInformation getUGI() throws IOException
/*     */   {
/* 642 */     return UserGroupInformation.getCurrentUser();
/*     */   }
/*     */ 
/*     */   public int refreshServiceAcl()
/*     */     throws IOException
/*     */   {
/* 652 */     Configuration conf = getConf();
/*     */ 
/* 657 */     conf.set("hadoop.security.service.user.name.key", conf.get("dfs.namenode.kerberos.principal", ""));
/*     */ 
/* 662 */     RefreshAuthorizationPolicyProtocol refreshProtocol = (RefreshAuthorizationPolicyProtocol)RPC.getProxy(RefreshAuthorizationPolicyProtocol.class, 1L, NameNode.getAddress(conf), getUGI(), conf, NetUtils.getSocketFactory(conf, RefreshAuthorizationPolicyProtocol.class));
/*     */ 
/* 672 */     refreshProtocol.refreshServiceAcl();
/*     */ 
/* 674 */     return 0;
/*     */   }
/*     */ 
/*     */   public int refreshUserToGroupsMappings()
/*     */     throws IOException
/*     */   {
/* 684 */     Configuration conf = getConf();
/*     */ 
/* 689 */     conf.set("hadoop.security.service.user.name.key", conf.get("dfs.namenode.kerberos.principal", ""));
/*     */ 
/* 693 */     RefreshUserMappingsProtocol refreshProtocol = (RefreshUserMappingsProtocol)RPC.getProxy(RefreshUserMappingsProtocol.class, 1L, NameNode.getAddress(conf), getUGI(), conf, NetUtils.getSocketFactory(conf, RefreshUserMappingsProtocol.class));
/*     */ 
/* 702 */     refreshProtocol.refreshUserToGroupsMappings();
/*     */ 
/* 704 */     return 0;
/*     */   }
/*     */ 
/*     */   public int refreshSuperUserGroupsConfiguration()
/*     */     throws IOException
/*     */   {
/* 714 */     Configuration conf = getConf();
/*     */ 
/* 719 */     conf.set("hadoop.security.service.user.name.key", conf.get("dfs.namenode.kerberos.principal", ""));
/*     */ 
/* 723 */     RefreshUserMappingsProtocol refreshProtocol = (RefreshUserMappingsProtocol)RPC.getProxy(RefreshUserMappingsProtocol.class, 1L, NameNode.getAddress(conf), getUGI(), conf, NetUtils.getSocketFactory(conf, RefreshUserMappingsProtocol.class));
/*     */ 
/* 732 */     refreshProtocol.refreshSuperUserGroupsConfiguration();
/*     */ 
/* 734 */     return 0;
/*     */   }
/*     */ 
/*     */   private static void printUsage(String cmd)
/*     */   {
/* 743 */     if ("-report".equals(cmd)) {
/* 744 */       System.err.println("Usage: java DFSAdmin [-report]");
/*     */     }
/* 746 */     else if ("-safemode".equals(cmd)) {
/* 747 */       System.err.println("Usage: java DFSAdmin [-safemode enter | leave | get | wait]");
/*     */     }
/* 749 */     else if ("-saveNamespace".equals(cmd)) {
/* 750 */       System.err.println("Usage: java DFSAdmin [-saveNamespace]");
/*     */     }
/* 752 */     else if ("-refreshNodes".equals(cmd)) {
/* 753 */       System.err.println("Usage: java DFSAdmin [-refreshNodes]");
/*     */     }
/* 755 */     else if ("-finalizeUpgrade".equals(cmd)) {
/* 756 */       System.err.println("Usage: java DFSAdmin [-finalizeUpgrade]");
/*     */     }
/* 758 */     else if ("-upgradeProgress".equals(cmd)) {
/* 759 */       System.err.println("Usage: java DFSAdmin [-upgradeProgress status | details | force]");
/*     */     }
/* 761 */     else if ("-metasave".equals(cmd)) {
/* 762 */       System.err.println("Usage: java DFSAdmin [-metasave filename]");
/*     */     }
/* 764 */     else if (SetQuotaCommand.matches(cmd)) {
/* 765 */       System.err.println("Usage: java DFSAdmin [-setQuota <quota> <dirname>...<dirname>]");
/*     */     }
/* 767 */     else if (ClearQuotaCommand.matches(cmd)) {
/* 768 */       System.err.println("Usage: java DFSAdmin [-clrQuota <dirname>...<dirname>]");
/*     */     }
/* 770 */     else if (SetSpaceQuotaCommand.matches(cmd)) {
/* 771 */       System.err.println("Usage: java DFSAdmin [-setSpaceQuota <quota> <dirname>...<dirname>]");
/*     */     }
/* 773 */     else if (ClearSpaceQuotaCommand.matches(cmd)) {
/* 774 */       System.err.println("Usage: java DFSAdmin [-clrSpaceQuota <dirname>...<dirname>]");
/*     */     }
/* 776 */     else if ("-refreshServiceAcl".equals(cmd)) {
/* 777 */       System.err.println("Usage: java DFSAdmin [-refreshServiceAcl]");
/*     */     }
/* 779 */     else if ("-refreshUserToGroupsMappings".equals(cmd)) {
/* 780 */       System.err.println("Usage: java DFSAdmin [-refreshUserToGroupsMappings]");
/*     */     }
/* 782 */     else if ("-refreshSuperUserGroupsConfiguration".equals(cmd)) {
/* 783 */       System.err.println("Usage: java DFSAdmin [-refreshSuperUserGroupsConfiguration]");
/*     */     }
/* 785 */     else if ("-setBalancerBandwidth".equals(cmd)) {
/* 786 */       System.err.println("Usage: java DFSAdmin [-setBalancerBandwidth <bandwidth in bytes per second>]");
/*     */     }
/*     */     else {
/* 789 */       System.err.println("Usage: java DFSAdmin");
/* 790 */       System.err.println("           [-report]");
/* 791 */       System.err.println("           [-safemode enter | leave | get | wait]");
/* 792 */       System.err.println("           [-saveNamespace]");
/* 793 */       System.err.println("           [-refreshNodes]");
/* 794 */       System.err.println("           [-finalizeUpgrade]");
/* 795 */       System.err.println("           [-upgradeProgress status | details | force]");
/* 796 */       System.err.println("           [-metasave filename]");
/* 797 */       System.err.println("           [-refreshServiceAcl]");
/* 798 */       System.err.println("           [-refreshUserToGroupsMappings]");
/* 799 */       System.err.println("           [-refreshSuperUserGroupsConfiguration]");
/* 800 */       System.err.println("           [-setQuota <quota> <dirname>...<dirname>]");
/* 801 */       System.err.println("           [-clrQuota <dirname>...<dirname>]");
/* 802 */       System.err.println("           [-setSpaceQuota <quota> <dirname>...<dirname>]");
/* 803 */       System.err.println("           [-clrSpaceQuota <dirname>...<dirname>]");
/* 804 */       System.err.println("           [-setBalancerBandwidth <bandwidth in bytes per second>]");
/* 805 */       System.err.println("           [-help [cmd]]");
/* 806 */       System.err.println();
/* 807 */       ToolRunner.printGenericCommandUsage(System.err);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int run(String[] argv)
/*     */     throws Exception
/*     */   {
/* 819 */     if (argv.length < 1) {
/* 820 */       printUsage("");
/* 821 */       return -1;
/*     */     }
/*     */ 
/* 824 */     int exitCode = -1;
/* 825 */     int i = 0;
/* 826 */     String cmd = argv[(i++)];
/*     */ 
/* 831 */     if ("-safemode".equals(cmd)) {
/* 832 */       if (argv.length != 2) {
/* 833 */         printUsage(cmd);
/* 834 */         return exitCode;
/*     */       }
/* 836 */     } else if ("-report".equals(cmd)) {
/* 837 */       if (argv.length != 1) {
/* 838 */         printUsage(cmd);
/* 839 */         return exitCode;
/*     */       }
/* 841 */     } else if ("-saveNamespace".equals(cmd)) {
/* 842 */       if (argv.length != 1) {
/* 843 */         printUsage(cmd);
/* 844 */         return exitCode;
/*     */       }
/* 846 */     } else if ("-refreshNodes".equals(cmd)) {
/* 847 */       if (argv.length != 1) {
/* 848 */         printUsage(cmd);
/* 849 */         return exitCode;
/*     */       }
/* 851 */     } else if ("-finalizeUpgrade".equals(cmd)) {
/* 852 */       if (argv.length != 1) {
/* 853 */         printUsage(cmd);
/* 854 */         return exitCode;
/*     */       }
/* 856 */     } else if ("-upgradeProgress".equals(cmd)) {
/* 857 */       if (argv.length != 2) {
/* 858 */         printUsage(cmd);
/* 859 */         return exitCode;
/*     */       }
/* 861 */     } else if ("-metasave".equals(cmd)) {
/* 862 */       if (argv.length != 2) {
/* 863 */         printUsage(cmd);
/* 864 */         return exitCode;
/*     */       }
/* 866 */     } else if ("-refreshServiceAcl".equals(cmd)) {
/* 867 */       if (argv.length != 1) {
/* 868 */         printUsage(cmd);
/* 869 */         return exitCode;
/*     */       }
/* 871 */     } else if ("-refreshUserToGroupsMappings".equals(cmd)) {
/* 872 */       if (argv.length != 1) {
/* 873 */         printUsage(cmd);
/* 874 */         return exitCode;
/*     */       }
/* 876 */     } else if (("-setBalancerBandwidth".equals(cmd)) && 
/* 877 */       (argv.length != 2)) {
/* 878 */       printUsage(cmd);
/* 879 */       return exitCode;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 885 */       init();
/*     */     } catch (RPC.VersionMismatch v) {
/* 887 */       System.err.println("Version Mismatch between client and server... command aborted.");
/*     */ 
/* 889 */       return exitCode;
/*     */     } catch (IOException e) {
/* 891 */       System.err.println("Bad connection to DFS... command aborted.");
/* 892 */       return exitCode;
/*     */     }
/*     */ 
/* 895 */     exitCode = 0;
/*     */     try {
/* 897 */       if ("-report".equals(cmd)) {
/* 898 */         report();
/* 899 */       } else if ("-safemode".equals(cmd)) {
/* 900 */         setSafeMode(argv, i);
/* 901 */       } else if ("-saveNamespace".equals(cmd)) {
/* 902 */         exitCode = saveNamespace();
/* 903 */       } else if ("-refreshNodes".equals(cmd)) {
/* 904 */         exitCode = refreshNodes();
/* 905 */       } else if ("-finalizeUpgrade".equals(cmd)) {
/* 906 */         exitCode = finalizeUpgrade();
/* 907 */       } else if ("-upgradeProgress".equals(cmd)) {
/* 908 */         exitCode = upgradeProgress(argv, i);
/* 909 */       } else if ("-metasave".equals(cmd)) {
/* 910 */         exitCode = metaSave(argv, i);
/* 911 */       } else if (ClearQuotaCommand.matches(cmd)) {
/* 912 */         exitCode = new ClearQuotaCommand(argv, i, getDFS()).runAll();
/* 913 */       } else if (SetQuotaCommand.matches(cmd)) {
/* 914 */         exitCode = new SetQuotaCommand(argv, i, getDFS()).runAll();
/* 915 */       } else if (ClearSpaceQuotaCommand.matches(cmd)) {
/* 916 */         exitCode = new ClearSpaceQuotaCommand(argv, i, getDFS()).runAll();
/* 917 */       } else if (SetSpaceQuotaCommand.matches(cmd)) {
/* 918 */         exitCode = new SetSpaceQuotaCommand(argv, i, getDFS()).runAll();
/* 919 */       } else if ("-refreshServiceAcl".equals(cmd)) {
/* 920 */         exitCode = refreshServiceAcl();
/* 921 */       } else if ("-refreshUserToGroupsMappings".equals(cmd)) {
/* 922 */         exitCode = refreshUserToGroupsMappings();
/* 923 */       } else if ("-refreshSuperUserGroupsConfiguration".equals(cmd)) {
/* 924 */         exitCode = refreshSuperUserGroupsConfiguration();
/* 925 */       } else if ("-setBalancerBandwidth".equals(cmd)) {
/* 926 */         exitCode = setBalancerBandwidth(argv, i);
/* 927 */       } else if ("-help".equals(cmd)) {
/* 928 */         if (i < argv.length)
/* 929 */           printHelp(argv[i]);
/*     */         else
/* 931 */           printHelp("");
/*     */       }
/*     */       else {
/* 934 */         exitCode = -1;
/* 935 */         System.err.println(new StringBuilder().append(cmd.substring(1)).append(": Unknown command").toString());
/* 936 */         printUsage("");
/*     */       }
/*     */     } catch (IllegalArgumentException arge) {
/* 939 */       exitCode = -1;
/* 940 */       System.err.println(new StringBuilder().append(cmd.substring(1)).append(": ").append(arge.getLocalizedMessage()).toString());
/* 941 */       printUsage(cmd);
/*     */     }
/*     */     catch (RemoteException e)
/*     */     {
/* 946 */       exitCode = -1;
/*     */       try
/*     */       {
/* 949 */         String[] content = e.getLocalizedMessage().split("\n");
/* 950 */         System.err.println(new StringBuilder().append(cmd.substring(1)).append(": ").append(content[0]).toString());
/*     */       }
/*     */       catch (Exception ex) {
/* 953 */         System.err.println(new StringBuilder().append(cmd.substring(1)).append(": ").append(ex.getLocalizedMessage()).toString());
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 957 */       exitCode = -1;
/* 958 */       System.err.println(new StringBuilder().append(cmd.substring(1)).append(": ").append(e.getLocalizedMessage()).toString());
/*     */     }
/*     */ 
/* 961 */     return exitCode;
/*     */   }
/*     */ 
/*     */   public static void main(String[] argv)
/*     */     throws Exception
/*     */   {
/* 970 */     int res = ToolRunner.run(new DFSAdmin(), argv);
/* 971 */     System.exit(res);
/*     */   }
/*     */ 
/*     */   private static class SetSpaceQuotaCommand extends DFSAdmin.DFSAdminCommand
/*     */   {
/*     */     private static final String NAME = "setSpaceQuota";
/*     */     private static final String USAGE = "-setSpaceQuota <quota> <dirname>...<dirname>";
/*     */     private static final String DESCRIPTION = "-setSpaceQuota <quota> <dirname>...<dirname>: Set the disk space quota <quota> for each directory <dirName>.\n\t\tThe space quota is a long integer that puts a hard limit\n\t\ton the total size of all the files under the directory tree.\n\t\tThe extra space required for replication is also counted. E.g.\n\t\ta 1GB file with replication of 3 consumes 3GB of the quota.\n\n\t\tQuota can also be speciefied with a binary prefix for terabytes,\n\t\tpetabytes etc (e.g. 50t is 50TB, 5m is 5MB, 3p is 3PB).\n\t\tBest effort for the directory, with faults reported if\n\t\t1. N is not a positive integer, or\n\t\t2. user is not an administrator, or\n\t\t3. the directory does not exist or is a file, or\n";
/*     */     private long quota;
/*     */ 
/*     */     SetSpaceQuotaCommand(String[] args, int pos, FileSystem fs)
/*     */     {
/* 215 */       super();
/* 216 */       CommandFormat c = new CommandFormat("setSpaceQuota", 2, 2147483647, new String[0]);
/* 217 */       List parameters = c.parse(args, pos);
/* 218 */       String str = ((String)parameters.remove(0)).trim();
/* 219 */       this.quota = StringUtils.TraditionalBinaryPrefix.string2long(str);
/* 220 */       this.args = ((String[])parameters.toArray(new String[parameters.size()]));
/*     */     }
/*     */ 
/*     */     public static boolean matches(String cmd)
/*     */     {
/* 229 */       return "-setSpaceQuota".equals(cmd);
/*     */     }
/*     */ 
/*     */     public String getCommandName()
/*     */     {
/* 234 */       return "setSpaceQuota";
/*     */     }
/*     */ 
/*     */     public void run(Path path) throws IOException
/*     */     {
/* 239 */       this.dfs.setQuota(path, 9223372036854775807L, this.quota);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ClearSpaceQuotaCommand extends DFSAdmin.DFSAdminCommand
/*     */   {
/*     */     private static final String NAME = "clrSpaceQuota";
/*     */     private static final String USAGE = "-clrSpaceQuota <dirname>...<dirname>";
/*     */     private static final String DESCRIPTION = "-clrSpaceQuota <dirname>...<dirname>: Clear the disk space quota for each directory <dirName>.\n\t\tBest effort for the directory. with fault reported if\n\t\t1. the directory does not exist or is a file, or\n\t\t2. user is not an administrator.\n\t\tIt does not fault if the directory has no quota.";
/*     */ 
/*     */     ClearSpaceQuotaCommand(String[] args, int pos, FileSystem fs)
/*     */     {
/* 167 */       super();
/* 168 */       CommandFormat c = new CommandFormat("clrSpaceQuota", 1, 2147483647, new String[0]);
/* 169 */       List parameters = c.parse(args, pos);
/* 170 */       this.args = ((String[])parameters.toArray(new String[parameters.size()]));
/*     */     }
/*     */ 
/*     */     public static boolean matches(String cmd)
/*     */     {
/* 179 */       return "-clrSpaceQuota".equals(cmd);
/*     */     }
/*     */ 
/*     */     public String getCommandName()
/*     */     {
/* 184 */       return "clrSpaceQuota";
/*     */     }
/*     */ 
/*     */     public void run(Path path) throws IOException
/*     */     {
/* 189 */       this.dfs.setQuota(path, 9223372036854775807L, -1L);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class SetQuotaCommand extends DFSAdmin.DFSAdminCommand
/*     */   {
/*     */     private static final String NAME = "setQuota";
/*     */     private static final String USAGE = "-setQuota <quota> <dirname>...<dirname>";
/*     */     private static final String DESCRIPTION = "-setQuota <quota> <dirname>...<dirname>: Set the quota <quota> for each directory <dirName>.\n\t\tThe directory quota is a long integer that puts a hard limit\n\t\ton the number of names in the directory tree\n\t\tBest effort for the directory, with faults reported if\n\t\t1. N is not a positive integer, or\n\t\t2. user is not an administrator, or\n\t\t3. the directory does not exist or is a file, or\n";
/*     */     private final long quota;
/*     */ 
/*     */     SetQuotaCommand(String[] args, int pos, FileSystem fs)
/*     */     {
/* 127 */       super();
/* 128 */       CommandFormat c = new CommandFormat("setQuota", 2, 2147483647, new String[0]);
/* 129 */       List parameters = c.parse(args, pos);
/* 130 */       this.quota = Long.parseLong((String)parameters.remove(0));
/* 131 */       this.args = ((String[])parameters.toArray(new String[parameters.size()]));
/*     */     }
/*     */ 
/*     */     public static boolean matches(String cmd)
/*     */     {
/* 140 */       return "-setQuota".equals(cmd);
/*     */     }
/*     */ 
/*     */     public String getCommandName()
/*     */     {
/* 145 */       return "setQuota";
/*     */     }
/*     */ 
/*     */     public void run(Path path) throws IOException
/*     */     {
/* 150 */       this.dfs.setQuota(path, this.quota, 9223372036854775807L);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ClearQuotaCommand extends DFSAdmin.DFSAdminCommand
/*     */   {
/*     */     private static final String NAME = "clrQuota";
/*     */     private static final String USAGE = "-clrQuota <dirname>...<dirname>";
/*     */     private static final String DESCRIPTION = "-clrQuota <dirname>...<dirname>: Clear the quota for each directory <dirName>.\n\t\tBest effort for the directory. with fault reported if\n\t\t1. the directory does not exist or is a file, or\n\t\t2. user is not an administrator.\n\t\tIt does not fault if the directory has no quota.";
/*     */ 
/*     */     ClearQuotaCommand(String[] args, int pos, FileSystem fs)
/*     */     {
/*  82 */       super();
/*  83 */       CommandFormat c = new CommandFormat("clrQuota", 1, 2147483647, new String[0]);
/*  84 */       List parameters = c.parse(args, pos);
/*  85 */       this.args = ((String[])parameters.toArray(new String[parameters.size()]));
/*     */     }
/*     */ 
/*     */     public static boolean matches(String cmd)
/*     */     {
/*  94 */       return "-clrQuota".equals(cmd);
/*     */     }
/*     */ 
/*     */     public String getCommandName()
/*     */     {
/*  99 */       return "clrQuota";
/*     */     }
/*     */ 
/*     */     public void run(Path path) throws IOException
/*     */     {
/* 104 */       this.dfs.setQuota(path, -1L, 9223372036854775807L);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static abstract class DFSAdminCommand extends Command
/*     */   {
/*     */     final DistributedFileSystem dfs;
/*     */ 
/*     */     public DFSAdminCommand(FileSystem fs)
/*     */     {
/*  60 */       super();
/*  61 */       if (!(fs instanceof DistributedFileSystem)) {
/*  62 */         throw new IllegalArgumentException("FileSystem " + fs.getUri() + " is not a distributed file system");
/*     */       }
/*     */ 
/*  65 */       this.dfs = ((DistributedFileSystem)fs);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.tools.DFSAdmin
 * JD-Core Version:    0.6.1
 */
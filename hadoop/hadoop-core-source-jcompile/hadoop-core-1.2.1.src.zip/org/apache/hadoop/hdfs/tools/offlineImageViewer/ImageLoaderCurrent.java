/*     */ package org.apache.hadoop.hdfs.tools.offlineImageViewer;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo.AdminStates;
/*     */ import org.apache.hadoop.hdfs.protocol.LayoutVersion;
/*     */ import org.apache.hadoop.hdfs.protocol.LayoutVersion.Feature;
/*     */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenIdentifier;
/*     */ import org.apache.hadoop.hdfs.server.namenode.FSImage;
/*     */ import org.apache.hadoop.io.Text;
/*     */ import org.apache.hadoop.io.WritableUtils;
/*     */ import org.apache.hadoop.io.compress.CompressionCodec;
/*     */ import org.apache.hadoop.io.compress.CompressionCodecFactory;
/*     */ import org.apache.hadoop.security.token.delegation.DelegationKey;
/*     */ 
/*     */ class ImageLoaderCurrent
/*     */   implements ImageLoader
/*     */ {
/* 122 */   protected final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
/*     */ 
/* 124 */   private static int[] versions = { -16, -17, -18, -19, -20, -21, -22, -23, -24, -25, -26, -27, -28, -30, -31, -32, -33, -34, -41 };
/*     */ 
/* 126 */   private int imageVersion = 0;
/*     */ 
/*     */   public boolean canLoadVersion(int version)
/*     */   {
/* 133 */     for (int v : versions) {
/* 134 */       if (v == version) return true;
/*     */     }
/* 136 */     return false;
/*     */   }
/*     */ 
/*     */   public void loadImage(DataInputStream in, ImageVisitor v, boolean skipBlocks)
/*     */     throws IOException
/*     */   {
/* 145 */     boolean done = false;
/*     */     try {
/* 147 */       v.start();
/* 148 */       v.visitEnclosingElement(ImageVisitor.ImageElement.FS_IMAGE);
/*     */ 
/* 150 */       this.imageVersion = in.readInt();
/* 151 */       if (!canLoadVersion(this.imageVersion)) {
/* 152 */         throw new IOException("Cannot process fslayout version " + this.imageVersion);
/*     */       }
/* 154 */       v.visit(ImageVisitor.ImageElement.IMAGE_VERSION, this.imageVersion);
/* 155 */       v.visit(ImageVisitor.ImageElement.NAMESPACE_ID, in.readInt());
/*     */ 
/* 157 */       long numInodes = in.readLong();
/*     */ 
/* 159 */       v.visit(ImageVisitor.ImageElement.GENERATION_STAMP, in.readLong());
/*     */ 
/* 161 */       if (LayoutVersion.supports(LayoutVersion.Feature.FSIMAGE_COMPRESSION, this.imageVersion)) {
/* 162 */         boolean isCompressed = in.readBoolean();
/* 163 */         v.visit(ImageVisitor.ImageElement.IS_COMPRESSED, String.valueOf(isCompressed));
/* 164 */         if (isCompressed) {
/* 165 */           String codecClassName = Text.readString(in);
/* 166 */           v.visit(ImageVisitor.ImageElement.COMPRESS_CODEC, codecClassName);
/* 167 */           CompressionCodecFactory codecFac = new CompressionCodecFactory(new Configuration());
/*     */ 
/* 169 */           CompressionCodec codec = codecFac.getCodecByClassName(codecClassName);
/* 170 */           if (codec == null) {
/* 171 */             throw new IOException("Image compression codec not supported: " + codecClassName);
/*     */           }
/*     */ 
/* 174 */           in = new DataInputStream(codec.createInputStream(in));
/*     */         }
/*     */       }
/* 177 */       processINodes(in, v, numInodes, skipBlocks);
/*     */ 
/* 179 */       processINodesUC(in, v, skipBlocks);
/*     */ 
/* 181 */       if (LayoutVersion.supports(LayoutVersion.Feature.DELEGATION_TOKEN, this.imageVersion)) {
/* 182 */         processDelegationTokens(in, v);
/*     */       }
/*     */ 
/* 185 */       v.leaveEnclosingElement();
/* 186 */       done = true;
/*     */     } finally {
/* 188 */       if (done)
/* 189 */         v.finish();
/*     */       else
/* 191 */         v.finishAbnormally();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void processDelegationTokens(DataInputStream in, ImageVisitor v)
/*     */     throws IOException
/*     */   {
/* 204 */     v.visit(ImageVisitor.ImageElement.CURRENT_DELEGATION_KEY_ID, in.readInt());
/* 205 */     int numDKeys = in.readInt();
/* 206 */     v.visitEnclosingElement(ImageVisitor.ImageElement.DELEGATION_KEYS, ImageVisitor.ImageElement.NUM_DELEGATION_KEYS, numDKeys);
/*     */ 
/* 208 */     for (int i = 0; i < numDKeys; i++) {
/* 209 */       DelegationKey key = new DelegationKey();
/* 210 */       key.readFields(in);
/* 211 */       v.visit(ImageVisitor.ImageElement.DELEGATION_KEY, key.toString());
/*     */     }
/* 213 */     v.leaveEnclosingElement();
/* 214 */     v.visit(ImageVisitor.ImageElement.DELEGATION_TOKEN_SEQUENCE_NUMBER, in.readInt());
/* 215 */     int numDTokens = in.readInt();
/* 216 */     v.visitEnclosingElement(ImageVisitor.ImageElement.DELEGATION_TOKENS, ImageVisitor.ImageElement.NUM_DELEGATION_TOKENS, numDTokens);
/*     */ 
/* 218 */     for (int i = 0; i < numDTokens; i++) {
/* 219 */       DelegationTokenIdentifier id = new DelegationTokenIdentifier();
/* 220 */       id.readFields(in);
/* 221 */       long expiryTime = in.readLong();
/* 222 */       v.visitEnclosingElement(ImageVisitor.ImageElement.DELEGATION_TOKEN_IDENTIFIER);
/* 223 */       v.visit(ImageVisitor.ImageElement.DELEGATION_TOKEN_IDENTIFIER_KIND, id.getKind().toString());
/*     */ 
/* 225 */       v.visit(ImageVisitor.ImageElement.DELEGATION_TOKEN_IDENTIFIER_SEQNO, id.getSequenceNumber());
/*     */ 
/* 227 */       v.visit(ImageVisitor.ImageElement.DELEGATION_TOKEN_IDENTIFIER_RENEWER, id.getRenewer().toString());
/*     */ 
/* 229 */       v.visit(ImageVisitor.ImageElement.DELEGATION_TOKEN_IDENTIFIER_ISSUE_DATE, id.getIssueDate());
/*     */ 
/* 231 */       v.visit(ImageVisitor.ImageElement.DELEGATION_TOKEN_IDENTIFIER_MAX_DATE, id.getMaxDate());
/*     */ 
/* 233 */       v.visit(ImageVisitor.ImageElement.DELEGATION_TOKEN_IDENTIFIER_EXPIRY_TIME, expiryTime);
/*     */ 
/* 235 */       v.visit(ImageVisitor.ImageElement.DELEGATION_TOKEN_IDENTIFIER_MASTER_KEY_ID, id.getMasterKeyId());
/*     */ 
/* 237 */       v.leaveEnclosingElement();
/*     */     }
/* 239 */     v.leaveEnclosingElement();
/*     */   }
/*     */ 
/*     */   private void processINodesUC(DataInputStream in, ImageVisitor v, boolean skipBlocks)
/*     */     throws IOException
/*     */   {
/* 251 */     int numINUC = in.readInt();
/*     */ 
/* 253 */     v.visitEnclosingElement(ImageVisitor.ImageElement.INODES_UNDER_CONSTRUCTION, ImageVisitor.ImageElement.NUM_INODES_UNDER_CONSTRUCTION, numINUC);
/*     */ 
/* 256 */     for (int i = 0; i < numINUC; i++) {
/* 257 */       v.visitEnclosingElement(ImageVisitor.ImageElement.INODE_UNDER_CONSTRUCTION);
/* 258 */       byte[] name = FSImage.readBytes(in);
/* 259 */       String n = new String(name, "UTF8");
/* 260 */       v.visit(ImageVisitor.ImageElement.INODE_PATH, n);
/* 261 */       v.visit(ImageVisitor.ImageElement.REPLICATION, in.readShort());
/* 262 */       v.visit(ImageVisitor.ImageElement.MODIFICATION_TIME, formatDate(in.readLong()));
/*     */ 
/* 264 */       v.visit(ImageVisitor.ImageElement.PREFERRED_BLOCK_SIZE, in.readLong());
/* 265 */       int numBlocks = in.readInt();
/* 266 */       processBlocks(in, v, numBlocks, skipBlocks);
/*     */ 
/* 268 */       processPermission(in, v);
/* 269 */       v.visit(ImageVisitor.ImageElement.CLIENT_NAME, FSImage.readString(in));
/* 270 */       v.visit(ImageVisitor.ImageElement.CLIENT_MACHINE, FSImage.readString(in));
/*     */ 
/* 274 */       int numLocs = in.readInt();
/* 275 */       for (int j = 0; j < numLocs; j++) {
/* 276 */         in.readShort();
/* 277 */         in.readLong();
/* 278 */         in.readLong();
/* 279 */         in.readLong();
/* 280 */         in.readInt();
/* 281 */         FSImage.readString(in);
/* 282 */         FSImage.readString(in);
/* 283 */         WritableUtils.readEnum(in, DatanodeInfo.AdminStates.class);
/*     */       }
/*     */ 
/* 286 */       v.leaveEnclosingElement();
/*     */     }
/*     */ 
/* 289 */     v.leaveEnclosingElement();
/*     */   }
/*     */ 
/*     */   private void processBlocks(DataInputStream in, ImageVisitor v, int numBlocks, boolean skipBlocks)
/*     */     throws IOException
/*     */   {
/* 301 */     v.visitEnclosingElement(ImageVisitor.ImageElement.BLOCKS, ImageVisitor.ImageElement.NUM_BLOCKS, numBlocks);
/*     */ 
/* 305 */     if ((numBlocks == -1) || (numBlocks == -2)) {
/* 306 */       v.leaveEnclosingElement();
/* 307 */       return;
/*     */     }
/*     */ 
/* 310 */     if (skipBlocks) {
/* 311 */       int bytesToSkip = 24 * numBlocks;
/* 312 */       if (in.skipBytes(bytesToSkip) != bytesToSkip)
/* 313 */         throw new IOException("Error skipping over blocks");
/*     */     }
/*     */     else {
/* 316 */       for (int j = 0; j < numBlocks; j++) {
/* 317 */         v.visitEnclosingElement(ImageVisitor.ImageElement.BLOCK);
/* 318 */         v.visit(ImageVisitor.ImageElement.BLOCK_ID, in.readLong());
/* 319 */         v.visit(ImageVisitor.ImageElement.NUM_BYTES, in.readLong());
/* 320 */         v.visit(ImageVisitor.ImageElement.GENERATION_STAMP, in.readLong());
/* 321 */         v.leaveEnclosingElement();
/*     */       }
/*     */     }
/* 324 */     v.leaveEnclosingElement();
/*     */   }
/*     */ 
/*     */   private void processPermission(DataInputStream in, ImageVisitor v)
/*     */     throws IOException
/*     */   {
/* 335 */     v.visitEnclosingElement(ImageVisitor.ImageElement.PERMISSIONS);
/* 336 */     v.visit(ImageVisitor.ImageElement.USER_NAME, Text.readString(in));
/* 337 */     v.visit(ImageVisitor.ImageElement.GROUP_NAME, Text.readString(in));
/* 338 */     FsPermission fsp = new FsPermission(in.readShort());
/* 339 */     v.visit(ImageVisitor.ImageElement.PERMISSION_STRING, fsp.toString());
/* 340 */     v.leaveEnclosingElement();
/*     */   }
/*     */ 
/*     */   private void processINodes(DataInputStream in, ImageVisitor v, long numInodes, boolean skipBlocks)
/*     */     throws IOException
/*     */   {
/* 355 */     v.visitEnclosingElement(ImageVisitor.ImageElement.INODES, ImageVisitor.ImageElement.NUM_INODES, numInodes);
/*     */ 
/* 358 */     if (LayoutVersion.supports(LayoutVersion.Feature.FSIMAGE_NAME_OPTIMIZATION, this.imageVersion))
/* 359 */       processLocalNameINodes(in, v, numInodes, skipBlocks);
/*     */     else {
/* 361 */       processFullNameINodes(in, v, numInodes, skipBlocks);
/*     */     }
/*     */ 
/* 365 */     v.leaveEnclosingElement();
/*     */   }
/*     */ 
/*     */   private void processLocalNameINodes(DataInputStream in, ImageVisitor v, long numInodes, boolean skipBlocks)
/*     */     throws IOException
/*     */   {
/* 380 */     processINode(in, v, skipBlocks, "");
/* 381 */     numInodes -= 1L;
/* 382 */     while (numInodes > 0L)
/* 383 */       numInodes -= processDirectory(in, v, skipBlocks);
/*     */   }
/*     */ 
/*     */   private int processDirectory(DataInputStream in, ImageVisitor v, boolean skipBlocks)
/*     */     throws IOException
/*     */   {
/* 389 */     String parentName = FSImage.readString(in);
/* 390 */     int numChildren = in.readInt();
/* 391 */     for (int i = 0; i < numChildren; i++) {
/* 392 */       processINode(in, v, skipBlocks, parentName);
/*     */     }
/* 394 */     return numChildren;
/*     */   }
/*     */ 
/*     */   private void processFullNameINodes(DataInputStream in, ImageVisitor v, long numInodes, boolean skipBlocks)
/*     */     throws IOException
/*     */   {
/* 408 */     for (long i = 0L; i < numInodes; i += 1L)
/* 409 */       processINode(in, v, skipBlocks, null);
/*     */   }
/*     */ 
/*     */   private void processINode(DataInputStream in, ImageVisitor v, boolean skipBlocks, String parentName)
/*     */     throws IOException
/*     */   {
/* 424 */     v.visitEnclosingElement(ImageVisitor.ImageElement.INODE);
/* 425 */     String pathName = FSImage.readString(in);
/* 426 */     if (parentName != null) {
/* 427 */       pathName = "/" + pathName;
/* 428 */       if (!"/".equals(parentName)) {
/* 429 */         pathName = parentName + pathName;
/*     */       }
/*     */     }
/*     */ 
/* 433 */     v.visit(ImageVisitor.ImageElement.INODE_PATH, pathName);
/* 434 */     v.visit(ImageVisitor.ImageElement.REPLICATION, in.readShort());
/* 435 */     v.visit(ImageVisitor.ImageElement.MODIFICATION_TIME, formatDate(in.readLong()));
/* 436 */     if (LayoutVersion.supports(LayoutVersion.Feature.FILE_ACCESS_TIME, this.imageVersion))
/* 437 */       v.visit(ImageVisitor.ImageElement.ACCESS_TIME, formatDate(in.readLong()));
/* 438 */     v.visit(ImageVisitor.ImageElement.BLOCK_SIZE, in.readLong());
/* 439 */     int numBlocks = in.readInt();
/*     */ 
/* 441 */     processBlocks(in, v, numBlocks, skipBlocks);
/*     */ 
/* 444 */     if ((numBlocks > 0) || (numBlocks == -1)) {
/* 445 */       v.visit(ImageVisitor.ImageElement.NS_QUOTA, numBlocks == -1 ? in.readLong() : -1L);
/* 446 */       if (LayoutVersion.supports(LayoutVersion.Feature.DISKSPACE_QUOTA, this.imageVersion))
/* 447 */         v.visit(ImageVisitor.ImageElement.DS_QUOTA, numBlocks == -1 ? in.readLong() : -1L);
/*     */     }
/* 449 */     if (numBlocks == -2) {
/* 450 */       v.visit(ImageVisitor.ImageElement.SYMLINK, Text.readString(in));
/*     */     }
/*     */ 
/* 453 */     processPermission(in, v);
/* 454 */     v.leaveEnclosingElement();
/*     */   }
/*     */ 
/*     */   private String formatDate(long date)
/*     */   {
/* 463 */     return this.dateFormat.format(new Date(date));
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.tools.offlineImageViewer.ImageLoaderCurrent
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs.tools.offlineImageViewer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Formatter;
/*     */ import java.util.LinkedList;
/*     */ 
/*     */ class LsImageVisitor extends TextWriterImageVisitor
/*     */ {
/*  37 */   private final LinkedList<ImageVisitor.ImageElement> elemQ = new LinkedList();
/*     */   private int numBlocks;
/*     */   private String perms;
/*     */   private int replication;
/*     */   private String username;
/*     */   private String group;
/*     */   private long filesize;
/*     */   private String modTime;
/*     */   private String path;
/*     */   private String linkTarget;
/*  49 */   private boolean inInode = false;
/*  50 */   private final StringBuilder sb = new StringBuilder();
/*  51 */   private final Formatter formatter = new Formatter(this.sb);
/*     */   private static final int widthRepl = 2;
/*     */   private static final int widthUser = 8;
/*     */   private static final int widthGroup = 10;
/*     */   private static final int widthSize = 10;
/*     */   private static final int widthMod = 10;
/*     */   private static final String lsStr = " %2s %8s %10s %10d %10s %s";
/*     */ 
/*     */   public LsImageVisitor(String filename)
/*     */     throws IOException
/*     */   {
/*  54 */     super(filename);
/*     */   }
/*     */ 
/*     */   public LsImageVisitor(String filename, boolean printToScreen) throws IOException {
/*  58 */     super(filename, printToScreen);
/*     */   }
/*     */ 
/*     */   private void newLine()
/*     */   {
/*  65 */     this.numBlocks = 0;
/*  66 */     this.perms = (this.username = this.group = this.path = this.linkTarget = "");
/*  67 */     this.filesize = 0L;
/*  68 */     this.replication = 0;
/*     */ 
/*  70 */     this.inInode = true;
/*     */   }
/*     */ 
/*     */   private void printLine()
/*     */     throws IOException
/*     */   {
/*  86 */     this.sb.append(this.numBlocks < 0 ? "d" : "-");
/*  87 */     this.sb.append(this.perms);
/*     */ 
/*  89 */     if (0 != this.linkTarget.length()) {
/*  90 */       this.path = new StringBuilder().append(this.path).append(" -> ").append(this.linkTarget).toString();
/*     */     }
/*  92 */     this.formatter.format(" %2s %8s %10s %10d %10s %s", new Object[] { this.replication > 0 ? Integer.valueOf(this.replication) : "-", this.username, this.group, Long.valueOf(this.filesize), this.modTime, this.path });
/*     */ 
/*  94 */     this.sb.append("\n");
/*     */ 
/*  96 */     write(this.sb.toString());
/*  97 */     this.sb.setLength(0);
/*     */ 
/*  99 */     this.inInode = false;
/*     */   }
/*     */ 
/*     */   void start() throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   void finish() throws IOException {
/* 107 */     super.finish();
/*     */   }
/*     */ 
/*     */   void finishAbnormally() throws IOException
/*     */   {
/* 112 */     System.out.println("Input ended unexpectedly.");
/* 113 */     super.finishAbnormally();
/*     */   }
/*     */ 
/*     */   void leaveEnclosingElement() throws IOException
/*     */   {
/* 118 */     ImageVisitor.ImageElement elem = (ImageVisitor.ImageElement)this.elemQ.pop();
/*     */ 
/* 120 */     if (elem == ImageVisitor.ImageElement.INODE)
/* 121 */       printLine();
/*     */   }
/*     */ 
/*     */   void visit(ImageVisitor.ImageElement element, String value)
/*     */     throws IOException
/*     */   {
/* 128 */     if (this.inInode)
/* 129 */       switch (1.$SwitchMap$org$apache$hadoop$hdfs$tools$offlineImageViewer$ImageVisitor$ImageElement[element.ordinal()]) {
/*     */       case 1:
/* 131 */         if (value.equals("")) this.path = "/"; else
/* 132 */           this.path = value;
/* 133 */         break;
/*     */       case 2:
/* 135 */         this.perms = value;
/* 136 */         break;
/*     */       case 3:
/* 138 */         this.replication = Integer.valueOf(value).intValue();
/* 139 */         break;
/*     */       case 4:
/* 141 */         this.username = value;
/* 142 */         break;
/*     */       case 5:
/* 144 */         this.group = value;
/* 145 */         break;
/*     */       case 6:
/* 147 */         this.filesize += Long.valueOf(value).longValue();
/* 148 */         break;
/*     */       case 7:
/* 150 */         this.modTime = value;
/* 151 */         break;
/*     */       case 8:
/* 153 */         this.linkTarget = value;
/* 154 */         break;
/*     */       }
/*     */   }
/*     */ 
/*     */   void visitEnclosingElement(ImageVisitor.ImageElement element)
/*     */     throws IOException
/*     */   {
/* 164 */     this.elemQ.push(element);
/* 165 */     if (element == ImageVisitor.ImageElement.INODE)
/* 166 */       newLine();
/*     */   }
/*     */ 
/*     */   void visitEnclosingElement(ImageVisitor.ImageElement element, ImageVisitor.ImageElement key, String value)
/*     */     throws IOException
/*     */   {
/* 172 */     this.elemQ.push(element);
/* 173 */     if (element == ImageVisitor.ImageElement.INODE)
/* 174 */       newLine();
/* 175 */     else if (element == ImageVisitor.ImageElement.BLOCKS)
/* 176 */       this.numBlocks = Integer.valueOf(value).intValue();
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.tools.offlineImageViewer.LsImageVisitor
 * JD-Core Version:    0.6.1
 */
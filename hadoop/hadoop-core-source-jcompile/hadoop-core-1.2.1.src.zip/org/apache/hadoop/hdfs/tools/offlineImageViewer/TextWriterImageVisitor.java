/*     */ package org.apache.hadoop.hdfs.tools.offlineImageViewer;
/*     */ 
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintStream;
/*     */ import java.nio.charset.Charset;
/*     */ 
/*     */ abstract class TextWriterImageVisitor extends ImageVisitor
/*     */ {
/*  38 */   private static final Charset UTF_8 = Charset.forName("UTF-8");
/*  39 */   private boolean printToScreen = false;
/*  40 */   private boolean okToWrite = false;
/*     */   private final OutputStreamWriter fw;
/*     */ 
/*     */   public TextWriterImageVisitor(String filename)
/*     */     throws IOException
/*     */   {
/*  49 */     this(filename, false);
/*     */   }
/*     */ 
/*     */   public TextWriterImageVisitor(String filename, boolean printToScreen)
/*     */     throws IOException
/*     */   {
/*  62 */     this.printToScreen = printToScreen;
/*  63 */     this.fw = new OutputStreamWriter(new FileOutputStream(filename), UTF_8);
/*  64 */     this.okToWrite = true;
/*     */   }
/*     */ 
/*     */   void finish()
/*     */     throws IOException
/*     */   {
/*  72 */     close();
/*     */   }
/*     */ 
/*     */   void finishAbnormally()
/*     */     throws IOException
/*     */   {
/*  80 */     close();
/*     */   }
/*     */ 
/*     */   private void close()
/*     */     throws IOException
/*     */   {
/*  87 */     this.fw.close();
/*  88 */     this.okToWrite = false;
/*     */   }
/*     */ 
/*     */   protected void write(String toWrite)
/*     */     throws IOException
/*     */   {
/*  97 */     if (!this.okToWrite) {
/*  98 */       throw new IOException("file not open for writing.");
/*     */     }
/* 100 */     if (this.printToScreen)
/* 101 */       System.out.print(toWrite);
/*     */     try
/*     */     {
/* 104 */       this.fw.write(toWrite);
/*     */     } catch (IOException e) {
/* 106 */       this.okToWrite = false;
/* 107 */       throw e;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.tools.offlineImageViewer.TextWriterImageVisitor
 * JD-Core Version:    0.6.1
 */
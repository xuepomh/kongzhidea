/*     */ package org.apache.hadoop.hdfs.tools.offlineImageViewer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ abstract class ImageVisitor
/*     */ {
/*     */   abstract void start()
/*     */     throws IOException;
/*     */ 
/*     */   abstract void finish()
/*     */     throws IOException;
/*     */ 
/*     */   abstract void finishAbnormally()
/*     */     throws IOException;
/*     */ 
/*     */   abstract void visit(ImageElement paramImageElement, String paramString)
/*     */     throws IOException;
/*     */ 
/*     */   void visit(ImageElement element, int value)
/*     */     throws IOException
/*     */   {
/* 114 */     visit(element, Integer.toString(value));
/*     */   }
/*     */ 
/*     */   void visit(ImageElement element, long value) throws IOException {
/* 118 */     visit(element, Long.toString(value));
/*     */   }
/*     */ 
/*     */   abstract void visitEnclosingElement(ImageElement paramImageElement)
/*     */     throws IOException;
/*     */ 
/*     */   abstract void visitEnclosingElement(ImageElement paramImageElement1, ImageElement paramImageElement2, String paramString)
/*     */     throws IOException;
/*     */ 
/*     */   void visitEnclosingElement(ImageElement element, ImageElement key, int value)
/*     */     throws IOException
/*     */   {
/* 148 */     visitEnclosingElement(element, key, Integer.toString(value));
/*     */   }
/*     */ 
/*     */   void visitEnclosingElement(ImageElement element, ImageElement key, long value)
/*     */     throws IOException
/*     */   {
/* 154 */     visitEnclosingElement(element, key, Long.toString(value));
/*     */   }
/*     */ 
/*     */   abstract void leaveEnclosingElement()
/*     */     throws IOException;
/*     */ 
/*     */   public static enum ImageElement
/*     */   {
/*  33 */     FS_IMAGE, 
/*  34 */     IMAGE_VERSION, 
/*  35 */     NAMESPACE_ID, 
/*  36 */     IS_COMPRESSED, 
/*  37 */     COMPRESS_CODEC, 
/*  38 */     LAYOUT_VERSION, 
/*  39 */     NUM_INODES, 
/*  40 */     GENERATION_STAMP, 
/*  41 */     INODES, 
/*  42 */     INODE, 
/*  43 */     INODE_PATH, 
/*  44 */     REPLICATION, 
/*  45 */     MODIFICATION_TIME, 
/*  46 */     ACCESS_TIME, 
/*  47 */     BLOCK_SIZE, 
/*  48 */     NUM_BLOCKS, 
/*  49 */     BLOCKS, 
/*  50 */     BLOCK, 
/*  51 */     BLOCK_ID, 
/*  52 */     NUM_BYTES, 
/*  53 */     NS_QUOTA, 
/*  54 */     DS_QUOTA, 
/*  55 */     PERMISSIONS, 
/*  56 */     SYMLINK, 
/*  57 */     NUM_INODES_UNDER_CONSTRUCTION, 
/*  58 */     INODES_UNDER_CONSTRUCTION, 
/*  59 */     INODE_UNDER_CONSTRUCTION, 
/*  60 */     PREFERRED_BLOCK_SIZE, 
/*  61 */     CLIENT_NAME, 
/*  62 */     CLIENT_MACHINE, 
/*  63 */     USER_NAME, 
/*  64 */     GROUP_NAME, 
/*  65 */     PERMISSION_STRING, 
/*  66 */     CURRENT_DELEGATION_KEY_ID, 
/*  67 */     NUM_DELEGATION_KEYS, 
/*  68 */     DELEGATION_KEYS, 
/*  69 */     DELEGATION_KEY, 
/*  70 */     DELEGATION_TOKEN_SEQUENCE_NUMBER, 
/*  71 */     NUM_DELEGATION_TOKENS, 
/*  72 */     DELEGATION_TOKENS, 
/*  73 */     DELEGATION_TOKEN_IDENTIFIER, 
/*  74 */     DELEGATION_TOKEN_IDENTIFIER_KIND, 
/*  75 */     DELEGATION_TOKEN_IDENTIFIER_SEQNO, 
/*  76 */     DELEGATION_TOKEN_IDENTIFIER_OWNER, 
/*  77 */     DELEGATION_TOKEN_IDENTIFIER_RENEWER, 
/*  78 */     DELEGATION_TOKEN_IDENTIFIER_REALUSER, 
/*  79 */     DELEGATION_TOKEN_IDENTIFIER_ISSUE_DATE, 
/*  80 */     DELEGATION_TOKEN_IDENTIFIER_MAX_DATE, 
/*  81 */     DELEGATION_TOKEN_IDENTIFIER_EXPIRY_TIME, 
/*  82 */     DELEGATION_TOKEN_IDENTIFIER_MASTER_KEY_ID;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.tools.offlineImageViewer.ImageVisitor
 * JD-Core Version:    0.6.1
 */
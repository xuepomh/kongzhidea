/*     */ package org.apache.hadoop.hdfs.tools.offlineImageViewer;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.Closeable;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import org.apache.commons.cli.CommandLine;
/*     */ import org.apache.commons.cli.CommandLineParser;
/*     */ import org.apache.commons.cli.OptionBuilder;
/*     */ import org.apache.commons.cli.Options;
/*     */ import org.apache.commons.cli.ParseException;
/*     */ import org.apache.commons.cli.PosixParser;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.classification.InterfaceAudience.Private;
/*     */ import org.apache.hadoop.io.IOUtils;
/*     */ 
/*     */ @InterfaceAudience.Private
/*     */ public class OfflineImageViewer
/*     */ {
/*  48 */   public static final Log LOG = LogFactory.getLog(OfflineImageViewer.class);
/*     */   private static final String usage = "Usage: bin/hadoop oiv [OPTIONS] -i INPUTFILE -o OUTPUTFILE\nOffline Image Viewer\nView a Hadoop fsimage INPUTFILE using the specified PROCESSOR,\nsaving the results in OUTPUTFILE.\n\nThe oiv utility will attempt to parse correctly formed image files\nand will abort fail with mal-formed image files.\n\nThe tool works offline and does not require a running cluster in\norder to process an image file.\n\nThe following image processors are available:\n  * Ls: The default image processor generates an lsr-style listing\n    of the files in the namespace, with the same fields in the same\n    order.  Note that in order to correctly determine file sizes,\n    this formatter cannot skip blocks and will override the\n    -skipBlocks option.\n  * Indented: This processor enumerates over all of the elements in\n    the fsimage file, using levels of indentation to delineate\n    sections within the file.\n  * Delimited: Generate a text file with all of the elements common\n    to both inodes and inodes-under-construction, separated by a\n    delimiter. The default delimiter is \001, though this may be\n    changed via the -delimiter argument. This processor also overrides\n    the -skipBlocks option for the same reason as the Ls processor\n  * XML: This processor creates an XML document with all elements of\n    the fsimage enumerated, suitable for further analysis by XML\n    tools.\n  * FileDistribution: This processor analyzes the file size\n    distribution in the image.\n    -maxSize specifies the range [0, maxSize] of file sizes to be\n     analyzed (128GB by default).\n    -step defines the granularity of the distribution. (2MB by default)\n  * NameDistribution: This processor analyzes the file names\n    in the image and prints total number of file names and how frequently    file names are reused.\n\nRequired command line arguments:\n-i,--inputFile <arg>   FSImage file to process.\n-o,--outputFile <arg>  Name of output file. If the specified\n                       file exists, it will be overwritten.\n\nOptional command line arguments:\n-p,--processor <arg>   Select which type of processor to apply\n                       against image file. (Ls|XML|Delimited|Indented|FileDistribution).\n-h,--help              Display usage information and exit\n-printToScreen         For processors that write to a file, also\n                       output to screen. On large image files this\n                       will dramatically increase processing time.\n-skipBlocks            Skip inodes' blocks information. May\n                       significantly decrease output.\n                       (default = false).\n-delimiter <arg>       Delimiting string to use with Delimited processor\n";
/*     */   private final boolean skipBlocks;
/*     */   private final String inputFile;
/*     */   private final ImageVisitor processor;
/*     */ 
/*     */   public OfflineImageViewer(String inputFile, ImageVisitor processor, boolean skipBlocks)
/*     */   {
/* 112 */     this.inputFile = inputFile;
/* 113 */     this.processor = processor;
/* 114 */     this.skipBlocks = skipBlocks;
/*     */   }
/*     */ 
/*     */   public void go()
/*     */     throws IOException
/*     */   {
/* 121 */     DataInputStream in = null;
/* 122 */     PositionTrackingInputStream tracker = null;
/* 123 */     ImageLoader fsip = null;
/* 124 */     boolean done = false;
/*     */     try {
/* 126 */       tracker = new PositionTrackingInputStream(new BufferedInputStream(new FileInputStream(new File(this.inputFile))));
/*     */ 
/* 128 */       in = new DataInputStream(tracker);
/*     */ 
/* 130 */       int imageVersionFile = findImageVersion(in);
/*     */ 
/* 132 */       fsip = ImageLoader.LoaderFactory.getLoader(imageVersionFile);
/*     */ 
/* 134 */       if (fsip == null) {
/* 135 */         throw new IOException("No image processor to read version " + imageVersionFile + " is available.");
/*     */       }
/* 137 */       fsip.loadImage(in, this.processor, this.skipBlocks);
/* 138 */       done = true;
/*     */     } finally {
/* 140 */       if (!done) {
/* 141 */         LOG.error("image loading failed at offset " + tracker.getPos());
/*     */       }
/* 143 */       IOUtils.cleanup(LOG, new Closeable[] { in, tracker });
/*     */     }
/*     */   }
/*     */ 
/*     */   private int findImageVersion(DataInputStream in)
/*     */     throws IOException
/*     */   {
/* 158 */     in.mark(42);
/*     */ 
/* 160 */     int version = in.readInt();
/* 161 */     in.reset();
/*     */ 
/* 163 */     return version;
/*     */   }
/*     */ 
/*     */   public static Options buildOptions()
/*     */   {
/* 170 */     Options options = new Options();
/*     */ 
/* 174 */     OptionBuilder.isRequired();
/* 175 */     OptionBuilder.hasArgs();
/* 176 */     OptionBuilder.withLongOpt("outputFile");
/* 177 */     options.addOption(OptionBuilder.create("o"));
/*     */ 
/* 179 */     OptionBuilder.isRequired();
/* 180 */     OptionBuilder.hasArgs();
/* 181 */     OptionBuilder.withLongOpt("inputFile");
/* 182 */     options.addOption(OptionBuilder.create("i"));
/*     */ 
/* 184 */     options.addOption("p", "processor", true, "");
/* 185 */     options.addOption("h", "help", false, "");
/* 186 */     options.addOption("skipBlocks", false, "");
/* 187 */     options.addOption("printToScreen", false, "");
/* 188 */     options.addOption("delimiter", true, "");
/*     */ 
/* 190 */     return options;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws IOException
/*     */   {
/* 203 */     Options options = buildOptions();
/* 204 */     if (args.length == 0) {
/* 205 */       printUsage();
/* 206 */       return;
/*     */     }
/*     */ 
/* 209 */     CommandLineParser parser = new PosixParser();
/*     */     CommandLine cmd;
/*     */     try {
/* 213 */       cmd = parser.parse(options, args);
/*     */     } catch (ParseException e) {
/* 215 */       System.out.println("Error parsing command-line options: ");
/* 216 */       printUsage();
/* 217 */       return;
/*     */     }
/*     */ 
/* 220 */     if (cmd.hasOption("h")) {
/* 221 */       printUsage();
/* 222 */       return;
/*     */     }
/*     */ 
/* 225 */     boolean skipBlocks = cmd.hasOption("skipBlocks");
/* 226 */     boolean printToScreen = cmd.hasOption("printToScreen");
/* 227 */     String inputFile = cmd.getOptionValue("i");
/* 228 */     String processor = cmd.getOptionValue("p", "Ls");
/* 229 */     String outputFile = cmd.getOptionValue("o");
/* 230 */     String delimiter = cmd.getOptionValue("delimiter");
/*     */ 
/* 232 */     if ((delimiter != null) && (!processor.equals("Delimited"))) {
/* 233 */       System.out.println("Can only specify -delimiter with Delimited processor");
/* 234 */       printUsage();
/*     */       return;
/*     */     }
/*     */     ImageVisitor v;
/*     */     ImageVisitor v;
/* 239 */     if (processor.equals("Indented")) {
/* 240 */       v = new IndentedImageVisitor(outputFile, printToScreen);
/*     */     }
/*     */     else
/*     */     {
/*     */       ImageVisitor v;
/* 241 */       if (processor.equals("XML")) {
/* 242 */         v = new XmlImageVisitor(outputFile, printToScreen);
/* 243 */       } else if (processor.equals("Delimited")) {
/* 244 */         ImageVisitor v = delimiter == null ? new DelimitedImageVisitor(outputFile, printToScreen) : new DelimitedImageVisitor(outputFile, printToScreen, delimiter);
/*     */ 
/* 247 */         skipBlocks = false;
/*     */       }
/*     */       else
/*     */       {
/*     */         ImageVisitor v;
/* 248 */         if (processor.equals("FileDistribution")) {
/* 249 */           long maxSize = Long.parseLong(cmd.getOptionValue("maxSize", "0"));
/* 250 */           int step = Integer.parseInt(cmd.getOptionValue("step", "0"));
/* 251 */           v = new FileDistributionVisitor(outputFile, maxSize, step);
/*     */         }
/*     */         else
/*     */         {
/*     */           ImageVisitor v;
/* 252 */           if (processor.equals("NameDistribution")) {
/* 253 */             v = new NameDistributionVisitor(outputFile, printToScreen);
/*     */           } else {
/* 255 */             v = new LsImageVisitor(outputFile, printToScreen);
/* 256 */             skipBlocks = false; } 
/*     */         }
/*     */       }
/*     */     }
/*     */     try { OfflineImageViewer d = new OfflineImageViewer(inputFile, v, skipBlocks);
/* 261 */       d.go();
/*     */     } catch (EOFException e) {
/* 263 */       System.err.println("Input file ended unexpectedly.  Exiting");
/*     */     } catch (IOException e) {
/* 265 */       System.err.println("Encountered exception.  Exiting: " + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void printUsage()
/*     */   {
/* 273 */     System.out.println("Usage: bin/hadoop oiv [OPTIONS] -i INPUTFILE -o OUTPUTFILE\nOffline Image Viewer\nView a Hadoop fsimage INPUTFILE using the specified PROCESSOR,\nsaving the results in OUTPUTFILE.\n\nThe oiv utility will attempt to parse correctly formed image files\nand will abort fail with mal-formed image files.\n\nThe tool works offline and does not require a running cluster in\norder to process an image file.\n\nThe following image processors are available:\n  * Ls: The default image processor generates an lsr-style listing\n    of the files in the namespace, with the same fields in the same\n    order.  Note that in order to correctly determine file sizes,\n    this formatter cannot skip blocks and will override the\n    -skipBlocks option.\n  * Indented: This processor enumerates over all of the elements in\n    the fsimage file, using levels of indentation to delineate\n    sections within the file.\n  * Delimited: Generate a text file with all of the elements common\n    to both inodes and inodes-under-construction, separated by a\n    delimiter. The default delimiter is \001, though this may be\n    changed via the -delimiter argument. This processor also overrides\n    the -skipBlocks option for the same reason as the Ls processor\n  * XML: This processor creates an XML document with all elements of\n    the fsimage enumerated, suitable for further analysis by XML\n    tools.\n  * FileDistribution: This processor analyzes the file size\n    distribution in the image.\n    -maxSize specifies the range [0, maxSize] of file sizes to be\n     analyzed (128GB by default).\n    -step defines the granularity of the distribution. (2MB by default)\n  * NameDistribution: This processor analyzes the file names\n    in the image and prints total number of file names and how frequently    file names are reused.\n\nRequired command line arguments:\n-i,--inputFile <arg>   FSImage file to process.\n-o,--outputFile <arg>  Name of output file. If the specified\n                       file exists, it will be overwritten.\n\nOptional command line arguments:\n-p,--processor <arg>   Select which type of processor to apply\n                       against image file. (Ls|XML|Delimited|Indented|FileDistribution).\n-h,--help              Display usage information and exit\n-printToScreen         For processors that write to a file, also\n                       output to screen. On large image files this\n                       will dramatically increase processing time.\n-skipBlocks            Skip inodes' blocks information. May\n                       significantly decrease output.\n                       (default = false).\n-delimiter <arg>       Delimiting string to use with Delimited processor\n");
/*     */   }
/*     */ 
/*     */   private static class PositionTrackingInputStream extends FilterInputStream
/*     */   {
/* 280 */     private long curPos = 0L;
/* 281 */     private long markPos = -1L;
/*     */ 
/*     */     public PositionTrackingInputStream(InputStream is) {
/* 284 */       super();
/*     */     }
/*     */ 
/*     */     public int read() throws IOException
/*     */     {
/* 289 */       int ret = super.read();
/* 290 */       if (ret != -1) this.curPos += 1L;
/* 291 */       return ret;
/*     */     }
/*     */ 
/*     */     public int read(byte[] data) throws IOException
/*     */     {
/* 296 */       int ret = super.read(data);
/* 297 */       if (ret > 0) this.curPos += ret;
/* 298 */       return ret;
/*     */     }
/*     */ 
/*     */     public int read(byte[] data, int offset, int length) throws IOException
/*     */     {
/* 303 */       int ret = super.read(data, offset, length);
/* 304 */       if (ret > 0) this.curPos += ret;
/* 305 */       return ret;
/*     */     }
/*     */ 
/*     */     public void mark(int limit)
/*     */     {
/* 310 */       super.mark(limit);
/* 311 */       this.markPos = this.curPos;
/*     */     }
/*     */ 
/*     */     public void reset() throws IOException
/*     */     {
/* 316 */       if (this.markPos == -1L) {
/* 317 */         throw new IOException("Not marked!");
/*     */       }
/* 319 */       super.reset();
/* 320 */       this.curPos = this.markPos;
/* 321 */       this.markPos = -1L;
/*     */     }
/*     */ 
/*     */     public long getPos() {
/* 325 */       return this.curPos;
/*     */     }
/*     */ 
/*     */     public long skip(long amt) throws IOException
/*     */     {
/* 330 */       long ret = super.skip(amt);
/* 331 */       this.curPos += ret;
/* 332 */       return ret;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.tools.offlineImageViewer.OfflineImageViewer
 * JD-Core Version:    0.6.1
 */
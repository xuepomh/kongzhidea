/*     */ package org.apache.hadoop.hdfs.tools;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.Closeable;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.apache.commons.cli.CommandLine;
/*     */ import org.apache.commons.cli.Options;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.hdfs.DFSUtil;
/*     */ import org.apache.hadoop.hdfs.HftpFileSystem;
/*     */ import org.apache.hadoop.hdfs.HsftpFileSystem;
/*     */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenIdentifier;
/*     */ import org.apache.hadoop.io.IOUtils;
/*     */ import org.apache.hadoop.io.Text;
/*     */ import org.apache.hadoop.security.AccessControlException;
/*     */ import org.apache.hadoop.security.Credentials;
/*     */ import org.apache.hadoop.security.Krb5AndCertsSslSocketConnector;
/*     */ import org.apache.hadoop.security.SecurityUtil;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.token.SecretManager.InvalidToken;
/*     */ import org.apache.hadoop.security.token.Token;
/*     */ import org.apache.hadoop.util.GenericOptionsParser;
/*     */ 
/*     */ public class DelegationTokenFetcher
/*     */ {
/*     */   private static final Log LOG;
/*     */   private static final String WEBSERVICE = "webservice";
/*     */   private static final String CANCEL = "cancel";
/*     */   private static final String RENEW = "renew";
/*     */ 
/*     */   private static void printUsage(PrintStream err)
/*     */     throws IOException
/*     */   {
/*  82 */     err.println("fetchdt retrieves delegation tokens from the NameNode");
/*  83 */     err.println();
/*  84 */     err.println("fetchdt <opts> <token file>");
/*  85 */     err.println("Options:");
/*  86 */     err.println("  --webservice <url>  Url to contact NN on");
/*  87 */     err.println("  --cancel            Cancel the delegation token");
/*  88 */     err.println("  --renew             Renew the delegation token");
/*  89 */     err.println();
/*  90 */     GenericOptionsParser.printGenericCommandUsage(err);
/*  91 */     System.exit(1);
/*     */   }
/*     */ 
/*     */   private static Collection<Token<?>> readTokens(Path file, Configuration conf) throws IOException
/*     */   {
/*  96 */     Credentials creds = Credentials.readTokenStorageFile(file, conf);
/*  97 */     return creds.getAllTokens();
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/* 104 */     Configuration conf = new Configuration();
/* 105 */     setupSsl(conf);
/* 106 */     Options fetcherOptions = new Options();
/* 107 */     fetcherOptions.addOption("webservice", true, "HTTP/S url to reach the NameNode at");
/*     */ 
/* 109 */     fetcherOptions.addOption("cancel", false, "cancel the token");
/* 110 */     fetcherOptions.addOption("renew", false, "renew the token");
/* 111 */     GenericOptionsParser parser = new GenericOptionsParser(conf, fetcherOptions, args);
/*     */ 
/* 113 */     CommandLine cmd = parser.getCommandLine();
/*     */ 
/* 116 */     String webUrl = cmd.hasOption("webservice") ? cmd.getOptionValue("webservice") : null;
/*     */ 
/* 118 */     boolean cancel = cmd.hasOption("cancel");
/* 119 */     boolean renew = cmd.hasOption("renew");
/* 120 */     String[] remaining = parser.getRemainingArgs();
/*     */ 
/* 123 */     if ((cancel) && (renew)) {
/* 124 */       System.err.println("ERROR: Only specify cancel or renew.");
/* 125 */       printUsage(System.err);
/*     */     }
/* 127 */     if ((remaining.length != 1) || (remaining[0].charAt(0) == '-')) {
/* 128 */       System.err.println("ERROR: Must specify exactly one token file");
/* 129 */       printUsage(System.err);
/*     */     }
/*     */ 
/* 132 */     FileSystem local = FileSystem.getLocal(conf);
/* 133 */     Path tokenFile = new Path(local.getWorkingDirectory(), remaining[0]);
/*     */ 
/* 135 */     if (cancel) {
/* 136 */       for (Token token : readTokens(tokenFile, conf)) {
/* 137 */         if (token.isManaged())
/* 138 */           token.cancel(conf);
/*     */       }
/*     */     }
/* 141 */     else if (renew) {
/* 142 */       for (Token token : readTokens(tokenFile, conf)) {
/* 143 */         if (token.isManaged()) {
/* 144 */           token.renew(conf);
/*     */         }
/*     */       }
/*     */     }
/* 148 */     else if (webUrl != null) {
/* 149 */       URI uri = new URI(webUrl);
/* 150 */       getDTfromRemote(uri.getScheme(), new InetSocketAddress(uri.getHost(), uri.getPort()), null, conf).writeTokenStorageFile(tokenFile, conf);
/*     */     }
/*     */     else
/*     */     {
/* 156 */       FileSystem fs = FileSystem.get(conf);
/* 157 */       UserGroupInformation ugi = UserGroupInformation.getCurrentUser();
/* 158 */       Token token = fs.getDelegationToken(ugi.getShortUserName());
/* 159 */       Credentials cred = new Credentials();
/* 160 */       cred.addToken(token.getService(), token);
/* 161 */       cred.writeTokenStorageFile(tokenFile, conf);
/* 162 */       if (LOG.isDebugEnabled())
/* 163 */         LOG.debug(new StringBuilder().append("Fetched token for ").append(fs.getUri()).append(" into ").append(tokenFile).toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void setupSsl(Configuration conf)
/*     */   {
/* 172 */     Configuration sslConf = new Configuration(false);
/* 173 */     sslConf.addResource(conf.get("dfs.https.client.keystore.resource", "ssl-client.xml"));
/*     */ 
/* 175 */     System.setProperty("javax.net.ssl.trustStore", sslConf.get("ssl.client.truststore.location", ""));
/*     */ 
/* 177 */     System.setProperty("javax.net.ssl.trustStorePassword", sslConf.get("ssl.client.truststore.password", ""));
/*     */ 
/* 179 */     System.setProperty("javax.net.ssl.trustStoreType", sslConf.get("ssl.client.truststore.type", "jks"));
/*     */ 
/* 181 */     System.setProperty("javax.net.ssl.keyStore", sslConf.get("ssl.client.keystore.location", ""));
/*     */ 
/* 183 */     System.setProperty("javax.net.ssl.keyStorePassword", sslConf.get("ssl.client.keystore.password", ""));
/*     */ 
/* 185 */     System.setProperty("javax.net.ssl.keyPassword", sslConf.get("ssl.client.keystore.keypassword", ""));
/*     */ 
/* 187 */     System.setProperty("javax.net.ssl.keyStoreType", sslConf.get("ssl.client.keystore.type", "jks"));
/*     */   }
/*     */ 
/*     */   public static Credentials getDTfromRemote(String protocol, final InetSocketAddress nnAddr, String renewer, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 203 */     String renewAddress = getRenewAddress(protocol, nnAddr, conf);
/* 204 */     final boolean https = "https".equals(protocol);
/*     */     try
/*     */     {
/* 207 */       StringBuffer url = new StringBuffer(renewAddress);
/* 208 */       url.append("/getDelegationToken");
/* 209 */       if (renewer != null) {
/* 210 */         url.append("?").append("renewer").append("=").append(renewer);
/*     */       }
/*     */ 
/* 214 */       if (LOG.isDebugEnabled()) {
/* 215 */         LOG.debug(new StringBuilder().append("Retrieving token from: ").append(url).toString());
/*     */       }
/* 217 */       URL remoteURL = new URL(url.toString());
/* 218 */       UserGroupInformation ugi = UserGroupInformation.getCurrentUser();
/* 219 */       return (Credentials)ugi.doAs(new PrivilegedExceptionAction() {
/*     */         public Credentials run() throws Exception {
/* 221 */           URLConnection connection = SecurityUtil.openSecureHttpConnection(this.val$remoteURL);
/*     */ 
/* 224 */           InputStream in = connection.getInputStream();
/* 225 */           Credentials ts = new Credentials();
/* 226 */           DataInputStream dis = new DataInputStream(in);
/*     */           try {
/* 228 */             ts.readFields(dis);
/* 229 */             for (Token token : ts.getAllTokens()) {
/* 230 */               if (https)
/* 231 */                 token.setKind(HsftpFileSystem.TOKEN_KIND);
/*     */               else {
/* 233 */                 token.setKind(HftpFileSystem.TOKEN_KIND);
/*     */               }
/* 235 */               SecurityUtil.setTokenService(token, nnAddr);
/*     */             }
/* 237 */             dis.close();
/*     */           } catch (IOException ie) {
/* 239 */             IOUtils.cleanup(DelegationTokenFetcher.LOG, new Closeable[] { dis });
/*     */           }
/* 241 */           return ts;
/*     */         } } );
/*     */     } catch (InterruptedException ie) {
/*     */     }
/* 245 */     return null;
/*     */   }
/*     */ 
/*     */   protected static String getRenewAddress(String protocol, InetSocketAddress addr, Configuration conf)
/*     */   {
/* 257 */     if ((SecurityUtil.useKsslAuth()) && ("http".equals(protocol))) {
/* 258 */       protocol = "https";
/* 259 */       int port = conf.getInt("dfs.https.port", 50470);
/*     */ 
/* 262 */       addr = new InetSocketAddress(addr.getAddress(), port);
/*     */     }
/* 264 */     return DFSUtil.createUri(protocol, addr).toString();
/*     */   }
/*     */ 
/*     */   public static long renewDelegationToken(String protocol, InetSocketAddress addr, Token<DelegationTokenIdentifier> tok, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 281 */     final String renewAddress = getRenewAddress(protocol, addr, conf);
/* 282 */     StringBuilder buf = new StringBuilder(renewAddress);
/* 283 */     final String service = tok.getService().toString();
/* 284 */     buf.append("/renewDelegationToken");
/* 285 */     buf.append("?");
/* 286 */     buf.append("token");
/* 287 */     buf.append("=");
/* 288 */     buf.append(tok.encodeToUrlString());
/* 289 */     UserGroupInformation ugi = UserGroupInformation.getCurrentUser();
/*     */     try {
/* 291 */       return ((Long)ugi.doAs(new PrivilegedExceptionAction() {
/*     */         public Long run() throws Exception {
/* 293 */           BufferedReader in = null;
/* 294 */           HttpURLConnection connection = null;
/*     */           try {
/* 296 */             URL url = new URL(this.val$buf.toString());
/* 297 */             connection = (HttpURLConnection)SecurityUtil.openSecureHttpConnection(url);
/*     */ 
/* 299 */             in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
/*     */ 
/* 301 */             long result = Long.parseLong(in.readLine());
/* 302 */             in.close();
/* 303 */             if (DelegationTokenFetcher.LOG.isDebugEnabled()) {
/* 304 */               DelegationTokenFetcher.LOG.debug("Renewed token for " + service + " via " + renewAddress);
/*     */             }
/*     */ 
/* 307 */             return Long.valueOf(result);
/*     */           } catch (IOException ie) {
/* 309 */             DelegationTokenFetcher.LOG.info("Error renewing token for " + renewAddress, ie);
/* 310 */             IOException e = null;
/* 311 */             if (connection != null) {
/* 312 */               String resp = connection.getResponseMessage();
/* 313 */               e = DelegationTokenFetcher.getExceptionFromResponse(resp);
/*     */             }
/*     */ 
/* 316 */             IOUtils.cleanup(DelegationTokenFetcher.LOG, new Closeable[] { in });
/* 317 */             if (e != null) {
/* 318 */               DelegationTokenFetcher.LOG.info("rethrowing exception from HTTP request: " + e.getLocalizedMessage());
/*     */ 
/* 320 */               throw e;
/*     */             }
/* 322 */             throw ie;
/*     */           }
/*     */         }
/*     */       })).longValue();
/*     */     }
/*     */     catch (InterruptedException ie)
/*     */     {
/*     */     }
/*     */ 
/* 327 */     return 0L;
/*     */   }
/*     */ 
/*     */   private static IOException getExceptionFromResponse(String resp)
/*     */   {
/* 332 */     String exceptionClass = ""; String exceptionMsg = "";
/* 333 */     if ((resp != null) && (!resp.isEmpty())) {
/* 334 */       String[] rs = resp.split(";");
/* 335 */       exceptionClass = rs[0];
/* 336 */       exceptionMsg = rs[1];
/*     */     }
/* 338 */     LOG.info(new StringBuilder().append("Error response from HTTP request=").append(resp).append(";ec=").append(exceptionClass).append(";em=").append(exceptionMsg).toString());
/*     */ 
/* 340 */     IOException e = null;
/* 341 */     if ((exceptionClass != null) && (!exceptionClass.isEmpty())) {
/* 342 */       if (exceptionClass.contains("InvalidToken")) {
/* 343 */         e = new SecretManager.InvalidToken(exceptionMsg);
/* 344 */         e.setStackTrace(new StackTraceElement[0]);
/* 345 */       } else if (exceptionClass.contains("AccessControlException")) {
/* 346 */         e = new AccessControlException(exceptionMsg);
/* 347 */         e.setStackTrace(new StackTraceElement[0]);
/*     */       }
/*     */     }
/* 350 */     LOG.info(new StringBuilder().append("Exception from HTTP response=").append(e.getLocalizedMessage()).toString());
/* 351 */     return e;
/*     */   }
/*     */ 
/*     */   public static void cancelDelegationToken(String protocol, InetSocketAddress addr, Token<DelegationTokenIdentifier> tok, Configuration conf)
/*     */     throws IOException
/*     */   {
/* 365 */     final String renewAddress = getRenewAddress(protocol, addr, conf);
/* 366 */     StringBuilder buf = new StringBuilder(renewAddress);
/* 367 */     buf.append("/cancelDelegationToken");
/* 368 */     buf.append("?");
/* 369 */     buf.append("token");
/* 370 */     buf.append("=");
/* 371 */     buf.append(tok.encodeToUrlString());
/* 372 */     BufferedReader in = null;
/*     */     try {
/* 374 */       URL url = new URL(buf.toString());
/* 375 */       if (LOG.isDebugEnabled()) {
/* 376 */         LOG.debug(new StringBuilder().append("cancelling token at ").append(buf.toString()).toString());
/*     */       }
/* 378 */       UserGroupInformation ugi = UserGroupInformation.getCurrentUser();
/* 379 */       ugi.doAs(new PrivilegedExceptionAction() {
/*     */         public Void run() throws Exception {
/* 381 */           HttpURLConnection connection = (HttpURLConnection)SecurityUtil.openSecureHttpConnection(this.val$url);
/*     */ 
/* 383 */           if (connection.getResponseCode() != 200) {
/* 384 */             throw new IOException("Error cancelling token for " + renewAddress + " response: " + connection.getResponseMessage());
/*     */           }
/*     */ 
/* 388 */           return null;
/*     */         }
/*     */       });
/* 391 */       if (LOG.isDebugEnabled())
/* 392 */         LOG.debug(new StringBuilder().append("Cancelled token for ").append(tok.getService()).append(" via ").append(renewAddress).toString());
/*     */     }
/*     */     catch (IOException ie)
/*     */     {
/* 396 */       LOG.warn(new StringBuilder().append("Error cancelling token for ").append(renewAddress).toString(), ie);
/* 397 */       IOUtils.cleanup(LOG, new Closeable[] { in });
/* 398 */       throw ie;
/*     */     }
/*     */     catch (InterruptedException ie)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  66 */     Configuration.addDefaultResource("hdfs-default.xml");
/*  67 */     Configuration.addDefaultResource("hdfs-site.xml");
/*     */ 
/*  70 */     LOG = LogFactory.getLog(DelegationTokenFetcher.class);
/*     */ 
/*  78 */     int x = Krb5AndCertsSslSocketConnector.KRB5_CIPHER_SUITES.size();
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.tools.DelegationTokenFetcher
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.tools.offlineImageViewer;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map.Entry;
/*    */ import org.apache.hadoop.classification.InterfaceAudience.Private;
/*    */ 
/*    */ @InterfaceAudience.Private
/*    */ public class NameDistributionVisitor extends TextWriterImageVisitor
/*    */ {
/* 37 */   HashMap<String, Integer> counts = new HashMap();
/*    */ 
/*    */   public NameDistributionVisitor(String filename, boolean printToScreen) throws IOException
/*    */   {
/* 41 */     super(filename, printToScreen);
/*    */   }
/*    */ 
/*    */   void finish() throws IOException
/*    */   {
/* 46 */     int BYTEARRAY_OVERHEAD = 24;
/*    */ 
/* 48 */     write("Total unique file names " + this.counts.size());
/*    */ 
/* 51 */     long[][] stats = { { 100000L, 0L, 0L, 0L }, { 10000L, 0L, 0L, 0L }, { 1000L, 0L, 0L, 0L }, { 100L, 0L, 0L, 0L }, { 10L, 0L, 0L, 0L }, { 5L, 0L, 0L, 0L }, { 4L, 0L, 0L, 0L }, { 3L, 0L, 0L, 0L }, { 2L, 0L, 0L, 0L } };
/*    */ 
/* 61 */     int highbound = -2147483648;
/* 62 */     for (Map.Entry entry : this.counts.entrySet()) {
/* 63 */       highbound = Math.max(highbound, ((Integer)entry.getValue()).intValue());
/* 64 */       for (int i = 0; i < stats.length; i++) {
/* 65 */         if (((Integer)entry.getValue()).intValue() >= stats[i][0]) {
/* 66 */           stats[i][1] += (24 + ((String)entry.getKey()).length()) * (((Integer)entry.getValue()).intValue() - 1);
/*    */ 
/* 68 */           stats[i][2] += ((Integer)entry.getValue()).intValue();
/* 69 */           stats[i][3] += 1L;
/* 70 */           break;
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 75 */     long lowbound = 0L;
/* 76 */     long totalsavings = 0L;
/* 77 */     for (long[] stat : stats) {
/* 78 */       lowbound = stat[0];
/* 79 */       totalsavings += stat[1];
/* 80 */       String range = " between " + lowbound + "-" + highbound;
/*    */ 
/* 82 */       write("\n" + stat[3] + " names are used by " + stat[2] + " files" + range + " times. Heap savings ~" + stat[1] + " bytes.");
/*    */ 
/* 84 */       highbound = (int)stat[0] - 1;
/*    */     }
/* 86 */     write("\n\nTotal saved heap ~" + totalsavings + "bytes.\n");
/* 87 */     super.finish();
/*    */   }
/*    */ 
/*    */   void visit(ImageVisitor.ImageElement element, String value) throws IOException
/*    */   {
/* 92 */     if (element == ImageVisitor.ImageElement.INODE_PATH) {
/* 93 */       String filename = value.substring(value.lastIndexOf("/") + 1);
/* 94 */       if (this.counts.containsKey(filename))
/* 95 */         this.counts.put(filename, Integer.valueOf(((Integer)this.counts.get(filename)).intValue() + 1));
/*    */       else
/* 97 */         this.counts.put(filename, Integer.valueOf(1));
/*    */     }
/*    */   }
/*    */ 
/*    */   void leaveEnclosingElement()
/*    */     throws IOException
/*    */   {
/*    */   }
/*    */ 
/*    */   void start()
/*    */     throws IOException
/*    */   {
/*    */   }
/*    */ 
/*    */   void visitEnclosingElement(ImageVisitor.ImageElement element)
/*    */     throws IOException
/*    */   {
/*    */   }
/*    */ 
/*    */   void visitEnclosingElement(ImageVisitor.ImageElement element, ImageVisitor.ImageElement key, String value)
/*    */     throws IOException
/*    */   {
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.tools.offlineImageViewer.NameDistributionVisitor
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.protocol;
/*    */ 
/*    */ import org.apache.hadoop.util.StringUtils;
/*    */ 
/*    */ public class DSQuotaExceededException extends QuotaExceededException
/*    */ {
/*    */   protected static final long serialVersionUID = 1L;
/*    */ 
/*    */   public DSQuotaExceededException(String msg)
/*    */   {
/* 27 */     super(msg);
/*    */   }
/*    */ 
/*    */   public DSQuotaExceededException(long quota, long count) {
/* 31 */     super(quota, count);
/*    */   }
/*    */ 
/*    */   public String getMessage() {
/* 35 */     String msg = super.getMessage();
/* 36 */     if (msg == null) {
/* 37 */       return new StringBuilder().append("The DiskSpace quota").append(this.pathName == null ? "" : new StringBuilder().append(" of ").append(this.pathName).toString()).append(" is exceeded: quota=").append(this.quota).append(" diskspace consumed=").append(StringUtils.humanReadableInt(this.count)).toString();
/*    */     }
/*    */ 
/* 40 */     return msg;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.protocol.DSQuotaExceededException
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.protocol;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.apache.hadoop.hdfs.security.token.block.BlockTokenIdentifier;
/*    */ import org.apache.hadoop.hdfs.security.token.block.BlockTokenSelector;
/*    */ import org.apache.hadoop.ipc.VersionedProtocol;
/*    */ import org.apache.hadoop.security.KerberosInfo;
/*    */ import org.apache.hadoop.security.token.Token;
/*    */ import org.apache.hadoop.security.token.TokenInfo;
/*    */ 
/*    */ @KerberosInfo(serverPrincipal="dfs.datanode.kerberos.principal")
/*    */ @TokenInfo(BlockTokenSelector.class)
/*    */ public abstract interface ClientDatanodeProtocol extends VersionedProtocol
/*    */ {
/* 38 */   public static final Log LOG = LogFactory.getLog(ClientDatanodeProtocol.class);
/*    */   public static final long versionID = 4L;
/*    */ 
/*    */   public abstract LocatedBlock recoverBlock(Block paramBlock, boolean paramBoolean, DatanodeInfo[] paramArrayOfDatanodeInfo)
/*    */     throws IOException;
/*    */ 
/*    */   public abstract Block getBlockInfo(Block paramBlock)
/*    */     throws IOException;
/*    */ 
/*    */   public abstract BlockLocalPathInfo getBlockLocalPathInfo(Block paramBlock, Token<BlockTokenIdentifier> paramToken)
/*    */     throws IOException;
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.protocol.ClientDatanodeProtocol
 * JD-Core Version:    0.6.1
 */
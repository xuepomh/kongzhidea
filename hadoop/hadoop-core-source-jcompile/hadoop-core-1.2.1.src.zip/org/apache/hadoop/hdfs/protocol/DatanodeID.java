/*     */ package org.apache.hadoop.hdfs.protocol;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.io.UTF8;
/*     */ import org.apache.hadoop.io.WritableComparable;
/*     */ 
/*     */ public class DatanodeID
/*     */   implements WritableComparable<DatanodeID>
/*     */ {
/*  35 */   public static final DatanodeID[] EMPTY_ARRAY = new DatanodeID[0];
/*     */   public String name;
/*     */   public String storageID;
/*     */   protected int infoPort;
/*     */   public int ipcPort;
/*     */ 
/*     */   public DatanodeID()
/*     */   {
/*  43 */     this("");
/*     */   }
/*     */   public DatanodeID(String nodeName) {
/*  46 */     this(nodeName, "", -1, -1);
/*     */   }
/*     */ 
/*     */   public DatanodeID(DatanodeID from)
/*     */   {
/*  54 */     this(from.getName(), from.getStorageID(), from.getInfoPort(), from.getIpcPort());
/*     */   }
/*     */ 
/*     */   public DatanodeID(String nodeName, String storageID, int infoPort, int ipcPort)
/*     */   {
/*  69 */     this.name = nodeName;
/*  70 */     this.storageID = storageID;
/*  71 */     this.infoPort = infoPort;
/*  72 */     this.ipcPort = ipcPort;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  79 */     return this.name;
/*     */   }
/*     */ 
/*     */   public String getStorageID()
/*     */   {
/*  86 */     return this.storageID;
/*     */   }
/*     */ 
/*     */   public int getInfoPort()
/*     */   {
/*  93 */     return this.infoPort;
/*     */   }
/*     */ 
/*     */   public int getIpcPort()
/*     */   {
/* 100 */     return this.ipcPort;
/*     */   }
/*     */ 
/*     */   public void setStorageID(String storageID)
/*     */   {
/* 107 */     this.storageID = storageID;
/*     */   }
/*     */ 
/*     */   public String getHost()
/*     */   {
/* 114 */     int colon = this.name.indexOf(":");
/* 115 */     if (colon < 0) {
/* 116 */       return this.name;
/*     */     }
/* 118 */     return this.name.substring(0, colon);
/*     */   }
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 123 */     int colon = this.name.indexOf(":");
/* 124 */     if (colon < 0) {
/* 125 */       return 50010;
/*     */     }
/* 127 */     return Integer.parseInt(this.name.substring(colon + 1));
/*     */   }
/*     */ 
/*     */   public boolean equals(Object to) {
/* 131 */     if (this == to) {
/* 132 */       return true;
/*     */     }
/* 134 */     if (!(to instanceof DatanodeID)) {
/* 135 */       return false;
/*     */     }
/* 137 */     return (this.name.equals(((DatanodeID)to).getName())) && (this.storageID.equals(((DatanodeID)to).getStorageID()));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 142 */     return this.name.hashCode() ^ this.storageID.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 146 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void updateRegInfo(DatanodeID nodeReg)
/*     */   {
/* 154 */     this.name = nodeReg.getName();
/* 155 */     this.infoPort = nodeReg.getInfoPort();
/* 156 */     this.ipcPort = nodeReg.getIpcPort();
/*     */   }
/*     */ 
/*     */   public int compareTo(DatanodeID that)
/*     */   {
/* 166 */     return this.name.compareTo(that.getName());
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/* 174 */     UTF8.writeString(out, this.name);
/* 175 */     UTF8.writeString(out, this.storageID);
/* 176 */     out.writeShort(this.infoPort);
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException
/*     */   {
/* 181 */     this.name = UTF8.readString(in);
/* 182 */     this.storageID = UTF8.readString(in);
/*     */ 
/* 187 */     this.infoPort = (in.readShort() & 0xFFFF);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.protocol.DatanodeID
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs.protocol;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.WritableFactories;
/*     */ import org.apache.hadoop.io.WritableFactory;
/*     */ 
/*     */ public class DirectoryListing
/*     */   implements Writable
/*     */ {
/*     */   private HdfsFileStatus[] partialListing;
/*     */   private int remainingEntries;
/*     */ 
/*     */   public DirectoryListing()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DirectoryListing(HdfsFileStatus[] partialListing, int remainingEntries)
/*     */   {
/*  56 */     if (partialListing == null) {
/*  57 */       throw new IllegalArgumentException("partial listing should not be null");
/*     */     }
/*  59 */     if ((partialListing.length == 0) && (remainingEntries != 0)) {
/*  60 */       throw new IllegalArgumentException("Partial listing is empty but the number of remaining entries is not zero");
/*     */     }
/*     */ 
/*  63 */     this.partialListing = partialListing;
/*  64 */     this.remainingEntries = remainingEntries;
/*     */   }
/*     */ 
/*     */   public HdfsFileStatus[] getPartialListing()
/*     */   {
/*  72 */     return this.partialListing;
/*     */   }
/*     */ 
/*     */   public int getRemainingEntries()
/*     */   {
/*  80 */     return this.remainingEntries;
/*     */   }
/*     */ 
/*     */   public boolean hasMore()
/*     */   {
/*  89 */     return this.remainingEntries != 0;
/*     */   }
/*     */ 
/*     */   public byte[] getLastName()
/*     */   {
/*  97 */     if (this.partialListing.length == 0) {
/*  98 */       return null;
/*     */     }
/* 100 */     return this.partialListing[(this.partialListing.length - 1)].getLocalNameInBytes();
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in)
/*     */     throws IOException
/*     */   {
/* 106 */     int numEntries = in.readInt();
/* 107 */     this.partialListing = new HdfsFileStatus[numEntries];
/* 108 */     for (int i = 0; i < numEntries; i++) {
/* 109 */       this.partialListing[i] = new HdfsFileStatus();
/* 110 */       this.partialListing[i].readFields(in);
/*     */     }
/* 112 */     this.remainingEntries = in.readInt();
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out) throws IOException
/*     */   {
/* 117 */     out.writeInt(this.partialListing.length);
/* 118 */     for (HdfsFileStatus fileStatus : this.partialListing) {
/* 119 */       fileStatus.write(out);
/*     */     }
/* 121 */     out.writeInt(this.remainingEntries);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  33 */     WritableFactories.setFactory(DirectoryListing.class, new WritableFactory()
/*     */     {
/*     */       public Writable newInstance() {
/*  36 */         return new DirectoryListing();
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.protocol.DirectoryListing
 * JD-Core Version:    0.6.1
 */
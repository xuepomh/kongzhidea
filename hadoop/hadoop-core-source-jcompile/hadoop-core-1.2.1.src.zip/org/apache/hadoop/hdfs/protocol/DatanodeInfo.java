/*     */ package org.apache.hadoop.hdfs.protocol;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.util.Date;
/*     */ import org.apache.hadoop.io.Text;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.WritableFactories;
/*     */ import org.apache.hadoop.io.WritableFactory;
/*     */ import org.apache.hadoop.io.WritableUtils;
/*     */ import org.apache.hadoop.net.Node;
/*     */ import org.apache.hadoop.net.NodeBase;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ public class DatanodeInfo extends DatanodeID
/*     */   implements Node
/*     */ {
/*     */   protected long capacity;
/*     */   protected long dfsUsed;
/*     */   protected long remaining;
/*     */   protected long lastUpdate;
/*     */   protected int xceiverCount;
/*  46 */   protected String location = "/default-rack";
/*     */ 
/*  51 */   protected String hostName = null;
/*     */   protected AdminStates adminState;
/*     */   private int level;
/*     */   private Node parent;
/*     */ 
/*     */   public DatanodeInfo()
/*     */   {
/*  60 */     this.adminState = null;
/*     */   }
/*     */ 
/*     */   public DatanodeInfo(DatanodeInfo from) {
/*  64 */     super(from);
/*  65 */     this.capacity = from.getCapacity();
/*  66 */     this.dfsUsed = from.getDfsUsed();
/*  67 */     this.remaining = from.getRemaining();
/*  68 */     this.lastUpdate = from.getLastUpdate();
/*  69 */     this.xceiverCount = from.getXceiverCount();
/*  70 */     this.location = from.getNetworkLocation();
/*  71 */     this.adminState = from.adminState;
/*  72 */     this.hostName = from.hostName;
/*     */   }
/*     */ 
/*     */   public DatanodeInfo(DatanodeID nodeID) {
/*  76 */     super(nodeID);
/*  77 */     this.capacity = 0L;
/*  78 */     this.dfsUsed = 0L;
/*  79 */     this.remaining = 0L;
/*  80 */     this.lastUpdate = 0L;
/*  81 */     this.xceiverCount = 0;
/*  82 */     this.adminState = null;
/*     */   }
/*     */ 
/*     */   protected DatanodeInfo(DatanodeID nodeID, String location, String hostName) {
/*  86 */     this(nodeID);
/*  87 */     this.location = location;
/*  88 */     this.hostName = hostName;
/*     */   }
/*     */ 
/*     */   public DatanodeInfo(String name, String storageID, int infoPort, int ipcPort, long capacity, long dfsUsed, long remaining, long lastUpdate, int xceiverCount, String networkLocation, String hostName, AdminStates adminState)
/*     */   {
/*  98 */     super(name, storageID, infoPort, ipcPort);
/*     */ 
/* 100 */     this.capacity = capacity;
/* 101 */     this.dfsUsed = dfsUsed;
/* 102 */     this.remaining = remaining;
/* 103 */     this.lastUpdate = lastUpdate;
/* 104 */     this.xceiverCount = xceiverCount;
/* 105 */     this.location = networkLocation;
/* 106 */     this.hostName = hostName;
/* 107 */     this.adminState = adminState;
/*     */   }
/*     */ 
/*     */   public long getCapacity() {
/* 111 */     return this.capacity;
/*     */   }
/*     */   public long getDfsUsed() {
/* 114 */     return this.dfsUsed;
/*     */   }
/*     */ 
/*     */   public long getNonDfsUsed() {
/* 118 */     long nonDFSUsed = this.capacity - this.dfsUsed - this.remaining;
/* 119 */     return nonDFSUsed < 0L ? 0L : nonDFSUsed;
/*     */   }
/*     */ 
/*     */   public float getDfsUsedPercent()
/*     */   {
/* 124 */     if (this.capacity <= 0L) {
/* 125 */       return 100.0F;
/*     */     }
/*     */ 
/* 128 */     return (float)this.dfsUsed * 100.0F / (float)this.capacity;
/*     */   }
/*     */ 
/*     */   public long getRemaining() {
/* 132 */     return this.remaining;
/*     */   }
/*     */ 
/*     */   public float getRemainingPercent() {
/* 136 */     if (this.capacity <= 0L) {
/* 137 */       return 0.0F;
/*     */     }
/*     */ 
/* 140 */     return (float)this.remaining * 100.0F / (float)this.capacity;
/*     */   }
/*     */ 
/*     */   public long getLastUpdate() {
/* 144 */     return this.lastUpdate;
/*     */   }
/*     */   public int getXceiverCount() {
/* 147 */     return this.xceiverCount;
/*     */   }
/*     */ 
/*     */   public void setCapacity(long capacity) {
/* 151 */     this.capacity = capacity;
/*     */   }
/*     */ 
/*     */   public void setRemaining(long remaining)
/*     */   {
/* 156 */     this.remaining = remaining;
/*     */   }
/*     */ 
/*     */   public void setLastUpdate(long lastUpdate)
/*     */   {
/* 161 */     this.lastUpdate = lastUpdate;
/*     */   }
/*     */ 
/*     */   public void setXceiverCount(int xceiverCount)
/*     */   {
/* 166 */     this.xceiverCount = xceiverCount;
/*     */   }
/*     */ 
/*     */   public synchronized String getNetworkLocation() {
/* 170 */     return this.location;
/*     */   }
/*     */ 
/*     */   public synchronized void setNetworkLocation(String location) {
/* 174 */     this.location = NodeBase.normalize(location);
/*     */   }
/*     */ 
/*     */   public String getHostName() {
/* 178 */     return (this.hostName == null) || (this.hostName.length() == 0) ? getHost() : this.hostName;
/*     */   }
/*     */ 
/*     */   public void setHostName(String host) {
/* 182 */     this.hostName = host;
/*     */   }
/*     */ 
/*     */   public String getName(boolean useHostname)
/*     */   {
/* 187 */     return useHostname ? getHostName() + ":" + getPort() : getName();
/*     */   }
/*     */ 
/*     */   public String getNameWithIpcPort(boolean useHostname)
/*     */   {
/* 194 */     return getHost() + ":" + getIpcPort();
/*     */   }
/*     */ 
/*     */   public String getDatanodeReport()
/*     */   {
/* 200 */     StringBuffer buffer = new StringBuffer();
/* 201 */     long c = getCapacity();
/* 202 */     long r = getRemaining();
/* 203 */     long u = getDfsUsed();
/* 204 */     long nonDFSUsed = getNonDfsUsed();
/* 205 */     float usedPercent = getDfsUsedPercent();
/* 206 */     float remainingPercent = getRemainingPercent();
/*     */ 
/* 208 */     buffer.append("Name: " + this.name + "\n");
/* 209 */     if (!"/default-rack".equals(this.location)) {
/* 210 */       buffer.append("Rack: " + this.location + "\n");
/*     */     }
/* 212 */     buffer.append("Decommission Status : ");
/* 213 */     if (isDecommissioned())
/* 214 */       buffer.append("Decommissioned\n");
/* 215 */     else if (isDecommissionInProgress())
/* 216 */       buffer.append("Decommission in progress\n");
/*     */     else {
/* 218 */       buffer.append("Normal\n");
/*     */     }
/* 220 */     buffer.append("Configured Capacity: " + c + " (" + StringUtils.byteDesc(c) + ")" + "\n");
/* 221 */     buffer.append("DFS Used: " + u + " (" + StringUtils.byteDesc(u) + ")" + "\n");
/* 222 */     buffer.append("Non DFS Used: " + nonDFSUsed + " (" + StringUtils.byteDesc(nonDFSUsed) + ")" + "\n");
/* 223 */     buffer.append("DFS Remaining: " + r + "(" + StringUtils.byteDesc(r) + ")" + "\n");
/* 224 */     buffer.append("DFS Used%: " + StringUtils.limitDecimalTo2(usedPercent) + "%\n");
/* 225 */     buffer.append("DFS Remaining%: " + StringUtils.limitDecimalTo2(remainingPercent) + "%\n");
/* 226 */     buffer.append("Last contact: " + new Date(this.lastUpdate) + "\n");
/* 227 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public String dumpDatanode()
/*     */   {
/* 232 */     StringBuffer buffer = new StringBuffer();
/* 233 */     long c = getCapacity();
/* 234 */     long r = getRemaining();
/* 235 */     long u = getDfsUsed();
/* 236 */     buffer.append(this.name);
/* 237 */     if (!"/default-rack".equals(this.location)) {
/* 238 */       buffer.append(" " + this.location);
/*     */     }
/* 240 */     if (isDecommissioned())
/* 241 */       buffer.append(" DD");
/* 242 */     else if (isDecommissionInProgress())
/* 243 */       buffer.append(" DP");
/*     */     else {
/* 245 */       buffer.append(" IN");
/*     */     }
/* 247 */     buffer.append(" " + c + "(" + StringUtils.byteDesc(c) + ")");
/* 248 */     buffer.append(" " + u + "(" + StringUtils.byteDesc(u) + ")");
/* 249 */     buffer.append(" " + StringUtils.limitDecimalTo2(1.0D * u / c * 100.0D) + "%");
/* 250 */     buffer.append(" " + r + "(" + StringUtils.byteDesc(r) + ")");
/* 251 */     buffer.append(" " + new Date(this.lastUpdate));
/* 252 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public void startDecommission()
/*     */   {
/* 260 */     this.adminState = AdminStates.DECOMMISSION_INPROGRESS;
/*     */   }
/*     */ 
/*     */   public void stopDecommission()
/*     */   {
/* 268 */     this.adminState = null;
/*     */   }
/*     */ 
/*     */   public boolean isDecommissionInProgress()
/*     */   {
/* 275 */     if (this.adminState == AdminStates.DECOMMISSION_INPROGRESS) {
/* 276 */       return true;
/*     */     }
/* 278 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isDecommissioned()
/*     */   {
/* 285 */     if (this.adminState == AdminStates.DECOMMISSIONED) {
/* 286 */       return true;
/*     */     }
/* 288 */     return false;
/*     */   }
/*     */ 
/*     */   public void setDecommissioned()
/*     */   {
/* 295 */     this.adminState = AdminStates.DECOMMISSIONED;
/*     */   }
/*     */ 
/*     */   public boolean isStale(long staleInterval)
/*     */   {
/* 312 */     return System.currentTimeMillis() - this.lastUpdate >= staleInterval;
/*     */   }
/*     */ 
/*     */   public AdminStates getAdminState()
/*     */   {
/* 319 */     if (this.adminState == null) {
/* 320 */       return AdminStates.NORMAL;
/*     */     }
/* 322 */     return this.adminState;
/*     */   }
/*     */ 
/*     */   protected void setAdminState(AdminStates newState)
/*     */   {
/* 329 */     if (newState == AdminStates.NORMAL) {
/* 330 */       this.adminState = null;
/*     */     }
/*     */     else
/* 333 */       this.adminState = newState;
/*     */   }
/*     */ 
/*     */   public Node getParent()
/*     */   {
/* 341 */     return this.parent; } 
/* 342 */   public void setParent(Node parent) { this.parent = parent; }
/*     */ 
/*     */ 
/*     */   public int getLevel()
/*     */   {
/* 347 */     return this.level; } 
/* 348 */   public void setLevel(int level) { this.level = level; }
/*     */ 
/*     */ 
/*     */   public void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/* 363 */     super.write(out);
/*     */ 
/* 366 */     out.writeShort(this.ipcPort);
/*     */ 
/* 368 */     out.writeLong(this.capacity);
/* 369 */     out.writeLong(this.dfsUsed);
/* 370 */     out.writeLong(this.remaining);
/* 371 */     out.writeLong(this.lastUpdate);
/* 372 */     out.writeInt(this.xceiverCount);
/* 373 */     Text.writeString(out, this.location);
/* 374 */     Text.writeString(out, this.hostName == null ? "" : this.hostName);
/* 375 */     WritableUtils.writeEnum(out, getAdminState());
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException
/*     */   {
/* 380 */     super.readFields(in);
/*     */ 
/* 383 */     this.ipcPort = (in.readShort() & 0xFFFF);
/*     */ 
/* 385 */     this.capacity = in.readLong();
/* 386 */     this.dfsUsed = in.readLong();
/* 387 */     this.remaining = in.readLong();
/* 388 */     this.lastUpdate = in.readLong();
/* 389 */     this.xceiverCount = in.readInt();
/* 390 */     this.location = Text.readString(in);
/* 391 */     this.hostName = Text.readString(in);
/* 392 */     setAdminState((AdminStates)WritableUtils.readEnum(in, AdminStates.class));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 354 */     WritableFactories.setFactory(DatanodeInfo.class, new WritableFactory()
/*     */     {
/*     */       public Writable newInstance() {
/* 357 */         return new DatanodeInfo();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public static enum AdminStates
/*     */   {
/*  54 */     NORMAL, DECOMMISSION_INPROGRESS, DECOMMISSIONED;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.protocol.DatanodeInfo
 * JD-Core Version:    0.6.1
 */
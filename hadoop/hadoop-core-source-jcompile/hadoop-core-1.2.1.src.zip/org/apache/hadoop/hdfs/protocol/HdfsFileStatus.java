/*     */ package org.apache.hadoop.hdfs.protocol;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.hdfs.DFSUtil;
/*     */ import org.apache.hadoop.io.Text;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.WritableFactories;
/*     */ import org.apache.hadoop.io.WritableFactory;
/*     */ 
/*     */ public class HdfsFileStatus
/*     */   implements Writable
/*     */ {
/*     */   private byte[] path;
/*     */   private long length;
/*     */   private boolean isdir;
/*     */   private short block_replication;
/*     */   private long blocksize;
/*     */   private long modification_time;
/*     */   private long access_time;
/*     */   private FsPermission permission;
/*     */   private String owner;
/*     */   private String group;
/*  54 */   public static final byte[] EMPTY_NAME = new byte[0];
/*     */ 
/*     */   public HdfsFileStatus()
/*     */   {
/*  59 */     this(0L, false, 0, 0L, 0L, 0L, null, null, null, null);
/*     */   }
/*     */ 
/*     */   public HdfsFileStatus(long length, boolean isdir, int block_replication, long blocksize, long modification_time, long access_time, FsPermission permission, String owner, String group, byte[] path)
/*     */   {
/*  78 */     this.length = length;
/*  79 */     this.isdir = isdir;
/*  80 */     this.block_replication = (short)block_replication;
/*  81 */     this.blocksize = blocksize;
/*  82 */     this.modification_time = modification_time;
/*  83 */     this.access_time = access_time;
/*  84 */     this.permission = (permission == null ? FsPermission.getDefault() : permission);
/*     */ 
/*  86 */     this.owner = (owner == null ? "" : owner);
/*  87 */     this.group = (group == null ? "" : group);
/*  88 */     this.path = path;
/*     */   }
/*     */ 
/*     */   public final long getLen()
/*     */   {
/*  96 */     return this.length;
/*     */   }
/*     */ 
/*     */   public final boolean isDir()
/*     */   {
/* 104 */     return this.isdir;
/*     */   }
/*     */ 
/*     */   public final long getBlockSize()
/*     */   {
/* 112 */     return this.blocksize;
/*     */   }
/*     */ 
/*     */   public final short getReplication()
/*     */   {
/* 120 */     return this.block_replication;
/*     */   }
/*     */ 
/*     */   public final long getModificationTime()
/*     */   {
/* 128 */     return this.modification_time;
/*     */   }
/*     */ 
/*     */   public final long getAccessTime()
/*     */   {
/* 136 */     return this.access_time;
/*     */   }
/*     */ 
/*     */   public final FsPermission getPermission()
/*     */   {
/* 144 */     return this.permission;
/*     */   }
/*     */ 
/*     */   public final String getOwner()
/*     */   {
/* 152 */     return this.owner;
/*     */   }
/*     */ 
/*     */   public final String getGroup()
/*     */   {
/* 160 */     return this.group;
/*     */   }
/*     */ 
/*     */   public final boolean isEmptyLocalName()
/*     */   {
/* 168 */     return this.path.length == 0;
/*     */   }
/*     */ 
/*     */   public final String getLocalName()
/*     */   {
/* 176 */     return DFSUtil.bytes2String(this.path);
/*     */   }
/*     */ 
/*     */   public final byte[] getLocalNameInBytes()
/*     */   {
/* 184 */     return this.path;
/*     */   }
/*     */ 
/*     */   public final String getFullName(String parent)
/*     */   {
/* 193 */     if (isEmptyLocalName()) {
/* 194 */       return parent;
/*     */     }
/*     */ 
/* 197 */     StringBuilder fullName = new StringBuilder(parent);
/* 198 */     if (!parent.endsWith("/")) {
/* 199 */       fullName.append("/");
/*     */     }
/* 201 */     fullName.append(getLocalName());
/* 202 */     return fullName.toString();
/*     */   }
/*     */ 
/*     */   public final Path getFullPath(Path parent)
/*     */   {
/* 211 */     if (isEmptyLocalName()) {
/* 212 */       return parent;
/*     */     }
/*     */ 
/* 215 */     return new Path(parent, getLocalName());
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/* 222 */     out.writeInt(this.path.length);
/* 223 */     out.write(this.path);
/* 224 */     out.writeLong(this.length);
/* 225 */     out.writeBoolean(this.isdir);
/* 226 */     out.writeShort(this.block_replication);
/* 227 */     out.writeLong(this.blocksize);
/* 228 */     out.writeLong(this.modification_time);
/* 229 */     out.writeLong(this.access_time);
/* 230 */     this.permission.write(out);
/* 231 */     Text.writeString(out, this.owner);
/* 232 */     Text.writeString(out, this.group);
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException {
/* 236 */     int numOfBytes = in.readInt();
/* 237 */     if (numOfBytes == 0) {
/* 238 */       this.path = EMPTY_NAME;
/*     */     } else {
/* 240 */       this.path = new byte[numOfBytes];
/* 241 */       in.readFully(this.path);
/*     */     }
/* 243 */     this.length = in.readLong();
/* 244 */     this.isdir = in.readBoolean();
/* 245 */     this.block_replication = in.readShort();
/* 246 */     this.blocksize = in.readLong();
/* 247 */     this.modification_time = in.readLong();
/* 248 */     this.access_time = in.readLong();
/* 249 */     this.permission.readFields(in);
/* 250 */     this.owner = Text.readString(in);
/* 251 */     this.group = Text.readString(in);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  36 */     WritableFactories.setFactory(HdfsFileStatus.class, new WritableFactory()
/*     */     {
/*     */       public Writable newInstance() {
/*  39 */         return new HdfsFileStatus();
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.protocol.HdfsFileStatus
 * JD-Core Version:    0.6.1
 */
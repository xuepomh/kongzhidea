/*     */ package org.apache.hadoop.hdfs.protocol;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ 
/*     */ public abstract interface DataTransferProtocol
/*     */ {
/*     */   public static final int DATA_TRANSFER_VERSION = 17;
/*     */   public static final byte OP_WRITE_BLOCK = 80;
/*     */   public static final byte OP_READ_BLOCK = 81;
/*     */ 
/*     */   @Deprecated
/*     */   public static final byte OP_READ_METADATA = 82;
/*     */   public static final byte OP_REPLACE_BLOCK = 83;
/*     */   public static final byte OP_COPY_BLOCK = 84;
/*     */   public static final byte OP_BLOCK_CHECKSUM = 85;
/*     */   public static final int OP_STATUS_SUCCESS = 0;
/*     */   public static final int OP_STATUS_ERROR = 1;
/*     */   public static final int OP_STATUS_ERROR_CHECKSUM = 2;
/*     */   public static final int OP_STATUS_ERROR_INVALID = 3;
/*     */   public static final int OP_STATUS_ERROR_EXISTS = 4;
/*     */   public static final int OP_STATUS_ERROR_ACCESS_TOKEN = 5;
/*     */   public static final int OP_STATUS_CHECKSUM_OK = 6;
/*     */ 
/*     */   public static class PipelineAck
/*     */     implements Writable
/*     */   {
/*     */     private long seqno;
/*     */     private short[] replies;
/*     */     public static final long UNKOWN_SEQNO = -2L;
/*     */ 
/*     */     public PipelineAck()
/*     */     {
/*     */     }
/*     */ 
/*     */     public PipelineAck(long seqno, short[] replies)
/*     */     {
/*  80 */       this.seqno = seqno;
/*  81 */       this.replies = replies;
/*     */     }
/*     */ 
/*     */     public long getSeqno()
/*     */     {
/*  89 */       return this.seqno;
/*     */     }
/*     */ 
/*     */     public short getNumOfReplies()
/*     */     {
/*  97 */       return (short)this.replies.length;
/*     */     }
/*     */ 
/*     */     public short getReply(int i)
/*     */     {
/* 105 */       return this.replies[i];
/*     */     }
/*     */ 
/*     */     public boolean isSuccess()
/*     */     {
/* 113 */       for (short reply : this.replies) {
/* 114 */         if (reply != 0) {
/* 115 */           return false;
/*     */         }
/*     */       }
/* 118 */       return true;
/*     */     }
/*     */ 
/*     */     public void readFields(DataInput in)
/*     */       throws IOException
/*     */     {
/* 124 */       this.seqno = in.readLong();
/* 125 */       short numOfReplies = in.readShort();
/* 126 */       this.replies = new short[numOfReplies];
/* 127 */       for (int i = 0; i < numOfReplies; i++)
/* 128 */         this.replies[i] = in.readShort();
/*     */     }
/*     */ 
/*     */     public void write(DataOutput out)
/*     */       throws IOException
/*     */     {
/* 135 */       out.writeLong(this.seqno);
/* 136 */       out.writeShort((short)this.replies.length);
/* 137 */       for (short reply : this.replies)
/* 138 */         out.writeShort(reply);
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 144 */       StringBuilder ack = new StringBuilder("Replies for seqno ");
/* 145 */       ack.append(this.seqno).append(" are");
/* 146 */       for (short reply : this.replies) {
/* 147 */         ack.append(" ");
/* 148 */         if (reply == 0)
/* 149 */           ack.append("SUCCESS");
/*     */         else {
/* 151 */           ack.append("FAILED");
/*     */         }
/*     */       }
/* 154 */       return ack.toString();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.protocol.DataTransferProtocol
 * JD-Core Version:    0.6.1
 */
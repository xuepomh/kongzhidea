/*     */ package org.apache.hadoop.hdfs.protocol;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.hdfs.security.token.block.BlockTokenIdentifier;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.WritableFactories;
/*     */ import org.apache.hadoop.io.WritableFactory;
/*     */ import org.apache.hadoop.security.token.Token;
/*     */ 
/*     */ public class LocatedBlock
/*     */   implements Writable
/*     */ {
/*     */   private Block b;
/*     */   private long offset;
/*     */   private DatanodeInfo[] locs;
/*     */   private boolean corrupt;
/*  48 */   private Token<BlockTokenIdentifier> blockToken = new Token();
/*     */ 
/*     */   public LocatedBlock()
/*     */   {
/*  53 */     this(new Block(), new DatanodeInfo[0], 0L, false);
/*     */   }
/*     */ 
/*     */   public LocatedBlock(Block b, DatanodeInfo[] locs)
/*     */   {
/*  59 */     this(b, locs, -1L, false);
/*     */   }
/*     */ 
/*     */   public LocatedBlock(Block b, DatanodeInfo[] locs, long startOffset)
/*     */   {
/*  65 */     this(b, locs, startOffset, false);
/*     */   }
/*     */ 
/*     */   public LocatedBlock(Block b, DatanodeInfo[] locs, long startOffset, boolean corrupt)
/*     */   {
/*  72 */     this.b = b;
/*  73 */     this.offset = startOffset;
/*  74 */     this.corrupt = corrupt;
/*  75 */     if (locs == null)
/*  76 */       this.locs = new DatanodeInfo[0];
/*     */     else
/*  78 */       this.locs = locs;
/*     */   }
/*     */ 
/*     */   public Token<BlockTokenIdentifier> getBlockToken()
/*     */   {
/*  83 */     return this.blockToken;
/*     */   }
/*     */ 
/*     */   public void setBlockToken(Token<BlockTokenIdentifier> token) {
/*  87 */     this.blockToken = token;
/*     */   }
/*     */ 
/*     */   public Block getBlock()
/*     */   {
/*  93 */     return this.b;
/*     */   }
/*     */ 
/*     */   public DatanodeInfo[] getLocations()
/*     */   {
/*  99 */     return this.locs;
/*     */   }
/*     */ 
/*     */   public long getStartOffset() {
/* 103 */     return this.offset;
/*     */   }
/*     */ 
/*     */   public long getBlockSize() {
/* 107 */     return this.b.getNumBytes();
/*     */   }
/*     */ 
/*     */   void setStartOffset(long value) {
/* 111 */     this.offset = value;
/*     */   }
/*     */ 
/*     */   void setCorrupt(boolean corrupt) {
/* 115 */     this.corrupt = corrupt;
/*     */   }
/*     */ 
/*     */   public boolean isCorrupt() {
/* 119 */     return this.corrupt;
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/* 126 */     this.blockToken.write(out);
/* 127 */     out.writeBoolean(this.corrupt);
/* 128 */     out.writeLong(this.offset);
/* 129 */     this.b.write(out);
/* 130 */     out.writeInt(this.locs.length);
/* 131 */     for (int i = 0; i < this.locs.length; i++)
/* 132 */       this.locs[i].write(out);
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException
/*     */   {
/* 137 */     this.blockToken.readFields(in);
/* 138 */     this.corrupt = in.readBoolean();
/* 139 */     this.offset = in.readLong();
/* 140 */     this.b = new Block();
/* 141 */     this.b.readFields(in);
/* 142 */     int count = in.readInt();
/* 143 */     this.locs = new DatanodeInfo[count];
/* 144 */     for (int i = 0; i < this.locs.length; i++) {
/* 145 */       this.locs[i] = new DatanodeInfo();
/* 146 */       this.locs[i].readFields(in);
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  34 */     WritableFactories.setFactory(LocatedBlock.class, new WritableFactory()
/*     */     {
/*     */       public Writable newInstance() {
/*  37 */         return new LocatedBlock();
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.protocol.LocatedBlock
 * JD-Core Version:    0.6.1
 */
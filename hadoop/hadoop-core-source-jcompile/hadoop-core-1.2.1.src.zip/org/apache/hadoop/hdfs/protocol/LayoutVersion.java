/*     */ package org.apache.hadoop.hdfs.protocol;
/*     */ 
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.hadoop.classification.InterfaceAudience.Private;
/*     */ 
/*     */ @InterfaceAudience.Private
/*     */ public class LayoutVersion
/*     */ {
/*     */   public static final int BUGFIX_HDFS_2991_VERSION = -40;
/* 156 */   static final Map<Integer, EnumSet<Feature>> map = new HashMap();
/*     */ 
/*     */   private static void initMap()
/*     */   {
/* 171 */     for (Feature f : Feature.values()) {
/* 172 */       EnumSet ancestorSet = (EnumSet)map.get(Integer.valueOf(f.ancestorLV));
/* 173 */       if (ancestorSet == null) {
/* 174 */         ancestorSet = EnumSet.noneOf(Feature.class);
/* 175 */         map.put(Integer.valueOf(f.ancestorLV), ancestorSet);
/*     */       }
/* 177 */       EnumSet featureSet = EnumSet.copyOf(ancestorSet);
/* 178 */       if (f.specialFeatures != null) {
/* 179 */         for (Feature specialFeature : f.specialFeatures) {
/* 180 */           featureSet.add(specialFeature);
/*     */         }
/*     */       }
/* 183 */       featureSet.add(f);
/* 184 */       map.put(Integer.valueOf(f.lv), featureSet);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String getString()
/*     */   {
/* 192 */     StringBuilder buf = new StringBuilder();
/* 193 */     buf.append("Feature List:\n");
/* 194 */     for (Feature f : Feature.values()) {
/* 195 */       buf.append(f).append(" introduced in layout version ").append(f.lv).append(" (").append(f.description).append(")\n");
/*     */     }
/*     */ 
/* 200 */     buf.append("\n\nLayoutVersion and supported features:\n");
/* 201 */     for (Feature f : Feature.values()) {
/* 202 */       buf.append(f.lv).append(": ").append(map.get(Integer.valueOf(f.lv))).append("\n");
/*     */     }
/*     */ 
/* 205 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   public static boolean supports(Feature f, int lv)
/*     */   {
/* 215 */     EnumSet set = (EnumSet)map.get(Integer.valueOf(lv));
/* 216 */     return (set != null) && (set.contains(f));
/*     */   }
/*     */ 
/*     */   public static int getCurrentLayoutVersion()
/*     */   {
/* 223 */     Feature[] values = Feature.values();
/* 224 */     for (int i = values.length - 1; i >= 0; i--) {
/* 225 */       if (!values[i].isReservedForOldRelease()) {
/* 226 */         return values[i].lv;
/*     */       }
/*     */     }
/* 229 */     throw new AssertionError("All layout versions are reserved.");
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 161 */     initMap();
/*     */   }
/*     */ 
/*     */   public static enum Feature
/*     */   {
/*  70 */     NAMESPACE_QUOTA(-16, "Support for namespace quotas"), 
/*  71 */     FILE_ACCESS_TIME(-17, "Support for access time on files"), 
/*  72 */     DISKSPACE_QUOTA(-18, "Support for disk space quotas"), 
/*  73 */     STICKY_BIT(-19, "Support for sticky bits"), 
/*  74 */     APPEND_RBW_DIR(-20, "Datanode has \"rbw\" subdirectory for append"), 
/*  75 */     ATOMIC_RENAME(-21, "Support for atomic rename"), 
/*  76 */     CONCAT(-22, "Support for concat operation"), 
/*  77 */     SYMLINKS(-23, "Support for symbolic links"), 
/*  78 */     DELEGATION_TOKEN(-24, "Support for delegation tokens for security"), 
/*  79 */     FSIMAGE_COMPRESSION(-25, "Support for fsimage compression"), 
/*  80 */     FSIMAGE_CHECKSUM(-26, "Support checksum for fsimage"), 
/*  81 */     REMOVE_REL13_DISK_LAYOUT_SUPPORT(-27, "Remove support for 0.13 disk layout"), 
/*  82 */     EDITS_CHESKUM(-28, "Support checksum for editlog"), 
/*  83 */     UNUSED(-29, "Skipped version"), 
/*  84 */     FSIMAGE_NAME_OPTIMIZATION(-30, "Store only last part of path in fsimage"), 
/*  85 */     RESERVED_REL20_203(-31, -19, "Reserved for release 0.20.203", true, new Feature[] { DELEGATION_TOKEN }), 
/*     */ 
/*  87 */     RESERVED_REL20_204(-32, -31, "Reserved for release 0.20.204", true, new Feature[0]), 
/*  88 */     RESERVED_REL22(-33, -27, "Reserved for release 0.22", true, new Feature[0]), 
/*  89 */     RESERVED_REL23(-34, -30, "Reserved for release 0.23", true, new Feature[0]), 
/*     */ 
/*  91 */     RESERVED_REL1_2_0(-41, -32, "Reserved for release 1.2.0", true, new Feature[] { CONCAT });
/*     */ 
/*     */     final int lv;
/*     */     final int ancestorLV;
/*     */     final String description;
/*     */     final boolean reserved;
/*     */     final Feature[] specialFeatures;
/*     */ 
/*     */     private Feature(int lv, String description)
/*     */     {
/* 105 */       this(lv, lv + 1, description, false, new Feature[0]);
/*     */     }
/*     */ 
/*     */     private Feature(int lv, int ancestorLV, String description, boolean reserved, Feature[] features)
/*     */     {
/* 119 */       this.lv = lv;
/* 120 */       this.ancestorLV = ancestorLV;
/* 121 */       this.description = description;
/* 122 */       this.reserved = reserved;
/* 123 */       this.specialFeatures = features;
/*     */     }
/*     */ 
/*     */     public int getLayoutVersion()
/*     */     {
/* 131 */       return this.lv;
/*     */     }
/*     */ 
/*     */     public int getAncestorLayoutVersion()
/*     */     {
/* 139 */       return this.ancestorLV;
/*     */     }
/*     */ 
/*     */     public String getDescription()
/*     */     {
/* 147 */       return this.description;
/*     */     }
/*     */ 
/*     */     public boolean isReservedForOldRelease() {
/* 151 */       return this.reserved;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.protocol.LayoutVersion
 * JD-Core Version:    0.6.1
 */
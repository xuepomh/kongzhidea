/*    */ package org.apache.hadoop.hdfs.protocol;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class UnregisteredDatanodeException extends IOException
/*    */ {
/*    */   public UnregisteredDatanodeException(DatanodeID nodeID)
/*    */   {
/* 32 */     super("Unregistered data node: " + nodeID.getName());
/*    */   }
/*    */ 
/*    */   public UnregisteredDatanodeException(DatanodeID nodeID, DatanodeInfo storedNode)
/*    */   {
/* 37 */     super("Data node " + nodeID.getName() + " is attempting to report storage ID " + nodeID.getStorageID() + ". Node " + storedNode.getName() + " is expected to serve this storage.");
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.protocol.UnregisteredDatanodeException
 * JD-Core Version:    0.6.1
 */
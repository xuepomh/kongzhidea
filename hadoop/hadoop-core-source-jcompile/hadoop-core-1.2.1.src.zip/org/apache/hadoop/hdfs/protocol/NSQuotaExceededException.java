/*    */ package org.apache.hadoop.hdfs.protocol;
/*    */ 
/*    */ public final class NSQuotaExceededException extends QuotaExceededException
/*    */ {
/*    */   protected static final long serialVersionUID = 1L;
/*    */ 
/*    */   public NSQuotaExceededException(String msg)
/*    */   {
/* 25 */     super(msg);
/*    */   }
/*    */ 
/*    */   public NSQuotaExceededException(long quota, long count) {
/* 29 */     super(quota, count);
/*    */   }
/*    */ 
/*    */   public String getMessage() {
/* 33 */     String msg = super.getMessage();
/* 34 */     if (msg == null) {
/* 35 */       return new StringBuilder().append("The NameSpace quota (directories and files)").append(this.pathName == null ? "" : new StringBuilder().append(" of directory ").append(this.pathName).toString()).append(" is exceeded: quota=").append(this.quota).append(" file count=").append(this.count).toString();
/*    */     }
/*    */ 
/* 39 */     return msg;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.protocol.NSQuotaExceededException
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs.protocol;
/*     */ 
/*     */ public class BlockListAsLongs
/*     */ {
/*     */   private static final int LONGS_PER_BLOCK = 3;
/*     */   private long[] blockList;
/*     */ 
/*     */   private static int index2BlockId(int index)
/*     */   {
/*  35 */     return index * 3;
/*     */   }
/*     */   private static int index2BlockLen(int index) {
/*  38 */     return index * 3 + 1;
/*     */   }
/*     */   private static int index2BlockGenStamp(int index) {
/*  41 */     return index * 3 + 2;
/*     */   }
/*     */ 
/*     */   public static long[] convertToArrayLongs(Block[] blockArray)
/*     */   {
/*  53 */     long[] blocksAsLongs = new long[blockArray.length * 3];
/*     */ 
/*  55 */     BlockListAsLongs bl = new BlockListAsLongs(blocksAsLongs);
/*  56 */     assert (bl.getNumberOfBlocks() == blockArray.length);
/*     */ 
/*  58 */     for (int i = 0; i < blockArray.length; i++) {
/*  59 */       bl.setBlock(i, blockArray[i]);
/*     */     }
/*  61 */     return blocksAsLongs;
/*     */   }
/*     */ 
/*     */   public BlockListAsLongs(long[] iBlockList)
/*     */   {
/*  69 */     if (iBlockList == null) {
/*  70 */       this.blockList = new long[0];
/*     */     } else {
/*  72 */       if (iBlockList.length % 3 != 0)
/*     */       {
/*  74 */         throw new IllegalArgumentException();
/*     */       }
/*  76 */       this.blockList = iBlockList;
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getNumberOfBlocks()
/*     */   {
/*  86 */     return this.blockList.length / 3;
/*     */   }
/*     */ 
/*     */   public long getBlockId(int index)
/*     */   {
/*  96 */     return this.blockList[index2BlockId(index)];
/*     */   }
/*     */ 
/*     */   public long getBlockLen(int index)
/*     */   {
/* 105 */     return this.blockList[index2BlockLen(index)];
/*     */   }
/*     */ 
/*     */   public long getBlockGenStamp(int index)
/*     */   {
/* 114 */     return this.blockList[index2BlockGenStamp(index)];
/*     */   }
/*     */ 
/*     */   void setBlock(int index, Block b)
/*     */   {
/* 123 */     this.blockList[index2BlockId(index)] = b.getBlockId();
/* 124 */     this.blockList[index2BlockLen(index)] = b.getNumBytes();
/* 125 */     this.blockList[index2BlockGenStamp(index)] = b.getGenerationStamp();
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.protocol.BlockListAsLongs
 * JD-Core Version:    0.6.1
 */
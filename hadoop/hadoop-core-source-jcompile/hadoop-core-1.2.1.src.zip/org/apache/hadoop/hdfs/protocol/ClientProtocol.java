package org.apache.hadoop.hdfs.protocol;

import java.io.FileNotFoundException;
import java.io.IOException;
import org.apache.hadoop.fs.ContentSummary;
import org.apache.hadoop.fs.permission.FsPermission;
import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenIdentifier;
import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenSelector;
import org.apache.hadoop.hdfs.server.common.UpgradeStatusReport;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.ipc.VersionedProtocol;
import org.apache.hadoop.security.AccessControlException;
import org.apache.hadoop.security.KerberosInfo;
import org.apache.hadoop.security.token.Token;
import org.apache.hadoop.security.token.TokenInfo;

@KerberosInfo(serverPrincipal="dfs.namenode.kerberos.principal")
@TokenInfo(DelegationTokenSelector.class)
public abstract interface ClientProtocol extends VersionedProtocol
{
  public static final long versionID = 61L;
  public static final int GET_STATS_CAPACITY_IDX = 0;
  public static final int GET_STATS_USED_IDX = 1;
  public static final int GET_STATS_REMAINING_IDX = 2;
  public static final int GET_STATS_UNDER_REPLICATED_IDX = 3;
  public static final int GET_STATS_CORRUPT_BLOCKS_IDX = 4;
  public static final int GET_STATS_MISSING_BLOCKS_IDX = 5;

  public abstract LocatedBlocks getBlockLocations(String paramString, long paramLong1, long paramLong2)
    throws IOException;

  public abstract void create(String paramString1, FsPermission paramFsPermission, String paramString2, boolean paramBoolean1, boolean paramBoolean2, short paramShort, long paramLong)
    throws IOException;

  public abstract void create(String paramString1, FsPermission paramFsPermission, String paramString2, boolean paramBoolean, short paramShort, long paramLong)
    throws IOException;

  public abstract LocatedBlock append(String paramString1, String paramString2)
    throws IOException;

  public abstract boolean recoverLease(String paramString1, String paramString2)
    throws IOException;

  public abstract boolean isFileClosed(String paramString)
    throws AccessControlException, FileNotFoundException, IOException;

  public abstract boolean setReplication(String paramString, short paramShort)
    throws IOException;

  public abstract void setPermission(String paramString, FsPermission paramFsPermission)
    throws IOException;

  public abstract void setOwner(String paramString1, String paramString2, String paramString3)
    throws IOException;

  public abstract void abandonBlock(Block paramBlock, String paramString1, String paramString2)
    throws IOException;

  /** @deprecated */
  public abstract LocatedBlock addBlock(String paramString1, String paramString2)
    throws IOException;

  public abstract LocatedBlock addBlock(String paramString1, String paramString2, DatanodeInfo[] paramArrayOfDatanodeInfo)
    throws IOException;

  public abstract boolean complete(String paramString1, String paramString2)
    throws IOException;

  public abstract void reportBadBlocks(LocatedBlock[] paramArrayOfLocatedBlock)
    throws IOException;

  public abstract boolean rename(String paramString1, String paramString2)
    throws IOException;

  public abstract void concat(String paramString, String[] paramArrayOfString)
    throws IOException;

  public abstract boolean delete(String paramString)
    throws IOException;

  public abstract boolean delete(String paramString, boolean paramBoolean)
    throws IOException;

  public abstract boolean mkdirs(String paramString, FsPermission paramFsPermission)
    throws IOException;

  public abstract DirectoryListing getListing(String paramString, byte[] paramArrayOfByte)
    throws IOException;

  public abstract void renewLease(String paramString)
    throws IOException;

  public abstract long[] getStats()
    throws IOException;

  public abstract DatanodeInfo[] getDatanodeReport(FSConstants.DatanodeReportType paramDatanodeReportType)
    throws IOException;

  public abstract long getPreferredBlockSize(String paramString)
    throws IOException;

  public abstract boolean setSafeMode(FSConstants.SafeModeAction paramSafeModeAction)
    throws IOException;

  public abstract void saveNamespace()
    throws IOException;

  public abstract void refreshNodes()
    throws IOException;

  public abstract void finalizeUpgrade()
    throws IOException;

  public abstract UpgradeStatusReport distributedUpgradeProgress(FSConstants.UpgradeAction paramUpgradeAction)
    throws IOException;

  public abstract void metaSave(String paramString)
    throws IOException;

  public abstract void setBalancerBandwidth(long paramLong)
    throws IOException;

  public abstract HdfsFileStatus getFileInfo(String paramString)
    throws IOException;

  public abstract ContentSummary getContentSummary(String paramString)
    throws IOException;

  public abstract void setQuota(String paramString, long paramLong1, long paramLong2)
    throws IOException;

  public abstract void fsync(String paramString1, String paramString2)
    throws IOException;

  public abstract void setTimes(String paramString, long paramLong1, long paramLong2)
    throws IOException;

  public abstract Token<DelegationTokenIdentifier> getDelegationToken(Text paramText)
    throws IOException;

  public abstract long renewDelegationToken(Token<DelegationTokenIdentifier> paramToken)
    throws IOException;

  public abstract void cancelDelegationToken(Token<DelegationTokenIdentifier> paramToken)
    throws IOException;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.protocol.ClientProtocol
 * JD-Core Version:    0.6.1
 */
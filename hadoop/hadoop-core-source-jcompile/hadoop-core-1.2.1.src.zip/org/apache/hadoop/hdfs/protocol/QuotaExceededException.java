/*    */ package org.apache.hadoop.hdfs.protocol;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class QuotaExceededException extends IOException
/*    */ {
/*    */   protected static final long serialVersionUID = 1L;
/* 37 */   protected String pathName = null;
/*    */   protected long quota;
/*    */   protected long count;
/*    */ 
/*    */   protected QuotaExceededException(String msg)
/*    */   {
/* 42 */     super(msg);
/*    */   }
/*    */ 
/*    */   protected QuotaExceededException(long quota, long count) {
/* 46 */     this.quota = quota;
/* 47 */     this.count = count;
/*    */   }
/*    */ 
/*    */   public void setPathName(String path) {
/* 51 */     this.pathName = path;
/*    */   }
/*    */ 
/*    */   public String getMessage() {
/* 55 */     return super.getMessage();
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.protocol.QuotaExceededException
 * JD-Core Version:    0.6.1
 */
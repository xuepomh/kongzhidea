/*     */ package org.apache.hadoop.hdfs.protocol;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.hdfs.server.common.GenerationStamp;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.WritableFactories;
/*     */ import org.apache.hadoop.io.WritableFactory;
/*     */ 
/*     */ public class Block
/*     */   implements Writable, Comparable<Block>
/*     */ {
/*     */   public static final long GRANDFATHER_GENERATION_STAMP = 0L;
/*     */   private long blockId;
/*     */   private long numBytes;
/*     */   private long generationStamp;
/*     */ 
/*     */   public static boolean isBlockFilename(File f)
/*     */   {
/*  47 */     String name = f.getName();
/*  48 */     if ((name.startsWith("blk_")) && (name.indexOf('.') < 0))
/*     */     {
/*  50 */       return true;
/*     */     }
/*  52 */     return false;
/*     */   }
/*     */ 
/*     */   static long filename2id(String name)
/*     */   {
/*  57 */     return Long.parseLong(name.substring("blk_".length()));
/*     */   }
/*     */ 
/*     */   public Block()
/*     */   {
/*  64 */     this(0L, 0L, 0L);
/*     */   }
/*     */   public Block(long blkid, long len, long generationStamp) {
/*  67 */     set(blkid, len, generationStamp);
/*     */   }
/*     */   public Block(long blkid) {
/*  70 */     this(blkid, 0L, 1L);
/*     */   }
/*  72 */   public Block(Block blk) { this(blk.blockId, blk.numBytes, blk.generationStamp); }
/*     */ 
/*     */ 
/*     */   public Block(File f, long len, long genstamp)
/*     */   {
/*  78 */     this(filename2id(f.getName()), len, genstamp);
/*     */   }
/*     */ 
/*     */   public void set(long blkid, long len, long genStamp) {
/*  82 */     this.blockId = blkid;
/*  83 */     this.numBytes = len;
/*  84 */     this.generationStamp = genStamp;
/*     */   }
/*     */ 
/*     */   public long getBlockId()
/*     */   {
/*  89 */     return this.blockId;
/*     */   }
/*     */ 
/*     */   public void setBlockId(long bid) {
/*  93 */     this.blockId = bid;
/*     */   }
/*     */ 
/*     */   public String getBlockName()
/*     */   {
/*  99 */     return "blk_" + String.valueOf(this.blockId);
/*     */   }
/*     */ 
/*     */   public long getNumBytes()
/*     */   {
/* 105 */     return this.numBytes;
/*     */   }
/*     */   public void setNumBytes(long len) {
/* 108 */     this.numBytes = len;
/*     */   }
/*     */ 
/*     */   public long getGenerationStamp() {
/* 112 */     return this.generationStamp;
/*     */   }
/*     */ 
/*     */   public void setGenerationStamp(long stamp) {
/* 116 */     this.generationStamp = stamp;
/*     */   }
/*     */ 
/*     */   public Block getWithWildcardGS() {
/* 120 */     return new Block(this.blockId, this.numBytes, 1L);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 126 */     return getBlockName() + "_" + getGenerationStamp();
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/* 133 */     out.writeLong(this.blockId);
/* 134 */     out.writeLong(this.numBytes);
/* 135 */     out.writeLong(this.generationStamp);
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException {
/* 139 */     this.blockId = in.readLong();
/* 140 */     this.numBytes = in.readLong();
/* 141 */     this.generationStamp = in.readLong();
/* 142 */     if (this.numBytes < 0L)
/* 143 */       throw new IOException("Unexpected block size: " + this.numBytes);
/*     */   }
/*     */ 
/*     */   static void validateGenerationStamp(long generationstamp)
/*     */   {
/* 151 */     if (generationstamp == 1L)
/* 152 */       throw new IllegalStateException("generationStamp (=" + generationstamp + ") == GenerationStamp.WILDCARD_STAMP");
/*     */   }
/*     */ 
/*     */   public int compareTo(Block b)
/*     */   {
/* 160 */     validateGenerationStamp(this.generationStamp);
/* 161 */     validateGenerationStamp(b.generationStamp);
/*     */ 
/* 163 */     if (this.blockId < b.blockId)
/* 164 */       return -1;
/* 165 */     if (this.blockId == b.blockId) {
/* 166 */       return GenerationStamp.compare(this.generationStamp, b.generationStamp);
/*     */     }
/* 168 */     return 1;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 174 */     if (!(o instanceof Block)) {
/* 175 */       return false;
/*     */     }
/* 177 */     Block that = (Block)o;
/*     */ 
/* 179 */     return (this.blockId == that.blockId) && (GenerationStamp.equalsWithWildcard(this.generationStamp, that.generationStamp));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 187 */     return 629 + (int)(this.blockId ^ this.blockId >>> 32);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  33 */     WritableFactories.setFactory(Block.class, new WritableFactory()
/*     */     {
/*     */       public Writable newInstance() {
/*  36 */         return new Block();
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.protocol.Block
 * JD-Core Version:    0.6.1
 */
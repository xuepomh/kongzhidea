/*     */ package org.apache.hadoop.hdfs.protocol;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.WritableFactories;
/*     */ import org.apache.hadoop.io.WritableFactory;
/*     */ 
/*     */ public class LocatedBlocks
/*     */   implements Writable
/*     */ {
/*     */   private long fileLength;
/*     */   private List<LocatedBlock> blocks;
/*     */   private boolean underConstruction;
/*     */ 
/*     */   LocatedBlocks()
/*     */   {
/*  41 */     this.fileLength = 0L;
/*  42 */     this.blocks = null;
/*  43 */     this.underConstruction = false;
/*     */   }
/*     */ 
/*     */   public LocatedBlocks(long flength, List<LocatedBlock> blks, boolean isUnderConstuction)
/*     */   {
/*  48 */     this.fileLength = flength;
/*  49 */     this.blocks = blks;
/*  50 */     this.underConstruction = isUnderConstuction;
/*     */   }
/*     */ 
/*     */   public List<LocatedBlock> getLocatedBlocks()
/*     */   {
/*  57 */     return this.blocks;
/*     */   }
/*     */ 
/*     */   public LocatedBlock get(int index)
/*     */   {
/*  64 */     return (LocatedBlock)this.blocks.get(index);
/*     */   }
/*     */ 
/*     */   public int locatedBlockCount()
/*     */   {
/*  71 */     return this.blocks == null ? 0 : this.blocks.size();
/*     */   }
/*     */ 
/*     */   public long getFileLength()
/*     */   {
/*  78 */     return this.fileLength;
/*     */   }
/*     */ 
/*     */   public boolean isUnderConstruction()
/*     */   {
/*  86 */     return this.underConstruction;
/*     */   }
/*     */ 
/*     */   public void setFileLength(long length)
/*     */   {
/*  93 */     this.fileLength = length;
/*     */   }
/*     */ 
/*     */   public int findBlock(long offset)
/*     */   {
/* 103 */     LocatedBlock key = new LocatedBlock();
/* 104 */     key.setStartOffset(offset);
/* 105 */     key.getBlock().setNumBytes(1L);
/* 106 */     Comparator comp = new Comparator()
/*     */     {
/*     */       public int compare(LocatedBlock a, LocatedBlock b)
/*     */       {
/* 110 */         long aBeg = a.getStartOffset();
/* 111 */         long bBeg = b.getStartOffset();
/* 112 */         long aEnd = aBeg + a.getBlockSize();
/* 113 */         long bEnd = bBeg + b.getBlockSize();
/* 114 */         if (((aBeg <= bBeg) && (bEnd <= aEnd)) || ((bBeg <= aBeg) && (aEnd <= bEnd)))
/*     */         {
/* 116 */           return 0;
/* 117 */         }if (aBeg < bBeg)
/* 118 */           return -1;
/* 119 */         return 1;
/*     */       }
/*     */     };
/* 122 */     return Collections.binarySearch(this.blocks, key, comp);
/*     */   }
/*     */ 
/*     */   public void insertRange(int blockIdx, List<LocatedBlock> newBlocks) {
/* 126 */     int oldIdx = blockIdx;
/* 127 */     int insStart = 0; int insEnd = 0;
/* 128 */     for (int newIdx = 0; (newIdx < newBlocks.size()) && (oldIdx < this.blocks.size()); 
/* 129 */       newIdx++) {
/* 130 */       long newOff = ((LocatedBlock)newBlocks.get(newIdx)).getStartOffset();
/* 131 */       long oldOff = ((LocatedBlock)this.blocks.get(oldIdx)).getStartOffset();
/* 132 */       if (newOff < oldOff) {
/* 133 */         insEnd++;
/* 134 */       } else if (newOff == oldOff)
/*     */       {
/* 136 */         this.blocks.set(oldIdx, newBlocks.get(newIdx));
/* 137 */         if (insStart < insEnd) {
/* 138 */           this.blocks.addAll(oldIdx, newBlocks.subList(insStart, insEnd));
/* 139 */           oldIdx += insEnd - insStart;
/*     */         }
/* 141 */         insStart = insEnd = newIdx + 1;
/* 142 */         oldIdx++;
/*     */       }
/* 144 */       else if (!$assertionsDisabled) { throw new AssertionError("List of LocatedBlock must be sorted by startOffset"); }
/*     */ 
/*     */     }
/* 147 */     insEnd = newBlocks.size();
/* 148 */     if (insStart < insEnd)
/* 149 */       this.blocks.addAll(oldIdx, newBlocks.subList(insStart, insEnd));
/*     */   }
/*     */ 
/*     */   public static int getInsertIndex(int binSearchResult)
/*     */   {
/* 154 */     return binSearchResult >= 0 ? binSearchResult : -(binSearchResult + 1);
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/* 169 */     out.writeLong(this.fileLength);
/* 170 */     out.writeBoolean(this.underConstruction);
/*     */ 
/* 172 */     int nrBlocks = locatedBlockCount();
/* 173 */     out.writeInt(nrBlocks);
/* 174 */     if (nrBlocks == 0) {
/* 175 */       return;
/*     */     }
/* 177 */     for (LocatedBlock blk : this.blocks)
/* 178 */       blk.write(out);
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException
/*     */   {
/* 183 */     this.fileLength = in.readLong();
/* 184 */     this.underConstruction = in.readBoolean();
/*     */ 
/* 186 */     int nrBlocks = in.readInt();
/* 187 */     this.blocks = new ArrayList(nrBlocks);
/* 188 */     for (int idx = 0; idx < nrBlocks; idx++) {
/* 189 */       LocatedBlock blk = new LocatedBlock();
/* 190 */       blk.readFields(in);
/* 191 */       this.blocks.add(blk);
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 161 */     WritableFactories.setFactory(LocatedBlocks.class, new WritableFactory()
/*     */     {
/*     */       public Writable newInstance() {
/* 164 */         return new LocatedBlocks();
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.protocol.LocatedBlocks
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.protocol;
/*    */ 
/*    */ import java.io.DataInput;
/*    */ import java.io.DataOutput;
/*    */ import java.io.IOException;
/*    */ import org.apache.hadoop.classification.InterfaceAudience.Private;
/*    */ import org.apache.hadoop.classification.InterfaceStability.Evolving;
/*    */ import org.apache.hadoop.io.Text;
/*    */ import org.apache.hadoop.io.Writable;
/*    */ import org.apache.hadoop.io.WritableFactories;
/*    */ import org.apache.hadoop.io.WritableFactory;
/*    */ 
/*    */ @InterfaceAudience.Private
/*    */ @InterfaceStability.Evolving
/*    */ public class BlockLocalPathInfo
/*    */   implements Writable
/*    */ {
/* 39 */   static final WritableFactory FACTORY = new WritableFactory() {
/* 40 */     public Writable newInstance() { return new BlockLocalPathInfo(); }
/*    */ 
/* 39 */   };
/*    */   private Block block;
/* 47 */   private String localBlockPath = "";
/* 48 */   private String localMetaPath = "";
/*    */ 
/*    */   public BlockLocalPathInfo()
/*    */   {
/*    */   }
/*    */ 
/*    */   public BlockLocalPathInfo(Block b, String file, String metafile)
/*    */   {
/* 59 */     this.block = b;
/* 60 */     this.localBlockPath = file;
/* 61 */     this.localMetaPath = metafile;
/*    */   }
/*    */ 
/*    */   public String getBlockPath()
/*    */   {
/* 68 */     return this.localBlockPath;
/*    */   }
/*    */ 
/*    */   public String getMetaPath()
/*    */   {
/* 74 */     return this.localMetaPath;
/*    */   }
/*    */ 
/*    */   public void write(DataOutput out) throws IOException {
/* 78 */     this.block.write(out);
/* 79 */     Text.writeString(out, this.localBlockPath);
/* 80 */     Text.writeString(out, this.localMetaPath);
/*    */   }
/*    */ 
/*    */   public void readFields(DataInput in) throws IOException
/*    */   {
/* 85 */     this.block = new Block();
/* 86 */     this.block.readFields(in);
/* 87 */     this.localBlockPath = Text.readString(in);
/* 88 */     this.localMetaPath = Text.readString(in);
/*    */   }
/*    */ 
/*    */   public long getNumBytes()
/*    */   {
/* 96 */     return this.block.getNumBytes();
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 43 */     WritableFactories.setFactory(BlockLocalPathInfo.class, FACTORY);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.protocol.BlockLocalPathInfo
 * JD-Core Version:    0.6.1
 */
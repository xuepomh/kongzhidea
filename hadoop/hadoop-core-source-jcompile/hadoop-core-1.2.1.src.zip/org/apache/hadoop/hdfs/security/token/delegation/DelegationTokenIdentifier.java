/*    */ package org.apache.hadoop.hdfs.security.token.delegation;
/*    */ 
/*    */ import org.apache.hadoop.io.Text;
/*    */ import org.apache.hadoop.security.token.delegation.AbstractDelegationTokenIdentifier;
/*    */ 
/*    */ public class DelegationTokenIdentifier extends AbstractDelegationTokenIdentifier
/*    */ {
/* 31 */   public static final Text HDFS_DELEGATION_KIND = new Text("HDFS_DELEGATION_TOKEN");
/*    */ 
/*    */   public DelegationTokenIdentifier()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DelegationTokenIdentifier(Text owner, Text renewer, Text realUser)
/*    */   {
/* 46 */     super(owner, renewer, realUser);
/*    */   }
/*    */ 
/*    */   public Text getKind()
/*    */   {
/* 51 */     return HDFS_DELEGATION_KIND;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenIdentifier
 * JD-Core Version:    0.6.1
 */
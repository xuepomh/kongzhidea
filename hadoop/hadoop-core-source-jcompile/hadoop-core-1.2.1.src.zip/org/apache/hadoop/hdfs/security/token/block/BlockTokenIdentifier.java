/*     */ package org.apache.hadoop.hdfs.security.token.block;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.EnumSet;
/*     */ import org.apache.hadoop.classification.InterfaceAudience.Private;
/*     */ import org.apache.hadoop.io.Text;
/*     */ import org.apache.hadoop.io.WritableUtils;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.token.Token.TrivialRenewer;
/*     */ import org.apache.hadoop.security.token.TokenIdentifier;
/*     */ 
/*     */ public class BlockTokenIdentifier extends TokenIdentifier
/*     */ {
/*  36 */   static final Text KIND_NAME = new Text("HDFS_BLOCK_TOKEN");
/*     */   private long expiryDate;
/*     */   private int keyId;
/*     */   private String userId;
/*     */   private long[] blockIds;
/*     */   private EnumSet<BlockTokenSecretManager.AccessMode> modes;
/*     */   private byte[] cache;
/*     */ 
/*     */   public BlockTokenIdentifier()
/*     */   {
/*  47 */     this(null, new long[0], EnumSet.noneOf(BlockTokenSecretManager.AccessMode.class));
/*     */   }
/*     */ 
/*     */   public BlockTokenIdentifier(String userId, long[] blockIds, EnumSet<BlockTokenSecretManager.AccessMode> modes)
/*     */   {
/*  52 */     if (blockIds == null)
/*  53 */       throw new IllegalArgumentException("blockIds can't be null");
/*  54 */     this.cache = null;
/*  55 */     this.userId = userId;
/*  56 */     this.blockIds = Arrays.copyOf(blockIds, blockIds.length);
/*  57 */     Arrays.sort(this.blockIds);
/*  58 */     this.modes = (modes == null ? EnumSet.noneOf(BlockTokenSecretManager.AccessMode.class) : modes);
/*     */   }
/*     */ 
/*     */   public Text getKind()
/*     */   {
/*  63 */     return KIND_NAME;
/*     */   }
/*     */ 
/*     */   public UserGroupInformation getUser()
/*     */   {
/*  68 */     if ((this.userId == null) || ("".equals(this.userId))) {
/*  69 */       return UserGroupInformation.createRemoteUser(Arrays.toString(this.blockIds));
/*     */     }
/*  71 */     return UserGroupInformation.createRemoteUser(this.userId);
/*     */   }
/*     */ 
/*     */   public long getExpiryDate() {
/*  75 */     return this.expiryDate;
/*     */   }
/*     */ 
/*     */   public void setExpiryDate(long expiryDate) {
/*  79 */     this.cache = null;
/*  80 */     this.expiryDate = expiryDate;
/*     */   }
/*     */ 
/*     */   public int getKeyId() {
/*  84 */     return this.keyId;
/*     */   }
/*     */ 
/*     */   public void setKeyId(int keyId) {
/*  88 */     this.cache = null;
/*  89 */     this.keyId = keyId;
/*     */   }
/*     */ 
/*     */   public String getUserId() {
/*  93 */     return this.userId;
/*     */   }
/*     */ 
/*     */   public long[] getBlockIds()
/*     */   {
/* 100 */     return this.blockIds;
/*     */   }
/*     */ 
/*     */   public boolean isBlockIncluded(long blockId)
/*     */   {
/* 107 */     switch (this.blockIds.length) {
/*     */     case 1:
/* 109 */       return this.blockIds[0] == blockId;
/*     */     case 2:
/* 111 */       return (this.blockIds[0] == blockId) || (this.blockIds[1] == blockId);
/*     */     }
/* 113 */     return Arrays.binarySearch(this.blockIds, blockId) >= 0;
/*     */   }
/*     */ 
/*     */   public EnumSet<BlockTokenSecretManager.AccessMode> getAccessModes()
/*     */   {
/* 118 */     return this.modes;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 123 */     return "block_token_identifier (expiryDate=" + getExpiryDate() + ", keyId=" + getKeyId() + ", userId=" + getUserId() + ", blockIds=" + Arrays.toString(this.blockIds) + ", access modes=" + getAccessModes() + ")";
/*     */   }
/*     */ 
/*     */   static boolean isEqual(Object a, Object b)
/*     */   {
/* 130 */     return a == null ? false : b == null ? true : a.equals(b);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 135 */     if (obj == this) {
/* 136 */       return true;
/*     */     }
/* 138 */     if ((obj instanceof BlockTokenIdentifier)) {
/* 139 */       BlockTokenIdentifier that = (BlockTokenIdentifier)obj;
/* 140 */       return (this.expiryDate == that.expiryDate) && (this.keyId == that.keyId) && (isEqual(this.userId, that.userId)) && (Arrays.equals(this.blockIds, that.blockIds)) && (isEqual(this.modes, that.modes));
/*     */     }
/*     */ 
/* 145 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 150 */     return (int)this.expiryDate ^ this.keyId ^ Arrays.hashCode(this.blockIds) ^ this.modes.hashCode() ^ (this.userId == null ? 0 : this.userId.hashCode());
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException
/*     */   {
/* 155 */     this.cache = null;
/* 156 */     this.expiryDate = WritableUtils.readVLong(in);
/* 157 */     this.keyId = WritableUtils.readVInt(in);
/* 158 */     this.userId = WritableUtils.readString(in);
/* 159 */     this.blockIds = new long[WritableUtils.readVInt(in)];
/* 160 */     for (int i = 0; i < this.blockIds.length; i++)
/* 161 */       this.blockIds[i] = WritableUtils.readVLong(in);
/* 162 */     int length = WritableUtils.readVInt(in);
/* 163 */     for (int i = 0; i < length; i++)
/* 164 */       this.modes.add(WritableUtils.readEnum(in, BlockTokenSecretManager.AccessMode.class));
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out) throws IOException
/*     */   {
/* 169 */     WritableUtils.writeVLong(out, this.expiryDate);
/* 170 */     WritableUtils.writeVInt(out, this.keyId);
/* 171 */     WritableUtils.writeString(out, this.userId);
/* 172 */     WritableUtils.writeVInt(out, this.blockIds.length);
/* 173 */     for (int i = 0; i < this.blockIds.length; i++)
/* 174 */       WritableUtils.writeVLong(out, this.blockIds[i]);
/* 175 */     WritableUtils.writeVInt(out, this.modes.size());
/* 176 */     for (BlockTokenSecretManager.AccessMode aMode : this.modes)
/* 177 */       WritableUtils.writeEnum(out, aMode);
/*     */   }
/*     */ 
/*     */   public byte[] getBytes()
/*     */   {
/* 183 */     if (this.cache == null) this.cache = super.getBytes();
/*     */ 
/* 185 */     return this.cache;
/*     */   }
/*     */ 
/*     */   @InterfaceAudience.Private
/*     */   public static class Renewer extends Token.TrivialRenewer
/*     */   {
/*     */     protected Text getKind() {
/* 192 */       return BlockTokenIdentifier.KIND_NAME;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.security.token.block.BlockTokenIdentifier
 * JD-Core Version:    0.6.1
 */
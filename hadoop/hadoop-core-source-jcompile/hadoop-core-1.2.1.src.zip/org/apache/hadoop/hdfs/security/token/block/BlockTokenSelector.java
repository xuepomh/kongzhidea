/*    */ package org.apache.hadoop.hdfs.security.token.block;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.apache.hadoop.io.Text;
/*    */ import org.apache.hadoop.security.token.Token;
/*    */ import org.apache.hadoop.security.token.TokenIdentifier;
/*    */ import org.apache.hadoop.security.token.TokenSelector;
/*    */ 
/*    */ public class BlockTokenSelector
/*    */   implements TokenSelector<BlockTokenIdentifier>
/*    */ {
/*    */   public Token<BlockTokenIdentifier> selectToken(Text service, Collection<Token<? extends TokenIdentifier>> tokens)
/*    */   {
/* 35 */     if (service == null) {
/* 36 */       return null;
/*    */     }
/* 38 */     for (Token token : tokens) {
/* 39 */       if (BlockTokenIdentifier.KIND_NAME.equals(token.getKind())) {
/* 40 */         return token;
/*    */       }
/*    */     }
/* 43 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.security.token.block.BlockTokenSelector
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs.security.token.delegation;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.hdfs.server.namenode.FSNamesystem;
/*     */ import org.apache.hadoop.hdfs.server.namenode.NameNode;
/*     */ import org.apache.hadoop.io.Text;
/*     */ import org.apache.hadoop.security.Credentials;
/*     */ import org.apache.hadoop.security.SecurityUtil;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.token.Token;
/*     */ import org.apache.hadoop.security.token.delegation.AbstractDelegationTokenSecretManager;
/*     */ import org.apache.hadoop.security.token.delegation.AbstractDelegationTokenSecretManager.DelegationTokenInformation;
/*     */ import org.apache.hadoop.security.token.delegation.DelegationKey;
/*     */ 
/*     */ public class DelegationTokenSecretManager extends AbstractDelegationTokenSecretManager<DelegationTokenIdentifier>
/*     */ {
/*  50 */   private static final Log LOG = LogFactory.getLog(DelegationTokenSecretManager.class);
/*     */   private final FSNamesystem namesystem;
/*     */ 
/*     */   public DelegationTokenSecretManager(long delegationKeyUpdateInterval, long delegationTokenMaxLifetime, long delegationTokenRenewInterval, long delegationTokenRemoverScanInterval, FSNamesystem namesystem)
/*     */   {
/*  67 */     super(delegationKeyUpdateInterval, delegationTokenMaxLifetime, delegationTokenRenewInterval, delegationTokenRemoverScanInterval);
/*     */ 
/*  69 */     this.namesystem = namesystem;
/*     */   }
/*     */ 
/*     */   public DelegationTokenIdentifier createIdentifier()
/*     */   {
/*  74 */     return new DelegationTokenIdentifier();
/*     */   }
/*     */ 
/*     */   public synchronized long getTokenExpiryTime(DelegationTokenIdentifier dtId)
/*     */     throws IOException
/*     */   {
/*  86 */     AbstractDelegationTokenSecretManager.DelegationTokenInformation info = (AbstractDelegationTokenSecretManager.DelegationTokenInformation)this.currentTokens.get(dtId);
/*  87 */     if (info != null) {
/*  88 */       return info.getRenewDate();
/*     */     }
/*  90 */     throw new IOException("No delegation token found for this identifier");
/*     */   }
/*     */ 
/*     */   public synchronized void loadSecretManagerState(DataInputStream in)
/*     */     throws IOException
/*     */   {
/* 102 */     if (this.running)
/*     */     {
/* 104 */       throw new IOException("Can't load state from image in a running SecretManager.");
/*     */     }
/*     */ 
/* 107 */     this.currentId = in.readInt();
/* 108 */     loadAllKeys(in);
/* 109 */     this.delegationTokenSequenceNumber = in.readInt();
/* 110 */     loadCurrentTokens(in);
/*     */   }
/*     */ 
/*     */   public synchronized void saveSecretManagerState(DataOutputStream out)
/*     */     throws IOException
/*     */   {
/* 121 */     out.writeInt(this.currentId);
/* 122 */     saveAllKeys(out);
/* 123 */     out.writeInt(this.delegationTokenSequenceNumber);
/* 124 */     saveCurrentTokens(out);
/*     */   }
/*     */ 
/*     */   public synchronized void addPersistedDelegationToken(DelegationTokenIdentifier identifier, long expiryTime)
/*     */     throws IOException
/*     */   {
/* 138 */     if (this.running)
/*     */     {
/* 140 */       throw new IOException("Can't add persisted delegation token to a running SecretManager.");
/*     */     }
/*     */ 
/* 143 */     int keyId = identifier.getMasterKeyId();
/* 144 */     DelegationKey dKey = (DelegationKey)this.allKeys.get(Integer.valueOf(keyId));
/* 145 */     if (dKey == null) {
/* 146 */       LOG.warn("No KEY found for persisted identifier " + identifier.toString());
/*     */ 
/* 149 */       return;
/*     */     }
/* 151 */     byte[] password = createPassword(identifier.getBytes(), dKey.getKey());
/* 152 */     if (identifier.getSequenceNumber() > this.delegationTokenSequenceNumber) {
/* 153 */       this.delegationTokenSequenceNumber = identifier.getSequenceNumber();
/*     */     }
/* 155 */     if (this.currentTokens.get(identifier) == null) {
/* 156 */       this.currentTokens.put(identifier, new AbstractDelegationTokenSecretManager.DelegationTokenInformation(expiryTime, password));
/*     */     }
/*     */     else
/* 159 */       throw new IOException("Same delegation token being added twice; invalid entry in fsimage or editlogs");
/*     */   }
/*     */ 
/*     */   public synchronized void updatePersistedMasterKey(DelegationKey key)
/*     */     throws IOException
/*     */   {
/* 172 */     addKey(key);
/*     */   }
/*     */ 
/*     */   public synchronized void updatePersistedTokenRenewal(DelegationTokenIdentifier identifier, long expiryTime)
/*     */     throws IOException
/*     */   {
/* 184 */     if (this.running)
/*     */     {
/* 186 */       throw new IOException("Can't update persisted delegation token renewal to a running SecretManager.");
/*     */     }
/*     */ 
/* 189 */     AbstractDelegationTokenSecretManager.DelegationTokenInformation info = null;
/* 190 */     info = (AbstractDelegationTokenSecretManager.DelegationTokenInformation)this.currentTokens.get(identifier);
/* 191 */     if (info != null) {
/* 192 */       int keyId = identifier.getMasterKeyId();
/* 193 */       byte[] password = createPassword(identifier.getBytes(), ((DelegationKey)this.allKeys.get(Integer.valueOf(keyId))).getKey());
/*     */ 
/* 195 */       this.currentTokens.put(identifier, new AbstractDelegationTokenSecretManager.DelegationTokenInformation(expiryTime, password));
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void updatePersistedTokenCancellation(DelegationTokenIdentifier identifier)
/*     */     throws IOException
/*     */   {
/* 208 */     if (this.running)
/*     */     {
/* 210 */       throw new IOException("Can't update persisted delegation token renewal to a running SecretManager.");
/*     */     }
/*     */ 
/* 213 */     this.currentTokens.remove(identifier);
/*     */   }
/*     */ 
/*     */   public synchronized int getNumberOfKeys()
/*     */   {
/* 221 */     return this.allKeys.size();
/*     */   }
/*     */ 
/*     */   private synchronized void saveCurrentTokens(DataOutputStream out)
/*     */     throws IOException
/*     */   {
/* 229 */     out.writeInt(this.currentTokens.size());
/* 230 */     Iterator iter = this.currentTokens.keySet().iterator();
/*     */ 
/* 232 */     while (iter.hasNext()) {
/* 233 */       DelegationTokenIdentifier id = (DelegationTokenIdentifier)iter.next();
/* 234 */       id.write(out);
/* 235 */       AbstractDelegationTokenSecretManager.DelegationTokenInformation info = (AbstractDelegationTokenSecretManager.DelegationTokenInformation)this.currentTokens.get(id);
/* 236 */       out.writeLong(info.getRenewDate());
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized void saveAllKeys(DataOutputStream out)
/*     */     throws IOException
/*     */   {
/* 245 */     out.writeInt(this.allKeys.size());
/* 246 */     Iterator iter = this.allKeys.keySet().iterator();
/* 247 */     while (iter.hasNext()) {
/* 248 */       Integer key = (Integer)iter.next();
/* 249 */       ((DelegationKey)this.allKeys.get(key)).write(out);
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized void loadCurrentTokens(DataInputStream in)
/*     */     throws IOException
/*     */   {
/* 258 */     int numberOfTokens = in.readInt();
/* 259 */     for (int i = 0; i < numberOfTokens; i++) {
/* 260 */       DelegationTokenIdentifier id = new DelegationTokenIdentifier();
/* 261 */       id.readFields(in);
/* 262 */       long expiryTime = in.readLong();
/* 263 */       addPersistedDelegationToken(id, expiryTime);
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized void loadAllKeys(DataInputStream in)
/*     */     throws IOException
/*     */   {
/* 273 */     int numberOfKeys = in.readInt();
/* 274 */     for (int i = 0; i < numberOfKeys; i++) {
/* 275 */       DelegationKey value = new DelegationKey();
/* 276 */       value.readFields(in);
/* 277 */       addKey(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void logUpdateMasterKey(DelegationKey key)
/*     */     throws IOException
/*     */   {
/* 287 */     synchronized (this.noInterruptsLock)
/*     */     {
/* 293 */       if (Thread.interrupted()) {
/* 294 */         throw new InterruptedIOException("Interrupted before updating master key");
/*     */       }
/*     */ 
/* 297 */       this.namesystem.logUpdateMasterKey(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Credentials createCredentials(NameNode namenode, UserGroupInformation ugi, String renewer)
/*     */     throws IOException
/*     */   {
/* 304 */     Token token = namenode.getDelegationToken(new Text(renewer));
/*     */ 
/* 306 */     if (token == null) {
/* 307 */       throw new IOException("Failed to get the token for " + renewer + ", user=" + ugi.getShortUserName());
/*     */     }
/*     */ 
/* 310 */     SecurityUtil.setTokenService(token, namenode.getNameNodeAddress());
/* 311 */     Credentials c = new Credentials();
/* 312 */     c.addToken(new Text(ugi.getShortUserName()), token);
/* 313 */     return c;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenSecretManager
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.security.token.block;
/*    */ 
/*    */ import javax.crypto.SecretKey;
/*    */ import org.apache.hadoop.security.token.delegation.DelegationKey;
/*    */ 
/*    */ public class BlockKey extends DelegationKey
/*    */ {
/*    */   public BlockKey()
/*    */   {
/*    */   }
/*    */ 
/*    */   public BlockKey(int keyId, long expiryDate, SecretKey key)
/*    */   {
/* 35 */     super(keyId, expiryDate, key);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.security.token.block.BlockKey
 * JD-Core Version:    0.6.1
 */
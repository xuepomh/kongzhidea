/*    */ package org.apache.hadoop.hdfs.security.token.block;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class InvalidBlockTokenException extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = 168L;
/*    */ 
/*    */   public InvalidBlockTokenException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public InvalidBlockTokenException(String msg)
/*    */   {
/* 34 */     super(msg);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.security.token.block.InvalidBlockTokenException
 * JD-Core Version:    0.6.1
 */
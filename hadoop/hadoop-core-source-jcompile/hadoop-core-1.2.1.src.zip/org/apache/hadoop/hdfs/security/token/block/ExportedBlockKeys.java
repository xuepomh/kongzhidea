/*     */ package org.apache.hadoop.hdfs.security.token.block;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.WritableFactories;
/*     */ import org.apache.hadoop.io.WritableFactory;
/*     */ 
/*     */ public class ExportedBlockKeys
/*     */   implements Writable
/*     */ {
/*  33 */   public static final ExportedBlockKeys DUMMY_KEYS = new ExportedBlockKeys();
/*     */   private boolean isBlockTokenEnabled;
/*     */   private long keyUpdateInterval;
/*     */   private long tokenLifetime;
/*     */   private BlockKey currentKey;
/*     */   private BlockKey[] allKeys;
/*     */ 
/*     */   public ExportedBlockKeys()
/*     */   {
/*  41 */     this(false, 0L, 0L, new BlockKey(), new BlockKey[0]);
/*     */   }
/*     */ 
/*     */   ExportedBlockKeys(boolean isBlockTokenEnabled, long keyUpdateInterval, long tokenLifetime, BlockKey currentKey, BlockKey[] allKeys)
/*     */   {
/*  46 */     this.isBlockTokenEnabled = isBlockTokenEnabled;
/*  47 */     this.keyUpdateInterval = keyUpdateInterval;
/*  48 */     this.tokenLifetime = tokenLifetime;
/*  49 */     this.currentKey = (currentKey == null ? new BlockKey() : currentKey);
/*  50 */     this.allKeys = (allKeys == null ? new BlockKey[0] : allKeys);
/*     */   }
/*     */ 
/*     */   public boolean isBlockTokenEnabled() {
/*  54 */     return this.isBlockTokenEnabled;
/*     */   }
/*     */ 
/*     */   public long getKeyUpdateInterval() {
/*  58 */     return this.keyUpdateInterval;
/*     */   }
/*     */ 
/*     */   public long getTokenLifetime() {
/*  62 */     return this.tokenLifetime;
/*     */   }
/*     */ 
/*     */   public BlockKey getCurrentKey() {
/*  66 */     return this.currentKey;
/*     */   }
/*     */ 
/*     */   public BlockKey[] getAllKeys() {
/*  70 */     return this.allKeys;
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/*  88 */     out.writeBoolean(this.isBlockTokenEnabled);
/*  89 */     out.writeLong(this.keyUpdateInterval);
/*  90 */     out.writeLong(this.tokenLifetime);
/*  91 */     this.currentKey.write(out);
/*  92 */     out.writeInt(this.allKeys.length);
/*  93 */     for (int i = 0; i < this.allKeys.length; i++)
/*  94 */       this.allKeys[i].write(out);
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in)
/*     */     throws IOException
/*     */   {
/* 101 */     this.isBlockTokenEnabled = in.readBoolean();
/* 102 */     this.keyUpdateInterval = in.readLong();
/* 103 */     this.tokenLifetime = in.readLong();
/* 104 */     this.currentKey.readFields(in);
/* 105 */     this.allKeys = new BlockKey[in.readInt()];
/* 106 */     for (int i = 0; i < this.allKeys.length; i++) {
/* 107 */       this.allKeys[i] = new BlockKey();
/* 108 */       this.allKeys[i].readFields(in);
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  77 */     WritableFactories.setFactory(ExportedBlockKeys.class, new WritableFactory()
/*     */     {
/*     */       public Writable newInstance() {
/*  80 */         return new ExportedBlockKeys();
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.security.token.block.ExportedBlockKeys
 * JD-Core Version:    0.6.1
 */
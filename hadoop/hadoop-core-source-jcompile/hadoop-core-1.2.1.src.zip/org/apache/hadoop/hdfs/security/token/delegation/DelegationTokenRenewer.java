/*     */ package org.apache.hadoop.hdfs.security.token.delegation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.concurrent.DelayQueue;
/*     */ import java.util.concurrent.Delayed;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.hadoop.classification.InterfaceAudience.Private;
/*     */ import org.apache.hadoop.conf.Configured;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.security.token.Token;
/*     */ import org.apache.hadoop.security.token.TokenIdentifier;
/*     */ 
/*     */ @InterfaceAudience.Private
/*     */ public class DelegationTokenRenewer<T extends FileSystem,  extends Renewable> extends Thread
/*     */ {
/*     */   private static final int RENEW_CYCLE = 82080000;
/* 135 */   private DelayQueue<RenewAction<T>> queue = new DelayQueue();
/*     */ 
/*     */   public DelegationTokenRenewer(Class<T> clazz) {
/* 138 */     super(clazz.getSimpleName() + "-" + DelegationTokenRenewer.class.getSimpleName());
/* 139 */     setDaemon(true);
/*     */   }
/*     */ 
/*     */   public void start()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void addRenewAction(T fs)
/*     */   {
/* 149 */     this.queue.add(new RenewAction(fs, null));
/* 150 */     if (!isAlive()) super.start(); 
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     while (true)
/*     */     {
/* 156 */       RenewAction action = null;
/*     */       try {
/* 158 */         action = (RenewAction)this.queue.take();
/* 159 */         if (action.renew()) {
/* 160 */           action.updateRenewalTime();
/* 161 */           this.queue.add(action);
/*     */         }
/*     */       } catch (InterruptedException ie) {
/* 164 */         return;
/*     */       } catch (Exception ie) {
/* 166 */         FileSystem.LOG.warn("Failed to renew token, action=" + action, ie);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class RenewAction<T extends FileSystem,  extends DelegationTokenRenewer.Renewable>
/*     */     implements Delayed
/*     */   {
/*     */     private long renewalTime;
/*     */     private final WeakReference<T> weakFs;
/*     */ 
/*     */     private RenewAction(T fs)
/*     */     {
/*  59 */       this.weakFs = new WeakReference(fs);
/*  60 */       updateRenewalTime();
/*     */     }
/*     */ 
/*     */     public long getDelay(TimeUnit unit)
/*     */     {
/*  66 */       long millisLeft = this.renewalTime - System.currentTimeMillis();
/*  67 */       return unit.convert(millisLeft, TimeUnit.MILLISECONDS);
/*     */     }
/*     */ 
/*     */     public int compareTo(Delayed delayed)
/*     */     {
/*  72 */       RenewAction that = (RenewAction)delayed;
/*  73 */       return this.renewalTime == that.renewalTime ? 0 : this.renewalTime < that.renewalTime ? -1 : 1;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/*  79 */       return (int)this.renewalTime ^ (int)(this.renewalTime >>> 32);
/*     */     }
/*     */ 
/*     */     public boolean equals(Object that)
/*     */     {
/*  84 */       if ((that == null) || (!(that instanceof RenewAction))) {
/*  85 */         return false;
/*     */       }
/*  87 */       return compareTo((Delayed)that) == 0;
/*     */     }
/*     */ 
/*     */     private void updateRenewalTime()
/*     */     {
/*  96 */       this.renewalTime = (82080000L + System.currentTimeMillis());
/*     */     }
/*     */ 
/*     */     private boolean renew()
/*     */       throws IOException, InterruptedException
/*     */     {
/* 105 */       FileSystem fs = (FileSystem)this.weakFs.get();
/* 106 */       boolean b = fs != null;
/* 107 */       if (b) {
/* 108 */         synchronized (fs) {
/*     */           try {
/* 110 */             ((DelegationTokenRenewer.Renewable)fs).getRenewToken().renew(fs.getConf());
/*     */           } catch (IOException ie) {
/*     */             try {
/* 113 */               ((DelegationTokenRenewer.Renewable)fs).setDelegationToken(fs.getDelegationToken(null));
/*     */             } catch (IOException ie2) {
/* 115 */               throw new IOException("Can't renew or get new delegation token ", ie);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 120 */       return b;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 125 */       DelegationTokenRenewer.Renewable fs = (DelegationTokenRenewer.Renewable)this.weakFs.get();
/* 126 */       return "The token will be renewed in " + getDelay(TimeUnit.SECONDS) + " secs, renewToken=" + fs.getRenewToken();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface Renewable
/*     */   {
/*     */     public abstract Token<?> getRenewToken();
/*     */ 
/*     */     public abstract <T extends TokenIdentifier> void setDelegationToken(Token<T> paramToken);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenRenewer
 * JD-Core Version:    0.6.1
 */
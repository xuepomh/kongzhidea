/*     */ package org.apache.hadoop.hdfs.security.token.block;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.io.WritableUtils;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.token.SecretManager;
/*     */ import org.apache.hadoop.security.token.SecretManager.InvalidToken;
/*     */ import org.apache.hadoop.security.token.Token;
/*     */ 
/*     */ public class BlockTokenSecretManager extends SecretManager<BlockTokenIdentifier>
/*     */ {
/*  48 */   public static final Log LOG = LogFactory.getLog(BlockTokenSecretManager.class);
/*     */ 
/*  50 */   public static final Token<BlockTokenIdentifier> DUMMY_TOKEN = new Token();
/*     */   private final boolean isMaster;
/*     */   private final long keyUpdateInterval;
/*     */   private volatile long tokenLifetime;
/*  60 */   private int serialNo = new SecureRandom().nextInt();
/*     */   private BlockKey currentKey;
/*     */   private BlockKey nextKey;
/*     */   private Map<Integer, BlockKey> allKeys;
/*     */ 
/*     */   public BlockTokenSecretManager(boolean isMaster, long keyUpdateInterval, long tokenLifetime)
/*     */     throws IOException
/*     */   {
/*  79 */     this.isMaster = isMaster;
/*  80 */     this.keyUpdateInterval = keyUpdateInterval;
/*  81 */     this.tokenLifetime = tokenLifetime;
/*  82 */     this.allKeys = new HashMap();
/*  83 */     generateKeys();
/*     */   }
/*     */ 
/*     */   private synchronized void generateKeys()
/*     */   {
/*  88 */     if (!this.isMaster) {
/*  89 */       return;
/*     */     }
/*     */ 
/* 102 */     this.serialNo += 1;
/* 103 */     this.currentKey = new BlockKey(this.serialNo, System.currentTimeMillis() + 2L * this.keyUpdateInterval + this.tokenLifetime, generateSecret());
/*     */ 
/* 105 */     this.serialNo += 1;
/* 106 */     this.nextKey = new BlockKey(this.serialNo, System.currentTimeMillis() + 3L * this.keyUpdateInterval + this.tokenLifetime, generateSecret());
/*     */ 
/* 108 */     this.allKeys.put(Integer.valueOf(this.currentKey.getKeyId()), this.currentKey);
/* 109 */     this.allKeys.put(Integer.valueOf(this.nextKey.getKeyId()), this.nextKey);
/*     */   }
/*     */ 
/*     */   public synchronized ExportedBlockKeys exportKeys()
/*     */   {
/* 114 */     if (!this.isMaster)
/* 115 */       return null;
/* 116 */     if (LOG.isDebugEnabled())
/* 117 */       LOG.debug("Exporting access keys");
/* 118 */     return new ExportedBlockKeys(true, this.keyUpdateInterval, this.tokenLifetime, this.currentKey, (BlockKey[])this.allKeys.values().toArray(new BlockKey[0]));
/*     */   }
/*     */ 
/*     */   private synchronized void removeExpiredKeys()
/*     */   {
/* 123 */     long now = System.currentTimeMillis();
/* 124 */     Iterator it = this.allKeys.entrySet().iterator();
/* 125 */     while (it.hasNext()) {
/* 126 */       Map.Entry e = (Map.Entry)it.next();
/* 127 */       if (((BlockKey)e.getValue()).getExpiryDate() < now)
/* 128 */         it.remove();
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void setKeys(ExportedBlockKeys exportedKeys)
/*     */     throws IOException
/*     */   {
/* 138 */     if ((this.isMaster) || (exportedKeys == null))
/* 139 */       return;
/* 140 */     LOG.info("Setting block keys");
/* 141 */     removeExpiredKeys();
/* 142 */     this.currentKey = exportedKeys.getCurrentKey();
/* 143 */     BlockKey[] receivedKeys = exportedKeys.getAllKeys();
/* 144 */     for (int i = 0; i < receivedKeys.length; i++)
/* 145 */       if (receivedKeys[i] != null)
/*     */       {
/* 147 */         this.allKeys.put(Integer.valueOf(receivedKeys[i].getKeyId()), receivedKeys[i]);
/*     */       }
/*     */   }
/*     */ 
/*     */   public synchronized void updateKeys()
/*     */     throws IOException
/*     */   {
/* 155 */     if (!this.isMaster)
/* 156 */       return;
/* 157 */     LOG.info("Updating block keys");
/* 158 */     removeExpiredKeys();
/*     */ 
/* 160 */     this.allKeys.put(Integer.valueOf(this.currentKey.getKeyId()), new BlockKey(this.currentKey.getKeyId(), System.currentTimeMillis() + this.keyUpdateInterval + this.tokenLifetime, this.currentKey.getKey()));
/*     */ 
/* 164 */     this.currentKey = new BlockKey(this.nextKey.getKeyId(), System.currentTimeMillis() + 2L * this.keyUpdateInterval + this.tokenLifetime, this.nextKey.getKey());
/*     */ 
/* 166 */     this.allKeys.put(Integer.valueOf(this.currentKey.getKeyId()), this.currentKey);
/*     */ 
/* 168 */     this.serialNo += 1;
/* 169 */     this.nextKey = new BlockKey(this.serialNo, System.currentTimeMillis() + 3L * this.keyUpdateInterval + this.tokenLifetime, generateSecret());
/*     */ 
/* 171 */     this.allKeys.put(Integer.valueOf(this.nextKey.getKeyId()), this.nextKey);
/*     */   }
/*     */ 
/*     */   public Token<BlockTokenIdentifier> generateToken(Block block, EnumSet<AccessMode> modes)
/*     */     throws IOException
/*     */   {
/* 177 */     return generateToken(new long[] { block.getBlockId() }, modes);
/*     */   }
/*     */ 
/*     */   public Token<BlockTokenIdentifier> generateToken(String userId, Block block, EnumSet<AccessMode> modes)
/*     */     throws IOException
/*     */   {
/* 183 */     return generateToken(userId, new long[] { block.getBlockId() }, modes);
/*     */   }
/*     */ 
/*     */   public Token<BlockTokenIdentifier> generateToken(long[] blockIds, EnumSet<AccessMode> modes)
/*     */     throws IOException
/*     */   {
/* 191 */     UserGroupInformation ugi = UserGroupInformation.getCurrentUser();
/* 192 */     String userID = ugi == null ? null : ugi.getShortUserName();
/* 193 */     return generateToken(userID, blockIds, modes);
/*     */   }
/*     */ 
/*     */   public Token<BlockTokenIdentifier> generateToken(String userID, long[] blockIds, EnumSet<AccessMode> modes)
/*     */   {
/* 199 */     BlockTokenIdentifier id = new BlockTokenIdentifier(userID, blockIds, modes);
/* 200 */     return new Token(id, this);
/*     */   }
/*     */ 
/*     */   public void checkAccess(BlockTokenIdentifier id, String userId, Block block, AccessMode mode)
/*     */     throws SecretManager.InvalidToken
/*     */   {
/* 210 */     if (LOG.isDebugEnabled()) {
/* 211 */       LOG.debug("Checking access for user=" + userId + ", block=" + block + ", access mode=" + mode + " using " + id.toString());
/*     */     }
/*     */ 
/* 214 */     if ((userId != null) && (!userId.equals(id.getUserId()))) {
/* 215 */       throw new SecretManager.InvalidToken("Block token with " + id.toString() + " doesn't belong to user " + userId);
/*     */     }
/*     */ 
/* 218 */     if (!id.isBlockIncluded(block.getBlockId())) {
/* 219 */       throw new SecretManager.InvalidToken("Block token with " + id.toString() + " doesn't apply to block " + block);
/*     */     }
/*     */ 
/* 222 */     if (isExpired(id.getExpiryDate())) {
/* 223 */       throw new SecretManager.InvalidToken("Block token with " + id.toString() + " is expired.");
/*     */     }
/*     */ 
/* 226 */     if (!id.getAccessModes().contains(mode))
/* 227 */       throw new SecretManager.InvalidToken("Block token with " + id.toString() + " doesn't have " + mode + " permission");
/*     */   }
/*     */ 
/*     */   public void checkAccess(Token<BlockTokenIdentifier> token, String userId, Block block, AccessMode mode)
/*     */     throws SecretManager.InvalidToken
/*     */   {
/* 235 */     BlockTokenIdentifier id = new BlockTokenIdentifier();
/*     */     try {
/* 237 */       id.readFields(new DataInputStream(new ByteArrayInputStream(token.getIdentifier())));
/*     */     }
/*     */     catch (IOException e) {
/* 240 */       throw new SecretManager.InvalidToken("Unable to de-serialize block token identifier for user=" + userId + ", block=" + block + ", access mode=" + mode);
/*     */     }
/*     */ 
/* 244 */     checkAccess(id, userId, block, mode);
/* 245 */     if (!Arrays.equals(retrievePassword(id), token.getPassword()))
/* 246 */       throw new SecretManager.InvalidToken("Block token with " + id.toString() + " doesn't have the correct token password");
/*     */   }
/*     */ 
/*     */   private static boolean isExpired(long expiryDate)
/*     */   {
/* 252 */     return System.currentTimeMillis() > expiryDate;
/*     */   }
/*     */ 
/*     */   static boolean isTokenExpired(Token<BlockTokenIdentifier> token)
/*     */     throws IOException
/*     */   {
/* 261 */     ByteArrayInputStream buf = new ByteArrayInputStream(token.getIdentifier());
/* 262 */     DataInputStream in = new DataInputStream(buf);
/* 263 */     long expiryDate = WritableUtils.readVLong(in);
/* 264 */     return isExpired(expiryDate);
/*     */   }
/*     */ 
/*     */   public void setTokenLifetime(long tokenLifetime)
/*     */   {
/* 269 */     this.tokenLifetime = tokenLifetime;
/*     */   }
/*     */ 
/*     */   public BlockTokenIdentifier createIdentifier()
/*     */   {
/* 279 */     return new BlockTokenIdentifier();
/*     */   }
/*     */ 
/*     */   protected byte[] createPassword(BlockTokenIdentifier identifier)
/*     */   {
/* 291 */     BlockKey key = null;
/* 292 */     synchronized (this) {
/* 293 */       key = this.currentKey;
/*     */     }
/* 295 */     if (key == null)
/* 296 */       throw new IllegalStateException("currentKey hasn't been initialized.");
/* 297 */     identifier.setExpiryDate(System.currentTimeMillis() + this.tokenLifetime);
/* 298 */     identifier.setKeyId(key.getKeyId());
/* 299 */     if (LOG.isDebugEnabled()) {
/* 300 */       LOG.debug("Generating block token for " + identifier.toString());
/*     */     }
/* 302 */     return createPassword(identifier.getBytes(), key.getKey());
/*     */   }
/*     */ 
/*     */   public byte[] retrievePassword(BlockTokenIdentifier identifier)
/*     */     throws SecretManager.InvalidToken
/*     */   {
/* 316 */     if (isExpired(identifier.getExpiryDate())) {
/* 317 */       throw new SecretManager.InvalidToken("Block token with " + identifier.toString() + " is expired.");
/*     */     }
/*     */ 
/* 320 */     BlockKey key = null;
/* 321 */     synchronized (this) {
/* 322 */       key = (BlockKey)this.allKeys.get(Integer.valueOf(identifier.getKeyId()));
/*     */     }
/* 324 */     if (key == null) {
/* 325 */       throw new SecretManager.InvalidToken("Can't re-compute password for " + identifier.toString() + ", since the required block key (keyID=" + identifier.getKeyId() + ") doesn't exist.");
/*     */     }
/*     */ 
/* 329 */     return createPassword(identifier.getBytes(), key.getKey());
/*     */   }
/*     */ 
/*     */   public static enum AccessMode
/*     */   {
/*  66 */     READ, WRITE, COPY, REPLACE;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.security.token.block.BlockTokenSecretManager
 * JD-Core Version:    0.6.1
 */
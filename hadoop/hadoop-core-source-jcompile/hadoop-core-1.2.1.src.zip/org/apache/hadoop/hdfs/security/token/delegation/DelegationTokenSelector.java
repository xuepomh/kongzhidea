/*    */ package org.apache.hadoop.hdfs.security.token.delegation;
/*    */ 
/*    */ import java.net.InetSocketAddress;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ import org.apache.hadoop.io.Text;
/*    */ import org.apache.hadoop.net.NetUtils;
/*    */ import org.apache.hadoop.security.SecurityUtil;
/*    */ import org.apache.hadoop.security.UserGroupInformation;
/*    */ import org.apache.hadoop.security.token.Token;
/*    */ import org.apache.hadoop.security.token.delegation.AbstractDelegationTokenSelector;
/*    */ 
/*    */ public class DelegationTokenSelector extends AbstractDelegationTokenSelector<DelegationTokenIdentifier>
/*    */ {
/*    */   private static final String SERVICE_NAME_KEY = "hdfs.service.host_";
/* 40 */   private static final DelegationTokenSelector INSTANCE = new DelegationTokenSelector();
/*    */ 
/*    */   public static Token<DelegationTokenIdentifier> selectHdfsDelegationToken(InetSocketAddress nnAddr, UserGroupInformation ugi, Configuration conf)
/*    */   {
/* 50 */     String key = "hdfs.service.host_" + SecurityUtil.buildTokenService(nnAddr);
/* 51 */     String nnServiceName = conf.get(key);
/*    */ 
/* 53 */     int nnRpcPort = 8020;
/* 54 */     if (nnServiceName != null) {
/* 55 */       nnRpcPort = NetUtils.createSocketAddr(nnServiceName, nnRpcPort).getPort();
/*    */     }
/*    */ 
/* 58 */     Text serviceName = SecurityUtil.buildTokenService(NetUtils.makeSocketAddr(nnAddr.getHostName(), nnRpcPort));
/*    */ 
/* 60 */     return INSTANCE.selectToken(serviceName, ugi.getTokens());
/*    */   }
/*    */ 
/*    */   public DelegationTokenSelector() {
/* 64 */     super(DelegationTokenIdentifier.HDFS_DELEGATION_KIND);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenSelector
 * JD-Core Version:    0.6.1
 */
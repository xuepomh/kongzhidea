/*     */ package org.apache.hadoop.hdfs;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FSInputChecker;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.hdfs.protocol.BlockLocalPathInfo;
/*     */ import org.apache.hadoop.hdfs.protocol.ClientDatanodeProtocol;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.hdfs.security.token.block.BlockTokenIdentifier;
/*     */ import org.apache.hadoop.hdfs.server.datanode.BlockMetadataHeader;
/*     */ import org.apache.hadoop.io.IOUtils;
/*     */ import org.apache.hadoop.ipc.RPC;
/*     */ import org.apache.hadoop.security.token.Token;
/*     */ import org.apache.hadoop.util.DataChecksum;
/*     */ 
/*     */ class BlockReaderLocal extends FSInputChecker
/*     */   implements BlockReader
/*     */ {
/*  62 */   public static final Log LOG = LogFactory.getLog(DFSClient.class);
/*     */ 
/* 118 */   private static Map<Integer, LocalDatanodeInfo> localDatanodeInfoMap = new HashMap();
/*     */   private FileInputStream dataIn;
/*     */   private FileInputStream checksumIn;
/*     */   private DataChecksum checksum;
/*     */   private int bytesPerChecksum;
/*     */   private int checksumSize;
/*     */   private long firstChunkOffset;
/* 127 */   private long lastChunkLen = -1L;
/* 128 */   private long lastChunkOffset = -1L;
/*     */   private long startOffset;
/* 130 */   private boolean gotEOS = false;
/* 131 */   private byte[] skipBuf = null;
/*     */ 
/*     */   static BlockReaderLocal newBlockReader(Configuration conf, String file, Block blk, Token<BlockTokenIdentifier> token, DatanodeInfo node, int socketTimeout, long startOffset, long length, boolean connectToDnViaHostname)
/*     */     throws IOException
/*     */   {
/* 141 */     LocalDatanodeInfo localDatanodeInfo = getLocalDatanodeInfo(node.getIpcPort());
/*     */ 
/* 143 */     BlockLocalPathInfo pathinfo = localDatanodeInfo.getBlockLocalPathInfo(blk);
/* 144 */     if (pathinfo == null) {
/* 145 */       pathinfo = getBlockPathInfo(blk, node, conf, socketTimeout, token, connectToDnViaHostname);
/*     */     }
/*     */ 
/* 154 */     FileInputStream dataIn = null;
/* 155 */     FileInputStream checksumIn = null;
/* 156 */     BlockReaderLocal localBlockReader = null;
/* 157 */     boolean skipChecksum = skipChecksumCheck(conf);
/*     */     try
/*     */     {
/* 160 */       File blkfile = new File(pathinfo.getBlockPath());
/* 161 */       dataIn = new FileInputStream(blkfile);
/*     */ 
/* 163 */       if (LOG.isDebugEnabled()) {
/* 164 */         LOG.debug("New BlockReaderLocal for file " + blkfile + " of size " + blkfile.length() + " startOffset " + startOffset + " length " + length + " short circuit checksum " + skipChecksum);
/*     */       }
/*     */ 
/* 169 */       if (!skipChecksum)
/*     */       {
/* 171 */         File metafile = new File(pathinfo.getMetaPath());
/* 172 */         checksumIn = new FileInputStream(metafile);
/*     */ 
/* 175 */         BlockMetadataHeader header = BlockMetadataHeader.readHeader(new DataInputStream(checksumIn));
/*     */ 
/* 177 */         short version = header.getVersion();
/* 178 */         if (version != 1) {
/* 179 */           LOG.warn("Wrong version (" + version + ") for metadata file for " + blk + " ignoring ...");
/*     */         }
/*     */ 
/* 182 */         DataChecksum checksum = header.getChecksum();
/* 183 */         localBlockReader = new BlockReaderLocal(conf, file, blk, token, startOffset, length, pathinfo, checksum, true, dataIn, checksumIn);
/*     */       }
/*     */       else {
/* 186 */         localBlockReader = new BlockReaderLocal(conf, file, blk, token, startOffset, length, pathinfo, dataIn);
/*     */       }
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 191 */       localDatanodeInfo.removeBlockLocalPathInfo(blk);
/* 192 */       DFSClient.LOG.warn("BlockReaderLocal: Removing " + blk + " from cache because local file " + pathinfo.getBlockPath() + " could not be opened.");
/*     */ 
/* 195 */       throw e;
/*     */     } finally {
/* 197 */       if (localBlockReader == null) {
/* 198 */         if (dataIn != null) {
/* 199 */           dataIn.close();
/*     */         }
/* 201 */         if (checksumIn != null) {
/* 202 */           checksumIn.close();
/*     */         }
/*     */       }
/*     */     }
/* 206 */     return localBlockReader;
/*     */   }
/*     */ 
/*     */   private static synchronized LocalDatanodeInfo getLocalDatanodeInfo(int port) {
/* 210 */     LocalDatanodeInfo ldInfo = (LocalDatanodeInfo)localDatanodeInfoMap.get(Integer.valueOf(port));
/* 211 */     if (ldInfo == null) {
/* 212 */       ldInfo = new LocalDatanodeInfo();
/* 213 */       localDatanodeInfoMap.put(Integer.valueOf(port), ldInfo);
/*     */     }
/* 215 */     return ldInfo;
/*     */   }
/*     */ 
/*     */   private static BlockLocalPathInfo getBlockPathInfo(Block blk, DatanodeInfo node, Configuration conf, int timeout, Token<BlockTokenIdentifier> token, boolean connectToDnViaHostname)
/*     */     throws IOException
/*     */   {
/* 222 */     LocalDatanodeInfo localDatanodeInfo = getLocalDatanodeInfo(node.ipcPort);
/* 223 */     BlockLocalPathInfo pathinfo = null;
/* 224 */     ClientDatanodeProtocol proxy = localDatanodeInfo.getDatanodeProxy(node, conf, timeout, connectToDnViaHostname);
/*     */     try
/*     */     {
/* 228 */       pathinfo = proxy.getBlockLocalPathInfo(blk, token);
/* 229 */       if (pathinfo != null) {
/* 230 */         if (LOG.isDebugEnabled()) {
/* 231 */           LOG.debug("Cached location of block " + blk + " as " + pathinfo);
/*     */         }
/* 233 */         localDatanodeInfo.setBlockLocalPathInfo(blk, pathinfo);
/*     */       }
/*     */     } catch (IOException e) {
/* 236 */       localDatanodeInfo.resetDatanodeProxy();
/* 237 */       throw e;
/*     */     }
/* 239 */     return pathinfo;
/*     */   }
/*     */ 
/*     */   private static boolean skipChecksumCheck(Configuration conf) {
/* 243 */     return conf.getBoolean("dfs.client.read.shortcircuit.skip.checksum", false);
/*     */   }
/*     */ 
/*     */   private BlockReaderLocal(Configuration conf, String hdfsfile, Block block, Token<BlockTokenIdentifier> token, long startOffset, long length, BlockLocalPathInfo pathinfo, FileInputStream dataIn)
/*     */     throws IOException
/*     */   {
/* 250 */     super(new Path("/blk_" + block.getBlockId() + ":of:" + hdfsfile), 1);
/*     */ 
/* 253 */     this.startOffset = startOffset;
/* 254 */     this.dataIn = dataIn;
/* 255 */     long toSkip = startOffset;
/* 256 */     while (toSkip > 0L) {
/* 257 */       long skipped = dataIn.skip(toSkip);
/* 258 */       if (skipped == 0L) {
/* 259 */         throw new IOException("Couldn't initialize input stream");
/*     */       }
/* 261 */       toSkip -= skipped;
/*     */     }
/*     */   }
/*     */ 
/*     */   private BlockReaderLocal(Configuration conf, String hdfsfile, Block block, Token<BlockTokenIdentifier> token, long startOffset, long length, BlockLocalPathInfo pathinfo, DataChecksum checksum, boolean verifyChecksum, FileInputStream dataIn, FileInputStream checksumIn)
/*     */     throws IOException
/*     */   {
/* 269 */     super(new Path("/blk_" + block.getBlockId() + ":of:" + hdfsfile), 1, verifyChecksum, checksum.getChecksumSize() > 0 ? checksum : null, checksum.getBytesPerChecksum(), checksum.getChecksumSize());
/*     */ 
/* 276 */     this.startOffset = startOffset;
/* 277 */     this.dataIn = dataIn;
/* 278 */     this.checksumIn = checksumIn;
/* 279 */     this.checksum = checksum;
/*     */ 
/* 281 */     long blockLength = pathinfo.getNumBytes();
/*     */ 
/* 287 */     this.bytesPerChecksum = checksum.getBytesPerChecksum();
/* 288 */     if ((this.bytesPerChecksum > 10485760) && (this.bytesPerChecksum > blockLength)) {
/* 289 */       checksum = DataChecksum.newDataChecksum(checksum.getChecksumType(), Math.max((int)blockLength, 10485760));
/*     */ 
/* 291 */       this.bytesPerChecksum = checksum.getBytesPerChecksum();
/*     */     }
/*     */ 
/* 294 */     this.checksumSize = checksum.getChecksumSize();
/*     */ 
/* 296 */     if ((startOffset < 0L) || (startOffset > blockLength) || (length + startOffset > blockLength))
/*     */     {
/* 298 */       String msg = " Offset " + startOffset + " and length " + length + " don't match block " + block + " ( blockLen " + blockLength + " )";
/*     */ 
/* 300 */       LOG.warn("BlockReaderLocal requested with incorrect offset: " + msg);
/* 301 */       throw new IOException(msg);
/*     */     }
/*     */ 
/* 304 */     this.firstChunkOffset = (startOffset - startOffset % this.bytesPerChecksum);
/*     */ 
/* 306 */     if (this.firstChunkOffset > 0L) {
/* 307 */       dataIn.getChannel().position(this.firstChunkOffset);
/*     */ 
/* 309 */       long checksumSkip = this.firstChunkOffset / this.bytesPerChecksum * this.checksumSize;
/* 310 */       if (checksumSkip > 0L) {
/* 311 */         checksumIn.skip(checksumSkip);
/*     */       }
/*     */     }
/*     */ 
/* 315 */     this.lastChunkOffset = this.firstChunkOffset;
/* 316 */     this.lastChunkLen = -1L;
/*     */   }
/*     */ 
/*     */   public synchronized int read(byte[] buf, int off, int len) throws IOException
/*     */   {
/* 321 */     if (LOG.isDebugEnabled()) {
/* 322 */       LOG.debug("read off " + off + " len " + len);
/*     */     }
/* 324 */     if (this.checksum == null) {
/* 325 */       return this.dataIn.read(buf, off, len);
/*     */     }
/*     */ 
/* 328 */     if ((this.lastChunkLen < 0L) && (this.startOffset > this.firstChunkOffset) && (len > 0))
/*     */     {
/* 330 */       int toSkip = (int)(this.startOffset - this.firstChunkOffset);
/* 331 */       if (this.skipBuf == null) {
/* 332 */         this.skipBuf = new byte[this.bytesPerChecksum];
/*     */       }
/* 334 */       if (super.read(this.skipBuf, 0, toSkip) != toSkip)
/*     */       {
/* 336 */         throw new IOException("Could not skip " + toSkip + " bytes");
/*     */       }
/*     */     }
/* 339 */     return super.read(buf, off, len);
/*     */   }
/*     */ 
/*     */   public int readAll(byte[] buf, int offset, int len) throws IOException
/*     */   {
/* 344 */     return readFully(this, buf, offset, len);
/*     */   }
/*     */ 
/*     */   public synchronized long skip(long n) throws IOException
/*     */   {
/* 349 */     if (LOG.isDebugEnabled()) {
/* 350 */       LOG.debug("skip " + n);
/*     */     }
/* 352 */     if (this.checksum == null) {
/* 353 */       return this.dataIn.skip(n);
/*     */     }
/*     */ 
/* 359 */     if (this.skipBuf == null) {
/* 360 */       this.skipBuf = new byte[this.bytesPerChecksum];
/*     */     }
/* 362 */     long nSkipped = 0L;
/* 363 */     while (nSkipped < n) {
/* 364 */       int toSkip = (int)Math.min(n - nSkipped, this.skipBuf.length);
/* 365 */       int ret = read(this.skipBuf, 0, toSkip);
/* 366 */       if (ret <= 0) {
/* 367 */         return nSkipped;
/*     */       }
/* 369 */       nSkipped += ret;
/*     */     }
/* 371 */     return nSkipped;
/*     */   }
/*     */ 
/*     */   public boolean seekToNewSource(long targetPos)
/*     */     throws IOException
/*     */   {
/* 377 */     return false;
/*     */   }
/*     */ 
/*     */   public synchronized void seek(long n) throws IOException
/*     */   {
/* 382 */     throw new IOException("Seek() is not supported in BlockReaderLocal");
/*     */   }
/*     */ 
/*     */   protected long getChunkPosition(long pos)
/*     */   {
/* 387 */     throw new RuntimeException("getChunkPosition() is not supported, since seek is not implemented");
/*     */   }
/*     */ 
/*     */   protected synchronized int readChunk(long pos, byte[] buf, int offset, int len, byte[] checksumBuf)
/*     */     throws IOException
/*     */   {
/* 394 */     if (LOG.isDebugEnabled()) {
/* 395 */       LOG.debug("Reading chunk from position " + pos + " at offset " + offset + " with length " + len);
/*     */     }
/*     */ 
/* 399 */     if (this.gotEOS) {
/* 400 */       this.startOffset = -1L;
/* 401 */       return -1;
/*     */     }
/*     */ 
/* 404 */     if (checksumBuf.length != this.checksumSize) {
/* 405 */       throw new IOException("Cannot read checksum into buffer. The buffer must be exactly '" + this.checksumSize + "' bytes long to hold the checksum bytes.");
/*     */     }
/*     */ 
/* 410 */     if (pos + this.firstChunkOffset != this.lastChunkOffset) {
/* 411 */       throw new IOException("Mismatch in pos : " + pos + " + " + this.firstChunkOffset + " != " + this.lastChunkOffset);
/*     */     }
/*     */ 
/* 415 */     int nRead = this.dataIn.read(buf, offset, this.bytesPerChecksum);
/* 416 */     if (nRead < this.bytesPerChecksum) {
/* 417 */       this.gotEOS = true;
/*     */     }
/*     */ 
/* 420 */     this.lastChunkOffset += nRead;
/* 421 */     this.lastChunkLen = nRead;
/*     */ 
/* 424 */     if (this.checksumIn != null) {
/* 425 */       int nChecksumRead = this.checksumIn.read(checksumBuf);
/* 426 */       if (nChecksumRead != this.checksumSize) {
/* 427 */         throw new IOException("Could not read checksum at offset " + this.checksumIn.getChannel().position() + " from the meta file.");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 432 */     return nRead;
/*     */   }
/*     */ 
/*     */   public synchronized void close() throws IOException
/*     */   {
/* 437 */     IOUtils.closeStream(this.dataIn);
/* 438 */     IOUtils.closeStream(this.checksumIn);
/*     */   }
/*     */ 
/*     */   private static class LocalDatanodeInfo
/*     */   {
/*  66 */     private ClientDatanodeProtocol proxy = null;
/*     */     private final Map<Block, BlockLocalPathInfo> cache;
/*     */ 
/*     */     LocalDatanodeInfo()
/*     */     {
/*  70 */       int cacheSize = 10000;
/*  71 */       float hashTableLoadFactor = 0.75F;
/*  72 */       int hashTableCapacity = (int)Math.ceil(13333.3330078125D) + 1;
/*  73 */       this.cache = Collections.synchronizedMap(new LinkedHashMap(hashTableCapacity, 0.75F, true)
/*     */       {
/*     */         private static final long serialVersionUID = 1L;
/*     */ 
/*     */         protected boolean removeEldestEntry(Map.Entry<Block, BlockLocalPathInfo> eldest)
/*     */         {
/*  81 */           return size() > 10000;
/*     */         }
/*     */       });
/*     */     }
/*     */ 
/*     */     private synchronized ClientDatanodeProtocol getDatanodeProxy(DatanodeInfo node, Configuration conf, int socketTimeout, boolean connectToDnViaHostname)
/*     */       throws IOException
/*     */     {
/*  89 */       if (this.proxy == null) {
/*  90 */         this.proxy = DFSClient.createClientDatanodeProtocolProxy(node, conf, socketTimeout, connectToDnViaHostname);
/*     */       }
/*     */ 
/*  93 */       return this.proxy;
/*     */     }
/*     */ 
/*     */     private synchronized void resetDatanodeProxy() {
/*  97 */       if (null != this.proxy) {
/*  98 */         RPC.stopProxy(this.proxy);
/*  99 */         this.proxy = null;
/*     */       }
/*     */     }
/*     */ 
/*     */     private BlockLocalPathInfo getBlockLocalPathInfo(Block b) {
/* 104 */       return (BlockLocalPathInfo)this.cache.get(b);
/*     */     }
/*     */ 
/*     */     private void setBlockLocalPathInfo(Block b, BlockLocalPathInfo info) {
/* 108 */       this.cache.put(b, info);
/*     */     }
/*     */ 
/*     */     private void removeBlockLocalPathInfo(Block b) {
/* 112 */       this.cache.remove(b);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.BlockReaderLocal
 * JD-Core Version:    0.6.1
 */
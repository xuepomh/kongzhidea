/*      */ package org.apache.hadoop.hdfs;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.Closeable;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.InterruptedIOException;
/*      */ import java.io.OutputStream;
/*      */ import java.net.InetAddress;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.NetworkInterface;
/*      */ import java.net.Socket;
/*      */ import java.net.SocketAddress;
/*      */ import java.net.SocketException;
/*      */ import java.net.UnknownHostException;
/*      */ import java.nio.BufferOverflowException;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.util.AbstractMap;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import javax.net.SocketFactory;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.apache.hadoop.classification.InterfaceAudience.Private;
/*      */ import org.apache.hadoop.conf.Configuration;
/*      */ import org.apache.hadoop.fs.BlockLocation;
/*      */ import org.apache.hadoop.fs.ChecksumException;
/*      */ import org.apache.hadoop.fs.ContentSummary;
/*      */ import org.apache.hadoop.fs.FSDataInputStream;
/*      */ import org.apache.hadoop.fs.FSDataOutputStream;
/*      */ import org.apache.hadoop.fs.FSInputChecker;
/*      */ import org.apache.hadoop.fs.FSInputStream;
/*      */ import org.apache.hadoop.fs.FSOutputSummer;
/*      */ import org.apache.hadoop.fs.FileAlreadyExistsException;
/*      */ import org.apache.hadoop.fs.FileSystem.Statistics;
/*      */ import org.apache.hadoop.fs.MD5MD5CRC32FileChecksum;
/*      */ import org.apache.hadoop.fs.Path;
/*      */ import org.apache.hadoop.fs.Syncable;
/*      */ import org.apache.hadoop.fs.permission.FsPermission;
/*      */ import org.apache.hadoop.hdfs.protocol.AlreadyBeingCreatedException;
/*      */ import org.apache.hadoop.hdfs.protocol.Block;
/*      */ import org.apache.hadoop.hdfs.protocol.ClientDatanodeProtocol;
/*      */ import org.apache.hadoop.hdfs.protocol.ClientProtocol;
/*      */ import org.apache.hadoop.hdfs.protocol.DSQuotaExceededException;
/*      */ import org.apache.hadoop.hdfs.protocol.DataTransferProtocol.PipelineAck;
/*      */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*      */ import org.apache.hadoop.hdfs.protocol.DirectoryListing;
/*      */ import org.apache.hadoop.hdfs.protocol.FSConstants;
/*      */ import org.apache.hadoop.hdfs.protocol.FSConstants.DatanodeReportType;
/*      */ import org.apache.hadoop.hdfs.protocol.FSConstants.SafeModeAction;
/*      */ import org.apache.hadoop.hdfs.protocol.FSConstants.UpgradeAction;
/*      */ import org.apache.hadoop.hdfs.protocol.HdfsFileStatus;
/*      */ import org.apache.hadoop.hdfs.protocol.LocatedBlock;
/*      */ import org.apache.hadoop.hdfs.protocol.LocatedBlocks;
/*      */ import org.apache.hadoop.hdfs.protocol.NSQuotaExceededException;
/*      */ import org.apache.hadoop.hdfs.security.token.block.BlockTokenIdentifier;
/*      */ import org.apache.hadoop.hdfs.security.token.block.InvalidBlockTokenException;
/*      */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenIdentifier;
/*      */ import org.apache.hadoop.hdfs.server.common.UpgradeStatusReport;
/*      */ import org.apache.hadoop.hdfs.server.datanode.DataNode;
/*      */ import org.apache.hadoop.hdfs.server.namenode.NameNode;
/*      */ import org.apache.hadoop.hdfs.server.namenode.NotReplicatedYetException;
/*      */ import org.apache.hadoop.hdfs.server.namenode.SafeModeException;
/*      */ import org.apache.hadoop.io.DataOutputBuffer;
/*      */ import org.apache.hadoop.io.IOUtils;
/*      */ import org.apache.hadoop.io.MD5Hash;
/*      */ import org.apache.hadoop.io.Text;
/*      */ import org.apache.hadoop.io.retry.RetryPolicies;
/*      */ import org.apache.hadoop.io.retry.RetryPolicy;
/*      */ import org.apache.hadoop.io.retry.RetryProxy;
/*      */ import org.apache.hadoop.io.retry.RetryUtils;
/*      */ import org.apache.hadoop.ipc.Client;
/*      */ import org.apache.hadoop.ipc.RPC;
/*      */ import org.apache.hadoop.ipc.RemoteException;
/*      */ import org.apache.hadoop.net.DNS;
/*      */ import org.apache.hadoop.net.NetUtils;
/*      */ import org.apache.hadoop.security.AccessControlException;
/*      */ import org.apache.hadoop.security.SecurityUtil;
/*      */ import org.apache.hadoop.security.UserGroupInformation;
/*      */ import org.apache.hadoop.security.token.SecretManager.InvalidToken;
/*      */ import org.apache.hadoop.security.token.Token;
/*      */ import org.apache.hadoop.security.token.TokenRenewer;
/*      */ import org.apache.hadoop.util.Daemon;
/*      */ import org.apache.hadoop.util.DataChecksum;
/*      */ import org.apache.hadoop.util.Progressable;
/*      */ import org.apache.hadoop.util.PureJavaCrc32;
/*      */ import org.apache.hadoop.util.StringUtils;
/*      */ import sun.net.util.IPAddressUtil;
/*      */ 
/*      */ public class DFSClient
/*      */   implements FSConstants, Closeable
/*      */ {
/*   79 */   public static final Log LOG = LogFactory.getLog(DFSClient.class);
/*      */   public static final int MAX_BLOCK_ACQUIRE_FAILURES = 3;
/*      */   private static final int TCP_WINDOW_SIZE = 131072;
/*      */   public final ClientProtocol namenode;
/*      */   final ClientProtocol rpcNamenode;
/*      */   private final InetSocketAddress nnAddress;
/*      */   final UserGroupInformation ugi;
/*   86 */   volatile boolean clientRunning = true;
/*   87 */   static Random r = new Random();
/*      */   final String clientName;
/*      */   private Configuration conf;
/*      */   private long defaultBlockSize;
/*      */   private short defaultReplication;
/*      */   private SocketFactory socketFactory;
/*      */   private int socketTimeout;
/*      */   private int datanodeWriteTimeout;
/*      */   private int timeoutValue;
/*      */   final int writePacketSize;
/*      */   private final FileSystem.Statistics stats;
/*      */   private int maxBlockAcquireFailures;
/*      */   private boolean shortCircuitLocalReads;
/*      */   private boolean connectToDnViaHostname;
/*      */   private SocketAddress[] localInterfaceAddrs;
/*  108 */   private volatile boolean serverSupportsHdfs630 = true;
/*  109 */   private volatile boolean serverSupportsHdfs200 = true;
/*      */   final int hdfsTimeout;
/*      */   private final String authority;
/*  118 */   private final Map<String, DFSOutputStream> filesBeingWritten = new HashMap();
/*      */ 
/*  523 */   private static Map<String, Boolean> localAddrMap = Collections.synchronizedMap(new HashMap());
/*      */ 
/*      */   public static ClientProtocol createNamenode(Configuration conf)
/*      */     throws IOException
/*      */   {
/*  123 */     return createNamenode(NameNode.getAddress(conf), conf);
/*      */   }
/*      */ 
/*      */   public static ClientProtocol createNamenode(InetSocketAddress nameNodeAddr, Configuration conf) throws IOException
/*      */   {
/*  128 */     return createNamenode(createRPCNamenode(nameNodeAddr, conf, UserGroupInformation.getCurrentUser()), conf);
/*      */   }
/*      */ 
/*      */   private static ClientProtocol createRPCNamenode(InetSocketAddress nameNodeAddr, Configuration conf, UserGroupInformation ugi)
/*      */     throws IOException
/*      */   {
/*  135 */     return (ClientProtocol)RPC.getProxy(ClientProtocol.class, 61L, nameNodeAddr, ugi, conf, NetUtils.getSocketFactory(conf, ClientProtocol.class), 0, RetryUtils.getMultipleLinearRandomRetry(conf, "dfs.client.retry.policy.enabled", false, "dfs.client.retry.policy.spec", "10000,6,60000,10"), false);
/*      */   }
/*      */ 
/*      */   private static ClientProtocol createNamenode(ClientProtocol rpcNamenode, Configuration conf)
/*      */     throws IOException
/*      */   {
/*  152 */     RetryPolicy defaultPolicy = RetryUtils.getDefaultRetryPolicy(conf, "dfs.client.retry.policy.enabled", false, "dfs.client.retry.policy.spec", "10000,6,60000,10", new Class[] { SafeModeException.class });
/*      */ 
/*  163 */     RetryPolicy createPolicy = RetryPolicies.retryUpToMaximumCountWithFixedSleep(5, 60000L, TimeUnit.MILLISECONDS);
/*      */ 
/*  166 */     Map remoteExceptionToPolicyMap = new HashMap();
/*      */ 
/*  168 */     remoteExceptionToPolicyMap.put(AlreadyBeingCreatedException.class, createPolicy);
/*      */ 
/*  170 */     Map exceptionToPolicyMap = new HashMap();
/*      */ 
/*  172 */     exceptionToPolicyMap.put(RemoteException.class, RetryPolicies.retryByRemoteException(defaultPolicy, remoteExceptionToPolicyMap));
/*      */ 
/*  175 */     RetryPolicy methodPolicy = RetryPolicies.retryByException(defaultPolicy, exceptionToPolicyMap);
/*      */ 
/*  177 */     Map methodNameToPolicyMap = new HashMap();
/*      */ 
/*  179 */     methodNameToPolicyMap.put("create", methodPolicy);
/*      */ 
/*  181 */     ClientProtocol cp = (ClientProtocol)RetryProxy.create(ClientProtocol.class, rpcNamenode, defaultPolicy, methodNameToPolicyMap);
/*      */ 
/*  183 */     RPC.checkVersion(ClientProtocol.class, 61L, cp);
/*  184 */     return cp;
/*      */   }
/*      */ 
/*      */   static ClientDatanodeProtocol createClientDatanodeProtocolProxy(DatanodeInfo di, Configuration conf, Block block, Token<BlockTokenIdentifier> token, int socketTimeout, boolean connectToDnViaHostname)
/*      */     throws IOException
/*      */   {
/*  192 */     String dnName = di.getNameWithIpcPort(connectToDnViaHostname);
/*  193 */     LOG.debug(new StringBuilder().append("Connecting to ").append(dnName).toString());
/*  194 */     InetSocketAddress addr = NetUtils.createSocketAddr(dnName);
/*  195 */     if (ClientDatanodeProtocol.LOG.isDebugEnabled()) {
/*  196 */       ClientDatanodeProtocol.LOG.info(new StringBuilder().append("ClientDatanodeProtocol addr=").append(addr).toString());
/*      */     }
/*  198 */     UserGroupInformation ticket = UserGroupInformation.createRemoteUser(block.toString());
/*      */ 
/*  200 */     ticket.addToken(token);
/*  201 */     return (ClientDatanodeProtocol)RPC.getProxy(ClientDatanodeProtocol.class, 4L, addr, ticket, conf, NetUtils.getDefaultSocketFactory(conf), socketTimeout);
/*      */   }
/*      */ 
/*      */   static ClientDatanodeProtocol createClientDatanodeProtocolProxy(DatanodeInfo di, Configuration conf, int socketTimeout, boolean connectToDnViaHostname)
/*      */     throws IOException
/*      */   {
/*  210 */     String dnName = di.getNameWithIpcPort(connectToDnViaHostname);
/*  211 */     LOG.debug(new StringBuilder().append("Connecting to ").append(dnName).toString());
/*  212 */     InetSocketAddress addr = NetUtils.createSocketAddr(dnName);
/*  213 */     if (ClientDatanodeProtocol.LOG.isDebugEnabled()) {
/*  214 */       ClientDatanodeProtocol.LOG.info(new StringBuilder().append("ClientDatanodeProtocol addr=").append(addr).toString());
/*      */     }
/*  216 */     return (ClientDatanodeProtocol)RPC.getProxy(ClientDatanodeProtocol.class, 4L, addr, conf, NetUtils.getDefaultSocketFactory(conf), socketTimeout);
/*      */   }
/*      */ 
/*      */   public DFSClient(Configuration conf)
/*      */     throws IOException
/*      */   {
/*  226 */     this(NameNode.getAddress(conf), conf);
/*      */   }
/*      */ 
/*      */   public DFSClient(InetSocketAddress nameNodeAddr, Configuration conf)
/*      */     throws IOException
/*      */   {
/*  235 */     this(nameNodeAddr, conf, null);
/*      */   }
/*      */ 
/*      */   public DFSClient(InetSocketAddress nameNodeAddr, Configuration conf, FileSystem.Statistics stats)
/*      */     throws IOException
/*      */   {
/*  245 */     this(nameNodeAddr, null, conf, stats);
/*      */   }
/*      */ 
/*      */   DFSClient(InetSocketAddress nameNodeAddr, ClientProtocol rpcNamenode, Configuration conf, FileSystem.Statistics stats)
/*      */     throws IOException
/*      */   {
/*  255 */     this.conf = conf;
/*  256 */     this.stats = stats;
/*  257 */     this.nnAddress = nameNodeAddr;
/*  258 */     this.socketTimeout = conf.getInt("dfs.socket.timeout", 60000);
/*      */ 
/*  260 */     this.datanodeWriteTimeout = conf.getInt("dfs.datanode.socket.write.timeout", 480000);
/*      */ 
/*  262 */     this.timeoutValue = this.socketTimeout;
/*  263 */     this.socketFactory = NetUtils.getSocketFactory(conf, ClientProtocol.class);
/*      */ 
/*  265 */     this.writePacketSize = conf.getInt("dfs.write.packet.size", 65536);
/*  266 */     this.maxBlockAcquireFailures = getMaxBlockAcquireFailures(conf);
/*      */ 
/*  268 */     this.hdfsTimeout = Client.getTimeout(conf);
/*  269 */     this.ugi = UserGroupInformation.getCurrentUser();
/*  270 */     this.authority = (nameNodeAddr == null ? "null" : new StringBuilder().append(nameNodeAddr.getHostName()).append(":").append(nameNodeAddr.getPort()).toString());
/*      */ 
/*  272 */     String taskId = conf.get("mapred.task.id", "NONMAPREDUCE");
/*  273 */     this.clientName = new StringBuilder().append("DFSClient_").append(taskId).append("_").append(r.nextInt()).append("_").append(Thread.currentThread().getId()).toString();
/*      */ 
/*  276 */     this.defaultBlockSize = conf.getLong("dfs.block.size", 67108864L);
/*  277 */     this.defaultReplication = (short)conf.getInt("dfs.replication", 3);
/*      */ 
/*  279 */     if ((nameNodeAddr != null) && (rpcNamenode == null)) {
/*  280 */       this.rpcNamenode = createRPCNamenode(nameNodeAddr, conf, this.ugi);
/*  281 */       this.namenode = createNamenode(this.rpcNamenode, conf);
/*  282 */     } else if ((nameNodeAddr == null) && (rpcNamenode != null))
/*      */     {
/*  284 */       this.namenode = (this.rpcNamenode = rpcNamenode);
/*      */     } else {
/*  286 */       throw new IllegalArgumentException(new StringBuilder().append("Expecting exactly one of nameNodeAddr and rpcNamenode being null: nameNodeAddr=").append(nameNodeAddr).append(", rpcNamenode=").append(rpcNamenode).toString());
/*      */     }
/*      */ 
/*  291 */     this.shortCircuitLocalReads = conf.getBoolean("dfs.client.read.shortcircuit", false);
/*      */ 
/*  294 */     if (LOG.isDebugEnabled()) {
/*  295 */       LOG.debug(new StringBuilder().append("Short circuit read is ").append(this.shortCircuitLocalReads).toString());
/*      */     }
/*  297 */     this.connectToDnViaHostname = conf.getBoolean("dfs.client.use.datanode.hostname", false);
/*      */ 
/*  300 */     if (LOG.isDebugEnabled()) {
/*  301 */       LOG.debug(new StringBuilder().append("Connect to datanode via hostname is ").append(this.connectToDnViaHostname).toString());
/*      */     }
/*  303 */     String[] localInterfaces = conf.getStrings("dfs.client.local.interfaces");
/*      */ 
/*  305 */     if (null == localInterfaces) {
/*  306 */       localInterfaces = new String[0];
/*      */     }
/*  308 */     this.localInterfaceAddrs = getLocalInterfaceAddrs(localInterfaces);
/*  309 */     if ((LOG.isDebugEnabled()) && (0 != localInterfaces.length))
/*  310 */       LOG.debug(new StringBuilder().append("Using local interfaces [").append(StringUtils.join(",", localInterfaces)).append("] with addresses [").append(StringUtils.join(",", this.localInterfaceAddrs)).append("]").toString());
/*      */   }
/*      */ 
/*      */   static int getMaxBlockAcquireFailures(Configuration conf)
/*      */   {
/*  317 */     return conf.getInt("dfs.client.max.block.acquire.failures", 3);
/*      */   }
/*      */ 
/*      */   private void checkOpen() throws IOException
/*      */   {
/*  322 */     if (!this.clientRunning) {
/*  323 */       IOException result = new IOException("Filesystem closed");
/*  324 */       throw result;
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized LeaseRenewer getLeaseRenewer()
/*      */     throws IOException
/*      */   {
/*  333 */     return LeaseRenewer.getInstance(this.authority, this.ugi, this);
/*      */   }
/*      */ 
/*      */   private void beginFileLease(String src, DFSOutputStream out)
/*      */     throws IOException
/*      */   {
/*  339 */     getLeaseRenewer().put(src, out, this);
/*      */   }
/*      */ 
/*      */   void endFileLease(String src) throws IOException
/*      */   {
/*  344 */     getLeaseRenewer().closeFile(src, this);
/*      */   }
/*      */ 
/*      */   void putFileBeingWritten(String src, DFSOutputStream out)
/*      */   {
/*  353 */     synchronized (this.filesBeingWritten) {
/*  354 */       this.filesBeingWritten.put(src, out);
/*      */     }
/*      */   }
/*      */ 
/*      */   void removeFileBeingWritten(String src)
/*      */   {
/*  360 */     synchronized (this.filesBeingWritten) {
/*  361 */       this.filesBeingWritten.remove(src);
/*      */     }
/*      */   }
/*      */ 
/*      */   boolean isFilesBeingWrittenEmpty()
/*      */   {
/*  367 */     synchronized (this.filesBeingWritten) {
/*  368 */       return this.filesBeingWritten.isEmpty();
/*      */     }
/*      */   }
/*      */ 
/*      */   boolean renewLease()
/*      */     throws IOException
/*      */   {
/*  378 */     if ((this.clientRunning) && (!isFilesBeingWrittenEmpty())) {
/*  379 */       this.namenode.renewLease(this.clientName);
/*  380 */       return true;
/*      */     }
/*  382 */     return false;
/*      */   }
/*      */ 
/*      */   void abort()
/*      */   {
/*  387 */     this.clientRunning = false;
/*  388 */     closeAllFilesBeingWritten(true);
/*      */     try
/*      */     {
/*  393 */       getLeaseRenewer().closeClient(this);
/*      */     } catch (IOException ioe) {
/*  395 */       LOG.info(new StringBuilder().append("Exception occurred while aborting the client. ").append(ioe).toString());
/*      */     }
/*  397 */     RPC.stopProxy(this.rpcNamenode);
/*      */   }
/*      */ 
/*      */   private void closeAllFilesBeingWritten(boolean abort)
/*      */   {
/*      */     while (true)
/*      */     {
/*      */       String src;
/*      */       DFSOutputStream out;
/*  405 */       synchronized (this.filesBeingWritten) {
/*  406 */         if (this.filesBeingWritten.isEmpty()) {
/*  407 */           return;
/*      */         }
/*  409 */         src = (String)this.filesBeingWritten.keySet().iterator().next();
/*  410 */         out = (DFSOutputStream)this.filesBeingWritten.remove(src);
/*      */       }
/*  412 */       if (out != null)
/*      */         try {
/*  414 */           if (abort)
/*  415 */             out.abort();
/*      */           else
/*  417 */             out.close();
/*      */         }
/*      */         catch (IOException ie) {
/*  420 */           LOG.error(new StringBuilder().append("Failed to ").append(abort ? "abort" : "close").append(" file ").append(src).toString(), ie);
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void close()
/*      */     throws IOException
/*      */   {
/*  432 */     if (this.clientRunning) {
/*  433 */       closeAllFilesBeingWritten(false);
/*  434 */       this.clientRunning = false;
/*      */ 
/*  436 */       getLeaseRenewer().closeClient(this);
/*      */ 
/*  438 */       RPC.stopProxy(this.rpcNamenode);
/*      */     }
/*      */   }
/*      */ 
/*      */   public long getDefaultBlockSize()
/*      */   {
/*  447 */     return this.defaultBlockSize;
/*      */   }
/*      */ 
/*      */   public long getBlockSize(String f) throws IOException {
/*      */     try {
/*  452 */       return this.namenode.getPreferredBlockSize(f);
/*      */     } catch (IOException ie) {
/*  454 */       LOG.warn(new StringBuilder().append("Problem getting block size: ").append(StringUtils.stringifyException(ie)).toString());
/*      */ 
/*  456 */       throw ie;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static String stringifyToken(Token<DelegationTokenIdentifier> token)
/*      */     throws IOException
/*      */   {
/*  463 */     DelegationTokenIdentifier ident = new DelegationTokenIdentifier();
/*  464 */     ByteArrayInputStream buf = new ByteArrayInputStream(token.getIdentifier());
/*  465 */     DataInputStream in = new DataInputStream(buf);
/*  466 */     ident.readFields(in);
/*  467 */     String str = new StringBuilder().append(ident.getKind()).append(" token ").append(ident.getSequenceNumber()).append(" for ").append(ident.getUser().getShortUserName()).toString();
/*      */ 
/*  469 */     if (token.getService().getLength() > 0) {
/*  470 */       return new StringBuilder().append(str).append(" on ").append(token.getService()).toString();
/*      */     }
/*  472 */     return str;
/*      */   }
/*      */ 
/*      */   public Token<DelegationTokenIdentifier> getDelegationToken(Text renewer)
/*      */     throws IOException
/*      */   {
/*  478 */     Token result = this.namenode.getDelegationToken(renewer);
/*      */ 
/*  480 */     SecurityUtil.setTokenService(result, this.nnAddress);
/*  481 */     LOG.info(new StringBuilder().append("Created ").append(stringifyToken(result)).toString());
/*  482 */     return result;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public long renewDelegationToken(Token<DelegationTokenIdentifier> token)
/*      */     throws SecretManager.InvalidToken, IOException
/*      */   {
/*      */     try
/*      */     {
/*  496 */       return token.renew(this.conf);
/*      */     } catch (InterruptedException ie) {
/*  498 */       throw new RuntimeException("caught interrupted", ie);
/*      */     } catch (RemoteException re) {
/*  500 */       throw re.unwrapRemoteException(new Class[] { SecretManager.InvalidToken.class, AccessControlException.class });
/*      */     }
/*      */   }
/*      */ 
/*      */   private BlockReader getLocalBlockReader(Configuration conf, String src, Block blk, Token<BlockTokenIdentifier> accessToken, DatanodeInfo chosenNode, int socketTimeout, long offsetIntoBlock)
/*      */     throws SecretManager.InvalidToken, IOException
/*      */   {
/*      */     try
/*      */     {
/*  513 */       return BlockReaderLocal.newBlockReader(conf, src, blk, accessToken, chosenNode, socketTimeout, offsetIntoBlock, blk.getNumBytes() - offsetIntoBlock, this.connectToDnViaHostname);
/*      */     }
/*      */     catch (RemoteException re)
/*      */     {
/*  517 */       throw re.unwrapRemoteException(new Class[] { SecretManager.InvalidToken.class, AccessControlException.class });
/*      */     }
/*      */   }
/*      */ 
/*      */   private static boolean isLocalAddress(InetSocketAddress targetAddr)
/*      */   {
/*  527 */     InetAddress addr = targetAddr.getAddress();
/*  528 */     Boolean cached = (Boolean)localAddrMap.get(addr.getHostAddress());
/*  529 */     if (cached != null) {
/*  530 */       if (LOG.isTraceEnabled()) {
/*  531 */         LOG.trace(new StringBuilder().append("Address ").append(targetAddr).append(cached.booleanValue() ? " is local" : " is not local").toString());
/*      */       }
/*      */ 
/*  534 */       return cached.booleanValue();
/*      */     }
/*      */ 
/*  538 */     boolean local = (addr.isAnyLocalAddress()) || (addr.isLoopbackAddress());
/*      */ 
/*  541 */     if (!local) {
/*      */       try {
/*  543 */         local = NetworkInterface.getByInetAddress(addr) != null;
/*      */       } catch (SocketException e) {
/*  545 */         local = false;
/*      */       }
/*      */     }
/*  548 */     if (LOG.isTraceEnabled()) {
/*  549 */       LOG.trace(new StringBuilder().append("Address ").append(targetAddr).append(local ? " is local" : " is not local").toString());
/*      */     }
/*      */ 
/*  552 */     localAddrMap.put(addr.getHostAddress(), Boolean.valueOf(local));
/*  553 */     return local;
/*      */   }
/*      */ 
/*      */   private static boolean tokenRefetchNeeded(IOException ex, InetSocketAddress targetAddr)
/*      */   {
/*  575 */     if (((ex instanceof InvalidBlockTokenException)) || ((ex instanceof SecretManager.InvalidToken))) {
/*  576 */       LOG.info(new StringBuilder().append("Access token was invalid when connecting to ").append(targetAddr).append(" : ").append(ex).toString());
/*      */ 
/*  578 */       return true;
/*      */     }
/*  580 */     return false;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public void cancelDelegationToken(Token<DelegationTokenIdentifier> token)
/*      */     throws SecretManager.InvalidToken, IOException
/*      */   {
/*      */     try
/*      */     {
/*  593 */       LOG.info(new StringBuilder().append("Cancelling ").append(stringifyToken(token)).toString());
/*  594 */       this.namenode.cancelDelegationToken(token);
/*      */     } catch (RemoteException re) {
/*  596 */       throw re.unwrapRemoteException(new Class[] { SecretManager.InvalidToken.class, AccessControlException.class });
/*      */     }
/*      */   }
/*      */ 
/*      */   public void reportBadBlocks(LocatedBlock[] blocks)
/*      */     throws IOException
/*      */   {
/*  654 */     this.namenode.reportBadBlocks(blocks);
/*      */   }
/*      */ 
/*      */   public short getDefaultReplication() {
/*  658 */     return this.defaultReplication;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public String[][] getHints(String src, long start, long length)
/*      */     throws IOException
/*      */   {
/*  678 */     BlockLocation[] blkLocations = getBlockLocations(src, start, length);
/*  679 */     if ((blkLocations == null) || (blkLocations.length == 0)) {
/*  680 */       return new String[0][];
/*      */     }
/*  682 */     int blkCount = blkLocations.length;
/*  683 */     String[][] hints = new String[blkCount][];
/*  684 */     for (int i = 0; i < blkCount; i++) {
/*  685 */       String[] hosts = blkLocations[i].getHosts();
/*  686 */       hints[i] = new String[hosts.length];
/*  687 */       hints[i] = hosts;
/*      */     }
/*  689 */     return hints;
/*      */   }
/*      */ 
/*      */   static LocatedBlocks callGetBlockLocations(ClientProtocol namenode, String src, long start, long length) throws IOException
/*      */   {
/*      */     try {
/*  695 */       return namenode.getBlockLocations(src, start, length);
/*      */     } catch (RemoteException re) {
/*  697 */       throw re.unwrapRemoteException(new Class[] { AccessControlException.class, FileNotFoundException.class });
/*      */     }
/*      */   }
/*      */ 
/*      */   public BlockLocation[] getBlockLocations(String src, long start, long length)
/*      */     throws IOException
/*      */   {
/*  716 */     LocatedBlocks blocks = callGetBlockLocations(this.namenode, src, start, length);
/*  717 */     return DFSUtil.locatedBlocks2Locations(blocks);
/*      */   }
/*      */ 
/*      */   public DFSInputStream open(String src) throws IOException {
/*  721 */     return open(src, this.conf.getInt("io.file.buffer.size", 4096), true, null);
/*      */   }
/*      */ 
/*      */   public DFSInputStream open(String src, int buffersize, boolean verifyChecksum, FileSystem.Statistics stats)
/*      */     throws IOException
/*      */   {
/*  733 */     checkOpen();
/*      */ 
/*  735 */     return new DFSInputStream(src, buffersize, verifyChecksum);
/*      */   }
/*      */ 
/*      */   public OutputStream create(String src, boolean overwrite)
/*      */     throws IOException
/*      */   {
/*  749 */     return create(src, overwrite, this.defaultReplication, this.defaultBlockSize, null);
/*      */   }
/*      */ 
/*      */   public OutputStream create(String src, boolean overwrite, Progressable progress)
/*      */     throws IOException
/*      */   {
/*  765 */     return create(src, overwrite, this.defaultReplication, this.defaultBlockSize, null);
/*      */   }
/*      */ 
/*      */   public OutputStream create(String src, boolean overwrite, short replication, long blockSize)
/*      */     throws IOException
/*      */   {
/*  783 */     return create(src, overwrite, replication, blockSize, null);
/*      */   }
/*      */ 
/*      */   public OutputStream create(String src, boolean overwrite, short replication, long blockSize, Progressable progress)
/*      */     throws IOException
/*      */   {
/*  804 */     return create(src, overwrite, replication, blockSize, progress, this.conf.getInt("io.file.buffer.size", 4096));
/*      */   }
/*      */ 
/*      */   public OutputStream create(String src, boolean overwrite, short replication, long blockSize, Progressable progress, int buffersize)
/*      */     throws IOException
/*      */   {
/*  820 */     return create(src, FsPermission.getDefault(), overwrite, replication, blockSize, progress, buffersize);
/*      */   }
/*      */ 
/*      */   public OutputStream create(String src, FsPermission permission, boolean overwrite, short replication, long blockSize, Progressable progress, int buffersize)
/*      */     throws IOException
/*      */   {
/*  836 */     return create(src, permission, overwrite, true, replication, blockSize, progress, buffersize);
/*      */   }
/*      */ 
/*      */   public OutputStream create(String src, FsPermission permission, boolean overwrite, boolean createParent, short replication, long blockSize, Progressable progress, int buffersize)
/*      */     throws IOException
/*      */   {
/*  864 */     checkOpen();
/*  865 */     if (permission == null) {
/*  866 */       permission = FsPermission.getDefault();
/*      */     }
/*  868 */     FsPermission masked = permission.applyUMask(FsPermission.getUMask(this.conf));
/*  869 */     LOG.debug(new StringBuilder().append(src).append(": masked=").append(masked).toString());
/*  870 */     DFSOutputStream result = new DFSOutputStream(src, masked, overwrite, createParent, replication, blockSize, progress, buffersize, this.conf.getInt("io.bytes.per.checksum", 512));
/*      */ 
/*  873 */     beginFileLease(src, result);
/*  874 */     return result;
/*      */   }
/*      */ 
/*      */   boolean recoverLease(String src)
/*      */     throws IOException
/*      */   {
/*  884 */     checkOpen();
/*      */     try
/*      */     {
/*  887 */       return this.namenode.recoverLease(src, this.clientName);
/*      */     } catch (RemoteException re) {
/*  889 */       throw re.unwrapRemoteException(new Class[] { FileNotFoundException.class, AccessControlException.class });
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean isFileClosed(String src)
/*      */     throws IOException
/*      */   {
/*  899 */     checkOpen();
/*      */     try {
/*  901 */       return this.namenode.isFileClosed(src);
/*      */     } catch (RemoteException re) {
/*  903 */       throw re.unwrapRemoteException(new Class[] { AccessControlException.class, FileNotFoundException.class });
/*      */     }
/*      */   }
/*      */ 
/*      */   public FSDataOutputStream append(String src, int buffersize, Progressable progress, FileSystem.Statistics statistics)
/*      */     throws IOException
/*      */   {
/*  922 */     DFSOutputStream out = append(src, buffersize, progress);
/*  923 */     return new FSDataOutputStream(out, statistics, out.getInitialLen());
/*      */   }
/*      */ 
/*      */   private DFSOutputStream append(String src, int buffersize, Progressable progress) throws IOException
/*      */   {
/*  928 */     checkOpen();
/*  929 */     HdfsFileStatus stat = null;
/*  930 */     LocatedBlock lastBlock = null;
/*      */     try {
/*  932 */       stat = getFileInfo(src);
/*  933 */       lastBlock = this.namenode.append(src, this.clientName);
/*      */     } catch (RemoteException re) {
/*  935 */       throw re.unwrapRemoteException(new Class[] { FileNotFoundException.class, AccessControlException.class, NSQuotaExceededException.class, DSQuotaExceededException.class });
/*      */     }
/*      */ 
/*  940 */     DFSOutputStream result = new DFSOutputStream(src, buffersize, progress, lastBlock, stat, this.conf.getInt("io.bytes.per.checksum", 512));
/*      */ 
/*  942 */     beginFileLease(src, result);
/*  943 */     return result;
/*      */   }
/*      */ 
/*      */   public boolean setReplication(String src, short replication)
/*      */     throws IOException
/*      */   {
/*      */     try
/*      */     {
/*  958 */       return this.namenode.setReplication(src, replication);
/*      */     } catch (RemoteException re) {
/*  960 */       throw re.unwrapRemoteException(new Class[] { AccessControlException.class, NSQuotaExceededException.class, DSQuotaExceededException.class });
/*      */     }
/*      */   }
/*      */ 
/*      */   public void concat(String trg, String[] srcs)
/*      */     throws IOException
/*      */   {
/*  971 */     checkOpen();
/*      */     try {
/*  973 */       this.namenode.concat(trg, srcs);
/*      */     } catch (RemoteException re) {
/*  975 */       throw re.unwrapRemoteException(new Class[] { AccessControlException.class });
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean rename(String src, String dst)
/*      */     throws IOException
/*      */   {
/*  984 */     checkOpen();
/*      */     try {
/*  986 */       return this.namenode.rename(src, dst);
/*      */     } catch (RemoteException re) {
/*  988 */       throw re.unwrapRemoteException(new Class[] { AccessControlException.class, NSQuotaExceededException.class, DSQuotaExceededException.class });
/*      */     }
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public boolean delete(String src)
/*      */     throws IOException
/*      */   {
/* 1000 */     checkOpen();
/* 1001 */     return this.namenode.delete(src, true);
/*      */   }
/*      */ 
/*      */   public boolean delete(String src, boolean recursive)
/*      */     throws IOException
/*      */   {
/* 1010 */     checkOpen();
/*      */     try {
/* 1012 */       return this.namenode.delete(src, recursive);
/*      */     } catch (RemoteException re) {
/* 1014 */       throw re.unwrapRemoteException(new Class[] { AccessControlException.class });
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean exists(String src)
/*      */     throws IOException
/*      */   {
/* 1021 */     checkOpen();
/* 1022 */     return getFileInfo(src) != null;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public boolean isDirectory(String src) throws IOException
/*      */   {
/* 1028 */     HdfsFileStatus fs = getFileInfo(src);
/* 1029 */     if (fs != null) {
/* 1030 */       return fs.isDir();
/*      */     }
/* 1032 */     throw new FileNotFoundException(new StringBuilder().append("File does not exist: ").append(src).toString());
/*      */   }
/*      */ 
/*      */   public DirectoryListing listPaths(String src, byte[] startAfter)
/*      */     throws IOException
/*      */   {
/* 1048 */     checkOpen();
/*      */     try {
/* 1050 */       return this.namenode.getListing(src, startAfter);
/*      */     } catch (RemoteException re) {
/* 1052 */       throw re.unwrapRemoteException(new Class[] { AccessControlException.class });
/*      */     }
/*      */   }
/*      */ 
/*      */   public HdfsFileStatus getFileInfo(String src) throws IOException {
/* 1057 */     checkOpen();
/*      */     try {
/* 1059 */       return this.namenode.getFileInfo(src);
/*      */     } catch (RemoteException re) {
/* 1061 */       throw re.unwrapRemoteException(new Class[] { AccessControlException.class });
/*      */     }
/*      */   }
/*      */ 
/*      */   private static SocketAddress[] getLocalInterfaceAddrs(String[] interfaceNames)
/*      */     throws UnknownHostException
/*      */   {
/* 1082 */     List localAddrs = new ArrayList();
/* 1083 */     for (String interfaceName : interfaceNames) {
/* 1084 */       if (IPAddressUtil.isIPv4LiteralAddress(interfaceName))
/* 1085 */         localAddrs.add(new InetSocketAddress(interfaceName, 0));
/* 1086 */       else if (NetUtils.isValidSubnet(interfaceName)) {
/* 1087 */         for (InetAddress addr : NetUtils.getIPs(interfaceName, false))
/* 1088 */           localAddrs.add(new InetSocketAddress(addr, 0));
/*      */       }
/*      */       else {
/* 1091 */         for (String ip : DNS.getIPs(interfaceName, false)) {
/* 1092 */           localAddrs.add(new InetSocketAddress(ip, 0));
/*      */         }
/*      */       }
/*      */     }
/* 1096 */     return (SocketAddress[])localAddrs.toArray(new SocketAddress[localAddrs.size()]);
/*      */   }
/*      */ 
/*      */   private SocketAddress getRandomLocalInterfaceAddr()
/*      */   {
/* 1108 */     if (this.localInterfaceAddrs.length == 0) {
/* 1109 */       return null;
/*      */     }
/* 1111 */     int idx = r.nextInt(this.localInterfaceAddrs.length);
/* 1112 */     SocketAddress addr = this.localInterfaceAddrs[idx];
/* 1113 */     if (LOG.isDebugEnabled()) {
/* 1114 */       LOG.debug(new StringBuilder().append("Using local interface ").append(addr).toString());
/*      */     }
/* 1116 */     return addr;
/*      */   }
/*      */ 
/*      */   public MD5MD5CRC32FileChecksum getFileChecksum(String src)
/*      */     throws IOException
/*      */   {
/* 1126 */     checkOpen();
/* 1127 */     return getFileChecksum(src, this.namenode, this.socketFactory, this.socketTimeout, this.connectToDnViaHostname);
/*      */   }
/*      */ 
/*      */   public static MD5MD5CRC32FileChecksum getFileChecksum(String src, ClientProtocol namenode, SocketFactory socketFactory, int socketTimeout)
/*      */     throws IOException
/*      */   {
/* 1138 */     return getFileChecksum(src, namenode, socketFactory, socketTimeout, false);
/*      */   }
/*      */ 
/*      */   private static MD5MD5CRC32FileChecksum getFileChecksum(String src, ClientProtocol namenode, SocketFactory socketFactory, int socketTimeout, boolean connectToDnViaHostname)
/*      */     throws IOException
/*      */   {
/* 1145 */     LocatedBlocks blockLocations = callGetBlockLocations(namenode, src, 0L, 9223372036854775807L);
/* 1146 */     if (null == blockLocations) {
/* 1147 */       throw new FileNotFoundException(new StringBuilder().append("File does not exist: ").append(src).toString());
/*      */     }
/* 1149 */     List locatedblocks = blockLocations.getLocatedBlocks();
/* 1150 */     DataOutputBuffer md5out = new DataOutputBuffer();
/* 1151 */     int bytesPerCRC = 0;
/* 1152 */     long crcPerBlock = 0L;
/* 1153 */     boolean refetchBlocks = false;
/* 1154 */     int lastRetriedIndex = -1;
/*      */ 
/* 1157 */     for (int i = 0; i < locatedblocks.size(); i++) {
/* 1158 */       if (refetchBlocks) {
/* 1159 */         blockLocations = callGetBlockLocations(namenode, src, 0L, 9223372036854775807L);
/* 1160 */         if (null == blockLocations) {
/* 1161 */           throw new FileNotFoundException(new StringBuilder().append("File does not exist: ").append(src).toString());
/*      */         }
/* 1163 */         locatedblocks = blockLocations.getLocatedBlocks();
/* 1164 */         refetchBlocks = false;
/*      */       }
/* 1166 */       LocatedBlock lb = (LocatedBlock)locatedblocks.get(i);
/* 1167 */       Block block = lb.getBlock();
/* 1168 */       DatanodeInfo[] datanodes = lb.getLocations();
/*      */ 
/* 1171 */       int timeout = socketTimeout > 0 ? socketTimeout + 3000 * datanodes.length : 0;
/*      */ 
/* 1174 */       boolean done = false;
/* 1175 */       for (int j = 0; (!done) && (j < datanodes.length); j++) {
/* 1176 */         String dnName = datanodes[j].getName(connectToDnViaHostname);
/* 1177 */         Socket sock = null;
/* 1178 */         DataOutputStream out = null;
/* 1179 */         DataInputStream in = null;
/*      */         try
/*      */         {
/* 1183 */           sock = socketFactory.createSocket();
/* 1184 */           LOG.debug(new StringBuilder().append("Connecting to ").append(dnName).toString());
/* 1185 */           NetUtils.connect(sock, NetUtils.createSocketAddr(dnName), timeout);
/* 1186 */           sock.setSoTimeout(timeout);
/*      */ 
/* 1188 */           out = new DataOutputStream(new BufferedOutputStream(NetUtils.getOutputStream(sock), DataNode.SMALL_BUFFER_SIZE));
/*      */ 
/* 1191 */           in = new DataInputStream(NetUtils.getInputStream(sock));
/*      */ 
/* 1193 */           if (LOG.isDebugEnabled()) {
/* 1194 */             LOG.debug(new StringBuilder().append("write to ").append(dnName).append(": ").append(85).append(", block=").append(block).toString());
/*      */           }
/*      */ 
/* 1199 */           out.writeShort(17);
/* 1200 */           out.write(85);
/* 1201 */           out.writeLong(block.getBlockId());
/* 1202 */           out.writeLong(block.getGenerationStamp());
/* 1203 */           lb.getBlockToken().write(out);
/* 1204 */           out.flush();
/*      */ 
/* 1206 */           short reply = in.readShort();
/* 1207 */           if (reply != 0) {
/* 1208 */             if ((reply == 5) && (i > lastRetriedIndex))
/*      */             {
/* 1210 */               if (LOG.isDebugEnabled()) {
/* 1211 */                 LOG.debug(new StringBuilder().append("Got access token error in response to OP_BLOCK_CHECKSUM for file ").append(src).append(" for block ").append(block).append(" from datanode ").append(dnName).append(". Will retry the block once.").toString());
/*      */               }
/*      */ 
/* 1216 */               lastRetriedIndex = i;
/* 1217 */               done = true;
/* 1218 */               i--;
/* 1219 */               refetchBlocks = true;
/*      */ 
/* 1259 */               IOUtils.closeStream(in);
/* 1260 */               IOUtils.closeStream(out);
/* 1261 */               IOUtils.closeSocket(sock); break;
/*      */             }
/* 1222 */             throw new IOException(new StringBuilder().append("Bad response ").append(reply).append(" for block ").append(block).append(" from datanode ").append(dnName).toString());
/*      */           }
/*      */ 
/* 1228 */           int bpc = in.readInt();
/* 1229 */           if (i == 0) {
/* 1230 */             bytesPerCRC = bpc;
/*      */           }
/* 1232 */           else if (bpc != bytesPerCRC) {
/* 1233 */             throw new IOException(new StringBuilder().append("Byte-per-checksum not matched: bpc=").append(bpc).append(" but bytesPerCRC=").append(bytesPerCRC).toString());
/*      */           }
/*      */ 
/* 1238 */           long cpb = in.readLong();
/* 1239 */           if ((locatedblocks.size() > 1) && (i == 0)) {
/* 1240 */             crcPerBlock = cpb;
/*      */           }
/*      */ 
/* 1244 */           MD5Hash md5 = MD5Hash.read(in);
/* 1245 */           md5.write(md5out);
/*      */ 
/* 1247 */           done = true;
/*      */ 
/* 1249 */           if (LOG.isDebugEnabled()) {
/* 1250 */             if (i == 0) {
/* 1251 */               LOG.debug(new StringBuilder().append("set bytesPerCRC=").append(bytesPerCRC).append(", crcPerBlock=").append(crcPerBlock).toString());
/*      */             }
/*      */ 
/* 1254 */             LOG.debug(new StringBuilder().append("got reply from ").append(dnName).append(": md5=").append(md5).toString());
/*      */           }
/*      */         } catch (IOException ie) {
/* 1257 */           LOG.warn(new StringBuilder().append("src=").append(src).append(", datanodes[").append(j).append("]=").append(dnName).toString(), ie);
/*      */         } finally {
/* 1259 */           IOUtils.closeStream(in);
/* 1260 */           IOUtils.closeStream(out);
/* 1261 */           IOUtils.closeSocket(sock);
/*      */         }
/*      */       }
/*      */ 
/* 1265 */       if (!done) {
/* 1266 */         throw new IOException(new StringBuilder().append("Fail to get block MD5 for ").append(block).toString());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1271 */     MD5Hash fileMD5 = MD5Hash.digest(md5out.getData());
/* 1272 */     return new MD5MD5CRC32FileChecksum(bytesPerCRC, crcPerBlock, fileMD5);
/*      */   }
/*      */ 
/*      */   public void setPermission(String src, FsPermission permission)
/*      */     throws IOException
/*      */   {
/* 1283 */     checkOpen();
/*      */     try {
/* 1285 */       this.namenode.setPermission(src, permission);
/*      */     } catch (RemoteException re) {
/* 1287 */       throw re.unwrapRemoteException(new Class[] { AccessControlException.class, FileNotFoundException.class });
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setOwner(String src, String username, String groupname)
/*      */     throws IOException
/*      */   {
/* 1301 */     checkOpen();
/*      */     try {
/* 1303 */       this.namenode.setOwner(src, username, groupname);
/*      */     } catch (RemoteException re) {
/* 1305 */       throw re.unwrapRemoteException(new Class[] { AccessControlException.class, FileNotFoundException.class });
/*      */     }
/*      */   }
/*      */ 
/*      */   public DistributedFileSystem.DiskStatus getDiskStatus() throws IOException
/*      */   {
/* 1311 */     long[] rawNums = this.namenode.getStats();
/* 1312 */     return new DistributedFileSystem.DiskStatus(rawNums[0], rawNums[1], rawNums[2]);
/*      */   }
/*      */ 
/*      */   public long totalRawCapacity() throws IOException
/*      */   {
/* 1317 */     long[] rawNums = this.namenode.getStats();
/* 1318 */     return rawNums[0];
/*      */   }
/*      */ 
/*      */   public long totalRawUsed()
/*      */     throws IOException
/*      */   {
/* 1324 */     long[] rawNums = this.namenode.getStats();
/* 1325 */     return rawNums[1];
/*      */   }
/*      */ 
/*      */   public long getMissingBlocksCount()
/*      */     throws IOException
/*      */   {
/* 1334 */     return this.namenode.getStats()[5];
/*      */   }
/*      */ 
/*      */   public long getUnderReplicatedBlocksCount()
/*      */     throws IOException
/*      */   {
/* 1342 */     return this.namenode.getStats()[3];
/*      */   }
/*      */ 
/*      */   public long getCorruptBlocksCount()
/*      */     throws IOException
/*      */   {
/* 1350 */     return this.namenode.getStats()[4];
/*      */   }
/*      */ 
/*      */   public DatanodeInfo[] datanodeReport(FSConstants.DatanodeReportType type) throws IOException
/*      */   {
/* 1355 */     return this.namenode.getDatanodeReport(type);
/*      */   }
/*      */ 
/*      */   public boolean setSafeMode(FSConstants.SafeModeAction action)
/*      */     throws IOException
/*      */   {
/* 1366 */     return this.namenode.setSafeMode(action);
/*      */   }
/*      */ 
/*      */   void saveNamespace()
/*      */     throws AccessControlException, IOException
/*      */   {
/*      */     try
/*      */     {
/* 1378 */       this.namenode.saveNamespace();
/*      */     } catch (RemoteException re) {
/* 1380 */       throw re.unwrapRemoteException(new Class[] { AccessControlException.class });
/*      */     }
/*      */   }
/*      */ 
/*      */   public void refreshNodes()
/*      */     throws IOException
/*      */   {
/* 1392 */     this.namenode.refreshNodes();
/*      */   }
/*      */ 
/*      */   public void metaSave(String pathname)
/*      */     throws IOException
/*      */   {
/* 1403 */     this.namenode.metaSave(pathname);
/*      */   }
/*      */ 
/*      */   public void setBalancerBandwidth(long bandwidth)
/*      */     throws IOException
/*      */   {
/* 1415 */     this.namenode.setBalancerBandwidth(bandwidth);
/*      */   }
/*      */ 
/*      */   public void finalizeUpgrade()
/*      */     throws IOException
/*      */   {
/* 1422 */     this.namenode.finalizeUpgrade();
/*      */   }
/*      */ 
/*      */   public UpgradeStatusReport distributedUpgradeProgress(FSConstants.UpgradeAction action)
/*      */     throws IOException
/*      */   {
/* 1430 */     return this.namenode.distributedUpgradeProgress(action);
/*      */   }
/*      */ 
/*      */   public boolean mkdirs(String src)
/*      */     throws IOException
/*      */   {
/* 1436 */     return mkdirs(src, null);
/*      */   }
/*      */ 
/*      */   public boolean mkdirs(String src, FsPermission permission)
/*      */     throws IOException
/*      */   {
/* 1450 */     checkOpen();
/* 1451 */     if (permission == null) {
/* 1452 */       permission = FsPermission.getDefault();
/*      */     }
/* 1454 */     FsPermission masked = permission.applyUMask(FsPermission.getUMask(this.conf));
/* 1455 */     LOG.debug(new StringBuilder().append(src).append(": masked=").append(masked).toString());
/*      */     try {
/* 1457 */       return this.namenode.mkdirs(src, masked);
/*      */     } catch (RemoteException re) {
/* 1459 */       throw re.unwrapRemoteException(new Class[] { AccessControlException.class, NSQuotaExceededException.class, DSQuotaExceededException.class });
/*      */     }
/*      */   }
/*      */ 
/*      */   ContentSummary getContentSummary(String src) throws IOException
/*      */   {
/*      */     try
/*      */     {
/* 1467 */       return this.namenode.getContentSummary(src);
/*      */     } catch (RemoteException re) {
/* 1469 */       throw re.unwrapRemoteException(new Class[] { AccessControlException.class, FileNotFoundException.class });
/*      */     }
/*      */   }
/*      */ 
/*      */   void setQuota(String src, long namespaceQuota, long diskspaceQuota)
/*      */     throws IOException
/*      */   {
/* 1481 */     if (((namespaceQuota <= 0L) && (namespaceQuota != 9223372036854775807L) && (namespaceQuota != -1L)) || ((diskspaceQuota <= 0L) && (diskspaceQuota != 9223372036854775807L) && (diskspaceQuota != -1L)))
/*      */     {
/* 1485 */       throw new IllegalArgumentException(new StringBuilder().append("Invalid values for quota : ").append(namespaceQuota).append(" and ").append(diskspaceQuota).toString());
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/* 1492 */       this.namenode.setQuota(src, namespaceQuota, diskspaceQuota);
/*      */     } catch (RemoteException re) {
/* 1494 */       throw re.unwrapRemoteException(new Class[] { AccessControlException.class, FileNotFoundException.class, NSQuotaExceededException.class, DSQuotaExceededException.class });
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setTimes(String src, long mtime, long atime)
/*      */     throws IOException
/*      */   {
/* 1506 */     checkOpen();
/*      */     try {
/* 1508 */       this.namenode.setTimes(src, mtime, atime);
/*      */     } catch (RemoteException re) {
/* 1510 */       throw re.unwrapRemoteException(new Class[] { AccessControlException.class, FileNotFoundException.class });
/*      */     }
/*      */   }
/*      */ 
/*      */   private DatanodeInfo bestNode(DatanodeInfo[] nodes, AbstractMap<DatanodeInfo, DatanodeInfo> deadNodes)
/*      */     throws IOException
/*      */   {
/* 1522 */     if (nodes != null) {
/* 1523 */       for (int i = 0; i < nodes.length; i++) {
/* 1524 */         if (!deadNodes.containsKey(nodes[i])) {
/* 1525 */           return nodes[i];
/*      */         }
/*      */       }
/*      */     }
/* 1529 */     throw new IOException("No live nodes contain current block");
/*      */   }
/*      */ 
/*      */   void reportChecksumFailure(String file, Block blk, DatanodeInfo dn)
/*      */   {
/* 4171 */     DatanodeInfo[] dnArr = { dn };
/* 4172 */     LocatedBlock[] lblocks = { new LocatedBlock(blk, dnArr) };
/* 4173 */     reportChecksumFailure(file, lblocks);
/*      */   }
/*      */ 
/*      */   void reportChecksumFailure(String file, LocatedBlock[] lblocks)
/*      */   {
/*      */     try {
/* 4179 */       reportBadBlocks(lblocks);
/*      */     } catch (IOException ie) {
/* 4181 */       LOG.info(new StringBuilder().append("Found corruption while reading ").append(file).append(".  Error repairing corrupt blocks.  Bad blocks remain. ").append(StringUtils.stringifyException(ie)).toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/* 4189 */     return new StringBuilder().append(getClass().getSimpleName()).append("[clientName=").append(this.clientName).append(", ugi=").append(this.ugi).append("]").toString();
/*      */   }
/*      */ 
/*      */   class DFSOutputStream extends FSOutputSummer
/*      */     implements Syncable
/*      */   {
/*      */     private Socket s;
/* 2785 */     boolean closed = false;
/*      */     private String src;
/*      */     private DataOutputStream blockStream;
/*      */     private DataInputStream blockReplyStream;
/*      */     private Block block;
/*      */     private Token<BlockTokenIdentifier> accessToken;
/*      */     private final long blockSize;
/*      */     private DataChecksum checksum;
/* 2794 */     private LinkedList<Packet> dataQueue = new LinkedList();
/* 2795 */     private LinkedList<Packet> ackQueue = new LinkedList();
/* 2796 */     private Packet currentPacket = null;
/* 2797 */     private int maxPackets = 80;
/*      */ 
/* 2799 */     private DataStreamer streamer = new DataStreamer(null);
/* 2800 */     private ResponseProcessor response = null;
/* 2801 */     private long currentSeqno = 0L;
/* 2802 */     private long lastQueuedSeqno = -1L;
/* 2803 */     private long lastAckedSeqno = -1L;
/* 2804 */     private long bytesCurBlock = 0L;
/* 2805 */     private int packetSize = 0;
/* 2806 */     private int chunksPerPacket = 0;
/* 2807 */     private DatanodeInfo[] nodes = null;
/* 2808 */     private ArrayList<DatanodeInfo> excludedNodes = new ArrayList();
/* 2809 */     private volatile boolean hasError = false;
/* 2810 */     private volatile int errorIndex = 0;
/* 2811 */     private volatile IOException lastException = null;
/* 2812 */     private long artificialSlowdown = 0L;
/* 2813 */     private long lastFlushOffset = 0L;
/* 2814 */     private boolean persistBlocks = false;
/* 2815 */     private int recoveryErrorCount = 0;
/* 2816 */     private int maxRecoveryErrorCount = 5;
/* 2817 */     private volatile boolean appendChunk = false;
/* 2818 */     private long initialFileSize = 0L;
/*      */     private Progressable progress;
/*      */     private short blockReplication;
/*      */ 
/*      */     Token<BlockTokenIdentifier> getAccessToken()
/*      */     {
/* 2823 */       return this.accessToken;
/*      */     }
/*      */ 
/*      */     private void setLastException(IOException e) {
/* 2827 */       if (this.lastException == null)
/* 2828 */         this.lastException = e;
/*      */     }
/*      */ 
/*      */     private boolean processDatanodeError(boolean hasError, boolean isAppend)
/*      */     {
/* 3236 */       if (!hasError) {
/* 3237 */         return false;
/*      */       }
/* 3239 */       if (this.response != null) {
/* 3240 */         DFSClient.LOG.info(new StringBuilder().append("Error Recovery for ").append(this.block).append(" waiting for responder to exit. ").toString());
/*      */ 
/* 3242 */         return true;
/*      */       }
/* 3244 */       if (this.errorIndex >= 0) {
/* 3245 */         DFSClient.LOG.warn(new StringBuilder().append("Error Recovery for ").append(this.block).append(" bad datanode[").append(this.errorIndex).append("] ").append(this.nodes == null ? "nodes == null" : this.nodes[this.errorIndex].getName()).toString());
/*      */       }
/*      */ 
/* 3250 */       if (this.blockStream != null) {
/* 3251 */         IOUtils.cleanup(DFSClient.LOG, new Closeable[] { this.blockStream, this.blockReplyStream });
/*      */       }
/* 3253 */       this.blockStream = null;
/* 3254 */       this.blockReplyStream = null;
/*      */ 
/* 3257 */       synchronized (this.ackQueue) {
/* 3258 */         this.dataQueue.addAll(0, this.ackQueue);
/* 3259 */         this.ackQueue.clear();
/*      */       }
/*      */ 
/* 3262 */       boolean success = false;
/* 3263 */       while ((!success) && (DFSClient.this.clientRunning)) {
/* 3264 */         DatanodeInfo[] newnodes = null;
/* 3265 */         if (this.nodes == null) {
/* 3266 */           String msg = new StringBuilder().append("Could not get block locations. Source file \"").append(this.src).append("\" - Aborting...").toString();
/*      */ 
/* 3269 */           DFSClient.LOG.warn(msg);
/* 3270 */           setLastException(new IOException(msg));
/* 3271 */           this.closed = true;
/* 3272 */           if (this.streamer != null) this.streamer.close();
/* 3273 */           return false;
/*      */         }
/* 3275 */         StringBuilder pipelineMsg = new StringBuilder();
/* 3276 */         for (int j = 0; j < this.nodes.length; j++) {
/* 3277 */           pipelineMsg.append(this.nodes[j].getName());
/* 3278 */           if (j < this.nodes.length - 1) {
/* 3279 */             pipelineMsg.append(", ");
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 3286 */         if (this.errorIndex < 0) {
/* 3287 */           newnodes = this.nodes;
/*      */         } else {
/* 3289 */           if (this.nodes.length <= 1) {
/* 3290 */             this.lastException = new IOException(new StringBuilder().append("All datanodes ").append(pipelineMsg).append(" are bad. Aborting...").toString());
/*      */ 
/* 3292 */             this.closed = true;
/* 3293 */             if (this.streamer != null) this.streamer.close();
/* 3294 */             return false;
/*      */           }
/* 3296 */           DFSClient.LOG.warn(new StringBuilder().append("Error Recovery for block ").append(this.block).append(" in pipeline ").append(pipelineMsg).append(": bad datanode ").append(this.nodes[this.errorIndex].getName()).toString());
/*      */ 
/* 3299 */           newnodes = new DatanodeInfo[this.nodes.length - 1];
/* 3300 */           System.arraycopy(this.nodes, 0, newnodes, 0, this.errorIndex);
/* 3301 */           System.arraycopy(this.nodes, this.errorIndex + 1, newnodes, this.errorIndex, newnodes.length - this.errorIndex);
/*      */         }
/*      */ 
/* 3308 */         LocatedBlock newBlock = null;
/* 3309 */         ClientDatanodeProtocol primary = null;
/* 3310 */         DatanodeInfo primaryNode = null;
/*      */         try
/*      */         {
/* 3313 */           primaryNode = (DatanodeInfo)Collections.min(Arrays.asList(newnodes));
/*      */ 
/* 3316 */           int recoveryTimeout = (newnodes.length * 2 + 2) * DFSClient.this.socketTimeout;
/* 3317 */           primary = DFSClient.createClientDatanodeProtocolProxy(primaryNode, DFSClient.this.conf, this.block, this.accessToken, recoveryTimeout, DFSClient.this.connectToDnViaHostname);
/*      */ 
/* 3319 */           newBlock = primary.recoverBlock(this.block, isAppend, newnodes);
/*      */         } catch (IOException e) {
/* 3321 */           DFSClient.LOG.warn(new StringBuilder().append("Failed recovery attempt #").append(this.recoveryErrorCount).append(" from primary datanode ").append(primaryNode).toString(), e);
/*      */ 
/* 3323 */           this.recoveryErrorCount += 1;
/*      */           String emsg;
/* 3324 */           if (this.recoveryErrorCount > this.maxRecoveryErrorCount) {
/* 3325 */             if (this.nodes.length > 1)
/*      */             {
/* 3329 */               for (int j = 0; j < this.nodes.length; j++) {
/* 3330 */                 if (this.nodes[j].equals(primaryNode)) {
/* 3331 */                   this.errorIndex = j;
/*      */                 }
/*      */               }
/*      */ 
/* 3335 */               newnodes = new DatanodeInfo[this.nodes.length - 1];
/* 3336 */               System.arraycopy(this.nodes, 0, newnodes, 0, this.errorIndex);
/* 3337 */               System.arraycopy(this.nodes, this.errorIndex + 1, newnodes, this.errorIndex, newnodes.length - this.errorIndex);
/*      */ 
/* 3339 */               this.nodes = newnodes;
/* 3340 */               DFSClient.LOG.warn(new StringBuilder().append("Error Recovery for block ").append(this.block).append(" failed ").append(" because recovery from primary datanode ").append(primaryNode).append(" failed ").append(this.recoveryErrorCount).append(" times. ").append(" Pipeline was ").append(pipelineMsg).append(". Marking primary datanode as bad.").toString());
/*      */ 
/* 3345 */               this.recoveryErrorCount = 0;
/* 3346 */               this.errorIndex = -1;
/* 3347 */               return 1;
/*      */             }
/* 3349 */             emsg = new StringBuilder().append("Error Recovery for block ").append(this.block).append(" failed ").append(" because recovery from primary datanode ").append(primaryNode).append(" failed ").append(this.recoveryErrorCount).append(" times. ").append(" Pipeline was ").append(pipelineMsg).append(". Aborting...").toString();
/*      */ 
/* 3354 */             DFSClient.LOG.warn(emsg);
/* 3355 */             this.lastException = new IOException(emsg);
/* 3356 */             this.closed = true;
/* 3357 */             if (this.streamer != null) this.streamer.close();
/* 3358 */             return false;
/*      */           }
/* 3360 */           DFSClient.LOG.warn(new StringBuilder().append("Error Recovery for block ").append(this.block).append(" failed ").append(" because recovery from primary datanode ").append(primaryNode).append(" failed ").append(this.recoveryErrorCount).append(" times. ").append(" Pipeline was ").append(pipelineMsg).append(". Will retry...").toString());
/*      */ 
/* 3365 */           return 1;
/*      */         } finally {
/* 3367 */           RPC.stopProxy(primary);
/*      */         }
/* 3369 */         this.recoveryErrorCount = 0;
/*      */ 
/* 3375 */         this.block = newBlock.getBlock();
/* 3376 */         this.accessToken = newBlock.getBlockToken();
/* 3377 */         this.nodes = newBlock.getLocations();
/*      */ 
/* 3379 */         this.hasError = false;
/* 3380 */         this.lastException = null;
/* 3381 */         this.errorIndex = 0;
/* 3382 */         success = createBlockOutputStream(this.nodes, DFSClient.this.clientName, true);
/*      */       }
/*      */ 
/* 3385 */       this.response = new ResponseProcessor(this.nodes);
/* 3386 */       this.response.start();
/* 3387 */       return false;
/*      */     }
/*      */ 
/*      */     private void isClosed() throws IOException {
/* 3391 */       if ((this.closed) && (this.lastException != null))
/* 3392 */         throw this.lastException;
/*      */     }
/*      */ 
/*      */     DatanodeInfo[] getPipeline()
/*      */     {
/* 3400 */       synchronized (this.dataQueue) {
/* 3401 */         if (this.nodes == null) {
/* 3402 */           return null;
/*      */         }
/* 3404 */         DatanodeInfo[] value = new DatanodeInfo[this.nodes.length];
/* 3405 */         for (int i = 0; i < this.nodes.length; i++) {
/* 3406 */           value[i] = this.nodes[i];
/*      */         }
/* 3408 */         return value;
/*      */       }
/*      */     }
/*      */ 
/*      */     private DFSOutputStream(String src, long blockSize, Progressable progress, int bytesPerChecksum, short replication) throws IOException
/*      */     {
/* 3414 */       super(bytesPerChecksum, 4);
/* 3415 */       this.src = src;
/* 3416 */       this.blockSize = blockSize;
/* 3417 */       this.blockReplication = replication;
/* 3418 */       this.progress = progress;
/* 3419 */       if (progress != null) {
/* 3420 */         DFSClient.LOG.debug(new StringBuilder().append("Set non-null progress callback on DFSOutputStream ").append(src).toString());
/*      */       }
/*      */ 
/* 3423 */       if ((bytesPerChecksum < 1) || (blockSize % bytesPerChecksum != 0L)) {
/* 3424 */         throw new IOException(new StringBuilder().append("io.bytes.per.checksum(").append(bytesPerChecksum).append(") and blockSize(").append(blockSize).append(") do not match. ").append("blockSize should be a ").append("multiple of io.bytes.per.checksum").toString());
/*      */       }
/*      */ 
/* 3430 */       this.checksum = DataChecksum.newDataChecksum(1, bytesPerChecksum);
/*      */     }
/*      */ 
/*      */     DFSOutputStream(String src, FsPermission masked, boolean overwrite, boolean createParent, short replication, long blockSize, Progressable progress, int buffersize, int bytesPerChecksum)
/*      */       throws IOException
/*      */     {
/* 3441 */       this(src, blockSize, progress, bytesPerChecksum, replication);
/*      */ 
/* 3443 */       computePacketChunkSize(DFSClient.this.writePacketSize, bytesPerChecksum);
/*      */       try
/*      */       {
/* 3450 */         if (createParent) {
/* 3451 */           DFSClient.this.namenode.create(src, masked, DFSClient.this.clientName, overwrite, replication, blockSize);
/*      */         }
/*      */         else
/* 3454 */           DFSClient.this.namenode.create(src, masked, DFSClient.this.clientName, overwrite, false, replication, blockSize);
/*      */       }
/*      */       catch (RemoteException re)
/*      */       {
/* 3458 */         throw re.unwrapRemoteException(new Class[] { AccessControlException.class, FileAlreadyExistsException.class, FileNotFoundException.class, NSQuotaExceededException.class, DSQuotaExceededException.class });
/*      */       }
/*      */ 
/* 3464 */       this.streamer.start();
/*      */     }
/*      */ 
/*      */     DFSOutputStream(String src, int buffersize, Progressable progress, LocatedBlock lastBlock, HdfsFileStatus stat, int bytesPerChecksum)
/*      */       throws IOException
/*      */     {
/* 3474 */       this(src, stat.getBlockSize(), progress, bytesPerChecksum, stat.getReplication());
/* 3475 */       this.initialFileSize = stat.getLen();
/*      */       long usedInLastBlock;
/* 3480 */       if (lastBlock != null) {
/* 3481 */         this.block = lastBlock.getBlock();
/* 3482 */         this.accessToken = lastBlock.getBlockToken();
/* 3483 */         usedInLastBlock = stat.getLen() % this.blockSize;
/* 3484 */         int freeInLastBlock = (int)(this.blockSize - usedInLastBlock);
/*      */ 
/* 3488 */         int usedInCksum = (int)(stat.getLen() % bytesPerChecksum);
/* 3489 */         int freeInCksum = bytesPerChecksum - usedInCksum;
/*      */ 
/* 3493 */         if (freeInLastBlock > this.blockSize) {
/* 3494 */           throw new IOException(new StringBuilder().append("The last block for file ").append(src).append(" is full.").toString());
/*      */         }
/*      */ 
/* 3499 */         this.bytesCurBlock = lastBlock.getBlockSize();
/*      */ 
/* 3501 */         if ((usedInCksum > 0) && (freeInCksum > 0))
/*      */         {
/* 3506 */           computePacketChunkSize(0, freeInCksum);
/* 3507 */           resetChecksumChunk(freeInCksum);
/* 3508 */           this.appendChunk = true;
/*      */         }
/*      */         else
/*      */         {
/* 3514 */           computePacketChunkSize(Math.min(DFSClient.this.writePacketSize, freeInLastBlock), bytesPerChecksum);
/*      */         }
/*      */ 
/* 3519 */         this.nodes = lastBlock.getLocations();
/* 3520 */         this.errorIndex = -1;
/* 3521 */         if (this.nodes.length < 1) {
/* 3522 */           throw new IOException(new StringBuilder().append("Unable to retrieve blocks locations for append to last block ").append(this.block).append(" of file ").append(src).toString());
/*      */         }
/*      */ 
/* 3527 */         while (processDatanodeError(true, true))
/*      */           try {
/* 3529 */             Thread.sleep(1000L);
/*      */           }
/*      */           catch (InterruptedException e) {
/*      */           }
/* 3533 */         if (this.lastException != null) {
/* 3534 */           throw this.lastException;
/*      */         }
/* 3536 */         this.streamer.start();
/*      */       }
/*      */       else {
/* 3539 */         computePacketChunkSize(DFSClient.this.writePacketSize, bytesPerChecksum);
/* 3540 */         this.streamer.start();
/*      */       }
/*      */     }
/*      */ 
/*      */     private void computePacketChunkSize(int psize, int csize) {
/* 3545 */       int chunkSize = csize + this.checksum.getChecksumSize();
/* 3546 */       int n = 25;
/* 3547 */       this.chunksPerPacket = Math.max((psize - n + chunkSize - 1) / chunkSize, 1);
/* 3548 */       this.packetSize = (n + chunkSize * this.chunksPerPacket);
/* 3549 */       if (DFSClient.LOG.isDebugEnabled())
/* 3550 */         DFSClient.LOG.debug(new StringBuilder().append("computePacketChunkSize: src=").append(this.src).append(", chunkSize=").append(chunkSize).append(", chunksPerPacket=").append(this.chunksPerPacket).append(", packetSize=").append(this.packetSize).toString());
/*      */     }
/*      */ 
/*      */     private DatanodeInfo[] nextBlockOutputStream()
/*      */       throws IOException
/*      */     {
/* 3564 */       LocatedBlock lb = null;
/* 3565 */       boolean retry = false;
/*      */ 
/* 3567 */       int count = DFSClient.this.conf.getInt("dfs.client.block.write.retries", 3);
/*      */       DatanodeInfo[] nodes;
/*      */       boolean success;
/*      */       do
/*      */       {
/* 3570 */         this.hasError = false;
/* 3571 */         this.lastException = null;
/* 3572 */         this.errorIndex = 0;
/* 3573 */         retry = false;
/* 3574 */         nodes = null;
/* 3575 */         success = false;
/*      */ 
/* 3577 */         long startTime = System.currentTimeMillis();
/*      */ 
/* 3579 */         DatanodeInfo[] excluded = (DatanodeInfo[])this.excludedNodes.toArray(new DatanodeInfo[0]);
/* 3580 */         lb = locateFollowingBlock(startTime, excluded.length > 0 ? excluded : null);
/* 3581 */         this.block = lb.getBlock();
/* 3582 */         this.accessToken = lb.getBlockToken();
/* 3583 */         nodes = lb.getLocations();
/*      */ 
/* 3588 */         success = createBlockOutputStream(nodes, DFSClient.this.clientName, false);
/*      */ 
/* 3590 */         if (!success) {
/* 3591 */           DFSClient.LOG.info(new StringBuilder().append("Abandoning ").append(this.block).toString());
/* 3592 */           DFSClient.this.namenode.abandonBlock(this.block, this.src, DFSClient.this.clientName);
/*      */ 
/* 3594 */           if (this.errorIndex < nodes.length) {
/* 3595 */             DFSClient.LOG.info(new StringBuilder().append("Excluding datanode ").append(nodes[this.errorIndex]).toString());
/* 3596 */             this.excludedNodes.add(nodes[this.errorIndex]);
/*      */           }
/*      */ 
/* 3600 */           retry = true;
/*      */         }
/* 3602 */         if (!retry) break; count--; } while (count >= 0);
/*      */ 
/* 3604 */       if (!success) {
/* 3605 */         throw new IOException("Unable to create new block.");
/*      */       }
/* 3607 */       return nodes;
/*      */     }
/*      */ 
/*      */     private boolean createBlockOutputStream(DatanodeInfo[] nodes, String client, boolean recoveryFlag)
/*      */     {
/* 3615 */       short pipelineStatus = 0;
/* 3616 */       String firstBadLink = "";
/* 3617 */       if (DFSClient.LOG.isDebugEnabled()) {
/* 3618 */         for (int i = 0; i < nodes.length; i++) {
/* 3619 */           DFSClient.LOG.debug(new StringBuilder().append("pipeline = ").append(nodes[i].getName()).toString());
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3624 */       this.persistBlocks = true;
/*      */ 
/* 3626 */       boolean result = false;
/*      */       try {
/* 3628 */         String dnName = nodes[0].getName(DFSClient.this.connectToDnViaHostname);
/* 3629 */         InetSocketAddress target = NetUtils.createSocketAddr(dnName);
/* 3630 */         this.s = DFSClient.this.socketFactory.createSocket();
/* 3631 */         DFSClient.this.timeoutValue = (DFSClient.this.socketTimeout > 0 ? 3000 * nodes.length + DFSClient.this.socketTimeout : 0);
/*      */ 
/* 3633 */         DFSClient.LOG.debug(new StringBuilder().append("Connecting to ").append(dnName).toString());
/* 3634 */         NetUtils.connect(this.s, target, DFSClient.this.getRandomLocalInterfaceAddr(), DFSClient.this.timeoutValue);
/* 3635 */         this.s.setSoTimeout(DFSClient.this.timeoutValue);
/* 3636 */         this.s.setSendBufferSize(131072);
/* 3637 */         DFSClient.LOG.debug(new StringBuilder().append("Send buf size ").append(this.s.getSendBufferSize()).toString());
/* 3638 */         long writeTimeout = DFSClient.this.datanodeWriteTimeout > 0 ? 5000 * nodes.length + DFSClient.this.datanodeWriteTimeout : 0L;
/*      */ 
/* 3645 */         DataOutputStream out = new DataOutputStream(new BufferedOutputStream(NetUtils.getOutputStream(this.s, writeTimeout), DataNode.SMALL_BUFFER_SIZE));
/*      */ 
/* 3648 */         this.blockReplyStream = new DataInputStream(NetUtils.getInputStream(this.s));
/*      */ 
/* 3650 */         out.writeShort(17);
/* 3651 */         out.write(80);
/* 3652 */         out.writeLong(this.block.getBlockId());
/* 3653 */         out.writeLong(this.block.getGenerationStamp());
/* 3654 */         out.writeInt(nodes.length);
/* 3655 */         out.writeBoolean(recoveryFlag);
/* 3656 */         Text.writeString(out, client);
/* 3657 */         out.writeBoolean(false);
/* 3658 */         out.writeInt(nodes.length - 1);
/* 3659 */         for (int i = 1; i < nodes.length; i++) {
/* 3660 */           nodes[i].write(out);
/*      */         }
/* 3662 */         this.accessToken.write(out);
/* 3663 */         this.checksum.writeHeader(out);
/* 3664 */         out.flush();
/*      */ 
/* 3667 */         pipelineStatus = this.blockReplyStream.readShort();
/* 3668 */         firstBadLink = Text.readString(this.blockReplyStream);
/* 3669 */         if (pipelineStatus != 0) {
/* 3670 */           if (pipelineStatus == 5) {
/* 3671 */             throw new InvalidBlockTokenException(new StringBuilder().append("Got access token error for connect ack with firstBadLink as ").append(firstBadLink).toString());
/*      */           }
/*      */ 
/* 3675 */           throw new IOException(new StringBuilder().append("Bad connect ack with firstBadLink as ").append(firstBadLink).toString());
/*      */         }
/*      */ 
/* 3680 */         this.blockStream = out;
/* 3681 */         result = true;
/*      */       }
/*      */       catch (IOException ie)
/*      */       {
/* 3685 */         DFSClient.LOG.info(new StringBuilder().append("Exception in createBlockOutputStream ").append(nodes[0].getName()).append(" ").append(ie).toString());
/*      */ 
/* 3689 */         if (firstBadLink.length() != 0) {
/* 3690 */           for (int i = 0; i < nodes.length; i++) {
/* 3691 */             if (nodes[i].getName().equals(firstBadLink)) {
/* 3692 */               this.errorIndex = i;
/* 3693 */               break;
/*      */             }
/*      */           }
/*      */         }
/* 3697 */         this.hasError = true;
/* 3698 */         setLastException(ie);
/* 3699 */         this.blockReplyStream = null;
/* 3700 */         result = false;
/*      */       } finally {
/* 3702 */         if (!result) {
/* 3703 */           IOUtils.closeSocket(this.s);
/* 3704 */           this.s = null;
/*      */         }
/*      */       }
/* 3707 */       return result;
/*      */     }
/*      */ 
/*      */     private LocatedBlock locateFollowingBlock(long start, DatanodeInfo[] excludedNodes)
/*      */       throws IOException
/*      */     {
/* 3713 */       int retries = DFSClient.this.conf.getInt("dfs.client.block.write.locateFollowingBlock.retries", 5);
/* 3714 */       long sleeptime = 400L;
/*      */ 
/* 3716 */       long localstart = System.currentTimeMillis();
/*      */       while (true)
/*      */         try {
/* 3719 */           if (DFSClient.this.serverSupportsHdfs630) {
/* 3720 */             return DFSClient.this.namenode.addBlock(this.src, DFSClient.this.clientName, excludedNodes);
/*      */           }
/* 3722 */           return DFSClient.this.namenode.addBlock(this.src, DFSClient.this.clientName);
/*      */         }
/*      */         catch (RemoteException e) {
/* 3725 */           IOException ue = e.unwrapRemoteException(new Class[] { FileNotFoundException.class, AccessControlException.class, NSQuotaExceededException.class, DSQuotaExceededException.class });
/*      */ 
/* 3730 */           if (ue != e) {
/* 3731 */             throw ue;
/*      */           }
/*      */ 
/* 3734 */           if (e.getMessage().startsWith("java.io.IOException: java.lang.NoSuchMethodException: org.apache.hadoop.hdfs.protocol.ClientProtocol.addBlock(java.lang.String, java.lang.String, [Lorg.apache.hadoop.hdfs.protocol.DatanodeInfo;)"))
/*      */           {
/* 3741 */             DFSClient.this.serverSupportsHdfs630 = false;
/*      */           }
/* 3745 */           else if (NotReplicatedYetException.class.getName().equals(e.getClassName()))
/*      */           {
/* 3748 */             if (retries == 0) {
/* 3749 */               throw e;
/*      */             }
/* 3751 */             retries--;
/* 3752 */             DFSClient.LOG.info(StringUtils.stringifyException(e));
/* 3753 */             if (System.currentTimeMillis() - localstart > 5000L) {
/* 3754 */               DFSClient.LOG.info(new StringBuilder().append("Waiting for replication for ").append((System.currentTimeMillis() - localstart) / 1000L).append(" seconds").toString());
/*      */             }
/*      */ 
/*      */             try
/*      */             {
/* 3759 */               DFSClient.LOG.warn(new StringBuilder().append("NotReplicatedYetException sleeping ").append(this.src).append(" retries left ").append(retries).toString());
/*      */ 
/* 3761 */               Thread.sleep(sleeptime);
/* 3762 */               sleeptime *= 2L;
/*      */             } catch (InterruptedException ie) {
/*      */             }
/*      */           }
/*      */           else {
/* 3767 */             throw e;
/*      */           }
/*      */         }
/*      */     }
/*      */ 
/*      */     protected synchronized void writeChunk(byte[] b, int offset, int len, byte[] checksum)
/*      */       throws IOException
/*      */     {
/* 3778 */       DFSClient.this.checkOpen();
/* 3779 */       isClosed();
/*      */ 
/* 3781 */       int cklen = checksum.length;
/* 3782 */       int bytesPerChecksum = this.checksum.getBytesPerChecksum();
/* 3783 */       if (len > bytesPerChecksum) {
/* 3784 */         throw new IOException(new StringBuilder().append("writeChunk() buffer size is ").append(len).append(" is larger than supported  bytesPerChecksum ").append(bytesPerChecksum).toString());
/*      */       }
/*      */ 
/* 3788 */       if (checksum.length != this.checksum.getChecksumSize()) {
/* 3789 */         throw new IOException(new StringBuilder().append("writeChunk() checksum size is supposed to be ").append(this.checksum.getChecksumSize()).append(" but found to be ").append(checksum.length).toString());
/*      */       }
/*      */ 
/* 3794 */       synchronized (this.dataQueue)
/*      */       {
/* 3797 */         while ((!this.closed) && (this.dataQueue.size() + this.ackQueue.size() > this.maxPackets))
/*      */           try {
/* 3799 */             this.dataQueue.wait();
/*      */           }
/*      */           catch (InterruptedException e) {
/*      */           }
/* 3803 */         isClosed();
/*      */ 
/* 3805 */         if (this.currentPacket == null) {
/* 3806 */           this.currentPacket = new Packet(this.packetSize, this.chunksPerPacket, this.bytesCurBlock);
/*      */ 
/* 3808 */           if (DFSClient.LOG.isDebugEnabled()) {
/* 3809 */             DFSClient.LOG.debug(new StringBuilder().append("DFSClient writeChunk allocating new packet seqno=").append(this.currentPacket.seqno).append(", src=").append(this.src).append(", packetSize=").append(this.packetSize).append(", chunksPerPacket=").append(this.chunksPerPacket).append(", bytesCurBlock=").append(this.bytesCurBlock).toString());
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 3818 */         this.currentPacket.writeChecksum(checksum, 0, cklen);
/* 3819 */         this.currentPacket.writeData(b, offset, len);
/* 3820 */         this.currentPacket.numChunks += 1;
/* 3821 */         this.bytesCurBlock += len;
/*      */ 
/* 3825 */         if ((this.currentPacket.numChunks == this.currentPacket.maxChunks) || (this.bytesCurBlock == this.blockSize))
/*      */         {
/* 3827 */           if (DFSClient.LOG.isDebugEnabled()) {
/* 3828 */             DFSClient.LOG.debug(new StringBuilder().append("DFSClient writeChunk packet full seqno=").append(this.currentPacket.seqno).append(", src=").append(this.src).append(", bytesCurBlock=").append(this.bytesCurBlock).append(", blockSize=").append(this.blockSize).append(", appendChunk=").append(this.appendChunk).toString());
/*      */           }
/*      */ 
/* 3839 */           if (this.bytesCurBlock == this.blockSize) {
/* 3840 */             this.currentPacket.lastPacketInBlock = true;
/* 3841 */             this.bytesCurBlock = 0L;
/* 3842 */             this.lastFlushOffset = 0L;
/*      */           }
/* 3844 */           enqueueCurrentPacket();
/*      */ 
/* 3849 */           if (this.appendChunk) {
/* 3850 */             this.appendChunk = false;
/* 3851 */             resetChecksumChunk(bytesPerChecksum);
/*      */           }
/* 3853 */           int psize = Math.min((int)(this.blockSize - this.bytesCurBlock), DFSClient.this.writePacketSize);
/* 3854 */           computePacketChunkSize(psize, bytesPerChecksum);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     private synchronized void enqueueCurrentPacket()
/*      */     {
/* 3862 */       synchronized (this.dataQueue) {
/* 3863 */         if (this.currentPacket == null) return;
/* 3864 */         this.dataQueue.addLast(this.currentPacket);
/* 3865 */         this.dataQueue.notifyAll();
/* 3866 */         this.lastQueuedSeqno = this.currentPacket.seqno;
/* 3867 */         this.currentPacket = null;
/*      */       }
/*      */     }
/*      */ 
/*      */     public void sync()
/*      */       throws IOException
/*      */     {
/* 3877 */       DFSClient.this.checkOpen();
/* 3878 */       if (this.closed)
/* 3879 */         throw new IOException("DFSOutputStream is closed");
/*      */       try
/*      */       {
/*      */         long toWaitFor;
/* 3883 */         synchronized (this)
/*      */         {
/* 3889 */           long saveOffset = this.bytesCurBlock;
/* 3890 */           Packet oldCurrentPacket = this.currentPacket;
/*      */ 
/* 3893 */           flushBuffer(true);
/*      */ 
/* 3897 */           if (this.lastFlushOffset != this.bytesCurBlock) {
/* 3898 */             assert (this.bytesCurBlock > this.lastFlushOffset);
/*      */ 
/* 3900 */             this.lastFlushOffset = this.bytesCurBlock;
/* 3901 */             enqueueCurrentPacket();
/*      */           }
/*      */           else {
/* 3904 */             if ((oldCurrentPacket == null) && (this.currentPacket != null))
/*      */             {
/* 3908 */               this.currentSeqno -= 1L;
/*      */             }
/* 3910 */             this.currentPacket = null;
/*      */           }
/*      */ 
/* 3915 */           this.bytesCurBlock = saveOffset;
/* 3916 */           toWaitFor = this.lastQueuedSeqno;
/*      */         }
/* 3918 */         waitForAckedSeqno(toWaitFor);
/*      */         boolean willPersist;
/* 3924 */         synchronized (this) {
/* 3925 */           willPersist = (this.persistBlocks) && (!this.closed);
/* 3926 */           this.persistBlocks = false;
/*      */         }
/* 3928 */         if (willPersist)
/*      */           try {
/* 3930 */             DFSClient.this.namenode.fsync(this.src, DFSClient.this.clientName);
/*      */           } catch (IOException ioe) {
/* 3932 */             DFSClient.LOG.warn(new StringBuilder().append("Unable to persist blocks in hflush for ").append(this.src).toString(), ioe);
/*      */ 
/* 3936 */             isClosed();
/* 3937 */             if (this.closed) {
/* 3938 */               throw new IOException("DFSOutputStream is closed");
/*      */             }
/*      */ 
/* 3943 */             throw ioe;
/*      */           }
/*      */       }
/*      */       catch (IOException e) {
/* 3947 */         DFSClient.LOG.warn("Error while syncing", e);
/* 3948 */         synchronized (this) {
/* 3949 */           if (!this.closed) {
/* 3950 */             this.lastException = new IOException(new StringBuilder().append("IOException flush:").append(e).toString());
/* 3951 */             this.closed = true;
/* 3952 */             closeThreads();
/*      */           }
/*      */         }
/* 3955 */         throw e;
/*      */       }
/*      */     }
/*      */ 
/*      */     public int getNumCurrentReplicas()
/*      */       throws IOException
/*      */     {
/* 3969 */       synchronized (this.dataQueue) {
/* 3970 */         if (this.nodes == null) {
/* 3971 */           return this.blockReplication;
/*      */         }
/* 3973 */         return this.nodes.length;
/*      */       }
/*      */     }
/*      */ 
/*      */     private void flushInternal()
/*      */       throws IOException
/*      */     {
/* 3982 */       isClosed();
/* 3983 */       DFSClient.this.checkOpen();
/*      */       long toWaitFor;
/* 3986 */       synchronized (this) {
/* 3987 */         enqueueCurrentPacket();
/* 3988 */         toWaitFor = this.lastQueuedSeqno;
/*      */       }
/*      */ 
/* 3991 */       waitForAckedSeqno(toWaitFor);
/*      */     }
/*      */ 
/*      */     private void waitForAckedSeqno(long seqnumToWaitFor) throws IOException {
/* 3995 */       synchronized (this.ackQueue) {
/* 3996 */         while (!this.closed) {
/* 3997 */           isClosed();
/* 3998 */           if (this.lastAckedSeqno >= seqnumToWaitFor)
/*      */             break;
/*      */           try
/*      */           {
/* 4002 */             this.ackQueue.wait(); } catch (InterruptedException ie) {
/*      */           }
/*      */         }
/*      */       }
/* 4006 */       isClosed();
/*      */     }
/*      */ 
/*      */     public void close()
/*      */       throws IOException
/*      */     {
/* 4015 */       if (this.closed) {
/* 4016 */         IOException e = this.lastException;
/* 4017 */         if (e == null) {
/* 4018 */           return;
/*      */         }
/* 4020 */         throw e;
/*      */       }
/* 4022 */       closeInternal();
/*      */ 
/* 4024 */       if (this.s != null) {
/* 4025 */         this.s.close();
/* 4026 */         this.s = null;
/*      */       }
/* 4028 */       DFSClient.this.endFileLease(this.src);
/*      */     }
/*      */ 
/*      */     void abortForTests()
/*      */       throws IOException
/*      */     {
/* 4036 */       this.streamer.close();
/* 4037 */       this.response.close();
/* 4038 */       this.closed = true;
/*      */     }
/*      */ 
/*      */     synchronized void abort()
/*      */       throws IOException
/*      */     {
/* 4046 */       if (this.closed) {
/* 4047 */         return;
/*      */       }
/* 4049 */       setLastException(new IOException(new StringBuilder().append("Lease timeout of ").append(DFSClient.this.hdfsTimeout / 1000).append(" seconds expired.").toString()));
/*      */ 
/* 4051 */       closeThreads();
/* 4052 */       DFSClient.this.endFileLease(this.src);
/*      */     }
/*      */ 
/*      */     private void closeThreads() throws IOException
/*      */     {
/*      */       try {
/* 4058 */         this.streamer.close();
/* 4059 */         this.streamer.join();
/*      */ 
/* 4062 */         if (this.response != null) {
/* 4063 */           this.response.close();
/* 4064 */           this.response.join();
/* 4065 */           this.response = null;
/*      */         }
/*      */       } catch (InterruptedException e) {
/* 4068 */         throw new IOException("Failed to shutdown response thread");
/*      */       }
/*      */     }
/*      */ 
/*      */     private synchronized void closeInternal()
/*      */       throws IOException
/*      */     {
/* 4077 */       DFSClient.this.checkOpen();
/* 4078 */       isClosed();
/*      */       try
/*      */       {
/* 4081 */         flushBuffer();
/*      */ 
/* 4087 */         synchronized (this.dataQueue) {
/* 4088 */           if ((this.currentPacket == null) && (this.bytesCurBlock != 0L)) {
/* 4089 */             this.currentPacket = new Packet(this.packetSize, this.chunksPerPacket, this.bytesCurBlock);
/*      */           }
/*      */ 
/* 4092 */           if (this.currentPacket != null) {
/* 4093 */             this.currentPacket.lastPacketInBlock = true;
/*      */           }
/*      */         }
/*      */ 
/* 4097 */         flushInternal();
/* 4098 */         isClosed();
/* 4099 */         this.closed = true;
/*      */ 
/* 4101 */         closeThreads();
/*      */ 
/* 4103 */         synchronized (this.dataQueue) {
/* 4104 */           if (this.blockStream != null) {
/* 4105 */             this.blockStream.writeInt(0);
/* 4106 */             IOUtils.cleanup(DFSClient.LOG, new Closeable[] { this.blockStream, this.blockReplyStream });
/*      */           }
/* 4108 */           if (this.s != null) {
/* 4109 */             this.s.close();
/* 4110 */             this.s = null;
/*      */           }
/*      */         }
/*      */ 
/* 4114 */         this.streamer = null;
/* 4115 */         this.blockStream = null;
/* 4116 */         this.blockReplyStream = null;
/*      */ 
/* 4118 */         long localstart = System.currentTimeMillis();
/* 4119 */         boolean fileComplete = false;
/* 4120 */         while (!fileComplete) {
/* 4121 */           fileComplete = DFSClient.this.namenode.complete(this.src, DFSClient.this.clientName);
/* 4122 */           if (!fileComplete) {
/* 4123 */             if ((!DFSClient.this.clientRunning) || ((DFSClient.this.hdfsTimeout > 0) && (localstart + DFSClient.this.hdfsTimeout < System.currentTimeMillis())))
/*      */             {
/* 4126 */               String msg = new StringBuilder().append("Unable to close file because dfsclient  was unable to contact the HDFS servers. clientRunning ").append(DFSClient.this.clientRunning).append(" hdfsTimeout ").append(DFSClient.this.hdfsTimeout).toString();
/*      */ 
/* 4130 */               DFSClient.LOG.info(msg);
/* 4131 */               throw new IOException(msg);
/*      */             }
/*      */             try {
/* 4134 */               Thread.sleep(400L);
/* 4135 */               if (System.currentTimeMillis() - localstart > 5000L)
/* 4136 */                 DFSClient.LOG.info(new StringBuilder().append("Could not complete ").append(this.src).append(" retrying...").toString());
/*      */             } catch (InterruptedException ie) {
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       finally {
/* 4143 */         this.closed = true;
/*      */       }
/*      */     }
/*      */ 
/*      */     void setArtificialSlowdown(long period) {
/* 4148 */       this.artificialSlowdown = period;
/*      */     }
/*      */ 
/*      */     synchronized void setChunksPerPacket(int value) {
/* 4152 */       this.chunksPerPacket = Math.min(this.chunksPerPacket, value);
/* 4153 */       this.packetSize = (25 + (this.checksum.getBytesPerChecksum() + this.checksum.getChecksumSize()) * this.chunksPerPacket);
/*      */     }
/*      */ 
/*      */     synchronized void setTestFilename(String newname)
/*      */     {
/* 4159 */       this.src = newname;
/*      */     }
/*      */ 
/*      */     long getInitialLen()
/*      */     {
/* 4166 */       return this.initialFileSize;
/*      */     }
/*      */ 
/*      */     private class ResponseProcessor extends Thread
/*      */     {
/* 3144 */       private volatile boolean closed = false;
/* 3145 */       private DatanodeInfo[] targets = null;
/* 3146 */       private boolean lastPacketInBlock = false;
/*      */ 
/*      */       ResponseProcessor(DatanodeInfo[] targets) {
/* 3149 */         this.targets = targets;
/*      */       }
/*      */ 
/*      */       public void run()
/*      */       {
/* 3154 */         setName("ResponseProcessor for block " + DFSClient.DFSOutputStream.this.block);
/* 3155 */         DataTransferProtocol.PipelineAck ack = new DataTransferProtocol.PipelineAck();
/*      */ 
/* 3157 */         while ((!this.closed) && (DFSClient.this.clientRunning) && (!this.lastPacketInBlock))
/*      */         {
/*      */           try
/*      */           {
/* 3161 */             ack.readFields(DFSClient.DFSOutputStream.this.blockReplyStream);
/* 3162 */             if (DFSClient.LOG.isDebugEnabled()) {
/* 3163 */               DFSClient.LOG.debug("DFSClient for block " + DFSClient.DFSOutputStream.this.block + " " + ack);
/*      */             }
/*      */ 
/* 3167 */             for (int i = ack.getNumOfReplies() - 1; (i >= 0) && (DFSClient.this.clientRunning); i--) {
/* 3168 */               short reply = ack.getReply(i);
/* 3169 */               if (reply != 0) {
/* 3170 */                 DFSClient.DFSOutputStream.this.errorIndex = i;
/* 3171 */                 throw new IOException("Bad response " + reply + " for block " + DFSClient.DFSOutputStream.this.block + " from datanode " + this.targets[i].getName());
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/* 3178 */             long seqno = ack.getSeqno();
/*      */ 
/* 3180 */             assert (seqno != -2L) : ("Ack for unkown seqno should be a failed ack: " + ack);
/* 3181 */             if (seqno == -1L)
/*      */             {
/*      */               continue;
/*      */             }
/* 3185 */             DFSClient.DFSOutputStream.Packet one = null;
/* 3186 */             synchronized (DFSClient.DFSOutputStream.this.ackQueue) {
/* 3187 */               one = (DFSClient.DFSOutputStream.Packet)DFSClient.DFSOutputStream.this.ackQueue.getFirst();
/*      */             }
/*      */ 
/* 3190 */             if (one.seqno != seqno) {
/* 3191 */               throw new IOException("Responseprocessor: Expecting seqno  for block " + DFSClient.DFSOutputStream.this.block + " " + one.seqno + " but received " + seqno);
/*      */             }
/*      */ 
/* 3195 */             this.lastPacketInBlock = one.lastPacketInBlock;
/*      */ 
/* 3197 */             synchronized (DFSClient.DFSOutputStream.this.ackQueue) {
/* 3198 */               assert (ack.getSeqno() == DFSClient.DFSOutputStream.this.lastAckedSeqno + 1L);
/* 3199 */               DFSClient.DFSOutputStream.this.lastAckedSeqno = ack.getSeqno();
/* 3200 */               DFSClient.DFSOutputStream.this.ackQueue.removeFirst();
/* 3201 */               DFSClient.DFSOutputStream.this.ackQueue.notifyAll();
/*      */             }
/*      */           } catch (Exception e) {
/* 3204 */             if (!this.closed) {
/* 3205 */               DFSClient.DFSOutputStream.this.hasError = true;
/* 3206 */               if ((e instanceof IOException)) {
/* 3207 */                 DFSClient.DFSOutputStream.this.setLastException((IOException)e);
/*      */               }
/* 3209 */               DFSClient.LOG.warn("DFSOutputStream ResponseProcessor exception  for block " + DFSClient.DFSOutputStream.this.block + StringUtils.stringifyException(e));
/*      */ 
/* 3212 */               this.closed = true;
/*      */             }
/*      */           }
/*      */ 
/* 3216 */           synchronized (DFSClient.DFSOutputStream.this.dataQueue) {
/* 3217 */             DFSClient.DFSOutputStream.this.dataQueue.notifyAll();
/*      */           }
/* 3219 */           synchronized (DFSClient.DFSOutputStream.this.ackQueue) {
/* 3220 */             DFSClient.DFSOutputStream.this.ackQueue.notifyAll();
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       void close() {
/* 3226 */         this.closed = true;
/* 3227 */         interrupt();
/*      */       }
/*      */     }
/*      */ 
/*      */     private class DataStreamer extends Daemon
/*      */     {
/* 2966 */       private volatile boolean closed = false;
/*      */ 
/*      */       private DataStreamer() {  } 
/* 2969 */       public void run() { long lastPacket = 0L;
/*      */ 
/* 2971 */         while ((!this.closed) && (DFSClient.this.clientRunning))
/*      */         {
/* 2974 */           if ((DFSClient.DFSOutputStream.this.hasError) && (DFSClient.DFSOutputStream.this.response != null))
/*      */             try {
/* 2976 */               DFSClient.DFSOutputStream.this.response.close();
/* 2977 */               DFSClient.DFSOutputStream.this.response.join();
/* 2978 */               DFSClient.DFSOutputStream.this.response = null;
/*      */             }
/*      */             catch (InterruptedException e)
/*      */             {
/*      */             }
/* 2983 */           DFSClient.DFSOutputStream.Packet one = null;
/* 2984 */           synchronized (DFSClient.DFSOutputStream.this.dataQueue)
/*      */           {
/* 2987 */             boolean doSleep = DFSClient.DFSOutputStream.this.processDatanodeError(DFSClient.DFSOutputStream.this.hasError, false);
/*      */ 
/* 2990 */             long now = System.currentTimeMillis();
/*      */ 
/* 2995 */             while (((!this.closed) && (!DFSClient.DFSOutputStream.this.hasError) && (DFSClient.this.clientRunning) && (DFSClient.DFSOutputStream.this.dataQueue.size() == 0) && ((DFSClient.DFSOutputStream.this.blockStream == null) || ((DFSClient.DFSOutputStream.this.blockStream != null) && (now - lastPacket < DFSClient.this.timeoutValue / 2)))) || (doSleep)) {
/* 2996 */               long timeout = DFSClient.this.timeoutValue / 2 - (now - lastPacket);
/* 2997 */               timeout = timeout <= 0L ? 1000L : timeout;
/*      */               try
/*      */               {
/* 3000 */                 DFSClient.DFSOutputStream.this.dataQueue.wait(timeout);
/* 3001 */                 now = System.currentTimeMillis();
/*      */               } catch (InterruptedException e) {
/*      */               }
/* 3004 */               doSleep = false;
/*      */             }
/* 3006 */             if ((!this.closed) && (!DFSClient.DFSOutputStream.this.hasError) && (!DFSClient.this.clientRunning))
/*      */             {
/*      */               continue;
/*      */             }
/*      */             try
/*      */             {
/* 3012 */               if (DFSClient.DFSOutputStream.this.dataQueue.isEmpty())
/* 3013 */                 one = new DFSClient.DFSOutputStream.Packet(DFSClient.DFSOutputStream.this);
/*      */               else {
/* 3015 */                 one = (DFSClient.DFSOutputStream.Packet)DFSClient.DFSOutputStream.this.dataQueue.getFirst();
/*      */               }
/*      */ 
/* 3018 */               long offsetInBlock = one.offsetInBlock;
/*      */ 
/* 3021 */               if (DFSClient.DFSOutputStream.this.blockStream == null) {
/* 3022 */                 DFSClient.LOG.debug("Allocating new block");
/* 3023 */                 DFSClient.DFSOutputStream.this.nodes = DFSClient.DFSOutputStream.this.nextBlockOutputStream();
/* 3024 */                 setName("DataStreamer for file " + DFSClient.DFSOutputStream.this.src + " block " + DFSClient.DFSOutputStream.this.block);
/*      */ 
/* 3026 */                 DFSClient.DFSOutputStream.this.response = new DFSClient.DFSOutputStream.ResponseProcessor(DFSClient.DFSOutputStream.this, DFSClient.DFSOutputStream.this.nodes);
/* 3027 */                 DFSClient.DFSOutputStream.this.response.start();
/*      */               }
/*      */ 
/* 3030 */               if (offsetInBlock >= DFSClient.DFSOutputStream.this.blockSize) {
/* 3031 */                 throw new IOException("BlockSize " + DFSClient.DFSOutputStream.this.blockSize + " is smaller than data size. " + " Offset of packet in block " + offsetInBlock + " Aborting file " + DFSClient.DFSOutputStream.this.src);
/*      */               }
/*      */ 
/* 3038 */               ByteBuffer buf = one.getBuffer();
/*      */ 
/* 3041 */               if (!DFSClient.DFSOutputStream.Packet.access$3000(one)) {
/* 3042 */                 DFSClient.DFSOutputStream.this.dataQueue.removeFirst();
/* 3043 */                 DFSClient.DFSOutputStream.this.dataQueue.notifyAll();
/* 3044 */                 synchronized (DFSClient.DFSOutputStream.this.ackQueue) {
/* 3045 */                   DFSClient.DFSOutputStream.this.ackQueue.addLast(one);
/* 3046 */                   DFSClient.DFSOutputStream.this.ackQueue.notifyAll();
/*      */                 }
/*      */ 
/*      */               }
/*      */ 
/* 3051 */               DFSClient.DFSOutputStream.this.blockStream.write(buf.array(), buf.position(), buf.remaining());
/*      */ 
/* 3053 */               if (one.lastPacketInBlock) {
/* 3054 */                 DFSClient.DFSOutputStream.this.blockStream.writeInt(0);
/*      */               }
/* 3056 */               DFSClient.DFSOutputStream.this.blockStream.flush();
/* 3057 */               lastPacket = System.currentTimeMillis();
/*      */ 
/* 3059 */               if (DFSClient.LOG.isDebugEnabled()) {
/* 3060 */                 DFSClient.LOG.debug("DataStreamer block " + DFSClient.DFSOutputStream.this.block + " wrote packet seqno:" + one.seqno + " size:" + buf.remaining() + " offsetInBlock:" + one.offsetInBlock + " lastPacketInBlock:" + one.lastPacketInBlock);
/*      */               }
/*      */ 
/*      */             }
/*      */             catch (Throwable e)
/*      */             {
/* 3067 */               DFSClient.LOG.warn("DataStreamer Exception: " + StringUtils.stringifyException(e));
/*      */ 
/* 3069 */               if ((e instanceof IOException)) {
/* 3070 */                 DFSClient.DFSOutputStream.this.setLastException((IOException)e);
/*      */               }
/* 3072 */               DFSClient.DFSOutputStream.this.hasError = true;
/*      */             }
/*      */           }
/*      */ 
/* 3076 */           if ((!this.closed) && (!DFSClient.DFSOutputStream.this.hasError) && (DFSClient.this.clientRunning))
/*      */           {
/* 3081 */             if (one.lastPacketInBlock) {
/* 3082 */               synchronized (DFSClient.DFSOutputStream.this.ackQueue) {
/* 3083 */                 while ((!DFSClient.DFSOutputStream.this.hasError) && (DFSClient.DFSOutputStream.this.ackQueue.size() != 0) && (DFSClient.this.clientRunning))
/*      */                   try {
/* 3085 */                     DFSClient.DFSOutputStream.this.ackQueue.wait();
/*      */                   }
/*      */                   catch (InterruptedException e) {
/*      */                   }
/*      */               }
/* 3090 */               DFSClient.LOG.debug("Closing old block " + DFSClient.DFSOutputStream.this.block);
/* 3091 */               setName("DataStreamer for file " + DFSClient.DFSOutputStream.this.src);
/*      */ 
/* 3093 */               DFSClient.DFSOutputStream.this.response.close();
/*      */               try {
/* 3095 */                 DFSClient.DFSOutputStream.this.response.join();
/* 3096 */                 DFSClient.DFSOutputStream.this.response = null;
/*      */               }
/*      */               catch (InterruptedException e) {
/*      */               }
/* 3100 */               if ((!this.closed) && (!DFSClient.DFSOutputStream.this.hasError) && (DFSClient.this.clientRunning))
/*      */               {
/* 3104 */                 synchronized (DFSClient.DFSOutputStream.this.dataQueue) {
/* 3105 */                   IOUtils.cleanup(DFSClient.LOG, new Closeable[] { DFSClient.DFSOutputStream.this.blockStream, DFSClient.DFSOutputStream.this.blockReplyStream });
/* 3106 */                   DFSClient.DFSOutputStream.this.nodes = null;
/* 3107 */                   DFSClient.DFSOutputStream.this.response = null;
/* 3108 */                   DFSClient.DFSOutputStream.this.blockStream = null;
/* 3109 */                   DFSClient.DFSOutputStream.this.blockReplyStream = null;
/*      */                 }
/*      */               }
/*      */             } else { if (DFSClient.DFSOutputStream.this.progress != null) DFSClient.DFSOutputStream.this.progress.progress();
/*      */ 
/* 3115 */               if ((DFSClient.DFSOutputStream.this.artificialSlowdown != 0L) && (DFSClient.this.clientRunning)) {
/* 3116 */                 DFSClient.LOG.debug("Sleeping for artificial slowdown of " + DFSClient.DFSOutputStream.this.artificialSlowdown + "ms");
/*      */                 try
/*      */                 {
/* 3119 */                   Thread.sleep(DFSClient.DFSOutputStream.this.artificialSlowdown);
/*      */                 } catch (InterruptedException e) {
/*      */                 }
/*      */               } }
/*      */           }
/*      */         } }
/*      */ 
/*      */       void close() {
/* 3127 */         this.closed = true;
/* 3128 */         synchronized (DFSClient.DFSOutputStream.this.dataQueue) {
/* 3129 */           DFSClient.DFSOutputStream.this.dataQueue.notifyAll();
/*      */         }
/* 3131 */         synchronized (DFSClient.DFSOutputStream.this.ackQueue) {
/* 3132 */           DFSClient.DFSOutputStream.this.ackQueue.notifyAll();
/*      */         }
/* 3134 */         interrupt();
/*      */       }
/*      */     }
/*      */ 
/*      */     private class Packet
/*      */     {
/*      */       ByteBuffer buffer;
/*      */       byte[] buf;
/*      */       long seqno;
/*      */       long offsetInBlock;
/*      */       boolean lastPacketInBlock;
/*      */       int numChunks;
/*      */       int maxChunks;
/*      */       int dataStart;
/*      */       int dataPos;
/*      */       int checksumStart;
/*      */       int checksumPos;
/*      */       private static final long HEART_BEAT_SEQNO = -1L;
/*      */ 
/*      */       Packet()
/*      */       {
/* 2851 */         this.lastPacketInBlock = false;
/* 2852 */         this.numChunks = 0;
/* 2853 */         this.offsetInBlock = 0L;
/* 2854 */         this.seqno = -1L;
/*      */ 
/* 2856 */         this.buffer = null;
/* 2857 */         int packetSize = 25;
/* 2858 */         this.buf = new byte[packetSize];
/*      */ 
/* 2860 */         this.checksumStart = (this.dataStart = packetSize);
/* 2861 */         this.checksumPos = this.checksumStart;
/* 2862 */         this.dataPos = this.dataStart;
/* 2863 */         this.maxChunks = 0;
/*      */       }
/*      */ 
/*      */       Packet(int pktSize, int chunksPerPkt, long offsetInBlock)
/*      */       {
/* 2868 */         this.lastPacketInBlock = false;
/* 2869 */         this.numChunks = 0;
/* 2870 */         this.offsetInBlock = offsetInBlock;
/* 2871 */         this.seqno = DFSClient.DFSOutputStream.this.currentSeqno;
/* 2872 */         DFSClient.DFSOutputStream.access$1708(DFSClient.DFSOutputStream.this);
/*      */ 
/* 2874 */         this.buffer = null;
/* 2875 */         this.buf = new byte[pktSize];
/*      */ 
/* 2877 */         this.checksumStart = 25;
/* 2878 */         this.checksumPos = this.checksumStart;
/* 2879 */         this.dataStart = (this.checksumStart + chunksPerPkt * DFSClient.DFSOutputStream.this.checksum.getChecksumSize());
/* 2880 */         this.dataPos = this.dataStart;
/* 2881 */         this.maxChunks = chunksPerPkt;
/*      */       }
/*      */ 
/*      */       void writeData(byte[] inarray, int off, int len) {
/* 2885 */         if (this.dataPos + len > this.buf.length) {
/* 2886 */           throw new BufferOverflowException();
/*      */         }
/* 2888 */         System.arraycopy(inarray, off, this.buf, this.dataPos, len);
/* 2889 */         this.dataPos += len;
/*      */       }
/*      */ 
/*      */       void writeChecksum(byte[] inarray, int off, int len) {
/* 2893 */         if (this.checksumPos + len > this.dataStart) {
/* 2894 */           throw new BufferOverflowException();
/*      */         }
/* 2896 */         System.arraycopy(inarray, off, this.buf, this.checksumPos, len);
/* 2897 */         this.checksumPos += len;
/*      */       }
/*      */ 
/*      */       ByteBuffer getBuffer()
/*      */       {
/* 2908 */         if (this.buffer != null) {
/* 2909 */           return this.buffer;
/*      */         }
/*      */ 
/* 2914 */         int dataLen = this.dataPos - this.dataStart;
/* 2915 */         int checksumLen = this.checksumPos - this.checksumStart;
/*      */ 
/* 2917 */         if (this.checksumPos != this.dataStart)
/*      */         {
/* 2921 */           System.arraycopy(this.buf, this.checksumStart, this.buf, this.dataStart - checksumLen, checksumLen);
/*      */         }
/*      */ 
/* 2925 */         int pktLen = 4 + dataLen + checksumLen;
/*      */ 
/* 2928 */         this.buffer = ByteBuffer.wrap(this.buf, this.dataStart - this.checksumPos, 21 + pktLen);
/*      */ 
/* 2930 */         this.buf = null;
/* 2931 */         this.buffer.mark();
/*      */ 
/* 2936 */         this.buffer.putInt(pktLen);
/* 2937 */         this.buffer.putLong(this.offsetInBlock);
/* 2938 */         this.buffer.putLong(this.seqno);
/* 2939 */         this.buffer.put((byte)(this.lastPacketInBlock ? 1 : 0));
/*      */ 
/* 2941 */         this.buffer.putInt(dataLen);
/*      */ 
/* 2943 */         this.buffer.reset();
/* 2944 */         return this.buffer;
/*      */       }
/*      */ 
/*      */       private boolean isHeartbeatPacket()
/*      */       {
/* 2952 */         return this.seqno == -1L;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class DFSDataInputStream extends FSDataInputStream
/*      */   {
/*      */     public DFSDataInputStream(DFSClient.DFSInputStream in)
/*      */       throws IOException
/*      */     {
/* 2729 */       super();
/*      */     }
/*      */ 
/*      */     public DatanodeInfo getCurrentDatanode()
/*      */     {
/* 2736 */       return ((DFSClient.DFSInputStream)this.in).getCurrentDatanode();
/*      */     }
/*      */ 
/*      */     public Block getCurrentBlock()
/*      */     {
/* 2743 */       return ((DFSClient.DFSInputStream)this.in).getCurrentBlock();
/*      */     }
/*      */ 
/*      */     synchronized List<LocatedBlock> getAllBlocks()
/*      */       throws IOException
/*      */     {
/* 2750 */       return ((DFSClient.DFSInputStream)this.in).getAllBlocks();
/*      */     }
/*      */ 
/*      */     public long getVisibleLength()
/*      */       throws IOException
/*      */     {
/* 2757 */       return ((DFSClient.DFSInputStream)this.in).getFileLength();
/*      */     }
/*      */   }
/*      */ 
/*      */   public class DFSInputStream extends FSInputStream
/*      */   {
/* 1923 */     private Socket s = null;
/* 1924 */     private boolean closed = false;
/*      */     private String src;
/* 1927 */     private long prefetchSize = 10L * DFSClient.this.defaultBlockSize;
/* 1928 */     private BlockReader blockReader = null;
/*      */     private boolean verifyChecksum;
/* 1930 */     private LocatedBlocks locatedBlocks = null;
/* 1931 */     private DatanodeInfo currentNode = null;
/* 1932 */     private Block currentBlock = null;
/* 1933 */     private long pos = 0L;
/* 1934 */     private long blockEnd = -1L;
/*      */ 
/* 1947 */     private int failures = 0;
/*      */ 
/* 1951 */     private ConcurrentHashMap<DatanodeInfo, DatanodeInfo> deadNodes = new ConcurrentHashMap();
/*      */ 
/* 1953 */     private int buffersize = 1;
/*      */ 
/* 1955 */     private byte[] oneByteBuf = new byte[1];
/*      */ 
/*      */     void addToDeadNodes(DatanodeInfo dnInfo) {
/* 1958 */       this.deadNodes.put(dnInfo, dnInfo);
/*      */     }
/*      */ 
/*      */     DFSInputStream(String src, int buffersize, boolean verifyChecksum) throws IOException
/*      */     {
/* 1963 */       this.verifyChecksum = verifyChecksum;
/* 1964 */       this.buffersize = buffersize;
/* 1965 */       this.src = src;
/* 1966 */       this.prefetchSize = DFSClient.this.conf.getLong("dfs.read.prefetch.size", this.prefetchSize);
/* 1967 */       openInfo();
/*      */     }
/*      */ 
/*      */     synchronized void openInfo()
/*      */       throws IOException
/*      */     {
/* 1974 */       for (int retries = 3; retries > 0; retries--) {
/* 1975 */         if (fetchLocatedBlocks())
/*      */         {
/* 1977 */           return;
/*      */         }
/*      */ 
/* 1983 */         DFSClient.LOG.warn("Last block locations unavailable. Datanodes might not have reported blocks completely. Will retry for " + retries + " times");
/*      */ 
/* 1986 */         waitFor(4000);
/*      */       }
/*      */ 
/* 1989 */       throw new IOException("Could not obtain the last block locations.");
/*      */     }
/*      */ 
/*      */     private void waitFor(int waitTime) throws InterruptedIOException {
/*      */       try {
/* 1994 */         Thread.sleep(waitTime);
/*      */       } catch (InterruptedException e) {
/* 1996 */         throw new InterruptedIOException("Interrupted while getting the last block length.");
/*      */       }
/*      */     }
/*      */ 
/*      */     private boolean fetchLocatedBlocks()
/*      */       throws IOException, FileNotFoundException
/*      */     {
/* 2003 */       LocatedBlocks newInfo = DFSClient.callGetBlockLocations(DFSClient.this.namenode, this.src, 0L, this.prefetchSize);
/*      */ 
/* 2005 */       if (newInfo == null) {
/* 2006 */         throw new FileNotFoundException("File does not exist: " + this.src);
/*      */       }
/*      */ 
/* 2009 */       if ((this.locatedBlocks != null) && (!this.locatedBlocks.isUnderConstruction()) && (!newInfo.isUnderConstruction()))
/*      */       {
/* 2011 */         Iterator oldIter = this.locatedBlocks.getLocatedBlocks().iterator();
/*      */ 
/* 2013 */         Iterator newIter = newInfo.getLocatedBlocks().iterator();
/* 2014 */         while ((oldIter.hasNext()) && (newIter.hasNext())) {
/* 2015 */           if (!((LocatedBlock)oldIter.next()).getBlock().equals(((LocatedBlock)newIter.next()).getBlock())) {
/* 2016 */             throw new IOException("Blocklist for " + this.src + " has changed!");
/*      */           }
/*      */         }
/*      */       }
/* 2020 */       boolean isBlkInfoUpdated = updateBlockInfo(newInfo);
/* 2021 */       this.locatedBlocks = newInfo;
/* 2022 */       this.currentNode = null;
/* 2023 */       return isBlkInfoUpdated;
/*      */     }
/*      */ 
/*      */     private boolean updateBlockInfo(LocatedBlocks newInfo)
/*      */       throws IOException
/*      */     {
/* 2031 */       if ((!DFSClient.this.serverSupportsHdfs200) || (!newInfo.isUnderConstruction()) || (newInfo.locatedBlockCount() <= 0))
/*      */       {
/* 2033 */         return true;
/*      */       }
/*      */ 
/* 2036 */       LocatedBlock last = newInfo.get(newInfo.locatedBlockCount() - 1);
/* 2037 */       boolean lastBlockInFile = last.getStartOffset() + last.getBlockSize() == newInfo.getFileLength();
/*      */ 
/* 2039 */       if (!lastBlockInFile) {
/* 2040 */         return true;
/*      */       }
/*      */ 
/* 2043 */       if (last.getLocations().length == 0) {
/* 2044 */         return false;
/*      */       }
/*      */ 
/* 2047 */       ClientDatanodeProtocol primary = null;
/* 2048 */       Block newBlock = null;
/* 2049 */       for (int i = 0; (i < last.getLocations().length) && (newBlock == null); i++) {
/* 2050 */         DatanodeInfo datanode = last.getLocations()[i];
/*      */         try {
/* 2052 */           primary = DFSClient.createClientDatanodeProtocolProxy(datanode, DFSClient.this.conf, last.getBlock(), last.getBlockToken(), DFSClient.this.socketTimeout, DFSClient.this.connectToDnViaHostname);
/*      */ 
/* 2055 */           newBlock = primary.getBlockInfo(last.getBlock());
/*      */         } catch (IOException e) {
/* 2057 */           if (e.getMessage().startsWith("java.io.IOException: java.lang.NoSuchMethodException: org.apache.hadoop.hdfs.protocol.ClientDatanodeProtocol.getBlockInfo"))
/*      */           {
/* 2062 */             DFSClient.this.serverSupportsHdfs200 = false;
/*      */           }
/* 2064 */           else DFSClient.LOG.info("Failed to get block info from " + datanode.getHostName() + " probably does not have " + last.getBlock(), e);
/*      */ 
/*      */         }
/*      */         finally
/*      */         {
/* 2069 */           if (primary != null) {
/* 2070 */             RPC.stopProxy(primary);
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 2075 */       if (newBlock == null) {
/* 2076 */         if (!DFSClient.this.serverSupportsHdfs200) {
/* 2077 */           return true;
/*      */         }
/* 2079 */         throw new IOException("Failed to get block info from any of the DN in pipeline: " + Arrays.toString(last.getLocations()));
/*      */       }
/*      */ 
/* 2084 */       long newBlockSize = newBlock.getNumBytes();
/* 2085 */       long delta = newBlockSize - last.getBlockSize();
/*      */ 
/* 2088 */       last.getBlock().setNumBytes(newBlockSize);
/* 2089 */       long newlength = newInfo.getFileLength() + delta;
/* 2090 */       newInfo.setFileLength(newlength);
/* 2091 */       DFSClient.LOG.debug("DFSClient setting last block " + last + " to length " + newBlockSize + " filesize is now " + newInfo.getFileLength());
/*      */ 
/* 2093 */       return true;
/*      */     }
/*      */ 
/*      */     public synchronized long getFileLength() {
/* 2097 */       return this.locatedBlocks == null ? 0L : this.locatedBlocks.getFileLength();
/*      */     }
/*      */ 
/*      */     private synchronized boolean blockUnderConstruction() {
/* 2101 */       return this.locatedBlocks.isUnderConstruction();
/*      */     }
/*      */ 
/*      */     public DatanodeInfo getCurrentDatanode()
/*      */     {
/* 2108 */       return this.currentNode;
/*      */     }
/*      */ 
/*      */     public Block getCurrentBlock()
/*      */     {
/* 2115 */       return this.currentBlock;
/*      */     }
/*      */ 
/*      */     synchronized List<LocatedBlock> getAllBlocks()
/*      */       throws IOException
/*      */     {
/* 2122 */       return getBlockRange(0L, getFileLength());
/*      */     }
/*      */ 
/*      */     private synchronized LocatedBlock getBlockAt(long offset, boolean updatePosition)
/*      */       throws IOException
/*      */     {
/* 2136 */       assert (this.locatedBlocks != null) : "locatedBlocks is null";
/*      */ 
/* 2138 */       int targetBlockIdx = this.locatedBlocks.findBlock(offset);
/* 2139 */       if (targetBlockIdx < 0) {
/* 2140 */         targetBlockIdx = LocatedBlocks.getInsertIndex(targetBlockIdx);
/*      */ 
/* 2143 */         LocatedBlocks newBlocks = DFSClient.callGetBlockLocations(DFSClient.this.namenode, this.src, offset, this.prefetchSize);
/* 2144 */         assert (newBlocks != null) : ("Could not find target position " + offset);
/* 2145 */         this.locatedBlocks.insertRange(targetBlockIdx, newBlocks.getLocatedBlocks());
/*      */       }
/* 2147 */       LocatedBlock blk = this.locatedBlocks.get(targetBlockIdx);
/*      */ 
/* 2149 */       if (updatePosition) {
/* 2150 */         this.pos = offset;
/* 2151 */         this.blockEnd = (blk.getStartOffset() + blk.getBlockSize() - 1L);
/* 2152 */         this.currentBlock = blk.getBlock();
/*      */       }
/* 2154 */       return blk;
/*      */     }
/*      */ 
/*      */     private synchronized void fetchBlockAt(long offset) throws IOException
/*      */     {
/* 2159 */       int targetBlockIdx = this.locatedBlocks.findBlock(offset);
/* 2160 */       if (targetBlockIdx < 0) {
/* 2161 */         targetBlockIdx = LocatedBlocks.getInsertIndex(targetBlockIdx);
/*      */       }
/*      */ 
/* 2165 */       LocatedBlocks newBlocks = DFSClient.callGetBlockLocations(DFSClient.this.namenode, this.src, offset, this.prefetchSize);
/* 2166 */       if (newBlocks == null) {
/* 2167 */         throw new IOException("Could not find target position " + offset);
/*      */       }
/* 2169 */       this.locatedBlocks.insertRange(targetBlockIdx, newBlocks.getLocatedBlocks());
/*      */     }
/*      */ 
/*      */     private synchronized List<LocatedBlock> getBlockRange(long offset, long length)
/*      */       throws IOException
/*      */     {
/* 2184 */       assert (this.locatedBlocks != null) : "locatedBlocks is null";
/* 2185 */       List blockRange = new ArrayList();
/*      */ 
/* 2187 */       int blockIdx = this.locatedBlocks.findBlock(offset);
/* 2188 */       if (blockIdx < 0) {
/* 2189 */         blockIdx = LocatedBlocks.getInsertIndex(blockIdx);
/*      */       }
/* 2191 */       long remaining = length;
/* 2192 */       long curOff = offset;
/* 2193 */       while (remaining > 0L) {
/* 2194 */         LocatedBlock blk = null;
/* 2195 */         if (blockIdx < this.locatedBlocks.locatedBlockCount())
/* 2196 */           blk = this.locatedBlocks.get(blockIdx);
/* 2197 */         if ((blk == null) || (curOff < blk.getStartOffset()))
/*      */         {
/* 2199 */           LocatedBlocks newBlocks = DFSClient.callGetBlockLocations(DFSClient.this.namenode, this.src, curOff, remaining);
/* 2200 */           this.locatedBlocks.insertRange(blockIdx, newBlocks.getLocatedBlocks());
/*      */         }
/*      */         else {
/* 2203 */           assert (curOff >= blk.getStartOffset()) : "Block not found";
/* 2204 */           blockRange.add(blk);
/* 2205 */           long bytesRead = blk.getStartOffset() + blk.getBlockSize() - curOff;
/* 2206 */           remaining -= bytesRead;
/* 2207 */           curOff += bytesRead;
/* 2208 */           blockIdx++;
/*      */         }
/*      */       }
/* 2210 */       return blockRange;
/*      */     }
/*      */ 
/*      */     private boolean shouldTryShortCircuitRead(InetSocketAddress targetAddr)
/*      */       throws IOException
/*      */     {
/* 2216 */       return (DFSClient.this.shortCircuitLocalReads) && (!blockUnderConstruction()) && (DFSClient.isLocalAddress(targetAddr));
/*      */     }
/*      */ 
/*      */     private synchronized DatanodeInfo blockSeekTo(long target)
/*      */       throws IOException
/*      */     {
/* 2225 */       if (target >= getFileLength()) {
/* 2226 */         throw new IOException("Attempted to read past end of file");
/*      */       }
/*      */ 
/* 2229 */       if (this.blockReader != null) {
/* 2230 */         this.blockReader.close();
/* 2231 */         this.blockReader = null;
/*      */       }
/*      */ 
/* 2234 */       if (this.s != null) {
/* 2235 */         this.s.close();
/* 2236 */         this.s = null;
/*      */       }
/*      */ 
/* 2242 */       DatanodeInfo chosenNode = null;
/* 2243 */       int refetchToken = 1;
/*      */       while (true)
/*      */       {
/* 2248 */         LocatedBlock targetBlock = getBlockAt(target, true);
/* 2249 */         assert (target == this.pos) : ("Wrong postion " + this.pos + " expect " + target);
/* 2250 */         long offsetIntoBlock = target - targetBlock.getStartOffset();
/*      */ 
/* 2252 */         DFSClient.DNAddrPair retval = chooseDataNode(targetBlock);
/* 2253 */         chosenNode = retval.info;
/* 2254 */         InetSocketAddress targetAddr = retval.addr;
/*      */ 
/* 2258 */         Block blk = targetBlock.getBlock();
/* 2259 */         Token accessToken = targetBlock.getBlockToken();
/* 2260 */         if (shouldTryShortCircuitRead(targetAddr)) {
/*      */           try {
/* 2262 */             this.blockReader = DFSClient.this.getLocalBlockReader(DFSClient.this.conf, this.src, blk, accessToken, chosenNode, DFSClient.this.socketTimeout, offsetIntoBlock);
/*      */ 
/* 2264 */             return chosenNode;
/*      */           } catch (AccessControlException ex) {
/* 2266 */             DFSClient.LOG.warn("Short circuit access failed ", ex);
/*      */ 
/* 2268 */             DFSClient.this.shortCircuitLocalReads = false;
/*      */           } catch (IOException ex) {
/* 2270 */             if ((refetchToken > 0) && (DFSClient.tokenRefetchNeeded(ex, targetAddr)))
/*      */             {
/* 2272 */               refetchToken--;
/* 2273 */               fetchBlockAt(target);
/* 2274 */               continue;
/*      */             }
/* 2276 */             DFSClient.LOG.info("Failed to read " + targetBlock.getBlock() + " on local machine" + StringUtils.stringifyException(ex));
/*      */ 
/* 2278 */             DFSClient.LOG.info("Try reading via the datanode on " + targetAddr);
/*      */           }
/*      */         }
/*      */         else
/*      */           try
/*      */           {
/* 2284 */             this.s = DFSClient.this.socketFactory.createSocket();
/* 2285 */             DFSClient.LOG.debug("Connecting to " + targetAddr);
/* 2286 */             NetUtils.connect(this.s, targetAddr, DFSClient.this.getRandomLocalInterfaceAddr(), DFSClient.this.socketTimeout);
/*      */ 
/* 2288 */             this.s.setSoTimeout(DFSClient.this.socketTimeout);
/* 2289 */             this.blockReader = DFSClient.RemoteBlockReader.newBlockReader(this.s, this.src, blk.getBlockId(), accessToken, blk.getGenerationStamp(), offsetIntoBlock, blk.getNumBytes() - offsetIntoBlock, this.buffersize, this.verifyChecksum, DFSClient.this.clientName);
/*      */ 
/* 2294 */             return chosenNode;
/*      */           } catch (IOException ex) {
/* 2296 */             if ((refetchToken > 0) && (DFSClient.tokenRefetchNeeded(ex, targetAddr))) {
/* 2297 */               refetchToken--;
/* 2298 */               fetchBlockAt(target);
/*      */             } else {
/* 2300 */               DFSClient.LOG.warn("Failed to connect to " + targetAddr + ", add to deadNodes and continue" + ex);
/*      */ 
/* 2302 */               if (DFSClient.LOG.isDebugEnabled()) {
/* 2303 */                 DFSClient.LOG.debug("Connection failure", ex);
/*      */               }
/*      */ 
/* 2306 */               addToDeadNodes(chosenNode);
/*      */             }
/* 2308 */             if (this.s != null)
/*      */               try {
/* 2310 */                 this.s.close();
/*      */               } catch (IOException iex) {
/*      */               }
/* 2313 */             this.s = null;
/*      */           }
/*      */       }
/*      */     }
/*      */ 
/*      */     public synchronized void close()
/*      */       throws IOException
/*      */     {
/* 2323 */       if (this.closed) {
/* 2324 */         return;
/*      */       }
/* 2326 */       DFSClient.this.checkOpen();
/*      */ 
/* 2328 */       if (this.blockReader != null) {
/* 2329 */         this.blockReader.close();
/* 2330 */         this.blockReader = null;
/*      */       }
/*      */ 
/* 2333 */       if (this.s != null) {
/* 2334 */         this.s.close();
/* 2335 */         this.s = null;
/*      */       }
/* 2337 */       super.close();
/* 2338 */       this.closed = true;
/*      */     }
/*      */ 
/*      */     public synchronized int read() throws IOException
/*      */     {
/* 2343 */       int ret = read(this.oneByteBuf, 0, 1);
/* 2344 */       return ret <= 0 ? -1 : this.oneByteBuf[0] & 0xFF;
/*      */     }
/*      */ 
/*      */     private synchronized int readBuffer(byte[] buf, int off, int len)
/*      */       throws IOException
/*      */     {
/* 2361 */       boolean retryCurrentNode = true;
/*      */       while (true)
/*      */       {
/*      */         IOException ioe;
/*      */         try {
/* 2366 */           return this.blockReader.read(buf, off, len);
/*      */         } catch (ChecksumException ce) {
/* 2368 */           DFSClient.LOG.warn("Found Checksum error for " + this.currentBlock + " from " + this.currentNode.getName() + " at " + ce.getPos());
/*      */ 
/* 2370 */           DFSClient.this.reportChecksumFailure(this.src, this.currentBlock, this.currentNode);
/* 2371 */           ioe = ce;
/* 2372 */           retryCurrentNode = false;
/*      */         } catch (IOException e) {
/* 2374 */           if (!retryCurrentNode) {
/* 2375 */             DFSClient.LOG.warn("Exception while reading from " + this.currentBlock + " of " + this.src + " from " + this.currentNode + ": " + StringUtils.stringifyException(e));
/*      */           }
/*      */ 
/* 2379 */           ioe = e;
/*      */         }
/* 2381 */         boolean sourceFound = false;
/* 2382 */         if (retryCurrentNode)
/*      */         {
/* 2387 */           sourceFound = seekToBlockSource(this.pos);
/*      */         } else {
/* 2389 */           addToDeadNodes(this.currentNode);
/* 2390 */           sourceFound = seekToNewSource(this.pos);
/*      */         }
/* 2392 */         if (!sourceFound) {
/* 2393 */           throw ioe;
/*      */         }
/* 2395 */         retryCurrentNode = false;
/*      */       }
/*      */     }
/*      */ 
/*      */     public synchronized int read(byte[] buf, int off, int len)
/*      */       throws IOException
/*      */     {
/* 2404 */       DFSClient.this.checkOpen();
/* 2405 */       if (this.closed) {
/* 2406 */         throw new IOException("Stream closed");
/*      */       }
/* 2408 */       this.failures = 0;
/*      */ 
/* 2410 */       if (this.pos < getFileLength()) {
/* 2411 */         int retries = 2;
/* 2412 */         while (retries > 0) {
/*      */           try {
/* 2414 */             if (this.pos > this.blockEnd) {
/* 2415 */               this.currentNode = blockSeekTo(this.pos);
/*      */             }
/* 2417 */             int realLen = (int)Math.min(len, this.blockEnd - this.pos + 1L);
/* 2418 */             int result = readBuffer(buf, off, realLen);
/*      */ 
/* 2420 */             if (result >= 0) {
/* 2421 */               this.pos += result;
/*      */             }
/*      */             else {
/* 2424 */               throw new IOException("Unexpected EOS from the reader");
/*      */             }
/* 2426 */             if ((DFSClient.this.stats != null) && (result != -1)) {
/* 2427 */               DFSClient.this.stats.incrementBytesRead(result);
/*      */             }
/* 2429 */             return result;
/*      */           } catch (ChecksumException ce) {
/* 2431 */             throw ce;
/*      */           } catch (IOException e) {
/* 2433 */             if (retries == 1) {
/* 2434 */               DFSClient.LOG.warn("DFS Read: " + StringUtils.stringifyException(e));
/*      */             }
/* 2436 */             this.blockEnd = -1L;
/* 2437 */             if (this.currentNode != null) addToDeadNodes(this.currentNode);
/* 2438 */             retries--; if (retries == 0) {
/* 2439 */               throw e;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 2444 */       return -1;
/*      */     }
/*      */ 
/*      */     private DFSClient.DNAddrPair chooseDataNode(LocatedBlock block) throws IOException
/*      */     {
/*      */       while (true)
/*      */       {
/* 2451 */         DatanodeInfo[] nodes = block.getLocations();
/*      */         try {
/* 2453 */           DatanodeInfo chosenNode = DFSClient.this.bestNode(nodes, this.deadNodes);
/* 2454 */           InetSocketAddress targetAddr = NetUtils.createSocketAddr(chosenNode.getName(DFSClient.this.connectToDnViaHostname));
/*      */ 
/* 2456 */           return new DFSClient.DNAddrPair(chosenNode, targetAddr);
/*      */         } catch (IOException ie) {
/* 2458 */           String blockInfo = block.getBlock() + " file=" + this.src;
/* 2459 */           if (this.failures >= DFSClient.this.maxBlockAcquireFailures) {
/* 2460 */             throw new IOException("Could not obtain block: " + blockInfo);
/*      */           }
/*      */ 
/* 2463 */           if ((nodes == null) || (nodes.length == 0)) {
/* 2464 */             DFSClient.LOG.info("No node available for: " + blockInfo);
/*      */           }
/* 2466 */           DFSClient.LOG.info("Could not obtain " + block.getBlock() + " from any node: " + ie + ". Will get new block locations from namenode and retry...");
/*      */           try
/*      */           {
/* 2470 */             Thread.sleep(3000L);
/*      */           } catch (InterruptedException iex) {
/*      */           }
/* 2473 */           this.deadNodes.clear();
/* 2474 */           openInfo();
/* 2475 */           block = getBlockAt(block.getStartOffset(), false);
/* 2476 */           this.failures += 1;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     private void fetchBlockByteRange(LocatedBlock block, long start, long end, byte[] buf, int offset)
/*      */       throws IOException
/*      */     {
/* 2487 */       Socket dn = null;
/* 2488 */       int refetchToken = 1;
/*      */       while (true)
/*      */       {
/* 2494 */         block = getBlockAt(block.getStartOffset(), false);
/* 2495 */         DFSClient.DNAddrPair retval = chooseDataNode(block);
/* 2496 */         DatanodeInfo chosenNode = retval.info;
/* 2497 */         InetSocketAddress targetAddr = retval.addr;
/* 2498 */         BlockReader reader = null;
/*      */         try
/*      */         {
/* 2501 */           Token accessToken = block.getBlockToken();
/* 2502 */           int len = (int)(end - start + 1L);
/*      */ 
/* 2505 */           if (shouldTryShortCircuitRead(targetAddr)) {
/*      */             try {
/* 2507 */               reader = DFSClient.this.getLocalBlockReader(DFSClient.this.conf, this.src, block.getBlock(), accessToken, chosenNode, DFSClient.this.socketTimeout, start);
/*      */             }
/*      */             catch (AccessControlException ex) {
/* 2510 */               DFSClient.LOG.warn("Short circuit access failed ", ex);
/*      */ 
/* 2512 */               DFSClient.this.shortCircuitLocalReads = false;
/*      */ 
/* 2551 */               IOUtils.closeStream(reader);
/* 2552 */             }IOUtils.closeSocket(dn); continue;
/*      */           }
/* 2517 */           dn = DFSClient.this.socketFactory.createSocket();
/* 2518 */           DFSClient.LOG.debug("Connecting to " + targetAddr);
/* 2519 */           NetUtils.connect(dn, targetAddr, DFSClient.this.getRandomLocalInterfaceAddr(), DFSClient.this.socketTimeout);
/*      */ 
/* 2521 */           dn.setSoTimeout(DFSClient.this.socketTimeout);
/* 2522 */           reader = DFSClient.RemoteBlockReader.newBlockReader(dn, this.src, block.getBlock().getBlockId(), accessToken, block.getBlock().getGenerationStamp(), start, len, this.buffersize, this.verifyChecksum, DFSClient.this.clientName);
/*      */ 
/* 2527 */           int nread = reader.readAll(buf, offset, len);
/* 2528 */           if (nread != len)
/* 2529 */             throw new IOException("truncated return from reader.read(): excpected " + len + ", got " + nread);
/*      */           return;
/*      */         }
/*      */         catch (ChecksumException e)
/*      */         {
/* 2534 */           DFSClient.LOG.warn("fetchBlockByteRange(). Got a checksum exception for " + this.src + " at " + block.getBlock() + ":" + e.getPos() + " from " + chosenNode.getName());
/*      */ 
/* 2537 */           DFSClient.this.reportChecksumFailure(this.src, block.getBlock(), chosenNode);
/*      */         } catch (IOException e) {
/* 2539 */           if ((refetchToken > 0) && (DFSClient.tokenRefetchNeeded(e, targetAddr))) {
/* 2540 */             refetchToken--;
/* 2541 */             fetchBlockAt(block.getStartOffset());
/*      */ 
/* 2551 */             IOUtils.closeStream(reader);
/* 2552 */             IOUtils.closeSocket(dn); continue;
/*      */           }
/* 2544 */           DFSClient.LOG.warn("Failed to connect to " + targetAddr + " for file " + this.src + " for block " + block.getBlock() + ":" + e);
/*      */ 
/* 2546 */           if (DFSClient.LOG.isDebugEnabled())
/* 2547 */             DFSClient.LOG.debug("Connection failure ", e);
/*      */         }
/*      */         finally
/*      */         {
/* 2551 */           IOUtils.closeStream(reader);
/* 2552 */           IOUtils.closeSocket(dn);
/*      */         }
/*      */ 
/* 2555 */         addToDeadNodes(chosenNode);
/*      */       }
/*      */     }
/*      */ 
/*      */     public int read(long position, byte[] buffer, int offset, int length)
/*      */       throws IOException
/*      */     {
/* 2573 */       DFSClient.this.checkOpen();
/* 2574 */       if (this.closed) {
/* 2575 */         throw new IOException("Stream closed");
/*      */       }
/* 2577 */       this.failures = 0;
/* 2578 */       long filelen = getFileLength();
/* 2579 */       if ((position < 0L) || (position >= filelen)) {
/* 2580 */         return -1;
/*      */       }
/* 2582 */       int realLen = length;
/* 2583 */       if (position + length > filelen) {
/* 2584 */         realLen = (int)(filelen - position);
/*      */       }
/*      */ 
/* 2589 */       List blockRange = getBlockRange(position, realLen);
/* 2590 */       int remaining = realLen;
/* 2591 */       for (LocatedBlock blk : blockRange) {
/* 2592 */         long targetStart = position - blk.getStartOffset();
/* 2593 */         long bytesToRead = Math.min(remaining, blk.getBlockSize() - targetStart);
/* 2594 */         fetchBlockByteRange(blk, targetStart, targetStart + bytesToRead - 1L, buffer, offset);
/*      */ 
/* 2596 */         remaining = (int)(remaining - bytesToRead);
/* 2597 */         position += bytesToRead;
/* 2598 */         offset = (int)(offset + bytesToRead);
/*      */       }
/* 2600 */       assert (remaining == 0) : "Wrong number of bytes read.";
/* 2601 */       if (DFSClient.this.stats != null) {
/* 2602 */         DFSClient.this.stats.incrementBytesRead(realLen);
/*      */       }
/* 2604 */       return realLen;
/*      */     }
/*      */ 
/*      */     public long skip(long n) throws IOException
/*      */     {
/* 2609 */       if (n > 0L) {
/* 2610 */         long curPos = getPos();
/* 2611 */         long fileLen = getFileLength();
/* 2612 */         if (n + curPos > fileLen) {
/* 2613 */           n = fileLen - curPos;
/*      */         }
/* 2615 */         seek(curPos + n);
/* 2616 */         return n;
/*      */       }
/* 2618 */       return n < 0L ? -1L : 0L;
/*      */     }
/*      */ 
/*      */     public synchronized void seek(long targetPos)
/*      */       throws IOException
/*      */     {
/* 2626 */       if (targetPos > getFileLength()) {
/* 2627 */         throw new IOException("Cannot seek after EOF");
/*      */       }
/* 2629 */       boolean done = false;
/* 2630 */       if ((this.pos <= targetPos) && (targetPos <= this.blockEnd))
/*      */       {
/* 2636 */         int diff = (int)(targetPos - this.pos);
/* 2637 */         if (diff <= 131072) {
/*      */           try {
/* 2639 */             this.pos += this.blockReader.skip(diff);
/* 2640 */             if (this.pos == targetPos)
/* 2641 */               done = true;
/*      */           }
/*      */           catch (IOException e) {
/* 2644 */             DFSClient.LOG.debug("Exception while seek to " + targetPos + " from " + this.currentBlock + " of " + this.src + " from " + this.currentNode + ": " + StringUtils.stringifyException(e));
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2650 */       if (!done) {
/* 2651 */         this.pos = targetPos;
/* 2652 */         this.blockEnd = -1L;
/*      */       }
/*      */     }
/*      */ 
/*      */     private synchronized boolean seekToBlockSource(long targetPos)
/*      */       throws IOException
/*      */     {
/* 2662 */       this.currentNode = blockSeekTo(targetPos);
/* 2663 */       return true;
/*      */     }
/*      */ 
/*      */     public synchronized boolean seekToNewSource(long targetPos)
/*      */       throws IOException
/*      */     {
/* 2673 */       boolean markedDead = this.deadNodes.containsKey(this.currentNode);
/* 2674 */       addToDeadNodes(this.currentNode);
/* 2675 */       DatanodeInfo oldNode = this.currentNode;
/* 2676 */       DatanodeInfo newNode = blockSeekTo(targetPos);
/* 2677 */       if (!markedDead)
/*      */       {
/* 2680 */         this.deadNodes.remove(oldNode);
/*      */       }
/* 2682 */       if (!oldNode.getStorageID().equals(newNode.getStorageID())) {
/* 2683 */         this.currentNode = newNode;
/* 2684 */         return true;
/*      */       }
/* 2686 */       return false;
/*      */     }
/*      */ 
/*      */     public synchronized long getPos()
/*      */       throws IOException
/*      */     {
/* 2694 */       return this.pos;
/*      */     }
/*      */ 
/*      */     public synchronized int available()
/*      */       throws IOException
/*      */     {
/* 2701 */       if (this.closed) {
/* 2702 */         throw new IOException("Stream closed");
/*      */       }
/* 2704 */       return (int)(getFileLength() - this.pos);
/*      */     }
/*      */ 
/*      */     public boolean markSupported()
/*      */     {
/* 2712 */       return false;
/*      */     }
/*      */ 
/*      */     public void mark(int readLimit) {
/*      */     }
/*      */ 
/*      */     public void reset() throws IOException {
/* 2719 */       throw new IOException("Mark/reset not supported");
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class RemoteBlockReader extends FSInputChecker
/*      */     implements BlockReader
/*      */   {
/*      */     private Socket dnSock;
/*      */     private DataInputStream in;
/*      */     private DataChecksum checksum;
/* 1550 */     private long lastChunkOffset = -1L;
/* 1551 */     private long lastChunkLen = -1L;
/* 1552 */     private long lastSeqNo = -1L;
/*      */     private long startOffset;
/*      */     private long firstChunkOffset;
/*      */     private int bytesPerChecksum;
/*      */     private int checksumSize;
/* 1558 */     private boolean gotEOS = false;
/*      */ 
/* 1560 */     byte[] skipBuf = null;
/* 1561 */     ByteBuffer checksumBytes = null;
/* 1562 */     int dataLeft = 0;
/* 1563 */     boolean isLastPacket = false;
/*      */ 
/*      */     public synchronized int read(byte[] buf, int off, int len)
/*      */       throws IOException
/*      */     {
/* 1579 */       if ((this.lastChunkLen < 0L) && (this.startOffset > this.firstChunkOffset) && (len > 0))
/*      */       {
/* 1581 */         int toSkip = (int)(this.startOffset - this.firstChunkOffset);
/* 1582 */         if (this.skipBuf == null) {
/* 1583 */           this.skipBuf = new byte[this.bytesPerChecksum];
/*      */         }
/* 1585 */         if (super.read(this.skipBuf, 0, toSkip) != toSkip)
/*      */         {
/* 1587 */           throw new IOException("Could not skip required number of bytes");
/*      */         }
/*      */       }
/*      */ 
/* 1591 */       boolean eosBefore = this.gotEOS;
/* 1592 */       int nRead = super.read(buf, off, len);
/*      */ 
/* 1595 */       if ((this.dnSock != null) && (this.gotEOS) && (!eosBefore) && (nRead >= 0) && (needChecksum()))
/*      */       {
/* 1598 */         checksumOk(this.dnSock);
/*      */       }
/* 1600 */       return nRead;
/*      */     }
/*      */ 
/*      */     public synchronized long skip(long n)
/*      */       throws IOException
/*      */     {
/* 1607 */       if (this.skipBuf == null) {
/* 1608 */         this.skipBuf = new byte[this.bytesPerChecksum];
/*      */       }
/*      */ 
/* 1611 */       long nSkipped = 0L;
/* 1612 */       while (nSkipped < n) {
/* 1613 */         int toSkip = (int)Math.min(n - nSkipped, this.skipBuf.length);
/* 1614 */         int ret = read(this.skipBuf, 0, toSkip);
/* 1615 */         if (ret <= 0) {
/* 1616 */           return nSkipped;
/*      */         }
/* 1618 */         nSkipped += ret;
/*      */       }
/* 1620 */       return nSkipped;
/*      */     }
/*      */ 
/*      */     public int read() throws IOException
/*      */     {
/* 1625 */       throw new IOException("read() is not expected to be invoked. Use read(buf, off, len) instead.");
/*      */     }
/*      */ 
/*      */     public boolean seekToNewSource(long targetPos)
/*      */       throws IOException
/*      */     {
/* 1635 */       return false;
/*      */     }
/*      */ 
/*      */     public void seek(long pos) throws IOException
/*      */     {
/* 1640 */       throw new IOException("Seek() is not supported in BlockInputChecker");
/*      */     }
/*      */ 
/*      */     protected long getChunkPosition(long pos)
/*      */     {
/* 1645 */       throw new RuntimeException("getChunkPosition() is not supported, since seek is not required");
/*      */     }
/*      */ 
/*      */     private void adjustChecksumBytes(int dataLen)
/*      */     {
/* 1655 */       int requiredSize = (dataLen + this.bytesPerChecksum - 1) / this.bytesPerChecksum * this.checksumSize;
/*      */ 
/* 1657 */       if ((this.checksumBytes == null) || (requiredSize > this.checksumBytes.capacity()))
/* 1658 */         this.checksumBytes = ByteBuffer.wrap(new byte[requiredSize]);
/*      */       else {
/* 1660 */         this.checksumBytes.clear();
/*      */       }
/* 1662 */       this.checksumBytes.limit(requiredSize);
/*      */     }
/*      */ 
/*      */     protected synchronized int readChunk(long pos, byte[] buf, int offset, int len, byte[] checksumBuf)
/*      */       throws IOException
/*      */     {
/* 1671 */       if (this.gotEOS) {
/* 1672 */         if (this.startOffset < 0L)
/*      */         {
/* 1674 */           throw new IOException("BlockRead: already got EOS or an error");
/*      */         }
/* 1676 */         this.startOffset = -1L;
/* 1677 */         return -1;
/*      */       }
/*      */ 
/* 1681 */       long chunkOffset = this.lastChunkOffset;
/* 1682 */       if (this.lastChunkLen > 0L) {
/* 1683 */         chunkOffset += this.lastChunkLen;
/*      */       }
/*      */ 
/* 1686 */       if (pos + this.firstChunkOffset != chunkOffset) {
/* 1687 */         throw new IOException("Mismatch in pos : " + pos + " + " + this.firstChunkOffset + " != " + chunkOffset);
/*      */       }
/*      */ 
/* 1692 */       if (this.dataLeft <= 0)
/*      */       {
/* 1694 */         int packetLen = this.in.readInt();
/* 1695 */         long offsetInBlock = this.in.readLong();
/* 1696 */         long seqno = this.in.readLong();
/* 1697 */         boolean lastPacketInBlock = this.in.readBoolean();
/*      */ 
/* 1699 */         if (LOG.isDebugEnabled()) {
/* 1700 */           LOG.debug("DFSClient readChunk got seqno " + seqno + " offsetInBlock " + offsetInBlock + " lastPacketInBlock " + lastPacketInBlock + " packetLen " + packetLen);
/*      */         }
/*      */ 
/* 1706 */         int dataLen = this.in.readInt();
/*      */ 
/* 1709 */         if ((dataLen < 0) || ((dataLen % this.bytesPerChecksum != 0) && (!lastPacketInBlock)) || (seqno != this.lastSeqNo + 1L))
/*      */         {
/* 1712 */           throw new IOException("BlockReader: error in packet header(chunkOffset : " + chunkOffset + ", dataLen : " + dataLen + ", seqno : " + seqno + " (last: " + this.lastSeqNo + "))");
/*      */         }
/*      */ 
/* 1719 */         this.lastSeqNo = seqno;
/* 1720 */         this.isLastPacket = lastPacketInBlock;
/* 1721 */         this.dataLeft = dataLen;
/* 1722 */         adjustChecksumBytes(dataLen);
/* 1723 */         if (dataLen > 0) {
/* 1724 */           IOUtils.readFully(this.in, this.checksumBytes.array(), 0, this.checksumBytes.limit());
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1729 */       int chunkLen = Math.min(this.dataLeft, this.bytesPerChecksum);
/*      */ 
/* 1731 */       if (chunkLen > 0)
/*      */       {
/* 1733 */         IOUtils.readFully(this.in, buf, offset, chunkLen);
/* 1734 */         this.checksumBytes.get(checksumBuf, 0, this.checksumSize);
/*      */       }
/*      */ 
/* 1737 */       this.dataLeft -= chunkLen;
/* 1738 */       this.lastChunkOffset = chunkOffset;
/* 1739 */       this.lastChunkLen = chunkLen;
/*      */ 
/* 1741 */       if (((this.dataLeft == 0) && (this.isLastPacket)) || (chunkLen == 0)) {
/* 1742 */         this.gotEOS = true;
/*      */       }
/* 1744 */       if (chunkLen == 0) {
/* 1745 */         return -1;
/*      */       }
/*      */ 
/* 1748 */       return chunkLen;
/*      */     }
/*      */ 
/*      */     private RemoteBlockReader(String file, long blockId, DataInputStream in, DataChecksum checksum, boolean verifyChecksum, long startOffset, long firstChunkOffset, Socket dnSock)
/*      */     {
/* 1755 */       super(1, verifyChecksum, checksum.getChecksumSize() > 0 ? checksum : null, checksum.getBytesPerChecksum(), checksum.getChecksumSize());
/*      */ 
/* 1761 */       this.dnSock = dnSock;
/* 1762 */       this.in = in;
/* 1763 */       this.checksum = checksum;
/* 1764 */       this.startOffset = Math.max(startOffset, 0L);
/*      */ 
/* 1766 */       this.firstChunkOffset = firstChunkOffset;
/* 1767 */       this.lastChunkOffset = firstChunkOffset;
/* 1768 */       this.lastChunkLen = -1L;
/*      */ 
/* 1770 */       this.bytesPerChecksum = this.checksum.getBytesPerChecksum();
/* 1771 */       this.checksumSize = this.checksum.getChecksumSize();
/*      */     }
/*      */ 
/*      */     RemoteBlockReader(Path file, int numRetries)
/*      */     {
/* 1778 */       super(numRetries);
/*      */     }
/*      */ 
/*      */     protected RemoteBlockReader(Path file, int numRetries, DataChecksum checksum, boolean verifyChecksum)
/*      */     {
/* 1783 */       super(numRetries, verifyChecksum, checksum.getChecksumSize() > 0 ? checksum : null, checksum.getBytesPerChecksum(), checksum.getChecksumSize());
/*      */     }
/*      */ 
/*      */     public static BlockReader newBlockReader(Socket sock, String file, long blockId, Token<BlockTokenIdentifier> accessToken, long genStamp, long startOffset, long len, int bufferSize)
/*      */       throws IOException
/*      */     {
/* 1793 */       return newBlockReader(sock, file, blockId, accessToken, genStamp, startOffset, len, bufferSize, true);
/*      */     }
/*      */ 
/*      */     public static BlockReader newBlockReader(Socket sock, String file, long blockId, Token<BlockTokenIdentifier> accessToken, long genStamp, long startOffset, long len, int bufferSize, boolean verifyChecksum)
/*      */       throws IOException
/*      */     {
/* 1817 */       return newBlockReader(sock, file, blockId, accessToken, genStamp, startOffset, len, bufferSize, verifyChecksum, "");
/*      */     }
/*      */ 
/*      */     public static BlockReader newBlockReader(Socket sock, String file, long blockId, Token<BlockTokenIdentifier> accessToken, long genStamp, long startOffset, long len, int bufferSize, boolean verifyChecksum, String clientName)
/*      */       throws IOException
/*      */     {
/* 1830 */       DataOutputStream out = new DataOutputStream(new BufferedOutputStream(NetUtils.getOutputStream(sock, 480000L)));
/*      */ 
/* 1834 */       out.writeShort(17);
/* 1835 */       out.write(81);
/* 1836 */       out.writeLong(blockId);
/* 1837 */       out.writeLong(genStamp);
/* 1838 */       out.writeLong(startOffset);
/* 1839 */       out.writeLong(len);
/* 1840 */       Text.writeString(out, clientName);
/* 1841 */       accessToken.write(out);
/* 1842 */       out.flush();
/*      */ 
/* 1848 */       DataInputStream in = new DataInputStream(new BufferedInputStream(NetUtils.getInputStream(sock), bufferSize));
/*      */ 
/* 1852 */       short status = in.readShort();
/* 1853 */       if (status != 0) {
/* 1854 */         if (status == 5) {
/* 1855 */           throw new InvalidBlockTokenException("Got access token error for OP_READ_BLOCK, self=" + sock.getLocalSocketAddress() + ", remote=" + sock.getRemoteSocketAddress() + ", for file " + file + ", for block " + blockId + "_" + genStamp);
/*      */         }
/*      */ 
/* 1861 */         throw new IOException("Got error for OP_READ_BLOCK, self=" + sock.getLocalSocketAddress() + ", remote=" + sock.getRemoteSocketAddress() + ", for file " + file + ", for block " + blockId + "_" + genStamp);
/*      */       }
/*      */ 
/* 1867 */       DataChecksum checksum = DataChecksum.newDataChecksum(in);
/*      */ 
/* 1871 */       long firstChunkOffset = in.readLong();
/*      */ 
/* 1873 */       if ((firstChunkOffset < 0L) || (firstChunkOffset > startOffset) || (firstChunkOffset >= startOffset + checksum.getBytesPerChecksum()))
/*      */       {
/* 1875 */         throw new IOException("BlockReader: error in first chunk offset (" + firstChunkOffset + ") startOffset is " + startOffset + " for file " + file);
/*      */       }
/*      */ 
/* 1880 */       return new RemoteBlockReader(file, blockId, in, checksum, verifyChecksum, startOffset, firstChunkOffset, sock);
/*      */     }
/*      */ 
/*      */     public synchronized void close()
/*      */       throws IOException
/*      */     {
/* 1886 */       this.startOffset = -1L;
/* 1887 */       this.checksum = null;
/*      */     }
/*      */ 
/*      */     public int readAll(byte[] buf, int offset, int len)
/*      */       throws IOException
/*      */     {
/* 1896 */       return readFully(this, buf, offset, len);
/*      */     }
/*      */ 
/*      */     private void checksumOk(Socket sock)
/*      */     {
/*      */       try
/*      */       {
/* 1905 */         OutputStream out = NetUtils.getOutputStream(sock, 480000L);
/* 1906 */         byte[] buf = { 0, 6 };
/*      */ 
/* 1908 */         out.write(buf);
/* 1909 */         out.flush();
/*      */       }
/*      */       catch (IOException e) {
/* 1912 */         LOG.debug("Could not write to datanode " + sock.getInetAddress() + ": " + e.getMessage());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class DNAddrPair
/*      */   {
/*      */     DatanodeInfo info;
/*      */     InetSocketAddress addr;
/*      */ 
/*      */     DNAddrPair(DatanodeInfo info, InetSocketAddress addr)
/*      */     {
/* 1537 */       this.info = info;
/* 1538 */       this.addr = addr;
/*      */     }
/*      */   }
/*      */ 
/*      */   @InterfaceAudience.Private
/*      */   public static class Renewer extends TokenRenewer
/*      */   {
/*      */     public boolean handleKind(Text kind)
/*      */     {
/*  606 */       return DelegationTokenIdentifier.HDFS_DELEGATION_KIND.equals(kind);
/*      */     }
/*      */ 
/*      */     public long renew(Token<?> token, Configuration conf)
/*      */       throws IOException
/*      */     {
/*  612 */       Token delToken = token;
/*      */ 
/*  614 */       DFSClient.LOG.info("Renewing " + DFSClient.stringifyToken(delToken));
/*  615 */       InetSocketAddress addr = SecurityUtil.getTokenServiceAddr(token);
/*  616 */       ClientProtocol nn = DFSClient.createRPCNamenode(addr, conf, UserGroupInformation.getCurrentUser());
/*      */       try
/*      */       {
/*  619 */         return nn.renewDelegationToken(delToken);
/*      */       } catch (RemoteException re) {
/*  621 */         throw re.unwrapRemoteException(new Class[] { SecretManager.InvalidToken.class, AccessControlException.class });
/*      */       }
/*      */     }
/*      */ 
/*      */     public void cancel(Token<?> token, Configuration conf)
/*      */       throws IOException
/*      */     {
/*  629 */       Token delToken = token;
/*      */ 
/*  631 */       DFSClient.LOG.info("Cancelling " + DFSClient.stringifyToken(delToken));
/*  632 */       InetSocketAddress addr = SecurityUtil.getTokenServiceAddr(token);
/*  633 */       ClientProtocol nn = DFSClient.createRPCNamenode(addr, conf, UserGroupInformation.getCurrentUser());
/*      */       try
/*      */       {
/*  636 */         nn.cancelDelegationToken(delToken);
/*      */       } catch (RemoteException re) {
/*  638 */         throw re.unwrapRemoteException(new Class[] { SecretManager.InvalidToken.class, AccessControlException.class });
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean isManaged(Token<?> token)
/*      */       throws IOException
/*      */     {
/*  645 */       return true;
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.DFSClient
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ import com.sun.jersey.api.core.HttpContext;
/*    */ import com.sun.jersey.core.spi.component.ComponentContext;
/*    */ import com.sun.jersey.core.spi.component.ComponentScope;
/*    */ import com.sun.jersey.server.impl.inject.AbstractHttpContextInjectable;
/*    */ import com.sun.jersey.spi.inject.Injectable;
/*    */ import com.sun.jersey.spi.inject.InjectableProvider;
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.ws.rs.core.Context;
/*    */ import javax.ws.rs.ext.Provider;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ import org.apache.hadoop.hdfs.server.namenode.JspHelper;
/*    */ import org.apache.hadoop.security.UserGroupInformation;
/*    */ import org.apache.hadoop.security.UserGroupInformation.AuthenticationMethod;
/*    */ 
/*    */ @Provider
/*    */ public class UserProvider extends AbstractHttpContextInjectable<UserGroupInformation>
/*    */   implements InjectableProvider<Context, Type>
/*    */ {
/*    */ 
/*    */   @Context
/*    */   HttpServletRequest request;
/*    */ 
/*    */   @Context
/*    */   ServletContext servletcontext;
/*    */ 
/*    */   public UserGroupInformation getValue(HttpContext context)
/*    */   {
/* 50 */     Configuration conf = (Configuration)this.servletcontext.getAttribute("current.conf");
/*    */     try
/*    */     {
/* 53 */       return JspHelper.getUGI(this.servletcontext, this.request, conf, UserGroupInformation.AuthenticationMethod.KERBEROS, false);
/*    */     }
/*    */     catch (IOException e) {
/* 56 */       throw new SecurityException("Failed to obtain user group information: " + e, e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public ComponentScope getScope()
/*    */   {
/* 63 */     return ComponentScope.PerRequest;
/*    */   }
/*    */ 
/*    */   public Injectable<UserGroupInformation> getInjectable(ComponentContext componentContext, Context context, Type type)
/*    */   {
/* 70 */     return type.equals(UserGroupInformation.class) ? this : null;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.UserProvider
 * JD-Core Version:    0.6.1
 */
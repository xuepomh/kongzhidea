/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ public class RenewerParam extends StringParam
/*    */ {
/*    */   public static final String NAME = "renewer";
/*    */   public static final String DEFAULT = "null";
/* 27 */   private static final StringParam.Domain DOMAIN = new StringParam.Domain("renewer", null);
/*    */ 
/*    */   public RenewerParam(String str)
/*    */   {
/* 34 */     super(DOMAIN, (str == null) || (str.equals("null")) ? null : str);
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 39 */     return "renewer";
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.RenewerParam
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ abstract class BooleanParam extends Param<Boolean, Domain>
/*    */ {
/*    */   static final String TRUE = "true";
/*    */   static final String FALSE = "false";
/*    */ 
/*    */   BooleanParam(Domain domain, Boolean value)
/*    */   {
/* 26 */     super(domain, value);
/*    */   }
/*    */ 
/*    */   static final class Domain extends Param.Domain<Boolean>
/*    */   {
/*    */     Domain(String paramName) {
/* 32 */       super();
/*    */     }
/*    */ 
/*    */     public String getDomain()
/*    */     {
/* 37 */       return "<null | boolean>";
/*    */     }
/*    */ 
/*    */     Boolean parse(String str)
/*    */     {
/* 42 */       if ("true".equalsIgnoreCase(str))
/* 43 */         return Boolean.valueOf(true);
/* 44 */       if ("false".equalsIgnoreCase(str)) {
/* 45 */         return Boolean.valueOf(false);
/*    */       }
/* 47 */       throw new IllegalArgumentException("Failed to parse \"" + str + "\" to Boolean.");
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.BooleanParam
 * JD-Core Version:    0.6.1
 */
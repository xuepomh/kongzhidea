/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ 
/*    */ public class ReplicationParam extends ShortParam
/*    */ {
/*    */   public static final String NAME = "replication";
/*    */   public static final String DEFAULT = "null";
/* 32 */   private static final ShortParam.Domain DOMAIN = new ShortParam.Domain("replication");
/*    */ 
/*    */   public ReplicationParam(Short value)
/*    */   {
/* 39 */     super(DOMAIN, value, Short.valueOf((short)1), null);
/*    */   }
/*    */ 
/*    */   public ReplicationParam(String str)
/*    */   {
/* 47 */     this(DOMAIN.parse(str));
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 52 */     return "replication";
/*    */   }
/*    */ 
/*    */   public short getValue(Configuration conf)
/*    */   {
/* 57 */     return getValue() != null ? ((Short)getValue()).shortValue() : (short)conf.getInt("dfs.replication", 3);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.ReplicationParam
 * JD-Core Version:    0.6.1
 */
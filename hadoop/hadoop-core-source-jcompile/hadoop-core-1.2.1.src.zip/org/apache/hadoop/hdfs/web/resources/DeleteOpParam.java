/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ public class DeleteOpParam extends HttpOpParam<Op>
/*    */ {
/* 62 */   private static final EnumParam.Domain<Op> DOMAIN = new EnumParam.Domain("op", Op.class);
/*    */ 
/*    */   public DeleteOpParam(String str)
/*    */   {
/* 69 */     super(DOMAIN, DOMAIN.parse(str));
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 74 */     return "op";
/*    */   }
/*    */ 
/*    */   public static enum Op
/*    */     implements HttpOpParam.Op
/*    */   {
/* 26 */     DELETE(200), 
/*    */ 
/* 28 */     NULL(501);
/*    */ 
/*    */     final int expectedHttpResponseCode;
/*    */ 
/*    */     private Op(int expectedHttpResponseCode) {
/* 33 */       this.expectedHttpResponseCode = expectedHttpResponseCode;
/*    */     }
/*    */ 
/*    */     public HttpOpParam.Type getType()
/*    */     {
/* 38 */       return HttpOpParam.Type.DELETE;
/*    */     }
/*    */ 
/*    */     public boolean getDoOutput()
/*    */     {
/* 43 */       return false;
/*    */     }
/*    */ 
/*    */     public boolean getRedirect()
/*    */     {
/* 48 */       return false;
/*    */     }
/*    */ 
/*    */     public int getExpectedHttpResponseCode()
/*    */     {
/* 53 */       return this.expectedHttpResponseCode;
/*    */     }
/*    */ 
/*    */     public String toQueryString()
/*    */     {
/* 58 */       return "op=" + this;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.DeleteOpParam
 * JD-Core Version:    0.6.1
 */
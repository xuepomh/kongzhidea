/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ public class PostOpParam extends HttpOpParam<Op>
/*    */ {
/* 66 */   private static final EnumParam.Domain<Op> DOMAIN = new EnumParam.Domain("op", Op.class);
/*    */ 
/*    */   public PostOpParam(String str)
/*    */   {
/* 73 */     super(DOMAIN, DOMAIN.parse(str));
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 78 */     return "op";
/*    */   }
/*    */ 
/*    */   public static enum Op
/*    */     implements HttpOpParam.Op
/*    */   {
/* 26 */     APPEND(true, 200), 
/*    */ 
/* 28 */     CONCAT(false, 200), 
/*    */ 
/* 30 */     NULL(false, 501);
/*    */ 
/*    */     final boolean doOutputAndRedirect;
/*    */     final int expectedHttpResponseCode;
/*    */ 
/* 36 */     private Op(boolean doOutputAndRedirect, int expectedHttpResponseCode) { this.doOutputAndRedirect = doOutputAndRedirect;
/* 37 */       this.expectedHttpResponseCode = expectedHttpResponseCode;
/*    */     }
/*    */ 
/*    */     public HttpOpParam.Type getType()
/*    */     {
/* 42 */       return HttpOpParam.Type.POST;
/*    */     }
/*    */ 
/*    */     public boolean getDoOutput()
/*    */     {
/* 47 */       return this.doOutputAndRedirect;
/*    */     }
/*    */ 
/*    */     public boolean getRedirect()
/*    */     {
/* 52 */       return this.doOutputAndRedirect;
/*    */     }
/*    */ 
/*    */     public int getExpectedHttpResponseCode()
/*    */     {
/* 57 */       return this.expectedHttpResponseCode;
/*    */     }
/*    */ 
/*    */     public String toQueryString()
/*    */     {
/* 62 */       return "op=" + this;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.PostOpParam
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.hdfs.web;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletRequestWrapper;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.authentication.server.AuthenticationFilter;
/*     */ 
/*     */ public class AuthFilter extends AuthenticationFilter
/*     */ {
/*     */   private static final String CONF_PREFIX = "dfs.web.authentication.";
/*     */ 
/*     */   protected Properties getConfiguration(String prefix, FilterConfig config)
/*     */     throws ServletException
/*     */   {
/*  63 */     Properties p = super.getConfiguration("dfs.web.authentication.", config);
/*     */ 
/*  65 */     p.setProperty("type", UserGroupInformation.isSecurityEnabled() ? "kerberos" : "simple");
/*     */ 
/*  68 */     p.setProperty("simple.anonymous.allowed", "true");
/*     */ 
/*  70 */     p.setProperty("cookie.path", "/");
/*  71 */     return p;
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
/*     */     throws IOException, ServletException
/*     */   {
/*  77 */     HttpServletRequest httpRequest = toLowerCase((HttpServletRequest)request);
/*  78 */     String tokenString = httpRequest.getParameter("delegation");
/*  79 */     if (tokenString != null)
/*     */     {
/*  82 */       filterChain.doFilter(httpRequest, response);
/*  83 */       return;
/*     */     }
/*  85 */     super.doFilter(httpRequest, response, filterChain);
/*     */   }
/*     */ 
/*     */   private static HttpServletRequest toLowerCase(HttpServletRequest request)
/*     */   {
/*  90 */     Map original = request.getParameterMap();
/*  91 */     if (!ParamFilter.containsUpperCase(original.keySet())) {
/*  92 */       return request;
/*     */     }
/*     */ 
/*  95 */     final Map m = new HashMap();
/*  96 */     for (Map.Entry entry : original.entrySet()) {
/*  97 */       String key = ((String)entry.getKey()).toLowerCase();
/*  98 */       List strings = (List)m.get(key);
/*  99 */       if (strings == null) {
/* 100 */         strings = new ArrayList();
/* 101 */         m.put(key, strings);
/*     */       }
/* 103 */       for (String v : (String[])entry.getValue()) {
/* 104 */         strings.add(v);
/*     */       }
/*     */     }
/*     */ 
/* 108 */     return new HttpServletRequestWrapper(request) {
/* 109 */       private Map<String, String[]> parameters = null;
/*     */ 
/*     */       public Map<String, String[]> getParameterMap()
/*     */       {
/* 113 */         if (this.parameters == null) {
/* 114 */           this.parameters = new HashMap();
/* 115 */           for (Map.Entry entry : m.entrySet()) {
/* 116 */             List a = (List)entry.getValue();
/* 117 */             this.parameters.put(entry.getKey(), a.toArray(new String[a.size()]));
/*     */           }
/*     */         }
/* 120 */         return this.parameters;
/*     */       }
/*     */ 
/*     */       public String getParameter(String name)
/*     */       {
/* 125 */         List a = (List)m.get(name);
/* 126 */         return a == null ? null : (String)a.get(0);
/*     */       }
/*     */ 
/*     */       public String[] getParameterValues(String name)
/*     */       {
/* 131 */         return (String[])getParameterMap().get(name);
/*     */       }
/*     */ 
/*     */       public Enumeration<String> getParameterNames()
/*     */       {
/* 136 */         final Iterator i = m.keySet().iterator();
/* 137 */         return new Enumeration()
/*     */         {
/*     */           public boolean hasMoreElements() {
/* 140 */             return i.hasNext();
/*     */           }
/*     */ 
/*     */           public String nextElement() {
/* 144 */             return (String)i.next();
/*     */           }
/*     */         };
/*     */       }
/*     */     };
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.AuthFilter
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ public class OwnerParam extends StringParam
/*    */ {
/*    */   public static final String NAME = "owner";
/*    */   public static final String DEFAULT = "";
/* 27 */   private static final StringParam.Domain DOMAIN = new StringParam.Domain("owner", null);
/*    */ 
/*    */   public OwnerParam(String str)
/*    */   {
/* 34 */     super(DOMAIN, (str == null) || (str.equals("")) ? null : str);
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 39 */     return "owner";
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.OwnerParam
 * JD-Core Version:    0.6.1
 */
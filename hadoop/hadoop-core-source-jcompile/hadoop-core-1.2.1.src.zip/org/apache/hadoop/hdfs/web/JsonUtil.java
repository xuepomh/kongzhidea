/*     */ package org.apache.hadoop.hdfs.web;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.hadoop.fs.ContentSummary;
/*     */ import org.apache.hadoop.fs.FileChecksum;
/*     */ import org.apache.hadoop.fs.FileStatus;
/*     */ import org.apache.hadoop.fs.MD5MD5CRC32FileChecksum;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.hdfs.DFSUtil;
/*     */ import org.apache.hadoop.hdfs.protocol.Block;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
/*     */ import org.apache.hadoop.hdfs.protocol.DatanodeInfo.AdminStates;
/*     */ import org.apache.hadoop.hdfs.protocol.HdfsFileStatus;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlock;
/*     */ import org.apache.hadoop.hdfs.protocol.LocatedBlocks;
/*     */ import org.apache.hadoop.hdfs.security.token.block.BlockTokenIdentifier;
/*     */ import org.apache.hadoop.hdfs.security.token.delegation.DelegationTokenIdentifier;
/*     */ import org.apache.hadoop.ipc.RemoteException;
/*     */ import org.apache.hadoop.security.token.Token;
/*     */ import org.apache.hadoop.security.token.TokenIdentifier;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ import org.mortbay.util.ajax.JSON;
/*     */ 
/*     */ public class JsonUtil
/*     */ {
/*  52 */   private static final Object[] EMPTY_OBJECT_ARRAY = new Object[0];
/*  53 */   private static final DatanodeInfo[] EMPTY_DATANODE_INFO_ARRAY = new DatanodeInfo[0];
/*     */ 
/*     */   public static String toJsonString(Token<? extends TokenIdentifier> token)
/*     */     throws IOException
/*     */   {
/*  58 */     return toJsonString(Token.class, toJsonMap(token));
/*     */   }
/*     */ 
/*     */   private static Map<String, Object> toJsonMap(Token<? extends TokenIdentifier> token) throws IOException
/*     */   {
/*  63 */     if (token == null) {
/*  64 */       return null;
/*     */     }
/*     */ 
/*  67 */     Map m = new TreeMap();
/*  68 */     m.put("urlString", token.encodeToUrlString());
/*  69 */     return m;
/*     */   }
/*     */ 
/*     */   public static Token<? extends TokenIdentifier> toToken(Map<?, ?> m)
/*     */     throws IOException
/*     */   {
/*  75 */     if (m == null) {
/*  76 */       return null;
/*     */     }
/*     */ 
/*  79 */     Token token = new Token();
/*     */ 
/*  81 */     token.decodeFromUrlString((String)m.get("urlString"));
/*  82 */     return token;
/*     */   }
/*     */ 
/*     */   public static Token<DelegationTokenIdentifier> toDelegationToken(Map<?, ?> json)
/*     */     throws IOException
/*     */   {
/*  89 */     Map m = (Map)json.get(Token.class.getSimpleName());
/*  90 */     return toToken(m);
/*     */   }
/*     */ 
/*     */   private static Token<BlockTokenIdentifier> toBlockToken(Map<?, ?> m)
/*     */     throws IOException
/*     */   {
/*  97 */     return toToken(m);
/*     */   }
/*     */ 
/*     */   public static String toJsonString(Exception e)
/*     */   {
/* 102 */     Map m = new TreeMap();
/* 103 */     m.put("exception", e.getClass().getSimpleName());
/* 104 */     m.put("message", e.getMessage());
/* 105 */     m.put("javaClassName", e.getClass().getName());
/* 106 */     return toJsonString(RemoteException.class, m);
/*     */   }
/*     */ 
/*     */   public static RemoteException toRemoteException(Map<?, ?> json)
/*     */   {
/* 111 */     Map m = (Map)json.get(RemoteException.class.getSimpleName());
/* 112 */     String message = (String)m.get("message");
/* 113 */     String javaClassName = (String)m.get("javaClassName");
/* 114 */     return new RemoteException(javaClassName, message);
/*     */   }
/*     */ 
/*     */   private static String toJsonString(Class<?> clazz, Object value) {
/* 118 */     return toJsonString(clazz.getSimpleName(), value);
/*     */   }
/*     */ 
/*     */   public static String toJsonString(String key, Object value)
/*     */   {
/* 123 */     Map m = new TreeMap();
/* 124 */     m.put(key, value);
/* 125 */     return JSON.toString(m);
/*     */   }
/*     */ 
/*     */   private static String toString(FsPermission permission)
/*     */   {
/* 130 */     return String.format("%o", new Object[] { Short.valueOf(permission.toShort()) });
/*     */   }
/*     */ 
/*     */   private static FsPermission toFsPermission(String s)
/*     */   {
/* 135 */     return new FsPermission(Short.parseShort(s, 8));
/*     */   }
/*     */ 
/*     */   public static String toJsonString(HdfsFileStatus status, boolean includeType)
/*     */   {
/* 149 */     if (status == null) {
/* 150 */       return null;
/*     */     }
/* 152 */     Map m = new TreeMap();
/* 153 */     m.put("pathSuffix", status.getLocalName());
/* 154 */     m.put("type", PathType.valueOf(status));
/* 155 */     m.put("length", Long.valueOf(status.getLen()));
/* 156 */     m.put("owner", status.getOwner());
/* 157 */     m.put("group", status.getGroup());
/* 158 */     m.put("permission", toString(status.getPermission()));
/* 159 */     m.put("accessTime", Long.valueOf(status.getAccessTime()));
/* 160 */     m.put("modificationTime", Long.valueOf(status.getModificationTime()));
/* 161 */     m.put("blockSize", Long.valueOf(status.getBlockSize()));
/* 162 */     m.put("replication", Short.valueOf(status.getReplication()));
/* 163 */     return includeType ? toJsonString(FileStatus.class, m) : JSON.toString(m);
/*     */   }
/*     */ 
/*     */   public static HdfsFileStatus toFileStatus(Map<?, ?> json, boolean includesType)
/*     */   {
/* 168 */     if (json == null) {
/* 169 */       return null;
/*     */     }
/*     */ 
/* 172 */     Map m = includesType ? (Map)json.get(FileStatus.class.getSimpleName()) : json;
/*     */ 
/* 174 */     String localName = (String)m.get("pathSuffix");
/* 175 */     PathType type = PathType.valueOf((String)m.get("type"));
/*     */ 
/* 177 */     long len = ((Long)m.get("length")).longValue();
/* 178 */     String owner = (String)m.get("owner");
/* 179 */     String group = (String)m.get("group");
/* 180 */     FsPermission permission = toFsPermission((String)m.get("permission"));
/* 181 */     long aTime = ((Long)m.get("accessTime")).longValue();
/* 182 */     long mTime = ((Long)m.get("modificationTime")).longValue();
/* 183 */     long blockSize = ((Long)m.get("blockSize")).longValue();
/* 184 */     short replication = (short)(int)((Long)m.get("replication")).longValue();
/* 185 */     return new HdfsFileStatus(len, type == PathType.DIRECTORY, replication, blockSize, mTime, aTime, permission, owner, group, DFSUtil.string2Bytes(localName));
/*     */   }
/*     */ 
/*     */   private static Map<String, Object> toJsonMap(Block block)
/*     */   {
/* 192 */     if (block == null) {
/* 193 */       return null;
/*     */     }
/*     */ 
/* 196 */     Map m = new TreeMap();
/* 197 */     m.put("blockId", Long.valueOf(block.getBlockId()));
/* 198 */     m.put("numBytes", Long.valueOf(block.getNumBytes()));
/* 199 */     m.put("generationStamp", Long.valueOf(block.getGenerationStamp()));
/* 200 */     return m;
/*     */   }
/*     */ 
/*     */   private static Block toBlock(Map<?, ?> m)
/*     */   {
/* 205 */     if (m == null) {
/* 206 */       return null;
/*     */     }
/*     */ 
/* 209 */     long blockId = ((Long)m.get("blockId")).longValue();
/* 210 */     long numBytes = ((Long)m.get("numBytes")).longValue();
/* 211 */     long generationStamp = ((Long)m.get("generationStamp")).longValue();
/* 212 */     return new Block(blockId, numBytes, generationStamp);
/*     */   }
/*     */ 
/*     */   private static Map<String, Object> toJsonMap(DatanodeInfo datanodeinfo)
/*     */   {
/* 217 */     if (datanodeinfo == null) {
/* 218 */       return null;
/*     */     }
/*     */ 
/* 221 */     Map m = new TreeMap();
/* 222 */     m.put("name", datanodeinfo.getName());
/* 223 */     m.put("storageID", datanodeinfo.getStorageID());
/* 224 */     m.put("infoPort", Integer.valueOf(datanodeinfo.getInfoPort()));
/*     */ 
/* 226 */     m.put("ipcPort", Integer.valueOf(datanodeinfo.getIpcPort()));
/*     */ 
/* 228 */     m.put("capacity", Long.valueOf(datanodeinfo.getCapacity()));
/* 229 */     m.put("dfsUsed", Long.valueOf(datanodeinfo.getDfsUsed()));
/* 230 */     m.put("remaining", Long.valueOf(datanodeinfo.getRemaining()));
/* 231 */     m.put("lastUpdate", Long.valueOf(datanodeinfo.getLastUpdate()));
/* 232 */     m.put("xceiverCount", Integer.valueOf(datanodeinfo.getXceiverCount()));
/* 233 */     m.put("networkLocation", datanodeinfo.getNetworkLocation());
/* 234 */     m.put("hostName", datanodeinfo.getHostName());
/* 235 */     m.put("adminState", datanodeinfo.getAdminState().name());
/* 236 */     return m;
/*     */   }
/*     */ 
/*     */   private static DatanodeInfo toDatanodeInfo(Map<?, ?> m)
/*     */   {
/* 241 */     if (m == null) {
/* 242 */       return null;
/*     */     }
/*     */ 
/* 245 */     return new DatanodeInfo((String)m.get("name"), (String)m.get("storageID"), (int)((Long)m.get("infoPort")).longValue(), (int)((Long)m.get("ipcPort")).longValue(), ((Long)m.get("capacity")).longValue(), ((Long)m.get("dfsUsed")).longValue(), ((Long)m.get("remaining")).longValue(), ((Long)m.get("lastUpdate")).longValue(), (int)((Long)m.get("xceiverCount")).longValue(), (String)m.get("networkLocation"), (String)m.get("hostName"), DatanodeInfo.AdminStates.valueOf((String)m.get("adminState")));
/*     */   }
/*     */ 
/*     */   private static Object[] toJsonArray(DatanodeInfo[] array)
/*     */   {
/* 263 */     if (array == null)
/* 264 */       return null;
/* 265 */     if (array.length == 0) {
/* 266 */       return EMPTY_OBJECT_ARRAY;
/*     */     }
/* 268 */     Object[] a = new Object[array.length];
/* 269 */     for (int i = 0; i < array.length; i++) {
/* 270 */       a[i] = toJsonMap(array[i]);
/*     */     }
/* 272 */     return a;
/*     */   }
/*     */ 
/*     */   private static DatanodeInfo[] toDatanodeInfoArray(Object[] objects)
/*     */   {
/* 278 */     if (objects == null)
/* 279 */       return null;
/* 280 */     if (objects.length == 0) {
/* 281 */       return EMPTY_DATANODE_INFO_ARRAY;
/*     */     }
/* 283 */     DatanodeInfo[] array = new DatanodeInfo[objects.length];
/* 284 */     for (int i = 0; i < array.length; i++) {
/* 285 */       array[i] = toDatanodeInfo((Map)objects[i]);
/*     */     }
/* 287 */     return array;
/*     */   }
/*     */ 
/*     */   private static Map<String, Object> toJsonMap(LocatedBlock locatedblock)
/*     */     throws IOException
/*     */   {
/* 294 */     if (locatedblock == null) {
/* 295 */       return null;
/*     */     }
/*     */ 
/* 298 */     Map m = new TreeMap();
/* 299 */     m.put("blockToken", toJsonMap(locatedblock.getBlockToken()));
/* 300 */     m.put("isCorrupt", Boolean.valueOf(locatedblock.isCorrupt()));
/* 301 */     m.put("startOffset", Long.valueOf(locatedblock.getStartOffset()));
/* 302 */     m.put("block", toJsonMap(locatedblock.getBlock()));
/*     */ 
/* 304 */     m.put("locations", toJsonArray(locatedblock.getLocations()));
/* 305 */     return m;
/*     */   }
/*     */ 
/*     */   private static LocatedBlock toLocatedBlock(Map<?, ?> m) throws IOException
/*     */   {
/* 310 */     if (m == null) {
/* 311 */       return null;
/*     */     }
/*     */ 
/* 314 */     Block b = toBlock((Map)m.get("block"));
/* 315 */     DatanodeInfo[] locations = toDatanodeInfoArray((Object[])m.get("locations"));
/*     */ 
/* 317 */     long startOffset = ((Long)m.get("startOffset")).longValue();
/* 318 */     boolean isCorrupt = ((Boolean)m.get("isCorrupt")).booleanValue();
/*     */ 
/* 320 */     LocatedBlock locatedblock = new LocatedBlock(b, locations, startOffset, isCorrupt);
/* 321 */     locatedblock.setBlockToken(toBlockToken((Map)m.get("blockToken")));
/* 322 */     return locatedblock;
/*     */   }
/*     */ 
/*     */   private static Object[] toJsonArray(List<LocatedBlock> array)
/*     */     throws IOException
/*     */   {
/* 328 */     if (array == null)
/* 329 */       return null;
/* 330 */     if (array.size() == 0) {
/* 331 */       return EMPTY_OBJECT_ARRAY;
/*     */     }
/* 333 */     Object[] a = new Object[array.size()];
/* 334 */     for (int i = 0; i < array.size(); i++) {
/* 335 */       a[i] = toJsonMap((LocatedBlock)array.get(i));
/*     */     }
/* 337 */     return a;
/*     */   }
/*     */ 
/*     */   private static List<LocatedBlock> toLocatedBlockList(Object[] objects)
/*     */     throws IOException
/*     */   {
/* 344 */     if (objects == null)
/* 345 */       return null;
/* 346 */     if (objects.length == 0) {
/* 347 */       return Collections.emptyList();
/*     */     }
/* 349 */     List list = new ArrayList(objects.length);
/* 350 */     for (int i = 0; i < objects.length; i++) {
/* 351 */       list.add(toLocatedBlock((Map)objects[i]));
/*     */     }
/* 353 */     return list;
/*     */   }
/*     */ 
/*     */   public static String toJsonString(LocatedBlocks locatedblocks)
/*     */     throws IOException
/*     */   {
/* 360 */     if (locatedblocks == null) {
/* 361 */       return null;
/*     */     }
/*     */ 
/* 364 */     Map m = new TreeMap();
/* 365 */     m.put("fileLength", Long.valueOf(locatedblocks.getFileLength()));
/* 366 */     m.put("isUnderConstruction", Boolean.valueOf(locatedblocks.isUnderConstruction()));
/*     */ 
/* 368 */     m.put("locatedBlocks", toJsonArray(locatedblocks.getLocatedBlocks()));
/* 369 */     return toJsonString(LocatedBlocks.class, m);
/*     */   }
/*     */ 
/*     */   public static LocatedBlocks toLocatedBlocks(Map<?, ?> json)
/*     */     throws IOException
/*     */   {
/* 375 */     if (json == null) {
/* 376 */       return null;
/*     */     }
/*     */ 
/* 379 */     Map m = (Map)json.get(LocatedBlocks.class.getSimpleName());
/* 380 */     long fileLength = ((Long)m.get("fileLength")).longValue();
/* 381 */     boolean isUnderConstruction = ((Boolean)m.get("isUnderConstruction")).booleanValue();
/* 382 */     List locatedBlocks = toLocatedBlockList((Object[])m.get("locatedBlocks"));
/*     */ 
/* 384 */     return new LocatedBlocks(fileLength, locatedBlocks, isUnderConstruction);
/*     */   }
/*     */ 
/*     */   public static String toJsonString(ContentSummary contentsummary)
/*     */   {
/* 389 */     if (contentsummary == null) {
/* 390 */       return null;
/*     */     }
/*     */ 
/* 393 */     Map m = new TreeMap();
/* 394 */     m.put("length", Long.valueOf(contentsummary.getLength()));
/* 395 */     m.put("fileCount", Long.valueOf(contentsummary.getFileCount()));
/* 396 */     m.put("directoryCount", Long.valueOf(contentsummary.getDirectoryCount()));
/* 397 */     m.put("quota", Long.valueOf(contentsummary.getQuota()));
/* 398 */     m.put("spaceConsumed", Long.valueOf(contentsummary.getSpaceConsumed()));
/* 399 */     m.put("spaceQuota", Long.valueOf(contentsummary.getSpaceQuota()));
/* 400 */     return toJsonString(ContentSummary.class, m);
/*     */   }
/*     */ 
/*     */   public static ContentSummary toContentSummary(Map<?, ?> json)
/*     */   {
/* 405 */     if (json == null) {
/* 406 */       return null;
/*     */     }
/*     */ 
/* 409 */     Map m = (Map)json.get(ContentSummary.class.getSimpleName());
/* 410 */     long length = ((Long)m.get("length")).longValue();
/* 411 */     long fileCount = ((Long)m.get("fileCount")).longValue();
/* 412 */     long directoryCount = ((Long)m.get("directoryCount")).longValue();
/* 413 */     long quota = ((Long)m.get("quota")).longValue();
/* 414 */     long spaceConsumed = ((Long)m.get("spaceConsumed")).longValue();
/* 415 */     long spaceQuota = ((Long)m.get("spaceQuota")).longValue();
/*     */ 
/* 417 */     return new ContentSummary(length, fileCount, directoryCount, quota, spaceConsumed, spaceQuota);
/*     */   }
/*     */ 
/*     */   public static String toJsonString(MD5MD5CRC32FileChecksum checksum)
/*     */   {
/* 423 */     if (checksum == null) {
/* 424 */       return null;
/*     */     }
/*     */ 
/* 427 */     Map m = new TreeMap();
/* 428 */     m.put("algorithm", checksum.getAlgorithmName());
/* 429 */     m.put("length", Integer.valueOf(checksum.getLength()));
/* 430 */     m.put("bytes", StringUtils.byteToHexString(checksum.getBytes()));
/* 431 */     return toJsonString(FileChecksum.class, m);
/*     */   }
/*     */ 
/*     */   public static MD5MD5CRC32FileChecksum toMD5MD5CRC32FileChecksum(Map<?, ?> json)
/*     */     throws IOException
/*     */   {
/* 437 */     if (json == null) {
/* 438 */       return null;
/*     */     }
/*     */ 
/* 441 */     Map m = (Map)json.get(FileChecksum.class.getSimpleName());
/* 442 */     String algorithm = (String)m.get("algorithm");
/* 443 */     int length = (int)((Long)m.get("length")).longValue();
/* 444 */     byte[] bytes = StringUtils.hexStringToByte((String)m.get("bytes"));
/*     */ 
/* 446 */     DataInputStream in = new DataInputStream(new ByteArrayInputStream(bytes));
/* 447 */     MD5MD5CRC32FileChecksum checksum = new MD5MD5CRC32FileChecksum();
/* 448 */     checksum.readFields(in);
/*     */ 
/* 451 */     if (!checksum.getAlgorithmName().equals(algorithm)) {
/* 452 */       throw new IOException("Algorithm not matched. Expected " + algorithm + ", Received " + checksum.getAlgorithmName());
/*     */     }
/*     */ 
/* 456 */     if (length != checksum.getLength()) {
/* 457 */       throw new IOException("Length not matched: length=" + length + ", checksum.getLength()=" + checksum.getLength());
/*     */     }
/*     */ 
/* 461 */     return checksum;
/*     */   }
/*     */ 
/*     */   static enum PathType
/*     */   {
/* 139 */     FILE, DIRECTORY;
/*     */ 
/*     */     static PathType valueOf(HdfsFileStatus status) {
/* 142 */       return status.isDir() ? DIRECTORY : FILE;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.JsonUtil
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ import org.apache.hadoop.security.UserGroupInformation;
/*    */ 
/*    */ public class UserParam extends StringParam
/*    */ {
/*    */   public static final String NAME = "user.name";
/*    */   public static final String DEFAULT = "";
/* 29 */   private static final StringParam.Domain DOMAIN = new StringParam.Domain("user.name", null);
/*    */ 
/*    */   public UserParam(String str)
/*    */   {
/* 36 */     super(DOMAIN, (str == null) || (str.equals("")) ? null : str);
/*    */   }
/*    */ 
/*    */   public UserParam(UserGroupInformation ugi)
/*    */   {
/* 43 */     this(ugi.getShortUserName());
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 48 */     return "user.name";
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.UserParam
 * JD-Core Version:    0.6.1
 */
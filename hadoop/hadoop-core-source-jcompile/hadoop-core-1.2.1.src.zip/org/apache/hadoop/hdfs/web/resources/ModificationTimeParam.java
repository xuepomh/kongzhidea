/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ public class ModificationTimeParam extends LongParam
/*    */ {
/*    */   public static final String NAME = "modificationtime";
/*    */   public static final String DEFAULT = "-1";
/* 27 */   private static final LongParam.Domain DOMAIN = new LongParam.Domain("modificationtime");
/*    */ 
/*    */   public ModificationTimeParam(Long value)
/*    */   {
/* 34 */     super(DOMAIN, value, Long.valueOf(-1L), null);
/*    */   }
/*    */ 
/*    */   public ModificationTimeParam(String str)
/*    */   {
/* 42 */     this(DOMAIN.parse(str));
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 47 */     return "modificationtime";
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.ModificationTimeParam
 * JD-Core Version:    0.6.1
 */
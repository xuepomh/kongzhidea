/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ public class RecursiveParam extends BooleanParam
/*    */ {
/*    */   public static final String NAME = "recursive";
/*    */   public static final String DEFAULT = "false";
/* 27 */   private static final BooleanParam.Domain DOMAIN = new BooleanParam.Domain("recursive");
/*    */ 
/*    */   public RecursiveParam(Boolean value)
/*    */   {
/* 34 */     super(DOMAIN, value);
/*    */   }
/*    */ 
/*    */   public RecursiveParam(String str)
/*    */   {
/* 42 */     this(DOMAIN.parse(str));
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 47 */     return "recursive";
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.RecursiveParam
 * JD-Core Version:    0.6.1
 */
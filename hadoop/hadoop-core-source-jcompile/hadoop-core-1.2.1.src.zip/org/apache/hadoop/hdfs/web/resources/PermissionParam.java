/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ import org.apache.hadoop.fs.permission.FsPermission;
/*    */ 
/*    */ public class PermissionParam extends ShortParam
/*    */ {
/*    */   public static final String NAME = "permission";
/*    */   public static final String DEFAULT = "null";
/* 29 */   private static final ShortParam.Domain DOMAIN = new ShortParam.Domain("permission", 8);
/*    */   private static final short DEFAULT_PERMISSION = 493;
/*    */ 
/*    */   public PermissionParam(FsPermission value)
/*    */   {
/* 38 */     super(DOMAIN, value == null ? null : Short.valueOf(value.toShort()), null, null);
/*    */   }
/*    */ 
/*    */   public PermissionParam(String str)
/*    */   {
/* 46 */     super(DOMAIN, DOMAIN.parse(str), Short.valueOf((short)0), Short.valueOf((short)511));
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 51 */     return "permission";
/*    */   }
/*    */ 
/*    */   public FsPermission getFsPermission()
/*    */   {
/* 56 */     Short v = (Short)getValue();
/* 57 */     return new FsPermission((short)(v != null ? v.shortValue() : 493));
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.PermissionParam
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.web;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.hadoop.security.UserGroupInformation;
/*    */ import org.apache.hadoop.security.authentication.client.Authenticator;
/*    */ import org.apache.hadoop.security.authentication.client.KerberosAuthenticator;
/*    */ import org.apache.hadoop.security.authentication.client.PseudoAuthenticator;
/*    */ 
/*    */ public class KerberosUgiAuthenticator extends KerberosAuthenticator
/*    */ {
/*    */   protected Authenticator getFallBackAuthenticator()
/*    */   {
/* 34 */     return new PseudoAuthenticator()
/*    */     {
/*    */       protected String getUserName() {
/*    */         try {
/* 38 */           return UserGroupInformation.getLoginUser().getUserName();
/*    */         } catch (IOException e) {
/* 40 */           throw new SecurityException("Failed to obtain current username", e);
/*    */         }
/*    */       }
/*    */     };
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.KerberosUgiAuthenticator
 * JD-Core Version:    0.6.1
 */
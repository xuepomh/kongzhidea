/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ public class UriFsPathParam extends StringParam
/*    */ {
/*    */   public static final String NAME = "path";
/* 25 */   private static final StringParam.Domain DOMAIN = new StringParam.Domain("path", null);
/*    */ 
/*    */   public UriFsPathParam(String str)
/*    */   {
/* 32 */     super(DOMAIN, str);
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 37 */     return "path";
/*    */   }
/*    */ 
/*    */   public final String getAbsolutePath()
/*    */   {
/* 42 */     String path = (String)getValue();
/* 43 */     return "/" + path;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.UriFsPathParam
 * JD-Core Version:    0.6.1
 */
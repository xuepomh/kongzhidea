/*     */ package org.apache.hadoop.hdfs.web.resources;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.ws.rs.core.Response.Status;
/*     */ 
/*     */ public abstract class HttpOpParam<E extends Enum<E>,  extends Op> extends EnumParam<E>
/*     */ {
/*     */   public static final String NAME = "op";
/*     */   public static final String DEFAULT = "null";
/*     */ 
/*     */   HttpOpParam(EnumParam.Domain<E> domain, E value)
/*     */   {
/* 118 */     super(domain, value);
/*     */   }
/*     */ 
/*     */   public static class TemporaryRedirectOp
/*     */     implements HttpOpParam.Op
/*     */   {
/*  61 */     static final TemporaryRedirectOp CREATE = new TemporaryRedirectOp(PutOpParam.Op.CREATE);
/*     */ 
/*  63 */     static final TemporaryRedirectOp APPEND = new TemporaryRedirectOp(PostOpParam.Op.APPEND);
/*     */ 
/*  65 */     static final TemporaryRedirectOp OPEN = new TemporaryRedirectOp(GetOpParam.Op.OPEN);
/*     */ 
/*  67 */     static final TemporaryRedirectOp GETFILECHECKSUM = new TemporaryRedirectOp(GetOpParam.Op.GETFILECHECKSUM);
/*     */ 
/*  70 */     static final List<TemporaryRedirectOp> values = Collections.unmodifiableList(Arrays.asList(new TemporaryRedirectOp[] { CREATE, APPEND, OPEN, GETFILECHECKSUM }));
/*     */     private final HttpOpParam.Op op;
/*     */ 
/*     */     public static TemporaryRedirectOp valueOf(HttpOpParam.Op op)
/*     */     {
/*  76 */       for (TemporaryRedirectOp t : values) {
/*  77 */         if (op == t.op) {
/*  78 */           return t;
/*     */         }
/*     */       }
/*  81 */       throw new IllegalArgumentException(op + " not found.");
/*     */     }
/*     */ 
/*     */     private TemporaryRedirectOp(HttpOpParam.Op op)
/*     */     {
/*  87 */       this.op = op;
/*     */     }
/*     */ 
/*     */     public HttpOpParam.Type getType()
/*     */     {
/*  92 */       return this.op.getType();
/*     */     }
/*     */ 
/*     */     public boolean getDoOutput()
/*     */     {
/*  97 */       return this.op.getDoOutput();
/*     */     }
/*     */ 
/*     */     public boolean getRedirect()
/*     */     {
/* 102 */       return false;
/*     */     }
/*     */ 
/*     */     public int getExpectedHttpResponseCode()
/*     */     {
/* 108 */       return Response.Status.TEMPORARY_REDIRECT.getStatusCode();
/*     */     }
/*     */ 
/*     */     public String toQueryString()
/*     */     {
/* 113 */       return this.op.toQueryString();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface Op
/*     */   {
/*     */     public abstract HttpOpParam.Type getType();
/*     */ 
/*     */     public abstract boolean getDoOutput();
/*     */ 
/*     */     public abstract boolean getRedirect();
/*     */ 
/*     */     public abstract int getExpectedHttpResponseCode();
/*     */ 
/*     */     public abstract String toQueryString();
/*     */   }
/*     */ 
/*     */   public static enum Type
/*     */   {
/*  38 */     GET, PUT, POST, DELETE;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.HttpOpParam
 * JD-Core Version:    0.6.1
 */
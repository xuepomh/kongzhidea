/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ public class OffsetParam extends LongParam
/*    */ {
/*    */   public static final String NAME = "offset";
/*    */   public static final String DEFAULT = "0";
/* 27 */   private static final LongParam.Domain DOMAIN = new LongParam.Domain("offset");
/*    */ 
/*    */   public OffsetParam(Long value)
/*    */   {
/* 34 */     super(DOMAIN, value, Long.valueOf(0L), null);
/*    */   }
/*    */ 
/*    */   public OffsetParam(String str)
/*    */   {
/* 42 */     this(DOMAIN.parse(str));
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 47 */     return "offset";
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.OffsetParam
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ abstract class LongParam extends Param<Long, Domain>
/*    */ {
/*    */   LongParam(Domain domain, Long value, Long min, Long max)
/*    */   {
/* 23 */     super(domain, value);
/* 24 */     checkRange(min, max);
/*    */   }
/*    */ 
/*    */   private void checkRange(Long min, Long max) {
/* 28 */     if (this.value == null) {
/* 29 */       return;
/*    */     }
/* 31 */     if ((min != null) && (((Long)this.value).longValue() < min.longValue())) {
/* 32 */       throw new IllegalArgumentException("Invalid parameter range: " + getName() + " = " + ((Domain)this.domain).toString((Long)this.value) + " < " + ((Domain)this.domain).toString(min));
/*    */     }
/*    */ 
/* 35 */     if ((max != null) && (((Long)this.value).longValue() > max.longValue()))
/* 36 */       throw new IllegalArgumentException("Invalid parameter range: " + getName() + " = " + ((Domain)this.domain).toString((Long)this.value) + " > " + ((Domain)this.domain).toString(max));
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 43 */     return getName() + "=" + ((Domain)this.domain).toString((Long)getValue());
/*    */   }
/*    */ 
/*    */   static final class Domain extends Param.Domain<Long>
/*    */   {
/*    */     final int radix;
/*    */ 
/*    */     Domain(String paramName)
/*    */     {
/* 52 */       this(paramName, 10);
/*    */     }
/*    */ 
/*    */     Domain(String paramName, int radix) {
/* 56 */       super();
/* 57 */       this.radix = radix;
/*    */     }
/*    */ 
/*    */     public String getDomain()
/*    */     {
/* 62 */       return "<null | short in radix " + this.radix + ">";
/*    */     }
/*    */ 
/*    */     Long parse(String str)
/*    */     {
/*    */       try {
/* 68 */         return "null".equals(str) ? null : Long.valueOf(Long.parseLong(str, this.radix));
/*    */       } catch (NumberFormatException e) {
/* 70 */         throw new IllegalArgumentException("Failed to parse \"" + str + "\" as a radix-" + this.radix + " long integer.", e);
/*    */       }
/*    */     }
/*    */ 
/*    */     String toString(Long n)
/*    */     {
/* 77 */       return n == null ? "null" : Long.toString(n.longValue(), this.radix);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.LongParam
 * JD-Core Version:    0.6.1
 */
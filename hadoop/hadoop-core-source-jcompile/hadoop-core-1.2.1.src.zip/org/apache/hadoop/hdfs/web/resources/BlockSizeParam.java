/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ 
/*    */ public class BlockSizeParam extends LongParam
/*    */ {
/*    */   public static final String NAME = "blocksize";
/*    */   public static final String DEFAULT = "null";
/* 32 */   private static final LongParam.Domain DOMAIN = new LongParam.Domain("blocksize");
/*    */ 
/*    */   public BlockSizeParam(Long value)
/*    */   {
/* 39 */     super(DOMAIN, value, Long.valueOf(1L), null);
/*    */   }
/*    */ 
/*    */   public BlockSizeParam(String str)
/*    */   {
/* 47 */     this(DOMAIN.parse(str));
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 52 */     return "blocksize";
/*    */   }
/*    */ 
/*    */   public long getValue(Configuration conf)
/*    */   {
/* 57 */     return getValue() != null ? ((Long)getValue()).longValue() : conf.getLong("dfs.block.size", 67108864L);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.BlockSizeParam
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ abstract class ShortParam extends Param<Short, Domain>
/*    */ {
/*    */   ShortParam(Domain domain, Short value, Short min, Short max)
/*    */   {
/* 24 */     super(domain, value);
/* 25 */     checkRange(min, max);
/*    */   }
/*    */ 
/*    */   private void checkRange(Short min, Short max) {
/* 29 */     if (this.value == null) {
/* 30 */       return;
/*    */     }
/* 32 */     if ((min != null) && (((Short)this.value).shortValue() < min.shortValue())) {
/* 33 */       throw new IllegalArgumentException("Invalid parameter range: " + getName() + " = " + ((Domain)this.domain).toString((Short)this.value) + " < " + ((Domain)this.domain).toString(min));
/*    */     }
/*    */ 
/* 36 */     if ((max != null) && (((Short)this.value).shortValue() > max.shortValue()))
/* 37 */       throw new IllegalArgumentException("Invalid parameter range: " + getName() + " = " + ((Domain)this.domain).toString((Short)this.value) + " > " + ((Domain)this.domain).toString(max));
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 44 */     return getName() + "=" + ((Domain)this.domain).toString((Short)getValue());
/*    */   }
/*    */ 
/*    */   static final class Domain extends Param.Domain<Short>
/*    */   {
/*    */     final int radix;
/*    */ 
/*    */     Domain(String paramName)
/*    */     {
/* 53 */       this(paramName, 10);
/*    */     }
/*    */ 
/*    */     Domain(String paramName, int radix) {
/* 57 */       super();
/* 58 */       this.radix = radix;
/*    */     }
/*    */ 
/*    */     public String getDomain()
/*    */     {
/* 63 */       return "<null | short in radix " + this.radix + ">";
/*    */     }
/*    */ 
/*    */     Short parse(String str)
/*    */     {
/*    */       try {
/* 69 */         return "null".equals(str) ? null : Short.valueOf(Short.parseShort(str, this.radix));
/*    */       } catch (NumberFormatException e) {
/* 71 */         throw new IllegalArgumentException("Failed to parse \"" + str + "\" as a radix-" + this.radix + " short integer.", e);
/*    */       }
/*    */     }
/*    */ 
/*    */     String toString(Short n)
/*    */     {
/* 78 */       return n == null ? "null" : Integer.toString(n.shortValue(), this.radix);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.ShortParam
 * JD-Core Version:    0.6.1
 */
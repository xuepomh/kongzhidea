/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.apache.hadoop.fs.Path;
/*    */ 
/*    */ public class DestinationParam extends StringParam
/*    */ {
/*    */   public static final String NAME = "destination";
/*    */   public static final String DEFAULT = "";
/* 29 */   private static final StringParam.Domain DOMAIN = new StringParam.Domain("destination", null);
/*    */ 
/*    */   private static String validate(String str) {
/* 32 */     if ((str == null) || (str.equals(""))) {
/* 33 */       return null;
/*    */     }
/* 35 */     if (!str.startsWith("/")) {
/* 36 */       throw new IllegalArgumentException("Invalid parameter value: destination = \"" + str + "\" is not an absolute path.");
/*    */     }
/*    */ 
/* 39 */     return new Path(str).toUri().getPath();
/*    */   }
/*    */ 
/*    */   public DestinationParam(String str)
/*    */   {
/* 47 */     super(DOMAIN, validate(str));
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 52 */     return "destination";
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.DestinationParam
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ public class TokenArgumentParam extends StringParam
/*    */ {
/*    */   public static final String NAME = "token";
/*    */   public static final String DEFAULT = "";
/* 30 */   private static final StringParam.Domain DOMAIN = new StringParam.Domain("token", null);
/*    */ 
/*    */   public TokenArgumentParam(String str)
/*    */   {
/* 37 */     super(DOMAIN, (str != null) && (!str.equals("")) ? str : null);
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 42 */     return "token";
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.TokenArgumentParam
 * JD-Core Version:    0.6.1
 */
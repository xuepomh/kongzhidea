/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ public class PutOpParam extends HttpOpParam<Op>
/*    */ {
/* 75 */   private static final EnumParam.Domain<Op> DOMAIN = new EnumParam.Domain("op", Op.class);
/*    */ 
/*    */   public PutOpParam(String str)
/*    */   {
/* 82 */     super(DOMAIN, DOMAIN.parse(str));
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 87 */     return "op";
/*    */   }
/*    */ 
/*    */   public static enum Op
/*    */     implements HttpOpParam.Op
/*    */   {
/* 26 */     CREATE(true, 201), 
/*    */ 
/* 28 */     MKDIRS(false, 200), 
/* 29 */     RENAME(false, 200), 
/* 30 */     SETREPLICATION(false, 200), 
/*    */ 
/* 32 */     SETOWNER(false, 200), 
/* 33 */     SETPERMISSION(false, 200), 
/* 34 */     SETTIMES(false, 200), 
/*    */ 
/* 36 */     RENEWDELEGATIONTOKEN(false, 200), 
/* 37 */     CANCELDELEGATIONTOKEN(false, 200), 
/*    */ 
/* 39 */     NULL(false, 501);
/*    */ 
/*    */     final boolean doOutputAndRedirect;
/*    */     final int expectedHttpResponseCode;
/*    */ 
/* 45 */     private Op(boolean doOutputAndRedirect, int expectedHttpResponseCode) { this.doOutputAndRedirect = doOutputAndRedirect;
/* 46 */       this.expectedHttpResponseCode = expectedHttpResponseCode;
/*    */     }
/*    */ 
/*    */     public HttpOpParam.Type getType()
/*    */     {
/* 51 */       return HttpOpParam.Type.PUT;
/*    */     }
/*    */ 
/*    */     public boolean getDoOutput()
/*    */     {
/* 56 */       return this.doOutputAndRedirect;
/*    */     }
/*    */ 
/*    */     public boolean getRedirect()
/*    */     {
/* 61 */       return this.doOutputAndRedirect;
/*    */     }
/*    */ 
/*    */     public int getExpectedHttpResponseCode()
/*    */     {
/* 66 */       return this.expectedHttpResponseCode;
/*    */     }
/*    */ 
/*    */     public String toQueryString()
/*    */     {
/* 71 */       return "op=" + this;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.PutOpParam
 * JD-Core Version:    0.6.1
 */
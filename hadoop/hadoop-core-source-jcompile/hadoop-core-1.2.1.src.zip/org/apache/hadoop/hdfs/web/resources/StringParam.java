/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ abstract class StringParam extends Param<String, Domain>
/*    */ {
/*    */   StringParam(Domain domain, String str)
/*    */   {
/* 25 */     super(domain, domain.parse(str));
/*    */   }
/*    */ 
/*    */   static final class Domain extends Param.Domain<String>
/*    */   {
/*    */     private final Pattern pattern;
/*    */ 
/*    */     Domain(String paramName, Pattern pattern)
/*    */     {
/* 34 */       super();
/* 35 */       this.pattern = pattern;
/*    */     }
/*    */ 
/*    */     public final String getDomain()
/*    */     {
/* 40 */       return this.pattern == null ? "<String>" : this.pattern.pattern();
/*    */     }
/*    */ 
/*    */     final String parse(String str)
/*    */     {
/* 45 */       if ((this.pattern != null) && 
/* 46 */         (!this.pattern.matcher(str).matches())) {
/* 47 */         throw new IllegalArgumentException("Invalid value: \"" + str + "\" does not belong to the domain " + getDomain());
/*    */       }
/*    */ 
/* 51 */       return str;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.StringParam
 * JD-Core Version:    0.6.1
 */
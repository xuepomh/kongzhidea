/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ abstract class EnumParam<E extends Enum<E>> extends Param<E, Domain<E>>
/*    */ {
/*    */   EnumParam(Domain<E> domain, E value)
/*    */   {
/* 24 */     super(domain, value);
/*    */   }
/*    */ 
/*    */   static final class Domain<E extends Enum<E>> extends Param.Domain<E>
/*    */   {
/*    */     private final Class<E> enumClass;
/*    */ 
/*    */     Domain(String name, Class<E> enumClass) {
/* 32 */       super();
/* 33 */       this.enumClass = enumClass;
/*    */     }
/*    */ 
/*    */     public final String getDomain()
/*    */     {
/* 38 */       return Arrays.asList(this.enumClass.getEnumConstants()).toString();
/*    */     }
/*    */ 
/*    */     final E parse(String str)
/*    */     {
/* 43 */       return Enum.valueOf(this.enumClass, str.toUpperCase());
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.EnumParam
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ import com.sun.jersey.api.ParamException;
/*    */ import com.sun.jersey.api.container.ContainerException;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.ws.rs.core.Context;
/*    */ import javax.ws.rs.core.Response;
/*    */ import javax.ws.rs.core.Response.ResponseBuilder;
/*    */ import javax.ws.rs.core.Response.Status;
/*    */ import javax.ws.rs.ext.ExceptionMapper;
/*    */ import javax.ws.rs.ext.Provider;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.apache.hadoop.hdfs.web.JsonUtil;
/*    */ import org.apache.hadoop.ipc.RemoteException;
/*    */ import org.apache.hadoop.security.authorize.AuthorizationException;
/*    */ 
/*    */ @Provider
/*    */ public class ExceptionHandler
/*    */   implements ExceptionMapper<Exception>
/*    */ {
/* 42 */   public static final Log LOG = LogFactory.getLog(ExceptionHandler.class);
/*    */ 
/*    */   @Context
/*    */   private HttpServletResponse response;
/*    */ 
/* 45 */   private static Exception toCause(Exception e) { Throwable t = e.getCause();
/* 46 */     if ((t != null) && ((t instanceof Exception))) {
/* 47 */       e = (Exception)e.getCause();
/*    */     }
/* 49 */     return e;
/*    */   }
/*    */ 
/*    */   public Response toResponse(Exception e)
/*    */   {
/* 56 */     if (LOG.isTraceEnabled()) {
/* 57 */       LOG.trace("GOT EXCEPITION", e);
/*    */     }
/*    */ 
/* 61 */     this.response.setContentType(null);
/*    */ 
/* 64 */     if ((e instanceof ParamException)) {
/* 65 */       ParamException paramexception = (ParamException)e;
/* 66 */       e = new IllegalArgumentException("Invalid value for webhdfs parameter \"" + paramexception.getParameterName() + "\": " + e.getCause().getMessage(), e);
/*    */     }
/*    */ 
/* 70 */     if ((e instanceof ContainerException)) {
/* 71 */       e = toCause(e);
/*    */     }
/* 73 */     if ((e instanceof RemoteException))
/* 74 */       e = ((RemoteException)e).unwrapRemoteException();
/*    */     Response.Status s;
/*    */     Response.Status s;
/* 79 */     if ((e instanceof SecurityException)) {
/* 80 */       s = Response.Status.UNAUTHORIZED;
/*    */     }
/*    */     else
/*    */     {
/*    */       Response.Status s;
/* 81 */       if ((e instanceof AuthorizationException)) {
/* 82 */         s = Response.Status.UNAUTHORIZED;
/*    */       }
/*    */       else
/*    */       {
/*    */         Response.Status s;
/* 83 */         if ((e instanceof FileNotFoundException)) {
/* 84 */           s = Response.Status.NOT_FOUND;
/*    */         }
/*    */         else
/*    */         {
/*    */           Response.Status s;
/* 85 */           if ((e instanceof IOException)) {
/* 86 */             s = Response.Status.FORBIDDEN;
/*    */           }
/*    */           else
/*    */           {
/*    */             Response.Status s;
/* 87 */             if ((e instanceof UnsupportedOperationException)) {
/* 88 */               s = Response.Status.BAD_REQUEST;
/*    */             }
/*    */             else
/*    */             {
/*    */               Response.Status s;
/* 89 */               if ((e instanceof IllegalArgumentException)) {
/* 90 */                 s = Response.Status.BAD_REQUEST;
/*    */               } else {
/* 92 */                 LOG.warn("INTERNAL_SERVER_ERROR", e);
/* 93 */                 s = Response.Status.INTERNAL_SERVER_ERROR;
/*    */               }
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/* 96 */     String js = JsonUtil.toJsonString(e);
/* 97 */     return Response.status(s).type("application/json").entity(js).build();
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.ExceptionHandler
 * JD-Core Version:    0.6.1
 */
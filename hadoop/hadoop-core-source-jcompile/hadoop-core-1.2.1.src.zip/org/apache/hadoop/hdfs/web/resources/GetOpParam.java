/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ public class GetOpParam extends HttpOpParam<Op>
/*    */ {
/* 75 */   private static final EnumParam.Domain<Op> DOMAIN = new EnumParam.Domain("op", Op.class);
/*    */ 
/*    */   public GetOpParam(String str)
/*    */   {
/* 82 */     super(DOMAIN, DOMAIN.parse(str));
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 87 */     return "op";
/*    */   }
/*    */ 
/*    */   public static enum Op
/*    */     implements HttpOpParam.Op
/*    */   {
/* 26 */     OPEN(true, 200), 
/*    */ 
/* 28 */     GETFILESTATUS(false, 200), 
/* 29 */     LISTSTATUS(false, 200), 
/* 30 */     GETCONTENTSUMMARY(false, 200), 
/* 31 */     GETFILECHECKSUM(true, 200), 
/*    */ 
/* 33 */     GETHOMEDIRECTORY(false, 200), 
/* 34 */     GETDELEGATIONTOKEN(false, 200), 
/*    */ 
/* 37 */     GET_BLOCK_LOCATIONS(false, 200), 
/*    */ 
/* 39 */     NULL(false, 501);
/*    */ 
/*    */     final boolean redirect;
/*    */     final int expectedHttpResponseCode;
/*    */ 
/* 45 */     private Op(boolean redirect, int expectedHttpResponseCode) { this.redirect = redirect;
/* 46 */       this.expectedHttpResponseCode = expectedHttpResponseCode;
/*    */     }
/*    */ 
/*    */     public HttpOpParam.Type getType()
/*    */     {
/* 51 */       return HttpOpParam.Type.GET;
/*    */     }
/*    */ 
/*    */     public boolean getDoOutput()
/*    */     {
/* 56 */       return false;
/*    */     }
/*    */ 
/*    */     public boolean getRedirect()
/*    */     {
/* 61 */       return this.redirect;
/*    */     }
/*    */ 
/*    */     public int getExpectedHttpResponseCode()
/*    */     {
/* 66 */       return this.expectedHttpResponseCode;
/*    */     }
/*    */ 
/*    */     public String toQueryString()
/*    */     {
/* 71 */       return "op=" + this;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.GetOpParam
 * JD-Core Version:    0.6.1
 */
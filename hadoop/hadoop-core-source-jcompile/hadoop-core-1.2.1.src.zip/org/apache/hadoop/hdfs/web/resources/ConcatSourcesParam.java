/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.apache.hadoop.fs.Path;
/*    */ 
/*    */ public class ConcatSourcesParam extends StringParam
/*    */ {
/*    */   public static final String NAME = "sources";
/*    */   public static final String DEFAULT = "";
/* 30 */   private static final StringParam.Domain DOMAIN = new StringParam.Domain("sources", null);
/*    */ 
/*    */   private static String paths2String(Path[] paths) {
/* 33 */     if ((paths == null) || (paths.length == 0)) {
/* 34 */       return "";
/*    */     }
/* 36 */     StringBuilder b = new StringBuilder(paths[0].toUri().getPath());
/* 37 */     for (int i = 1; i < paths.length; i++) {
/* 38 */       b.append(',').append(paths[i].toUri().getPath());
/*    */     }
/* 40 */     return b.toString();
/*    */   }
/*    */ 
/*    */   public ConcatSourcesParam(String str)
/*    */   {
/* 48 */     super(DOMAIN, str);
/*    */   }
/*    */ 
/*    */   public ConcatSourcesParam(Path[] paths) {
/* 52 */     this(paths2String(paths));
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 57 */     return "sources";
/*    */   }
/*    */ 
/*    */   public final String[] getAbsolutePaths()
/*    */   {
/* 62 */     String[] paths = ((String)getValue()).split(",");
/* 63 */     return paths;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.ConcatSourcesParam
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ public class DoAsParam extends StringParam
/*    */ {
/*    */   public static final String NAME = "doas";
/*    */   public static final String DEFAULT = "";
/* 27 */   private static final StringParam.Domain DOMAIN = new StringParam.Domain("doas", null);
/*    */ 
/*    */   public DoAsParam(String str)
/*    */   {
/* 34 */     super(DOMAIN, (str == null) || (str.equals("")) ? null : str);
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 39 */     return "doas";
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.DoAsParam
 * JD-Core Version:    0.6.1
 */
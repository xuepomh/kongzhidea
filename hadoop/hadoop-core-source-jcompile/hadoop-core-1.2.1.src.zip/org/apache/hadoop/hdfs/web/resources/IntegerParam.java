/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ abstract class IntegerParam extends Param<Integer, Domain>
/*    */ {
/*    */   IntegerParam(Domain domain, Integer value, Integer min, Integer max)
/*    */   {
/* 24 */     super(domain, value);
/* 25 */     checkRange(min, max);
/*    */   }
/*    */ 
/*    */   private void checkRange(Integer min, Integer max) {
/* 29 */     if (this.value == null) {
/* 30 */       return;
/*    */     }
/* 32 */     if ((min != null) && (((Integer)this.value).intValue() < min.intValue())) {
/* 33 */       throw new IllegalArgumentException("Invalid parameter range: " + getName() + " = " + ((Domain)this.domain).toString((Integer)this.value) + " < " + ((Domain)this.domain).toString(min));
/*    */     }
/*    */ 
/* 36 */     if ((max != null) && (((Integer)this.value).intValue() > max.intValue()))
/* 37 */       throw new IllegalArgumentException("Invalid parameter range: " + getName() + " = " + ((Domain)this.domain).toString((Integer)this.value) + " > " + ((Domain)this.domain).toString(max));
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 44 */     return getName() + "=" + ((Domain)this.domain).toString((Integer)getValue());
/*    */   }
/*    */ 
/*    */   static final class Domain extends Param.Domain<Integer>
/*    */   {
/*    */     final int radix;
/*    */ 
/*    */     Domain(String paramName)
/*    */     {
/* 53 */       this(paramName, 10);
/*    */     }
/*    */ 
/*    */     Domain(String paramName, int radix) {
/* 57 */       super();
/* 58 */       this.radix = radix;
/*    */     }
/*    */ 
/*    */     public String getDomain()
/*    */     {
/* 63 */       return "<null | int in radix " + this.radix + ">";
/*    */     }
/*    */ 
/*    */     Integer parse(String str)
/*    */     {
/*    */       try {
/* 69 */         return "null".equals(str) ? null : Integer.valueOf(Integer.parseInt(str, this.radix));
/*    */       } catch (NumberFormatException e) {
/* 71 */         throw new IllegalArgumentException("Failed to parse \"" + str + "\" as a radix-" + this.radix + " integer.", e);
/*    */       }
/*    */     }
/*    */ 
/*    */     String toString(Integer n)
/*    */     {
/* 78 */       return n == null ? "null" : Integer.toString(n.intValue(), this.radix);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.IntegerParam
 * JD-Core Version:    0.6.1
 */
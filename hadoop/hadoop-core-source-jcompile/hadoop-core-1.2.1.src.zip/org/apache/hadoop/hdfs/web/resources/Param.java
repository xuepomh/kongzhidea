/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Comparator;
/*    */ 
/*    */ public abstract class Param<T, D extends Domain<T>>
/*    */ {
/*    */   static final String NULL = "null";
/* 28 */   static final Comparator<Param<?, ?>> NAME_CMP = new Comparator()
/*    */   {
/*    */     public int compare(Param<?, ?> left, Param<?, ?> right) {
/* 31 */       return left.getName().compareTo(right.getName());
/*    */     } } ;
/*    */   final D domain;
/*    */   final T value;
/*    */ 
/* 38 */   public static String toSortedString(String separator, Param<?, ?>[] parameters) { Arrays.sort(parameters, NAME_CMP);
/* 39 */     StringBuilder b = new StringBuilder();
/* 40 */     for (Param p : parameters) {
/* 41 */       if (p.getValue() != null) {
/* 42 */         b.append(separator).append(p);
/*    */       }
/*    */     }
/* 45 */     return b.toString();
/*    */   }
/*    */ 
/*    */   Param(D domain, T value)
/*    */   {
/* 54 */     this.domain = domain;
/* 55 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public final T getValue()
/*    */   {
/* 60 */     return this.value;
/*    */   }
/*    */ 
/*    */   public abstract String getName();
/*    */ 
/*    */   public String toString()
/*    */   {
/* 68 */     return new StringBuilder().append(getName()).append("=").append(this.value).toString();
/*    */   }
/*    */ 
/*    */   static abstract class Domain<T>
/*    */   {
/*    */     final String paramName;
/*    */ 
/*    */     Domain(String paramName)
/*    */     {
/* 77 */       this.paramName = paramName;
/*    */     }
/*    */ 
/*    */     public final String getParamName()
/*    */     {
/* 82 */       return this.paramName;
/*    */     }
/*    */ 
/*    */     public abstract String getDomain();
/*    */ 
/*    */     abstract T parse(String paramString);
/*    */ 
/*    */     public final T parse(String varName, String str)
/*    */     {
/*    */       try
/*    */       {
/* 96 */         return (str != null) && (str.trim().length() > 0) ? parse(str) : null;
/*    */       } catch (Exception e) {
/* 98 */         throw new IllegalArgumentException("Failed to parse \"" + str + "\" for the parameter " + varName + ".  The value must be in the domain " + getDomain(), e);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.Param
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ public class LengthParam extends LongParam
/*    */ {
/*    */   public static final String NAME = "length";
/*    */   public static final String DEFAULT = "null";
/* 27 */   private static final LongParam.Domain DOMAIN = new LongParam.Domain("length");
/*    */ 
/*    */   public LengthParam(Long value)
/*    */   {
/* 34 */     super(DOMAIN, value, Long.valueOf(0L), null);
/*    */   }
/*    */ 
/*    */   public LengthParam(String str)
/*    */   {
/* 42 */     this(DOMAIN.parse(str));
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 47 */     return "length";
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.LengthParam
 * JD-Core Version:    0.6.1
 */
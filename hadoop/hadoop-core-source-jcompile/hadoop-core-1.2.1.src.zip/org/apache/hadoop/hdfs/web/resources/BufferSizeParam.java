/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ 
/*    */ public class BufferSizeParam extends IntegerParam
/*    */ {
/*    */   public static final String NAME = "buffersize";
/*    */   public static final String DEFAULT = "null";
/* 29 */   private static final IntegerParam.Domain DOMAIN = new IntegerParam.Domain("buffersize");
/*    */ 
/*    */   public BufferSizeParam(Integer value)
/*    */   {
/* 36 */     super(DOMAIN, value, Integer.valueOf(1), null);
/*    */   }
/*    */ 
/*    */   public BufferSizeParam(String str)
/*    */   {
/* 44 */     this(DOMAIN.parse(str));
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 49 */     return "buffersize";
/*    */   }
/*    */ 
/*    */   public int getValue(Configuration conf)
/*    */   {
/* 54 */     return getValue() != null ? ((Integer)getValue()).intValue() : conf.getInt("io.file.buffer.size", 4096);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.BufferSizeParam
 * JD-Core Version:    0.6.1
 */
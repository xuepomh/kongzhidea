/*    */ package org.apache.hadoop.hdfs.web;
/*    */ 
/*    */ import com.sun.jersey.spi.container.ContainerRequest;
/*    */ import com.sun.jersey.spi.container.ContainerRequestFilter;
/*    */ import com.sun.jersey.spi.container.ContainerResponseFilter;
/*    */ import com.sun.jersey.spi.container.ResourceFilter;
/*    */ import java.net.URI;
/*    */ import java.util.List;
/*    */ import java.util.Map.Entry;
/*    */ import javax.ws.rs.core.MultivaluedMap;
/*    */ import javax.ws.rs.core.UriBuilder;
/*    */ 
/*    */ public class ParamFilter
/*    */   implements ResourceFilter
/*    */ {
/* 37 */   private static final ContainerRequestFilter LOWER_CASE = new ContainerRequestFilter()
/*    */   {
/*    */     public ContainerRequest filter(ContainerRequest request)
/*    */     {
/* 41 */       MultivaluedMap parameters = request.getQueryParameters();
/* 42 */       if (ParamFilter.containsUpperCase(parameters.keySet()))
/*    */       {
/* 44 */         URI lower = ParamFilter.rebuildQuery(request.getRequestUri(), parameters);
/* 45 */         request.setUris(request.getBaseUri(), lower);
/*    */       }
/* 47 */       return request;
/*    */     }
/* 37 */   };
/*    */ 
/*    */   public ContainerRequestFilter getRequestFilter()
/*    */   {
/* 53 */     return LOWER_CASE;
/*    */   }
/*    */ 
/*    */   public ContainerResponseFilter getResponseFilter()
/*    */   {
/* 58 */     return null;
/*    */   }
/*    */ 
/*    */   static boolean containsUpperCase(Iterable<String> strings)
/*    */   {
/* 63 */     for (String s : strings) {
/* 64 */       for (int i = 0; i < s.length(); i++) {
/* 65 */         if (Character.isUpperCase(s.charAt(i))) {
/* 66 */           return true;
/*    */         }
/*    */       }
/*    */     }
/* 70 */     return false;
/*    */   }
/*    */ 
/*    */   private static URI rebuildQuery(URI uri, MultivaluedMap<String, String> parameters)
/*    */   {
/* 76 */     UriBuilder b = UriBuilder.fromUri(uri).replaceQuery("");
/* 77 */     for (Map.Entry e : parameters.entrySet()) {
/* 78 */       key = ((String)e.getKey()).toLowerCase();
/* 79 */       for (String v : (List)e.getValue())
/* 80 */         b = b.queryParam(key, new Object[] { v });
/*    */     }
/*    */     String key;
/* 83 */     return b.build(new Object[0]);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.ParamFilter
 * JD-Core Version:    0.6.1
 */
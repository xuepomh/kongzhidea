/*    */ package org.apache.hadoop.hdfs.web.resources;
/*    */ 
/*    */ import org.apache.hadoop.security.UserGroupInformation;
/*    */ 
/*    */ public class DelegationParam extends StringParam
/*    */ {
/*    */   public static final String NAME = "delegation";
/*    */   public static final String DEFAULT = "";
/* 29 */   private static final StringParam.Domain DOMAIN = new StringParam.Domain("delegation", null);
/*    */ 
/*    */   public DelegationParam(String str)
/*    */   {
/* 36 */     super(DOMAIN, (UserGroupInformation.isSecurityEnabled()) && (str != null) && (!str.equals("")) ? str : null);
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 42 */     return "delegation";
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.web.resources.DelegationParam
 * JD-Core Version:    0.6.1
 */
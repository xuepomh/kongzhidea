/*     */ package org.apache.hadoop.hdfs.util;
/*     */ 
/*     */ public class DataTransferThrottler
/*     */ {
/*     */   private long period;
/*     */   private long periodExtension;
/*     */   private long bytesPerPeriod;
/*     */   private long curPeriodStart;
/*     */   private long curReserve;
/*     */   private long bytesAlreadyUsed;
/*     */ 
/*     */   public DataTransferThrottler(long bandwidthPerSec)
/*     */   {
/*  38 */     this(500L, bandwidthPerSec);
/*     */   }
/*     */ 
/*     */   public DataTransferThrottler(long period, long bandwidthPerSec)
/*     */   {
/*  48 */     this.curPeriodStart = System.currentTimeMillis();
/*  49 */     this.period = period;
/*  50 */     this.curReserve = (this.bytesPerPeriod = bandwidthPerSec * period / 1000L);
/*  51 */     this.periodExtension = (period * 3L);
/*     */   }
/*     */ 
/*     */   public synchronized long getBandwidth()
/*     */   {
/*  58 */     return this.bytesPerPeriod * 1000L / this.period;
/*     */   }
/*     */ 
/*     */   public synchronized void setBandwidth(long bytesPerSecond)
/*     */   {
/*  68 */     if (bytesPerSecond <= 0L) {
/*  69 */       throw new IllegalArgumentException("" + bytesPerSecond);
/*     */     }
/*  71 */     this.bytesPerPeriod = (bytesPerSecond * this.period / 1000L);
/*     */   }
/*     */ 
/*     */   public synchronized void throttle(long numOfBytes)
/*     */   {
/*  82 */     if (numOfBytes <= 0L) {
/*  83 */       return;
/*     */     }
/*     */ 
/*  86 */     this.curReserve -= numOfBytes;
/*  87 */     this.bytesAlreadyUsed += numOfBytes;
/*     */ 
/*  89 */     while (this.curReserve <= 0L) {
/*  90 */       long now = System.currentTimeMillis();
/*  91 */       long curPeriodEnd = this.curPeriodStart + this.period;
/*     */ 
/*  93 */       if (now < curPeriodEnd)
/*     */       {
/*     */         try {
/*  96 */           wait(curPeriodEnd - now); } catch (InterruptedException ignored) {
/*     */         }
/*  98 */       } else if (now < this.curPeriodStart + this.periodExtension) {
/*  99 */         this.curPeriodStart = curPeriodEnd;
/* 100 */         this.curReserve += this.bytesPerPeriod;
/*     */       }
/*     */       else
/*     */       {
/* 104 */         this.curPeriodStart = now;
/* 105 */         this.curReserve = (this.bytesPerPeriod - this.bytesAlreadyUsed);
/*     */       }
/*     */     }
/*     */ 
/* 109 */     this.bytesAlreadyUsed -= numOfBytes;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.util.DataTransferThrottler
 * JD-Core Version:    0.6.1
 */
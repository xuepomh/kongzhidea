package org.apache.hadoop.hdfs.util;

public abstract interface GSet<K, E extends K> extends Iterable<E>
{
  public abstract int size();

  public abstract boolean contains(K paramK);

  public abstract E get(K paramK);

  public abstract E put(E paramE);

  public abstract E remove(K paramK);

  public abstract void clear();
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.util.GSet
 * JD-Core Version:    0.6.1
 */
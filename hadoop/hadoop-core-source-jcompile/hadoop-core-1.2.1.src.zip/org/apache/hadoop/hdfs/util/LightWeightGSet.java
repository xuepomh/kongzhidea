/*     */ package org.apache.hadoop.hdfs.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.Iterator;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class LightWeightGSet<K, E extends K>
/*     */   implements GSet<K, E>
/*     */ {
/*  56 */   public static final Log LOG = LogFactory.getLog(GSet.class);
/*     */   static final int MAX_ARRAY_LENGTH = 1073741824;
/*     */   static final int MIN_ARRAY_LENGTH = 1;
/*     */   private final LinkedElement[] entries;
/*     */   private final int hash_mask;
/*  68 */   private int size = 0;
/*     */ 
/*  72 */   private volatile int modification = 0;
/*     */ 
/*     */   public LightWeightGSet(int recommended_length)
/*     */   {
/*  78 */     int actual = actualArrayLength(recommended_length);
/*  79 */     LOG.info("recommended=" + recommended_length + ", actual=" + actual);
/*     */ 
/*  81 */     this.entries = new LinkedElement[actual];
/*  82 */     this.hash_mask = (this.entries.length - 1);
/*     */   }
/*     */ 
/*     */   private static int actualArrayLength(int recommended)
/*     */   {
/*  87 */     if (recommended > 1073741824)
/*  88 */       return 1073741824;
/*  89 */     if (recommended < 1) {
/*  90 */       return 1;
/*     */     }
/*  92 */     int a = Integer.highestOneBit(recommended);
/*  93 */     return a == recommended ? a : a << 1;
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/*  99 */     return this.size;
/*     */   }
/*     */ 
/*     */   private int getIndex(K key) {
/* 103 */     return key.hashCode() & this.hash_mask;
/*     */   }
/*     */ 
/*     */   private E convert(LinkedElement e)
/*     */   {
/* 108 */     Object r = e;
/* 109 */     return r;
/*     */   }
/*     */ 
/*     */   public E get(K key)
/*     */   {
/* 115 */     if (key == null) {
/* 116 */       throw new NullPointerException("key == null");
/*     */     }
/*     */ 
/* 120 */     int index = getIndex(key);
/* 121 */     for (LinkedElement e = this.entries[index]; e != null; e = e.getNext()) {
/* 122 */       if (e.equals(key)) {
/* 123 */         return convert(e);
/*     */       }
/*     */     }
/*     */ 
/* 127 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean contains(K key)
/*     */   {
/* 132 */     return get(key) != null;
/*     */   }
/*     */ 
/*     */   public E put(E element)
/*     */   {
/* 138 */     if (element == null) {
/* 139 */       throw new NullPointerException("Null element is not supported.");
/*     */     }
/* 141 */     if (!(element instanceof LinkedElement)) {
/* 142 */       throw new IllegalArgumentException("!(element instanceof LinkedElement), element.getClass()=" + element.getClass());
/*     */     }
/*     */ 
/* 146 */     LinkedElement e = (LinkedElement)element;
/*     */ 
/* 149 */     int index = getIndex(element);
/*     */ 
/* 152 */     Object existing = remove(index, element);
/*     */ 
/* 155 */     this.modification += 1;
/* 156 */     this.size += 1;
/* 157 */     e.setNext(this.entries[index]);
/* 158 */     this.entries[index] = e;
/*     */ 
/* 160 */     return existing;
/*     */   }
/*     */ 
/*     */   private E remove(int index, K key)
/*     */   {
/* 171 */     if (this.entries[index] == null)
/* 172 */       return null;
/* 173 */     if (this.entries[index].equals(key))
/*     */     {
/* 175 */       this.modification += 1;
/* 176 */       this.size -= 1;
/* 177 */       LinkedElement e = this.entries[index];
/* 178 */       this.entries[index] = e.getNext();
/* 179 */       e.setNext(null);
/* 180 */       return convert(e);
/*     */     }
/*     */ 
/* 184 */     LinkedElement prev = this.entries[index];
/* 185 */     for (LinkedElement curr = prev.getNext(); curr != null; ) {
/* 186 */       if (curr.equals(key))
/*     */       {
/* 188 */         this.modification += 1;
/* 189 */         this.size -= 1;
/* 190 */         prev.setNext(curr.getNext());
/* 191 */         curr.setNext(null);
/* 192 */         return convert(curr);
/*     */       }
/* 194 */       prev = curr;
/* 195 */       curr = curr.getNext();
/*     */     }
/*     */ 
/* 199 */     return null;
/*     */   }
/*     */ 
/*     */   public E remove(K key)
/*     */   {
/* 206 */     if (key == null) {
/* 207 */       throw new NullPointerException("key == null");
/*     */     }
/* 209 */     return remove(getIndex(key), key);
/*     */   }
/*     */ 
/*     */   public Iterator<E> iterator()
/*     */   {
/* 214 */     return new SetIterator(null);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 219 */     StringBuilder b = new StringBuilder(getClass().getSimpleName());
/* 220 */     b.append("(size=").append(this.size).append(String.format(", %08x", new Object[] { Integer.valueOf(this.hash_mask) })).append(", modification=").append(this.modification).append(", entries.length=").append(this.entries.length).append(")");
/*     */ 
/* 225 */     return b.toString();
/*     */   }
/*     */ 
/*     */   public void printDetails(PrintStream out)
/*     */   {
/* 230 */     out.print(this + ", entries = [");
/* 231 */     for (int i = 0; i < this.entries.length; i++) {
/* 232 */       if (this.entries[i] != null) {
/* 233 */         LinkedElement e = this.entries[i];
/* 234 */         out.print("\n  " + i + ": " + e);
/* 235 */         for (e = e.getNext(); e != null; e = e.getNext()) {
/* 236 */           out.print(" -> " + e);
/*     */         }
/*     */       }
/*     */     }
/* 240 */     out.println("\n]");
/*     */   }
/*     */ 
/*     */   public static int computeCapacity(double percentage, String mapName)
/*     */   {
/* 291 */     return computeCapacity(Runtime.getRuntime().maxMemory(), percentage, mapName);
/*     */   }
/*     */ 
/*     */   static int computeCapacity(long maxMemory, double percentage, String mapName)
/*     */   {
/* 298 */     if ((percentage > 100.0D) || (percentage < 0.0D)) {
/* 299 */       throw new IllegalArgumentException("Percentage " + percentage + " must be greater than or equal to 0 " + " and less than or equal to 100");
/*     */     }
/*     */ 
/* 303 */     if (maxMemory < 0L) {
/* 304 */       throw new IllegalArgumentException("Memory " + maxMemory + " must be greater than or equal to 0");
/*     */     }
/*     */ 
/* 307 */     if ((percentage == 0.0D) || (maxMemory == 0L)) {
/* 308 */       return 0;
/*     */     }
/*     */ 
/* 312 */     String vmBit = System.getProperty("sun.arch.data.model");
/*     */ 
/* 315 */     double percentDivisor = 100.0D / percentage;
/* 316 */     double percentMemory = maxMemory / percentDivisor;
/*     */ 
/* 319 */     int e1 = (int)(Math.log(percentMemory) / Math.log(2.0D) + 0.5D);
/* 320 */     int e2 = e1 - ("32".equals(vmBit) ? 2 : 3);
/* 321 */     int exponent = e2 > 30 ? 30 : e2 < 0 ? 0 : e2;
/* 322 */     int c = 1 << exponent;
/*     */ 
/* 324 */     LOG.info("Computing capacity for map " + mapName);
/* 325 */     LOG.info("VM type       = " + vmBit + "-bit");
/* 326 */     LOG.info(percentage + "% max memory = " + maxMemory);
/* 327 */     LOG.info("capacity      = 2^" + exponent + " = " + c + " entries");
/* 328 */     return c;
/*     */   }
/*     */ 
/*     */   public void clear() {
/* 332 */     for (int i = 0; i < this.entries.length; i++) {
/* 333 */       this.entries[i] = null;
/*     */     }
/* 335 */     this.size = 0;
/*     */   }
/*     */ 
/*     */   private class SetIterator
/*     */     implements Iterator<E>
/*     */   {
/* 245 */     private final int startModification = LightWeightGSet.this.modification;
/*     */ 
/* 247 */     private int index = -1;
/*     */ 
/* 249 */     private LightWeightGSet.LinkedElement next = nextNonemptyEntry();
/*     */ 
/*     */     private SetIterator() {
/*     */     }
/* 253 */     private LightWeightGSet.LinkedElement nextNonemptyEntry() { for (this.index += 1; (this.index < LightWeightGSet.this.entries.length) && (LightWeightGSet.this.entries[this.index] == null); this.index += 1);
/* 254 */       return this.index < LightWeightGSet.this.entries.length ? LightWeightGSet.this.entries[this.index] : null;
/*     */     }
/*     */ 
/*     */     public boolean hasNext()
/*     */     {
/* 259 */       return this.next != null;
/*     */     }
/*     */ 
/*     */     public E next()
/*     */     {
/* 264 */       if (LightWeightGSet.this.modification != this.startModification) {
/* 265 */         throw new ConcurrentModificationException("modification=" + LightWeightGSet.this.modification + " != startModification = " + this.startModification);
/*     */       }
/*     */ 
/* 269 */       Object e = LightWeightGSet.this.convert(this.next);
/*     */ 
/* 272 */       LightWeightGSet.LinkedElement n = this.next.getNext();
/* 273 */       this.next = (n != null ? n : nextNonemptyEntry());
/*     */ 
/* 275 */       return e;
/*     */     }
/*     */ 
/*     */     public void remove()
/*     */     {
/* 280 */       throw new UnsupportedOperationException("Remove is not supported.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface LinkedElement
/*     */   {
/*     */     public abstract void setNext(LinkedElement paramLinkedElement);
/*     */ 
/*     */     public abstract LinkedElement getNext();
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.util.LightWeightGSet
 * JD-Core Version:    0.6.1
 */
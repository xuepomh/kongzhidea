/*    */ package org.apache.hadoop.hdfs.util;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.FilterOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.nio.channels.FileChannel;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.apache.hadoop.io.IOUtils;
/*    */ 
/*    */ public class AtomicFileOutputStream extends FilterOutputStream
/*    */ {
/*    */   private static final String TMP_EXTENSION = ".tmp";
/* 47 */   private static final Log LOG = LogFactory.getLog(AtomicFileOutputStream.class);
/*    */   private final File origFile;
/*    */   private final File tmpFile;
/*    */ 
/*    */   public AtomicFileOutputStream(File f)
/*    */     throws FileNotFoundException
/*    */   {
/* 56 */     super(new FileOutputStream(new File(f.getParentFile(), f.getName() + ".tmp")));
/* 57 */     this.origFile = f.getAbsoluteFile();
/* 58 */     this.tmpFile = new File(f.getParentFile(), f.getName() + ".tmp").getAbsoluteFile();
/*    */   }
/*    */ 
/*    */   public void close() throws IOException
/*    */   {
/* 63 */     boolean triedToClose = false; boolean success = false;
/*    */     try {
/* 65 */       flush();
/* 66 */       ((FileOutputStream)this.out).getChannel().force(true);
/*    */ 
/* 68 */       triedToClose = true;
/* 69 */       super.close();
/* 70 */       success = true;
/*    */     }
/*    */     finally
/*    */     {
/*    */       boolean renamed;
/* 72 */       if (success) {
/* 73 */         boolean renamed = this.tmpFile.renameTo(this.origFile);
/* 74 */         if (!renamed)
/*    */         {
/* 76 */           if ((!this.origFile.delete()) || (!this.tmpFile.renameTo(this.origFile)))
/* 77 */             throw new IOException("Could not rename temporary file " + this.tmpFile + " to " + this.origFile);
/*    */         }
/*    */       }
/*    */       else
/*    */       {
/* 82 */         if (!triedToClose)
/*    */         {
/* 84 */           IOUtils.closeStream(this.out);
/*    */         }
/*    */ 
/* 87 */         if (!this.tmpFile.delete())
/* 88 */           LOG.warn("Unable to delete tmp file " + this.tmpFile);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.util.AtomicFileOutputStream
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.hdfs.util;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ public class ByteArray
/*    */ {
/* 26 */   private int hash = 0;
/*    */   private final byte[] bytes;
/*    */ 
/*    */   public ByteArray(byte[] bytes)
/*    */   {
/* 30 */     this.bytes = bytes;
/*    */   }
/*    */ 
/*    */   public byte[] getBytes() {
/* 34 */     return this.bytes;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 39 */     if (this.hash == 0) {
/* 40 */       this.hash = Arrays.hashCode(this.bytes);
/*    */     }
/* 42 */     return this.hash;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 47 */     if (!(o instanceof ByteArray)) {
/* 48 */       return false;
/*    */     }
/* 50 */     return Arrays.equals(this.bytes, ((ByteArray)o).bytes);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.util.ByteArray
 * JD-Core Version:    0.6.1
 */
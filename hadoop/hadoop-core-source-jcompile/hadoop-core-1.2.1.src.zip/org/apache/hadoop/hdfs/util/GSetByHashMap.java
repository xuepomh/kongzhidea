/*    */ package org.apache.hadoop.hdfs.util;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class GSetByHashMap<K, E extends K>
/*    */   implements GSet<K, E>
/*    */ {
/*    */   private final HashMap<K, E> m;
/*    */ 
/*    */   public GSetByHashMap(int initialCapacity, float loadFactor)
/*    */   {
/* 30 */     this.m = new HashMap(initialCapacity, loadFactor);
/*    */   }
/*    */ 
/*    */   public int size()
/*    */   {
/* 35 */     return this.m.size();
/*    */   }
/*    */ 
/*    */   public boolean contains(K k)
/*    */   {
/* 40 */     return this.m.containsKey(k);
/*    */   }
/*    */ 
/*    */   public E get(K k)
/*    */   {
/* 45 */     return this.m.get(k);
/*    */   }
/*    */ 
/*    */   public E put(E element)
/*    */   {
/* 50 */     if (element == null) {
/* 51 */       throw new UnsupportedOperationException("Null element is not supported.");
/*    */     }
/* 53 */     return this.m.put(element, element);
/*    */   }
/*    */ 
/*    */   public E remove(K k)
/*    */   {
/* 58 */     return this.m.remove(k);
/*    */   }
/*    */ 
/*    */   public Iterator<E> iterator()
/*    */   {
/* 63 */     return this.m.values().iterator();
/*    */   }
/*    */ 
/*    */   public void clear()
/*    */   {
/* 68 */     this.m.clear();
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.hdfs.util.GSetByHashMap
 * JD-Core Version:    0.6.1
 */
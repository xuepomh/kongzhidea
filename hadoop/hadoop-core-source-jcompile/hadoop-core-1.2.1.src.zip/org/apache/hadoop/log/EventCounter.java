/*    */ package org.apache.hadoop.log;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ @Deprecated
/*    */ public class EventCounter extends org.apache.hadoop.log.metrics.EventCounter
/*    */ {
/*    */   static
/*    */   {
/* 29 */     System.err.println("WARNING: " + EventCounter.class.getName() + " is deprecated. Please use " + org.apache.hadoop.log.metrics.EventCounter.class.getName() + " in all the log4j.properties files.");
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.log.EventCounter
 * JD-Core Version:    0.6.1
 */
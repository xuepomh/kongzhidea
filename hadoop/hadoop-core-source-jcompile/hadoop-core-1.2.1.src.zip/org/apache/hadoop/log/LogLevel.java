/*     */ package org.apache.hadoop.log;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.commons.logging.impl.Jdk14Logger;
/*     */ import org.apache.commons.logging.impl.Log4JLogger;
/*     */ import org.apache.hadoop.http.HttpServer;
/*     */ import org.apache.hadoop.util.ServletUtil;
/*     */ 
/*     */ public class LogLevel
/*     */ {
/*  36 */   public static final String USAGES = "\nUSAGES:\njava " + LogLevel.class.getName() + " -getlevel <host:port> <name>\n" + "java " + LogLevel.class.getName() + " -setlevel <host:port> <name> <level>\n";
/*     */   static final String MARKER = "<!-- OUTPUT -->";
/*  80 */   static final Pattern TAG = Pattern.compile("<[^>]*>");
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  46 */     if ((args.length == 3) && ("-getlevel".equals(args[0]))) {
/*  47 */       process("http://" + args[1] + "/logLevel?log=" + args[2]);
/*  48 */       return;
/*     */     }
/*  50 */     if ((args.length == 4) && ("-setlevel".equals(args[0]))) {
/*  51 */       process("http://" + args[1] + "/logLevel?log=" + args[2] + "&level=" + args[3]);
/*     */ 
/*  53 */       return;
/*     */     }
/*     */ 
/*  56 */     System.err.println(USAGES);
/*  57 */     System.exit(-1);
/*     */   }
/*     */ 
/*     */   private static void process(String urlstring) {
/*     */     try {
/*  62 */       URL url = new URL(urlstring);
/*  63 */       System.out.println("Connecting to " + url);
/*  64 */       URLConnection connection = url.openConnection();
/*  65 */       connection.connect();
/*     */ 
/*  67 */       BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
/*     */       String line;
/*  69 */       while ((line = in.readLine()) != null) {
/*  70 */         if (line.startsWith("<!-- OUTPUT -->"))
/*  71 */           System.out.println(TAG.matcher(line).replaceAll(""));
/*     */       }
/*  73 */       in.close();
/*     */     } catch (IOException ioe) {
/*  75 */       System.err.println("" + ioe);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Servlet extends HttpServlet
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     static final String FORMS = "\n<br /><hr /><h3>Get / Set</h3>\n<form>Log: <input type='text' size='50' name='log' /> <input type='submit' value='Get Log Level' /></form>\n<form>Log: <input type='text' size='50' name='log' /> Level: <input type='text' name='level' /> <input type='submit' value='Set Log Level' /></form>";
/*     */ 
/*     */     public void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */       throws ServletException, IOException
/*     */     {
/*  92 */       if (!HttpServer.hasAdministratorAccess(getServletContext(), request, response))
/*     */       {
/*  94 */         return;
/*     */       }
/*     */ 
/*  97 */       PrintWriter out = ServletUtil.initHTML(response, "Log Level");
/*  98 */       String logName = ServletUtil.getParameter(request, "log");
/*  99 */       String level = ServletUtil.getParameter(request, "level");
/*     */ 
/* 101 */       if (logName != null) {
/* 102 */         out.println("<br /><hr /><h3>Results</h3>");
/* 103 */         out.println("<!-- OUTPUT -->Submitted Log Name: <b>" + logName + "</b><br />");
/*     */ 
/* 106 */         Log log = LogFactory.getLog(logName);
/* 107 */         out.println("<!-- OUTPUT -->Log Class: <b>" + log.getClass().getName() + "</b><br />");
/*     */ 
/* 109 */         if (level != null) {
/* 110 */           out.println("<!-- OUTPUT -->Submitted Level: <b>" + level + "</b><br />");
/*     */         }
/*     */ 
/* 113 */         if ((log instanceof Log4JLogger)) {
/* 114 */           process(((Log4JLogger)log).getLogger(), level, out);
/*     */         }
/* 116 */         else if ((log instanceof Jdk14Logger)) {
/* 117 */           process(((Jdk14Logger)log).getLogger(), level, out);
/*     */         }
/*     */         else {
/* 120 */           out.println("Sorry, " + log.getClass() + " not supported.<br />");
/*     */         }
/*     */       }
/*     */ 
/* 124 */       out.println("\n<br /><hr /><h3>Get / Set</h3>\n<form>Log: <input type='text' size='50' name='log' /> <input type='submit' value='Get Log Level' /></form>\n<form>Log: <input type='text' size='50' name='log' /> Level: <input type='text' name='level' /> <input type='submit' value='Set Log Level' /></form>");
/* 125 */       out.println(ServletUtil.HTML_TAIL);
/*     */     }
/*     */ 
/*     */     private static void process(org.apache.log4j.Logger log, String level, PrintWriter out)
/*     */       throws IOException
/*     */     {
/* 139 */       if (level != null) {
/* 140 */         log.setLevel(org.apache.log4j.Level.toLevel(level));
/* 141 */         out.println("<!-- OUTPUT -->Setting Level to " + level + " ...<br />");
/*     */       }
/* 143 */       out.println("<!-- OUTPUT -->Effective level: <b>" + log.getEffectiveLevel() + "</b><br />");
/*     */     }
/*     */ 
/*     */     private static void process(java.util.logging.Logger log, String level, PrintWriter out)
/*     */       throws IOException
/*     */     {
/* 149 */       if (level != null) {
/* 150 */         log.setLevel(java.util.logging.Level.parse(level));
/* 151 */         out.println("<!-- OUTPUT -->Setting Level to " + level + " ...<br />");
/*     */       }
/* 155 */       java.util.logging.Level lev;
/* 155 */       while ((lev = log.getLevel()) == null) log = log.getParent();
/* 156 */       out.println("<!-- OUTPUT -->Effective level: <b>" + lev + "</b><br />");
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.log.LogLevel
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.log.metrics;
/*    */ 
/*    */ import org.apache.hadoop.classification.InterfaceAudience.Private;
/*    */ import org.apache.hadoop.classification.InterfaceAudience.Public;
/*    */ import org.apache.hadoop.classification.InterfaceStability.Stable;
/*    */ import org.apache.log4j.AppenderSkeleton;
/*    */ import org.apache.log4j.Level;
/*    */ import org.apache.log4j.spi.LoggingEvent;
/*    */ 
/*    */ @InterfaceAudience.Public
/*    */ @InterfaceStability.Stable
/*    */ public class EventCounter extends AppenderSkeleton
/*    */ {
/*    */   private static final int FATAL = 0;
/*    */   private static final int ERROR = 1;
/*    */   private static final int WARN = 2;
/*    */   private static final int INFO = 3;
/* 53 */   private static EventCounts counts = new EventCounts(null);
/*    */ 
/*    */   @InterfaceAudience.Private
/*    */   public static long getFatal() {
/* 57 */     return counts.get(0);
/*    */   }
/*    */ 
/*    */   @InterfaceAudience.Private
/*    */   public static long getError() {
/* 62 */     return counts.get(1);
/*    */   }
/*    */ 
/*    */   @InterfaceAudience.Private
/*    */   public static long getWarn() {
/* 67 */     return counts.get(2);
/*    */   }
/*    */ 
/*    */   @InterfaceAudience.Private
/*    */   public static long getInfo() {
/* 72 */     return counts.get(3);
/*    */   }
/*    */ 
/*    */   public void append(LoggingEvent event)
/*    */   {
/* 77 */     Level level = event.getLevel();
/* 78 */     if (level == Level.INFO) {
/* 79 */       counts.incr(3);
/*    */     }
/* 81 */     else if (level == Level.WARN) {
/* 82 */       counts.incr(2);
/*    */     }
/* 84 */     else if (level == Level.ERROR) {
/* 85 */       counts.incr(1);
/*    */     }
/* 87 */     else if (level == Level.FATAL)
/* 88 */       counts.incr(0);
/*    */   }
/*    */ 
/*    */   public void close()
/*    */   {
/*    */   }
/*    */ 
/*    */   public boolean requiresLayout()
/*    */   {
/* 99 */     return false;
/*    */   }
/*    */ 
/*    */   private static class EventCounts
/*    */   {
/* 42 */     private final long[] counts = { 0L, 0L, 0L, 0L };
/*    */ 
/*    */     private synchronized void incr(int i) {
/* 45 */       this.counts[i] += 1L;
/*    */     }
/*    */ 
/*    */     private synchronized long get(int i) {
/* 49 */       return this.counts[i];
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.log.metrics.EventCounter
 * JD-Core Version:    0.6.1
 */
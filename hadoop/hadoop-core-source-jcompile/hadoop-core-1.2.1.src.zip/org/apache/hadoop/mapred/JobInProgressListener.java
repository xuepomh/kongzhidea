package org.apache.hadoop.mapred;

import java.io.IOException;

abstract class JobInProgressListener
{
  public abstract void jobAdded(JobInProgress paramJobInProgress)
    throws IOException;

  public abstract void jobRemoved(JobInProgress paramJobInProgress);

  public abstract void jobUpdated(JobChangeEvent paramJobChangeEvent);
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JobInProgressListener
 * JD-Core Version:    0.6.1
 */
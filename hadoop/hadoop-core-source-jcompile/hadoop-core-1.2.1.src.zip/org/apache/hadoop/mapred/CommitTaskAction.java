/*    */ package org.apache.hadoop.mapred;
/*    */ 
/*    */ import java.io.DataInput;
/*    */ import java.io.DataOutput;
/*    */ import java.io.IOException;
/*    */ 
/*    */ class CommitTaskAction extends TaskTrackerAction
/*    */ {
/*    */   private TaskAttemptID taskId;
/*    */ 
/*    */   public CommitTaskAction()
/*    */   {
/* 34 */     super(TaskTrackerAction.ActionType.COMMIT_TASK);
/* 35 */     this.taskId = new TaskAttemptID();
/*    */   }
/*    */ 
/*    */   public CommitTaskAction(TaskAttemptID taskId) {
/* 39 */     super(TaskTrackerAction.ActionType.COMMIT_TASK);
/* 40 */     this.taskId = taskId;
/*    */   }
/*    */ 
/*    */   public TaskAttemptID getTaskID() {
/* 44 */     return this.taskId;
/*    */   }
/*    */ 
/*    */   public void write(DataOutput out) throws IOException {
/* 48 */     this.taskId.write(out);
/*    */   }
/*    */ 
/*    */   public void readFields(DataInput in) throws IOException {
/* 52 */     this.taskId.readFields(in);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.CommitTaskAction
 * JD-Core Version:    0.6.1
 */
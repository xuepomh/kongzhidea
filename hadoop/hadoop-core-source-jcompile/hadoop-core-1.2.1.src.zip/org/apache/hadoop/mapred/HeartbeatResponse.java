/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.hadoop.conf.Configurable;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.WritableUtils;
/*     */ 
/*     */ class HeartbeatResponse
/*     */   implements Writable, Configurable
/*     */ {
/*  40 */   Configuration conf = null;
/*     */   short responseId;
/*     */   int heartbeatInterval;
/*     */   TaskTrackerAction[] actions;
/*  44 */   Set<JobID> recoveredJobs = new HashSet();
/*     */ 
/*     */   HeartbeatResponse() {
/*     */   }
/*     */   HeartbeatResponse(short responseId, TaskTrackerAction[] actions) {
/*  49 */     this.responseId = responseId;
/*  50 */     this.actions = actions;
/*  51 */     this.heartbeatInterval = 300;
/*     */   }
/*     */ 
/*     */   public void setResponseId(short responseId) {
/*  55 */     this.responseId = responseId;
/*     */   }
/*     */ 
/*     */   public short getResponseId() {
/*  59 */     return this.responseId;
/*     */   }
/*     */ 
/*     */   public void setRecoveredJobs(Set<JobID> ids) {
/*  63 */     this.recoveredJobs = ids;
/*     */   }
/*     */ 
/*     */   public Set<JobID> getRecoveredJobs() {
/*  67 */     return this.recoveredJobs;
/*     */   }
/*     */ 
/*     */   public void setActions(TaskTrackerAction[] actions) {
/*  71 */     this.actions = actions;
/*     */   }
/*     */ 
/*     */   public TaskTrackerAction[] getActions() {
/*  75 */     return this.actions;
/*     */   }
/*     */ 
/*     */   public void setConf(Configuration conf) {
/*  79 */     this.conf = conf;
/*     */   }
/*     */ 
/*     */   public Configuration getConf() {
/*  83 */     return this.conf;
/*     */   }
/*     */ 
/*     */   public void setHeartbeatInterval(int interval) {
/*  87 */     this.heartbeatInterval = interval;
/*     */   }
/*     */ 
/*     */   public int getHeartbeatInterval() {
/*  91 */     return this.heartbeatInterval;
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out) throws IOException {
/*  95 */     out.writeShort(this.responseId);
/*  96 */     out.writeInt(this.heartbeatInterval);
/*  97 */     if (this.actions == null) {
/*  98 */       WritableUtils.writeVInt(out, 0);
/*     */     } else {
/* 100 */       WritableUtils.writeVInt(out, this.actions.length);
/* 101 */       for (TaskTrackerAction action : this.actions) {
/* 102 */         WritableUtils.writeEnum(out, action.getActionId());
/* 103 */         action.write(out);
/*     */       }
/*     */     }
/*     */ 
/* 107 */     out.writeInt(this.recoveredJobs.size());
/* 108 */     for (JobID id : this.recoveredJobs)
/* 109 */       id.write(out);
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException
/*     */   {
/* 114 */     this.responseId = in.readShort();
/* 115 */     this.heartbeatInterval = in.readInt();
/* 116 */     int length = WritableUtils.readVInt(in);
/* 117 */     if (length > 0) {
/* 118 */       this.actions = new TaskTrackerAction[length];
/* 119 */       for (int i = 0; i < length; i++) {
/* 120 */         TaskTrackerAction.ActionType actionType = (TaskTrackerAction.ActionType)WritableUtils.readEnum(in, TaskTrackerAction.ActionType.class);
/*     */ 
/* 122 */         this.actions[i] = TaskTrackerAction.createAction(actionType);
/* 123 */         this.actions[i].readFields(in);
/*     */       }
/*     */     } else {
/* 126 */       this.actions = null;
/*     */     }
/*     */ 
/* 129 */     int size = in.readInt();
/* 130 */     for (int i = 0; i < size; i++) {
/* 131 */       JobID id = new JobID();
/* 132 */       id.readFields(in);
/* 133 */       this.recoveredJobs.add(id);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.HeartbeatResponse
 * JD-Core Version:    0.6.1
 */
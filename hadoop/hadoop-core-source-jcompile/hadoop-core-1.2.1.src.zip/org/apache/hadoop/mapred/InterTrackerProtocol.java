package org.apache.hadoop.mapred;

import java.io.IOException;
import org.apache.hadoop.ipc.VersionedProtocol;
import org.apache.hadoop.security.KerberosInfo;

@KerberosInfo(serverPrincipal="mapreduce.jobtracker.kerberos.principal", clientPrincipal="mapreduce.tasktracker.kerberos.principal")
abstract interface InterTrackerProtocol extends VersionedProtocol
{
  public static final long versionID = 31L;
  public static final int TRACKERS_OK = 0;
  public static final int UNKNOWN_TASKTRACKER = 1;

  public abstract HeartbeatResponse heartbeat(TaskTrackerStatus paramTaskTrackerStatus, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, short paramShort)
    throws IOException;

  public abstract String getFilesystemName()
    throws IOException;

  public abstract void reportTaskTrackerError(String paramString1, String paramString2, String paramString3)
    throws IOException;

  public abstract TaskCompletionEvent[] getTaskCompletionEvents(JobID paramJobID, int paramInt1, int paramInt2)
    throws IOException;

  public abstract String getSystemDir();

  public abstract String getBuildVersion()
    throws IOException;

  public abstract String getVIVersion()
    throws IOException;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.InterTrackerProtocol
 * JD-Core Version:    0.6.1
 */
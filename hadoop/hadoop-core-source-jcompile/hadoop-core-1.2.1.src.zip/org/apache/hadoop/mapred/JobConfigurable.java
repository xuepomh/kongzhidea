package org.apache.hadoop.mapred;

public abstract interface JobConfigurable
{
  public abstract void configure(JobConf paramJobConf);
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JobConfigurable
 * JD-Core Version:    0.6.1
 */
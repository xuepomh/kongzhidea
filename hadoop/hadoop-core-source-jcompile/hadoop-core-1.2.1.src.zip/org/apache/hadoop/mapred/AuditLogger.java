/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.net.InetAddress;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.ipc.Server;
/*     */ 
/*     */ class AuditLogger
/*     */ {
/*  30 */   private static final Log LOG = LogFactory.getLog(AuditLogger.class);
/*     */ 
/*     */   static String createSuccessLog(String user, String operation, String target)
/*     */   {
/*  64 */     StringBuilder b = new StringBuilder();
/*  65 */     start(Keys.USER, user, b);
/*  66 */     addRemoteIP(b);
/*  67 */     add(Keys.OPERATION, operation, b);
/*  68 */     add(Keys.TARGET, target, b);
/*  69 */     add(Keys.RESULT, "SUCCESS", b);
/*  70 */     return b.toString();
/*     */   }
/*     */ 
/*     */   static void logSuccess(String user, String operation, String target)
/*     */   {
/*  86 */     LOG.info(createSuccessLog(user, operation, target));
/*     */   }
/*     */ 
/*     */   static String createFailureLog(String user, String operation, String perm, String target, String description)
/*     */   {
/*  95 */     StringBuilder b = new StringBuilder();
/*  96 */     start(Keys.USER, user, b);
/*  97 */     addRemoteIP(b);
/*  98 */     add(Keys.OPERATION, operation, b);
/*  99 */     add(Keys.TARGET, target, b);
/* 100 */     add(Keys.RESULT, "FAILURE", b);
/* 101 */     add(Keys.DESCRIPTION, description, b);
/* 102 */     add(Keys.PERMISSIONS, perm, b);
/* 103 */     return b.toString();
/*     */   }
/*     */ 
/*     */   static void logFailure(String user, String operation, String perm, String target, String description)
/*     */   {
/* 123 */     LOG.warn(createFailureLog(user, operation, perm, target, description));
/*     */   }
/*     */ 
/*     */   static void addRemoteIP(StringBuilder b)
/*     */   {
/* 128 */     InetAddress ip = Server.getRemoteIp();
/*     */ 
/* 130 */     if (ip != null)
/* 131 */       add(Keys.IP, ip.getHostAddress(), b);
/*     */   }
/*     */ 
/*     */   static void start(Keys key, String value, StringBuilder b)
/*     */   {
/* 138 */     b.append(key.name()).append("=").append(value);
/*     */   }
/*     */ 
/*     */   static void add(Keys key, String value, StringBuilder b)
/*     */   {
/* 144 */     b.append('\t').append(key.name()).append("=").append(value);
/*     */   }
/*     */ 
/*     */   static class Constants
/*     */   {
/*     */     static final String SUCCESS = "SUCCESS";
/*     */     static final String FAILURE = "FAILURE";
/*     */     static final String KEY_VAL_SEPARATOR = "=";
/*     */     static final char PAIR_SEPARATOR = '\t';
/*     */     static final String JOBTRACKER = "JobTracker";
/*     */     static final String REFRESH_QUEUE = "REFRESH_QUEUE";
/*     */     static final String REFRESH_NODES = "REFRESH_NODES";
/*     */     static final String GET_SAFEMODE = "GET_SAFEMODE";
/*     */     static final String SET_SAFEMODE = "SET_SAFEMODE";
/*     */     static final String UNAUTHORIZED_USER = "Unauthorized user";
/*     */   }
/*     */ 
/*     */   static enum Keys
/*     */   {
/*  33 */     USER, OPERATION, TARGET, RESULT, IP, PERMISSIONS, 
/*  34 */     DESCRIPTION;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.AuditLogger
 * JD-Core Version:    0.6.1
 */
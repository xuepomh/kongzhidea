/*    */ package org.apache.hadoop.mapred;
/*    */ 
/*    */ public enum JobPriority
/*    */ {
/* 26 */   VERY_HIGH, 
/* 27 */   HIGH, 
/* 28 */   NORMAL, 
/* 29 */   LOW, 
/* 30 */   VERY_LOW;
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JobPriority
 * JD-Core Version:    0.6.1
 */
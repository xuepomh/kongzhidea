/*    */ package org.apache.hadoop.mapred;
/*    */ 
/*    */ import java.io.DataInput;
/*    */ import java.io.DataOutput;
/*    */ import java.io.IOException;
/*    */ import org.apache.hadoop.fs.Path;
/*    */ import org.apache.hadoop.io.UTF8;
/*    */ 
/*    */ public class FileSplit extends org.apache.hadoop.mapreduce.InputSplit
/*    */   implements InputSplit
/*    */ {
/*    */   private Path file;
/*    */   private long start;
/*    */   private long length;
/*    */   private String[] hosts;
/*    */ 
/*    */   FileSplit()
/*    */   {
/*    */   }
/*    */ 
/*    */   @Deprecated
/*    */   public FileSplit(Path file, long start, long length, JobConf conf)
/*    */   {
/* 49 */     this(file, start, length, (String[])null);
/*    */   }
/*    */ 
/*    */   public FileSplit(Path file, long start, long length, String[] hosts)
/*    */   {
/* 60 */     this.file = file;
/* 61 */     this.start = start;
/* 62 */     this.length = length;
/* 63 */     this.hosts = hosts;
/*    */   }
/*    */ 
/*    */   public Path getPath() {
/* 67 */     return this.file;
/*    */   }
/*    */   public long getStart() {
/* 70 */     return this.start;
/*    */   }
/*    */   public long getLength() {
/* 73 */     return this.length;
/*    */   }
/* 75 */   public String toString() { return this.file + ":" + this.start + "+" + this.length; }
/*    */ 
/*    */ 
/*    */   public void write(DataOutput out)
/*    */     throws IOException
/*    */   {
/* 82 */     UTF8.writeString(out, this.file.toString());
/* 83 */     out.writeLong(this.start);
/* 84 */     out.writeLong(this.length);
/*    */   }
/*    */   public void readFields(DataInput in) throws IOException {
/* 87 */     this.file = new Path(UTF8.readString(in));
/* 88 */     this.start = in.readLong();
/* 89 */     this.length = in.readLong();
/* 90 */     this.hosts = null;
/*    */   }
/*    */ 
/*    */   public String[] getLocations() throws IOException {
/* 94 */     if (this.hosts == null) {
/* 95 */       return new String[0];
/*    */     }
/* 97 */     return this.hosts;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.FileSplit
 * JD-Core Version:    0.6.1
 */
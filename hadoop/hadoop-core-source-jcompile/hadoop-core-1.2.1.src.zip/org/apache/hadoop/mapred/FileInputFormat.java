/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.fs.BlockLocation;
/*     */ import org.apache.hadoop.fs.FileStatus;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.fs.PathFilter;
/*     */ import org.apache.hadoop.mapreduce.security.TokenCache;
/*     */ import org.apache.hadoop.net.NetworkTopology;
/*     */ import org.apache.hadoop.net.Node;
/*     */ import org.apache.hadoop.net.NodeBase;
/*     */ import org.apache.hadoop.util.ReflectionUtils;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ public abstract class FileInputFormat<K, V>
/*     */   implements InputFormat<K, V>
/*     */ {
/*  58 */   public static final Log LOG = LogFactory.getLog(FileInputFormat.class);
/*     */   private static final double SPLIT_SLOP = 1.1D;
/*     */   private long minSplitSize;
/*  67 */   private static final PathFilter hiddenFileFilter = new PathFilter() {
/*     */     public boolean accept(Path p) {
/*  69 */       String name = p.getName();
/*  70 */       return (!name.startsWith("_")) && (!name.startsWith("."));
/*     */     }
/*  67 */   };
/*     */   static final String NUM_INPUT_FILES = "mapreduce.input.num.files";
/*     */ 
/*     */   public FileInputFormat()
/*     */   {
/*  66 */     this.minSplitSize = 1L;
/*     */   }
/*     */ 
/*     */   protected void setMinSplitSize(long minSplitSize)
/*     */   {
/*  77 */     this.minSplitSize = minSplitSize;
/*     */   }
/*     */ 
/*     */   protected boolean isSplitable(FileSystem fs, Path filename)
/*     */   {
/* 115 */     return true;
/*     */   }
/*     */ 
/*     */   public abstract RecordReader<K, V> getRecordReader(InputSplit paramInputSplit, JobConf paramJobConf, Reporter paramReporter)
/*     */     throws IOException;
/*     */ 
/*     */   public static void setInputPathFilter(JobConf conf, Class<? extends PathFilter> filter)
/*     */   {
/* 130 */     conf.setClass("mapred.input.pathFilter.class", filter, PathFilter.class);
/*     */   }
/*     */ 
/*     */   public static PathFilter getInputPathFilter(JobConf conf)
/*     */   {
/* 139 */     Class filterClass = conf.getClass("mapred.input.pathFilter.class", null, PathFilter.class);
/*     */ 
/* 141 */     return filterClass != null ? (PathFilter)ReflectionUtils.newInstance(filterClass, conf) : null;
/*     */   }
/*     */ 
/*     */   protected FileStatus[] listStatus(JobConf job)
/*     */     throws IOException
/*     */   {
/* 154 */     Path[] dirs = getInputPaths(job);
/* 155 */     if (dirs.length == 0) {
/* 156 */       throw new IOException("No input paths specified in job");
/*     */     }
/*     */ 
/* 160 */     TokenCache.obtainTokensForNamenodes(job.getCredentials(), dirs, job);
/*     */ 
/* 162 */     List result = new ArrayList();
/* 163 */     List errors = new ArrayList();
/*     */ 
/* 167 */     List filters = new ArrayList();
/* 168 */     filters.add(hiddenFileFilter);
/* 169 */     PathFilter jobFilter = getInputPathFilter(job);
/* 170 */     if (jobFilter != null) {
/* 171 */       filters.add(jobFilter);
/*     */     }
/* 173 */     PathFilter inputFilter = new MultiPathFilter(filters);
/*     */ 
/* 175 */     for (Path p : dirs) {
/* 176 */       FileSystem fs = p.getFileSystem(job);
/* 177 */       FileStatus[] matches = fs.globStatus(p, inputFilter);
/* 178 */       if (matches == null)
/* 179 */         errors.add(new IOException("Input path does not exist: " + p));
/* 180 */       else if (matches.length == 0)
/* 181 */         errors.add(new IOException("Input Pattern " + p + " matches 0 files"));
/*     */       else {
/* 183 */         for (FileStatus globStat : matches) {
/* 184 */           if (globStat.isDir())
/* 185 */             for (FileStatus stat : fs.listStatus(globStat.getPath(), inputFilter))
/*     */             {
/* 187 */               result.add(stat);
/*     */             }
/*     */           else {
/* 190 */             result.add(globStat);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 196 */     if (!errors.isEmpty()) {
/* 197 */       throw new InvalidInputException(errors);
/*     */     }
/* 199 */     LOG.info("Total input paths to process : " + result.size());
/* 200 */     return (FileStatus[])result.toArray(new FileStatus[result.size()]);
/*     */   }
/*     */ 
/*     */   public InputSplit[] getSplits(JobConf job, int numSplits)
/*     */     throws IOException
/*     */   {
/* 208 */     FileStatus[] files = listStatus(job);
/*     */ 
/* 211 */     job.setLong("mapreduce.input.num.files", files.length);
/* 212 */     long totalSize = 0L;
/* 213 */     for (FileStatus file : files) {
/* 214 */       if (file.isDir()) {
/* 215 */         throw new IOException("Not a file: " + file.getPath());
/*     */       }
/* 217 */       totalSize += file.getLen();
/*     */     }
/*     */ 
/* 220 */     long goalSize = totalSize / numSplits == 0 ? 1 : numSplits;
/* 221 */     long minSize = Math.max(job.getLong("mapred.min.split.size", 1L), this.minSplitSize);
/*     */ 
/* 225 */     ArrayList splits = new ArrayList(numSplits);
/* 226 */     NetworkTopology clusterMap = new NetworkTopology();
/* 227 */     for (FileStatus file : files) {
/* 228 */       Path path = file.getPath();
/* 229 */       FileSystem fs = path.getFileSystem(job);
/* 230 */       long length = file.getLen();
/* 231 */       BlockLocation[] blkLocations = fs.getFileBlockLocations(file, 0L, length);
/* 232 */       if ((length != 0L) && (isSplitable(fs, path))) {
/* 233 */         long blockSize = file.getBlockSize();
/* 234 */         long splitSize = computeSplitSize(goalSize, minSize, blockSize);
/*     */ 
/* 236 */         long bytesRemaining = length;
/* 237 */         while (bytesRemaining / splitSize > 1.1D) {
/* 238 */           String[] splitHosts = getSplitHosts(blkLocations, length - bytesRemaining, splitSize, clusterMap);
/*     */ 
/* 240 */           splits.add(new FileSplit(path, length - bytesRemaining, splitSize, splitHosts));
/*     */ 
/* 242 */           bytesRemaining -= splitSize;
/*     */         }
/*     */ 
/* 245 */         if (bytesRemaining != 0L) {
/* 246 */           splits.add(new FileSplit(path, length - bytesRemaining, bytesRemaining, blkLocations[(blkLocations.length - 1)].getHosts()));
/*     */         }
/*     */       }
/* 249 */       else if (length != 0L) {
/* 250 */         String[] splitHosts = getSplitHosts(blkLocations, 0L, length, clusterMap);
/* 251 */         splits.add(new FileSplit(path, 0L, length, splitHosts));
/*     */       }
/*     */       else {
/* 254 */         splits.add(new FileSplit(path, 0L, length, new String[0]));
/*     */       }
/*     */     }
/* 257 */     LOG.debug("Total # of splits: " + splits.size());
/* 258 */     return (InputSplit[])splits.toArray(new FileSplit[splits.size()]);
/*     */   }
/*     */ 
/*     */   protected long computeSplitSize(long goalSize, long minSize, long blockSize)
/*     */   {
/* 263 */     return Math.max(minSize, Math.min(goalSize, blockSize));
/*     */   }
/*     */ 
/*     */   protected int getBlockIndex(BlockLocation[] blkLocations, long offset)
/*     */   {
/* 268 */     for (int i = 0; i < blkLocations.length; i++)
/*     */     {
/* 270 */       if ((blkLocations[i].getOffset() <= offset) && (offset < blkLocations[i].getOffset() + blkLocations[i].getLength()))
/*     */       {
/* 272 */         return i;
/*     */       }
/*     */     }
/* 275 */     BlockLocation last = blkLocations[(blkLocations.length - 1)];
/* 276 */     long fileLength = last.getOffset() + last.getLength() - 1L;
/* 277 */     throw new IllegalArgumentException("Offset " + offset + " is outside of file (0.." + fileLength + ")");
/*     */   }
/*     */ 
/*     */   public static void setInputPaths(JobConf conf, String commaSeparatedPaths)
/*     */   {
/* 291 */     setInputPaths(conf, StringUtils.stringToPath(getPathStrings(commaSeparatedPaths)));
/*     */   }
/*     */ 
/*     */   public static void addInputPaths(JobConf conf, String commaSeparatedPaths)
/*     */   {
/* 304 */     for (String str : getPathStrings(commaSeparatedPaths))
/* 305 */       addInputPath(conf, new Path(str));
/*     */   }
/*     */ 
/*     */   public static void setInputPaths(JobConf conf, Path[] inputPaths)
/*     */   {
/* 318 */     Path path = new Path(conf.getWorkingDirectory(), inputPaths[0]);
/* 319 */     StringBuffer str = new StringBuffer(StringUtils.escapeString(path.toString()));
/* 320 */     for (int i = 1; i < inputPaths.length; i++) {
/* 321 */       str.append(",");
/* 322 */       path = new Path(conf.getWorkingDirectory(), inputPaths[i]);
/* 323 */       str.append(StringUtils.escapeString(path.toString()));
/*     */     }
/* 325 */     conf.set("mapred.input.dir", str.toString());
/*     */   }
/*     */ 
/*     */   public static void addInputPath(JobConf conf, Path path)
/*     */   {
/* 336 */     path = new Path(conf.getWorkingDirectory(), path);
/* 337 */     String dirStr = StringUtils.escapeString(path.toString());
/* 338 */     String dirs = conf.get("mapred.input.dir");
/* 339 */     conf.set("mapred.input.dir", dirs + "," + dirStr);
/*     */   }
/*     */ 
/*     */   private static String[] getPathStrings(String commaSeparatedPaths)
/*     */   {
/* 345 */     int length = commaSeparatedPaths.length();
/* 346 */     int curlyOpen = 0;
/* 347 */     int pathStart = 0;
/* 348 */     boolean globPattern = false;
/* 349 */     List pathStrings = new ArrayList();
/*     */ 
/* 351 */     for (int i = 0; i < length; i++) {
/* 352 */       char ch = commaSeparatedPaths.charAt(i);
/* 353 */       switch (ch) {
/*     */       case '{':
/* 355 */         curlyOpen++;
/* 356 */         if (!globPattern)
/* 357 */           globPattern = true; break;
/*     */       case '}':
/* 362 */         curlyOpen--;
/* 363 */         if ((curlyOpen == 0) && (globPattern))
/* 364 */           globPattern = false; break;
/*     */       case ',':
/* 369 */         if (!globPattern) {
/* 370 */           pathStrings.add(commaSeparatedPaths.substring(pathStart, i));
/* 371 */           pathStart = i + 1;
/*     */         }
/*     */         break;
/*     */       }
/*     */     }
/*     */ 
/* 377 */     pathStrings.add(commaSeparatedPaths.substring(pathStart, length));
/*     */ 
/* 379 */     return (String[])pathStrings.toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   public static Path[] getInputPaths(JobConf conf)
/*     */   {
/* 389 */     String dirs = conf.get("mapred.input.dir", "");
/* 390 */     String[] list = StringUtils.split(dirs);
/* 391 */     Path[] result = new Path[list.length];
/* 392 */     for (int i = 0; i < list.length; i++) {
/* 393 */       result[i] = new Path(StringUtils.unEscapeString(list[i]));
/*     */     }
/* 395 */     return result;
/*     */   }
/*     */ 
/*     */   private void sortInDescendingOrder(List<NodeInfo> mylist)
/*     */   {
/* 400 */     Collections.sort(mylist, new Comparator()
/*     */     {
/*     */       public int compare(FileInputFormat.NodeInfo obj1, FileInputFormat.NodeInfo obj2) {
/* 403 */         if ((obj1 == null) || (obj2 == null)) {
/* 404 */           return -1;
/*     */         }
/* 406 */         if (obj1.getValue() == obj2.getValue()) {
/* 407 */           return 0;
/*     */         }
/*     */ 
/* 410 */         return obj1.getValue() < obj2.getValue() ? 1 : -1;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   protected String[] getSplitHosts(BlockLocation[] blkLocations, long offset, long splitSize, NetworkTopology clusterMap)
/*     */     throws IOException
/*     */   {
/* 433 */     int startIndex = getBlockIndex(blkLocations, offset);
/*     */ 
/* 435 */     long bytesInThisBlock = blkLocations[startIndex].getOffset() + blkLocations[startIndex].getLength() - offset;
/*     */ 
/* 439 */     if (bytesInThisBlock >= splitSize) {
/* 440 */       return blkLocations[startIndex].getHosts();
/*     */     }
/*     */ 
/* 443 */     long bytesInFirstBlock = bytesInThisBlock;
/* 444 */     int index = startIndex + 1;
/* 445 */     splitSize -= bytesInThisBlock;
/*     */ 
/* 447 */     while (splitSize > 0L) {
/* 448 */       bytesInThisBlock = Math.min(splitSize, blkLocations[(index++)].getLength());
/*     */ 
/* 450 */       splitSize -= bytesInThisBlock;
/*     */     }
/*     */ 
/* 453 */     long bytesInLastBlock = bytesInThisBlock;
/* 454 */     int endIndex = index - 1;
/*     */ 
/* 456 */     Map hostsMap = new IdentityHashMap();
/* 457 */     Map racksMap = new IdentityHashMap();
/* 458 */     String[] allTopos = new String[0];
/*     */ 
/* 463 */     for (index = startIndex; index <= endIndex; index++)
/*     */     {
/* 466 */       if (index == startIndex) {
/* 467 */         bytesInThisBlock = bytesInFirstBlock;
/*     */       }
/* 469 */       else if (index == endIndex) {
/* 470 */         bytesInThisBlock = bytesInLastBlock;
/*     */       }
/*     */       else {
/* 473 */         bytesInThisBlock = blkLocations[index].getLength();
/*     */       }
/*     */ 
/* 476 */       allTopos = blkLocations[index].getTopologyPaths();
/*     */ 
/* 480 */       if (allTopos.length == 0) {
/* 481 */         allTopos = fakeRacks(blkLocations, index);
/*     */       }
/*     */ 
/* 489 */       for (String topo : allTopos)
/*     */       {
/* 494 */         Node node = clusterMap.getNode(topo);
/*     */ 
/* 496 */         if (node == null) {
/* 497 */           node = new NodeBase(topo);
/* 498 */           clusterMap.add(node);
/*     */         }
/*     */ 
/* 501 */         NodeInfo nodeInfo = (NodeInfo)hostsMap.get(node);
/*     */         NodeInfo parentNodeInfo;
/* 503 */         if (nodeInfo == null) {
/* 504 */           nodeInfo = new NodeInfo(node);
/* 505 */           hostsMap.put(node, nodeInfo);
/* 506 */           Node parentNode = node.getParent();
/* 507 */           NodeInfo parentNodeInfo = (NodeInfo)racksMap.get(parentNode);
/* 508 */           if (parentNodeInfo == null) {
/* 509 */             parentNodeInfo = new NodeInfo(parentNode);
/* 510 */             racksMap.put(parentNode, parentNodeInfo);
/*     */           }
/* 512 */           parentNodeInfo.addLeaf(nodeInfo);
/*     */         }
/*     */         else {
/* 515 */           nodeInfo = (NodeInfo)hostsMap.get(node);
/* 516 */           Node parentNode = node.getParent();
/* 517 */           parentNodeInfo = (NodeInfo)racksMap.get(parentNode);
/*     */         }
/*     */ 
/* 520 */         nodeInfo.addValue(index, bytesInThisBlock);
/* 521 */         parentNodeInfo.addValue(index, bytesInThisBlock);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 527 */     return identifyHosts(allTopos.length, racksMap);
/*     */   }
/*     */ 
/*     */   private String[] identifyHosts(int replicationFactor, Map<Node, NodeInfo> racksMap)
/*     */   {
/* 533 */     String[] retVal = new String[replicationFactor];
/*     */ 
/* 535 */     List rackList = new LinkedList();
/*     */ 
/* 537 */     rackList.addAll(racksMap.values());
/*     */ 
/* 540 */     sortInDescendingOrder(rackList);
/*     */ 
/* 542 */     boolean done = false;
/* 543 */     int index = 0;
/*     */ 
/* 547 */     for (NodeInfo ni : rackList)
/*     */     {
/* 549 */       Set hostSet = ni.getLeaves();
/*     */ 
/* 551 */       List hostList = new LinkedList();
/* 552 */       hostList.addAll(hostSet);
/*     */ 
/* 555 */       sortInDescendingOrder(hostList);
/*     */ 
/* 557 */       for (NodeInfo host : hostList)
/*     */       {
/* 559 */         retVal[(index++)] = host.node.getName().split(":")[0];
/* 560 */         if (index == replicationFactor) {
/* 561 */           done = true;
/* 562 */           break;
/*     */         }
/*     */       }
/*     */ 
/* 566 */       if (done == true) {
/*     */         break;
/*     */       }
/*     */     }
/* 570 */     return retVal;
/*     */   }
/*     */ 
/*     */   private String[] fakeRacks(BlockLocation[] blkLocations, int index) throws IOException
/*     */   {
/* 575 */     String[] allHosts = blkLocations[index].getHosts();
/* 576 */     String[] allTopos = new String[allHosts.length];
/* 577 */     for (int i = 0; i < allHosts.length; i++) {
/* 578 */       allTopos[i] = ("/default-rack/" + allHosts[i]);
/*     */     }
/* 580 */     return allTopos;
/*     */   }
/*     */   private static class NodeInfo {
/*     */     final Node node;
/*     */     final Set<Integer> blockIds;
/*     */     final Set<NodeInfo> leaves;
/*     */     private long value;
/*     */ 
/*     */     NodeInfo(Node node) {
/* 592 */       this.node = node;
/* 593 */       this.blockIds = new HashSet();
/* 594 */       this.leaves = new HashSet();
/*     */     }
/*     */     long getValue() {
/* 597 */       return this.value;
/*     */     }
/*     */     void addValue(int blockIndex, long value) {
/* 600 */       if (this.blockIds.add(Integer.valueOf(blockIndex)) == true)
/* 601 */         this.value += value;
/*     */     }
/*     */ 
/*     */     Set<NodeInfo> getLeaves() {
/* 605 */       return this.leaves;
/*     */     }
/*     */     void addLeaf(NodeInfo nodeInfo) {
/* 608 */       this.leaves.add(nodeInfo);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class MultiPathFilter
/*     */     implements PathFilter
/*     */   {
/*     */     private List<PathFilter> filters;
/*     */ 
/*     */     public MultiPathFilter(List<PathFilter> filters)
/*     */     {
/*  89 */       this.filters = filters;
/*     */     }
/*     */ 
/*     */     public boolean accept(Path path) {
/*  93 */       for (PathFilter filter : this.filters) {
/*  94 */         if (!filter.accept(path)) {
/*  95 */           return false;
/*     */         }
/*     */       }
/*  98 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static enum Counter
/*     */   {
/*  61 */     BYTES_READ;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.FileInputFormat
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.mapred;
/*    */ 
/*    */ abstract class JobChangeEvent
/*    */ {
/*    */   private JobInProgress jip;
/*    */ 
/*    */   JobChangeEvent(JobInProgress jip)
/*    */   {
/* 28 */     this.jip = jip;
/*    */   }
/*    */ 
/*    */   JobInProgress getJobInProgress()
/*    */   {
/* 35 */     return this.jip;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JobChangeEvent
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.mapred;
/*    */ 
/*    */ import java.util.LinkedHashMap;
/*    */ import org.mortbay.util.ajax.JSON;
/*    */ 
/*    */ class InfoMap extends LinkedHashMap<String, Object>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   String toJson()
/*    */   {
/* 29 */     return JSON.toString(this);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.InfoMap
 * JD-Core Version:    0.6.1
 */
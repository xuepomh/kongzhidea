/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ class JobQueueJobInProgressListener extends JobInProgressListener
/*     */ {
/*  81 */   static final Comparator<JobSchedulingInfo> FIFO_JOB_QUEUE_COMPARATOR = new Comparator()
/*     */   {
/*     */     public int compare(JobQueueJobInProgressListener.JobSchedulingInfo o1, JobQueueJobInProgressListener.JobSchedulingInfo o2) {
/*  84 */       int res = o1.getPriority().compareTo(o2.getPriority());
/*  85 */       if (res == 0) {
/*  86 */         if (o1.getStartTime() < o2.getStartTime())
/*  87 */           res = -1;
/*     */         else {
/*  89 */           res = o1.getStartTime() == o2.getStartTime() ? 0 : 1;
/*     */         }
/*     */       }
/*  92 */       if (res == 0) {
/*  93 */         res = o1.getJobID().compareTo(o2.getJobID());
/*     */       }
/*  95 */       return res;
/*     */     }
/*  81 */   };
/*     */   private Map<JobSchedulingInfo, JobInProgress> jobQueue;
/*     */ 
/*     */   public JobQueueJobInProgressListener() {
/* 102 */     this(new TreeMap(FIFO_JOB_QUEUE_COMPARATOR));
/*     */   }
/*     */ 
/*     */   protected JobQueueJobInProgressListener(Map<JobSchedulingInfo, JobInProgress> jobQueue)
/*     */   {
/* 112 */     this.jobQueue = Collections.synchronizedMap(jobQueue);
/*     */   }
/*     */ 
/*     */   public Collection<JobInProgress> getJobQueue()
/*     */   {
/* 119 */     return this.jobQueue.values();
/*     */   }
/*     */ 
/*     */   public void jobAdded(JobInProgress job)
/*     */   {
/* 124 */     this.jobQueue.put(new JobSchedulingInfo(job.getStatus()), job);
/*     */   }
/*     */ 
/*     */   public void jobRemoved(JobInProgress job)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void jobCompleted(JobSchedulingInfo oldInfo) {
/* 132 */     this.jobQueue.remove(oldInfo);
/*     */   }
/*     */ 
/*     */   public synchronized void jobUpdated(JobChangeEvent event)
/*     */   {
/* 137 */     JobInProgress job = event.getJobInProgress();
/* 138 */     if ((event instanceof JobStatusChangeEvent))
/*     */     {
/* 141 */       JobStatusChangeEvent statusEvent = (JobStatusChangeEvent)event;
/* 142 */       JobSchedulingInfo oldInfo = new JobSchedulingInfo(statusEvent.getOldStatus());
/*     */ 
/* 144 */       if ((statusEvent.getEventType() == JobStatusChangeEvent.EventType.PRIORITY_CHANGED) || (statusEvent.getEventType() == JobStatusChangeEvent.EventType.START_TIME_CHANGED))
/*     */       {
/* 147 */         reorderJobs(job, oldInfo);
/* 148 */       } else if (statusEvent.getEventType() == JobStatusChangeEvent.EventType.RUN_STATE_CHANGED)
/*     */       {
/* 150 */         int runState = statusEvent.getNewStatus().getRunState();
/* 151 */         if ((runState == 2) || (runState == 3) || (runState == 5))
/*     */         {
/* 154 */           jobCompleted(oldInfo);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void reorderJobs(JobInProgress job, JobSchedulingInfo oldInfo) {
/* 161 */     synchronized (this.jobQueue) {
/* 162 */       this.jobQueue.remove(oldInfo);
/* 163 */       this.jobQueue.put(new JobSchedulingInfo(job), job);
/*     */     }
/*     */   }
/*     */ 
/*     */   static class JobSchedulingInfo
/*     */   {
/*     */     private JobPriority priority;
/*     */     private long startTime;
/*     */     private JobID id;
/*     */ 
/*     */     public JobSchedulingInfo(JobInProgress jip)
/*     */     {
/*  45 */       this(jip.getStatus());
/*     */     }
/*     */ 
/*     */     public JobSchedulingInfo(JobStatus status) {
/*  49 */       this.priority = status.getJobPriority();
/*  50 */       this.startTime = status.getStartTime();
/*  51 */       this.id = status.getJobID();
/*     */     }
/*     */     JobPriority getPriority() {
/*  54 */       return this.priority; } 
/*  55 */     long getStartTime() { return this.startTime; } 
/*  56 */     JobID getJobID() { return this.id; }
/*     */ 
/*     */     public boolean equals(Object obj)
/*     */     {
/*  60 */       if ((obj == null) || (obj.getClass() != JobSchedulingInfo.class))
/*  61 */         return false;
/*  62 */       if (obj == this) {
/*  63 */         return true;
/*     */       }
/*  65 */       if ((obj instanceof JobSchedulingInfo)) {
/*  66 */         JobSchedulingInfo that = (JobSchedulingInfo)obj;
/*  67 */         return (this.id.equals(that.id)) && (this.startTime == that.startTime) && (this.priority == that.priority);
/*     */       }
/*     */ 
/*  71 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/*  76 */       return (int)(this.id.hashCode() * this.priority.hashCode() + this.startTime);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JobQueueJobInProgressListener
 * JD-Core Version:    0.6.1
 */
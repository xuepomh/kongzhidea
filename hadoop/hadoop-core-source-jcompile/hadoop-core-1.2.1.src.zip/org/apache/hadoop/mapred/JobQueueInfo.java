/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.apache.hadoop.io.Text;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ 
/*     */ public class JobQueueInfo
/*     */   implements Writable
/*     */ {
/*     */   static final String EMPTY_INFO = "N/A";
/*  40 */   private String queueName = "";
/*  41 */   private String queueState = Queue.QueueState.RUNNING.getStateName();
/*     */ 
/*  44 */   private String schedulingInfo = "N/A";
/*     */ 
/*     */   public JobQueueInfo()
/*     */   {
/*     */   }
/*     */ 
/*     */   public JobQueueInfo(String queueName, String schedulingInfo)
/*     */   {
/*  57 */     this.queueName = queueName;
/*  58 */     this.schedulingInfo = schedulingInfo;
/*     */   }
/*     */ 
/*     */   public void setQueueName(String queueName)
/*     */   {
/*  68 */     this.queueName = queueName;
/*     */   }
/*     */ 
/*     */   public String getQueueName()
/*     */   {
/*  77 */     return this.queueName;
/*     */   }
/*     */ 
/*     */   public void setSchedulingInfo(String schedulingInfo)
/*     */   {
/*  86 */     this.schedulingInfo = (schedulingInfo != null ? schedulingInfo : "N/A");
/*     */   }
/*     */ 
/*     */   public String getSchedulingInfo()
/*     */   {
/*  98 */     return this.schedulingInfo;
/*     */   }
/*     */ 
/*     */   public void setQueueState(String state)
/*     */   {
/* 106 */     this.queueState = state;
/*     */   }
/*     */ 
/*     */   public String getQueueState()
/*     */   {
/* 114 */     return this.queueState;
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException
/*     */   {
/* 119 */     this.queueName = Text.readString(in);
/* 120 */     this.queueState = Text.readString(in);
/* 121 */     this.schedulingInfo = Text.readString(in);
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out) throws IOException
/*     */   {
/* 126 */     Text.writeString(out, this.queueName);
/* 127 */     Text.writeString(out, this.queueState);
/* 128 */     Text.writeString(out, this.schedulingInfo);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JobQueueInfo
 * JD-Core Version:    0.6.1
 */
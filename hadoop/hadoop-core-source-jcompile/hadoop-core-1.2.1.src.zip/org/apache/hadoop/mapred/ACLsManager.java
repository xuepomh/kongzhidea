/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.security.AccessControlException;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.authorize.AccessControlList;
/*     */ 
/*     */ class ACLsManager
/*     */ {
/*     */   private final UserGroupInformation mrOwner;
/*     */   private final AccessControlList adminAcl;
/*     */   private final JobACLsManager jobACLsManager;
/*     */   private final QueueManager queueManager;
/*     */   private final boolean aclsEnabled;
/*     */ 
/*     */   ACLsManager(Configuration conf, JobACLsManager jobACLsManager, QueueManager queueManager)
/*     */     throws IOException
/*     */   {
/*  49 */     if (UserGroupInformation.isLoginKeytabBased())
/*  50 */       this.mrOwner = UserGroupInformation.getLoginUser();
/*     */     else {
/*  52 */       this.mrOwner = UserGroupInformation.getCurrentUser();
/*     */     }
/*     */ 
/*  55 */     this.aclsEnabled = conf.getBoolean("mapred.acls.enabled", false);
/*     */ 
/*  57 */     this.adminAcl = new AccessControlList(conf.get("mapreduce.cluster.administrators", " "));
/*  58 */     this.adminAcl.addUser(this.mrOwner.getShortUserName());
/*     */ 
/*  60 */     this.jobACLsManager = jobACLsManager;
/*     */ 
/*  62 */     this.queueManager = queueManager;
/*     */   }
/*     */ 
/*     */   UserGroupInformation getMROwner() {
/*  66 */     return this.mrOwner;
/*     */   }
/*     */ 
/*     */   AccessControlList getAdminsAcl() {
/*  70 */     return this.adminAcl;
/*     */   }
/*     */ 
/*     */   JobACLsManager getJobACLsManager() {
/*  74 */     return this.jobACLsManager;
/*     */   }
/*     */ 
/*     */   boolean isMRAdmin(UserGroupInformation callerUGI)
/*     */   {
/*  83 */     if (this.adminAcl.isUserAllowed(callerUGI)) {
/*  84 */       return true;
/*     */     }
/*  86 */     return false;
/*     */   }
/*     */ 
/*     */   void checkAccess(JobInProgress job, UserGroupInformation callerUGI, Operation operation)
/*     */     throws AccessControlException
/*     */   {
/* 110 */     String queue = job.getProfile().getQueueName();
/* 111 */     JobStatus jobStatus = job.getStatus();
/*     */ 
/* 113 */     checkAccess(jobStatus, callerUGI, queue, operation);
/*     */   }
/*     */ 
/*     */   void checkAccess(JobStatus jobStatus, UserGroupInformation callerUGI, String queue, Operation operation)
/*     */     throws AccessControlException
/*     */   {
/* 129 */     String jobId = jobStatus.getJobID().toString();
/* 130 */     String jobOwner = jobStatus.getUsername();
/* 131 */     AccessControlList jobAcl = (AccessControlList)jobStatus.getJobACLs().get(operation.jobACLNeeded);
/*     */ 
/* 136 */     checkAccess(jobId, callerUGI, queue, operation, jobOwner, jobAcl);
/*     */   }
/*     */ 
/*     */   void checkAccess(String jobId, UserGroupInformation callerUGI, String queue, Operation operation, String jobOwner, AccessControlList jobAcl)
/*     */     throws AccessControlException
/*     */   {
/* 158 */     if (!this.aclsEnabled) {
/* 159 */       return;
/*     */     }
/*     */ 
/* 162 */     String user = callerUGI.getShortUserName();
/* 163 */     String targetResource = jobId + " in queue " + queue;
/*     */ 
/* 167 */     if (isMRAdmin(callerUGI)) {
/* 168 */       AuditLogger.logSuccess(user, operation.name(), targetResource);
/* 169 */       return;
/*     */     }
/*     */ 
/* 172 */     if (operation == Operation.SUBMIT_JOB)
/*     */     {
/* 174 */       if (!this.queueManager.hasAccess(queue, operation.qACLNeeded, callerUGI)) {
/* 175 */         AuditLogger.logFailure(user, operation.name(), this.queueManager.getQueueACL(queue, operation.qACLNeeded).toString(), targetResource, "Unauthorized user");
/*     */ 
/* 179 */         throw new AccessControlException("User " + callerUGI.getShortUserName() + " cannot perform " + "operation " + operation.name() + " on queue " + queue + ".\n Please run \"hadoop queue -showacls\" " + "command to find the queues you have access to .");
/*     */       }
/*     */ 
/* 185 */       AuditLogger.logSuccess(user, operation.name(), targetResource);
/* 186 */       return;
/*     */     }
/*     */ 
/* 195 */     if (operation == Operation.VIEW_TASK_LOGS) {
/* 196 */       if (this.jobACLsManager.checkAccess(callerUGI, operation.jobACLNeeded, jobOwner, jobAcl))
/*     */       {
/* 198 */         AuditLogger.logSuccess(user, operation.name(), targetResource);
/*     */       }
/*     */     }
/* 201 */     else if ((this.queueManager.hasAccess(queue, operation.qACLNeeded, callerUGI)) || (this.jobACLsManager.checkAccess(callerUGI, operation.jobACLNeeded, jobOwner, jobAcl)))
/*     */     {
/* 204 */       AuditLogger.logSuccess(user, operation.name(), targetResource);
/* 205 */       return;
/*     */     }
/*     */ 
/* 208 */     AuditLogger.logFailure(user, operation.name(), jobAcl.toString(), targetResource, "Unauthorized user");
/*     */ 
/* 211 */     throw new AccessControlException("User " + callerUGI.getShortUserName() + " cannot perform operation " + operation.name() + " on " + jobId + " that is in the queue " + queue);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.ACLsManager
 * JD-Core Version:    0.6.1
 */
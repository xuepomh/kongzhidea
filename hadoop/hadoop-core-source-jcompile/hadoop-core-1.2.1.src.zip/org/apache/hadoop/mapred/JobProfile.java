/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import org.apache.hadoop.io.Text;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.WritableFactories;
/*     */ import org.apache.hadoop.io.WritableFactory;
/*     */ 
/*     */ public class JobProfile
/*     */   implements Writable
/*     */ {
/*     */   String user;
/*     */   final JobID jobid;
/*     */   String jobFile;
/*     */   String url;
/*     */   String name;
/*     */   String queueName;
/*     */ 
/*     */   public JobProfile()
/*     */   {
/*  56 */     this.jobid = new JobID();
/*     */   }
/*     */ 
/*     */   public JobProfile(String user, org.apache.hadoop.mapreduce.JobID jobid, String jobFile, String url, String name)
/*     */   {
/*  72 */     this(user, jobid, jobFile, url, name, "default");
/*     */   }
/*     */ 
/*     */   public JobProfile(String user, org.apache.hadoop.mapreduce.JobID jobid, String jobFile, String url, String name, String queueName)
/*     */   {
/*  89 */     this.user = user;
/*  90 */     this.jobid = JobID.downgrade(jobid);
/*  91 */     this.jobFile = jobFile;
/*  92 */     this.url = url;
/*  93 */     this.name = name;
/*  94 */     this.queueName = queueName;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public JobProfile(String user, String jobid, String jobFile, String url, String name)
/*     */   {
/* 103 */     this(user, JobID.forName(jobid), jobFile, url, name);
/*     */   }
/*     */ 
/*     */   public String getUser()
/*     */   {
/* 110 */     return this.user;
/*     */   }
/*     */ 
/*     */   public JobID getJobID()
/*     */   {
/* 117 */     return this.jobid;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public String getJobId()
/*     */   {
/* 125 */     return this.jobid.toString();
/*     */   }
/*     */ 
/*     */   public String getJobFile()
/*     */   {
/* 132 */     return this.jobFile;
/*     */   }
/*     */ 
/*     */   public URL getURL()
/*     */   {
/*     */     try
/*     */     {
/* 140 */       return new URL(this.url); } catch (IOException ie) {
/*     */     }
/* 142 */     return null;
/*     */   }
/*     */ 
/*     */   public String getJobName()
/*     */   {
/* 150 */     return this.name;
/*     */   }
/*     */ 
/*     */   public String getQueueName()
/*     */   {
/* 158 */     return this.queueName;
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/* 165 */     this.jobid.write(out);
/* 166 */     Text.writeString(out, this.jobFile);
/* 167 */     Text.writeString(out, this.url);
/* 168 */     Text.writeString(out, this.user);
/* 169 */     Text.writeString(out, this.name);
/* 170 */     Text.writeString(out, this.queueName);
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException {
/* 174 */     this.jobid.readFields(in);
/* 175 */     this.jobFile = Text.readString(in);
/* 176 */     this.url = Text.readString(in);
/* 177 */     this.user = Text.readString(in);
/* 178 */     this.name = Text.readString(in);
/* 179 */     this.queueName = Text.readString(in);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  38 */     WritableFactories.setFactory(JobProfile.class, new WritableFactory()
/*     */     {
/*     */       public Writable newInstance() {
/*  41 */         return new JobProfile();
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JobProfile
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import org.apache.hadoop.io.Text;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.WritableUtils;
/*     */ 
/*     */ public class ClusterStatus
/*     */   implements Writable
/*     */ {
/*     */   private int numActiveTrackers;
/*  61 */   private Collection<String> activeTrackers = new ArrayList();
/*  62 */   private Collection<String> blacklistedTrackers = new ArrayList();
/*  63 */   private Collection<String> graylistedTrackers = new ArrayList();
/*     */   private int numBlacklistedTrackers;
/*     */   private int numGraylistedTrackers;
/*     */   private int numExcludedNodes;
/*     */   private long ttExpiryInterval;
/*     */   private int map_tasks;
/*     */   private int reduce_tasks;
/*     */   private int max_map_tasks;
/*     */   private int max_reduce_tasks;
/*     */   private JobTracker.State state;
/*     */   public static final long UNINITIALIZED_MEMORY_VALUE = -1L;
/*  75 */   private long used_memory = -1L;
/*  76 */   private long max_memory = -1L;
/*     */ 
/*     */   ClusterStatus()
/*     */   {
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   ClusterStatus(int trackers, int maps, int reduces, int maxMaps, int maxReduces, JobTracker.State state)
/*     */   {
/*  94 */     this(trackers, 0, 0, JobTracker.TASKTRACKER_EXPIRY_INTERVAL, maps, reduces, maxMaps, maxReduces, state);
/*     */   }
/*     */ 
/*     */   ClusterStatus(int trackers, int blacklists, int graylists, long ttExpiryInterval, int maps, int reduces, int maxMaps, int maxReduces, JobTracker.State state)
/*     */   {
/* 114 */     this(trackers, blacklists, graylists, ttExpiryInterval, maps, reduces, maxMaps, maxReduces, state, 0);
/*     */   }
/*     */ 
/*     */   ClusterStatus(int trackers, int blacklists, int graylists, long ttExpiryInterval, int maps, int reduces, int maxMaps, int maxReduces, JobTracker.State state, int numDecommissionedNodes)
/*     */   {
/* 136 */     this(trackers, blacklists, graylists, ttExpiryInterval, maps, reduces, maxMaps, maxReduces, state, numDecommissionedNodes, -1L, -1L);
/*     */   }
/*     */ 
/*     */   ClusterStatus(Collection<String> activeTrackers, Collection<String> blacklistedTrackers, Collection<String> graylistedTrackers, long ttExpiryInterval, int maps, int reduces, int maxMaps, int maxReduces, JobTracker.State state)
/*     */   {
/* 160 */     this(activeTrackers, blacklistedTrackers, graylistedTrackers, ttExpiryInterval, maps, reduces, maxMaps, maxReduces, state, 0);
/*     */   }
/*     */ 
/*     */   ClusterStatus(int trackers, int blacklists, int graylists, long ttExpiryInterval, int maps, int reduces, int maxMaps, int maxReduces, JobTracker.State state, int numDecommissionedNodes, long used_memory, long max_memory)
/*     */   {
/* 168 */     this.numActiveTrackers = trackers;
/* 169 */     this.numBlacklistedTrackers = blacklists;
/* 170 */     this.numGraylistedTrackers = graylists;
/* 171 */     this.numExcludedNodes = numDecommissionedNodes;
/* 172 */     this.ttExpiryInterval = ttExpiryInterval;
/* 173 */     this.map_tasks = maps;
/* 174 */     this.reduce_tasks = reduces;
/* 175 */     this.max_map_tasks = maxMaps;
/* 176 */     this.max_reduce_tasks = maxReduces;
/* 177 */     this.state = state;
/* 178 */     this.used_memory = used_memory;
/* 179 */     this.max_memory = max_memory;
/*     */   }
/*     */ 
/*     */   ClusterStatus(Collection<String> activeTrackers, Collection<String> blacklistedTrackers, Collection<String> graylistedTrackers, long ttExpiryInterval, int maps, int reduces, int maxMaps, int maxReduces, JobTracker.State state, int numDecommissionNodes)
/*     */   {
/* 200 */     this(activeTrackers.size(), blacklistedTrackers.size(), graylistedTrackers.size(), ttExpiryInterval, maps, reduces, maxMaps, maxReduces, state, numDecommissionNodes, Runtime.getRuntime().totalMemory(), Runtime.getRuntime().maxMemory());
/*     */ 
/* 204 */     this.activeTrackers = activeTrackers;
/* 205 */     this.blacklistedTrackers = blacklistedTrackers;
/* 206 */     this.graylistedTrackers = graylistedTrackers;
/*     */   }
/*     */ 
/*     */   public int getTaskTrackers()
/*     */   {
/* 216 */     return this.numActiveTrackers;
/*     */   }
/*     */ 
/*     */   public Collection<String> getActiveTrackerNames()
/*     */   {
/* 226 */     return this.activeTrackers;
/*     */   }
/*     */ 
/*     */   public Collection<String> getBlacklistedTrackerNames()
/*     */   {
/* 235 */     return this.blacklistedTrackers;
/*     */   }
/*     */ 
/*     */   public int getBlacklistedTrackers()
/*     */   {
/* 244 */     return this.numBlacklistedTrackers;
/*     */   }
/*     */ 
/*     */   public Collection<String> getGraylistedTrackerNames()
/*     */   {
/* 253 */     return this.graylistedTrackers;
/*     */   }
/*     */ 
/*     */   public int getGraylistedTrackers()
/*     */   {
/* 262 */     return this.numGraylistedTrackers;
/*     */   }
/*     */ 
/*     */   public int getNumExcludedNodes()
/*     */   {
/* 270 */     return this.numExcludedNodes;
/*     */   }
/*     */ 
/*     */   public long getTTExpiryInterval()
/*     */   {
/* 278 */     return this.ttExpiryInterval;
/*     */   }
/*     */ 
/*     */   public int getMapTasks()
/*     */   {
/* 287 */     return this.map_tasks;
/*     */   }
/*     */ 
/*     */   public int getReduceTasks()
/*     */   {
/* 296 */     return this.reduce_tasks;
/*     */   }
/*     */ 
/*     */   public int getMaxMapTasks()
/*     */   {
/* 305 */     return this.max_map_tasks;
/*     */   }
/*     */ 
/*     */   public int getMaxReduceTasks()
/*     */   {
/* 314 */     return this.max_reduce_tasks;
/*     */   }
/*     */ 
/*     */   public JobTracker.State getJobTrackerState()
/*     */   {
/* 324 */     return this.state;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public long getUsedMemory()
/*     */   {
/* 334 */     return this.used_memory;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public long getMaxMemory()
/*     */   {
/* 344 */     return this.max_memory;
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out) throws IOException {
/* 348 */     if (this.activeTrackers.size() == 0) {
/* 349 */       out.writeInt(this.numActiveTrackers);
/* 350 */       out.writeInt(0);
/*     */     } else {
/* 352 */       out.writeInt(this.activeTrackers.size());
/* 353 */       out.writeInt(this.activeTrackers.size());
/* 354 */       for (String tracker : this.activeTrackers) {
/* 355 */         Text.writeString(out, tracker);
/*     */       }
/*     */     }
/* 358 */     if (this.blacklistedTrackers.size() == 0) {
/* 359 */       out.writeInt(this.numBlacklistedTrackers);
/* 360 */       out.writeInt(0);
/*     */     } else {
/* 362 */       out.writeInt(this.blacklistedTrackers.size());
/* 363 */       out.writeInt(this.blacklistedTrackers.size());
/* 364 */       for (String tracker : this.blacklistedTrackers) {
/* 365 */         Text.writeString(out, tracker);
/*     */       }
/*     */     }
/* 368 */     if (this.graylistedTrackers.size() == 0) {
/* 369 */       out.writeInt(this.numGraylistedTrackers);
/* 370 */       out.writeInt(0);
/*     */     } else {
/* 372 */       out.writeInt(this.graylistedTrackers.size());
/* 373 */       out.writeInt(this.graylistedTrackers.size());
/* 374 */       for (String tracker : this.graylistedTrackers) {
/* 375 */         Text.writeString(out, tracker);
/*     */       }
/*     */     }
/* 378 */     out.writeInt(this.numExcludedNodes);
/* 379 */     out.writeLong(this.ttExpiryInterval);
/* 380 */     out.writeInt(this.map_tasks);
/* 381 */     out.writeInt(this.reduce_tasks);
/* 382 */     out.writeInt(this.max_map_tasks);
/* 383 */     out.writeInt(this.max_reduce_tasks);
/* 384 */     out.writeLong(this.used_memory);
/* 385 */     out.writeLong(this.max_memory);
/* 386 */     WritableUtils.writeEnum(out, this.state);
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException {
/* 390 */     this.numActiveTrackers = in.readInt();
/* 391 */     int numTrackerNames = in.readInt();
/* 392 */     if (numTrackerNames > 0) {
/* 393 */       for (int i = 0; i < numTrackerNames; i++) {
/* 394 */         String name = Text.readString(in);
/* 395 */         this.activeTrackers.add(name);
/*     */       }
/*     */     }
/* 398 */     this.numBlacklistedTrackers = in.readInt();
/* 399 */     numTrackerNames = in.readInt();
/* 400 */     if (numTrackerNames > 0) {
/* 401 */       for (int i = 0; i < numTrackerNames; i++) {
/* 402 */         String name = Text.readString(in);
/* 403 */         this.blacklistedTrackers.add(name);
/*     */       }
/*     */     }
/* 406 */     this.numGraylistedTrackers = in.readInt();
/* 407 */     numTrackerNames = in.readInt();
/* 408 */     if (numTrackerNames > 0) {
/* 409 */       for (int i = 0; i < numTrackerNames; i++) {
/* 410 */         String name = Text.readString(in);
/* 411 */         this.graylistedTrackers.add(name);
/*     */       }
/*     */     }
/* 414 */     this.numExcludedNodes = in.readInt();
/* 415 */     this.ttExpiryInterval = in.readLong();
/* 416 */     this.map_tasks = in.readInt();
/* 417 */     this.reduce_tasks = in.readInt();
/* 418 */     this.max_map_tasks = in.readInt();
/* 419 */     this.max_reduce_tasks = in.readInt();
/* 420 */     this.used_memory = in.readLong();
/* 421 */     this.max_memory = in.readLong();
/* 422 */     this.state = ((JobTracker.State)WritableUtils.readEnum(in, JobTracker.State.class));
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.ClusterStatus
 * JD-Core Version:    0.6.1
 */
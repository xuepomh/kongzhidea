/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.mapreduce.security.token.DelegationTokenRenewal;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ 
/*     */ public class CleanupQueue
/*     */ {
/*  36 */   public static final Log LOG = LogFactory.getLog(CleanupQueue.class);
/*     */ 
/*  39 */   private static final PathCleanupThread cleanupThread = new PathCleanupThread();
/*     */ 
/*  41 */   private static final CleanupQueue inst = new CleanupQueue();
/*     */ 
/*  43 */   public static CleanupQueue getInstance() { return inst; }
/*     */ 
/*     */ 
/*     */   public void addToQueue(PathDeletionContext[] contexts)
/*     */   {
/* 142 */     cleanupThread.addToQueue(contexts);
/*     */   }
/*     */ 
/*     */   protected boolean isQueueEmpty()
/*     */   {
/* 147 */     return cleanupThread.queue.size() == 0;
/*     */   }
/*     */ 
/*     */   private static class PathCleanupThread extends Thread
/*     */   {
/* 153 */     private LinkedBlockingQueue<CleanupQueue.PathDeletionContext> queue = new LinkedBlockingQueue();
/*     */ 
/*     */     public PathCleanupThread()
/*     */     {
/* 157 */       setName("Directory/File cleanup thread");
/* 158 */       setDaemon(true);
/* 159 */       start();
/*     */     }
/*     */ 
/*     */     void addToQueue(CleanupQueue.PathDeletionContext[] contexts) {
/* 163 */       for (CleanupQueue.PathDeletionContext context : contexts)
/*     */         try {
/* 165 */           this.queue.put(context);
/*     */         } catch (InterruptedException ie) {
/*     */         }
/*     */     }
/*     */ 
/*     */     public void run() {
/* 171 */       if (CleanupQueue.LOG.isDebugEnabled()) {
/* 172 */         CleanupQueue.LOG.debug(getName() + " started.");
/*     */       }
/* 174 */       CleanupQueue.PathDeletionContext context = null;
/*     */       while (true)
/*     */         try {
/* 177 */           context = (CleanupQueue.PathDeletionContext)this.queue.take();
/* 178 */           context.deletePath();
/*     */ 
/* 180 */           if (CleanupQueue.LOG.isDebugEnabled())
/* 181 */             CleanupQueue.LOG.debug("DELETED " + context);
/*     */         }
/*     */         catch (InterruptedException t) {
/* 184 */           CleanupQueue.LOG.warn("Interrupted deletion of " + context);
/* 185 */           return;
/*     */         } catch (Throwable e) {
/* 187 */           CleanupQueue.LOG.warn("Error deleting path " + context, e);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   static class PathDeletionContext
/*     */   {
/*     */     final Path fullPath;
/*     */     final Configuration conf;
/*     */     final UserGroupInformation ugi;
/*     */     final JobID jobIdTokenRenewalToCancel;
/*     */ 
/*     */     public PathDeletionContext(Path fullPath, Configuration conf)
/*     */     {
/*  65 */       this(fullPath, conf, null, null);
/*     */     }
/*     */ 
/*     */     public PathDeletionContext(Path fullPath, Configuration conf, UserGroupInformation ugi)
/*     */     {
/*  70 */       this(fullPath, conf, ugi, null);
/*     */     }
/*     */ 
/*     */     public PathDeletionContext(Path fullPath, Configuration conf, UserGroupInformation ugi, JobID jobIdTokenRenewalToCancel)
/*     */     {
/*  90 */       this.fullPath = fullPath;
/*  91 */       this.conf = conf;
/*  92 */       this.ugi = ugi;
/*  93 */       this.jobIdTokenRenewalToCancel = jobIdTokenRenewalToCancel;
/*     */     }
/*     */ 
/*     */     protected Path getPathForCleanup() {
/*  97 */       return this.fullPath;
/*     */     }
/*     */ 
/*     */     protected void deletePath()
/*     */       throws IOException, InterruptedException
/*     */     {
/* 105 */       final Path p = getPathForCleanup();
/* 106 */       (this.ugi == null ? UserGroupInformation.getLoginUser() : this.ugi).doAs(new Object()
/*     */       {
/*     */         public Object run() throws IOException {
/* 109 */           FileSystem fs = p.getFileSystem(CleanupQueue.PathDeletionContext.this.conf);
/*     */           try {
/* 111 */             fs.delete(p, true);
/* 112 */             return null;
/*     */           }
/*     */           finally
/*     */           {
/* 116 */             if (CleanupQueue.PathDeletionContext.this.ugi != null)
/* 117 */               fs.close();
/*     */           }
/*     */         }
/*     */       });
/* 124 */       if ((this.jobIdTokenRenewalToCancel != null) && (this.conf.getBoolean("mapreduce.job.complete.cancel.delegation.tokens", true)))
/*     */       {
/* 126 */         DelegationTokenRenewal.removeDelegationTokenRenewalForJob(this.jobIdTokenRenewalToCancel);
/*     */       }
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 133 */       Path p = getPathForCleanup();
/* 134 */       return null == p ? "undefined" : p.toString();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.CleanupQueue
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.mapred;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ public class InvalidInputException extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private List<IOException> problems;
/*    */ 
/*    */   public InvalidInputException(List<IOException> probs)
/*    */   {
/* 39 */     this.problems = probs;
/*    */   }
/*    */ 
/*    */   public List<IOException> getProblems()
/*    */   {
/* 47 */     return this.problems;
/*    */   }
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 55 */     StringBuffer result = new StringBuffer();
/* 56 */     Iterator itr = this.problems.iterator();
/* 57 */     while (itr.hasNext()) {
/* 58 */       result.append(((IOException)itr.next()).getMessage());
/* 59 */       if (itr.hasNext()) {
/* 60 */         result.append("\n");
/*    */       }
/*    */     }
/* 63 */     return result.toString();
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.InvalidInputException
 * JD-Core Version:    0.6.1
 */
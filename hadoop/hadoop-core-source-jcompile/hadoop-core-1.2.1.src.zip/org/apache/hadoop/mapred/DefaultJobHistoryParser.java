/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ 
/*     */ public class DefaultJobHistoryParser
/*     */ {
/*     */   public static void parseJobTasks(String jobHistoryFile, JobHistory.JobInfo job, FileSystem fs)
/*     */     throws IOException
/*     */   {
/*  50 */     JobHistory.parseHistoryFromFS(jobHistoryFile, new JobTasksParseListener(job), fs);
/*     */   }
/*     */ 
/*     */   static class KilledOnNodesFilter extends DefaultJobHistoryParser.NodesFilter
/*     */   {
/*     */     void setFailureType()
/*     */     {
/* 173 */       this.failureType = JobHistory.Values.KILLED.name();
/*     */     }
/*     */   }
/*     */ 
/*     */   static class FailedOnNodesFilter extends DefaultJobHistoryParser.NodesFilter
/*     */   {
/*     */     void setFailureType()
/*     */     {
/* 168 */       this.failureType = JobHistory.Values.FAILED.name();
/*     */     }
/*     */   }
/*     */ 
/*     */   static abstract class NodesFilter
/*     */     implements JobHistory.Listener
/*     */   {
/* 131 */     private Map<String, Set<String>> badNodesToNumFailedTasks = new HashMap();
/*     */     String failureType;
/*     */ 
/*     */     Map<String, Set<String>> getValues()
/*     */     {
/* 135 */       return this.badNodesToNumFailedTasks;
/*     */     }
/*     */ 
/*     */     public void handle(JobHistory.RecordTypes recType, Map<JobHistory.Keys, String> values)
/*     */       throws IOException
/*     */     {
/* 141 */       if ((recType.equals(JobHistory.RecordTypes.MapAttempt)) || (recType.equals(JobHistory.RecordTypes.ReduceAttempt)))
/*     */       {
/* 143 */         if (this.failureType.equals(values.get(JobHistory.Keys.TASK_STATUS))) {
/* 144 */           String hostName = (String)values.get(JobHistory.Keys.HOSTNAME);
/* 145 */           String taskid = (String)values.get(JobHistory.Keys.TASKID);
/* 146 */           Set tasks = (Set)this.badNodesToNumFailedTasks.get(hostName);
/* 147 */           if (null == tasks) {
/* 148 */             tasks = new TreeSet();
/* 149 */             tasks.add(taskid);
/* 150 */             this.badNodesToNumFailedTasks.put(hostName, tasks);
/*     */           } else {
/* 152 */             tasks.add(taskid); } 
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     abstract void setFailureType();
/*     */ 
/* 159 */     String getFailureType() { return this.failureType; }
/*     */ 
/*     */     NodesFilter() {
/* 162 */       setFailureType();
/*     */     }
/*     */   }
/*     */ 
/*     */   static class JobTasksParseListener
/*     */     implements JobHistory.Listener
/*     */   {
/*     */     JobHistory.JobInfo job;
/*     */ 
/*     */     JobTasksParseListener(JobHistory.JobInfo job)
/*     */     {
/*  63 */       this.job = job;
/*     */     }
/*     */ 
/*     */     private JobHistory.Task getTask(String taskId) {
/*  67 */       JobHistory.Task task = (JobHistory.Task)this.job.getAllTasks().get(taskId);
/*  68 */       if (null == task) {
/*  69 */         task = new JobHistory.Task();
/*  70 */         task.set(JobHistory.Keys.TASKID, taskId);
/*  71 */         this.job.getAllTasks().put(taskId, task);
/*     */       }
/*  73 */       return task;
/*     */     }
/*     */ 
/*     */     private JobHistory.MapAttempt getMapAttempt(String jobid, String jobTrackerId, String taskId, String taskAttemptId)
/*     */     {
/*  79 */       JobHistory.Task task = getTask(taskId);
/*  80 */       JobHistory.MapAttempt mapAttempt = (JobHistory.MapAttempt)task.getTaskAttempts().get(taskAttemptId);
/*     */ 
/*  82 */       if (null == mapAttempt) {
/*  83 */         mapAttempt = new JobHistory.MapAttempt();
/*  84 */         mapAttempt.set(JobHistory.Keys.TASK_ATTEMPT_ID, taskAttemptId);
/*  85 */         task.getTaskAttempts().put(taskAttemptId, mapAttempt);
/*     */       }
/*  87 */       return mapAttempt;
/*     */     }
/*     */ 
/*     */     private JobHistory.ReduceAttempt getReduceAttempt(String jobid, String jobTrackerId, String taskId, String taskAttemptId)
/*     */     {
/*  93 */       JobHistory.Task task = getTask(taskId);
/*  94 */       JobHistory.ReduceAttempt reduceAttempt = (JobHistory.ReduceAttempt)task.getTaskAttempts().get(taskAttemptId);
/*     */ 
/*  96 */       if (null == reduceAttempt) {
/*  97 */         reduceAttempt = new JobHistory.ReduceAttempt();
/*  98 */         reduceAttempt.set(JobHistory.Keys.TASK_ATTEMPT_ID, taskAttemptId);
/*  99 */         task.getTaskAttempts().put(taskAttemptId, reduceAttempt);
/*     */       }
/* 101 */       return reduceAttempt;
/*     */     }
/*     */ 
/*     */     public void handle(JobHistory.RecordTypes recType, Map<JobHistory.Keys, String> values)
/*     */       throws IOException
/*     */     {
/* 107 */       String jobTrackerId = (String)values.get(JobHistory.Keys.JOBTRACKERID);
/* 108 */       String jobid = (String)values.get(JobHistory.Keys.JOBID);
/*     */ 
/* 110 */       if (recType == JobHistory.RecordTypes.Job)
/* 111 */         this.job.handle(values);
/* 112 */       if (recType.equals(JobHistory.RecordTypes.Task)) {
/* 113 */         String taskid = (String)values.get(JobHistory.Keys.TASKID);
/* 114 */         getTask(taskid).handle(values);
/* 115 */       } else if (recType.equals(JobHistory.RecordTypes.MapAttempt)) {
/* 116 */         String taskid = (String)values.get(JobHistory.Keys.TASKID);
/* 117 */         String mapAttemptId = (String)values.get(JobHistory.Keys.TASK_ATTEMPT_ID);
/*     */ 
/* 119 */         getMapAttempt(jobid, jobTrackerId, taskid, mapAttemptId).handle(values);
/* 120 */       } else if (recType.equals(JobHistory.RecordTypes.ReduceAttempt)) {
/* 121 */         String taskid = (String)values.get(JobHistory.Keys.TASKID);
/* 122 */         String reduceAttemptId = (String)values.get(JobHistory.Keys.TASK_ATTEMPT_ID);
/*     */ 
/* 124 */         getReduceAttempt(jobid, jobTrackerId, taskid, reduceAttemptId).handle(values);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.DefaultJobHistoryParser
 * JD-Core Version:    0.6.1
 */
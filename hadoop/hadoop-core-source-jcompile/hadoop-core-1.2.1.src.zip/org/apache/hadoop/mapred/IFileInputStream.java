/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.FileDescriptor;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.ChecksumException;
/*     */ import org.apache.hadoop.fs.HasFileDescriptor;
/*     */ import org.apache.hadoop.io.IOUtils;
/*     */ import org.apache.hadoop.io.ReadaheadPool;
/*     */ import org.apache.hadoop.io.ReadaheadPool.ReadaheadRequest;
/*     */ import org.apache.hadoop.util.DataChecksum;
/*     */ 
/*     */ class IFileInputStream extends InputStream
/*     */ {
/*     */   private final InputStream in;
/*     */   private final FileDescriptor inFd;
/*     */   private final long length;
/*     */   private final long dataLength;
/*     */   private DataChecksum sum;
/*  49 */   private long currentOffset = 0L;
/*  50 */   private final byte[] b = new byte[1];
/*  51 */   private byte[] csum = null;
/*     */   private int checksumSize;
/*  54 */   private ReadaheadPool.ReadaheadRequest curReadahead = null;
/*  55 */   private ReadaheadPool raPool = ReadaheadPool.getInstance();
/*     */   private boolean readahead;
/*     */   private int readaheadLength;
/*     */   public static final String MAPRED_IFILE_READAHEAD = "mapreduce.ifile.readahead";
/*     */   public static final boolean DEFAULT_MAPRED_IFILE_READAHEAD = true;
/*     */   public static final String MAPRED_IFILE_READAHEAD_BYTES = "mapreduce.ifile.readahead.bytes";
/*     */   public static final int DEFAULT_MAPRED_IFILE_READAHEAD_BYTES = 4194304;
/*  76 */   public static final Log LOG = LogFactory.getLog(IFileInputStream.class);
/*     */ 
/*     */   public IFileInputStream(InputStream in, long len, Configuration conf)
/*     */   {
/*  84 */     this.in = in;
/*  85 */     this.inFd = getFileDescriptorIfAvail(in);
/*  86 */     this.sum = DataChecksum.newDataChecksum(1, 2147483647);
/*     */ 
/*  88 */     this.checksumSize = this.sum.getChecksumSize();
/*  89 */     this.length = len;
/*  90 */     this.dataLength = (this.length - this.checksumSize);
/*     */ 
/*  92 */     conf = conf != null ? conf : new Configuration();
/*  93 */     this.readahead = conf.getBoolean("mapreduce.ifile.readahead", true);
/*     */ 
/*  95 */     this.readaheadLength = conf.getInt("mapreduce.ifile.readahead.bytes", 4194304);
/*     */ 
/*  98 */     doReadahead();
/*     */   }
/*     */ 
/*     */   private static FileDescriptor getFileDescriptorIfAvail(InputStream in) {
/* 102 */     FileDescriptor fd = null;
/*     */     try {
/* 104 */       if ((in instanceof HasFileDescriptor))
/* 105 */         fd = ((HasFileDescriptor)in).getFileDescriptor();
/* 106 */       else if ((in instanceof FileInputStream))
/* 107 */         fd = ((FileInputStream)in).getFD();
/*     */     }
/*     */     catch (IOException e) {
/* 110 */       LOG.info("Unable to determine FileDescriptor", e);
/*     */     }
/* 112 */     return fd;
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 122 */     if (this.curReadahead != null) {
/* 123 */       this.curReadahead.cancel();
/*     */     }
/* 125 */     if (this.currentOffset < this.dataLength) {
/* 126 */       byte[] t = new byte[Math.min((int)(0x7FFFFFFF & this.dataLength - this.currentOffset), 32768)];
/*     */ 
/* 128 */       while (this.currentOffset < this.dataLength) {
/* 129 */         int n = read(t, 0, t.length);
/* 130 */         if (0 == n) {
/* 131 */           throw new EOFException("Could not validate checksum");
/*     */         }
/*     */       }
/*     */     }
/* 135 */     this.in.close();
/*     */   }
/*     */ 
/*     */   public long skip(long n) throws IOException
/*     */   {
/* 140 */     throw new IOException("Skip not supported for IFileInputStream");
/*     */   }
/*     */ 
/*     */   public long getPosition() {
/* 144 */     return this.currentOffset >= this.dataLength ? this.dataLength : this.currentOffset;
/*     */   }
/*     */ 
/*     */   public long getSize() {
/* 148 */     return this.checksumSize;
/*     */   }
/*     */ 
/*     */   public int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 158 */     if (this.currentOffset >= this.dataLength) {
/* 159 */       return -1;
/*     */     }
/*     */ 
/* 162 */     doReadahead();
/*     */ 
/* 164 */     return doRead(b, off, len);
/*     */   }
/*     */ 
/*     */   private void doReadahead() {
/* 168 */     if ((this.raPool != null) && (this.inFd != null) && (this.readahead))
/* 169 */       this.curReadahead = this.raPool.readaheadStream("ifile", this.inFd, this.currentOffset, this.readaheadLength, this.dataLength, this.curReadahead);
/*     */   }
/*     */ 
/*     */   public int readWithChecksum(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 184 */     if (this.currentOffset == this.length) {
/* 185 */       return -1;
/*     */     }
/* 187 */     if (this.currentOffset >= this.dataLength)
/*     */     {
/* 191 */       int lenToCopy = (int)(this.checksumSize - (this.currentOffset - this.dataLength));
/* 192 */       if (len < lenToCopy) {
/* 193 */         lenToCopy = len;
/*     */       }
/* 195 */       System.arraycopy(this.csum, (int)(this.currentOffset - this.dataLength), b, off, lenToCopy);
/*     */ 
/* 197 */       this.currentOffset += lenToCopy;
/* 198 */       return lenToCopy;
/*     */     }
/*     */ 
/* 201 */     int bytesRead = doRead(b, off, len);
/*     */ 
/* 203 */     if ((this.currentOffset == this.dataLength) && 
/* 204 */       (len >= bytesRead + this.checksumSize)) {
/* 205 */       System.arraycopy(this.csum, 0, b, off + bytesRead, this.checksumSize);
/* 206 */       bytesRead += this.checksumSize;
/* 207 */       this.currentOffset += this.checksumSize;
/*     */     }
/*     */ 
/* 210 */     return bytesRead;
/*     */   }
/*     */ 
/*     */   private int doRead(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 217 */     if (this.currentOffset + len > this.dataLength) {
/* 218 */       len = (int)this.dataLength - (int)this.currentOffset;
/*     */     }
/*     */ 
/* 221 */     int bytesRead = this.in.read(b, off, len);
/*     */ 
/* 223 */     if (bytesRead < 0) {
/* 224 */       throw new ChecksumException("Checksum Error", 0L);
/*     */     }
/*     */ 
/* 227 */     this.sum.update(b, off, bytesRead);
/*     */ 
/* 229 */     this.currentOffset += bytesRead;
/*     */ 
/* 231 */     if (this.currentOffset == this.dataLength)
/*     */     {
/* 233 */       this.csum = new byte[this.checksumSize];
/* 234 */       IOUtils.readFully(this.in, this.csum, 0, this.checksumSize);
/* 235 */       if (!this.sum.compare(this.csum, 0)) {
/* 236 */         throw new ChecksumException("Checksum Error", 0L);
/*     */       }
/*     */     }
/* 239 */     return bytesRead;
/*     */   }
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/* 245 */     this.b[0] = 0;
/* 246 */     int l = read(this.b, 0, 1);
/* 247 */     if (l < 0) return l;
/*     */ 
/* 251 */     int result = 0xFF & this.b[0];
/* 252 */     return result;
/*     */   }
/*     */ 
/*     */   public byte[] getChecksum() {
/* 256 */     return this.csum;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.IFileInputStream
 * JD-Core Version:    0.6.1
 */
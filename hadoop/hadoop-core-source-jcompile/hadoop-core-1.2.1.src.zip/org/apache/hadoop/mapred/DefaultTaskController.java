/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.FileUtil;
/*     */ import org.apache.hadoop.fs.LocalDirAllocator;
/*     */ import org.apache.hadoop.fs.LocalFileSystem;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.mapreduce.JobID;
/*     */ import org.apache.hadoop.mapreduce.server.tasktracker.JVMInfo;
/*     */ import org.apache.hadoop.mapreduce.server.tasktracker.Localizer;
/*     */ import org.apache.hadoop.util.ProcessTree;
/*     */ import org.apache.hadoop.util.ProcessTree.Signal;
/*     */ import org.apache.hadoop.util.Shell.ShellCommandExecutor;
/*     */ 
/*     */ public class DefaultTaskController extends TaskController
/*     */ {
/*  55 */   private static final Log LOG = LogFactory.getLog(DefaultTaskController.class);
/*     */   private FileSystem fs;
/*     */ 
/*     */   public void setConf(Configuration conf)
/*     */   {
/*  60 */     super.setConf(conf);
/*     */     try {
/*  62 */       this.fs = FileSystem.getLocal(conf).getRaw();
/*     */     } catch (IOException ie) {
/*  64 */       throw new RuntimeException("Failed getting LocalFileSystem", ie);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void createLogDir(TaskAttemptID taskID, boolean isCleanup)
/*     */     throws IOException
/*     */   {
/*  71 */     TaskLog.createTaskAttemptLogDir(taskID, isCleanup, this.localStorage.getDirs());
/*     */   }
/*     */ 
/*     */   public int launchTask(String user, String jobId, String attemptId, List<String> setup, List<String> jvmArguments, File currentWorkDirectory, String stdout, String stderr)
/*     */     throws IOException
/*     */   {
/*  90 */     Shell.ShellCommandExecutor shExec = null;
/*     */     try {
/*  92 */       FileSystem localFs = FileSystem.getLocal(getConf());
/*     */ 
/*  95 */       new Localizer(localFs, getConf().getStrings("mapred.local.dir")).initializeAttemptDirs(user, jobId, attemptId);
/*     */ 
/* 100 */       if (!currentWorkDirectory.mkdir()) {
/* 101 */         throw new IOException("Mkdirs failed to create " + currentWorkDirectory.toString());
/*     */       }
/*     */ 
/* 106 */       String logLocation = TaskLog.getAttemptDir(jobId, attemptId).toString();
/* 107 */       if (!localFs.mkdirs(new Path(logLocation))) {
/* 108 */         throw new IOException("Mkdirs failed to create " + logLocation);
/*     */       }
/*     */ 
/* 112 */       FileSystem rawFs = FileSystem.getLocal(getConf()).getRaw();
/* 113 */       long logSize = 0L;
/*     */ 
/* 115 */       String cmdLine = TaskLog.buildCommandLine(setup, jvmArguments, new File(stdout), new File(stderr), logSize, true);
/*     */ 
/* 122 */       Path p = new Path(this.allocator.getLocalPathForWrite(TaskTracker.getPrivateDirTaskScriptLocation(user, jobId, attemptId), getConf()), "taskjvm.sh");
/*     */ 
/* 126 */       String commandFile = writeCommand(cmdLine, rawFs, p);
/* 127 */       rawFs.setPermission(p, TaskController.TASK_LAUNCH_SCRIPT_PERMISSION);
/*     */ 
/* 137 */       shExec = new Shell.ShellCommandExecutor(new String[] { "bash", commandFile }, currentWorkDirectory);
/*     */ 
/* 140 */       shExec.execute();
/*     */     } catch (Exception e) {
/* 142 */       if (shExec == null) {
/* 143 */         return -1;
/*     */       }
/* 145 */       int exitCode = shExec.getExitCode();
/* 146 */       LOG.warn("Exit code from task is : " + exitCode);
/* 147 */       LOG.info("Output from DefaultTaskController's launchTask follows:");
/* 148 */       logOutput(shExec.getOutput());
/* 149 */       return exitCode;
/*     */     }
/* 151 */     return 0;
/*     */   }
/*     */ 
/*     */   public void initializeJob(String user, String jobid, Path credentials, Path jobConf, TaskUmbilicalProtocol taskTracker, InetSocketAddress ttAddr)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 188 */     LocalDirAllocator lDirAlloc = this.allocator;
/* 189 */     FileSystem localFs = FileSystem.getLocal(getConf());
/* 190 */     JobLocalizer localizer = new JobLocalizer((JobConf)getConf(), user, jobid);
/* 191 */     localizer.createLocalDirs();
/* 192 */     localizer.createUserDirs();
/* 193 */     localizer.createJobDirs();
/*     */ 
/* 195 */     JobConf jConf = new JobConf(jobConf);
/* 196 */     localizer.createWorkDir(jConf);
/*     */ 
/* 198 */     Path localJobTokenFile = lDirAlloc.getLocalPathForWrite(TaskTracker.getLocalJobTokenFile(user, jobid), getConf());
/*     */ 
/* 200 */     FileUtil.copy(localFs, credentials, localFs, localJobTokenFile, false, getConf());
/*     */ 
/* 205 */     localizer.initializeJobLogDir();
/*     */ 
/* 211 */     localizer.localizeJobFiles(JobID.forName(jobid), jConf, localJobTokenFile, taskTracker);
/*     */   }
/*     */ 
/*     */   public void signalTask(String user, int taskPid, ProcessTree.Signal signal)
/*     */   {
/* 217 */     if (ProcessTree.isSetsidAvailable)
/* 218 */       ProcessTree.killProcessGroup(Integer.toString(taskPid), signal);
/*     */     else
/* 220 */       ProcessTree.killProcess(Integer.toString(taskPid), signal);
/*     */   }
/*     */ 
/*     */   public void deleteAsUser(String user, String subDir)
/*     */     throws IOException
/*     */   {
/* 234 */     String dir = TaskTracker.getUserDir(user) + "/" + subDir;
/* 235 */     for (Path fullDir : this.allocator.getAllLocalPathsToRead(dir, getConf()))
/* 236 */       this.fs.delete(fullDir, true);
/*     */   }
/*     */ 
/*     */   public void deleteLogAsUser(String user, String subDir)
/*     */     throws IOException
/*     */   {
/* 249 */     Path dir = new Path(TaskLog.getUserLogDir().getAbsolutePath(), subDir);
/*     */ 
/* 251 */     File subDirPath = new File(dir.toString());
/* 252 */     FileUtil.fullyDelete(subDirPath);
/*     */ 
/* 255 */     for (String localdir : this.localStorage.getDirs()) {
/* 256 */       String dirPath = localdir + File.separatorChar + "userlogs" + File.separatorChar + subDir;
/*     */       try
/*     */       {
/* 260 */         FileUtil.fullyDelete(new File(dirPath));
/*     */       }
/*     */       catch (Exception e) {
/* 263 */         LOG.warn("Could not delete dir: " + dirPath + " , Reason : " + e.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void truncateLogsAsUser(String user, List<Task> allAttempts)
/*     */     throws IOException
/*     */   {
/* 272 */     Task firstTask = (Task)allAttempts.get(0);
/* 273 */     TaskLogsTruncater trunc = new TaskLogsTruncater(getConf());
/*     */ 
/* 275 */     trunc.truncateLogs(new JVMInfo(TaskLog.getAttemptDir(firstTask.getTaskID(), firstTask.isTaskCleanupTask()), allAttempts));
/*     */   }
/*     */ 
/*     */   public void setup(LocalDirAllocator allocator, TaskTracker.LocalStorage localStorage)
/*     */   {
/* 283 */     this.allocator = allocator;
/* 284 */     this.localStorage = localStorage;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.DefaultTaskController
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import org.apache.hadoop.conf.Configured;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.util.Tool;
/*     */ import org.apache.hadoop.util.ToolRunner;
/*     */ 
/*     */ class JobQueueClient extends Configured
/*     */   implements Tool
/*     */ {
/*     */   JobClient jc;
/*     */ 
/*     */   public JobQueueClient()
/*     */   {
/*     */   }
/*     */ 
/*     */   public JobQueueClient(JobConf conf)
/*     */     throws IOException
/*     */   {
/*  43 */     setConf(conf);
/*     */   }
/*     */ 
/*     */   private void init(JobConf conf) throws IOException {
/*  47 */     setConf(conf);
/*  48 */     this.jc = new JobClient(conf);
/*     */   }
/*     */ 
/*     */   public int run(String[] argv) throws Exception
/*     */   {
/*  53 */     int exitcode = -1;
/*     */ 
/*  55 */     if (argv.length < 1) {
/*  56 */       displayUsage("");
/*  57 */       return exitcode;
/*     */     }
/*  59 */     String cmd = argv[0];
/*  60 */     boolean displayQueueList = false;
/*  61 */     boolean displayQueueInfoWithJobs = false;
/*  62 */     boolean displayQueueInfoWithoutJobs = false;
/*  63 */     boolean displayQueueAclsInfoForCurrentUser = false;
/*     */ 
/*  65 */     if ("-list".equals(cmd)) {
/*  66 */       displayQueueList = true;
/*  67 */     } else if ("-showacls".equals(cmd)) {
/*  68 */       displayQueueAclsInfoForCurrentUser = true;
/*  69 */     } else if ("-info".equals(cmd)) {
/*  70 */       if ((argv.length == 2) && (!argv[1].equals("-showJobs"))) {
/*  71 */         displayQueueInfoWithoutJobs = true;
/*  72 */       } else if (argv.length == 3) {
/*  73 */         if (argv[2].equals("-showJobs")) {
/*  74 */           displayQueueInfoWithJobs = true;
/*     */         } else {
/*  76 */           displayUsage(cmd);
/*  77 */           return exitcode;
/*     */         }
/*     */       } else {
/*  80 */         displayUsage(cmd);
/*  81 */         return exitcode;
/*     */       }
/*     */     } else {
/*  84 */       displayUsage(cmd);
/*  85 */       return exitcode;
/*     */     }
/*  87 */     JobConf conf = new JobConf(getConf());
/*  88 */     init(conf);
/*  89 */     if (displayQueueList) {
/*  90 */       displayQueueList();
/*  91 */       exitcode = 0;
/*  92 */     } else if (displayQueueInfoWithoutJobs) {
/*  93 */       displayQueueInfo(argv[1], false);
/*  94 */       exitcode = 0;
/*  95 */     } else if (displayQueueInfoWithJobs) {
/*  96 */       displayQueueInfo(argv[1], true);
/*  97 */       exitcode = 0;
/*  98 */     } else if (displayQueueAclsInfoForCurrentUser) {
/*  99 */       displayQueueAclsInfoForCurrentUser();
/* 100 */       exitcode = 0;
/*     */     }
/*     */ 
/* 103 */     return exitcode;
/*     */   }
/*     */ 
/*     */   private void displayQueueInfo(String queue, boolean showJobs)
/*     */     throws IOException
/*     */   {
/* 116 */     JobQueueInfo jobQueueInfo = this.jc.getQueueInfo(queue);
/* 117 */     if (jobQueueInfo == null) {
/* 118 */       System.out.println("Queue Name : " + queue + " has no scheduling information");
/*     */     }
/*     */     else {
/* 121 */       printJobQueueInfo(jobQueueInfo);
/*     */     }
/* 123 */     if (showJobs) {
/* 124 */       System.out.printf("Job List\n", new Object[0]);
/* 125 */       JobStatus[] jobs = this.jc.getJobsFromQueue(queue);
/* 126 */       if (jobs == null)
/* 127 */         jobs = new JobStatus[0];
/* 128 */       this.jc.displayJobList(jobs);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void printJobQueueInfo(JobQueueInfo jobQueueInfo)
/*     */   {
/* 136 */     System.out.println("Queue Name : " + jobQueueInfo.getQueueName());
/* 137 */     System.out.println("Queue State : " + jobQueueInfo.getQueueState());
/* 138 */     String schedInfo = jobQueueInfo.getSchedulingInfo();
/* 139 */     if ((null == schedInfo) || ("".equals(schedInfo.trim()))) {
/* 140 */       schedInfo = "N/A";
/*     */     }
/* 142 */     System.out.println("Scheduling Info : " + schedInfo);
/*     */   }
/*     */ 
/*     */   private void displayQueueList()
/*     */     throws IOException
/*     */   {
/* 152 */     JobQueueInfo[] queues = this.jc.getQueues();
/* 153 */     for (JobQueueInfo queue : queues)
/* 154 */       printJobQueueInfo(queue);
/*     */   }
/*     */ 
/*     */   private void displayQueueAclsInfoForCurrentUser() throws IOException
/*     */   {
/* 159 */     QueueAclsInfo[] queueAclsInfoList = this.jc.getQueueAclsForCurrentUser();
/* 160 */     UserGroupInformation ugi = UserGroupInformation.getCurrentUser();
/* 161 */     if (queueAclsInfoList.length > 0) {
/* 162 */       System.out.println("Queue acls for user :  " + ugi.getShortUserName());
/*     */ 
/* 164 */       System.out.println("\nQueue  Operations");
/* 165 */       System.out.println("=====================");
/* 166 */       for (QueueAclsInfo queueInfo : queueAclsInfoList) {
/* 167 */         System.out.print(queueInfo.getQueueName() + "  ");
/* 168 */         String[] ops = queueInfo.getOperations();
/* 169 */         int max = ops.length - 1;
/* 170 */         for (int j = 0; j < ops.length; j++) {
/* 171 */           System.out.print(ops[j].replaceFirst("acl-", ""));
/* 172 */           if (j < max) {
/* 173 */             System.out.print(",");
/*     */           }
/*     */         }
/* 176 */         System.out.println();
/*     */       }
/*     */     } else {
/* 179 */       System.out.println("User " + ugi.getShortUserName() + " does not have access to any queue. \n");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void displayUsage(String cmd)
/*     */   {
/* 186 */     String prefix = "Usage: JobQueueClient ";
/* 187 */     if ("-queueinfo".equals(cmd)) {
/* 188 */       System.err.println(prefix + "[" + cmd + "<job-queue-name> [-showJobs]]");
/*     */     } else {
/* 190 */       System.err.printf(prefix + "<command> <args>\n", new Object[0]);
/* 191 */       System.err.printf("\t[-list]\n", new Object[0]);
/* 192 */       System.err.printf("\t[-info <job-queue-name> [-showJobs]]\n", new Object[0]);
/* 193 */       System.err.printf("\t[-showacls] \n\n", new Object[0]);
/* 194 */       ToolRunner.printGenericCommandUsage(System.out);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] argv) throws Exception {
/* 199 */     int res = ToolRunner.run(new JobQueueClient(), argv);
/* 200 */     System.exit(res);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JobQueueClient
 * JD-Core Version:    0.6.1
 */
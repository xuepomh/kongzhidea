/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.hadoop.mapreduce.JobACL;
/*     */ import org.apache.hadoop.security.AccessControlException;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.authorize.AccessControlList;
/*     */ 
/*     */ class JobACLsManager
/*     */ {
/*     */   JobConf conf;
/*     */ 
/*     */   public JobACLsManager(JobConf conf)
/*     */   {
/*  33 */     this.conf = conf;
/*     */   }
/*     */ 
/*     */   boolean areACLsEnabled() {
/*  37 */     return this.conf.getBoolean("mapred.acls.enabled", false);
/*     */   }
/*     */ 
/*     */   Map<JobACL, AccessControlList> constructJobACLs(JobConf conf)
/*     */   {
/*  49 */     Map acls = new HashMap();
/*     */ 
/*  53 */     if (!areACLsEnabled()) {
/*  54 */       return acls;
/*     */     }
/*     */ 
/*  57 */     for (JobACL aclName : JobACL.values()) {
/*  58 */       String aclConfigName = aclName.getAclName();
/*  59 */       String aclConfigured = conf.get(aclConfigName);
/*  60 */       if (aclConfigured == null)
/*     */       {
/*  63 */         aclConfigured = "";
/*     */       }
/*  65 */       acls.put(aclName, new AccessControlList(aclConfigured));
/*     */     }
/*  67 */     return acls;
/*     */   }
/*     */ 
/*     */   boolean checkAccess(UserGroupInformation callerUGI, JobACL jobOperation, String jobOwner, AccessControlList jobACL)
/*     */     throws AccessControlException
/*     */   {
/*  89 */     String user = callerUGI.getShortUserName();
/*  90 */     if (!areACLsEnabled()) {
/*  91 */       return true;
/*     */     }
/*     */ 
/*  95 */     if ((user.equals(jobOwner)) || (jobACL.isUserAllowed(callerUGI)))
/*     */     {
/*  97 */       return true;
/*     */     }
/*     */ 
/* 100 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JobACLsManager
 * JD-Core Version:    0.6.1
 */
/*      */ package org.apache.hadoop.mapred;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.net.UnknownHostException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Comparator;
/*      */ import java.util.EnumMap;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.IdentityHashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.SortedSet;
/*      */ import java.util.TreeMap;
/*      */ import java.util.TreeSet;
/*      */ import java.util.Vector;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.apache.hadoop.fs.FileStatus;
/*      */ import org.apache.hadoop.fs.FileSystem;
/*      */ import org.apache.hadoop.fs.LocalFileSystem;
/*      */ import org.apache.hadoop.fs.Path;
/*      */ import org.apache.hadoop.io.Text;
/*      */ import org.apache.hadoop.mapreduce.JobStatus.State;
/*      */ import org.apache.hadoop.mapreduce.JobSubmissionFiles;
/*      */ import org.apache.hadoop.mapreduce.TaskType;
/*      */ import org.apache.hadoop.mapreduce.security.token.DelegationTokenRenewal;
/*      */ import org.apache.hadoop.mapreduce.server.jobtracker.TaskTracker;
/*      */ import org.apache.hadoop.mapreduce.split.JobSplit;
/*      */ import org.apache.hadoop.mapreduce.split.JobSplit.TaskSplitMetaInfo;
/*      */ import org.apache.hadoop.mapreduce.split.SplitMetaInfoReader;
/*      */ import org.apache.hadoop.net.NetUtils;
/*      */ import org.apache.hadoop.net.Node;
/*      */ import org.apache.hadoop.security.Credentials;
/*      */ import org.apache.hadoop.security.UserGroupInformation;
/*      */ import org.apache.hadoop.security.token.Token;
/*      */ import org.apache.hadoop.util.StringUtils;
/*      */ 
/*      */ public class JobInProgress
/*      */ {
/*   85 */   static final Log LOG = LogFactory.getLog(JobInProgress.class);
/*      */   JobProfile profile;
/*      */   JobStatus status;
/*   89 */   String jobFile = null;
/*   90 */   Path localJobFile = null;
/*      */   final QueueMetrics queueMetrics;
/*   93 */   TaskInProgress[] maps = new TaskInProgress[0];
/*   94 */   TaskInProgress[] reduces = new TaskInProgress[0];
/*   95 */   TaskInProgress[] cleanup = new TaskInProgress[0];
/*   96 */   TaskInProgress[] setup = new TaskInProgress[0];
/*   97 */   int numMapTasks = 0;
/*   98 */   int numReduceTasks = 0;
/*      */   final long memoryPerMap;
/*      */   final long memoryPerReduce;
/*  101 */   volatile int numSlotsPerMap = 1;
/*  102 */   volatile int numSlotsPerReduce = 1;
/*      */   final int maxTaskFailuresPerTracker;
/*  106 */   int runningMapTasks = 0;
/*  107 */   int runningReduceTasks = 0;
/*  108 */   int finishedMapTasks = 0;
/*  109 */   int finishedReduceTasks = 0;
/*  110 */   int failedMapTasks = 0;
/*  111 */   int failedReduceTasks = 0;
/*  112 */   private static long DEFAULT_REDUCE_INPUT_LIMIT = -1L;
/*  113 */   long reduce_input_limit = -1L;
/*  114 */   private static float DEFAULT_COMPLETED_MAPS_PERCENT_FOR_REDUCE_SLOWSTART = 0.05F;
/*  115 */   int completedMapsForReduceSlowstart = 0;
/*      */ 
/*  119 */   int speculativeMapTasks = 0;
/*  120 */   int speculativeReduceTasks = 0;
/*      */   final int mapFailuresPercent;
/*      */   final int reduceFailuresPercent;
/*  124 */   int failedMapTIPs = 0;
/*  125 */   int failedReduceTIPs = 0;
/*  126 */   private volatile boolean launchedCleanup = false;
/*  127 */   private volatile boolean launchedSetup = false;
/*  128 */   private volatile boolean jobKilled = false;
/*  129 */   private volatile boolean jobFailed = false;
/*      */ 
/*  131 */   JobPriority priority = JobPriority.NORMAL;
/*      */   final JobTracker jobtracker;
/*      */   protected Credentials tokenStorage;
/*      */   Map<Node, List<TaskInProgress>> nonRunningMapCache;
/*      */   Map<Node, Set<TaskInProgress>> runningMapCache;
/*      */   final List<TaskInProgress> nonLocalMaps;
/*      */   final SortedSet<TaskInProgress> failedMaps;
/*      */   Set<TaskInProgress> nonLocalRunningMaps;
/*      */   Set<TaskInProgress> nonRunningReduces;
/*      */   Set<TaskInProgress> runningReduces;
/*  158 */   List<TaskAttemptID> mapCleanupTasks = new LinkedList();
/*      */ 
/*  161 */   List<TaskAttemptID> reduceCleanupTasks = new LinkedList();
/*      */ 
/*  165 */   private static final Comparator<TaskInProgress> failComparator = new Comparator()
/*      */   {
/*      */     public int compare(TaskInProgress t1, TaskInProgress t2)
/*      */     {
/*  169 */       if (t1 == null) return -1;
/*  170 */       if (t2 == null) return 1;
/*      */ 
/*  172 */       int failures = t2.numTaskFailures() - t1.numTaskFailures();
/*  173 */       return failures == 0 ? t1.getTIPId().getId() - t2.getTIPId().getId() : failures;
/*      */     }
/*  165 */   };
/*      */   private final int maxLevel;
/*      */   private final int anyCacheLevel;
/*      */   private volatile long numSchedulingOpportunities;
/*  192 */   static String LOCALITY_WAIT_FACTOR = "mapreduce.job.locality.wait.factor";
/*      */   static final float DEFAULT_LOCALITY_WAIT_FACTOR = 1.0F;
/*  198 */   private float localityWaitFactor = 1.0F;
/*      */   private static final int NON_LOCAL_CACHE_LEVEL = -1;
/*  207 */   private int taskCompletionEventTracker = 0;
/*      */   List<TaskCompletionEvent> taskCompletionEvents;
/*      */   private static final double CLUSTER_BLACKLIST_PERCENT = 0.25D;
/*      */   private static final double MAX_ALLOWED_FETCH_FAILURES_PERCENT = 0.5D;
/*  217 */   private volatile int clusterSize = 0;
/*      */ 
/*  221 */   private volatile int flakyTaskTrackers = 0;
/*      */ 
/*  223 */   private Map<String, Integer> trackerToFailuresMap = new TreeMap();
/*      */   private ResourceEstimator resourceEstimator;
/*      */   long startTime;
/*      */   long launchTime;
/*      */   long finishTime;
/*  234 */   final Map<TaskType, Long> firstTaskLaunchTimes = new EnumMap(TaskType.class);
/*      */   private final int restartCount;
/*      */   private JobConf conf;
/*  241 */   volatile boolean tasksInited = false;
/*  242 */   private JobInitKillStatus jobInitKillStatus = new JobInitKillStatus(null);
/*      */   private LocalFileSystem localFs;
/*      */   private FileSystem fs;
/*      */   private JobID jobId;
/*      */   private volatile boolean hasSpeculativeMaps;
/*      */   private volatile boolean hasSpeculativeReduces;
/*  249 */   private long inputLength = 0L;
/*      */   private String submitHostName;
/*      */   private String submitHostAddress;
/*      */   private String user;
/*  253 */   private String historyFile = "";
/*      */ 
/*  270 */   private Counters jobCounters = new Counters();
/*      */   private static final int MAX_FETCH_FAILURES_NOTIFICATIONS = 3;
/*  277 */   private Map<TaskAttemptID, Integer> mapTaskIdToFetchFailuresMap = new TreeMap();
/*      */   private Object schedulingInfo;
/*  308 */   private Map<TaskTracker, FallowSlotInfo> trackersReservedForMaps = new HashMap();
/*      */ 
/*  310 */   private Map<TaskTracker, FallowSlotInfo> trackersReservedForReduces = new HashMap();
/*      */ 
/*  312 */   private Path jobSubmitDir = null;
/*      */   private final UserGroupInformation userUGI;
/*      */   static final String JOB_INIT_EXCEPTION = "mapreduce.job.init.throw.exception";
/*      */   static final String JT_JOB_INIT_EXCEPTION_OVERRIDE = "mapreduce.jt.job.init.throw.exception.override";
/*  659 */   Object jobInitWaitLockForTests = new Object();
/*      */   private static final long OVERRIDE = 1000000L;
/*      */ 
/*      */   protected JobInProgress(JobID jobid, JobConf conf, JobTracker tracker)
/*      */     throws IOException
/*      */   {
/*  321 */     this.conf = conf;
/*  322 */     this.jobId = jobid;
/*  323 */     this.numMapTasks = conf.getNumMapTasks();
/*  324 */     this.numReduceTasks = conf.getNumReduceTasks();
/*  325 */     this.maxLevel = 2;
/*  326 */     this.anyCacheLevel = (this.maxLevel + 1);
/*  327 */     this.jobtracker = tracker;
/*  328 */     this.restartCount = 0;
/*  329 */     this.hasSpeculativeMaps = conf.getMapSpeculativeExecution();
/*  330 */     this.hasSpeculativeReduces = conf.getReduceSpeculativeExecution();
/*  331 */     this.nonLocalMaps = new LinkedList();
/*  332 */     this.failedMaps = new TreeSet(failComparator);
/*  333 */     this.nonLocalRunningMaps = new LinkedHashSet();
/*  334 */     this.runningMapCache = new IdentityHashMap();
/*  335 */     this.nonRunningReduces = new TreeSet(failComparator);
/*  336 */     this.runningReduces = new LinkedHashSet();
/*  337 */     this.resourceEstimator = new ResourceEstimator(this);
/*  338 */     this.status = new JobStatus(jobid, 0.0F, 0.0F, 4);
/*  339 */     this.status.setUsername(conf.getUser());
/*  340 */     String queueName = conf.getQueueName();
/*  341 */     this.profile = new JobProfile(conf.getUser(), jobid, "", "", conf.getJobName(), queueName);
/*      */ 
/*  343 */     this.memoryPerMap = conf.getMemoryForMapTask();
/*  344 */     this.memoryPerReduce = conf.getMemoryForReduceTask();
/*  345 */     this.maxTaskFailuresPerTracker = conf.getMaxTaskFailuresPerTracker();
/*  346 */     this.mapFailuresPercent = conf.getMaxMapTaskFailuresPercent();
/*  347 */     this.reduceFailuresPercent = conf.getMaxReduceTaskFailuresPercent();
/*      */ 
/*  349 */     Queue queue = this.jobtracker.getQueueManager().getQueue(queueName);
/*  350 */     if (queue == null) {
/*  351 */       throw new IOException("Queue \"" + queueName + "\" does not exist");
/*      */     }
/*  353 */     this.queueMetrics = queue.getMetrics();
/*      */ 
/*  356 */     checkTaskLimits();
/*      */ 
/*  358 */     this.taskCompletionEvents = new ArrayList(this.numMapTasks + this.numReduceTasks + 10);
/*      */     try
/*      */     {
/*  361 */       this.userUGI = UserGroupInformation.getCurrentUser();
/*      */     } catch (IOException ie) {
/*  363 */       throw new RuntimeException(ie);
/*      */     }
/*      */   }
/*      */ 
/*      */   JobInProgress(JobTracker jobtracker, final JobConf default_conf, JobInfo jobInfo, int rCount, Credentials ts) throws IOException, InterruptedException
/*      */   {
/*      */     try
/*      */     {
/*  371 */       this.restartCount = rCount;
/*  372 */       this.jobId = JobID.downgrade(jobInfo.getJobID());
/*  373 */       String url = "http://" + jobtracker.getJobTrackerMachine() + ":" + jobtracker.getInfoPort() + "/jobdetails.jsp?jobid=" + this.jobId;
/*      */ 
/*  375 */       this.jobtracker = jobtracker;
/*  376 */       this.status = new JobStatus(this.jobId, 0.0F, 0.0F, 4);
/*  377 */       this.status.setUsername(jobInfo.getUser().toString());
/*  378 */       this.jobtracker.getInstrumentation().addPrepJob(this.conf, this.jobId);
/*      */ 
/*  380 */       this.startTime = jobtracker.getClock().getTime();
/*  381 */       this.status.setStartTime(this.startTime);
/*  382 */       this.localFs = jobtracker.getLocalFileSystem();
/*      */ 
/*  384 */       this.tokenStorage = ts;
/*      */ 
/*  386 */       this.jobSubmitDir = jobInfo.getJobSubmitDir();
/*  387 */       this.user = jobInfo.getUser().toString();
/*  388 */       this.userUGI = UserGroupInformation.createRemoteUser(this.user);
/*  389 */       if (ts != null) {
/*  390 */         for (Token token : ts.getAllTokens()) {
/*  391 */           this.userUGI.addToken(token);
/*      */         }
/*      */       }
/*      */ 
/*  395 */       this.fs = ((FileSystem)this.userUGI.doAs(new PrivilegedExceptionAction() {
/*      */         public FileSystem run() throws IOException {
/*  397 */           return JobInProgress.this.jobSubmitDir.getFileSystem(default_conf);
/*      */         }
/*      */       }));
/*  401 */       Path submitJobFile = JobSubmissionFiles.getJobConfPath(this.jobSubmitDir);
/*  402 */       FileStatus fstatus = this.fs.getFileStatus(submitJobFile);
/*  403 */       if (fstatus.getLen() > jobtracker.MAX_JOBCONF_SIZE) {
/*  404 */         throw new IOException("Exceeded max jobconf size: " + fstatus.getLen() + " limit: " + jobtracker.MAX_JOBCONF_SIZE);
/*      */       }
/*      */ 
/*  407 */       this.localJobFile = default_conf.getLocalPath("jobTracker/" + this.jobId + ".xml");
/*      */ 
/*  409 */       Path jobFilePath = JobSubmissionFiles.getJobConfPath(this.jobSubmitDir);
/*  410 */       this.jobFile = jobFilePath.toString();
/*  411 */       this.fs.copyToLocalFile(jobFilePath, this.localJobFile);
/*  412 */       this.conf = new JobConf(this.localJobFile);
/*  413 */       if (this.conf.getUser() == null) {
/*  414 */         this.conf.setUser(this.user);
/*      */       }
/*  416 */       if (!this.conf.getUser().equals(this.user)) {
/*  417 */         String desc = "The username " + this.conf.getUser() + " obtained from the " + "conf doesn't match the username " + this.user + " the user " + "authenticated as";
/*      */ 
/*  420 */         AuditLogger.logFailure(this.user, Operation.SUBMIT_JOB.name(), this.conf.getUser(), this.jobId.toString(), desc);
/*      */ 
/*  422 */         throw new IOException(desc);
/*      */       }
/*      */ 
/*  425 */       this.priority = this.conf.getJobPriority();
/*  426 */       this.status.setJobPriority(this.priority);
/*  427 */       String queueName = this.conf.getQueueName();
/*  428 */       this.profile = new JobProfile(this.user, this.jobId, this.jobFile, url, this.conf.getJobName(), queueName);
/*      */ 
/*  431 */       Queue queue = this.jobtracker.getQueueManager().getQueue(queueName);
/*  432 */       if (queue == null) {
/*  433 */         throw new IOException("Queue \"" + queueName + "\" does not exist");
/*      */       }
/*  435 */       this.queueMetrics = queue.getMetrics();
/*  436 */       this.queueMetrics.addPrepJob(this.conf, this.jobId);
/*      */ 
/*  438 */       this.submitHostName = this.conf.getJobSubmitHostName();
/*  439 */       this.submitHostAddress = this.conf.getJobSubmitHostAddress();
/*  440 */       this.numMapTasks = this.conf.getNumMapTasks();
/*  441 */       this.numReduceTasks = this.conf.getNumReduceTasks();
/*      */ 
/*  443 */       this.memoryPerMap = this.conf.getMemoryForMapTask();
/*  444 */       this.memoryPerReduce = this.conf.getMemoryForReduceTask();
/*      */ 
/*  446 */       this.taskCompletionEvents = new ArrayList(this.numMapTasks + this.numReduceTasks + 10);
/*      */ 
/*  450 */       this.status.setJobACLs(jobtracker.getJobACLsManager().constructJobACLs(this.conf));
/*      */ 
/*  452 */       this.mapFailuresPercent = this.conf.getMaxMapTaskFailuresPercent();
/*  453 */       this.reduceFailuresPercent = this.conf.getMaxReduceTaskFailuresPercent();
/*      */ 
/*  455 */       this.maxTaskFailuresPerTracker = this.conf.getMaxTaskFailuresPerTracker();
/*      */ 
/*  457 */       this.hasSpeculativeMaps = this.conf.getMapSpeculativeExecution();
/*  458 */       this.hasSpeculativeReduces = this.conf.getReduceSpeculativeExecution();
/*      */ 
/*  464 */       this.reduce_input_limit = -1L;
/*  465 */       this.maxLevel = jobtracker.getNumTaskCacheLevels();
/*  466 */       this.anyCacheLevel = (this.maxLevel + 1);
/*  467 */       this.nonLocalMaps = new LinkedList();
/*  468 */       this.failedMaps = new TreeSet(failComparator);
/*  469 */       this.nonLocalRunningMaps = new LinkedHashSet();
/*  470 */       this.runningMapCache = new IdentityHashMap();
/*  471 */       this.nonRunningReduces = new TreeSet(failComparator);
/*  472 */       this.runningReduces = new LinkedHashSet();
/*  473 */       this.resourceEstimator = new ResourceEstimator(this);
/*  474 */       this.reduce_input_limit = this.conf.getLong("mapreduce.reduce.input.limit", DEFAULT_REDUCE_INPUT_LIMIT);
/*      */ 
/*  477 */       DelegationTokenRenewal.registerDelegationTokensForRenewal(jobInfo.getJobID(), ts, jobtracker.getConf());
/*      */ 
/*  481 */       checkTaskLimits();
/*      */     }
/*      */     finally
/*      */     {
/*  487 */       FileSystem.closeAllForUGI(UserGroupInformation.getCurrentUser());
/*      */     }
/*      */   }
/*      */ 
/*      */   public QueueMetrics getQueueMetrics()
/*      */   {
/*  496 */     return this.queueMetrics;
/*      */   }
/*      */ 
/*      */   private void checkTaskLimits()
/*      */     throws IOException
/*      */   {
/*  502 */     int maxTasks = this.jobtracker.getMaxTasksPerJob();
/*  503 */     LOG.info(this.jobId + ": nMaps=" + this.numMapTasks + " nReduces=" + this.numReduceTasks + " max=" + maxTasks);
/*  504 */     if ((maxTasks > 0) && (this.numMapTasks + this.numReduceTasks > maxTasks))
/*  505 */       throw new IOException("The number of tasks for this job " + (this.numMapTasks + this.numReduceTasks) + " exceeds the configured limit " + maxTasks);
/*      */   }
/*      */ 
/*      */   public void cleanUpMetrics()
/*      */   {
/*      */   }
/*      */ 
/*      */   private void printCache(Map<Node, List<TaskInProgress>> cache)
/*      */   {
/*  520 */     LOG.info("The taskcache info:");
/*  521 */     for (Map.Entry n : cache.entrySet()) {
/*  522 */       List tips = (List)n.getValue();
/*  523 */       LOG.info("Cached TIPs on node: " + n.getKey());
/*  524 */       for (TaskInProgress tip : tips)
/*  525 */         LOG.info("tip : " + tip.getTIPId());
/*      */     }
/*      */   }
/*      */ 
/*      */   private Map<Node, List<TaskInProgress>> createCache(JobSplit.TaskSplitMetaInfo[] splits, int maxLevel)
/*      */     throws UnknownHostException
/*      */   {
/*  533 */     Map cache = new IdentityHashMap(maxLevel);
/*      */ 
/*  536 */     Set uniqueHosts = new TreeSet();
/*  537 */     for (int i = 0; i < splits.length; i++) {
/*  538 */       String[] splitLocations = splits[i].getLocations();
/*  539 */       if ((splitLocations == null) || (splitLocations.length == 0)) {
/*  540 */         this.nonLocalMaps.add(this.maps[i]);
/*      */       }
/*      */       else
/*      */       {
/*  544 */         for (String host : splitLocations) {
/*  545 */           Node node = this.jobtracker.resolveAndAddToTopology(host);
/*  546 */           uniqueHosts.add(host);
/*  547 */           LOG.info("tip:" + this.maps[i].getTIPId() + " has split on node:" + node);
/*  548 */           for (int j = 0; j < maxLevel; j++) {
/*  549 */             List hostMaps = (List)cache.get(node);
/*  550 */             if (hostMaps == null) {
/*  551 */               hostMaps = new ArrayList();
/*  552 */               cache.put(node, hostMaps);
/*  553 */               hostMaps.add(this.maps[i]);
/*      */             }
/*      */ 
/*  560 */             if (hostMaps.get(hostMaps.size() - 1) != this.maps[i]) {
/*  561 */               hostMaps.add(this.maps[i]);
/*      */             }
/*  563 */             node = node.getParent();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  569 */     if (this.localityWaitFactor == 1.0F) {
/*  570 */       int jobNodes = uniqueHosts.size();
/*  571 */       int clusterNodes = this.jobtracker.getNumberOfUniqueHosts();
/*      */ 
/*  573 */       if (clusterNodes > 0) {
/*  574 */         this.localityWaitFactor = Math.min(jobNodes / clusterNodes, this.localityWaitFactor);
/*      */       }
/*      */ 
/*  577 */       LOG.info(this.jobId + " LOCALITY_WAIT_FACTOR=" + this.localityWaitFactor);
/*      */     }
/*      */ 
/*  580 */     return cache;
/*      */   }
/*      */ 
/*      */   public boolean inited()
/*      */   {
/*  589 */     return this.tasksInited;
/*      */   }
/*      */ 
/*      */   public String getUser()
/*      */   {
/*  596 */     return this.user;
/*      */   }
/*      */ 
/*      */   boolean hasRestarted() {
/*  600 */     return this.restartCount > 0;
/*      */   }
/*      */ 
/*      */   boolean getMapSpeculativeExecution() {
/*  604 */     return this.hasSpeculativeMaps;
/*      */   }
/*      */ 
/*      */   boolean getReduceSpeculativeExecution() {
/*  608 */     return this.hasSpeculativeReduces;
/*      */   }
/*      */ 
/*      */   long getMemoryForMapTask() {
/*  612 */     return this.memoryPerMap;
/*      */   }
/*      */ 
/*      */   long getMemoryForReduceTask() {
/*  616 */     return this.memoryPerReduce;
/*      */   }
/*      */ 
/*      */   int getNumSlotsPerMap()
/*      */   {
/*  624 */     return this.numSlotsPerMap;
/*      */   }
/*      */ 
/*      */   void setNumSlotsPerMap(int numSlotsPerMap)
/*      */   {
/*  633 */     this.numSlotsPerMap = numSlotsPerMap;
/*      */   }
/*      */ 
/*      */   int getNumSlotsPerReduce()
/*      */   {
/*  641 */     return this.numSlotsPerReduce;
/*      */   }
/*      */ 
/*      */   void setNumSlotsPerReduce(int numSlotsPerReduce)
/*      */   {
/*  651 */     this.numSlotsPerReduce = numSlotsPerReduce;
/*      */   }
/*      */ 
/*      */   void signalInitWaitLockForTests()
/*      */   {
/*  662 */     synchronized (this.jobInitWaitLockForTests) {
/*  663 */       this.jobInitWaitLockForTests.notify();
/*      */     }
/*      */   }
/*      */ 
/*      */   void waitForInitWaitLockForTests() {
/*  668 */     synchronized (this.jobInitWaitLockForTests) {
/*      */       try {
/*  670 */         LOG.info("About to wait for jobInitWaitLockForTests");
/*  671 */         this.jobInitWaitLockForTests.wait();
/*  672 */         LOG.info("Done waiting for jobInitWaitLockForTests");
/*      */       }
/*      */       catch (InterruptedException ie)
/*      */       {
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void initTasks()
/*      */     throws IOException, JobInProgress.KillInterruptedException, UnknownHostException
/*      */   {
/*  686 */     if ((!this.jobtracker.getConf().getBoolean("mapreduce.jt.job.init.throw.exception.override", false)) && (getJobConf().getBoolean("mapreduce.job.init.throw.exception", false)))
/*      */     {
/*  689 */       waitForInitWaitLockForTests();
/*      */     }
/*      */ 
/*  692 */     if ((this.tasksInited) || (isComplete())) {
/*  693 */       return;
/*      */     }
/*  695 */     synchronized (this.jobInitKillStatus) {
/*  696 */       if ((this.jobInitKillStatus.killed) || (this.jobInitKillStatus.initStarted)) {
/*  697 */         return;
/*      */       }
/*  699 */       this.jobInitKillStatus.initStarted = true;
/*      */     }
/*      */ 
/*  702 */     LOG.info("Initializing " + this.jobId);
/*  703 */     final long startTimeFinal = this.startTime;
/*      */     try
/*      */     {
/*  706 */       this.userUGI.doAs(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Object run() throws Exception {
/*  709 */           JobHistory.JobInfo.logSubmitted(JobInProgress.this.getJobID(), JobInProgress.this.conf, JobInProgress.this.jobFile, startTimeFinal, JobInProgress.this.hasRestarted());
/*      */ 
/*  711 */           return null;
/*      */         } } );
/*      */     }
/*      */     catch (InterruptedException ie) {
/*  715 */       throw new IOException(ie);
/*      */     }
/*      */ 
/*  719 */     setPriority(this.priority);
/*      */ 
/*  724 */     JobSplit.TaskSplitMetaInfo[] splits = createSplits(this.jobId);
/*  725 */     if (this.numMapTasks != splits.length) {
/*  726 */       throw new IOException("Number of maps in JobConf doesn't match number of recieved splits for job " + this.jobId + "! " + "numMapTasks=" + this.numMapTasks + ", #splits=" + splits.length);
/*      */     }
/*      */ 
/*  730 */     this.numMapTasks = splits.length;
/*      */ 
/*  733 */     for (JobSplit.TaskSplitMetaInfo split : splits) {
/*  734 */       NetUtils.verifyHostnames(split.getLocations());
/*      */     }
/*      */ 
/*  737 */     this.jobtracker.getInstrumentation().addWaitingMaps(getJobID(), this.numMapTasks);
/*  738 */     this.jobtracker.getInstrumentation().addWaitingReduces(getJobID(), this.numReduceTasks);
/*  739 */     this.queueMetrics.addWaitingMaps(getJobID(), this.numMapTasks);
/*  740 */     this.queueMetrics.addWaitingReduces(getJobID(), this.numReduceTasks);
/*      */ 
/*  742 */     this.maps = new TaskInProgress[this.numMapTasks];
/*  743 */     for (int i = 0; i < this.numMapTasks; i++) {
/*  744 */       this.inputLength += splits[i].getInputDataLength();
/*  745 */       this.maps[i] = new TaskInProgress(this.jobId, this.jobFile, splits[i], this.jobtracker, this.conf, this, i, this.numSlotsPerMap);
/*      */     }
/*      */ 
/*  749 */     LOG.info("Input size for job " + this.jobId + " = " + this.inputLength + ". Number of splits = " + splits.length);
/*      */ 
/*  753 */     this.localityWaitFactor = this.conf.getFloat(LOCALITY_WAIT_FACTOR, 1.0F);
/*      */ 
/*  755 */     if (this.numMapTasks > 0) {
/*  756 */       this.nonRunningMapCache = createCache(splits, this.maxLevel);
/*      */     }
/*      */ 
/*  760 */     this.launchTime = this.jobtracker.getClock().getTime();
/*      */ 
/*  765 */     this.reduces = new TaskInProgress[this.numReduceTasks];
/*  766 */     for (int i = 0; i < this.numReduceTasks; i++) {
/*  767 */       this.reduces[i] = new TaskInProgress(this.jobId, this.jobFile, this.numMapTasks, i, this.jobtracker, this.conf, this, this.numSlotsPerReduce);
/*      */ 
/*  770 */       this.nonRunningReduces.add(this.reduces[i]);
/*      */     }
/*      */ 
/*  775 */     this.completedMapsForReduceSlowstart = (int)Math.ceil(this.conf.getFloat("mapred.reduce.slowstart.completed.maps", DEFAULT_COMPLETED_MAPS_PERCENT_FOR_REDUCE_SLOWSTART) * this.numMapTasks);
/*      */ 
/*  782 */     this.resourceEstimator.setThreshhold(this.completedMapsForReduceSlowstart);
/*      */ 
/*  785 */     this.cleanup = new TaskInProgress[2];
/*      */ 
/*  789 */     JobSplit.TaskSplitMetaInfo emptySplit = JobSplit.EMPTY_TASK_SPLIT;
/*  790 */     this.cleanup[0] = new TaskInProgress(this.jobId, this.jobFile, emptySplit, this.jobtracker, this.conf, this, this.numMapTasks, 1);
/*      */ 
/*  792 */     this.cleanup[0].setJobCleanupTask();
/*      */ 
/*  795 */     this.cleanup[1] = new TaskInProgress(this.jobId, this.jobFile, this.numMapTasks, this.numReduceTasks, this.jobtracker, this.conf, this, 1);
/*      */ 
/*  797 */     this.cleanup[1].setJobCleanupTask();
/*      */ 
/*  800 */     this.setup = new TaskInProgress[2];
/*      */ 
/*  804 */     this.setup[0] = new TaskInProgress(this.jobId, this.jobFile, emptySplit, this.jobtracker, this.conf, this, this.numMapTasks + 1, 1);
/*      */ 
/*  806 */     this.setup[0].setJobSetupTask();
/*      */ 
/*  809 */     this.setup[1] = new TaskInProgress(this.jobId, this.jobFile, this.numMapTasks, this.numReduceTasks + 1, this.jobtracker, this.conf, this, 1);
/*      */ 
/*  811 */     this.setup[1].setJobSetupTask();
/*      */ 
/*  813 */     synchronized (this.jobInitKillStatus) {
/*  814 */       this.jobInitKillStatus.initDone = true;
/*      */ 
/*  817 */       this.tasksInited = true;
/*      */ 
/*  819 */       if (this.jobInitKillStatus.killed) {
/*  820 */         throw new KillInterruptedException("Job " + this.jobId + " killed in init");
/*      */       }
/*      */     }
/*      */ 
/*  824 */     JobHistory.JobInfo.logInited(this.profile.getJobID(), this.launchTime, this.numMapTasks, this.numReduceTasks);
/*      */ 
/*  828 */     LOG.info("Job " + this.jobId + " initialized successfully with " + this.numMapTasks + " map tasks and " + this.numReduceTasks + " reduce tasks.");
/*      */   }
/*      */ 
/*      */   JobSplit.TaskSplitMetaInfo[] createSplits(org.apache.hadoop.mapreduce.JobID jobId)
/*      */     throws IOException
/*      */   {
/*  834 */     JobSplit.TaskSplitMetaInfo[] allTaskSplitMetaInfo = SplitMetaInfoReader.readSplitMetaInfo(jobId, this.fs, this.jobtracker.getConf(), this.jobSubmitDir);
/*      */ 
/*  837 */     return allTaskSplitMetaInfo;
/*      */   }
/*      */ 
/*      */   public JobProfile getProfile()
/*      */   {
/*  844 */     return this.profile;
/*      */   }
/*      */   public JobStatus getStatus() {
/*  847 */     return this.status;
/*      */   }
/*      */   public synchronized long getLaunchTime() {
/*  850 */     return this.launchTime;
/*      */   }
/*      */   Map<TaskType, Long> getFirstTaskLaunchTimes() {
/*  853 */     return this.firstTaskLaunchTimes;
/*      */   }
/*      */   public long getStartTime() {
/*  856 */     return this.startTime;
/*      */   }
/*      */   public long getFinishTime() {
/*  859 */     return this.finishTime;
/*      */   }
/*      */   public int desiredMaps() {
/*  862 */     return this.numMapTasks;
/*      */   }
/*      */   public synchronized int finishedMaps() {
/*  865 */     return this.finishedMapTasks;
/*      */   }
/*      */   public int desiredReduces() {
/*  868 */     return this.numReduceTasks;
/*      */   }
/*      */   public synchronized int runningMaps() {
/*  871 */     return this.runningMapTasks;
/*      */   }
/*      */   public synchronized int runningReduces() {
/*  874 */     return this.runningReduceTasks;
/*      */   }
/*      */   public synchronized int finishedReduces() {
/*  877 */     return this.finishedReduceTasks;
/*      */   }
/*      */   public synchronized int pendingMaps() {
/*  880 */     return this.numMapTasks - this.runningMapTasks - this.failedMapTIPs - this.finishedMapTasks + this.speculativeMapTasks;
/*      */   }
/*      */ 
/*      */   public synchronized int pendingReduces() {
/*  884 */     return this.numReduceTasks - this.runningReduceTasks - this.failedReduceTIPs - this.finishedReduceTasks + this.speculativeReduceTasks;
/*      */   }
/*      */ 
/*      */   public int desiredTasks()
/*      */   {
/*  893 */     return desiredMaps() + desiredReduces();
/*      */   }
/*      */ 
/*      */   public int getNumSlotsPerTask(TaskType taskType) {
/*  897 */     if (taskType == TaskType.MAP)
/*  898 */       return this.numSlotsPerMap;
/*  899 */     if (taskType == TaskType.REDUCE) {
/*  900 */       return this.numSlotsPerReduce;
/*      */     }
/*  902 */     return 1;
/*      */   }
/*      */ 
/*      */   public JobPriority getPriority() {
/*  906 */     return this.priority;
/*      */   }
/*      */   public void setPriority(JobPriority priority) {
/*  909 */     if (priority == null)
/*  910 */       this.priority = JobPriority.NORMAL;
/*      */     else {
/*  912 */       this.priority = priority;
/*      */     }
/*  914 */     synchronized (this) {
/*  915 */       this.status.setJobPriority(priority);
/*      */     }
/*      */ 
/*  918 */     JobHistory.JobInfo.logJobPriority(this.jobId, priority);
/*      */   }
/*      */ 
/*      */   synchronized void updateJobInfo(long startTime, long launchTime)
/*      */   {
/*  924 */     this.startTime = startTime;
/*  925 */     this.launchTime = launchTime;
/*  926 */     JobHistory.JobInfo.logJobInfo(this.jobId, startTime, launchTime);
/*      */   }
/*      */ 
/*      */   int getNumRestarts()
/*      */   {
/*  933 */     return this.restartCount;
/*      */   }
/*      */ 
/*      */   long getInputLength() {
/*  937 */     return this.inputLength;
/*      */   }
/*      */ 
/*      */   boolean isCleanupLaunched() {
/*  941 */     return this.launchedCleanup;
/*      */   }
/*      */ 
/*      */   boolean isSetupLaunched() {
/*  945 */     return this.launchedSetup;
/*      */   }
/*      */ 
/*      */   TaskInProgress[] getTasks(TaskType type)
/*      */   {
/*  955 */     TaskInProgress[] tasks = null;
/*  956 */     switch (4.$SwitchMap$org$apache$hadoop$mapreduce$TaskType[type.ordinal()])
/*      */     {
/*      */     case 1:
/*  959 */       tasks = this.maps;
/*      */ 
/*  961 */       break;
/*      */     case 2:
/*  964 */       tasks = this.reduces;
/*      */ 
/*  966 */       break;
/*      */     case 3:
/*  969 */       tasks = this.setup;
/*      */ 
/*  971 */       break;
/*      */     case 4:
/*  974 */       tasks = this.cleanup;
/*      */ 
/*  976 */       break;
/*      */     default:
/*  979 */       tasks = new TaskInProgress[0];
/*      */     }
/*      */ 
/*  984 */     return tasks;
/*      */   }
/*      */ 
/*      */   Set<TaskInProgress> getNonLocalRunningMaps()
/*      */   {
/*  993 */     return this.nonLocalRunningMaps;
/*      */   }
/*      */ 
/*      */   Map<Node, Set<TaskInProgress>> getRunningMapCache()
/*      */   {
/* 1002 */     return this.runningMapCache;
/*      */   }
/*      */ 
/*      */   Set<TaskInProgress> getRunningReduces()
/*      */   {
/* 1011 */     return this.runningReduces;
/*      */   }
/*      */ 
/*      */   JobConf getJobConf()
/*      */   {
/* 1019 */     return this.conf;
/*      */   }
/*      */ 
/*      */   public synchronized Vector<TaskInProgress> reportTasksInProgress(boolean shouldBeMap, boolean shouldBeComplete)
/*      */   {
/* 1028 */     Vector results = new Vector();
/* 1029 */     TaskInProgress[] tips = null;
/* 1030 */     if (shouldBeMap)
/* 1031 */       tips = this.maps;
/*      */     else {
/* 1033 */       tips = this.reduces;
/*      */     }
/* 1035 */     for (int i = 0; i < tips.length; i++) {
/* 1036 */       if (tips[i].isComplete() == shouldBeComplete) {
/* 1037 */         results.add(tips[i]);
/*      */       }
/*      */     }
/* 1040 */     return results;
/*      */   }
/*      */ 
/*      */   public synchronized Vector<TaskInProgress> reportCleanupTIPs(boolean shouldBeComplete)
/*      */   {
/* 1049 */     Vector results = new Vector();
/* 1050 */     for (int i = 0; i < this.cleanup.length; i++) {
/* 1051 */       if (this.cleanup[i].isComplete() == shouldBeComplete) {
/* 1052 */         results.add(this.cleanup[i]);
/*      */       }
/*      */     }
/* 1055 */     return results;
/*      */   }
/*      */ 
/*      */   public synchronized Vector<TaskInProgress> reportSetupTIPs(boolean shouldBeComplete)
/*      */   {
/* 1064 */     Vector results = new Vector();
/* 1065 */     for (int i = 0; i < this.setup.length; i++) {
/* 1066 */       if (this.setup[i].isComplete() == shouldBeComplete) {
/* 1067 */         results.add(this.setup[i]);
/*      */       }
/*      */     }
/* 1070 */     return results;
/*      */   }
/*      */ 
/*      */   public synchronized void updateTaskStatus(TaskInProgress tip, TaskStatus status)
/*      */   {
/* 1084 */     double oldProgress = tip.getProgress();
/* 1085 */     boolean wasRunning = tip.isRunning();
/* 1086 */     boolean wasComplete = tip.isComplete();
/* 1087 */     boolean wasPending = tip.isOnlyCommitPending();
/* 1088 */     TaskAttemptID taskid = status.getTaskID();
/* 1089 */     boolean wasAttemptRunning = tip.isAttemptRunning(taskid);
/*      */ 
/* 1097 */     if (((wasComplete) || (tip.wasKilled(taskid))) && (status.getRunState() == TaskStatus.State.SUCCEEDED))
/*      */     {
/* 1099 */       status.setRunState(TaskStatus.State.KILLED);
/*      */     }
/*      */ 
/* 1107 */     if (((isComplete()) || (this.jobFailed) || (this.jobKilled)) && (!tip.isCleanupAttempt(taskid)))
/*      */     {
/* 1109 */       if (status.getRunState() == TaskStatus.State.FAILED_UNCLEAN)
/* 1110 */         status.setRunState(TaskStatus.State.FAILED);
/* 1111 */       else if (status.getRunState() == TaskStatus.State.KILLED_UNCLEAN) {
/* 1112 */         status.setRunState(TaskStatus.State.KILLED);
/*      */       }
/*      */     }
/*      */ 
/* 1116 */     boolean change = tip.updateStatus(status);
/* 1117 */     if (change) {
/* 1118 */       TaskStatus.State state = status.getRunState();
/*      */ 
/* 1120 */       TaskTracker taskTracker = this.jobtracker.getTaskTracker(tip.machineWhereTaskRan(taskid));
/*      */ 
/* 1122 */       TaskTrackerStatus ttStatus = taskTracker == null ? null : taskTracker.getStatus();
/*      */ 
/* 1124 */       String httpTaskLogLocation = null;
/*      */ 
/* 1126 */       if (null != ttStatus)
/*      */       {
/*      */         String host;
/*      */         String host;
/* 1128 */         if (NetUtils.getStaticResolution(ttStatus.getHost()) != null)
/* 1129 */           host = NetUtils.getStaticResolution(ttStatus.getHost());
/*      */         else {
/* 1131 */           host = ttStatus.getHost();
/*      */         }
/* 1133 */         httpTaskLogLocation = "http://" + host + ":" + ttStatus.getHttpPort();
/*      */       }
/*      */ 
/* 1137 */       TaskCompletionEvent taskEvent = null;
/* 1138 */       if (state == TaskStatus.State.SUCCEEDED) {
/* 1139 */         taskEvent = new TaskCompletionEvent(this.taskCompletionEventTracker, taskid, tip.idWithinJob(), (status.getIsMap()) && (!tip.isJobCleanupTask()) && (!tip.isJobSetupTask()), TaskCompletionEvent.Status.SUCCEEDED, httpTaskLogLocation);
/*      */ 
/* 1149 */         taskEvent.setTaskRunTime((int)(status.getFinishTime() - status.getStartTime()));
/*      */ 
/* 1151 */         tip.setSuccessEventNumber(this.taskCompletionEventTracker); } else {
/* 1152 */         if (state == TaskStatus.State.COMMIT_PENDING)
/*      */         {
/* 1155 */           if ((!wasComplete) && (!wasPending)) {
/* 1156 */             tip.doCommit(taskid);
/*      */           }
/* 1158 */           return;
/* 1159 */         }if ((state == TaskStatus.State.FAILED_UNCLEAN) || (state == TaskStatus.State.KILLED_UNCLEAN))
/*      */         {
/* 1161 */           tip.incompleteSubTask(taskid, this.status);
/*      */ 
/* 1163 */           if (tip.isMapTask())
/* 1164 */             this.mapCleanupTasks.add(taskid);
/*      */           else {
/* 1166 */             this.reduceCleanupTasks.add(taskid);
/*      */           }
/*      */ 
/* 1169 */           this.jobtracker.removeTaskEntry(taskid);
/*      */         }
/* 1172 */         else if ((state == TaskStatus.State.FAILED) || (state == TaskStatus.State.KILLED))
/*      */         {
/*      */           int eventNumber;
/* 1177 */           if ((eventNumber = tip.getSuccessEventNumber()) != -1) {
/* 1178 */             TaskCompletionEvent t = (TaskCompletionEvent)this.taskCompletionEvents.get(eventNumber);
/*      */ 
/* 1180 */             if (t.getTaskAttemptId().equals(taskid)) {
/* 1181 */               t.setTaskStatus(TaskCompletionEvent.Status.OBSOLETE);
/*      */             }
/*      */           }
/*      */ 
/* 1185 */           failedTask(tip, taskid, status, taskTracker, wasRunning, wasComplete, wasAttemptRunning);
/*      */ 
/* 1189 */           TaskCompletionEvent.Status taskCompletionStatus = state == TaskStatus.State.FAILED ? TaskCompletionEvent.Status.FAILED : TaskCompletionEvent.Status.KILLED;
/*      */ 
/* 1193 */           if (tip.isFailed()) {
/* 1194 */             taskCompletionStatus = TaskCompletionEvent.Status.TIPFAILED;
/*      */           }
/* 1196 */           taskEvent = new TaskCompletionEvent(this.taskCompletionEventTracker, taskid, tip.idWithinJob(), (status.getIsMap()) && (!tip.isJobCleanupTask()) && (!tip.isJobSetupTask()), taskCompletionStatus, httpTaskLogLocation);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1213 */       if (taskEvent != null) {
/* 1214 */         this.taskCompletionEvents.add(taskEvent);
/* 1215 */         this.taskCompletionEventTracker += 1;
/* 1216 */         JobTrackerStatistics.TaskTrackerStat ttStat = this.jobtracker.getStatistics().getTaskTrackerStat(tip.machineWhereTaskRan(taskid));
/*      */ 
/* 1218 */         if (ttStat != null) {
/* 1219 */           ttStat.incrTotalTasks();
/*      */         }
/* 1221 */         if (state == TaskStatus.State.SUCCEEDED) {
/* 1222 */           completedTask(tip, status);
/* 1223 */           if (ttStat != null) {
/* 1224 */             ttStat.incrSucceededTasks();
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1233 */     if (LOG.isDebugEnabled()) {
/* 1234 */       LOG.debug("Taking progress for " + tip.getTIPId() + " from " + oldProgress + " to " + tip.getProgress());
/*      */     }
/*      */ 
/* 1238 */     if ((!tip.isJobCleanupTask()) && (!tip.isJobSetupTask())) {
/* 1239 */       double progressDelta = tip.getProgress() - oldProgress;
/* 1240 */       if (tip.isMapTask()) {
/* 1241 */         this.status.setMapProgress((float)(this.status.mapProgress() + progressDelta / this.maps.length));
/*      */       }
/*      */       else
/* 1244 */         this.status.setReduceProgress((float)(this.status.reduceProgress() + progressDelta / this.reduces.length));
/*      */     }
/*      */   }
/*      */ 
/*      */   String getHistoryFile()
/*      */   {
/* 1251 */     return this.historyFile;
/*      */   }
/*      */ 
/*      */   synchronized void setHistoryFile(String file) {
/* 1255 */     this.historyFile = file;
/*      */   }
/*      */ 
/*      */   public synchronized Counters getJobCounters()
/*      */   {
/* 1264 */     return this.jobCounters;
/*      */   }
/*      */ 
/*      */   public synchronized boolean getMapCounters(Counters counters)
/*      */   {
/*      */     try
/*      */     {
/* 1273 */       counters = incrementTaskCounters(counters, this.maps);
/*      */     } catch (Counters.CountersExceededException ce) {
/* 1275 */       LOG.info("Counters Exceeded for Job: " + this.jobId, ce);
/* 1276 */       return false;
/*      */     }
/* 1278 */     return true;
/*      */   }
/*      */ 
/*      */   public synchronized boolean getReduceCounters(Counters counters)
/*      */   {
/*      */     try
/*      */     {
/* 1287 */       counters = incrementTaskCounters(counters, this.reduces);
/*      */     } catch (Counters.CountersExceededException ce) {
/* 1289 */       LOG.info("Counters Exceeded for Job: " + this.jobId, ce);
/* 1290 */       return false;
/*      */     }
/* 1292 */     return true;
/*      */   }
/*      */ 
/*      */   public synchronized boolean getCounters(Counters result)
/*      */   {
/*      */     try
/*      */     {
/* 1302 */       result.incrAllCounters(getJobCounters());
/* 1303 */       incrementTaskCounters(result, this.maps);
/* 1304 */       incrementTaskCounters(result, this.reduces);
/*      */     } catch (Counters.CountersExceededException ce) {
/* 1306 */       LOG.info("Counters Exceeded for Job: " + this.jobId, ce);
/* 1307 */       return false;
/*      */     }
/* 1309 */     return true;
/*      */   }
/*      */ 
/*      */   private Counters incrementTaskCounters(Counters counters, TaskInProgress[] tips)
/*      */   {
/* 1320 */     for (TaskInProgress tip : tips) {
/* 1321 */       counters.incrAllCounters(tip.getCounters());
/*      */     }
/* 1323 */     return counters;
/*      */   }
/*      */ 
/*      */   public synchronized Task obtainNewMapTask(TaskTrackerStatus tts, int clusterSize, int numUniqueHosts)
/*      */     throws IOException
/*      */   {
/* 1336 */     return obtainNewMapTaskCommon(tts, clusterSize, numUniqueHosts, this.anyCacheLevel);
/*      */   }
/*      */ 
/*      */   public synchronized Task obtainNewMapTaskCommon(TaskTrackerStatus tts, int clusterSize, int numUniqueHosts, int maxCacheLevel)
/*      */     throws IOException
/*      */   {
/* 1356 */     if (!this.tasksInited) {
/* 1357 */       LOG.info("Cannot create task split for " + this.profile.getJobID());
/*      */       try { throw new IOException("state = " + this.status.getRunState()); } catch (IOException ioe) {
/* 1359 */         ioe.printStackTrace();
/* 1360 */         return null;
/*      */       }
/*      */     }
/* 1363 */     int target = findNewMapTask(tts, clusterSize, numUniqueHosts, maxCacheLevel, this.status.mapProgress());
/*      */ 
/* 1365 */     if (target == -1) {
/* 1366 */       return null;
/*      */     }
/*      */ 
/* 1369 */     Task result = this.maps[target].getTaskToRun(tts.getTrackerName());
/* 1370 */     if (result != null) {
/* 1371 */       addRunningTaskToTIP(this.maps[target], result.getTaskID(), tts, true);
/*      */ 
/* 1373 */       if (maxCacheLevel != -1) {
/* 1374 */         resetSchedulingOpportunities();
/*      */       }
/*      */     }
/* 1377 */     return result;
/*      */   }
/*      */ 
/*      */   public Task obtainTaskCleanupTask(TaskTrackerStatus tts, boolean isMapSlot)
/*      */     throws IOException
/*      */   {
/* 1386 */     if (!this.tasksInited) {
/* 1387 */       return null;
/*      */     }
/* 1389 */     synchronized (this) {
/* 1390 */       if ((this.status.getRunState() != 1) || (this.jobFailed) || (this.jobKilled))
/*      */       {
/* 1392 */         return null;
/*      */       }
/* 1394 */       String taskTracker = tts.getTrackerName();
/* 1395 */       if (!shouldRunOnTaskTracker(taskTracker)) {
/* 1396 */         return null;
/*      */       }
/* 1398 */       TaskAttemptID taskid = null;
/* 1399 */       TaskInProgress tip = null;
/* 1400 */       if (isMapSlot) {
/* 1401 */         if (!this.mapCleanupTasks.isEmpty()) {
/* 1402 */           taskid = (TaskAttemptID)this.mapCleanupTasks.remove(0);
/* 1403 */           tip = this.maps[taskid.getTaskID().getId()];
/*      */         }
/*      */       }
/* 1406 */       else if (!this.reduceCleanupTasks.isEmpty()) {
/* 1407 */         taskid = (TaskAttemptID)this.reduceCleanupTasks.remove(0);
/* 1408 */         tip = this.reduces[taskid.getTaskID().getId()];
/*      */       }
/*      */ 
/* 1411 */       if (tip != null) {
/* 1412 */         return tip.addRunningTask(taskid, taskTracker, true);
/*      */       }
/* 1414 */       return null;
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized Task obtainNewNodeLocalMapTask(TaskTrackerStatus tts, int clusterSize, int numUniqueHosts)
/*      */     throws IOException
/*      */   {
/* 1422 */     return obtainNewMapTaskCommon(tts, clusterSize, numUniqueHosts, 1);
/*      */   }
/*      */ 
/*      */   public synchronized Task obtainNewNodeOrRackLocalMapTask(TaskTrackerStatus tts, int clusterSize, int numUniqueHosts)
/*      */     throws IOException
/*      */   {
/* 1428 */     return obtainNewMapTaskCommon(tts, clusterSize, numUniqueHosts, this.maxLevel);
/*      */   }
/*      */ 
/*      */   public synchronized Task obtainNewNonLocalMapTask(TaskTrackerStatus tts, int clusterSize, int numUniqueHosts)
/*      */     throws IOException
/*      */   {
/* 1435 */     return obtainNewMapTaskCommon(tts, clusterSize, numUniqueHosts, -1);
/*      */   }
/*      */ 
/*      */   public void schedulingOpportunity()
/*      */   {
/* 1440 */     this.numSchedulingOpportunities += 1L;
/*      */   }
/*      */ 
/*      */   public void resetSchedulingOpportunities() {
/* 1444 */     this.numSchedulingOpportunities = 0L;
/*      */   }
/*      */ 
/*      */   public long getNumSchedulingOpportunities() {
/* 1448 */     return this.numSchedulingOpportunities;
/*      */   }
/*      */ 
/*      */   public void overrideSchedulingOpportunities()
/*      */   {
/* 1453 */     this.numSchedulingOpportunities = 1000000L;
/*      */   }
/*      */ 
/*      */   public boolean scheduleOffSwitch(int numTaskTrackers)
/*      */   {
/* 1466 */     long missedTaskTrackers = getNumSchedulingOpportunities();
/* 1467 */     long requiredSlots = Math.min(desiredMaps() - finishedMaps(), numTaskTrackers);
/*      */ 
/* 1470 */     return (float)requiredSlots * this.localityWaitFactor < (float)missedTaskTrackers;
/*      */   }
/*      */ 
/*      */   public Task obtainJobCleanupTask(TaskTrackerStatus tts, int clusterSize, int numUniqueHosts, boolean isMapSlot)
/*      */     throws IOException
/*      */   {
/* 1482 */     if (!this.tasksInited) {
/* 1483 */       return null;
/*      */     }
/*      */ 
/* 1486 */     synchronized (this) {
/* 1487 */       if (!canLaunchJobCleanupTask()) {
/* 1488 */         return null;
/*      */       }
/*      */ 
/* 1491 */       String taskTracker = tts.getTrackerName();
/*      */ 
/* 1493 */       this.clusterSize = clusterSize;
/* 1494 */       if (!shouldRunOnTaskTracker(taskTracker)) {
/* 1495 */         return null;
/*      */       }
/*      */ 
/* 1498 */       List cleanupTaskList = new ArrayList();
/* 1499 */       if (isMapSlot)
/* 1500 */         cleanupTaskList.add(this.cleanup[0]);
/*      */       else {
/* 1502 */         cleanupTaskList.add(this.cleanup[1]);
/*      */       }
/* 1504 */       TaskInProgress tip = findTaskFromList(cleanupTaskList, tts, numUniqueHosts, false);
/*      */ 
/* 1506 */       if (tip == null) {
/* 1507 */         return null;
/*      */       }
/*      */ 
/* 1511 */       Task result = tip.getTaskToRun(tts.getTrackerName());
/*      */ 
/* 1513 */       if (result != null) {
/* 1514 */         addRunningTaskToTIP(tip, result.getTaskID(), tts, true);
/* 1515 */         if (this.jobFailed) {
/* 1516 */           result.setJobCleanupTaskState(JobStatus.State.FAILED);
/*      */         }
/* 1518 */         else if (this.jobKilled) {
/* 1519 */           result.setJobCleanupTaskState(JobStatus.State.KILLED);
/*      */         }
/*      */         else {
/* 1522 */           result.setJobCleanupTaskState(JobStatus.State.SUCCEEDED);
/*      */         }
/*      */       }
/*      */ 
/* 1526 */       return result;
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized boolean canLaunchJobCleanupTask()
/*      */   {
/* 1541 */     if ((this.status.getRunState() != 1) && (this.status.getRunState() != 4))
/*      */     {
/* 1543 */       return false;
/*      */     }
/*      */ 
/* 1548 */     if ((this.launchedCleanup) || (!isSetupFinished())) {
/* 1549 */       return false;
/*      */     }
/*      */ 
/* 1552 */     if ((this.jobKilled) || (this.jobFailed)) {
/* 1553 */       return true;
/*      */     }
/*      */ 
/* 1556 */     boolean launchCleanupTask = this.finishedMapTasks + this.failedMapTIPs == this.numMapTasks;
/*      */ 
/* 1558 */     if (launchCleanupTask) {
/* 1559 */       launchCleanupTask = this.finishedReduceTasks + this.failedReduceTIPs == this.numReduceTasks;
/*      */     }
/*      */ 
/* 1562 */     return launchCleanupTask;
/*      */   }
/*      */ 
/*      */   public Task obtainJobSetupTask(TaskTrackerStatus tts, int clusterSize, int numUniqueHosts, boolean isMapSlot)
/*      */     throws IOException
/*      */   {
/* 1574 */     if (!this.tasksInited) {
/* 1575 */       return null;
/*      */     }
/*      */ 
/* 1578 */     synchronized (this) {
/* 1579 */       if (!canLaunchSetupTask()) {
/* 1580 */         return null;
/*      */       }
/* 1582 */       String taskTracker = tts.getTrackerName();
/*      */ 
/* 1584 */       this.clusterSize = clusterSize;
/* 1585 */       if (!shouldRunOnTaskTracker(taskTracker)) {
/* 1586 */         return null;
/*      */       }
/*      */ 
/* 1589 */       List setupTaskList = new ArrayList();
/* 1590 */       if (isMapSlot)
/* 1591 */         setupTaskList.add(this.setup[0]);
/*      */       else {
/* 1593 */         setupTaskList.add(this.setup[1]);
/*      */       }
/* 1595 */       TaskInProgress tip = findTaskFromList(setupTaskList, tts, numUniqueHosts, false);
/*      */ 
/* 1597 */       if (tip == null) {
/* 1598 */         return null;
/*      */       }
/*      */ 
/* 1602 */       Task result = tip.getTaskToRun(tts.getTrackerName());
/* 1603 */       if (result != null) {
/* 1604 */         addRunningTaskToTIP(tip, result.getTaskID(), tts, true);
/*      */       }
/* 1606 */       return result;
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized boolean scheduleReduces() {
/* 1611 */     return this.finishedMapTasks + this.failedMapTIPs >= this.completedMapsForReduceSlowstart;
/*      */   }
/*      */ 
/*      */   private synchronized boolean canLaunchSetupTask()
/*      */   {
/* 1624 */     return (this.tasksInited) && (this.status.getRunState() == 4) && (!this.launchedSetup) && (!this.jobKilled) && (!this.jobFailed);
/*      */   }
/*      */ 
/*      */   public synchronized Task obtainNewReduceTask(TaskTrackerStatus tts, int clusterSize, int numUniqueHosts)
/*      */     throws IOException
/*      */   {
/* 1638 */     if (this.status.getRunState() != 1) {
/* 1639 */       LOG.info("Cannot create task split for " + this.profile.getJobID());
/* 1640 */       return null;
/*      */     }
/*      */ 
/* 1648 */     long estimatedReduceInputSize = this.resourceEstimator.getEstimatedReduceInputSize() / 2L;
/* 1649 */     if ((estimatedReduceInputSize > this.reduce_input_limit) && (this.reduce_input_limit > 0L))
/*      */     {
/* 1652 */       LOG.info("Exceeded limit for reduce input size: Estimated:" + estimatedReduceInputSize + " Limit: " + this.reduce_input_limit + " Failing Job " + this.jobId);
/*      */ 
/* 1655 */       this.status.setFailureInfo("Job exceeded Reduce Input limit  Limit:  " + this.reduce_input_limit + " Estimated: " + estimatedReduceInputSize);
/*      */ 
/* 1658 */       this.jobtracker.failJob(this);
/* 1659 */       return null;
/*      */     }
/*      */ 
/* 1664 */     if (!scheduleReduces()) {
/* 1665 */       return null;
/*      */     }
/*      */ 
/* 1668 */     int target = findNewReduceTask(tts, clusterSize, numUniqueHosts, this.status.reduceProgress());
/*      */ 
/* 1670 */     if (target == -1) {
/* 1671 */       return null;
/*      */     }
/*      */ 
/* 1674 */     Task result = this.reduces[target].getTaskToRun(tts.getTrackerName());
/* 1675 */     if (result != null) {
/* 1676 */       addRunningTaskToTIP(this.reduces[target], result.getTaskID(), tts, true);
/*      */     }
/*      */ 
/* 1679 */     return result;
/*      */   }
/*      */ 
/*      */   private int getMatchingLevelForNodes(Node n1, Node n2)
/*      */   {
/* 1684 */     return getMatchingLevelForNodes(n1, n2, this.maxLevel);
/*      */   }
/*      */ 
/*      */   static int getMatchingLevelForNodes(Node n1, Node n2, int maxLevel) {
/* 1688 */     int count = 0;
/*      */ 
/* 1694 */     int level1 = n1.getLevel(); int level2 = n2.getLevel();
/* 1695 */     while ((n1 != null) && (level1 > level2)) {
/* 1696 */       n1 = n1.getParent();
/* 1697 */       level1--;
/* 1698 */       count++;
/*      */     }
/* 1700 */     while ((n2 != null) && (level2 > level1)) {
/* 1701 */       n2 = n2.getParent();
/* 1702 */       level2--;
/* 1703 */       count++;
/*      */     }
/*      */     do
/*      */     {
/* 1707 */       if ((n1.equals(n2)) || (count >= maxLevel)) {
/* 1708 */         return Math.min(count, maxLevel);
/*      */       }
/* 1710 */       count++;
/* 1711 */       n1 = n1.getParent();
/* 1712 */       n2 = n2.getParent();
/* 1713 */     }while (n1 != null);
/* 1714 */     return maxLevel;
/*      */   }
/*      */ 
/*      */   synchronized void addRunningTaskToTIP(TaskInProgress tip, TaskAttemptID id, TaskTrackerStatus tts, boolean isScheduled)
/*      */   {
/* 1733 */     if (!isScheduled) {
/* 1734 */       tip.addRunningTask(id, tts.getTrackerName());
/*      */     }
/* 1736 */     JobTrackerInstrumentation metrics = this.jobtracker.getInstrumentation();
/*      */ 
/* 1740 */     String splits = "";
/* 1741 */     Enum counter = null;
/*      */     String name;
/*      */     String name;
/* 1742 */     if (tip.isJobSetupTask()) {
/* 1743 */       this.launchedSetup = true;
/* 1744 */       name = JobHistory.Values.SETUP.name();
/*      */     }
/*      */     else
/*      */     {
/*      */       String name;
/* 1745 */       if (tip.isJobCleanupTask()) {
/* 1746 */         this.launchedCleanup = true;
/* 1747 */         name = JobHistory.Values.CLEANUP.name();
/* 1748 */       } else if (tip.isMapTask()) {
/* 1749 */         this.runningMapTasks += 1;
/* 1750 */         String name = JobHistory.Values.MAP.name();
/* 1751 */         counter = Counter.TOTAL_LAUNCHED_MAPS;
/* 1752 */         splits = tip.getSplitNodes();
/* 1753 */         if (tip.getActiveTasks().size() > 1)
/* 1754 */           this.speculativeMapTasks += 1;
/* 1755 */         metrics.launchMap(id);
/* 1756 */         this.queueMetrics.launchMap(id);
/*      */       } else {
/* 1758 */         this.runningReduceTasks += 1;
/* 1759 */         name = JobHistory.Values.REDUCE.name();
/* 1760 */         counter = Counter.TOTAL_LAUNCHED_REDUCES;
/* 1761 */         if (tip.getActiveTasks().size() > 1)
/* 1762 */           this.speculativeReduceTasks += 1;
/* 1763 */         metrics.launchReduce(id);
/* 1764 */         this.queueMetrics.launchReduce(id);
/*      */       }
/*      */     }
/*      */ 
/* 1768 */     if (tip.isFirstAttempt(id)) {
/* 1769 */       JobHistory.Task.logStarted(tip.getTIPId(), name, tip.getExecStartTime(), splits);
/*      */ 
/* 1771 */       setFirstTaskLaunchTime(tip);
/*      */     }
/* 1773 */     if ((!tip.isJobSetupTask()) && (!tip.isJobCleanupTask())) {
/* 1774 */       this.jobCounters.incrCounter(counter, 1L);
/*      */     }
/*      */ 
/* 1788 */     Locality locality = Locality.OFF_SWITCH;
/* 1789 */     if ((tip.isMapTask()) && (!tip.isJobSetupTask()) && (!tip.isJobCleanupTask()))
/*      */     {
/* 1791 */       Node tracker = this.jobtracker.getNode(tts.getHost());
/* 1792 */       int level = this.maxLevel;
/*      */ 
/* 1794 */       for (String local : this.maps[tip.getIdWithinJob()].getSplitLocations()) {
/* 1795 */         Node datanode = this.jobtracker.getNode(local);
/* 1796 */         int newLevel = this.maxLevel;
/* 1797 */         if ((tracker != null) && (datanode != null)) {
/* 1798 */           newLevel = getMatchingLevelForNodes(tracker, datanode);
/*      */         }
/* 1800 */         if (newLevel < level) {
/* 1801 */           level = newLevel;
/*      */ 
/* 1803 */           if (level == 0) {
/*      */             break;
/*      */           }
/*      */         }
/*      */       }
/* 1808 */       locality = logAndIncreJobCounters(tip, level, this.jobtracker.isNodeGroupAware());
/*      */     }
/*      */ 
/* 1811 */     tip.setTaskAttemptLocality(id, locality);
/*      */ 
/* 1814 */     Avataar avataar = tip.getActiveTasks().size() > 1 ? Avataar.SPECULATIVE : Avataar.VIRGIN;
/*      */ 
/* 1816 */     tip.setTaskAttemptAvataar(id, avataar);
/*      */   }
/*      */ 
/*      */   private Locality logAndIncreJobCounters(TaskInProgress tip, int level, boolean isNodeGroupAware)
/*      */   {
/* 1821 */     switch (level)
/*      */     {
/*      */     case 0:
/* 1824 */       logAndIncrDataLocalMaps(tip);
/* 1825 */       return Locality.NODE_LOCAL;
/*      */     case 1:
/* 1827 */       if (isNodeGroupAware)
/*      */       {
/* 1829 */         logAndIncrNodeGroupLocalMaps(tip);
/* 1830 */         return Locality.GROUP_LOCAL;
/*      */       }
/*      */ 
/* 1833 */       logAndIncrRackLocalMaps(tip);
/* 1834 */       return Locality.RACK_LOCAL;
/*      */     case 2:
/* 1837 */       if (isNodeGroupAware)
/*      */       {
/* 1839 */         logAndIncrRackLocalMaps(tip);
/* 1840 */         return Locality.RACK_LOCAL;
/*      */       }
/*      */ 
/*      */       break;
/*      */     }
/*      */ 
/* 1846 */     if (level != this.maxLevel) {
/* 1847 */       logAndIncrOtherLocalMaps(tip, level);
/*      */     }
/* 1849 */     return Locality.OFF_SWITCH;
/*      */   }
/*      */ 
/*      */   private void logAndIncrOtherLocalMaps(TaskInProgress tip, int level)
/*      */   {
/* 1854 */     LOG.info("Choosing cached task at level " + level + tip.getTIPId());
/* 1855 */     this.jobCounters.incrCounter(Counter.OTHER_LOCAL_MAPS, 1L);
/*      */   }
/*      */ 
/*      */   private void logAndIncrNodeGroupLocalMaps(TaskInProgress tip) {
/* 1859 */     LOG.info("Choosing nodeGroup-local task " + tip.getTIPId());
/* 1860 */     this.jobCounters.incrCounter(Counter.NODEGROUP_LOCAL_MAPS, 1L);
/*      */   }
/*      */ 
/*      */   private void logAndIncrRackLocalMaps(TaskInProgress tip) {
/* 1864 */     LOG.info("Choosing rack-local task " + tip.getTIPId());
/* 1865 */     this.jobCounters.incrCounter(Counter.RACK_LOCAL_MAPS, 1L);
/*      */   }
/*      */ 
/*      */   private void logAndIncrDataLocalMaps(TaskInProgress tip) {
/* 1869 */     LOG.info("Choosing data-local task " + tip.getTIPId());
/* 1870 */     this.jobCounters.incrCounter(Counter.DATA_LOCAL_MAPS, 1L);
/*      */   }
/*      */ 
/*      */   void setFirstTaskLaunchTime(TaskInProgress tip) {
/* 1874 */     TaskType key = tip.getFirstTaskType();
/*      */ 
/* 1876 */     synchronized (this.firstTaskLaunchTimes)
/*      */     {
/* 1878 */       if (!this.firstTaskLaunchTimes.containsKey(key))
/* 1879 */         this.firstTaskLaunchTimes.put(key, Long.valueOf(tip.getExecStartTime()));
/*      */     }
/*      */   }
/*      */ 
/*      */   static String convertTrackerNameToHostName(String trackerName)
/*      */   {
/* 1887 */     int indexOfColon = trackerName.indexOf(":");
/* 1888 */     String trackerHostName = indexOfColon == -1 ? trackerName : trackerName.substring(0, indexOfColon);
/*      */ 
/* 1891 */     return trackerHostName.substring("tracker_".length());
/*      */   }
/*      */ 
/*      */   synchronized void addTrackerTaskFailure(String trackerName, TaskTracker taskTracker)
/*      */   {
/* 1903 */     if (this.flakyTaskTrackers < this.clusterSize * 0.25D) {
/* 1904 */       String trackerHostName = convertTrackerNameToHostName(trackerName);
/*      */ 
/* 1906 */       Integer trackerFailures = (Integer)this.trackerToFailuresMap.get(trackerHostName);
/* 1907 */       if (trackerFailures == null) {
/* 1908 */         trackerFailures = Integer.valueOf(0);
/*      */       }
/* 1910 */       this.trackerToFailuresMap.put(trackerHostName, trackerFailures = Integer.valueOf(trackerFailures.intValue() + 1));
/*      */ 
/* 1913 */       if (trackerFailures.intValue() == this.maxTaskFailuresPerTracker) {
/* 1914 */         this.flakyTaskTrackers += 1;
/*      */ 
/* 1917 */         if (taskTracker != null) {
/* 1918 */           if (this.trackersReservedForMaps.containsKey(taskTracker)) {
/* 1919 */             taskTracker.unreserveSlots(TaskType.MAP, this);
/*      */           }
/* 1921 */           if (this.trackersReservedForReduces.containsKey(taskTracker)) {
/* 1922 */             taskTracker.unreserveSlots(TaskType.REDUCE, this);
/*      */           }
/*      */         }
/* 1925 */         LOG.info("TaskTracker at '" + trackerHostName + "' turned 'flaky'");
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void reserveTaskTracker(TaskTracker taskTracker, TaskType type, int numSlots)
/*      */   {
/* 1932 */     Map map = type == TaskType.MAP ? this.trackersReservedForMaps : this.trackersReservedForReduces;
/*      */ 
/* 1935 */     long now = this.jobtracker.getClock().getTime();
/*      */ 
/* 1937 */     FallowSlotInfo info = (FallowSlotInfo)map.get(taskTracker);
/* 1938 */     int reservedSlots = 0;
/* 1939 */     if (info == null) {
/* 1940 */       info = new FallowSlotInfo(now, numSlots);
/* 1941 */       reservedSlots = numSlots;
/*      */     }
/* 1944 */     else if (info.getNumSlots() != numSlots) {
/* 1945 */       Enum counter = type == TaskType.MAP ? Counter.FALLOW_SLOTS_MILLIS_MAPS : Counter.FALLOW_SLOTS_MILLIS_REDUCES;
/*      */ 
/* 1949 */       long fallowSlotMillis = (now - info.getTimestamp()) * info.getNumSlots();
/* 1950 */       this.jobCounters.incrCounter(counter, fallowSlotMillis);
/*      */ 
/* 1953 */       reservedSlots = numSlots - info.getNumSlots();
/* 1954 */       info.setTimestamp(now);
/* 1955 */       info.setNumSlots(numSlots);
/*      */     }
/*      */ 
/* 1958 */     map.put(taskTracker, info);
/* 1959 */     if (type == TaskType.MAP) {
/* 1960 */       this.jobtracker.getInstrumentation().addReservedMapSlots(reservedSlots);
/* 1961 */       this.queueMetrics.addReservedMapSlots(reservedSlots);
/*      */     }
/*      */     else {
/* 1964 */       this.jobtracker.getInstrumentation().addReservedReduceSlots(reservedSlots);
/* 1965 */       this.queueMetrics.addReservedReduceSlots(reservedSlots);
/*      */     }
/* 1967 */     this.jobtracker.incrementReservations(type, reservedSlots);
/*      */   }
/*      */ 
/*      */   public synchronized void unreserveTaskTracker(TaskTracker taskTracker, TaskType type)
/*      */   {
/* 1972 */     Map map = type == TaskType.MAP ? this.trackersReservedForMaps : this.trackersReservedForReduces;
/*      */ 
/* 1976 */     FallowSlotInfo info = (FallowSlotInfo)map.get(taskTracker);
/* 1977 */     if (info == null) {
/* 1978 */       LOG.warn("Cannot find information about fallow slots for " + taskTracker.getTrackerName());
/*      */ 
/* 1980 */       return;
/*      */     }
/*      */ 
/* 1983 */     long now = this.jobtracker.getClock().getTime();
/*      */ 
/* 1985 */     Enum counter = type == TaskType.MAP ? Counter.FALLOW_SLOTS_MILLIS_MAPS : Counter.FALLOW_SLOTS_MILLIS_REDUCES;
/*      */ 
/* 1989 */     long fallowSlotMillis = (now - info.getTimestamp()) * info.getNumSlots();
/* 1990 */     this.jobCounters.incrCounter(counter, fallowSlotMillis);
/*      */ 
/* 1992 */     map.remove(taskTracker);
/* 1993 */     if (type == TaskType.MAP) {
/* 1994 */       this.jobtracker.getInstrumentation().decReservedMapSlots(info.getNumSlots());
/* 1995 */       this.queueMetrics.decReservedMapSlots(info.getNumSlots());
/*      */     }
/*      */     else {
/* 1998 */       this.jobtracker.getInstrumentation().decReservedReduceSlots(info.getNumSlots());
/*      */ 
/* 2000 */       this.queueMetrics.decReservedReduceSlots(info.getNumSlots());
/*      */     }
/* 2002 */     this.jobtracker.decrementReservations(type, info.getNumSlots());
/*      */   }
/*      */ 
/*      */   public int getNumReservedTaskTrackersForMaps() {
/* 2006 */     return this.trackersReservedForMaps.size();
/*      */   }
/*      */ 
/*      */   public int getNumReservedTaskTrackersForReduces() {
/* 2010 */     return this.trackersReservedForReduces.size();
/*      */   }
/*      */ 
/*      */   private int getTrackerTaskFailures(String trackerName) {
/* 2014 */     String trackerHostName = convertTrackerNameToHostName(trackerName);
/* 2015 */     Integer failedTasks = (Integer)this.trackerToFailuresMap.get(trackerHostName);
/* 2016 */     return failedTasks != null ? failedTasks.intValue() : 0;
/*      */   }
/*      */ 
/*      */   List<String> getBlackListedTrackers()
/*      */   {
/* 2025 */     List blackListedTrackers = new ArrayList();
/* 2026 */     for (Map.Entry e : this.trackerToFailuresMap.entrySet()) {
/* 2027 */       if (((Integer)e.getValue()).intValue() >= this.maxTaskFailuresPerTracker) {
/* 2028 */         blackListedTrackers.add(e.getKey());
/*      */       }
/*      */     }
/* 2031 */     return blackListedTrackers;
/*      */   }
/*      */ 
/*      */   int getNoOfBlackListedTrackers()
/*      */   {
/* 2040 */     return this.flakyTaskTrackers;
/*      */   }
/*      */ 
/*      */   synchronized Map<String, Integer> getTaskTrackerErrors()
/*      */   {
/* 2052 */     Map trackerErrors = new TreeMap(this.trackerToFailuresMap);
/*      */ 
/* 2054 */     return trackerErrors;
/*      */   }
/*      */ 
/*      */   private synchronized void retireMap(TaskInProgress tip)
/*      */   {
/* 2064 */     if (this.runningMapCache == null) {
/* 2065 */       LOG.warn("Running cache for maps missing!! Job details are missing.");
/*      */ 
/* 2067 */       return;
/*      */     }
/*      */ 
/* 2070 */     String[] splitLocations = tip.getSplitLocations();
/*      */ 
/* 2073 */     if ((splitLocations == null) || (splitLocations.length == 0)) {
/* 2074 */       this.nonLocalRunningMaps.remove(tip);
/* 2075 */       return;
/*      */     }
/*      */ 
/* 2079 */     for (String host : splitLocations) {
/* 2080 */       Node node = this.jobtracker.getNode(host);
/*      */ 
/* 2082 */       for (int j = 0; j < this.maxLevel; j++) {
/* 2083 */         Set hostMaps = (Set)this.runningMapCache.get(node);
/* 2084 */         if (hostMaps != null) {
/* 2085 */           hostMaps.remove(tip);
/* 2086 */           if (hostMaps.size() == 0) {
/* 2087 */             this.runningMapCache.remove(node);
/*      */           }
/*      */         }
/* 2090 */         node = node.getParent();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized void retireReduce(TaskInProgress tip)
/*      */   {
/* 2101 */     if (this.runningReduces == null) {
/* 2102 */       LOG.warn("Running list for reducers missing!! Job details are missing.");
/*      */ 
/* 2104 */       return;
/*      */     }
/* 2106 */     this.runningReduces.remove(tip);
/*      */   }
/*      */ 
/*      */   protected synchronized void scheduleMap(TaskInProgress tip)
/*      */   {
/* 2115 */     if (this.runningMapCache == null) {
/* 2116 */       LOG.warn("Running cache for maps is missing!! Job details are missing.");
/*      */ 
/* 2118 */       return;
/*      */     }
/* 2120 */     String[] splitLocations = tip.getSplitLocations();
/*      */ 
/* 2123 */     if ((splitLocations == null) || (splitLocations.length == 0)) {
/* 2124 */       this.nonLocalRunningMaps.add(tip);
/* 2125 */       return;
/*      */     }
/*      */ 
/* 2128 */     for (String host : splitLocations) {
/* 2129 */       Node node = this.jobtracker.getNode(host);
/*      */ 
/* 2131 */       for (int j = 0; j < this.maxLevel; j++) {
/* 2132 */         Set hostMaps = (Set)this.runningMapCache.get(node);
/* 2133 */         if (hostMaps == null)
/*      */         {
/* 2135 */           hostMaps = new LinkedHashSet();
/* 2136 */           this.runningMapCache.put(node, hostMaps);
/*      */         }
/* 2138 */         hostMaps.add(tip);
/* 2139 */         node = node.getParent();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected synchronized void scheduleReduce(TaskInProgress tip)
/*      */   {
/* 2149 */     if (this.runningReduces == null) {
/* 2150 */       LOG.warn("Running cache for reducers missing!! Job details are missing.");
/*      */ 
/* 2152 */       return;
/*      */     }
/* 2154 */     this.runningReduces.add(tip);
/*      */   }
/*      */ 
/*      */   private synchronized void failMap(TaskInProgress tip)
/*      */   {
/* 2162 */     if (this.failedMaps == null) {
/* 2163 */       LOG.warn("Failed cache for maps is missing! Job details are missing.");
/* 2164 */       return;
/*      */     }
/*      */ 
/* 2169 */     this.failedMaps.add(tip);
/*      */   }
/*      */ 
/*      */   private synchronized void failReduce(TaskInProgress tip)
/*      */   {
/* 2177 */     if (this.nonRunningReduces == null) {
/* 2178 */       LOG.warn("Failed cache for reducers missing!! Job details are missing.");
/*      */ 
/* 2180 */       return;
/*      */     }
/* 2182 */     this.nonRunningReduces.add(tip);
/*      */   }
/*      */ 
/*      */   private synchronized TaskInProgress findTaskFromList(Collection<TaskInProgress> tips, TaskTrackerStatus ttStatus, int numUniqueHosts, boolean removeFailedTip)
/*      */   {
/* 2196 */     Iterator iter = tips.iterator();
/* 2197 */     while (iter.hasNext()) {
/* 2198 */       TaskInProgress tip = (TaskInProgress)iter.next();
/*      */ 
/* 2209 */       if ((tip.isRunnable()) && (!tip.isRunning()))
/*      */       {
/* 2211 */         if ((!tip.hasFailedOnMachine(ttStatus.getHost())) || (tip.getNumberOfFailedMachines() >= numUniqueHosts))
/*      */         {
/* 2214 */           iter.remove();
/* 2215 */           return tip;
/* 2216 */         }if (removeFailedTip)
/*      */         {
/* 2219 */           iter.remove();
/*      */         }
/*      */       }
/*      */       else {
/* 2223 */         iter.remove();
/*      */       }
/*      */     }
/* 2226 */     return null;
/*      */   }
/*      */ 
/*      */   protected synchronized TaskInProgress findSpeculativeTask(Collection<TaskInProgress> list, TaskTrackerStatus ttStatus, double avgProgress, long currentTime, boolean shouldRemove)
/*      */   {
/* 2242 */     Iterator iter = list.iterator();
/*      */ 
/* 2244 */     while (iter.hasNext()) {
/* 2245 */       TaskInProgress tip = (TaskInProgress)iter.next();
/*      */ 
/* 2247 */       if ((!tip.isRunning()) || (!tip.isRunnable())) {
/* 2248 */         iter.remove();
/*      */       }
/* 2252 */       else if (tip.hasSpeculativeTask(currentTime, avgProgress))
/*      */       {
/* 2255 */         if (shouldRemove) {
/* 2256 */           iter.remove();
/*      */         }
/* 2258 */         if (!tip.hasRunOnMachine(ttStatus.getHost(), ttStatus.getTrackerName()))
/*      */         {
/* 2260 */           return tip;
/*      */         }
/*      */       }
/* 2263 */       else if ((shouldRemove) && (tip.hasRunOnMachine(ttStatus.getHost(), ttStatus.getTrackerName())))
/*      */       {
/* 2265 */         iter.remove();
/*      */       }
/*      */     }
/*      */ 
/* 2269 */     return null;
/*      */   }
/*      */ 
/*      */   private synchronized int findNewMapTask(TaskTrackerStatus tts, int clusterSize, int numUniqueHosts, int maxCacheLevel, double avgProgress)
/*      */   {
/* 2292 */     if (this.numMapTasks == 0) {
/* 2293 */       if (LOG.isDebugEnabled()) {
/* 2294 */         LOG.debug("No maps to schedule for " + this.profile.getJobID());
/*      */       }
/* 2296 */       return -1;
/*      */     }
/*      */ 
/* 2299 */     String taskTracker = tts.getTrackerName();
/* 2300 */     TaskInProgress tip = null;
/*      */ 
/* 2305 */     this.clusterSize = clusterSize;
/*      */ 
/* 2307 */     if (!shouldRunOnTaskTracker(taskTracker)) {
/* 2308 */       return -1;
/*      */     }
/*      */ 
/* 2313 */     long outSize = this.resourceEstimator.getEstimatedMapOutputSize();
/* 2314 */     long availSpace = tts.getResourceStatus().getAvailableSpace();
/* 2315 */     if (availSpace < outSize) {
/* 2316 */       LOG.warn("No room for map task. Node " + tts.getHost() + " has " + availSpace + " bytes free; but we expect map to take " + outSize);
/*      */ 
/* 2320 */       return -1;
/*      */     }
/*      */ 
/* 2339 */     tip = findTaskFromList(this.failedMaps, tts, numUniqueHosts, false);
/* 2340 */     if (tip != null)
/*      */     {
/* 2342 */       scheduleMap(tip);
/* 2343 */       LOG.info("Choosing a failed task " + tip.getTIPId());
/* 2344 */       return tip.getIdWithinJob();
/*      */     }
/*      */ 
/* 2347 */     Node node = this.jobtracker.getNode(tts.getHost());
/*      */ 
/* 2356 */     if (node != null) {
/* 2357 */       Node key = node;
/* 2358 */       int level = 0;
/*      */ 
/* 2364 */       int maxLevelToSchedule = Math.min(maxCacheLevel, this.maxLevel);
/* 2365 */       for (level = 0; level < maxLevelToSchedule; level++) {
/* 2366 */         List cacheForLevel = (List)this.nonRunningMapCache.get(key);
/* 2367 */         if (cacheForLevel != null) {
/* 2368 */           tip = findTaskFromList(cacheForLevel, tts, numUniqueHosts, level == 0);
/*      */ 
/* 2370 */           if (tip != null)
/*      */           {
/* 2372 */             scheduleMap(tip);
/*      */ 
/* 2375 */             if (cacheForLevel.size() == 0) {
/* 2376 */               this.nonRunningMapCache.remove(key);
/*      */             }
/*      */ 
/* 2379 */             return tip.getIdWithinJob();
/*      */           }
/*      */         }
/* 2382 */         key = key.getParent();
/*      */       }
/*      */ 
/* 2386 */       if (level == maxCacheLevel) {
/* 2387 */         return -1;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2398 */     Collection nodesAtMaxLevel = this.jobtracker.getNodesAtMaxLevel();
/*      */ 
/* 2401 */     Node nodeParentAtMaxLevel = node == null ? null : JobTracker.getParentNode(node, this.maxLevel - 1);
/*      */ 
/* 2404 */     for (Node parent : nodesAtMaxLevel)
/*      */     {
/* 2407 */       if (parent != nodeParentAtMaxLevel)
/*      */       {
/* 2411 */         List cache = (List)this.nonRunningMapCache.get(parent);
/* 2412 */         if (cache != null) {
/* 2413 */           tip = findTaskFromList(cache, tts, numUniqueHosts, false);
/* 2414 */           if (tip != null)
/*      */           {
/* 2416 */             scheduleMap(tip);
/*      */ 
/* 2419 */             if (cache.size() == 0) {
/* 2420 */               this.nonRunningMapCache.remove(parent);
/*      */             }
/* 2422 */             LOG.info("Choosing a non-local task " + tip.getTIPId());
/* 2423 */             return tip.getIdWithinJob();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 2429 */     tip = findTaskFromList(this.nonLocalMaps, tts, numUniqueHosts, false);
/* 2430 */     if (tip != null)
/*      */     {
/* 2432 */       scheduleMap(tip);
/*      */ 
/* 2434 */       LOG.info("Choosing a non-local task " + tip.getTIPId());
/* 2435 */       return tip.getIdWithinJob();
/*      */     }
/*      */ 
/* 2442 */     if (this.hasSpeculativeMaps) {
/* 2443 */       long currentTime = this.jobtracker.getClock().getTime();
/*      */ 
/* 2446 */       if (node != null) {
/* 2447 */         Node key = node;
/* 2448 */         for (int level = 0; level < this.maxLevel; level++) {
/* 2449 */           Set cacheForLevel = (Set)this.runningMapCache.get(key);
/* 2450 */           if (cacheForLevel != null) {
/* 2451 */             tip = findSpeculativeTask(cacheForLevel, tts, avgProgress, currentTime, level == 0);
/*      */ 
/* 2453 */             if (tip != null) {
/* 2454 */               if (cacheForLevel.size() == 0) {
/* 2455 */                 this.runningMapCache.remove(key);
/*      */               }
/* 2457 */               return tip.getIdWithinJob();
/*      */             }
/*      */           }
/* 2460 */           key = key.getParent();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2466 */       for (Node parent : nodesAtMaxLevel)
/*      */       {
/* 2468 */         if (parent != nodeParentAtMaxLevel)
/*      */         {
/* 2472 */           Set cache = (Set)this.runningMapCache.get(parent);
/* 2473 */           if (cache != null) {
/* 2474 */             tip = findSpeculativeTask(cache, tts, avgProgress, currentTime, false);
/*      */ 
/* 2476 */             if (tip != null)
/*      */             {
/* 2478 */               if (cache.size() == 0) {
/* 2479 */                 this.runningMapCache.remove(parent);
/*      */               }
/* 2481 */               LOG.info("Choosing a non-local task " + tip.getTIPId() + " for speculation");
/*      */ 
/* 2483 */               return tip.getIdWithinJob();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 2489 */       tip = findSpeculativeTask(this.nonLocalRunningMaps, tts, avgProgress, currentTime, false);
/*      */ 
/* 2491 */       if (tip != null) {
/* 2492 */         LOG.info("Choosing a non-local task " + tip.getTIPId() + " for speculation");
/*      */ 
/* 2494 */         return tip.getIdWithinJob();
/*      */       }
/*      */     }
/*      */ 
/* 2498 */     return -1;
/*      */   }
/*      */ 
/*      */   private synchronized int findNewReduceTask(TaskTrackerStatus tts, int clusterSize, int numUniqueHosts, double avgProgress)
/*      */   {
/* 2513 */     if (this.numReduceTasks == 0) {
/* 2514 */       if (LOG.isDebugEnabled()) {
/* 2515 */         LOG.debug("No reduces to schedule for " + this.profile.getJobID());
/*      */       }
/* 2517 */       return -1;
/*      */     }
/*      */ 
/* 2520 */     String taskTracker = tts.getTrackerName();
/* 2521 */     TaskInProgress tip = null;
/*      */ 
/* 2524 */     this.clusterSize = clusterSize;
/*      */ 
/* 2526 */     if (!shouldRunOnTaskTracker(taskTracker)) {
/* 2527 */       return -1;
/*      */     }
/*      */ 
/* 2532 */     tip = findTaskFromList(this.nonRunningReduces, tts, numUniqueHosts, false);
/* 2533 */     if (tip != null) {
/* 2534 */       scheduleReduce(tip);
/* 2535 */       return tip.getIdWithinJob();
/*      */     }
/*      */ 
/* 2539 */     if (this.hasSpeculativeReduces) {
/* 2540 */       tip = findSpeculativeTask(this.runningReduces, tts, avgProgress, this.jobtracker.getClock().getTime(), false);
/*      */ 
/* 2542 */       if (tip != null) {
/* 2543 */         scheduleReduce(tip);
/* 2544 */         return tip.getIdWithinJob();
/*      */       }
/*      */     }
/*      */ 
/* 2548 */     return -1;
/*      */   }
/*      */ 
/*      */   private boolean shouldRunOnTaskTracker(String taskTracker)
/*      */   {
/* 2556 */     int taskTrackerFailedTasks = getTrackerTaskFailures(taskTracker);
/* 2557 */     if ((this.flakyTaskTrackers < this.clusterSize * 0.25D) && (taskTrackerFailedTasks >= this.maxTaskFailuresPerTracker))
/*      */     {
/* 2559 */       if (LOG.isDebugEnabled()) {
/* 2560 */         String flakyTracker = convertTrackerNameToHostName(taskTracker);
/* 2561 */         LOG.debug("Ignoring the black-listed tasktracker: '" + flakyTracker + "' for assigning a new task");
/*      */       }
/*      */ 
/* 2564 */       return false;
/*      */     }
/* 2566 */     return true;
/*      */   }
/*      */ 
/*      */   private void meterTaskAttempt(TaskInProgress tip, TaskStatus status)
/*      */   {
/* 2578 */     Counter slotCounter = tip.isMapTask() ? Counter.SLOTS_MILLIS_MAPS : Counter.SLOTS_MILLIS_REDUCES;
/*      */ 
/* 2581 */     this.jobCounters.incrCounter(slotCounter, tip.getNumSlotsRequired() * (status.getFinishTime() - status.getStartTime()));
/*      */   }
/*      */ 
/*      */   public synchronized boolean completedTask(TaskInProgress tip, TaskStatus status)
/*      */   {
/* 2592 */     TaskAttemptID taskid = status.getTaskID();
/* 2593 */     int oldNumAttempts = tip.getActiveTasks().size();
/* 2594 */     JobTrackerInstrumentation metrics = this.jobtracker.getInstrumentation();
/*      */ 
/* 2597 */     meterTaskAttempt(tip, status);
/*      */ 
/* 2605 */     if (tip.isComplete())
/*      */     {
/* 2607 */       tip.alreadyCompletedTask(taskid);
/*      */ 
/* 2610 */       if (this.status.getRunState() != 1) {
/* 2611 */         this.jobtracker.markCompletedTaskAttempt(status.getTaskTracker(), taskid);
/*      */       }
/* 2613 */       return false;
/*      */     }
/*      */ 
/* 2616 */     LOG.info("Task '" + taskid + "' has completed " + tip.getTIPId() + " successfully.");
/*      */ 
/* 2620 */     tip.completed(taskid);
/* 2621 */     this.resourceEstimator.updateWithCompletedTask(status, tip);
/*      */ 
/* 2624 */     TaskTrackerStatus ttStatus = this.jobtracker.getTaskTrackerStatus(status.getTaskTracker());
/*      */ 
/* 2626 */     String trackerHostname = this.jobtracker.getNode(ttStatus.getHost()).toString();
/* 2627 */     String taskType = getTaskType(tip);
/* 2628 */     TaskAttemptID taskAttemptId = status.getTaskID();
/* 2629 */     Locality locality = checkLocality(tip, taskAttemptId);
/* 2630 */     Avataar avataar = checkAvataar(tip, taskAttemptId);
/* 2631 */     if (status.getIsMap()) {
/* 2632 */       JobHistory.MapAttempt.logStarted(taskAttemptId, status.getStartTime(), status.getTaskTracker(), ttStatus.getHttpPort(), taskType, locality, avataar);
/*      */ 
/* 2636 */       JobHistory.MapAttempt.logFinished(taskAttemptId, status.getFinishTime(), trackerHostname, taskType, status.getStateString(), status.getCounters());
/*      */     }
/*      */     else
/*      */     {
/* 2641 */       JobHistory.ReduceAttempt.logStarted(taskAttemptId, status.getStartTime(), status.getTaskTracker(), ttStatus.getHttpPort(), taskType, locality, avataar);
/*      */ 
/* 2645 */       JobHistory.ReduceAttempt.logFinished(taskAttemptId, status.getShuffleFinishTime(), status.getSortFinishTime(), status.getFinishTime(), trackerHostname, taskType, status.getStateString(), status.getCounters());
/*      */     }
/*      */ 
/* 2654 */     JobHistory.Task.logFinished(tip.getTIPId(), taskType, tip.getExecFinishTime(), status.getCounters());
/*      */ 
/* 2659 */     int newNumAttempts = tip.getActiveTasks().size();
/* 2660 */     if (tip.isJobSetupTask())
/*      */     {
/* 2662 */       killSetupTip(!tip.isMapTask());
/*      */ 
/* 2664 */       this.status.setSetupProgress(1.0F);
/*      */ 
/* 2666 */       if (this.status.getRunState() == 4) {
/* 2667 */         changeStateTo(1);
/* 2668 */         JobHistory.JobInfo.logStarted(this.profile.getJobID());
/*      */       }
/* 2670 */     } else if (tip.isJobCleanupTask())
/*      */     {
/* 2672 */       if (tip.isMapTask())
/*      */       {
/* 2674 */         this.cleanup[1].kill();
/*      */       }
/* 2676 */       else this.cleanup[0].kill();
/*      */ 
/* 2681 */       if (this.jobFailed) {
/* 2682 */         terminateJob(3);
/*      */       }
/*      */ 
/* 2685 */       if (this.jobKilled) {
/* 2686 */         terminateJob(5);
/*      */       }
/*      */       else {
/* 2689 */         jobComplete();
/*      */       }
/*      */ 
/* 2693 */       this.jobtracker.markCompletedTaskAttempt(status.getTaskTracker(), taskid);
/* 2694 */     } else if (tip.isMapTask()) {
/* 2695 */       this.runningMapTasks -= 1;
/*      */ 
/* 2697 */       if (oldNumAttempts > 1) {
/* 2698 */         this.speculativeMapTasks -= oldNumAttempts - newNumAttempts;
/*      */       }
/* 2700 */       this.finishedMapTasks += 1;
/* 2701 */       metrics.completeMap(taskid);
/* 2702 */       this.queueMetrics.completeMap(taskid);
/*      */ 
/* 2704 */       retireMap(tip);
/* 2705 */       if (this.finishedMapTasks + this.failedMapTIPs == this.numMapTasks) {
/* 2706 */         this.status.setMapProgress(1.0F);
/* 2707 */         if (canLaunchJobCleanupTask())
/* 2708 */           checkCounterLimitsAndFail();
/*      */       }
/*      */     }
/*      */     else {
/* 2712 */       this.runningReduceTasks -= 1;
/* 2713 */       if (oldNumAttempts > 1) {
/* 2714 */         this.speculativeReduceTasks -= oldNumAttempts - newNumAttempts;
/*      */       }
/* 2716 */       this.finishedReduceTasks += 1;
/* 2717 */       metrics.completeReduce(taskid);
/* 2718 */       this.queueMetrics.completeReduce(taskid);
/*      */ 
/* 2720 */       retireReduce(tip);
/* 2721 */       if (this.finishedReduceTasks + this.failedReduceTIPs == this.numReduceTasks) {
/* 2722 */         this.status.setReduceProgress(1.0F);
/* 2723 */         if (canLaunchJobCleanupTask()) {
/* 2724 */           checkCounterLimitsAndFail();
/*      */         }
/*      */       }
/*      */     }
/* 2728 */     return true;
/*      */   }
/*      */ 
/*      */   private void checkCounterLimitsAndFail()
/*      */   {
/* 2739 */     boolean jobIsFine = true;
/* 2740 */     boolean mapIsFine = getMapCounters(new Counters());
/* 2741 */     boolean reduceIsFine = getReduceCounters(new Counters());
/* 2742 */     jobIsFine = getCounters(new Counters());
/* 2743 */     if ((!mapIsFine) || (!reduceIsFine) || (!jobIsFine)) {
/* 2744 */       this.status.setFailureInfo("Counters Exceeded: Limit: " + Counters.MAX_COUNTER_LIMIT);
/*      */ 
/* 2746 */       this.jobtracker.failJob(this);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void changeStateTo(int newState)
/*      */   {
/* 2754 */     int oldState = this.status.getRunState();
/* 2755 */     if (oldState == newState) {
/* 2756 */       return;
/*      */     }
/* 2758 */     this.status.setRunState(newState);
/*      */ 
/* 2761 */     if (oldState == 4) {
/* 2762 */       this.jobtracker.getInstrumentation().decPrepJob(this.conf, this.jobId);
/* 2763 */       this.queueMetrics.decPrepJob(this.conf, this.jobId);
/* 2764 */     } else if (oldState == 1) {
/* 2765 */       this.jobtracker.getInstrumentation().decRunningJob(this.conf, this.jobId);
/* 2766 */       this.queueMetrics.decRunningJob(this.conf, this.jobId);
/*      */     }
/*      */ 
/* 2769 */     if (newState == 4) {
/* 2770 */       this.jobtracker.getInstrumentation().addPrepJob(this.conf, this.jobId);
/* 2771 */       this.queueMetrics.addPrepJob(this.conf, this.jobId);
/* 2772 */     } else if (newState == 1) {
/* 2773 */       this.jobtracker.getInstrumentation().addRunningJob(this.conf, this.jobId);
/* 2774 */       this.queueMetrics.addRunningJob(this.conf, this.jobId);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void jobComplete()
/*      */   {
/* 2784 */     JobTrackerInstrumentation metrics = this.jobtracker.getInstrumentation();
/*      */ 
/* 2788 */     if (this.status.getRunState() == 1) {
/* 2789 */       changeStateTo(2);
/* 2790 */       this.status.setCleanupProgress(1.0F);
/* 2791 */       if (this.maps.length == 0) {
/* 2792 */         this.status.setMapProgress(1.0F);
/*      */       }
/* 2794 */       if (this.reduces.length == 0) {
/* 2795 */         this.status.setReduceProgress(1.0F);
/*      */       }
/*      */ 
/* 2798 */       this.finishTime = this.jobtracker.getClock().getTime();
/* 2799 */       LOG.info("Job " + this.status.getJobID() + " has completed successfully.");
/*      */ 
/* 2804 */       JobSummary.logJobSummary(this, this.jobtracker.getClusterStatus(false));
/*      */ 
/* 2806 */       Counters mapCounters = new Counters();
/* 2807 */       boolean isFine = getMapCounters(mapCounters);
/* 2808 */       mapCounters = isFine ? mapCounters : new Counters();
/* 2809 */       Counters reduceCounters = new Counters();
/* 2810 */       isFine = getReduceCounters(reduceCounters);
/* 2811 */       reduceCounters = isFine ? reduceCounters : new Counters();
/* 2812 */       Counters jobCounters = new Counters();
/* 2813 */       isFine = getCounters(jobCounters);
/* 2814 */       jobCounters = isFine ? jobCounters : new Counters();
/*      */ 
/* 2817 */       JobHistory.JobInfo.logFinished(this.status.getJobID(), this.finishTime, this.finishedMapTasks, this.finishedReduceTasks, this.failedMapTasks, this.failedReduceTasks, mapCounters, reduceCounters, jobCounters);
/*      */ 
/* 2826 */       garbageCollect();
/*      */ 
/* 2828 */       metrics.completeJob(this.conf, this.status.getJobID());
/* 2829 */       this.queueMetrics.completeJob(this.conf, this.status.getJobID());
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized void terminateJob(int jobTerminationState) {
/* 2834 */     if ((this.status.getRunState() == 1) || (this.status.getRunState() == 4))
/*      */     {
/* 2836 */       this.finishTime = this.jobtracker.getClock().getTime();
/* 2837 */       this.status.setMapProgress(1.0F);
/* 2838 */       this.status.setReduceProgress(1.0F);
/* 2839 */       this.status.setCleanupProgress(1.0F);
/*      */ 
/* 2841 */       if (jobTerminationState == 3) {
/* 2842 */         changeStateTo(3);
/*      */ 
/* 2845 */         JobSummary.logJobSummary(this, this.jobtracker.getClusterStatus(false));
/*      */ 
/* 2848 */         JobHistory.JobInfo.logFailed(this.status.getJobID(), this.finishTime, this.finishedMapTasks, this.finishedReduceTasks, this.status.getFailureInfo());
/*      */       }
/*      */       else
/*      */       {
/* 2853 */         changeStateTo(5);
/*      */ 
/* 2856 */         JobSummary.logJobSummary(this, this.jobtracker.getClusterStatus(false));
/*      */ 
/* 2859 */         JobHistory.JobInfo.logKilled(this.status.getJobID(), this.finishTime, this.finishedMapTasks, this.finishedReduceTasks);
/*      */       }
/*      */ 
/* 2863 */       garbageCollect();
/*      */ 
/* 2865 */       this.jobtracker.getInstrumentation().terminateJob(this.conf, this.status.getJobID());
/*      */ 
/* 2867 */       if (jobTerminationState == 3) {
/* 2868 */         this.jobtracker.getInstrumentation().failedJob(this.conf, this.status.getJobID());
/*      */ 
/* 2870 */         this.queueMetrics.failedJob(this.conf, this.status.getJobID());
/*      */       } else {
/* 2872 */         this.jobtracker.getInstrumentation().killedJob(this.conf, this.status.getJobID());
/*      */ 
/* 2874 */         this.queueMetrics.killedJob(this.conf, this.status.getJobID());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized void terminate(int jobTerminationState)
/*      */   {
/* 2888 */     if (!this.tasksInited)
/*      */     {
/* 2890 */       terminateJob(jobTerminationState);
/* 2891 */       return;
/*      */     }
/*      */ 
/* 2894 */     if ((this.status.getRunState() == 1) || (this.status.getRunState() == 4))
/*      */     {
/* 2896 */       LOG.info("Killing job '" + this.status.getJobID() + "'");
/* 2897 */       if (jobTerminationState == 3) {
/* 2898 */         if (this.jobFailed) {
/* 2899 */           return;
/*      */         }
/* 2901 */         this.jobFailed = true;
/* 2902 */       } else if (jobTerminationState == 5) {
/* 2903 */         if (this.jobKilled) {
/* 2904 */           return;
/*      */         }
/* 2906 */         this.jobKilled = true;
/*      */       }
/*      */ 
/* 2909 */       clearUncleanTasks();
/*      */ 
/* 2913 */       for (int i = 0; i < this.setup.length; i++) {
/* 2914 */         this.setup[i].kill();
/*      */       }
/* 2916 */       for (int i = 0; i < this.maps.length; i++) {
/* 2917 */         this.maps[i].kill();
/*      */       }
/* 2919 */       for (int i = 0; i < this.reduces.length; i++)
/* 2920 */         this.reduces[i].kill();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void cancelReservedSlots()
/*      */   {
/* 2928 */     Set tm = new HashSet(this.trackersReservedForMaps.keySet());
/*      */ 
/* 2930 */     for (TaskTracker tt : tm) {
/* 2931 */       tt.unreserveSlots(TaskType.MAP, this);
/*      */     }
/*      */ 
/* 2934 */     Set tr = new HashSet(this.trackersReservedForReduces.keySet());
/*      */ 
/* 2936 */     for (TaskTracker tt : tr)
/* 2937 */       tt.unreserveSlots(TaskType.REDUCE, this);
/*      */   }
/*      */ 
/*      */   private void clearUncleanTasks() {
/* 2941 */     TaskAttemptID taskid = null;
/* 2942 */     TaskInProgress tip = null;
/* 2943 */     while (!this.mapCleanupTasks.isEmpty()) {
/* 2944 */       taskid = (TaskAttemptID)this.mapCleanupTasks.remove(0);
/* 2945 */       tip = this.maps[taskid.getTaskID().getId()];
/* 2946 */       updateTaskStatus(tip, tip.getTaskStatus(taskid));
/*      */     }
/* 2948 */     while (!this.reduceCleanupTasks.isEmpty()) {
/* 2949 */       taskid = (TaskAttemptID)this.reduceCleanupTasks.remove(0);
/* 2950 */       tip = this.reduces[taskid.getTaskID().getId()];
/* 2951 */       updateTaskStatus(tip, tip.getTaskStatus(taskid));
/*      */     }
/*      */   }
/*      */ 
/*      */   public void kill()
/*      */   {
/* 2960 */     boolean killNow = false;
/* 2961 */     synchronized (this.jobInitKillStatus) {
/* 2962 */       this.jobInitKillStatus.killed = true;
/*      */ 
/* 2964 */       if ((!this.jobInitKillStatus.initStarted) || (this.jobInitKillStatus.initDone))
/*      */       {
/* 2966 */         killNow = true;
/*      */       }
/*      */     }
/* 2969 */     if (killNow)
/* 2970 */       terminate(5);
/*      */   }
/*      */ 
/*      */   synchronized void fail()
/*      */   {
/* 2980 */     terminate(3);
/*      */   }
/*      */ 
/*      */   private void failedTask(TaskInProgress tip, TaskAttemptID taskid, TaskStatus status, TaskTracker taskTracker, boolean wasRunning, boolean wasComplete, boolean wasAttemptRunning)
/*      */   {
/* 2999 */     JobTrackerInstrumentation metrics = this.jobtracker.getInstrumentation();
/*      */ 
/* 3001 */     boolean wasFailed = tip.isFailed();
/*      */ 
/* 3004 */     tip.incompleteSubTask(taskid, this.status);
/*      */ 
/* 3006 */     boolean isRunning = tip.isRunning();
/* 3007 */     boolean isComplete = tip.isComplete();
/* 3008 */     boolean metricsDone = isComplete();
/*      */ 
/* 3010 */     if (wasAttemptRunning)
/*      */     {
/* 3021 */       if ((!tip.isJobCleanupTask()) && (!tip.isJobSetupTask())) {
/* 3022 */         if ((tip.isMapTask()) && (!metricsDone)) {
/* 3023 */           this.runningMapTasks -= 1;
/* 3024 */           metrics.failedMap(taskid);
/* 3025 */           this.queueMetrics.failedMap(taskid);
/* 3026 */         } else if (!metricsDone) {
/* 3027 */           this.runningReduceTasks -= 1;
/* 3028 */           metrics.failedReduce(taskid);
/* 3029 */           this.queueMetrics.failedReduce(taskid);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3034 */       meterTaskAttempt(tip, status);
/*      */     }
/*      */ 
/* 3038 */     if ((wasRunning) && (!isRunning)) {
/* 3039 */       if (tip.isJobCleanupTask()) {
/* 3040 */         this.launchedCleanup = false;
/* 3041 */       } else if (tip.isJobSetupTask()) {
/* 3042 */         this.launchedSetup = false;
/* 3043 */       } else if (tip.isMapTask())
/*      */       {
/* 3046 */         if (!isComplete) {
/* 3047 */           retireMap(tip);
/* 3048 */           failMap(tip);
/*      */         }
/*      */ 
/*      */       }
/* 3053 */       else if (!isComplete) {
/* 3054 */         retireReduce(tip);
/* 3055 */         failReduce(tip);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 3062 */     if ((wasComplete) && (!isComplete) && 
/* 3063 */       (tip.isMapTask()))
/*      */     {
/* 3071 */       failMap(tip);
/* 3072 */       this.finishedMapTasks -= 1;
/*      */     }
/*      */ 
/* 3078 */     TaskStatus taskStatus = tip.getTaskStatus(taskid);
/* 3079 */     String taskTrackerName = taskStatus.getTaskTracker();
/* 3080 */     String taskTrackerHostName = convertTrackerNameToHostName(taskTrackerName);
/* 3081 */     int taskTrackerPort = -1;
/* 3082 */     TaskTrackerStatus taskTrackerStatus = taskTracker == null ? null : taskTracker.getStatus();
/*      */ 
/* 3084 */     if (taskTrackerStatus != null) {
/* 3085 */       taskTrackerPort = taskTrackerStatus.getHttpPort();
/*      */     }
/* 3087 */     long startTime = taskStatus.getStartTime();
/* 3088 */     long finishTime = taskStatus.getFinishTime();
/* 3089 */     List taskDiagnosticInfo = tip.getDiagnosticInfo(taskid);
/* 3090 */     String diagInfo = taskDiagnosticInfo == null ? "" : StringUtils.arrayToString((String[])taskDiagnosticInfo.toArray(new String[0]));
/*      */ 
/* 3092 */     String taskType = getTaskType(tip);
/* 3093 */     TaskAttemptID taskAttemptId = status.getTaskID();
/* 3094 */     Locality locality = checkLocality(tip, taskAttemptId);
/* 3095 */     Avataar avataar = checkAvataar(tip, taskAttemptId);
/* 3096 */     if (taskStatus.getIsMap()) {
/* 3097 */       JobHistory.MapAttempt.logStarted(taskid, startTime, taskTrackerName, taskTrackerPort, taskType, locality, avataar);
/*      */ 
/* 3099 */       if (taskStatus.getRunState() == TaskStatus.State.FAILED) {
/* 3100 */         JobHistory.MapAttempt.logFailed(taskid, finishTime, taskTrackerHostName, diagInfo, taskType);
/*      */       }
/*      */       else
/* 3103 */         JobHistory.MapAttempt.logKilled(taskid, finishTime, taskTrackerHostName, diagInfo, taskType);
/*      */     }
/*      */     else
/*      */     {
/* 3107 */       JobHistory.ReduceAttempt.logStarted(taskid, startTime, taskTrackerName, taskTrackerPort, taskType, locality, avataar);
/*      */ 
/* 3109 */       if (taskStatus.getRunState() == TaskStatus.State.FAILED) {
/* 3110 */         JobHistory.ReduceAttempt.logFailed(taskid, finishTime, taskTrackerHostName, diagInfo, taskType);
/*      */       }
/*      */       else {
/* 3113 */         JobHistory.ReduceAttempt.logKilled(taskid, finishTime, taskTrackerHostName, diagInfo, taskType);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 3120 */     if ((!tip.isJobCleanupTask()) && (!tip.isJobSetupTask())) {
/* 3121 */       if (tip.isMapTask())
/* 3122 */         this.failedMapTasks += 1;
/*      */       else {
/* 3124 */         this.failedReduceTasks += 1;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 3131 */     if (status.getRunState() == TaskStatus.State.FAILED) {
/* 3132 */       addTrackerTaskFailure(taskTrackerName, taskTracker);
/*      */     }
/*      */ 
/* 3138 */     this.jobtracker.markCompletedTaskAttempt(status.getTaskTracker(), taskid);
/*      */ 
/* 3145 */     if ((!wasFailed) && (tip.isFailed()))
/*      */     {
/* 3150 */       boolean killJob = (tip.isJobCleanupTask()) || (tip.isJobSetupTask());
/*      */ 
/* 3155 */       if (killJob) {
/* 3156 */         String failureInfo = "";
/* 3157 */         if (tip.isJobCleanupTask())
/* 3158 */           failureInfo = "JobCleanup Task Failure, Task: " + tip.getTIPId();
/* 3159 */         else if (tip.isJobSetupTask())
/* 3160 */           failureInfo = "JobSetup Task Failure, Task: " + tip.getTIPId();
/* 3161 */         else if (tip.isMapTask()) {
/* 3162 */           failureInfo = "# of failed Map Tasks exceeded allowed limit. FailedCount: " + this.failedMapTIPs + ". LastFailedTask: " + tip.getTIPId();
/*      */         }
/*      */         else {
/* 3165 */           failureInfo = "# of failed Reduce Tasks exceeded allowed limit. FailedCount: " + this.failedReduceTIPs + ". LastFailedTask: " + tip.getTIPId();
/*      */         }
/*      */ 
/* 3168 */         this.status.setFailureInfo(failureInfo);
/* 3169 */         LOG.info("Aborting job " + this.profile.getJobID());
/* 3170 */         JobHistory.Task.logFailed(tip.getTIPId(), taskType, finishTime, diagInfo);
/*      */ 
/* 3174 */         if (tip.isJobCleanupTask())
/*      */         {
/* 3176 */           if (tip.isMapTask())
/* 3177 */             this.cleanup[1].kill();
/*      */           else {
/* 3179 */             this.cleanup[0].kill();
/*      */           }
/* 3181 */           terminateJob(3);
/*      */         } else {
/* 3183 */           if (tip.isJobSetupTask())
/*      */           {
/* 3185 */             killSetupTip(!tip.isMapTask());
/*      */           }
/* 3187 */           fail();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3194 */       if ((!tip.isJobCleanupTask()) && (!tip.isJobSetupTask()))
/* 3195 */         if (tip.isMapTask())
/* 3196 */           this.jobCounters.incrCounter(Counter.NUM_FAILED_MAPS, 1L);
/*      */         else
/* 3198 */           this.jobCounters.incrCounter(Counter.NUM_FAILED_REDUCES, 1L);
/*      */     }
/*      */   }
/*      */ 
/*      */   private Locality checkLocality(TaskInProgress tip, TaskAttemptID taskAttemptId)
/*      */   {
/* 3205 */     Locality locality = tip.getTaskAttemptLocality(taskAttemptId);
/* 3206 */     if (locality == null) {
/* 3207 */       locality = Locality.OFF_SWITCH;
/*      */     }
/* 3209 */     return locality;
/*      */   }
/*      */ 
/*      */   private Avataar checkAvataar(TaskInProgress tip, TaskAttemptID taskAttemptId) {
/* 3213 */     Avataar avataar = tip.getTaskAttemptAvataar(taskAttemptId);
/* 3214 */     if (avataar == null) {
/* 3215 */       avataar = Avataar.VIRGIN;
/*      */     }
/* 3217 */     return avataar;
/*      */   }
/*      */ 
/*      */   void killSetupTip(boolean isMap) {
/* 3221 */     if (isMap)
/* 3222 */       this.setup[0].kill();
/*      */     else
/* 3224 */       this.setup[1].kill();
/*      */   }
/*      */ 
/*      */   boolean isSetupFinished()
/*      */   {
/* 3229 */     if ((this.setup[0].isComplete()) || (this.setup[0].isFailed()) || (this.setup[1].isComplete()) || (this.setup[1].isFailed()))
/*      */     {
/* 3231 */       return true;
/*      */     }
/* 3233 */     return false;
/*      */   }
/*      */ 
/*      */   public void failedTask(TaskInProgress tip, TaskAttemptID taskid, String reason, TaskStatus.Phase phase, TaskStatus.State state, String trackerName)
/*      */   {
/* 3249 */     TaskStatus status = TaskStatus.createTaskStatus(tip.isMapTask(), taskid, 0.0F, tip.isMapTask() ? this.numSlotsPerMap : this.numSlotsPerReduce, state, reason, reason, trackerName, phase, new Counters());
/*      */ 
/* 3261 */     TaskStatus oldStatus = tip.getTaskStatus(taskid);
/* 3262 */     long startTime = oldStatus == null ? this.jobtracker.getClock().getTime() : oldStatus.getStartTime();
/*      */ 
/* 3265 */     status.setStartTime(startTime);
/* 3266 */     status.setFinishTime(this.jobtracker.getClock().getTime());
/* 3267 */     boolean wasComplete = tip.isComplete();
/* 3268 */     updateTaskStatus(tip, status);
/* 3269 */     boolean isComplete = tip.isComplete();
/* 3270 */     if ((wasComplete) && (!isComplete)) {
/* 3271 */       String taskType = getTaskType(tip);
/* 3272 */       JobHistory.Task.logFailed(tip.getTIPId(), taskType, tip.getExecFinishTime(), reason, taskid);
/*      */     }
/*      */   }
/*      */ 
/*      */   void garbageCollect()
/*      */   {
/* 3284 */     synchronized (this)
/*      */     {
/* 3286 */       cancelReservedSlots();
/*      */ 
/* 3291 */       if (this.tasksInited) {
/* 3292 */         this.jobtracker.getInstrumentation().decWaitingMaps(getJobID(), pendingMaps());
/* 3293 */         this.jobtracker.getInstrumentation().decWaitingReduces(getJobID(), pendingReduces());
/* 3294 */         this.queueMetrics.decWaitingMaps(getJobID(), pendingMaps());
/* 3295 */         this.queueMetrics.decWaitingReduces(getJobID(), pendingReduces());
/*      */       }
/*      */ 
/* 3298 */       this.jobtracker.storeCompletedJob(this);
/* 3299 */       this.jobtracker.finalizeJob(this);
/*      */     }
/*      */ 
/* 3302 */     cleanupJob();
/*      */   }
/*      */ 
/*      */   void cleanupJob()
/*      */   {
/* 3310 */     FileSystem tempDirFs = null;
/* 3311 */     synchronized (this)
/*      */     {
/*      */       try {
/* 3314 */         if (this.localJobFile != null) {
/* 3315 */           this.localFs.delete(this.localJobFile, true);
/* 3316 */           this.localJobFile = null;
/*      */         }
/*      */ 
/* 3319 */         Path tempDir = this.jobtracker.getSystemDirectoryForJob(getJobID());
/* 3320 */         CleanupQueue.getInstance().addToQueue(new CleanupQueue.PathDeletionContext[] { new CleanupQueue.PathDeletionContext(tempDir, this.conf) });
/*      */ 
/* 3324 */         String jobTempDir = this.conf.get("mapreduce.job.dir");
/* 3325 */         if ((jobTempDir != null) && (this.conf.getKeepTaskFilesPattern() == null) && (!this.conf.getKeepFailedTaskFiles()))
/*      */         {
/* 3327 */           Path jobTempDirPath = new Path(jobTempDir);
/* 3328 */           tempDirFs = jobTempDirPath.getFileSystem(this.conf);
/* 3329 */           CleanupQueue.getInstance().addToQueue(new CleanupQueue.PathDeletionContext[] { new CleanupQueue.PathDeletionContext(jobTempDirPath, this.conf, this.userUGI, this.jobId) });
/*      */         }
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/* 3334 */         LOG.warn("Error cleaning up " + this.profile.getJobID() + ": " + e);
/*      */       }
/*      */ 
/* 3337 */       cleanUpMetrics();
/*      */ 
/* 3339 */       this.failedMaps.clear();
/* 3340 */       this.nonRunningMapCache = null;
/* 3341 */       this.runningMapCache = null;
/* 3342 */       this.nonRunningReduces = null;
/* 3343 */       this.runningReduces = null;
/*      */     }
/*      */ 
/* 3348 */     if (tempDirFs != this.fs)
/*      */       try {
/* 3350 */         this.fs.close();
/*      */       } catch (IOException ie) {
/* 3352 */         LOG.warn("Ignoring exception " + StringUtils.stringifyException(ie) + " while closing FileSystem for " + this.userUGI);
/*      */       }
/*      */   }
/*      */ 
/*      */   public synchronized TaskInProgress getTaskInProgress(TaskID tipid)
/*      */   {
/* 3362 */     if (tipid.isMap()) {
/* 3363 */       if (tipid.equals(this.cleanup[0].getTIPId())) {
/* 3364 */         return this.cleanup[0];
/*      */       }
/* 3366 */       if (tipid.equals(this.setup[0].getTIPId())) {
/* 3367 */         return this.setup[0];
/*      */       }
/* 3369 */       for (int i = 0; i < this.maps.length; i++)
/* 3370 */         if (tipid.equals(this.maps[i].getTIPId()))
/* 3371 */           return this.maps[i];
/*      */     }
/*      */     else
/*      */     {
/* 3375 */       if (tipid.equals(this.cleanup[1].getTIPId())) {
/* 3376 */         return this.cleanup[1];
/*      */       }
/* 3378 */       if (tipid.equals(this.setup[1].getTIPId())) {
/* 3379 */         return this.setup[1];
/*      */       }
/* 3381 */       for (int i = 0; i < this.reduces.length; i++) {
/* 3382 */         if (tipid.equals(this.reduces[i].getTIPId())) {
/* 3383 */           return this.reduces[i];
/*      */         }
/*      */       }
/*      */     }
/* 3387 */     return null;
/*      */   }
/*      */ 
/*      */   public synchronized TaskStatus findFinishedMap(int mapId)
/*      */   {
/* 3396 */     TaskInProgress tip = this.maps[mapId];
/* 3397 */     if (tip.isComplete()) {
/* 3398 */       TaskStatus[] statuses = tip.getTaskStatuses();
/* 3399 */       for (int i = 0; i < statuses.length; i++) {
/* 3400 */         if (statuses[i].getRunState() == TaskStatus.State.SUCCEEDED) {
/* 3401 */           return statuses[i];
/*      */         }
/*      */       }
/*      */     }
/* 3405 */     return null;
/*      */   }
/*      */ 
/*      */   synchronized int getNumTaskCompletionEvents() {
/* 3409 */     return this.taskCompletionEvents.size();
/*      */   }
/*      */ 
/*      */   public synchronized TaskCompletionEvent[] getTaskCompletionEvents(int fromEventId, int maxEvents)
/*      */   {
/* 3414 */     TaskCompletionEvent[] events = TaskCompletionEvent.EMPTY_ARRAY;
/* 3415 */     if (this.taskCompletionEvents.size() > fromEventId) {
/* 3416 */       int actualMax = Math.min(maxEvents, this.taskCompletionEvents.size() - fromEventId);
/*      */ 
/* 3418 */       events = (TaskCompletionEvent[])this.taskCompletionEvents.subList(fromEventId, actualMax + fromEventId).toArray(events);
/*      */     }
/* 3420 */     return events;
/*      */   }
/*      */ 
/*      */   synchronized void fetchFailureNotification(TaskInProgress tip, TaskAttemptID mapTaskId, String mapTrackerName, TaskAttemptID reduceTaskId, String reduceTrackerName)
/*      */   {
/* 3428 */     Integer fetchFailures = (Integer)this.mapTaskIdToFetchFailuresMap.get(mapTaskId);
/* 3429 */     fetchFailures = Integer.valueOf(fetchFailures == null ? 1 : fetchFailures.intValue() + 1);
/* 3430 */     this.mapTaskIdToFetchFailuresMap.put(mapTaskId, fetchFailures);
/* 3431 */     LOG.info("Failed fetch notification #" + fetchFailures + " for map task: " + mapTaskId + " running on tracker: " + mapTrackerName + " and reduce task: " + reduceTaskId + " running on tracker: " + reduceTrackerName);
/*      */ 
/* 3436 */     float failureRate = fetchFailures.intValue() / this.runningReduceTasks;
/*      */ 
/* 3438 */     boolean isMapFaulty = failureRate >= 0.5D;
/* 3439 */     if ((fetchFailures.intValue() >= 3) && (isMapFaulty))
/*      */     {
/* 3441 */       LOG.info("Too many fetch-failures for output of task: " + mapTaskId + " ... killing it");
/*      */ 
/* 3444 */       failedTask(tip, mapTaskId, "Too many fetch-failures", tip.isMapTask() ? TaskStatus.Phase.MAP : TaskStatus.Phase.REDUCE, TaskStatus.State.FAILED, mapTrackerName);
/*      */ 
/* 3449 */       this.mapTaskIdToFetchFailuresMap.remove(mapTaskId);
/*      */     }
/*      */   }
/*      */ 
/*      */   public JobID getJobID()
/*      */   {
/* 3457 */     return this.jobId;
/*      */   }
/*      */ 
/*      */   public String getJobSubmitHostName()
/*      */   {
/* 3464 */     return this.submitHostName;
/*      */   }
/*      */ 
/*      */   public String getJobSubmitHostAddress()
/*      */   {
/* 3471 */     return this.submitHostAddress;
/*      */   }
/*      */ 
/*      */   public synchronized Object getSchedulingInfo() {
/* 3475 */     return this.schedulingInfo;
/*      */   }
/*      */ 
/*      */   public synchronized void setSchedulingInfo(Object schedulingInfo) {
/* 3479 */     this.schedulingInfo = schedulingInfo;
/* 3480 */     this.status.setSchedulingInfo(schedulingInfo.toString());
/*      */   }
/*      */ 
/*      */   boolean isComplete()
/*      */   {
/* 3497 */     return this.status.isJobComplete();
/*      */   }
/*      */ 
/*      */   private String getTaskType(TaskInProgress tip)
/*      */   {
/* 3504 */     if (tip.isJobCleanupTask())
/* 3505 */       return JobHistory.Values.CLEANUP.name();
/* 3506 */     if (tip.isJobSetupTask())
/* 3507 */       return JobHistory.Values.SETUP.name();
/* 3508 */     if (tip.isMapTask()) {
/* 3509 */       return JobHistory.Values.MAP.name();
/*      */     }
/* 3511 */     return JobHistory.Values.REDUCE.name();
/*      */   }
/*      */ 
/*      */   void setClusterSize(int clusterSize)
/*      */   {
/* 3519 */     this.clusterSize = clusterSize;
/*      */   }
/*      */ 
/*      */   int getLocalityLevel(TaskInProgress tip, TaskTrackerStatus tts)
/*      */   {
/* 3622 */     Node tracker = this.jobtracker.getNode(tts.getHost());
/* 3623 */     int level = this.maxLevel;
/*      */ 
/* 3625 */     for (String local : this.maps[tip.getIdWithinJob()].getSplitLocations()) {
/* 3626 */       Node datanode = this.jobtracker.getNode(local);
/* 3627 */       int newLevel = this.maxLevel;
/* 3628 */       if ((tracker != null) && (datanode != null)) {
/* 3629 */         newLevel = getMatchingLevelForNodes(tracker, datanode);
/*      */       }
/* 3631 */       if (newLevel < level) {
/* 3632 */         level = newLevel;
/*      */ 
/* 3634 */         if (level == 0) {
/*      */           break;
/*      */         }
/*      */       }
/*      */     }
/* 3639 */     return level;
/*      */   }
/*      */ 
/*      */   static class JobSummary
/*      */   {
/* 3523 */     static final Log LOG = LogFactory.getLog(JobSummary.class);
/*      */     static final char EQUALS = '=';
/* 3527 */     static final char[] charsToEscape = { ',', '=', '\\' };
/*      */ 
/*      */     static SummaryBuilder getTaskLaunchTimesSummary(JobInProgress job)
/*      */     {
/* 3561 */       SummaryBuilder summary = new SummaryBuilder();
/* 3562 */       Map timeMap = job.getFirstTaskLaunchTimes();
/*      */ 
/* 3564 */       synchronized (timeMap) {
/* 3565 */         for (Map.Entry e : timeMap.entrySet()) {
/* 3566 */           summary.add("first" + StringUtils.camelize(((TaskType)e.getKey()).name()) + "TaskLaunchTime", ((Long)e.getValue()).longValue());
/*      */         }
/*      */       }
/*      */ 
/* 3570 */       return summary;
/*      */     }
/*      */ 
/*      */     public static void logJobSummary(JobInProgress job, ClusterStatus cluster)
/*      */     {
/* 3582 */       JobStatus status = job.getStatus();
/* 3583 */       JobProfile profile = job.getProfile();
/* 3584 */       Counters jobCounters = job.getJobCounters();
/* 3585 */       long mapSlotSeconds = (jobCounters.getCounter(JobInProgress.Counter.SLOTS_MILLIS_MAPS) + jobCounters.getCounter(JobInProgress.Counter.FALLOW_SLOTS_MILLIS_MAPS)) / 1000L;
/*      */ 
/* 3588 */       long reduceSlotSeconds = (jobCounters.getCounter(JobInProgress.Counter.SLOTS_MILLIS_REDUCES) + jobCounters.getCounter(JobInProgress.Counter.FALLOW_SLOTS_MILLIS_REDUCES)) / 1000L;
/*      */ 
/* 3592 */       SummaryBuilder summary = new SummaryBuilder().add("jobId", job.getJobID()).add("submitTime", job.getStartTime()).add("launchTime", job.getLaunchTime()).add(getTaskLaunchTimesSummary(job)).add("finishTime", job.getFinishTime()).add("numMaps", job.getTasks(TaskType.MAP).length).add("numSlotsPerMap", job.getNumSlotsPerMap()).add("numReduces", job.getTasks(TaskType.REDUCE).length).add("numSlotsPerReduce", job.getNumSlotsPerReduce()).add("user", profile.getUser()).add("queue", profile.getQueueName()).add("status", JobStatus.getJobRunState(status.getRunState())).add("mapSlotSeconds", mapSlotSeconds).add("reduceSlotsSeconds", reduceSlotSeconds).add("clusterMapCapacity", cluster.getMaxMapTasks()).add("clusterReduceCapacity", cluster.getMaxReduceTasks()).add("jobName", profile.getJobName());
/*      */ 
/* 3611 */       LOG.info(summary);
/*      */     }
/*      */ 
/*      */     static class SummaryBuilder
/*      */     {
/* 3531 */       final StringBuilder buffer = new StringBuilder();
/*      */ 
/*      */       SummaryBuilder add(String key, long value)
/*      */       {
/* 3535 */         return _add(key, Long.toString(value));
/*      */       }
/*      */ 
/*      */       <T> SummaryBuilder add(String key, T value) {
/* 3539 */         return _add(key, StringUtils.escapeString(String.valueOf(value), '\\', JobInProgress.JobSummary.charsToEscape));
/*      */       }
/*      */ 
/*      */       SummaryBuilder add(SummaryBuilder summary)
/*      */       {
/* 3544 */         if (this.buffer.length() > 0) this.buffer.append(',');
/* 3545 */         this.buffer.append(summary.buffer);
/* 3546 */         return this;
/*      */       }
/*      */ 
/*      */       SummaryBuilder _add(String key, String value) {
/* 3550 */         if (this.buffer.length() > 0) this.buffer.append(',');
/* 3551 */         this.buffer.append(key).append('=').append(value);
/* 3552 */         return this;
/*      */       }
/*      */ 
/*      */       public String toString() {
/* 3556 */         return this.buffer.toString();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class JobInitKillStatus
/*      */   {
/*      */     boolean killed;
/*      */     boolean initStarted;
/*      */     boolean initDone;
/*      */   }
/*      */ 
/*      */   private static class FallowSlotInfo
/*      */   {
/*      */     long timestamp;
/*      */     int numSlots;
/*      */ 
/*      */     public FallowSlotInfo(long timestamp, int numSlots)
/*      */     {
/*  287 */       this.timestamp = timestamp;
/*  288 */       this.numSlots = numSlots;
/*      */     }
/*      */ 
/*      */     public long getTimestamp() {
/*  292 */       return this.timestamp;
/*      */     }
/*      */ 
/*      */     public void setTimestamp(long timestamp) {
/*  296 */       this.timestamp = timestamp;
/*      */     }
/*      */ 
/*      */     public int getNumSlots() {
/*  300 */       return this.numSlots;
/*      */     }
/*      */ 
/*      */     public void setNumSlots(int numSlots) {
/*  304 */       this.numSlots = numSlots;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static enum Counter
/*      */   {
/*  257 */     NUM_FAILED_MAPS, 
/*  258 */     NUM_FAILED_REDUCES, 
/*  259 */     TOTAL_LAUNCHED_MAPS, 
/*  260 */     TOTAL_LAUNCHED_REDUCES, 
/*  261 */     OTHER_LOCAL_MAPS, 
/*  262 */     DATA_LOCAL_MAPS, 
/*  263 */     NODEGROUP_LOCAL_MAPS, 
/*  264 */     RACK_LOCAL_MAPS, 
/*  265 */     SLOTS_MILLIS_MAPS, 
/*  266 */     SLOTS_MILLIS_REDUCES, 
/*  267 */     FALLOW_SLOTS_MILLIS_MAPS, 
/*  268 */     FALLOW_SLOTS_MILLIS_REDUCES;
/*      */   }
/*      */ 
/*      */   static class KillInterruptedException extends InterruptedException
/*      */   {
/*      */     public KillInterruptedException(String msg)
/*      */     {
/*   81 */       super();
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JobInProgress
 * JD-Core Version:    0.6.1
 */
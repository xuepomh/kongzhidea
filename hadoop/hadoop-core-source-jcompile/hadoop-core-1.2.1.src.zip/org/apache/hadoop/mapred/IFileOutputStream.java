/*    */ package org.apache.hadoop.mapred;
/*    */ 
/*    */ import java.io.FilterOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import org.apache.hadoop.util.DataChecksum;
/*    */ 
/*    */ class IFileOutputStream extends FilterOutputStream
/*    */ {
/*    */   private final DataChecksum sum;
/*    */   private byte[] barray;
/* 38 */   private boolean closed = false;
/* 39 */   private boolean finished = false;
/*    */ 
/*    */   public IFileOutputStream(OutputStream out)
/*    */   {
/* 47 */     super(out);
/* 48 */     this.sum = DataChecksum.newDataChecksum(1, 2147483647);
/*    */ 
/* 50 */     this.barray = new byte[this.sum.getChecksumSize()];
/*    */   }
/*    */ 
/*    */   public void close() throws IOException
/*    */   {
/* 55 */     if (this.closed) {
/* 56 */       return;
/*    */     }
/* 58 */     this.closed = true;
/* 59 */     finish();
/* 60 */     this.out.close();
/*    */   }
/*    */ 
/*    */   public void finish()
/*    */     throws IOException
/*    */   {
/* 69 */     if (this.finished) {
/* 70 */       return;
/*    */     }
/* 72 */     this.finished = true;
/* 73 */     this.sum.writeValue(this.barray, 0, false);
/* 74 */     this.out.write(this.barray, 0, this.sum.getChecksumSize());
/* 75 */     this.out.flush();
/*    */   }
/*    */ 
/*    */   public void write(byte[] b, int off, int len)
/*    */     throws IOException
/*    */   {
/* 83 */     this.sum.update(b, off, len);
/* 84 */     this.out.write(b, off, len);
/*    */   }
/*    */ 
/*    */   public void write(int b) throws IOException
/*    */   {
/* 89 */     this.barray[0] = (byte)(b & 0xFF);
/* 90 */     write(this.barray, 0, 1);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.IFileOutputStream
 * JD-Core Version:    0.6.1
 */
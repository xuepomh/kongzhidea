/*    */ package org.apache.hadoop.mapred;
/*    */ 
/*    */ class Clock
/*    */ {
/*    */   long getTime()
/*    */   {
/* 26 */     return System.currentTimeMillis();
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.Clock
 * JD-Core Version:    0.6.1
 */
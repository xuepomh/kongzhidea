/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.text.NumberFormat;
/*     */ 
/*     */ class JVMId extends ID
/*     */ {
/*     */   boolean isMap;
/*     */   JobID jobId;
/*     */   private static final String JVM = "jvm";
/*  30 */   private static NumberFormat idFormat = NumberFormat.getInstance();
/*     */ 
/*     */   public JVMId(JobID jobId, boolean isMap, int id)
/*     */   {
/*  37 */     super(id);
/*  38 */     this.isMap = isMap;
/*  39 */     this.jobId = jobId;
/*     */   }
/*     */ 
/*     */   public JVMId(String jtIdentifier, int jobId, boolean isMap, int id) {
/*  43 */     this(new JobID(jtIdentifier, jobId), isMap, id);
/*     */   }
/*     */ 
/*     */   public JVMId() {
/*  47 */     this.jobId = new JobID();
/*     */   }
/*     */ 
/*     */   public boolean isMapJVM() {
/*  51 */     return this.isMap;
/*     */   }
/*     */   public JobID getJobId() {
/*  54 */     return this.jobId;
/*     */   }
/*     */   public boolean equals(Object o) {
/*  57 */     if (o == null)
/*  58 */       return false;
/*  59 */     if (o.getClass().equals(JVMId.class)) {
/*  60 */       JVMId that = (JVMId)o;
/*  61 */       return (this.id == that.id) && (this.isMap == that.isMap) && (this.jobId.equals(that.jobId));
/*     */     }
/*     */ 
/*  65 */     return false;
/*     */   }
/*     */ 
/*     */   public int compareTo(org.apache.hadoop.mapreduce.ID o)
/*     */   {
/*  72 */     JVMId that = (JVMId)o;
/*  73 */     int jobComp = this.jobId.compareTo(that.jobId);
/*  74 */     if (jobComp == 0) {
/*  75 */       if (this.isMap == that.isMap) {
/*  76 */         return this.id - that.id;
/*     */       }
/*  78 */       return this.isMap ? -1 : 1;
/*     */     }
/*     */ 
/*  81 */     return jobComp;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  87 */     return appendTo(new StringBuilder("jvm")).toString();
/*     */   }
/*     */ 
/*     */   protected StringBuilder appendTo(StringBuilder builder)
/*     */   {
/*  96 */     return this.jobId.appendTo(builder).append('_').append(this.isMap ? 'm' : 'r').append('_').append(idFormat.format(this.id));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 105 */     return this.jobId.hashCode() * 11 + this.id;
/*     */   }
/*     */ 
/*     */   public void readFields(DataInput in) throws IOException
/*     */   {
/* 110 */     super.readFields(in);
/* 111 */     this.jobId.readFields(in);
/* 112 */     this.isMap = in.readBoolean();
/*     */   }
/*     */ 
/*     */   public void write(DataOutput out) throws IOException
/*     */   {
/* 117 */     super.write(out);
/* 118 */     this.jobId.write(out);
/* 119 */     out.writeBoolean(this.isMap);
/*     */   }
/*     */ 
/*     */   public static JVMId forName(String str)
/*     */     throws IllegalArgumentException
/*     */   {
/* 128 */     if (str == null)
/* 129 */       return null;
/*     */     try {
/* 131 */       String[] parts = str.split("_");
/* 132 */       if ((parts.length == 5) && 
/* 133 */         (parts[0].equals("jvm"))) {
/* 134 */         boolean isMap = false;
/* 135 */         if (parts[3].equals("m")) isMap = true;
/* 136 */         else if (parts[3].equals("r")) isMap = false; else
/* 137 */           throw new Exception();
/* 138 */         return new JVMId(parts[1], Integer.parseInt(parts[2]), isMap, Integer.parseInt(parts[4]));
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/* 144 */     throw new IllegalArgumentException(new StringBuilder().append("TaskId string : ").append(str).append(" is not properly formed").toString());
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  32 */     idFormat.setGroupingUsed(false);
/*  33 */     idFormat.setMinimumIntegerDigits(6);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JVMId
 * JD-Core Version:    0.6.1
 */
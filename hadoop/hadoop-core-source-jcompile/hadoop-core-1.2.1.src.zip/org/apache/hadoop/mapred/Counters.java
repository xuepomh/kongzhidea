/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.text.ParseException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.io.IntWritable;
/*     */ import org.apache.hadoop.io.Text;
/*     */ import org.apache.hadoop.io.Writable;
/*     */ import org.apache.hadoop.io.WritableUtils;
/*     */ import org.apache.hadoop.mapreduce.Counter;
/*     */ import org.apache.hadoop.mapreduce.CounterGroup;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ public class Counters
/*     */   implements Writable, Iterable<Group>
/*     */ {
/*  53 */   private static final Log LOG = LogFactory.getLog(Counters.class);
/*     */   private static final char GROUP_OPEN = '{';
/*     */   private static final char GROUP_CLOSE = '}';
/*     */   private static final char COUNTER_OPEN = '[';
/*     */   private static final char COUNTER_CLOSE = ']';
/*     */   private static final char UNIT_OPEN = '(';
/*     */   private static final char UNIT_CLOSE = ')';
/*  60 */   private static char[] charsToEscape = { '{', '}', '[', ']', '(', ')' };
/*     */ 
/*  63 */   private static final JobConf conf = new JobConf();
/*     */ 
/*  65 */   private static final int GROUP_NAME_LIMIT = conf.getInt("mapreduce.job.counters.group.name.max", 128);
/*     */ 
/*  68 */   private static final int COUNTER_NAME_LIMIT = conf.getInt("mapreduce.job.counters.counter.name.max", 64);
/*     */ 
/*  72 */   public static int MAX_COUNTER_LIMIT = conf.getInt("mapreduce.job.counters.limit", conf.getInt("mapreduce.job.counters.max", 120));
/*     */ 
/*  77 */   public static final int MAX_GROUP_LIMIT = conf.getInt("mapreduce.job.counters.groups.max", 50);
/*     */   private int numCounters;
/*     */   private Map<String, Group> counters;
/*     */   private Map<Enum, Counter> cache;
/*     */ 
/*     */   public Counters()
/*     */   {
/*  81 */     this.numCounters = 0;
/*     */ 
/* 380 */     this.counters = new HashMap();
/*     */ 
/* 386 */     this.cache = new IdentityHashMap();
/*     */   }
/*     */ 
/*     */   public synchronized Collection<String> getGroupNames()
/*     */   {
/* 393 */     return this.counters.keySet();
/*     */   }
/*     */ 
/*     */   public synchronized Iterator<Group> iterator() {
/* 397 */     return this.counters.values().iterator();
/*     */   }
/*     */ 
/*     */   public synchronized Group getGroup(String groupName)
/*     */   {
/* 405 */     String shortGroupName = getShortName(groupName, GROUP_NAME_LIMIT);
/* 406 */     Group result = (Group)this.counters.get(shortGroupName);
/* 407 */     if (result == null)
/*     */     {
/* 409 */       if (this.counters.size() > MAX_GROUP_LIMIT) {
/* 410 */         throw new RuntimeException(new StringBuilder().append("Error: Exceeded limits on number of groups in counters - Groups=").append(this.counters.size()).append(" Limit=").append(MAX_GROUP_LIMIT).toString());
/*     */       }
/*     */ 
/* 414 */       result = new Group(shortGroupName);
/* 415 */       this.counters.put(shortGroupName, result);
/*     */     }
/* 417 */     return result;
/*     */   }
/*     */ 
/*     */   public synchronized Counter findCounter(Enum key)
/*     */   {
/* 427 */     Counter counter = (Counter)this.cache.get(key);
/* 428 */     if (counter == null) {
/* 429 */       Group group = getGroup(key.getDeclaringClass().getName());
/* 430 */       if (group != null) {
/* 431 */         counter = group.getCounterForName(key.toString());
/* 432 */         if (counter != null) this.cache.put(key, counter);
/*     */       }
/*     */     }
/* 435 */     return counter;
/*     */   }
/*     */ 
/*     */   public synchronized Counter findCounter(String group, String name)
/*     */   {
/* 445 */     Group retGroup = getGroup(group);
/* 446 */     return retGroup == null ? null : retGroup.getCounterForName(name);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public synchronized Counter findCounter(String group, int id, String name)
/*     */   {
/* 459 */     Group retGroup = getGroup(group);
/* 460 */     return retGroup == null ? null : retGroup.getCounterForName(name);
/*     */   }
/*     */ 
/*     */   public synchronized void incrCounter(Enum key, long amount)
/*     */   {
/* 470 */     findCounter(key).increment(amount);
/*     */   }
/*     */ 
/*     */   public synchronized void incrCounter(String group, String counter, long amount)
/*     */   {
/* 481 */     Group retGroup = getGroup(group);
/* 482 */     if (retGroup != null) {
/* 483 */       Counter retCounter = retGroup.getCounterForName(counter);
/* 484 */       if (retCounter != null)
/* 485 */         retCounter.increment(amount);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized long getCounter(Enum key)
/*     */   {
/* 495 */     Counter retCounter = findCounter(key);
/* 496 */     return retCounter == null ? 0L : retCounter.getValue();
/*     */   }
/*     */ 
/*     */   public synchronized void incrAllCounters(Counters other)
/*     */   {
/* 505 */     for (Group otherGroup : other) {
/* 506 */       group = getGroup(otherGroup.getName());
/* 507 */       if (group != null)
/*     */       {
/* 510 */         group.displayName = otherGroup.displayName;
/* 511 */         for (Counter otherCounter : otherGroup) {
/* 512 */           Counter counter = group.getCounterForName(otherCounter.getName());
/* 513 */           if (counter != null)
/*     */           {
/* 516 */             counter.setDisplayName(otherCounter.getDisplayName());
/* 517 */             counter.increment(otherCounter.getValue());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     Group group;
/*     */   }
/*     */ 
/*     */   public static Counters sum(Counters a, Counters b) {
/* 526 */     Counters counters = new Counters();
/* 527 */     counters.incrAllCounters(a);
/* 528 */     counters.incrAllCounters(b);
/* 529 */     return counters;
/*     */   }
/*     */ 
/*     */   public synchronized int size()
/*     */   {
/* 537 */     int result = 0;
/* 538 */     for (Group group : this) {
/* 539 */       result += group.size();
/*     */     }
/* 541 */     return result;
/*     */   }
/*     */ 
/*     */   public synchronized void write(DataOutput out)
/*     */     throws IOException
/*     */   {
/* 559 */     out.writeInt(this.counters.size());
/* 560 */     for (Group group : this.counters.values()) {
/* 561 */       Text.writeString(out, group.getName());
/* 562 */       group.write(out);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void readFields(DataInput in)
/*     */     throws IOException
/*     */   {
/* 570 */     int numClasses = in.readInt();
/* 571 */     this.counters.clear();
/* 572 */     while (numClasses-- > 0) {
/* 573 */       String groupName = Text.readString(in);
/* 574 */       Group group = new Group(groupName);
/* 575 */       group.readFields(in);
/* 576 */       this.counters.put(groupName, group);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void log(Log log)
/*     */   {
/* 585 */     log.info(new StringBuilder().append("Counters: ").append(size()).toString());
/* 586 */     for (Group group : this) {
/* 587 */       log.info(new StringBuilder().append("  ").append(group.getDisplayName()).toString());
/* 588 */       for (Counter counter : group)
/* 589 */         log.info(new StringBuilder().append("    ").append(counter.getDisplayName()).append("=").append(counter.getCounter()).toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized String toString()
/*     */   {
/* 599 */     StringBuilder sb = new StringBuilder(new StringBuilder().append("Counters: ").append(size()).toString());
/* 600 */     for (Group group : this) {
/* 601 */       sb.append(new StringBuilder().append("\n\t").append(group.getDisplayName()).toString());
/* 602 */       for (Counter counter : group) {
/* 603 */         sb.append(new StringBuilder().append("\n\t\t").append(counter.getDisplayName()).append("=").append(counter.getCounter()).toString());
/*     */       }
/*     */     }
/*     */ 
/* 607 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public synchronized String makeCompactString()
/*     */   {
/* 615 */     StringBuffer buffer = new StringBuffer();
/* 616 */     boolean first = true;
/* 617 */     for (Iterator i$ = iterator(); i$.hasNext(); ) { group = (Group)i$.next();
/* 618 */       for (Counter counter : group) {
/* 619 */         if (first)
/* 620 */           first = false;
/*     */         else {
/* 622 */           buffer.append(',');
/*     */         }
/* 624 */         buffer.append(group.getDisplayName());
/* 625 */         buffer.append('.');
/* 626 */         buffer.append(counter.getDisplayName());
/* 627 */         buffer.append(':');
/* 628 */         buffer.append(counter.getCounter());
/*     */       }
/*     */     }
/*     */     Group group;
/* 631 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public synchronized String makeEscapedCompactString()
/*     */   {
/* 641 */     String[] groupsArray = new String[this.counters.size()];
/* 642 */     int i = 0;
/* 643 */     int length = 0;
/*     */ 
/* 647 */     for (Group group : this) {
/* 648 */       String escapedString = group.makeEscapedCompactString();
/* 649 */       groupsArray[(i++)] = escapedString;
/* 650 */       length += escapedString.length();
/*     */     }
/*     */ 
/* 654 */     StringBuilder builder = new StringBuilder(length);
/* 655 */     for (String group : groupsArray) {
/* 656 */       builder.append(group);
/*     */     }
/* 658 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   static String getShortName(String name, int limit)
/*     */   {
/* 669 */     return name.length() > limit ? name.substring(name.length() - limit, name.length()) : name;
/*     */   }
/*     */ 
/*     */   private static String getBlock(String str, char open, char close, IntWritable index)
/*     */     throws ParseException
/*     */   {
/* 678 */     StringBuilder split = new StringBuilder();
/* 679 */     int next = StringUtils.findNext(str, open, '\\', index.get(), split);
/*     */ 
/* 681 */     split.setLength(0);
/* 682 */     if (next >= 0) {
/* 683 */       next++;
/*     */ 
/* 685 */       next = StringUtils.findNext(str, close, '\\', next, split);
/*     */ 
/* 687 */       if (next >= 0) {
/* 688 */         next++;
/* 689 */         index.set(next);
/* 690 */         return split.toString();
/*     */       }
/* 692 */       throw new ParseException("Unexpected end of block", next);
/*     */     }
/*     */ 
/* 695 */     return null;
/*     */   }
/*     */ 
/*     */   public static Counters fromEscapedCompactString(String compactString)
/*     */     throws ParseException
/*     */   {
/* 706 */     Counters counters = new Counters();
/* 707 */     IntWritable index = new IntWritable(0);
/*     */ 
/* 710 */     String groupString = getBlock(compactString, '{', '}', index);
/*     */ 
/* 713 */     while (groupString != null) {
/* 714 */       IntWritable groupIndex = new IntWritable(0);
/*     */ 
/* 717 */       String groupName = getBlock(groupString, '(', ')', groupIndex);
/*     */ 
/* 719 */       groupName = unescape(groupName);
/*     */ 
/* 722 */       String groupDisplayName = getBlock(groupString, '(', ')', groupIndex);
/*     */ 
/* 724 */       groupDisplayName = unescape(groupDisplayName);
/*     */ 
/* 727 */       Group group = counters.getGroup(groupName);
/* 728 */       group.setDisplayName(groupDisplayName);
/*     */ 
/* 730 */       String counterString = getBlock(groupString, '[', ']', groupIndex);
/*     */ 
/* 733 */       while (counterString != null) {
/* 734 */         IntWritable counterIndex = new IntWritable(0);
/*     */ 
/* 737 */         String counterName = getBlock(counterString, '(', ')', counterIndex);
/*     */ 
/* 739 */         counterName = unescape(counterName);
/*     */ 
/* 742 */         String counterDisplayName = getBlock(counterString, '(', ')', counterIndex);
/*     */ 
/* 744 */         counterDisplayName = unescape(counterDisplayName);
/*     */ 
/* 747 */         long value = Long.parseLong(getBlock(counterString, '(', ')', counterIndex));
/*     */ 
/* 752 */         Counter counter = group.getCounterForName(counterName);
/* 753 */         counter.setDisplayName(counterDisplayName);
/* 754 */         counter.increment(value);
/*     */ 
/* 757 */         counterString = getBlock(groupString, '[', ']', groupIndex);
/*     */       }
/*     */ 
/* 761 */       groupString = getBlock(compactString, '{', '}', index);
/*     */     }
/* 763 */     return counters;
/*     */   }
/*     */ 
/*     */   private static String escape(String string)
/*     */   {
/* 768 */     return StringUtils.escapeString(string, '\\', charsToEscape);
/*     */   }
/*     */ 
/*     */   private static String unescape(String string)
/*     */   {
/* 774 */     return StringUtils.unEscapeString(string, '\\', charsToEscape);
/*     */   }
/*     */ 
/*     */   public synchronized int hashCode()
/*     */   {
/* 780 */     return this.counters.hashCode();
/*     */   }
/*     */ 
/*     */   public synchronized boolean equals(Object obj)
/*     */   {
/* 785 */     boolean isEqual = false;
/*     */     Counters other;
/* 786 */     if ((obj != null) && ((obj instanceof Counters))) {
/* 787 */       other = (Counters)obj;
/* 788 */       if (size() == other.size()) {
/* 789 */         isEqual = true;
/* 790 */         for (Map.Entry entry : this.counters.entrySet()) {
/* 791 */           String key = (String)entry.getKey();
/* 792 */           Group sourceGroup = (Group)entry.getValue();
/* 793 */           Group targetGroup = other.getGroup(key);
/* 794 */           if (!sourceGroup.equals(targetGroup)) {
/* 795 */             isEqual = false;
/* 796 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 801 */     return isEqual;
/*     */   }
/*     */ 
/*     */   public static class CountersExceededException extends RuntimeException
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public CountersExceededException(String msg)
/*     */     {
/* 813 */       super();
/*     */     }
/*     */   }
/*     */ 
/*     */   public class Group
/*     */     implements Writable, Iterable<Counters.Counter>
/*     */   {
/*     */     private String groupName;
/*     */     private String displayName;
/* 164 */     private Map<String, Counters.Counter> subcounters = new HashMap();
/*     */ 
/* 167 */     private ResourceBundle bundle = null;
/*     */ 
/*     */     Group(String groupName) {
/*     */       try {
/* 171 */         this.bundle = CounterGroup.getResourceBundle(groupName);
/*     */       }
/*     */       catch (MissingResourceException localMissingResourceException)
/*     */       {
/*     */       }
/*     */       ???;
/* 175 */       this.groupName = groupName;
/* 176 */       this.displayName = localize("CounterGroupName", groupName);
/* 177 */       if (Counters.LOG.isDebugEnabled())
/* 178 */         Counters.LOG.debug(new StringBuilder().append("Creating group ").append(groupName).append(" with ").append(this.bundle == null ? "nothing" : "bundle").toString());
/*     */     }
/*     */ 
/*     */     public String getName()
/*     */     {
/* 188 */       return this.groupName;
/*     */     }
/*     */ 
/*     */     public String getDisplayName()
/*     */     {
/* 196 */       return this.displayName;
/*     */     }
/*     */ 
/*     */     public void setDisplayName(String displayName)
/*     */     {
/* 203 */       this.displayName = displayName;
/*     */     }
/*     */ 
/*     */     public String makeEscapedCompactString()
/*     */     {
/* 212 */       String[] subcountersArray = new String[this.subcounters.size()];
/*     */ 
/* 216 */       String escapedName = Counters.escape(getName());
/* 217 */       String escapedDispName = Counters.escape(getDisplayName());
/* 218 */       int i = 0;
/* 219 */       int length = escapedName.length() + escapedDispName.length();
/* 220 */       for (Counters.Counter counter : this.subcounters.values()) {
/* 221 */         String escapedStr = counter.makeEscapedCompactString();
/* 222 */         subcountersArray[(i++)] = escapedStr;
/* 223 */         length += escapedStr.length();
/*     */       }
/*     */ 
/* 226 */       length += 6;
/* 227 */       StringBuilder builder = new StringBuilder(length);
/* 228 */       builder.append('{');
/*     */ 
/* 231 */       builder.append('(');
/* 232 */       builder.append(escapedName);
/* 233 */       builder.append(')');
/*     */ 
/* 236 */       builder.append('(');
/* 237 */       builder.append(escapedDispName);
/* 238 */       builder.append(')');
/*     */ 
/* 241 */       for (String str : subcountersArray) {
/* 242 */         builder.append(str);
/*     */       }
/*     */ 
/* 245 */       builder.append('}');
/* 246 */       return builder.toString();
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 251 */       return this.subcounters.hashCode();
/*     */     }
/*     */ 
/*     */     public synchronized boolean equals(Object obj)
/*     */     {
/* 259 */       boolean isEqual = false;
/*     */       Group g;
/* 260 */       if ((obj != null) && ((obj instanceof Group))) {
/* 261 */         g = (Group)obj;
/* 262 */         if (size() == g.size()) {
/* 263 */           isEqual = true;
/* 264 */           for (Map.Entry entry : this.subcounters.entrySet()) {
/* 265 */             String key = (String)entry.getKey();
/* 266 */             Counters.Counter c1 = (Counters.Counter)entry.getValue();
/* 267 */             Counters.Counter c2 = g.getCounterForName(key);
/* 268 */             if (!c1.contentEquals(c2)) {
/* 269 */               isEqual = false;
/* 270 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 275 */       return isEqual;
/*     */     }
/*     */ 
/*     */     public synchronized long getCounter(String counterName)
/*     */     {
/* 283 */       for (Counters.Counter counter : this.subcounters.values()) {
/* 284 */         if ((counter != null) && (counter.getDisplayName().equals(counterName))) {
/* 285 */           return counter.getValue();
/*     */         }
/*     */       }
/* 288 */       return 0L;
/*     */     }
/*     */ 
/*     */     @Deprecated
/*     */     public Counters.Counter getCounter(int id, String name)
/*     */     {
/* 300 */       return getCounterForName(name);
/*     */     }
/*     */ 
/*     */     public Counters.Counter getCounterForName(String name)
/*     */     {
/* 309 */       synchronized (Counters.this) {
/* 310 */         synchronized (this) {
/* 311 */           String shortName = Counters.getShortName(name, Counters.COUNTER_NAME_LIMIT);
/* 312 */           Counters.Counter result = (Counters.Counter)this.subcounters.get(shortName);
/* 313 */           if (result == null) {
/* 314 */             if (Counters.LOG.isDebugEnabled()) {
/* 315 */               Counters.LOG.debug(new StringBuilder().append("Adding ").append(shortName).toString());
/*     */             }
/* 317 */             Counters.this.numCounters = (Counters.this.numCounters == 0 ? Counters.this.size() : Counters.this.numCounters);
/* 318 */             if (Counters.this.numCounters >= Counters.MAX_COUNTER_LIMIT) {
/* 319 */               throw new Counters.CountersExceededException(new StringBuilder().append("Error: Exceeded limits on number of counters - Counters=").append(Counters.this.numCounters).append(" Limit=").append(Counters.MAX_COUNTER_LIMIT).toString());
/*     */             }
/*     */ 
/* 322 */             result = new Counters.Counter(shortName, localize(new StringBuilder().append(shortName).append(".name").toString(), shortName), 0L);
/* 323 */             this.subcounters.put(shortName, result);
/* 324 */             Counters.access$308(Counters.this);
/*     */           }
/* 326 */           return result;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public synchronized int size()
/*     */     {
/* 335 */       return this.subcounters.size();
/*     */     }
/*     */ 
/*     */     private String localize(String key, String defaultValue)
/*     */     {
/* 343 */       String result = defaultValue;
/* 344 */       if (this.bundle != null)
/*     */         try {
/* 346 */           result = this.bundle.getString(key);
/*     */         }
/*     */         catch (MissingResourceException mre)
/*     */         {
/*     */         }
/* 351 */       return result;
/*     */     }
/*     */ 
/*     */     public synchronized void write(DataOutput out) throws IOException {
/* 355 */       Text.writeString(out, this.displayName);
/* 356 */       WritableUtils.writeVInt(out, this.subcounters.size());
/* 357 */       for (Counters.Counter counter : this.subcounters.values())
/* 358 */         counter.write(out);
/*     */     }
/*     */ 
/*     */     public synchronized void readFields(DataInput in) throws IOException
/*     */     {
/* 363 */       this.displayName = Text.readString(in);
/* 364 */       this.subcounters.clear();
/* 365 */       int size = WritableUtils.readVInt(in);
/* 366 */       for (int i = 0; i < size; i++) {
/* 367 */         Counters.Counter counter = new Counters.Counter();
/* 368 */         counter.readFields(in);
/* 369 */         this.subcounters.put(counter.getName(), counter);
/*     */       }
/*     */     }
/*     */ 
/*     */     public synchronized Iterator<Counters.Counter> iterator() {
/* 374 */       return new ArrayList(this.subcounters.values()).iterator();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Counter extends Counter
/*     */   {
/*     */     Counter()
/*     */     {
/*     */     }
/*     */ 
/*     */     Counter(String name, String displayName, long value)
/*     */     {
/*  94 */       super(displayName);
/*  95 */       increment(value);
/*     */     }
/*     */ 
/*     */     public void setDisplayName(String newName) {
/*  99 */       super.setDisplayName(newName);
/*     */     }
/*     */ 
/*     */     public synchronized String makeEscapedCompactString()
/*     */     {
/* 110 */       String escapedName = Counters.escape(getName());
/* 111 */       String escapedDispName = Counters.escape(getDisplayName());
/* 112 */       long currentValue = getValue();
/* 113 */       int length = escapedName.length() + escapedDispName.length() + 4;
/*     */ 
/* 115 */       length += 8;
/* 116 */       StringBuilder builder = new StringBuilder(length);
/* 117 */       builder.append('[');
/*     */ 
/* 120 */       builder.append('(');
/* 121 */       builder.append(escapedName);
/* 122 */       builder.append(')');
/*     */ 
/* 125 */       builder.append('(');
/* 126 */       builder.append(escapedDispName);
/* 127 */       builder.append(')');
/*     */ 
/* 130 */       builder.append('(');
/* 131 */       builder.append(currentValue);
/* 132 */       builder.append(')');
/*     */ 
/* 134 */       builder.append(']');
/*     */ 
/* 136 */       return builder.toString();
/*     */     }
/*     */ 
/*     */     synchronized boolean contentEquals(Counter c)
/*     */     {
/* 141 */       return equals(c);
/*     */     }
/*     */ 
/*     */     public synchronized long getCounter()
/*     */     {
/* 149 */       return getValue();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.Counters
 * JD-Core Version:    0.6.1
 */
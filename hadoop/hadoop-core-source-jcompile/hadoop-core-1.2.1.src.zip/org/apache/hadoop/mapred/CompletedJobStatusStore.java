/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FSDataInputStream;
/*     */ import org.apache.hadoop.fs.FSDataOutputStream;
/*     */ import org.apache.hadoop.fs.FileStatus;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.fs.permission.FsAction;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.security.AccessControlException;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.util.DiskChecker.DiskErrorException;
/*     */ 
/*     */ class CompletedJobStatusStore
/*     */   implements Runnable
/*     */ {
/*     */   private boolean active;
/*     */   private String jobInfoDir;
/*     */   private long retainTime;
/*     */   private FileSystem fs;
/*     */   private static final String JOB_INFO_STORE_DIR = "/jobtracker/jobsInfo";
/*     */   private ACLsManager aclsManager;
/*  56 */   public static final Log LOG = LogFactory.getLog(CompletedJobStatusStore.class);
/*     */ 
/*  59 */   private static long HOUR = 3600000L;
/*  60 */   private static long SLEEP_TIME = 1L * HOUR;
/*  61 */   static final FsPermission JOB_STATUS_STORE_DIR_PERMISSION = FsPermission.createImmutable((short)488);
/*     */ 
/*     */   CompletedJobStatusStore(Configuration conf, ACLsManager aclsManager)
/*     */     throws IOException
/*     */   {
/*  66 */     this.active = conf.getBoolean("mapred.job.tracker.persist.jobstatus.active", false);
/*     */ 
/*  69 */     if (this.active) {
/*  70 */       this.retainTime = (conf.getInt("mapred.job.tracker.persist.jobstatus.hours", 0) * HOUR);
/*     */ 
/*  73 */       this.jobInfoDir = conf.get("mapred.job.tracker.persist.jobstatus.dir", "/jobtracker/jobsInfo");
/*     */ 
/*  76 */       Path path = new Path(this.jobInfoDir);
/*     */ 
/*  79 */       this.fs = path.getFileSystem(conf);
/*  80 */       if (!this.fs.exists(path)) {
/*  81 */         if (!this.fs.mkdirs(path, new FsPermission(JOB_STATUS_STORE_DIR_PERMISSION))) {
/*  82 */           throw new IOException("CompletedJobStatusStore mkdirs failed to create " + path.toString());
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*  87 */         FileStatus stat = this.fs.getFileStatus(path);
/*  88 */         FsPermission actual = stat.getPermission();
/*  89 */         if (!stat.isDir()) {
/*  90 */           throw new DiskChecker.DiskErrorException("not a directory: " + path.toString());
/*     */         }
/*  92 */         FsAction user = actual.getUserAction();
/*  93 */         if (!user.implies(FsAction.READ)) {
/*  94 */           throw new DiskChecker.DiskErrorException("directory is not readable: " + path.toString());
/*     */         }
/*  96 */         if (!user.implies(FsAction.WRITE)) {
/*  97 */           throw new DiskChecker.DiskErrorException("directory is not writable: " + path.toString());
/*     */         }
/*     */       }
/*     */ 
/* 101 */       if (this.retainTime == 0L)
/*     */       {
/* 103 */         deleteJobStatusDirs();
/*     */       }
/*     */ 
/* 106 */       this.aclsManager = aclsManager;
/*     */ 
/* 108 */       LOG.info("Completed job store activated/configured with retain-time : " + this.retainTime + " , job-info-dir : " + this.jobInfoDir);
/*     */     }
/*     */     else {
/* 111 */       LOG.info("Completed job store is inactive");
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isActive()
/*     */   {
/* 121 */     return this.active;
/*     */   }
/*     */ 
/*     */   public void run() {
/* 125 */     if (this.retainTime > 0L)
/*     */       while (true) {
/* 127 */         deleteJobStatusDirs();
/*     */         try {
/* 129 */           Thread.sleep(SLEEP_TIME);
/*     */         }
/*     */         catch (InterruptedException ex)
/*     */         {
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   private void deleteJobStatusDirs()
/*     */   {
/*     */     try {
/* 140 */       long currentTime = System.currentTimeMillis();
/* 141 */       FileStatus[] jobInfoFiles = this.fs.listStatus(new Path[] { new Path(this.jobInfoDir) });
/*     */ 
/* 145 */       for (FileStatus jobInfo : jobInfoFiles) {
/*     */         try {
/* 147 */           if (currentTime - jobInfo.getModificationTime() > this.retainTime)
/* 148 */             this.fs.delete(jobInfo.getPath(), true);
/*     */         }
/*     */         catch (IOException ie)
/*     */         {
/* 152 */           LOG.warn("Could not do housekeeping for [ " + jobInfo.getPath() + "] job info : " + ie.getMessage(), ie);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (IOException ie)
/*     */     {
/* 158 */       LOG.warn("Could not obtain job info files : " + ie.getMessage(), ie);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Path getInfoFilePath(JobID jobId) {
/* 163 */     return new Path(this.jobInfoDir, jobId + ".info");
/*     */   }
/*     */ 
/*     */   public void store(JobInProgress job)
/*     */   {
/* 172 */     if ((this.active) && (this.retainTime > 0L)) {
/* 173 */       JobID jobId = job.getStatus().getJobID();
/* 174 */       Path jobStatusFile = getInfoFilePath(jobId);
/*     */       try {
/* 176 */         FSDataOutputStream dataOut = this.fs.create(jobStatusFile);
/*     */ 
/* 178 */         job.getStatus().write(dataOut);
/*     */ 
/* 180 */         job.getProfile().write(dataOut);
/*     */ 
/* 182 */         Counters counters = new Counters();
/* 183 */         boolean isFine = job.getCounters(counters);
/* 184 */         counters = isFine ? counters : new Counters();
/* 185 */         counters.write(dataOut);
/*     */ 
/* 187 */         TaskCompletionEvent[] events = job.getTaskCompletionEvents(0, 2147483647);
/*     */ 
/* 189 */         dataOut.writeInt(events.length);
/* 190 */         for (TaskCompletionEvent event : events) {
/* 191 */           event.write(dataOut);
/*     */         }
/*     */ 
/* 194 */         dataOut.close();
/*     */       } catch (IOException ex) {
/* 196 */         LOG.warn("Could not store [" + jobId + "] job info : " + ex.getMessage(), ex);
/*     */         try
/*     */         {
/* 199 */           this.fs.delete(jobStatusFile, true);
/*     */         }
/*     */         catch (IOException ex1)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private FSDataInputStream getJobInfoFile(JobID jobId) throws IOException {
/* 209 */     Path jobStatusFile = getInfoFilePath(jobId);
/* 210 */     return this.fs.exists(jobStatusFile) ? this.fs.open(jobStatusFile) : null;
/*     */   }
/*     */ 
/*     */   private JobStatus readJobStatus(FSDataInputStream dataIn) throws IOException {
/* 214 */     JobStatus jobStatus = new JobStatus();
/* 215 */     jobStatus.readFields(dataIn);
/* 216 */     return jobStatus;
/*     */   }
/*     */ 
/*     */   private JobProfile readJobProfile(FSDataInputStream dataIn) throws IOException
/*     */   {
/* 221 */     JobProfile jobProfile = new JobProfile();
/* 222 */     jobProfile.readFields(dataIn);
/* 223 */     return jobProfile;
/*     */   }
/*     */ 
/*     */   private Counters readCounters(FSDataInputStream dataIn) throws IOException {
/* 227 */     Counters counters = new Counters();
/* 228 */     counters.readFields(dataIn);
/* 229 */     return counters;
/*     */   }
/*     */ 
/*     */   private TaskCompletionEvent[] readEvents(FSDataInputStream dataIn, int offset, int len)
/*     */     throws IOException
/*     */   {
/* 235 */     int size = dataIn.readInt();
/* 236 */     if (offset > size) {
/* 237 */       return TaskCompletionEvent.EMPTY_ARRAY;
/*     */     }
/* 239 */     if (offset + len > size) {
/* 240 */       len = size - offset;
/*     */     }
/* 242 */     TaskCompletionEvent[] events = new TaskCompletionEvent[len];
/* 243 */     for (int i = 0; i < offset + len; i++) {
/* 244 */       TaskCompletionEvent event = new TaskCompletionEvent();
/* 245 */       event.readFields(dataIn);
/* 246 */       if (i >= offset) {
/* 247 */         events[(i - offset)] = event;
/*     */       }
/*     */     }
/* 250 */     return events;
/*     */   }
/*     */ 
/*     */   public JobStatus readJobStatus(JobID jobId)
/*     */   {
/* 261 */     JobStatus jobStatus = null;
/*     */ 
/* 263 */     if (null == jobId) {
/* 264 */       LOG.warn("Could not read job status for null jobId");
/* 265 */       return null;
/*     */     }
/*     */ 
/* 268 */     if (this.active) {
/*     */       try {
/* 270 */         FSDataInputStream dataIn = getJobInfoFile(jobId);
/* 271 */         if (dataIn != null) {
/* 272 */           jobStatus = readJobStatus(dataIn);
/* 273 */           dataIn.close();
/*     */         }
/*     */       } catch (IOException ex) {
/* 276 */         LOG.warn("Could not read [" + jobId + "] job status : " + ex, ex);
/*     */       }
/*     */     }
/* 279 */     return jobStatus;
/*     */   }
/*     */ 
/*     */   public JobProfile readJobProfile(JobID jobId)
/*     */   {
/* 290 */     JobProfile jobProfile = null;
/* 291 */     if (this.active) {
/*     */       try {
/* 293 */         FSDataInputStream dataIn = getJobInfoFile(jobId);
/* 294 */         if (dataIn != null) {
/* 295 */           readJobStatus(dataIn);
/* 296 */           jobProfile = readJobProfile(dataIn);
/* 297 */           dataIn.close();
/*     */         }
/*     */       } catch (IOException ex) {
/* 300 */         LOG.warn("Could not read [" + jobId + "] job profile : " + ex, ex);
/*     */       }
/*     */     }
/* 303 */     return jobProfile;
/*     */   }
/*     */ 
/*     */   public Counters readCounters(JobID jobId)
/*     */     throws AccessControlException
/*     */   {
/* 315 */     Counters counters = null;
/* 316 */     if (this.active) {
/*     */       try {
/* 318 */         FSDataInputStream dataIn = getJobInfoFile(jobId);
/* 319 */         if (dataIn != null) {
/* 320 */           JobStatus jobStatus = readJobStatus(dataIn);
/* 321 */           JobProfile profile = readJobProfile(dataIn);
/* 322 */           String queue = profile.getQueueName();
/*     */ 
/* 324 */           this.aclsManager.checkAccess(jobStatus, UserGroupInformation.getCurrentUser(), queue, Operation.VIEW_JOB_COUNTERS);
/*     */ 
/* 328 */           counters = readCounters(dataIn);
/* 329 */           dataIn.close();
/*     */         }
/*     */       } catch (AccessControlException ace) {
/* 332 */         throw ace;
/*     */       } catch (IOException ex) {
/* 334 */         LOG.warn("Could not read [" + jobId + "] job counters : " + ex, ex);
/*     */       }
/*     */     }
/* 337 */     return counters;
/*     */   }
/*     */ 
/*     */   public TaskCompletionEvent[] readJobTaskCompletionEvents(JobID jobId, int fromEventId, int maxEvents)
/*     */   {
/* 352 */     TaskCompletionEvent[] events = TaskCompletionEvent.EMPTY_ARRAY;
/* 353 */     if (this.active) {
/*     */       try {
/* 355 */         FSDataInputStream dataIn = getJobInfoFile(jobId);
/* 356 */         if (dataIn != null) {
/* 357 */           readJobStatus(dataIn);
/* 358 */           readJobProfile(dataIn);
/* 359 */           readCounters(dataIn);
/* 360 */           events = readEvents(dataIn, fromEventId, maxEvents);
/* 361 */           dataIn.close();
/*     */         }
/*     */       } catch (IOException ex) {
/* 364 */         LOG.warn("Could not read [" + jobId + "] job events : " + ex, ex);
/*     */       }
/*     */     }
/* 367 */     return events;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.CompletedJobStatusStore
 * JD-Core Version:    0.6.1
 */
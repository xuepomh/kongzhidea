/*      */ package org.apache.hadoop.mapred;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.apache.hadoop.conf.Configuration;
/*      */ import org.apache.hadoop.conf.Configuration.IntegerRanges;
/*      */ import org.apache.hadoop.fs.FileSystem;
/*      */ import org.apache.hadoop.fs.LocalFileSystem;
/*      */ import org.apache.hadoop.fs.Path;
/*      */ import org.apache.hadoop.io.LongWritable;
/*      */ import org.apache.hadoop.io.RawComparator;
/*      */ import org.apache.hadoop.io.Text;
/*      */ import org.apache.hadoop.io.WritableComparable;
/*      */ import org.apache.hadoop.io.WritableComparator;
/*      */ import org.apache.hadoop.io.compress.CompressionCodec;
/*      */ import org.apache.hadoop.mapred.lib.HashPartitioner;
/*      */ import org.apache.hadoop.mapred.lib.IdentityMapper;
/*      */ import org.apache.hadoop.mapred.lib.IdentityReducer;
/*      */ import org.apache.hadoop.mapred.lib.KeyFieldBasedComparator;
/*      */ import org.apache.hadoop.mapred.lib.KeyFieldBasedPartitioner;
/*      */ import org.apache.hadoop.security.Credentials;
/*      */ import org.apache.hadoop.util.ClassUtil;
/*      */ import org.apache.hadoop.util.ReflectionUtils;
/*      */ 
/*      */ public class JobConf extends Configuration
/*      */ {
/*  107 */   private static final Log LOG = LogFactory.getLog(JobConf.class);
/*      */ 
/*      */   @Deprecated
/*      */   public static final String MAPRED_TASK_MAXVMEM_PROPERTY = "mapred.task.maxvmem";
/*      */ 
/*      */   @Deprecated
/*      */   public static final String UPPER_LIMIT_ON_TASK_VMEM_PROPERTY = "mapred.task.limit.maxvmem";
/*      */ 
/*      */   @Deprecated
/*      */   public static final String MAPRED_TASK_DEFAULT_MAXVMEM_PROPERTY = "mapred.task.default.maxvmem";
/*      */ 
/*      */   @Deprecated
/*      */   public static final String MAPRED_TASK_MAXPMEM_PROPERTY = "mapred.task.maxpmem";
/*      */   public static final long DISABLED_MEMORY_LIMIT = -1L;
/*      */   public static final String MAPRED_LOCAL_DIR_PROPERTY = "mapred.local.dir";
/*      */   public static final String DEFAULT_QUEUE_NAME = "default";
/*      */   public static final String MAPRED_JOB_MAP_MEMORY_MB_PROPERTY = "mapred.job.map.memory.mb";
/*      */   public static final String MAPRED_JOB_REDUCE_MEMORY_MB_PROPERTY = "mapred.job.reduce.memory.mb";
/*      */   static final String MR_ACLS_ENABLED = "mapred.acls.enabled";
/*      */   static final String MR_ADMINS = "mapreduce.cluster.administrators";
/*      */ 
/*      */   @Deprecated
/*      */   public static final String MAPRED_TASK_JAVA_OPTS = "mapred.child.java.opts";
/*      */   public static final String MAPRED_MAP_TASK_JAVA_OPTS = "mapred.map.child.java.opts";
/*      */   public static final String MAPRED_REDUCE_TASK_JAVA_OPTS = "mapred.reduce.child.java.opts";
/*      */   public static final String DEFAULT_MAPRED_TASK_JAVA_OPTS = "-Xmx200m";
/*      */ 
/*      */   @Deprecated
/*      */   public static final String MAPRED_TASK_ULIMIT = "mapred.child.ulimit";
/*      */   public static final String MAPRED_MAP_TASK_ULIMIT = "mapred.map.child.ulimit";
/*      */   public static final String MAPRED_REDUCE_TASK_ULIMIT = "mapred.reduce.child.ulimit";
/*      */ 
/*      */   @Deprecated
/*      */   public static final String MAPRED_TASK_ENV = "mapred.child.env";
/*      */   public static final String MAPRED_MAP_TASK_ENV = "mapred.map.child.env";
/*      */   public static final String MAPRED_REDUCE_TASK_ENV = "mapred.reduce.child.env";
/*      */   public static final String WORKFLOW_ID = "mapreduce.workflow.id";
/*      */   public static final String WORKFLOW_NAME = "mapreduce.workflow.name";
/*      */   public static final String WORKFLOW_NODE_NAME = "mapreduce.workflow.node.name";
/*      */   public static final String WORKFLOW_ADJACENCY_PREFIX_STRING = "mapreduce.workflow.adjacency.";
/*      */   public static final String WORKFLOW_ADJACENCY_PREFIX_PATTERN = "^mapreduce\\.workflow\\.adjacency\\..+";
/*      */   public static final String WORKFLOW_TAGS = "mapreduce.workflow.tags";
/*      */   public static final String MAPREDUCE_RECOVER_JOB = "mapreduce.job.restart.recover";
/*      */   public static final boolean DEFAULT_MAPREDUCE_RECOVER_JOB = true;
/*  337 */   private Credentials credentials = new Credentials();
/*      */ 
/*      */   public JobConf()
/*      */   {
/*  343 */     checkAndWarnDeprecation();
/*      */   }
/*      */ 
/*      */   public JobConf(Class exampleClass)
/*      */   {
/*  352 */     setJarByClass(exampleClass);
/*  353 */     checkAndWarnDeprecation();
/*      */   }
/*      */ 
/*      */   public JobConf(Configuration conf)
/*      */   {
/*  362 */     super(conf);
/*      */ 
/*  364 */     if ((conf instanceof JobConf)) {
/*  365 */       JobConf that = (JobConf)conf;
/*  366 */       this.credentials = that.credentials;
/*      */     }
/*      */ 
/*  369 */     checkAndWarnDeprecation();
/*      */   }
/*      */ 
/*      */   public JobConf(Configuration conf, Class exampleClass)
/*      */   {
/*  379 */     this(conf);
/*  380 */     setJarByClass(exampleClass);
/*      */   }
/*      */ 
/*      */   public JobConf(String config)
/*      */   {
/*  389 */     this(new Path(config));
/*      */   }
/*      */ 
/*      */   public JobConf(Path config)
/*      */   {
/*  398 */     addResource(config);
/*  399 */     checkAndWarnDeprecation();
/*      */   }
/*      */ 
/*      */   public JobConf(boolean loadDefaults)
/*      */   {
/*  411 */     super(loadDefaults);
/*  412 */     checkAndWarnDeprecation();
/*      */   }
/*      */ 
/*      */   public Credentials getCredentials()
/*      */   {
/*  420 */     return this.credentials;
/*      */   }
/*      */ 
/*      */   void setCredentials(Credentials credentials) {
/*  424 */     this.credentials = credentials;
/*      */   }
/*      */ 
/*      */   public String getJar()
/*      */   {
/*  432 */     return get("mapred.jar");
/*      */   }
/*      */ 
/*      */   public void setJar(String jar)
/*      */   {
/*  439 */     set("mapred.jar", jar);
/*      */   }
/*      */ 
/*      */   public void setJarByClass(Class cls)
/*      */   {
/*  447 */     String jar = ClassUtil.findContainingJar(cls);
/*  448 */     if (jar != null)
/*  449 */       setJar(jar);
/*      */   }
/*      */ 
/*      */   public String[] getLocalDirs() throws IOException
/*      */   {
/*  454 */     return getStrings("mapred.local.dir");
/*      */   }
/*      */ 
/*      */   public void deleteLocalFiles() throws IOException {
/*  458 */     String[] localDirs = getLocalDirs();
/*  459 */     for (int i = 0; i < localDirs.length; i++)
/*  460 */       FileSystem.getLocal(this).delete(new Path(localDirs[i]));
/*      */   }
/*      */ 
/*      */   public void deleteLocalFiles(String subdir) throws IOException
/*      */   {
/*  465 */     String[] localDirs = getLocalDirs();
/*  466 */     for (int i = 0; i < localDirs.length; i++)
/*  467 */       FileSystem.getLocal(this).delete(new Path(localDirs[i], subdir));
/*      */   }
/*      */ 
/*      */   public Path getLocalPath(String pathString)
/*      */     throws IOException
/*      */   {
/*  476 */     return getLocalPath("mapred.local.dir", pathString);
/*      */   }
/*      */ 
/*      */   public String getUser()
/*      */   {
/*  485 */     return get("user.name");
/*      */   }
/*      */ 
/*      */   public void setUser(String user)
/*      */   {
/*  494 */     set("user.name", user);
/*      */   }
/*      */ 
/*      */   public void setKeepFailedTaskFiles(boolean keep)
/*      */   {
/*  508 */     setBoolean("keep.failed.task.files", keep);
/*      */   }
/*      */ 
/*      */   public boolean getKeepFailedTaskFiles()
/*      */   {
/*  517 */     return getBoolean("keep.failed.task.files", false);
/*      */   }
/*      */ 
/*      */   public void setKeepTaskFilesPattern(String pattern)
/*      */   {
/*  529 */     set("keep.task.files.pattern", pattern);
/*      */   }
/*      */ 
/*      */   public String getKeepTaskFilesPattern()
/*      */   {
/*  539 */     return get("keep.task.files.pattern");
/*      */   }
/*      */ 
/*      */   public void setWorkingDirectory(Path dir)
/*      */   {
/*  548 */     dir = new Path(getWorkingDirectory(), dir);
/*  549 */     set("mapred.working.dir", dir.toString());
/*      */   }
/*      */ 
/*      */   public Path getWorkingDirectory()
/*      */   {
/*  558 */     String name = get("mapred.working.dir");
/*  559 */     if (name != null)
/*  560 */       return new Path(name);
/*      */     try
/*      */     {
/*  563 */       Path dir = FileSystem.get(this).getWorkingDirectory();
/*  564 */       set("mapred.working.dir", dir.toString());
/*  565 */       return dir;
/*      */     } catch (IOException e) {
/*  567 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setNumTasksToExecutePerJvm(int numTasks)
/*      */   {
/*  579 */     setInt("mapred.job.reuse.jvm.num.tasks", numTasks);
/*      */   }
/*      */ 
/*      */   public int getNumTasksToExecutePerJvm()
/*      */   {
/*  586 */     return getInt("mapred.job.reuse.jvm.num.tasks", 1);
/*      */   }
/*      */ 
/*      */   public InputFormat getInputFormat()
/*      */   {
/*  596 */     return (InputFormat)ReflectionUtils.newInstance(getClass("mapred.input.format.class", TextInputFormat.class, InputFormat.class), this);
/*      */   }
/*      */ 
/*      */   public void setInputFormat(Class<? extends InputFormat> theClass)
/*      */   {
/*  609 */     setClass("mapred.input.format.class", theClass, InputFormat.class);
/*      */   }
/*      */ 
/*      */   public OutputFormat getOutputFormat()
/*      */   {
/*  619 */     return (OutputFormat)ReflectionUtils.newInstance(getClass("mapred.output.format.class", TextOutputFormat.class, OutputFormat.class), this);
/*      */   }
/*      */ 
/*      */   public OutputCommitter getOutputCommitter()
/*      */   {
/*  632 */     return (OutputCommitter)ReflectionUtils.newInstance(getClass("mapred.output.committer.class", FileOutputCommitter.class, OutputCommitter.class), this);
/*      */   }
/*      */ 
/*      */   public void setOutputCommitter(Class<? extends OutputCommitter> theClass)
/*      */   {
/*  644 */     setClass("mapred.output.committer.class", theClass, OutputCommitter.class);
/*      */   }
/*      */ 
/*      */   public void setOutputFormat(Class<? extends OutputFormat> theClass)
/*      */   {
/*  654 */     setClass("mapred.output.format.class", theClass, OutputFormat.class);
/*      */   }
/*      */ 
/*      */   public void setCompressMapOutput(boolean compress)
/*      */   {
/*  664 */     setBoolean("mapred.compress.map.output", compress);
/*      */   }
/*      */ 
/*      */   public boolean getCompressMapOutput()
/*      */   {
/*  674 */     return getBoolean("mapred.compress.map.output", false);
/*      */   }
/*      */ 
/*      */   public void setMapOutputCompressorClass(Class<? extends CompressionCodec> codecClass)
/*      */   {
/*  685 */     setCompressMapOutput(true);
/*  686 */     setClass("mapred.map.output.compression.codec", codecClass, CompressionCodec.class);
/*      */   }
/*      */ 
/*      */   public Class<? extends CompressionCodec> getMapOutputCompressorClass(Class<? extends CompressionCodec> defaultValue)
/*      */   {
/*  700 */     Class codecClass = defaultValue;
/*  701 */     String name = get("mapred.map.output.compression.codec");
/*  702 */     if (name != null) {
/*      */       try {
/*  704 */         codecClass = getClassByName(name).asSubclass(CompressionCodec.class);
/*      */       } catch (ClassNotFoundException e) {
/*  706 */         throw new IllegalArgumentException("Compression codec " + name + " was not found.", e);
/*      */       }
/*      */     }
/*      */ 
/*  710 */     return codecClass;
/*      */   }
/*      */ 
/*      */   public Class<?> getMapOutputKeyClass()
/*      */   {
/*  721 */     Class retv = getClass("mapred.mapoutput.key.class", null, Object.class);
/*  722 */     if (retv == null) {
/*  723 */       retv = getOutputKeyClass();
/*      */     }
/*  725 */     return retv;
/*      */   }
/*      */ 
/*      */   public void setMapOutputKeyClass(Class<?> theClass)
/*      */   {
/*  736 */     setClass("mapred.mapoutput.key.class", theClass, Object.class);
/*      */   }
/*      */ 
/*      */   public Class<?> getMapOutputValueClass()
/*      */   {
/*  747 */     Class retv = getClass("mapred.mapoutput.value.class", null, Object.class);
/*      */ 
/*  749 */     if (retv == null) {
/*  750 */       retv = getOutputValueClass();
/*      */     }
/*  752 */     return retv;
/*      */   }
/*      */ 
/*      */   public void setMapOutputValueClass(Class<?> theClass)
/*      */   {
/*  763 */     setClass("mapred.mapoutput.value.class", theClass, Object.class);
/*      */   }
/*      */ 
/*      */   public Class<?> getOutputKeyClass()
/*      */   {
/*  772 */     return getClass("mapred.output.key.class", LongWritable.class, Object.class);
/*      */   }
/*      */ 
/*      */   public void setOutputKeyClass(Class<?> theClass)
/*      */   {
/*  782 */     setClass("mapred.output.key.class", theClass, Object.class);
/*      */   }
/*      */ 
/*      */   public RawComparator getOutputKeyComparator()
/*      */   {
/*  791 */     Class theClass = getClass("mapred.output.key.comparator.class", null, RawComparator.class);
/*      */ 
/*  793 */     if (theClass != null)
/*  794 */       return (RawComparator)ReflectionUtils.newInstance(theClass, this);
/*  795 */     return WritableComparator.get(getMapOutputKeyClass().asSubclass(WritableComparable.class));
/*      */   }
/*      */ 
/*      */   public void setOutputKeyComparatorClass(Class<? extends RawComparator> theClass)
/*      */   {
/*  806 */     setClass("mapred.output.key.comparator.class", theClass, RawComparator.class);
/*      */   }
/*      */ 
/*      */   public void setKeyFieldComparatorOptions(String keySpec)
/*      */   {
/*  826 */     setOutputKeyComparatorClass(KeyFieldBasedComparator.class);
/*  827 */     set("mapred.text.key.comparator.options", keySpec);
/*      */   }
/*      */ 
/*      */   public String getKeyFieldComparatorOption()
/*      */   {
/*  834 */     return get("mapred.text.key.comparator.options");
/*      */   }
/*      */ 
/*      */   public void setKeyFieldPartitionerOptions(String keySpec)
/*      */   {
/*  851 */     setPartitionerClass(KeyFieldBasedPartitioner.class);
/*  852 */     set("mapred.text.key.partitioner.options", keySpec);
/*      */   }
/*      */ 
/*      */   public String getKeyFieldPartitionerOption()
/*      */   {
/*  859 */     return get("mapred.text.key.partitioner.options");
/*      */   }
/*      */ 
/*      */   public RawComparator getOutputValueGroupingComparator()
/*      */   {
/*  870 */     Class theClass = getClass("mapred.output.value.groupfn.class", null, RawComparator.class);
/*      */ 
/*  872 */     if (theClass == null) {
/*  873 */       return getOutputKeyComparator();
/*      */     }
/*      */ 
/*  876 */     return (RawComparator)ReflectionUtils.newInstance(theClass, this);
/*      */   }
/*      */ 
/*      */   public void setOutputValueGroupingComparator(Class<? extends RawComparator> theClass)
/*      */   {
/*  906 */     setClass("mapred.output.value.groupfn.class", theClass, RawComparator.class);
/*      */   }
/*      */ 
/*      */   public boolean getUseNewMapper()
/*      */   {
/*  916 */     return getBoolean("mapred.mapper.new-api", false);
/*      */   }
/*      */ 
/*      */   public void setUseNewMapper(boolean flag)
/*      */   {
/*  924 */     setBoolean("mapred.mapper.new-api", flag);
/*      */   }
/*      */ 
/*      */   public boolean getUseNewReducer()
/*      */   {
/*  933 */     return getBoolean("mapred.reducer.new-api", false);
/*      */   }
/*      */ 
/*      */   public void setUseNewReducer(boolean flag)
/*      */   {
/*  941 */     setBoolean("mapred.reducer.new-api", flag);
/*      */   }
/*      */ 
/*      */   public Class<?> getOutputValueClass()
/*      */   {
/*  950 */     return getClass("mapred.output.value.class", Text.class, Object.class);
/*      */   }
/*      */ 
/*      */   public void setOutputValueClass(Class<?> theClass)
/*      */   {
/*  959 */     setClass("mapred.output.value.class", theClass, Object.class);
/*      */   }
/*      */ 
/*      */   public Class<? extends Mapper> getMapperClass()
/*      */   {
/*  968 */     return getClass("mapred.mapper.class", IdentityMapper.class, Mapper.class);
/*      */   }
/*      */ 
/*      */   public void setMapperClass(Class<? extends Mapper> theClass)
/*      */   {
/*  977 */     setClass("mapred.mapper.class", theClass, Mapper.class);
/*      */   }
/*      */ 
/*      */   public Class<? extends MapRunnable> getMapRunnerClass()
/*      */   {
/*  986 */     return getClass("mapred.map.runner.class", MapRunner.class, MapRunnable.class);
/*      */   }
/*      */ 
/*      */   public void setMapRunnerClass(Class<? extends MapRunnable> theClass)
/*      */   {
/*  998 */     setClass("mapred.map.runner.class", theClass, MapRunnable.class);
/*      */   }
/*      */ 
/*      */   public Class<? extends Partitioner> getPartitionerClass()
/*      */   {
/* 1008 */     return getClass("mapred.partitioner.class", HashPartitioner.class, Partitioner.class);
/*      */   }
/*      */ 
/*      */   public void setPartitionerClass(Class<? extends Partitioner> theClass)
/*      */   {
/* 1019 */     setClass("mapred.partitioner.class", theClass, Partitioner.class);
/*      */   }
/*      */ 
/*      */   public Class<? extends Reducer> getReducerClass()
/*      */   {
/* 1028 */     return getClass("mapred.reducer.class", IdentityReducer.class, Reducer.class);
/*      */   }
/*      */ 
/*      */   public void setReducerClass(Class<? extends Reducer> theClass)
/*      */   {
/* 1038 */     setClass("mapred.reducer.class", theClass, Reducer.class);
/*      */   }
/*      */ 
/*      */   public Class<? extends Reducer> getCombinerClass()
/*      */   {
/* 1049 */     return getClass("mapred.combiner.class", null, Reducer.class);
/*      */   }
/*      */ 
/*      */   public void setCombinerClass(Class<? extends Reducer> theClass)
/*      */   {
/* 1076 */     setClass("mapred.combiner.class", theClass, Reducer.class);
/*      */   }
/*      */ 
/*      */   public boolean getSpeculativeExecution()
/*      */   {
/* 1087 */     return (getMapSpeculativeExecution()) || (getReduceSpeculativeExecution());
/*      */   }
/*      */ 
/*      */   public void setSpeculativeExecution(boolean speculativeExecution)
/*      */   {
/* 1097 */     setMapSpeculativeExecution(speculativeExecution);
/* 1098 */     setReduceSpeculativeExecution(speculativeExecution);
/*      */   }
/*      */ 
/*      */   public boolean getMapSpeculativeExecution()
/*      */   {
/* 1110 */     return getBoolean("mapred.map.tasks.speculative.execution", true);
/*      */   }
/*      */ 
/*      */   public void setMapSpeculativeExecution(boolean speculativeExecution)
/*      */   {
/* 1121 */     setBoolean("mapred.map.tasks.speculative.execution", speculativeExecution);
/*      */   }
/*      */ 
/*      */   public boolean getReduceSpeculativeExecution()
/*      */   {
/* 1133 */     return getBoolean("mapred.reduce.tasks.speculative.execution", true);
/*      */   }
/*      */ 
/*      */   public void setReduceSpeculativeExecution(boolean speculativeExecution)
/*      */   {
/* 1144 */     setBoolean("mapred.reduce.tasks.speculative.execution", speculativeExecution);
/*      */   }
/*      */ 
/*      */   public int getNumMapTasks()
/*      */   {
/* 1154 */     return getInt("mapred.map.tasks", 1);
/*      */   }
/*      */ 
/*      */   public void setNumMapTasks(int n)
/*      */   {
/* 1194 */     setInt("mapred.map.tasks", n);
/*      */   }
/*      */ 
/*      */   public int getNumReduceTasks()
/*      */   {
/* 1202 */     return getInt("mapred.reduce.tasks", 1);
/*      */   }
/*      */ 
/*      */   public void setNumReduceTasks(int n)
/*      */   {
/* 1238 */     setInt("mapred.reduce.tasks", n);
/*      */   }
/*      */ 
/*      */   public int getMaxMapAttempts()
/*      */   {
/* 1248 */     return getInt("mapred.map.max.attempts", 4);
/*      */   }
/*      */ 
/*      */   public void setMaxMapAttempts(int n)
/*      */   {
/* 1258 */     setInt("mapred.map.max.attempts", n);
/*      */   }
/*      */ 
/*      */   public int getMaxReduceAttempts()
/*      */   {
/* 1269 */     return getInt("mapred.reduce.max.attempts", 4);
/*      */   }
/*      */ 
/*      */   public void setMaxReduceAttempts(int n)
/*      */   {
/* 1278 */     setInt("mapred.reduce.max.attempts", n);
/*      */   }
/*      */ 
/*      */   public String getJobName()
/*      */   {
/* 1288 */     return get("mapred.job.name", "");
/*      */   }
/*      */ 
/*      */   public void setJobName(String name)
/*      */   {
/* 1297 */     set("mapred.job.name", name);
/*      */   }
/*      */ 
/*      */   public String getSessionId()
/*      */   {
/* 1316 */     return get("session.id", "");
/*      */   }
/*      */ 
/*      */   public void setSessionId(String sessionId)
/*      */   {
/* 1325 */     set("session.id", sessionId);
/*      */   }
/*      */ 
/*      */   public void setMaxTaskFailuresPerTracker(int noFailures)
/*      */   {
/* 1336 */     setInt("mapred.max.tracker.failures", noFailures);
/*      */   }
/*      */ 
/*      */   public int getMaxTaskFailuresPerTracker()
/*      */   {
/* 1347 */     return getInt("mapred.max.tracker.failures", 4);
/*      */   }
/*      */ 
/*      */   public int getMaxMapTaskFailuresPercent()
/*      */   {
/* 1364 */     return getInt("mapred.max.map.failures.percent", 0);
/*      */   }
/*      */ 
/*      */   public void setMaxMapTaskFailuresPercent(int percent)
/*      */   {
/* 1378 */     setInt("mapred.max.map.failures.percent", percent);
/*      */   }
/*      */ 
/*      */   public int getMaxReduceTaskFailuresPercent()
/*      */   {
/* 1395 */     return getInt("mapred.max.reduce.failures.percent", 0);
/*      */   }
/*      */ 
/*      */   public void setMaxReduceTaskFailuresPercent(int percent)
/*      */   {
/* 1409 */     setInt("mapred.max.reduce.failures.percent", percent);
/*      */   }
/*      */ 
/*      */   public void setJobPriority(JobPriority prio)
/*      */   {
/* 1418 */     set("mapred.job.priority", prio.toString());
/*      */   }
/*      */ 
/*      */   public JobPriority getJobPriority()
/*      */   {
/* 1427 */     String prio = get("mapred.job.priority");
/* 1428 */     if (prio == null) {
/* 1429 */       return JobPriority.NORMAL;
/*      */     }
/*      */ 
/* 1432 */     return JobPriority.valueOf(prio);
/*      */   }
/*      */ 
/*      */   void setJobSubmitHostName(String hostname)
/*      */   {
/* 1441 */     set("mapreduce.job.submithost", hostname);
/*      */   }
/*      */ 
/*      */   String getJobSubmitHostName()
/*      */   {
/* 1450 */     String hostname = get("mapreduce.job.submithost");
/*      */ 
/* 1452 */     return hostname;
/*      */   }
/*      */ 
/*      */   void setJobSubmitHostAddress(String hostadd)
/*      */   {
/* 1461 */     set("mapreduce.job.submithostaddress", hostadd);
/*      */   }
/*      */ 
/*      */   String getJobSubmitHostAddress()
/*      */   {
/* 1470 */     String hostadd = get("mapreduce.job.submithostaddress");
/*      */ 
/* 1472 */     return hostadd;
/*      */   }
/*      */ 
/*      */   public boolean getProfileEnabled()
/*      */   {
/* 1480 */     return getBoolean("mapred.task.profile", false);
/*      */   }
/*      */ 
/*      */   public void setProfileEnabled(boolean newValue)
/*      */   {
/* 1490 */     setBoolean("mapred.task.profile", newValue);
/*      */   }
/*      */ 
/*      */   public String getProfileParams()
/*      */   {
/* 1502 */     return get("mapred.task.profile.params", "-agentlib:hprof=cpu=samples,heap=sites,force=n,thread=y,verbose=n,file=%s");
/*      */   }
/*      */ 
/*      */   public void setProfileParams(String value)
/*      */   {
/* 1517 */     set("mapred.task.profile.params", value);
/*      */   }
/*      */ 
/*      */   public Configuration.IntegerRanges getProfileTaskRange(boolean isMap)
/*      */   {
/* 1526 */     return getRange(isMap ? "mapred.task.profile.maps" : "mapred.task.profile.reduces", "0-2");
/*      */   }
/*      */ 
/*      */   public void setProfileTaskRange(boolean isMap, String newValue)
/*      */   {
/* 1537 */     new Configuration.IntegerRanges(newValue);
/* 1538 */     set(isMap ? "mapred.task.profile.maps" : "mapred.task.profile.reduces", newValue);
/*      */   }
/*      */ 
/*      */   public void setMapDebugScript(String mDbgScript)
/*      */   {
/* 1566 */     set("mapred.map.task.debug.script", mDbgScript);
/*      */   }
/*      */ 
/*      */   public String getMapDebugScript()
/*      */   {
/* 1576 */     return get("mapred.map.task.debug.script");
/*      */   }
/*      */ 
/*      */   public void setReduceDebugScript(String rDbgScript)
/*      */   {
/* 1603 */     set("mapred.reduce.task.debug.script", rDbgScript);
/*      */   }
/*      */ 
/*      */   public String getReduceDebugScript()
/*      */   {
/* 1613 */     return get("mapred.reduce.task.debug.script");
/*      */   }
/*      */ 
/*      */   public String getJobEndNotificationURI()
/*      */   {
/* 1625 */     return get("job.end.notification.url");
/*      */   }
/*      */ 
/*      */   public void setJobEndNotificationURI(String uri)
/*      */   {
/* 1645 */     set("job.end.notification.url", uri);
/*      */   }
/*      */ 
/*      */   public String getJobLocalDir()
/*      */   {
/* 1664 */     return get("job.local.dir");
/*      */   }
/*      */ 
/*      */   public long getMemoryForMapTask()
/*      */   {
/* 1681 */     long value = getDeprecatedMemoryValue();
/* 1682 */     if (value == -1L) {
/* 1683 */       value = normalizeMemoryConfigValue(getLong("mapred.job.map.memory.mb", -1L));
/*      */     }
/*      */ 
/* 1687 */     return value;
/*      */   }
/*      */ 
/*      */   public void setMemoryForMapTask(long mem) {
/* 1691 */     setLong("mapred.job.map.memory.mb", mem);
/*      */   }
/*      */ 
/*      */   public long getMemoryForReduceTask()
/*      */   {
/* 1708 */     long value = getDeprecatedMemoryValue();
/* 1709 */     if (value == -1L) {
/* 1710 */       value = normalizeMemoryConfigValue(getLong("mapred.job.reduce.memory.mb", -1L));
/*      */     }
/*      */ 
/* 1714 */     return value;
/*      */   }
/*      */ 
/*      */   private long getDeprecatedMemoryValue()
/*      */   {
/* 1722 */     long oldValue = getLong("mapred.task.maxvmem", -1L);
/*      */ 
/* 1724 */     oldValue = normalizeMemoryConfigValue(oldValue);
/* 1725 */     if (oldValue != -1L) {
/* 1726 */       oldValue /= 1048576L;
/*      */     }
/* 1728 */     return oldValue;
/*      */   }
/*      */ 
/*      */   public void setMemoryForReduceTask(long mem) {
/* 1732 */     setLong("mapred.job.reduce.memory.mb", mem);
/*      */   }
/*      */ 
/*      */   public String getQueueName()
/*      */   {
/* 1742 */     return get("mapred.job.queue.name", "default");
/*      */   }
/*      */ 
/*      */   public void setQueueName(String queueName)
/*      */   {
/* 1751 */     set("mapred.job.queue.name", queueName);
/*      */   }
/*      */ 
/*      */   public static long normalizeMemoryConfigValue(long val)
/*      */   {
/* 1761 */     if (val < 0L) {
/* 1762 */       val = -1L;
/*      */     }
/* 1764 */     return val;
/*      */   }
/*      */ 
/*      */   int computeNumSlotsPerMap(long slotSizePerMap)
/*      */   {
/* 1776 */     if ((slotSizePerMap == -1L) || (getMemoryForMapTask() == -1L))
/*      */     {
/* 1778 */       return 1;
/*      */     }
/* 1780 */     return (int)Math.ceil((float)getMemoryForMapTask() / (float)slotSizePerMap);
/*      */   }
/*      */ 
/*      */   int computeNumSlotsPerReduce(long slotSizePerReduce)
/*      */   {
/* 1792 */     if ((slotSizePerReduce == -1L) || (getMemoryForReduceTask() == -1L))
/*      */     {
/* 1794 */       return 1;
/*      */     }
/* 1796 */     return (int)Math.ceil((float)getMemoryForReduceTask() / (float)slotSizePerReduce);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public long getMaxVirtualMemoryForTask()
/*      */   {
/* 1822 */     LOG.warn("getMaxVirtualMemoryForTask() is deprecated. Instead use getMemoryForMapTask() and getMemoryForReduceTask()");
/*      */ 
/* 1826 */     long value = getLong("mapred.task.maxvmem", -1L);
/* 1827 */     value = normalizeMemoryConfigValue(value);
/* 1828 */     if (value == -1L) {
/* 1829 */       value = Math.max(getMemoryForMapTask(), getMemoryForReduceTask());
/* 1830 */       value = normalizeMemoryConfigValue(value);
/* 1831 */       if (value != -1L) {
/* 1832 */         value *= 1048576L;
/*      */       }
/*      */     }
/* 1835 */     return value;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public void setMaxVirtualMemoryForTask(long vmem)
/*      */   {
/* 1858 */     LOG.warn("setMaxVirtualMemoryForTask() is deprecated.Instead use setMemoryForMapTask() and setMemoryForReduceTask()");
/*      */ 
/* 1860 */     if ((vmem != -1L) && (vmem < 0L)) {
/* 1861 */       setMemoryForMapTask(-1L);
/* 1862 */       setMemoryForReduceTask(-1L);
/*      */     }
/*      */ 
/* 1865 */     if (get("mapred.task.maxvmem") == null) {
/* 1866 */       setMemoryForMapTask(vmem / 1048576L);
/* 1867 */       setMemoryForReduceTask(vmem / 1048576L);
/*      */     } else {
/* 1869 */       setLong("mapred.task.maxvmem", vmem);
/*      */     }
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public long getMaxPhysicalMemoryForTask()
/*      */   {
/* 1878 */     LOG.warn("The API getMaxPhysicalMemoryForTask() is deprecated. Refer to the APIs getMemoryForMapTask() and getMemoryForReduceTask() for details.");
/*      */ 
/* 1881 */     return -1L;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public void setMaxPhysicalMemoryForTask(long mem)
/*      */   {
/* 1889 */     LOG.warn("The API setMaxPhysicalMemoryForTask() is deprecated. The value set is ignored. Refer to  setMemoryForMapTask() and setMemoryForReduceTask() for details.");
/*      */   }
/*      */ 
/*      */   static String deprecatedString(String key)
/*      */   {
/* 1895 */     return "The variable " + key + " is no longer used.";
/*      */   }
/*      */ 
/*      */   private void checkAndWarnDeprecation() {
/* 1899 */     if (get("mapred.task.maxvmem") != null)
/* 1900 */       LOG.warn(deprecatedString("mapred.task.maxvmem") + " Instead use " + "mapred.job.map.memory.mb" + " and " + "mapred.job.reduce.memory.mb");
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*  110 */     Configuration.addDefaultResource("mapred-default.xml");
/*  111 */     Configuration.addDefaultResource("mapred-site.xml");
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JobConf
 * JD-Core Version:    0.6.1
 */
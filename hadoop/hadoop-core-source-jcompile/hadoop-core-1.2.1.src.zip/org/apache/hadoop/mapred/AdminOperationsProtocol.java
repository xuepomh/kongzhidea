package org.apache.hadoop.mapred;

import java.io.IOException;
import org.apache.hadoop.ipc.VersionedProtocol;
import org.apache.hadoop.security.KerberosInfo;

@KerberosInfo(serverPrincipal="mapreduce.jobtracker.kerberos.principal")
public abstract interface AdminOperationsProtocol extends VersionedProtocol
{
  public static final long versionID = 3L;

  public abstract void refreshQueues()
    throws IOException;

  public abstract void refreshNodes()
    throws IOException;

  public abstract boolean setSafeMode(JobTracker.SafeModeAction paramSafeModeAction)
    throws IOException;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.AdminOperationsProtocol
 * JD-Core Version:    0.6.1
 */
/*    */ package org.apache.hadoop.mapred;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.apache.hadoop.conf.Configuration;
/*    */ import org.apache.hadoop.fs.FileSystem;
/*    */ import org.apache.hadoop.hdfs.DistributedFileSystem;
/*    */ 
/*    */ public class HDFSMonitorThread extends Thread
/*    */ {
/* 31 */   public static final Log LOG = LogFactory.getLog(HDFSMonitorThread.class);
/*    */   private final JobTracker jt;
/*    */   private final FileSystem fs;
/*    */   private final int hdfsMonitorInterval;
/*    */ 
/*    */   public HDFSMonitorThread(Configuration conf, JobTracker jt, FileSystem fs)
/*    */   {
/* 39 */     super("JT-HDFS-Monitor-Thread");
/* 40 */     this.jt = jt;
/* 41 */     this.fs = fs;
/* 42 */     this.hdfsMonitorInterval = conf.getInt("mapreduce.jt.hdfs.monitor.interval.ms", 5000);
/*    */ 
/* 46 */     setDaemon(true);
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/* 52 */     LOG.info("Starting HDFS Health Monitoring...");
/*    */ 
/* 54 */     boolean previouslyHealthy = true;
/* 55 */     boolean done = false;
/*    */ 
/* 57 */     while ((!done) && (!isInterrupted()))
/*    */     {
/* 59 */       boolean currentlyHealthy = DistributedFileSystem.isHealthy(this.fs.getUri());
/* 60 */       if (currentlyHealthy != previouslyHealthy)
/*    */       {
/*    */         JobTracker.SafeModeAction action;
/* 63 */         if (currentlyHealthy) {
/* 64 */           JobTracker.SafeModeAction action = JobTracker.SafeModeAction.SAFEMODE_LEAVE;
/* 65 */           LOG.info("HDFS healthy again, instructing JobTracker to leave 'safemode' ...");
/*    */         }
/*    */         else {
/* 68 */           action = JobTracker.SafeModeAction.SAFEMODE_ENTER;
/* 69 */           LOG.info("HDFS is unhealthy, instructing JobTracker to enter 'safemode' ...");
/*    */         }
/*    */ 
/*    */         try
/*    */         {
/* 74 */           if (this.jt.isInAdminSafeMode())
/*    */           {
/* 76 */             LOG.info("JobTracker is in admin-set safemode, not overriding through " + action);
/*    */ 
/* 78 */             previouslyHealthy = currentlyHealthy;
/*    */           } else {
/* 80 */             previouslyHealthy = !this.jt.setSafeModeInternal(action);
/*    */           }
/*    */         }
/*    */         catch (IOException ioe) {
/* 84 */           LOG.info("Failed to setSafeMode with action " + action, ioe);
/*    */         }
/*    */       }
/*    */       try
/*    */       {
/* 89 */         Thread.sleep(this.hdfsMonitorInterval);
/*    */       } catch (InterruptedException e) {
/* 91 */         done = true;
/*    */       }
/*    */     }
/*    */ 
/* 95 */     LOG.info("Stoping HDFS Health Monitoring...");
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.HDFSMonitorThread
 * JD-Core Version:    0.6.1
 */
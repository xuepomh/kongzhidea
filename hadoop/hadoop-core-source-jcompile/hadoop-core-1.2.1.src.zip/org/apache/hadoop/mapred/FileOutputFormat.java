/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.text.NumberFormat;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.io.compress.CompressionCodec;
/*     */ import org.apache.hadoop.mapreduce.security.TokenCache;
/*     */ import org.apache.hadoop.util.Progressable;
/*     */ 
/*     */ public abstract class FileOutputFormat<K, V>
/*     */   implements OutputFormat<K, V>
/*     */ {
/*     */   public static void setCompressOutput(JobConf conf, boolean compress)
/*     */   {
/*  43 */     conf.setBoolean("mapred.output.compress", compress);
/*     */   }
/*     */ 
/*     */   public static boolean getCompressOutput(JobConf conf)
/*     */   {
/*  53 */     return conf.getBoolean("mapred.output.compress", false);
/*     */   }
/*     */ 
/*     */   public static void setOutputCompressorClass(JobConf conf, Class<? extends CompressionCodec> codecClass)
/*     */   {
/*  65 */     setCompressOutput(conf, true);
/*  66 */     conf.setClass("mapred.output.compression.codec", codecClass, CompressionCodec.class);
/*     */   }
/*     */ 
/*     */   public static Class<? extends CompressionCodec> getOutputCompressorClass(JobConf conf, Class<? extends CompressionCodec> defaultValue)
/*     */   {
/*  81 */     Class codecClass = defaultValue;
/*     */ 
/*  83 */     String name = conf.get("mapred.output.compression.codec");
/*  84 */     if (name != null) {
/*     */       try {
/*  86 */         codecClass = conf.getClassByName(name).asSubclass(CompressionCodec.class);
/*     */       }
/*     */       catch (ClassNotFoundException e) {
/*  89 */         throw new IllegalArgumentException("Compression codec " + name + " was not found.", e);
/*     */       }
/*     */     }
/*     */ 
/*  93 */     return codecClass;
/*     */   }
/*     */ 
/*     */   public abstract RecordWriter<K, V> getRecordWriter(FileSystem paramFileSystem, JobConf paramJobConf, String paramString, Progressable paramProgressable)
/*     */     throws IOException;
/*     */ 
/*     */   public void checkOutputSpecs(FileSystem ignored, JobConf job)
/*     */     throws FileAlreadyExistsException, InvalidJobConfException, IOException
/*     */   {
/* 105 */     Path outDir = getOutputPath(job);
/* 106 */     if ((outDir == null) && (job.getNumReduceTasks() != 0)) {
/* 107 */       throw new InvalidJobConfException("Output directory not set in JobConf.");
/*     */     }
/* 109 */     if (outDir != null) {
/* 110 */       FileSystem fs = outDir.getFileSystem(job);
/*     */ 
/* 112 */       outDir = fs.makeQualified(outDir);
/* 113 */       setOutputPath(job, outDir);
/*     */ 
/* 116 */       TokenCache.obtainTokensForNamenodes(job.getCredentials(), new Path[] { outDir }, job);
/*     */ 
/* 120 */       if (fs.exists(outDir))
/* 121 */         throw new FileAlreadyExistsException("Output directory " + outDir + " already exists");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void setOutputPath(JobConf conf, Path outputDir)
/*     */   {
/* 135 */     outputDir = new Path(conf.getWorkingDirectory(), outputDir);
/* 136 */     conf.set("mapred.output.dir", outputDir.toString());
/*     */   }
/*     */ 
/*     */   static void setWorkOutputPath(JobConf conf, Path outputDir)
/*     */   {
/* 151 */     outputDir = new Path(conf.getWorkingDirectory(), outputDir);
/* 152 */     conf.set("mapred.work.output.dir", outputDir.toString());
/*     */   }
/*     */ 
/*     */   public static Path getOutputPath(JobConf conf)
/*     */   {
/* 162 */     String name = conf.get("mapred.output.dir");
/* 163 */     return name == null ? null : new Path(name);
/*     */   }
/*     */ 
/*     */   public static Path getWorkOutputPath(JobConf conf)
/*     */   {
/* 218 */     String name = conf.get("mapred.work.output.dir");
/* 219 */     return name == null ? null : new Path(name);
/*     */   }
/*     */ 
/*     */   public static Path getTaskOutputPath(JobConf conf, String name)
/*     */     throws IOException
/*     */   {
/* 234 */     Path outputPath = getOutputPath(conf);
/* 235 */     if (outputPath == null) {
/* 236 */       throw new IOException("Undefined job output-path");
/*     */     }
/*     */ 
/* 239 */     OutputCommitter committer = conf.getOutputCommitter();
/* 240 */     Path workPath = outputPath;
/* 241 */     TaskAttemptContext context = new TaskAttemptContext(conf, TaskAttemptID.forName(conf.get("mapred.task.id")));
/*     */ 
/* 243 */     if ((committer instanceof FileOutputCommitter)) {
/* 244 */       workPath = ((FileOutputCommitter)committer).getWorkPath(context, outputPath);
/*     */     }
/*     */ 
/* 249 */     return new Path(workPath, name);
/*     */   }
/*     */ 
/*     */   public static String getUniqueName(JobConf conf, String name)
/*     */   {
/* 269 */     int partition = conf.getInt("mapred.task.partition", -1);
/* 270 */     if (partition == -1) {
/* 271 */       throw new IllegalArgumentException("This method can only be called from within a Job");
/*     */     }
/*     */ 
/* 275 */     String taskType = conf.getBoolean("mapred.task.is.map", true) ? "m" : "r";
/*     */ 
/* 277 */     NumberFormat numberFormat = NumberFormat.getInstance();
/* 278 */     numberFormat.setMinimumIntegerDigits(5);
/* 279 */     numberFormat.setGroupingUsed(false);
/*     */ 
/* 281 */     return name + "-" + taskType + "-" + numberFormat.format(partition);
/*     */   }
/*     */ 
/*     */   public static Path getPathForCustomFile(JobConf conf, String name)
/*     */   {
/* 300 */     return new Path(getWorkOutputPath(conf), getUniqueName(conf, name));
/*     */   }
/*     */ 
/*     */   public static enum Counter
/*     */   {
/*  34 */     BYTES_WRITTEN;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.FileOutputFormat
 * JD-Core Version:    0.6.1
 */
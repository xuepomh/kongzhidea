package org.apache.hadoop.mapred;

import java.io.IOException;

public abstract interface InputFormat<K, V>
{
  public abstract InputSplit[] getSplits(JobConf paramJobConf, int paramInt)
    throws IOException;

  public abstract RecordReader<K, V> getRecordReader(InputSplit paramInputSplit, JobConf paramJobConf, Reporter paramReporter)
    throws IOException;
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.InputFormat
 * JD-Core Version:    0.6.1
 */
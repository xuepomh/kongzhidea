/*    */ package org.apache.hadoop.mapred;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class InvalidFileTypeException extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public InvalidFileTypeException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public InvalidFileTypeException(String msg)
/*    */   {
/* 37 */     super(msg);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.InvalidFileTypeException
 * JD-Core Version:    0.6.1
 */
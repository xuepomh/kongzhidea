/*      */ package org.apache.hadoop.mapred;
/*      */ 
/*      */ import java.io.BufferedReader;
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.URLDecoder;
/*      */ import java.net.URLEncoder;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.SortedMap;
/*      */ import java.util.TreeMap;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.LinkedBlockingQueue;
/*      */ import java.util.concurrent.ThreadPoolExecutor;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.apache.hadoop.conf.Configuration;
/*      */ import org.apache.hadoop.fs.FSDataInputStream;
/*      */ import org.apache.hadoop.fs.FSDataOutputStream;
/*      */ import org.apache.hadoop.fs.FileStatus;
/*      */ import org.apache.hadoop.fs.FileSystem;
/*      */ import org.apache.hadoop.fs.FileUtil;
/*      */ import org.apache.hadoop.fs.Path;
/*      */ import org.apache.hadoop.fs.PathFilter;
/*      */ import org.apache.hadoop.fs.permission.FsAction;
/*      */ import org.apache.hadoop.fs.permission.FsPermission;
/*      */ import org.apache.hadoop.mapreduce.JobACL;
/*      */ import org.apache.hadoop.security.authorize.AccessControlList;
/*      */ import org.apache.hadoop.util.DiskChecker.DiskErrorException;
/*      */ import org.apache.hadoop.util.StringUtils;
/*      */ 
/*      */ public class JobHistory
/*      */ {
/*      */   static final long VERSION = 1L;
/*      */   static final int DONE_DIRECTORY_FORMAT_VERSION = 1;
/*      */   static final String DONE_DIRECTORY_FORMAT_DIRNAME = "version-1";
/*      */   static final String UNDERSCORE_ESCAPE = "%5F";
/*  105 */   public static final Log LOG = LogFactory.getLog(JobHistory.class);
/*      */   private static final char DELIMITER = ' ';
/*      */   static final char LINE_DELIMITER_CHAR = '.';
/*  108 */   static final char[] charsToEscape = { '"', '=', '.' };
/*      */   static final String DIGITS = "[0-9]+";
/*      */   static final String KEY = "(\\w+)";
/*      */   static final String VALUE = "[^\"\\\\]*+(?:\\\\.[^\"\\\\]*+)*+";
/*  116 */   static final Pattern pattern = Pattern.compile("(\\w+)=\"[^\"\\\\]*+(?:\\\\.[^\"\\\\]*+)*+\"");
/*      */   static final int MAXIMUM_DATESTRING_COUNT = 200000;
/*      */   public static final int JOB_NAME_TRIM_LENGTH = 50;
/*  121 */   private static String JOBTRACKER_UNIQUE_STRING = null;
/*  122 */   private static String LOG_DIR = null;
/*      */   private static final String SECONDARY_FILE_SUFFIX = ".recover";
/*  124 */   private static long jobHistoryBlockSize = 0L;
/*      */   private static String jobtrackerHostname;
/*  126 */   private static JobHistoryFilesManager fileManager = null;
/*  127 */   static final FsPermission HISTORY_DIR_PERMISSION = FsPermission.createImmutable((short)493);
/*      */ 
/*  129 */   static final FsPermission HISTORY_FILE_PERMISSION = FsPermission.createImmutable((short)484);
/*      */   private static FileSystem LOGDIR_FS;
/*      */   protected static FileSystem DONEDIR_FS;
/*      */   private static JobConf jtConf;
/*  134 */   protected static Path DONE = null;
/*  135 */   private static String DONE_BEFORE_SERIAL_TAIL = doneSubdirsBeforeSerialTail();
/*  136 */   private static String DONE_LEAF_FILES = new StringBuilder().append(DONE_BEFORE_SERIAL_TAIL).append("/*").toString();
/*  137 */   private static boolean aclsEnabled = false;
/*      */   static final String CONF_FILE_NAME_SUFFIX = "_conf.xml";
/*      */   private static final int SERIAL_NUMBER_DIRECTORY_DIGITS = 6;
/*      */   private static int SERIAL_NUMBER_LOW_DIGITS;
/*      */   private static String SERIAL_NUMBER_FORMAT;
/*  146 */   private static final Set<Path> existingDoneSubdirs = new HashSet();
/*      */ 
/*  148 */   private static final SortedMap<Integer, String> idToDateString = new TreeMap();
/*      */ 
/*  154 */   private static final PathFilter CONF_FILTER = new PathFilter() {
/*      */     public boolean accept(Path path) {
/*  156 */       return path.getName().endsWith("_conf.xml");
/*      */     }
/*  154 */   };
/*      */ 
/*  160 */   private static final Map<JobID, MovedFileInfo> jobHistoryFileMap = Collections.synchronizedMap(new LinkedHashMap());
/*      */ 
/*  164 */   private static final SortedMap<Long, String> jobToDirectoryMap = new TreeMap();
/*      */ 
/*  168 */   public static final Pattern JOBHISTORY_FILENAME_REGEX = Pattern.compile("(job_[0-9]+_[0-9]+)_.+");
/*      */ 
/*  171 */   public static final Pattern CONF_FILENAME_REGEX = Pattern.compile("(job_[0-9]+_[0-9]+)_conf.xml");
/*      */ 
/*      */   public static String getHistoryFilePath(JobID jobId)
/*      */   {
/*  187 */     MovedFileInfo info = (MovedFileInfo)jobHistoryFileMap.get(jobId);
/*  188 */     if (info == null) {
/*  189 */       return null;
/*      */     }
/*  191 */     return info.historyFile;
/*      */   }
/*      */ 
/*      */   private static int jobSerialNumber(JobID id)
/*      */   {
/*  340 */     return id.getId();
/*      */   }
/*      */ 
/*      */   private static String serialNumberDirectoryComponent(JobID id) {
/*  344 */     return String.format(SERIAL_NUMBER_FORMAT, new Object[] { Integer.valueOf(jobSerialNumber(id)) }).substring(0, 6);
/*      */   }
/*      */ 
/*      */   private static String timestampDirectoryComponent(JobID id, long millisecondTime)
/*      */   {
/*  353 */     int serialNumber = jobSerialNumber(id);
/*  354 */     Integer boxedSerialNumber = Integer.valueOf(serialNumber);
/*      */ 
/*  357 */     Calendar timestamp = Calendar.getInstance();
/*  358 */     timestamp.setTimeInMillis(millisecondTime);
/*      */ 
/*  360 */     synchronized (idToDateString) {
/*  361 */       String dateString = (String)idToDateString.get(boxedSerialNumber);
/*      */ 
/*  363 */       if (dateString == null)
/*      */       {
/*  365 */         dateString = String.format("%04d/%02d/%02d", new Object[] { Integer.valueOf(timestamp.get(1)), Integer.valueOf(timestamp.get(2) + 1), Integer.valueOf(timestamp.get(5)) });
/*      */ 
/*  373 */         dateString = dateString.intern();
/*      */ 
/*  375 */         idToDateString.put(boxedSerialNumber, dateString);
/*      */ 
/*  377 */         if (idToDateString.size() > 200000) {
/*  378 */           idToDateString.remove(idToDateString.firstKey());
/*      */         }
/*      */       }
/*      */ 
/*  382 */       return dateString;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static boolean maybeMakeSubdirectory(JobID id, long millisecondTime)
/*      */     throws IOException
/*      */   {
/*  389 */     Path dir = canonicalHistoryLogPath(id, millisecondTime);
/*      */ 
/*  391 */     synchronized (existingDoneSubdirs) {
/*  392 */       if (existingDoneSubdirs.contains(dir)) {
/*  393 */         if ((LOG.isDebugEnabled()) && (!DONEDIR_FS.exists(dir))) {
/*  394 */           LOG.error(new StringBuilder().append("JobHistory.maybeMakeSubdirectory -- We believed ").append(dir).append(" already existed, but it didn't.").toString());
/*      */         }
/*      */ 
/*  398 */         return true;
/*      */       }
/*      */ 
/*  401 */       if (!DONEDIR_FS.exists(dir)) {
/*  402 */         LOG.info(new StringBuilder().append("Creating DONE subfolder at ").append(dir).toString());
/*      */ 
/*  404 */         if (!FileSystem.mkdirs(DONEDIR_FS, dir, new FsPermission(HISTORY_DIR_PERMISSION)))
/*      */         {
/*  406 */           throw new IOException(new StringBuilder().append("Mkdirs failed to create ").append(dir.toString()).toString());
/*      */         }
/*      */ 
/*  409 */         existingDoneSubdirs.add(dir);
/*      */ 
/*  411 */         return false;
/*      */       }
/*  413 */       if (LOG.isDebugEnabled()) {
/*  414 */         LOG.error(new StringBuilder().append("JobHistory.maybeMakeSubdirectory -- We believed ").append(dir).append(" didn't already exist, but it did.").toString());
/*      */       }
/*      */ 
/*  418 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static Path canonicalHistoryLogPath(JobID id, long millisecondTime)
/*      */   {
/*  424 */     return new Path(DONE, historyLogSubdirectory(id, millisecondTime));
/*      */   }
/*      */ 
/*      */   private static String historyLogSubdirectory(JobID id, long millisecondTime) {
/*  428 */     String result = new StringBuilder().append("version-1/").append(jobtrackerDirectoryComponent(id)).toString();
/*      */ 
/*  432 */     String serialNumberDirectory = serialNumberDirectoryComponent(id);
/*      */ 
/*  434 */     result = new StringBuilder().append(result).append("/").append(timestampDirectoryComponent(id, millisecondTime)).append("/").append(serialNumberDirectory).append("/").toString();
/*      */ 
/*  439 */     return result;
/*      */   }
/*      */ 
/*      */   private static String jobtrackerDirectoryComponent(JobID id) {
/*  443 */     return JOBTRACKER_UNIQUE_STRING;
/*      */   }
/*      */ 
/*      */   private static String doneSubdirsBeforeSerialTail()
/*      */   {
/*  448 */     String result = "/version-1/*";
/*      */ 
/*  453 */     result = new StringBuilder().append(result).append("/*/*/*").toString();
/*      */ 
/*  455 */     return result;
/*      */   }
/*      */ 
/*      */   public static void init(JobTracker jobTracker, JobConf conf, String hostname, long jobTrackerStartTime)
/*      */     throws IOException
/*      */   {
/*  500 */     initLogDir(conf);
/*  501 */     SERIAL_NUMBER_LOW_DIGITS = 3;
/*  502 */     SERIAL_NUMBER_FORMAT = new StringBuilder().append("%0").append(6 + SERIAL_NUMBER_LOW_DIGITS).append("d").toString();
/*      */ 
/*  505 */     JOBTRACKER_UNIQUE_STRING = new StringBuilder().append(hostname).append("_").append(String.valueOf(jobTrackerStartTime)).append("_").toString();
/*      */ 
/*  507 */     jobtrackerHostname = hostname;
/*  508 */     Path logDir = new Path(LOG_DIR);
/*  509 */     if (!LOGDIR_FS.exists(logDir)) {
/*  510 */       if (!LOGDIR_FS.mkdirs(logDir, new FsPermission(HISTORY_DIR_PERMISSION)))
/*  511 */         throw new IOException(new StringBuilder().append("Mkdirs failed to create ").append(logDir.toString()).toString());
/*      */     }
/*      */     else {
/*  514 */       checkDirectoryPermissions(LOGDIR_FS, logDir, "hadoop.job.history.location");
/*      */     }
/*  516 */     conf.set("hadoop.job.history.location", LOG_DIR);
/*      */ 
/*  518 */     jobHistoryBlockSize = conf.getLong("mapred.jobtracker.job.history.block.size", 3145728L);
/*      */ 
/*  521 */     jtConf = conf;
/*      */ 
/*  524 */     aclsEnabled = conf.getBoolean("mapred.acls.enabled", false);
/*      */ 
/*  527 */     fileManager = new JobHistoryFilesManager(conf, jobTracker);
/*      */   }
/*      */ 
/*      */   private static void initLogDir(JobConf conf) throws IOException {
/*  531 */     LOG_DIR = conf.get("hadoop.job.history.location", new StringBuilder().append("file:///").append(new File(System.getProperty("hadoop.log.dir")).getAbsolutePath()).append(File.separator).append("history").toString());
/*      */ 
/*  535 */     Path logDir = new Path(LOG_DIR);
/*  536 */     LOGDIR_FS = logDir.getFileSystem(conf);
/*      */   }
/*      */ 
/*      */   static void initDone(JobConf conf, FileSystem fs) throws IOException {
/*  540 */     initDone(conf, fs, true);
/*      */   }
/*      */ 
/*      */   static void initDone(JobConf conf, FileSystem fs, boolean setup)
/*      */     throws IOException
/*      */   {
/*  547 */     String doneLocation = conf.get("mapred.job.tracker.history.completed.location");
/*      */ 
/*  549 */     if (doneLocation != null) {
/*  550 */       DONE = fs.makeQualified(new Path(doneLocation));
/*  551 */       DONEDIR_FS = fs;
/*      */     } else {
/*  553 */       if (!setup) {
/*  554 */         initLogDir(conf);
/*      */       }
/*  556 */       DONE = new Path(LOG_DIR, "done");
/*  557 */       DONEDIR_FS = LOGDIR_FS;
/*      */     }
/*  559 */     Path versionSubdir = new Path(DONE, "version-1");
/*      */ 
/*  562 */     if (!DONEDIR_FS.exists(DONE)) {
/*  563 */       LOG.info(new StringBuilder().append("Creating DONE folder at ").append(DONE).toString());
/*  564 */       if (!DONEDIR_FS.mkdirs(DONE, new FsPermission(HISTORY_DIR_PERMISSION)))
/*      */       {
/*  566 */         throw new IOException(new StringBuilder().append("Mkdirs failed to create ").append(DONE.toString()).toString());
/*      */       }
/*      */ 
/*  569 */       if ((!DONEDIR_FS.exists(versionSubdir)) && 
/*  570 */         (!DONEDIR_FS.mkdirs(versionSubdir, new FsPermission(HISTORY_DIR_PERMISSION))))
/*      */       {
/*  572 */         throw new IOException(new StringBuilder().append("Mkdirs failed to create ").append(versionSubdir).toString());
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  577 */       checkDirectoryPermissions(DONEDIR_FS, DONE, "mapred.job.tracker.history.completed.location");
/*      */ 
/*  579 */       if (DONEDIR_FS.exists(versionSubdir)) {
/*  580 */         checkDirectoryPermissions(DONEDIR_FS, versionSubdir, "mapred.job.tracker.history.completed.location-versionsubdir");
/*      */       }
/*      */     }
/*      */ 
/*  584 */     if (!setup) {
/*  585 */       return;
/*      */     }
/*      */ 
/*  588 */     fileManager.start();
/*      */ 
/*  590 */     HistoryCleaner.cleanupFrequency = conf.getLong("mapreduce.jobhistory.cleaner.interval-ms", 86400000L);
/*      */ 
/*  593 */     HistoryCleaner.maxAgeOfHistoryFiles = conf.getLong("mapreduce.jobhistory.max-age-ms", 2592000000L);
/*      */ 
/*  596 */     LOG.info(String.format("Job History MaxAge is %d ms (%.2f days), Cleanup Frequency is %d ms (%.2f days)", new Object[] { Long.valueOf(HistoryCleaner.maxAgeOfHistoryFiles), Float.valueOf((float)HistoryCleaner.maxAgeOfHistoryFiles / 86400000.0F), Long.valueOf(HistoryCleaner.cleanupFrequency), Float.valueOf((float)HistoryCleaner.cleanupFrequency / 86400000.0F) }));
/*      */   }
/*      */ 
/*      */   static void checkDirectoryPermissions(FileSystem fs, Path path, String configKey)
/*      */     throws IOException, DiskChecker.DiskErrorException
/*      */   {
/*  613 */     FileStatus stat = fs.getFileStatus(path);
/*  614 */     FsPermission actual = stat.getPermission();
/*  615 */     if (!stat.isDir()) {
/*  616 */       throw new DiskChecker.DiskErrorException(new StringBuilder().append(configKey).append(" - not a directory: ").append(path.toString()).toString());
/*      */     }
/*  618 */     FsAction user = actual.getUserAction();
/*  619 */     if (!user.implies(FsAction.READ)) {
/*  620 */       throw new DiskChecker.DiskErrorException(new StringBuilder().append("bad ").append(configKey).append("- directory is not readable: ").append(path.toString()).toString());
/*      */     }
/*  622 */     if (!user.implies(FsAction.WRITE))
/*  623 */       throw new DiskChecker.DiskErrorException(new StringBuilder().append("bad ").append(configKey).append("- directory is not writable ").append(path.toString()).toString());
/*      */   }
/*      */ 
/*      */   static String escapeString(String data)
/*      */   {
/*  685 */     return StringUtils.escapeString(data, '\\', charsToEscape);
/*      */   }
/*      */ 
/*      */   public static void parseHistoryFromFS(String path, Listener l, FileSystem fs)
/*      */     throws IOException
/*      */   {
/*  700 */     FSDataInputStream in = fs.open(new Path(path));
/*  701 */     BufferedReader reader = new BufferedReader(new InputStreamReader(in));
/*      */     try {
/*  703 */       String line = null;
/*  704 */       StringBuffer buf = new StringBuffer();
/*      */ 
/*  708 */       line = reader.readLine();
/*      */ 
/*  711 */       if (line == null)
/*      */       {
/*      */         return;
/*      */       }
/*      */ 
/*  716 */       MetaInfoManager mgr = new MetaInfoManager(line);
/*  717 */       boolean isEscaped = mgr.isValueEscaped();
/*  718 */       String lineDelim = String.valueOf(mgr.getLineDelim());
/*  719 */       String escapedLineDelim = StringUtils.escapeString(lineDelim, '\\', mgr.getLineDelim());
/*      */       do
/*      */       {
/*  724 */         buf.append(line);
/*  725 */         if ((!line.trim().endsWith(lineDelim)) || (line.trim().endsWith(escapedLineDelim)))
/*      */         {
/*  727 */           buf.append("\n");
/*      */         }
/*      */         else {
/*  730 */           parseLine(buf.toString(), l, isEscaped);
/*  731 */           buf = new StringBuffer(); } 
/*  732 */       }while ((line = reader.readLine()) != null); } finally {
/*      */       try {
/*  734 */         reader.close();
/*      */       }
/*      */       catch (IOException ex)
/*      */       {
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void parseLine(String line, Listener l, boolean isEscaped)
/*      */     throws IOException
/*      */   {
/*  747 */     int idx = line.indexOf(32);
/*  748 */     String recType = line.substring(0, idx);
/*  749 */     String data = line.substring(idx + 1, line.length());
/*      */ 
/*  751 */     Matcher matcher = pattern.matcher(data);
/*  752 */     Map parseBuffer = new HashMap();
/*      */ 
/*  754 */     while (matcher.find()) {
/*  755 */       String tuple = matcher.group(0);
/*  756 */       String[] parts = StringUtils.split(tuple, '\\', '=');
/*  757 */       String value = parts[1].substring(1, parts[1].length() - 1);
/*  758 */       if (isEscaped) {
/*  759 */         value = StringUtils.unEscapeString(value, '\\', charsToEscape);
/*      */       }
/*      */ 
/*  762 */       parseBuffer.put(Keys.valueOf(parts[0]), value);
/*      */     }
/*      */ 
/*  765 */     l.handle(RecordTypes.valueOf(recType), parseBuffer);
/*      */ 
/*  767 */     parseBuffer.clear();
/*      */   }
/*      */ 
/*      */   static void log(PrintWriter out, RecordTypes recordType, Keys key, String value)
/*      */   {
/*  780 */     value = escapeString(value);
/*  781 */     out.println(new StringBuilder().append(recordType.name()).append(' ').append(key).append("=\"").append(value).append("\"").append(' ').append('.').toString());
/*      */   }
/*      */ 
/*      */   static void log(ArrayList<PrintWriter> writers, RecordTypes recordType, Keys[] keys, String[] values)
/*      */   {
/*  803 */     log(writers, recordType, keys, values, null);
/*      */   }
/*      */ 
/*      */   static void log(ArrayList<PrintWriter> writers, RecordTypes recordType, Keys[] keys, String[] values, JobID id)
/*      */   {
/*  824 */     int length = recordType.name().length() + keys.length * 4 + 2;
/*  825 */     for (int i = 0; i < keys.length; i++) {
/*  826 */       values[i] = escapeString(values[i]);
/*  827 */       length += values[i].length() + keys[i].toString().length();
/*      */     }
/*      */ 
/*  831 */     StringBuilder builder = new StringBuilder(length);
/*  832 */     builder.append(recordType.name());
/*  833 */     builder.append(' ');
/*  834 */     for (int i = 0; i < keys.length; i++) {
/*  835 */       builder.append(keys[i]);
/*  836 */       builder.append("=\"");
/*  837 */       builder.append(values[i]);
/*  838 */       builder.append("\"");
/*  839 */       builder.append(' ');
/*      */     }
/*  841 */     builder.append('.');
/*      */ 
/*  843 */     String logLine = builder.toString();
/*  844 */     for (Iterator iter = writers.iterator(); iter.hasNext(); ) {
/*  845 */       PrintWriter out = (PrintWriter)iter.next();
/*  846 */       out.println(logLine);
/*  847 */       if ((out.checkError()) && (id != null)) {
/*  848 */         LOG.info(new StringBuilder().append("Logging failed for job ").append(id).append("removing PrintWriter from FileManager").toString());
/*  849 */         iter.remove();
/*      */       }
/*      */     }
/*  852 */     if (recordType != RecordTypes.Meta)
/*  853 */       JobHistoryLogger.LOG.debug(logLine);
/*      */   }
/*      */ 
/*      */   static Path getJobHistoryLocation()
/*      */   {
/*  861 */     return new Path(LOG_DIR);
/*      */   }
/*      */ 
/*      */   static Path getCompletedJobHistoryLocation()
/*      */   {
/*  868 */     return DONE;
/*      */   }
/*      */ 
/*      */   static int serialNumberDirectoryDigits() {
/*  872 */     return 6;
/*      */   }
/*      */ 
/*      */   static int serialNumberTotalDigits() {
/*  876 */     return serialNumberDirectoryDigits() + SERIAL_NUMBER_LOW_DIGITS;
/*      */   }
/*      */ 
/*      */   static Path[] filteredStat2Paths(FileStatus[] stats, boolean dirs, AtomicBoolean hasMismatches)
/*      */   {
/*  958 */     int resultCount = 0;
/*      */ 
/*  960 */     if (hasMismatches == null) {
/*  961 */       hasMismatches = new AtomicBoolean(false);
/*      */     }
/*      */ 
/*  964 */     for (int i = 0; i < stats.length; i++) {
/*  965 */       if (stats[i].isDir() == dirs)
/*  966 */         stats[(resultCount++)] = stats[i];
/*      */       else {
/*  968 */         hasMismatches.set(true);
/*      */       }
/*      */     }
/*      */ 
/*  972 */     Path[] paddedResult = FileUtil.stat2Paths(stats);
/*      */ 
/*  974 */     Path[] result = new Path[resultCount];
/*      */ 
/*  976 */     System.arraycopy(paddedResult, 0, result, 0, resultCount);
/*      */ 
/*  978 */     return result;
/*      */   }
/*      */ 
/*      */   static FileStatus[] localGlobber(FileSystem fs, Path root, String tail)
/*      */     throws IOException
/*      */   {
/*  984 */     return localGlobber(fs, root, tail, null);
/*      */   }
/*      */ 
/*      */   static FileStatus[] localGlobber(FileSystem fs, Path root, String tail, PathFilter filter)
/*      */     throws IOException
/*      */   {
/*  990 */     return localGlobber(fs, root, tail, filter, null);
/*      */   }
/*      */ 
/*      */   private static FileStatus[] nullToEmpty(FileStatus[] result) {
/*  994 */     return result == null ? new FileStatus[0] : result;
/*      */   }
/*      */ 
/*      */   private static FileStatus[] listFilteredStatus(FileSystem fs, Path root, PathFilter filter)
/*      */     throws IOException
/*      */   {
/* 1000 */     return filter == null ? fs.listStatus(root) : fs.listStatus(root, filter);
/*      */   }
/*      */ 
/*      */   static FileStatus[] localGlobber(FileSystem fs, Path root, String tail, PathFilter filter, AtomicBoolean hasFlatFiles)
/*      */     throws IOException
/*      */   {
/* 1009 */     if (tail.equals("")) {
/* 1010 */       return nullToEmpty(listFilteredStatus(fs, root, filter));
/*      */     }
/*      */ 
/* 1013 */     if (tail.startsWith("/*")) {
/* 1014 */       Path[] subdirs = filteredStat2Paths(nullToEmpty(fs.listStatus(root)), true, hasFlatFiles);
/*      */ 
/* 1017 */       FileStatus[][] subsubdirs = new FileStatus[subdirs.length][];
/*      */ 
/* 1019 */       int subsubdirCount = 0;
/*      */ 
/* 1021 */       if (subsubdirs.length == 0) {
/* 1022 */         return new FileStatus[0];
/*      */       }
/*      */ 
/* 1025 */       String newTail = tail.substring(2);
/*      */ 
/* 1027 */       for (int i = 0; i < subdirs.length; i++) {
/* 1028 */         subsubdirs[i] = localGlobber(fs, subdirs[i], newTail, filter, null);
/* 1029 */         subsubdirCount += subsubdirs[i].length;
/*      */       }
/*      */ 
/* 1032 */       FileStatus[] result = new FileStatus[subsubdirCount];
/*      */ 
/* 1034 */       int segmentStart = 0;
/*      */ 
/* 1036 */       for (int i = 0; i < subsubdirs.length; i++) {
/* 1037 */         System.arraycopy(subsubdirs[i], 0, result, segmentStart, subsubdirs[i].length);
/* 1038 */         segmentStart += subsubdirs[i].length;
/*      */       }
/*      */ 
/* 1041 */       return result;
/*      */     }
/*      */ 
/* 1044 */     if (tail.startsWith("/")) {
/* 1045 */       int split = tail.indexOf(47, 1);
/*      */ 
/* 1047 */       if (split < 0) {
/* 1048 */         return nullToEmpty(listFilteredStatus(fs, new Path(root, tail.substring(1)), filter));
/*      */       }
/*      */ 
/* 1051 */       String thisSegment = tail.substring(1, split);
/* 1052 */       String newTail = tail.substring(split);
/* 1053 */       return localGlobber(fs, new Path(root, thisSegment), newTail, filter, hasFlatFiles);
/*      */     }
/*      */ 
/* 1058 */     IOException e = new IOException("localGlobber: bad tail");
/*      */ 
/* 1060 */     throw e;
/*      */   }
/*      */ 
/*      */   static Path confPathFromLogFilePath(Path logFile) {
/* 1064 */     String jobId = jobIdNameFromLogFileName(logFile.getName());
/*      */ 
/* 1066 */     Path logDir = logFile.getParent();
/*      */ 
/* 1068 */     return new Path(logDir, new StringBuilder().append(jobId).append("_conf.xml").toString());
/*      */   }
/*      */ 
/*      */   static String jobIdNameFromLogFileName(String logFileName) {
/* 1072 */     String[] jobDetails = logFileName.split("_");
/* 1073 */     return new StringBuilder().append(jobDetails[0]).append("_").append(jobDetails[1]).append("_").append(jobDetails[2]).toString();
/*      */   }
/*      */ 
/*      */   static String userNameFromLogFileName(String logFileName) {
/* 1077 */     String[] jobDetails = logFileName.split("_");
/* 1078 */     return jobDetails[3];
/*      */   }
/*      */ 
/*      */   static String jobNameFromLogFileName(String logFileName) {
/* 1082 */     String[] jobDetails = logFileName.split("_");
/* 1083 */     return jobDetails[4];
/*      */   }
/*      */ 
/*      */   static String escapeUnderscores(String escapee)
/*      */   {
/* 1089 */     return replaceStringInstances(escapee, "_", "%5F");
/*      */   }
/*      */ 
/*      */   static String nonOccursString(String logFileName) {
/* 1093 */     int adHocIndex = 0;
/*      */ 
/* 1095 */     String unfoundString = new StringBuilder().append("q").append(adHocIndex).toString();
/*      */ 
/* 1097 */     while (logFileName.contains(unfoundString)) {
/* 1098 */       unfoundString = new StringBuilder().append("q").append(++adHocIndex).toString();
/*      */     }
/*      */ 
/* 1101 */     return new StringBuilder().append(unfoundString).append("q").toString();
/*      */   }
/*      */ 
/*      */   static String replaceStringInstances(String logFileName, String old, String replacement)
/*      */   {
/* 1108 */     int index = logFileName.indexOf(old);
/*      */ 
/* 1110 */     while (index > 0) {
/* 1111 */       logFileName = new StringBuilder().append(logFileName.substring(0, index)).append(replacement).append(replaceStringInstances(logFileName.substring(index + old.length()), old, replacement)).toString();
/*      */ 
/* 1117 */       index = logFileName.indexOf(old);
/*      */     }
/*      */ 
/* 1120 */     return logFileName;
/*      */   }
/*      */ 
/*      */   static long directoryTime(String year, String month, String day)
/*      */   {
/* 2611 */     Calendar result = Calendar.getInstance();
/* 2612 */     result.clear();
/*      */ 
/* 2614 */     result.set(1, Integer.parseInt(year));
/*      */ 
/* 2619 */     result.set(2, Integer.parseInt(month) - 1);
/*      */ 
/* 2621 */     result.set(5, Integer.parseInt(day));
/*      */ 
/* 2624 */     long timeInMillis = result.getTimeInMillis();
/* 2625 */     return timeInMillis;
/*      */   }
/*      */ 
/*      */   public static String getTaskLogsUrl(TaskAttempt attempt)
/*      */   {
/* 2787 */     if ((attempt.get(Keys.HTTP_PORT).equals("")) || (attempt.get(Keys.TRACKER_NAME).equals("")) || (attempt.get(Keys.TASK_ATTEMPT_ID).equals("")))
/*      */     {
/* 2790 */       return null;
/*      */     }
/*      */ 
/* 2793 */     String taskTrackerName = JobInProgress.convertTrackerNameToHostName(attempt.get(Keys.TRACKER_NAME));
/*      */ 
/* 2796 */     return TaskLogServlet.getTaskLogUrl(taskTrackerName, attempt.get(Keys.HTTP_PORT), attempt.get(Keys.TASK_ATTEMPT_ID));
/*      */   }
/*      */ 
/*      */   public static class HistoryCleaner
/*      */     implements Runnable
/*      */   {
/*      */     static final long ONE_DAY_IN_MS = 86400000L;
/*      */     static final long DEFAULT_HISTORY_MAX_AGE = 2592000000L;
/*      */     static final long DEFAULT_CLEANUP_FREQUENCY = 86400000L;
/* 2638 */     static long cleanupFrequency = 86400000L;
/* 2639 */     static long maxAgeOfHistoryFiles = 2592000000L;
/*      */     private long now;
/* 2641 */     private static final AtomicBoolean isRunning = new AtomicBoolean(false);
/* 2642 */     private static long lastRan = 0L;
/*      */ 
/* 2644 */     private static Pattern parseDirectory = Pattern.compile(".+/([0-9]+)/([0-9]+)/([0-9]+)/[0-9]+/?");
/*      */ 
/*      */     public void run()
/*      */     {
/* 2651 */       if (isRunning.getAndSet(true)) {
/* 2652 */         return;
/*      */       }
/* 2654 */       this.now = System.currentTimeMillis();
/*      */ 
/* 2656 */       if ((lastRan != 0L) && (this.now - lastRan < cleanupFrequency)) {
/* 2657 */         isRunning.set(false);
/* 2658 */         return;
/*      */       }
/* 2660 */       lastRan = this.now;
/* 2661 */       clean(this.now);
/*      */     }
/*      */ 
/*      */     public void clean(long now) {
/* 2665 */       Set deletedPathnames = new HashSet();
/*      */ 
/* 2668 */       boolean printedOneDeletee = false;
/* 2669 */       boolean printedOneMovedFile = false;
/*      */       try
/*      */       {
/* 2672 */         Path[] datedDirectories = FileUtil.stat2Paths(JobHistory.localGlobber(JobHistory.DONEDIR_FS, JobHistory.DONE, JobHistory.DONE_BEFORE_SERIAL_TAIL, null));
/*      */ 
/* 2677 */         long cutoff = now - maxAgeOfHistoryFiles;
/* 2678 */         Calendar cutoffDay = Calendar.getInstance();
/* 2679 */         cutoffDay.setTimeInMillis(cutoff);
/* 2680 */         cutoffDay.set(11, 0);
/* 2681 */         cutoffDay.set(12, 0);
/* 2682 */         cutoffDay.set(13, 0);
/* 2683 */         cutoffDay.set(14, 0);
/*      */ 
/* 2686 */         for (int i = 0; i < datedDirectories.length; i++) {
/* 2687 */           String thisDir = datedDirectories[i].toString();
/* 2688 */           Matcher pathMatcher = parseDirectory.matcher(thisDir);
/*      */ 
/* 2690 */           if (pathMatcher.matches()) {
/* 2691 */             long dirDay = JobHistory.directoryTime(pathMatcher.group(1), pathMatcher.group(2), pathMatcher.group(3));
/*      */ 
/* 2695 */             if (JobHistory.LOG.isDebugEnabled()) {
/* 2696 */               JobHistory.LOG.debug("HistoryCleaner.run just parsed " + thisDir + " as year/month/day = " + pathMatcher.group(1) + "/" + pathMatcher.group(2) + "/" + pathMatcher.group(3));
/*      */             }
/*      */ 
/* 2701 */             if ((dirDay <= cutoffDay.getTimeInMillis()) && 
/* 2702 */               (JobHistory.LOG.isDebugEnabled())) {
/* 2703 */               Calendar nnow = Calendar.getInstance();
/* 2704 */               nnow.setTimeInMillis(now);
/* 2705 */               Calendar then = Calendar.getInstance();
/* 2706 */               then.setTimeInMillis(dirDay);
/*      */ 
/* 2708 */               JobHistory.LOG.debug("HistoryCleaner.run directory: " + thisDir + " because its time is " + then + " but it's now " + nnow);
/*      */             }
/*      */ 
/* 2714 */             if (dirDay == cutoffDay.getTimeInMillis())
/*      */             {
/* 2716 */               FileStatus[] possibleDeletees = JobHistory.DONEDIR_FS.listStatus(datedDirectories[i]);
/*      */ 
/* 2718 */               for (int j = 0; j < possibleDeletees.length; j++) {
/* 2719 */                 if (possibleDeletees[j].getModificationTime() < now - maxAgeOfHistoryFiles)
/*      */                 {
/* 2721 */                   Path deletee = possibleDeletees[j].getPath();
/* 2722 */                   if ((JobHistory.LOG.isDebugEnabled()) && (!printedOneDeletee)) {
/* 2723 */                     JobHistory.LOG.debug("HistoryCleaner.run deletee: " + deletee.toString());
/*      */ 
/* 2725 */                     printedOneDeletee = true;
/*      */                   }
/*      */ 
/* 2728 */                   JobHistory.DONEDIR_FS.delete(deletee);
/* 2729 */                   deletedPathnames.add(deletee.toString());
/*      */                 }
/*      */ 
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/* 2736 */             if (dirDay < cutoffDay.getTimeInMillis()) {
/* 2737 */               synchronized (JobHistory.existingDoneSubdirs) {
/* 2738 */                 if (!JobHistory.existingDoneSubdirs.contains(datedDirectories[i])) {
/* 2739 */                   JobHistory.LOG.warn("JobHistory: existingDoneSubdirs doesn't contain " + datedDirectories[i] + ", but should.");
/*      */                 }
/*      */ 
/* 2742 */                 JobHistory.DONEDIR_FS.delete(datedDirectories[i], true);
/* 2743 */                 JobHistory.existingDoneSubdirs.remove(datedDirectories[i]);
/*      */               }
/*      */             }
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 2750 */         synchronized (JobHistory.jobHistoryFileMap) {
/* 2751 */           Iterator it = JobHistory.jobHistoryFileMap.entrySet().iterator();
/*      */ 
/* 2753 */           while (it.hasNext()) {
/* 2754 */             JobHistory.MovedFileInfo info = (JobHistory.MovedFileInfo)((Map.Entry)it.next()).getValue();
/*      */ 
/* 2756 */             if ((JobHistory.LOG.isDebugEnabled()) && (!printedOneMovedFile)) {
/* 2757 */               JobHistory.LOG.debug("HistoryCleaner.run a moved file: " + JobHistory.MovedFileInfo.access$000(info));
/* 2758 */               printedOneMovedFile = true;
/*      */             }
/*      */ 
/* 2761 */             if (deletedPathnames.contains(JobHistory.MovedFileInfo.access$000(info)))
/* 2762 */               it.remove();
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (IOException ie) {
/* 2767 */         JobHistory.LOG.info("Error cleaning up history directory" + StringUtils.stringifyException(ie));
/*      */       }
/*      */       finally {
/* 2770 */         isRunning.set(false);
/*      */       }
/*      */     }
/*      */ 
/*      */     static long getLastRan() {
/* 2775 */       return lastRan;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static abstract interface Listener
/*      */   {
/*      */     public abstract void handle(JobHistory.RecordTypes paramRecordTypes, Map<JobHistory.Keys, String> paramMap)
/*      */       throws IOException;
/*      */   }
/*      */ 
/*      */   public static class ReduceAttempt extends JobHistory.TaskAttempt
/*      */   {
/*      */     @Deprecated
/*      */     public static void logStarted(TaskAttemptID taskAttemptId, long startTime, String hostName)
/*      */     {
/* 2397 */       logStarted(taskAttemptId, startTime, hostName, -1, JobHistory.Values.REDUCE.name());
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public static void logStarted(TaskAttemptID taskAttemptId, long startTime, String trackerName, int httpPort, String taskType)
/*      */     {
/* 2405 */       logStarted(taskAttemptId, startTime, trackerName, httpPort, taskType, Locality.OFF_SWITCH, Avataar.VIRGIN);
/*      */     }
/*      */ 
/*      */     public static void logStarted(TaskAttemptID taskAttemptId, long startTime, String trackerName, int httpPort, String taskType, Locality locality, Avataar avataar)
/*      */     {
/* 2424 */       JobID id = taskAttemptId.getJobID();
/* 2425 */       ArrayList writer = JobHistory.fileManager.getWriters(id);
/*      */ 
/* 2427 */       if (null != writer)
/* 2428 */         JobHistory.log(writer, JobHistory.RecordTypes.ReduceAttempt, new JobHistory.Keys[] { JobHistory.Keys.TASK_TYPE, JobHistory.Keys.TASKID, JobHistory.Keys.TASK_ATTEMPT_ID, JobHistory.Keys.START_TIME, JobHistory.Keys.TRACKER_NAME, JobHistory.Keys.HTTP_PORT, JobHistory.Keys.LOCALITY, JobHistory.Keys.AVATAAR }, new String[] { taskType, taskAttemptId.getTaskID().toString(), taskAttemptId.toString(), String.valueOf(startTime), trackerName, httpPort == -1 ? "" : String.valueOf(httpPort), locality.toString(), avataar.toString() }, id);
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public static void logFinished(TaskAttemptID taskAttemptId, long shuffleFinished, long sortFinished, long finishTime, String hostName)
/*      */     {
/* 2458 */       logFinished(taskAttemptId, shuffleFinished, sortFinished, finishTime, hostName, JobHistory.Values.REDUCE.name(), "", new Counters());
/*      */     }
/*      */ 
/*      */     public static void logFinished(TaskAttemptID taskAttemptId, long shuffleFinished, long sortFinished, long finishTime, String hostName, String taskType, String stateString, Counters counter)
/*      */     {
/* 2480 */       JobID id = taskAttemptId.getJobID();
/* 2481 */       ArrayList writer = JobHistory.fileManager.getWriters(id);
/*      */ 
/* 2483 */       if (null != writer)
/* 2484 */         JobHistory.log(writer, JobHistory.RecordTypes.ReduceAttempt, new JobHistory.Keys[] { JobHistory.Keys.TASK_TYPE, JobHistory.Keys.TASKID, JobHistory.Keys.TASK_ATTEMPT_ID, JobHistory.Keys.TASK_STATUS, JobHistory.Keys.SHUFFLE_FINISHED, JobHistory.Keys.SORT_FINISHED, JobHistory.Keys.FINISH_TIME, JobHistory.Keys.HOSTNAME, JobHistory.Keys.STATE_STRING, JobHistory.Keys.COUNTERS }, new String[] { taskType, taskAttemptId.getTaskID().toString(), taskAttemptId.toString(), JobHistory.Values.SUCCESS.name(), String.valueOf(shuffleFinished), String.valueOf(sortFinished), String.valueOf(finishTime), hostName, stateString, counter.makeEscapedCompactString() }, id);
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public static void logFailed(TaskAttemptID taskAttemptId, long timestamp, String hostName, String error)
/*      */     {
/* 2514 */       logFailed(taskAttemptId, timestamp, hostName, error, JobHistory.Values.REDUCE.name());
/*      */     }
/*      */ 
/*      */     public static void logFailed(TaskAttemptID taskAttemptId, long timestamp, String hostName, String error, String taskType)
/*      */     {
/* 2529 */       JobID id = taskAttemptId.getJobID();
/* 2530 */       ArrayList writer = JobHistory.fileManager.getWriters(id);
/*      */ 
/* 2532 */       if (null != writer)
/* 2533 */         JobHistory.log(writer, JobHistory.RecordTypes.ReduceAttempt, new JobHistory.Keys[] { JobHistory.Keys.TASK_TYPE, JobHistory.Keys.TASKID, JobHistory.Keys.TASK_ATTEMPT_ID, JobHistory.Keys.TASK_STATUS, JobHistory.Keys.FINISH_TIME, JobHistory.Keys.HOSTNAME, JobHistory.Keys.ERROR }, new String[] { taskType, taskAttemptId.getTaskID().toString(), taskAttemptId.toString(), JobHistory.Values.FAILED.name(), String.valueOf(timestamp), hostName, error }, id);
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public static void logKilled(TaskAttemptID taskAttemptId, long timestamp, String hostName, String error)
/*      */     {
/* 2558 */       logKilled(taskAttemptId, timestamp, hostName, error, JobHistory.Values.REDUCE.name());
/*      */     }
/*      */ 
/*      */     public static void logKilled(TaskAttemptID taskAttemptId, long timestamp, String hostName, String error, String taskType)
/*      */     {
/* 2573 */       JobID id = taskAttemptId.getJobID();
/* 2574 */       ArrayList writer = JobHistory.fileManager.getWriters(id);
/*      */ 
/* 2576 */       if (null != writer)
/* 2577 */         JobHistory.log(writer, JobHistory.RecordTypes.ReduceAttempt, new JobHistory.Keys[] { JobHistory.Keys.TASK_TYPE, JobHistory.Keys.TASKID, JobHistory.Keys.TASK_ATTEMPT_ID, JobHistory.Keys.TASK_STATUS, JobHistory.Keys.FINISH_TIME, JobHistory.Keys.HOSTNAME, JobHistory.Keys.ERROR }, new String[] { taskType, taskAttemptId.getTaskID().toString(), taskAttemptId.toString(), JobHistory.Values.KILLED.name(), String.valueOf(timestamp), hostName, error }, id);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class MapAttempt extends JobHistory.TaskAttempt
/*      */   {
/*      */     @Deprecated
/*      */     public static void logStarted(TaskAttemptID taskAttemptId, long startTime, String hostName)
/*      */     {
/* 2196 */       logStarted(taskAttemptId, startTime, hostName, -1, JobHistory.Values.MAP.name());
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public static void logStarted(TaskAttemptID taskAttemptId, long startTime, String trackerName, int httpPort, String taskType)
/*      */     {
/* 2202 */       logStarted(taskAttemptId, startTime, trackerName, httpPort, taskType, Locality.OFF_SWITCH, Avataar.VIRGIN);
/*      */     }
/*      */ 
/*      */     public static void logStarted(TaskAttemptID taskAttemptId, long startTime, String trackerName, int httpPort, String taskType, Locality locality, Avataar avataar)
/*      */     {
/* 2221 */       JobID id = taskAttemptId.getJobID();
/* 2222 */       ArrayList writer = JobHistory.fileManager.getWriters(id);
/*      */ 
/* 2224 */       if (null != writer)
/* 2225 */         JobHistory.log(writer, JobHistory.RecordTypes.MapAttempt, new JobHistory.Keys[] { JobHistory.Keys.TASK_TYPE, JobHistory.Keys.TASKID, JobHistory.Keys.TASK_ATTEMPT_ID, JobHistory.Keys.START_TIME, JobHistory.Keys.TRACKER_NAME, JobHistory.Keys.HTTP_PORT, JobHistory.Keys.LOCALITY, JobHistory.Keys.AVATAAR }, new String[] { taskType, taskAttemptId.getTaskID().toString(), taskAttemptId.toString(), String.valueOf(startTime), trackerName, httpPort == -1 ? "" : String.valueOf(httpPort), locality.toString(), avataar.toString() }, id);
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public static void logFinished(TaskAttemptID taskAttemptId, long finishTime, String hostName)
/*      */     {
/* 2252 */       logFinished(taskAttemptId, finishTime, hostName, JobHistory.Values.MAP.name(), "", new Counters());
/*      */     }
/*      */ 
/*      */     public static void logFinished(TaskAttemptID taskAttemptId, long finishTime, String hostName, String taskType, String stateString, Counters counter)
/*      */     {
/* 2272 */       JobID id = taskAttemptId.getJobID();
/* 2273 */       ArrayList writer = JobHistory.fileManager.getWriters(id);
/*      */ 
/* 2275 */       if (null != writer)
/* 2276 */         JobHistory.log(writer, JobHistory.RecordTypes.MapAttempt, new JobHistory.Keys[] { JobHistory.Keys.TASK_TYPE, JobHistory.Keys.TASKID, JobHistory.Keys.TASK_ATTEMPT_ID, JobHistory.Keys.TASK_STATUS, JobHistory.Keys.FINISH_TIME, JobHistory.Keys.HOSTNAME, JobHistory.Keys.STATE_STRING, JobHistory.Keys.COUNTERS }, new String[] { taskType, taskAttemptId.getTaskID().toString(), taskAttemptId.toString(), JobHistory.Values.SUCCESS.name(), String.valueOf(finishTime), hostName, stateString, counter.makeEscapedCompactString() }, id);
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public static void logFailed(TaskAttemptID taskAttemptId, long timestamp, String hostName, String error)
/*      */     {
/* 2304 */       logFailed(taskAttemptId, timestamp, hostName, error, JobHistory.Values.MAP.name());
/*      */     }
/*      */ 
/*      */     public static void logFailed(TaskAttemptID taskAttemptId, long timestamp, String hostName, String error, String taskType)
/*      */     {
/* 2319 */       JobID id = taskAttemptId.getJobID();
/* 2320 */       ArrayList writer = JobHistory.fileManager.getWriters(id);
/*      */ 
/* 2322 */       if (null != writer)
/* 2323 */         JobHistory.log(writer, JobHistory.RecordTypes.MapAttempt, new JobHistory.Keys[] { JobHistory.Keys.TASK_TYPE, JobHistory.Keys.TASKID, JobHistory.Keys.TASK_ATTEMPT_ID, JobHistory.Keys.TASK_STATUS, JobHistory.Keys.FINISH_TIME, JobHistory.Keys.HOSTNAME, JobHistory.Keys.ERROR }, new String[] { taskType, taskAttemptId.getTaskID().toString(), taskAttemptId.toString(), JobHistory.Values.FAILED.name(), String.valueOf(timestamp), hostName, error }, id);
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public static void logKilled(TaskAttemptID taskAttemptId, long timestamp, String hostName, String error)
/*      */     {
/* 2348 */       logKilled(taskAttemptId, timestamp, hostName, error, JobHistory.Values.MAP.name());
/*      */     }
/*      */ 
/*      */     public static void logKilled(TaskAttemptID taskAttemptId, long timestamp, String hostName, String error, String taskType)
/*      */     {
/* 2363 */       JobID id = taskAttemptId.getJobID();
/* 2364 */       ArrayList writer = JobHistory.fileManager.getWriters(id);
/*      */ 
/* 2366 */       if (null != writer)
/* 2367 */         JobHistory.log(writer, JobHistory.RecordTypes.MapAttempt, new JobHistory.Keys[] { JobHistory.Keys.TASK_TYPE, JobHistory.Keys.TASKID, JobHistory.Keys.TASK_ATTEMPT_ID, JobHistory.Keys.TASK_STATUS, JobHistory.Keys.FINISH_TIME, JobHistory.Keys.HOSTNAME, JobHistory.Keys.ERROR }, new String[] { taskType, taskAttemptId.getTaskID().toString(), taskAttemptId.toString(), JobHistory.Values.KILLED.name(), String.valueOf(timestamp), hostName, error }, id);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class TaskAttempt extends JobHistory.Task
/*      */   {
/*      */   }
/*      */ 
/*      */   public static class Task extends JobHistory.KeyValuePair
/*      */   {
/* 2073 */     private Map<String, JobHistory.TaskAttempt> taskAttempts = new TreeMap();
/*      */ 
/*      */     public static void logStarted(TaskID taskId, String taskType, long startTime, String splitLocations)
/*      */     {
/* 2083 */       JobID id = taskId.getJobID();
/* 2084 */       ArrayList writer = JobHistory.fileManager.getWriters(id);
/*      */ 
/* 2086 */       if (null != writer)
/* 2087 */         JobHistory.log(writer, JobHistory.RecordTypes.Task, new JobHistory.Keys[] { JobHistory.Keys.TASKID, JobHistory.Keys.TASK_TYPE, JobHistory.Keys.START_TIME, JobHistory.Keys.SPLITS }, new String[] { taskId.toString(), taskType, String.valueOf(startTime), splitLocations }, id);
/*      */     }
/*      */ 
/*      */     public static void logFinished(TaskID taskId, String taskType, long finishTime, Counters counters)
/*      */     {
/* 2103 */       JobID id = taskId.getJobID();
/* 2104 */       ArrayList writer = JobHistory.fileManager.getWriters(id);
/*      */ 
/* 2106 */       if (null != writer)
/* 2107 */         JobHistory.log(writer, JobHistory.RecordTypes.Task, new JobHistory.Keys[] { JobHistory.Keys.TASKID, JobHistory.Keys.TASK_TYPE, JobHistory.Keys.TASK_STATUS, JobHistory.Keys.FINISH_TIME, JobHistory.Keys.COUNTERS }, new String[] { taskId.toString(), taskType, JobHistory.Values.SUCCESS.name(), String.valueOf(finishTime), counters.makeEscapedCompactString() }, id);
/*      */     }
/*      */ 
/*      */     public static void logUpdates(TaskID taskId, long finishTime)
/*      */     {
/* 2123 */       JobID id = taskId.getJobID();
/* 2124 */       ArrayList writer = JobHistory.fileManager.getWriters(id);
/*      */ 
/* 2126 */       if (null != writer)
/* 2127 */         JobHistory.log(writer, JobHistory.RecordTypes.Task, new JobHistory.Keys[] { JobHistory.Keys.TASKID, JobHistory.Keys.FINISH_TIME }, new String[] { taskId.toString(), String.valueOf(finishTime) }, id);
/*      */     }
/*      */ 
/*      */     public static void logFailed(TaskID taskId, String taskType, long time, String error)
/*      */     {
/* 2142 */       logFailed(taskId, taskType, time, error, null);
/*      */     }
/*      */ 
/*      */     public static void logFailed(TaskID taskId, String taskType, long time, String error, TaskAttemptID failedDueToAttempt)
/*      */     {
/* 2151 */       JobID id = taskId.getJobID();
/* 2152 */       ArrayList writer = JobHistory.fileManager.getWriters(id);
/*      */ 
/* 2154 */       if (null != writer) {
/* 2155 */         String failedAttempt = failedDueToAttempt == null ? "" : failedDueToAttempt.toString();
/*      */ 
/* 2158 */         JobHistory.log(writer, JobHistory.RecordTypes.Task, new JobHistory.Keys[] { JobHistory.Keys.TASKID, JobHistory.Keys.TASK_TYPE, JobHistory.Keys.TASK_STATUS, JobHistory.Keys.FINISH_TIME, JobHistory.Keys.ERROR, JobHistory.Keys.TASK_ATTEMPT_ID }, new String[] { taskId.toString(), taskType, JobHistory.Values.FAILED.name(), String.valueOf(time), error, failedAttempt }, id);
/*      */       }
/*      */     }
/*      */ 
/*      */     public Map<String, JobHistory.TaskAttempt> getTaskAttempts()
/*      */     {
/* 2172 */       return this.taskAttempts;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class JobInfo extends JobHistory.KeyValuePair
/*      */   {
/* 1129 */     private Map<String, JobHistory.Task> allTasks = new TreeMap();
/* 1130 */     private Map<JobACL, AccessControlList> jobACLs = new HashMap();
/*      */ 
/* 1132 */     private String queueName = null;
/*      */ 
/*      */     public JobInfo(String jobId)
/*      */     {
/* 1136 */       set(JobHistory.Keys.JOBID, jobId);
/*      */     }
/*      */ 
/*      */     public Map<String, JobHistory.Task> getAllTasks()
/*      */     {
/* 1142 */       return this.allTasks;
/*      */     }
/*      */ 
/*      */     public Map<JobACL, AccessControlList> getJobACLs()
/*      */     {
/* 1150 */       return this.jobACLs;
/*      */     }
/*      */ 
/*      */     public synchronized void handle(Map<JobHistory.Keys, String> values)
/*      */     {
/* 1155 */       if (values.containsKey(JobHistory.Keys.SUBMIT_TIME))
/*      */       {
/* 1157 */         String viewJobACL = (String)values.get(JobHistory.Keys.VIEW_JOB);
/* 1158 */         String modifyJobACL = (String)values.get(JobHistory.Keys.MODIFY_JOB);
/* 1159 */         if (viewJobACL != null) {
/* 1160 */           this.jobACLs.put(JobACL.VIEW_JOB, new AccessControlList(viewJobACL));
/*      */         }
/* 1162 */         if (modifyJobACL != null) {
/* 1163 */           this.jobACLs.put(JobACL.MODIFY_JOB, new AccessControlList(modifyJobACL));
/*      */         }
/*      */ 
/* 1166 */         this.queueName = ((String)values.get(JobHistory.Keys.JOB_QUEUE));
/*      */       }
/* 1168 */       super.handle(values);
/*      */     }
/*      */ 
/*      */     String getJobQueue() {
/* 1172 */       return this.queueName;
/*      */     }
/*      */ 
/*      */     public static String getLocalJobFilePath(JobID jobId)
/*      */     {
/* 1181 */       return new StringBuilder().append(System.getProperty("hadoop.log.dir")).append(File.separator).append(jobId).append("_conf.xml").toString();
/*      */     }
/*      */ 
/*      */     public static String encodeJobHistoryFilePath(String logFile)
/*      */       throws IOException
/*      */     {
/* 1196 */       Path rawPath = new Path(logFile);
/* 1197 */       String encodedFileName = null;
/*      */       try {
/* 1199 */         encodedFileName = URLEncoder.encode(rawPath.getName(), "UTF-8");
/*      */       } catch (UnsupportedEncodingException uee) {
/* 1201 */         IOException ioe = new IOException();
/* 1202 */         ioe.initCause(uee);
/* 1203 */         ioe.setStackTrace(uee.getStackTrace());
/* 1204 */         throw ioe;
/*      */       }
/*      */ 
/* 1207 */       Path encodedPath = new Path(rawPath.getParent(), encodedFileName);
/* 1208 */       return encodedPath.toString();
/*      */     }
/*      */ 
/*      */     public static String encodeJobHistoryFileName(String logFileName)
/*      */       throws IOException
/*      */     {
/* 1221 */       String replacementUnderscoreEscape = null;
/*      */ 
/* 1223 */       if (logFileName.contains("%5F")) {
/* 1224 */         replacementUnderscoreEscape = JobHistory.nonOccursString(logFileName);
/*      */ 
/* 1226 */         logFileName = JobHistory.replaceStringInstances(logFileName, "%5F", replacementUnderscoreEscape);
/*      */       }
/*      */ 
/* 1230 */       String encodedFileName = null;
/*      */       try {
/* 1232 */         encodedFileName = URLEncoder.encode(logFileName, "UTF-8");
/*      */       } catch (UnsupportedEncodingException uee) {
/* 1234 */         IOException ioe = new IOException();
/* 1235 */         ioe.initCause(uee);
/* 1236 */         ioe.setStackTrace(uee.getStackTrace());
/* 1237 */         throw ioe;
/*      */       }
/*      */ 
/* 1240 */       if (replacementUnderscoreEscape != null) {
/* 1241 */         encodedFileName = JobHistory.replaceStringInstances(encodedFileName, replacementUnderscoreEscape, "%5F");
/*      */       }
/*      */ 
/* 1245 */       return encodedFileName;
/*      */     }
/*      */ 
/*      */     public static String decodeJobHistoryFileName(String logFileName)
/*      */       throws IOException
/*      */     {
/* 1258 */       String decodedFileName = null;
/*      */       try {
/* 1260 */         decodedFileName = URLDecoder.decode(logFileName, "UTF-8");
/*      */       } catch (UnsupportedEncodingException uee) {
/* 1262 */         IOException ioe = new IOException();
/* 1263 */         ioe.initCause(uee);
/* 1264 */         ioe.setStackTrace(uee.getStackTrace());
/* 1265 */         throw ioe;
/*      */       }
/* 1267 */       return decodedFileName;
/*      */     }
/*      */ 
/*      */     static String getJobName(JobConf jobConf)
/*      */     {
/* 1274 */       String jobName = jobConf.getJobName();
/* 1275 */       if ((jobName == null) || (jobName.length() == 0)) {
/* 1276 */         jobName = "NA";
/*      */       }
/* 1278 */       return jobName;
/*      */     }
/*      */ 
/*      */     public static String getUserName(JobConf jobConf)
/*      */     {
/* 1285 */       String user = jobConf.getUser();
/* 1286 */       if ((user == null) || (user.length() == 0)) {
/* 1287 */         user = "NA";
/*      */       }
/* 1289 */       return user;
/*      */     }
/*      */ 
/*      */     public static String getWorkflowAdjacencies(Configuration conf)
/*      */     {
/* 1297 */       int prefixLen = "mapreduce.workflow.adjacency.".length();
/* 1298 */       Map adjacencies = conf.getValByRegex("^mapreduce\\.workflow\\.adjacency\\..+");
/*      */ 
/* 1300 */       if (adjacencies.isEmpty())
/* 1301 */         return "";
/* 1302 */       int size = 0;
/* 1303 */       for (Map.Entry entry : adjacencies.entrySet()) {
/* 1304 */         int keyLen = ((String)entry.getKey()).length();
/* 1305 */         size += keyLen - prefixLen;
/* 1306 */         size += ((String)entry.getValue()).length() + 6;
/*      */       }
/* 1308 */       StringBuilder sb = new StringBuilder(size);
/* 1309 */       for (Map.Entry entry : adjacencies.entrySet()) {
/* 1310 */         int keyLen = ((String)entry.getKey()).length();
/* 1311 */         sb.append("\"");
/* 1312 */         sb.append(JobHistory.escapeString(((String)entry.getKey()).substring(prefixLen, keyLen)));
/* 1313 */         sb.append("\"=\"");
/* 1314 */         sb.append(JobHistory.escapeString((String)entry.getValue()));
/* 1315 */         sb.append("\" ");
/*      */       }
/* 1317 */       return sb.toString();
/*      */     }
/*      */ 
/*      */     public static Path getJobHistoryLogLocation(String logFileName)
/*      */     {
/* 1325 */       return JobHistory.LOG_DIR == null ? null : new Path(JobHistory.LOG_DIR, logFileName);
/*      */     }
/*      */ 
/*      */     public static Path getJobHistoryLogLocationForUser(String logFileName, JobConf jobConf)
/*      */     {
/* 1334 */       Path userLogFile = null;
/* 1335 */       Path outputPath = FileOutputFormat.getOutputPath(jobConf);
/* 1336 */       String userLogDir = jobConf.get("hadoop.job.history.user.location", outputPath == null ? null : outputPath.toString());
/*      */ 
/* 1340 */       if ("none".equals(userLogDir)) {
/* 1341 */         userLogDir = null;
/*      */       }
/* 1343 */       if (userLogDir != null) {
/* 1344 */         userLogDir = new StringBuilder().append(userLogDir).append("/").append("_logs").append("/").append("history").toString();
/*      */ 
/* 1346 */         userLogFile = new Path(userLogDir, logFileName);
/*      */       }
/* 1348 */       return userLogFile;
/*      */     }
/*      */ 
/*      */     private static String getNewJobHistoryFileName(JobConf jobConf, JobID id, long submitTime)
/*      */     {
/* 1355 */       return new StringBuilder().append(id.toString()).append("_").append(submitTime).append("_").append(JobHistory.escapeUnderscores(getUserName(jobConf))).append("_").append(JobHistory.escapeUnderscores(trimJobName(getJobName(jobConf)))).toString();
/*      */     }
/*      */ 
/*      */     private static String trimJobName(String jobName)
/*      */     {
/* 1366 */       if (jobName.length() > 50) {
/* 1367 */         jobName = jobName.substring(0, 50);
/*      */       }
/* 1369 */       return jobName;
/*      */     }
/*      */ 
/*      */     private static String escapeRegexChars(String string) {
/* 1373 */       return new StringBuilder().append("\\Q").append(string.replaceAll("\\\\E", "\\\\E\\\\\\\\E\\\\Q")).append("\\E").toString();
/*      */     }
/*      */ 
/*      */     public static synchronized String getJobHistoryFileName(JobConf jobConf, JobID id)
/*      */       throws IOException
/*      */     {
/* 1386 */       return getJobHistoryFileName(jobConf, id, new Path(JobHistory.LOG_DIR), JobHistory.LOGDIR_FS);
/*      */     }
/*      */ 
/*      */     static synchronized String getDoneJobHistoryFileName(JobConf jobConf, JobID id)
/*      */       throws IOException
/*      */     {
/* 1392 */       if (JobHistory.DONE == null) {
/* 1393 */         return null;
/*      */       }
/* 1395 */       return getJobHistoryFileName(jobConf, id, JobHistory.DONE, JobHistory.DONEDIR_FS);
/*      */     }
/*      */ 
/*      */     private static synchronized String getJobHistoryFileName(JobConf jobConf, JobID id, Path dir, FileSystem fs)
/*      */       throws IOException
/*      */     {
/* 1404 */       String user = getUserName(jobConf);
/* 1405 */       String jobName = trimJobName(getJobName(jobConf));
/* 1406 */       if (JobHistory.LOG_DIR == null) {
/* 1407 */         return null;
/*      */       }
/*      */ 
/* 1412 */       String regexp = new StringBuilder().append(id.toString()).append("_").append("[0-9]+").append("_").append(user).append("_").append(escapeRegexChars(jobName)).append("+").toString();
/*      */ 
/* 1416 */       Pattern historyFilePattern = Pattern.compile(regexp);
/*      */ 
/* 1423 */       PathFilter filter = new PathFilter() {
/*      */         public boolean accept(Path path) {
/* 1425 */           String unescapedFileName = path.getName();
/* 1426 */           String fileName = null;
/*      */           try {
/* 1428 */             fileName = JobHistory.JobInfo.decodeJobHistoryFileName(unescapedFileName);
/*      */           } catch (IOException ioe) {
/* 1430 */             JobHistory.LOG.info("Error while decoding history file " + fileName + "." + " Ignoring file.", ioe);
/*      */ 
/* 1432 */             return false;
/*      */           }
/*      */ 
/* 1435 */           return this.val$historyFilePattern.matcher(fileName).find();
/*      */         }
/*      */       };
/* 1439 */       FileStatus[] statuses = null;
/*      */ 
/* 1441 */       if (dir == JobHistory.DONE) {
/* 1442 */         String scanTail = new StringBuilder().append(JobHistory.DONE_BEFORE_SERIAL_TAIL).append("/").append(JobHistory.serialNumberDirectoryComponent(id)).toString();
/*      */ 
/* 1446 */         if (JobHistory.LOG.isDebugEnabled()) {
/* 1447 */           JobHistory.LOG.debug(new StringBuilder().append("JobHistory.getJobHistoryFileName DONE dir: scanning ").append(scanTail).toString());
/*      */ 
/* 1449 */           if (JobHistory.LOG.isTraceEnabled()) {
/* 1450 */             JobHistory.LOG.trace(Thread.currentThread().getStackTrace());
/*      */           }
/*      */         }
/*      */ 
/* 1454 */         statuses = JobHistory.localGlobber(fs, JobHistory.DONE, scanTail, filter);
/*      */       } else {
/* 1456 */         statuses = fs.listStatus(dir, filter);
/*      */       }
/*      */ 
/* 1459 */       String filename = null;
/* 1460 */       if ((statuses == null) || (statuses.length == 0)) {
/* 1461 */         JobHistory.LOG.info(new StringBuilder().append("Nothing to recover for job ").append(id).toString());
/*      */       }
/*      */       else
/*      */       {
/* 1465 */         filename = getPrimaryFilename(statuses[0].getPath().getName(), jobName);
/* 1466 */         if (dir == JobHistory.DONE) {
/* 1467 */           Path parent = statuses[0].getPath().getParent();
/* 1468 */           String parentPathName = parent.toString();
/* 1469 */           String donePathName = JobHistory.DONE.toString();
/* 1470 */           filename = new StringBuilder().append(parentPathName.substring(donePathName.length() + "/".length())).append("/").append(filename).toString();
/*      */         }
/*      */ 
/* 1474 */         JobHistory.LOG.info(new StringBuilder().append("Recovered job history filename for job ").append(id).append(" is ").append(filename).toString());
/*      */       }
/*      */ 
/* 1477 */       return filename;
/*      */     }
/*      */ 
/*      */     private static String getPrimaryFilename(String filename, String jobName)
/*      */       throws IOException
/*      */     {
/* 1484 */       filename = decodeJobHistoryFileName(filename);
/*      */ 
/* 1486 */       if (filename.endsWith(new StringBuilder().append(jobName).append(".recover").toString())) {
/* 1487 */         int newLength = filename.length() - ".recover".length();
/* 1488 */         filename = filename.substring(0, newLength);
/*      */       }
/* 1490 */       return encodeJobHistoryFileName(filename);
/*      */     }
/*      */ 
/*      */     static synchronized void checkpointRecovery(String fileName, JobConf conf)
/*      */       throws IOException
/*      */     {
/* 1503 */       Path logPath = getJobHistoryLogLocation(fileName);
/* 1504 */       if (logPath != null) {
/* 1505 */         JobHistory.LOG.info(new StringBuilder().append("Deleting job history file ").append(logPath.getName()).toString());
/* 1506 */         JobHistory.LOGDIR_FS.delete(logPath, false);
/*      */       }
/*      */ 
/* 1509 */       logPath = getJobHistoryLogLocationForUser(fileName, conf);
/*      */ 
/* 1511 */       if (logPath != null) {
/* 1512 */         FileSystem fs = logPath.getFileSystem(conf);
/* 1513 */         fs.delete(logPath, false);
/*      */       }
/*      */     }
/*      */ 
/*      */     static String getSecondaryJobHistoryFile(String filename) throws IOException
/*      */     {
/* 1519 */       return encodeJobHistoryFileName(new StringBuilder().append(decodeJobHistoryFileName(filename)).append(".recover").toString());
/*      */     }
/*      */ 
/*      */     public static synchronized Path recoverJobHistoryFile(JobConf conf, Path logFilePath)
/*      */       throws IOException
/*      */     {
/* 1534 */       String logFileName = logFilePath.getName();
/* 1535 */       String tmpFilename = getSecondaryJobHistoryFile(logFileName);
/* 1536 */       Path logDir = logFilePath.getParent();
/* 1537 */       Path tmpFilePath = new Path(logDir, tmpFilename);
/*      */       Path ret;
/*      */       Path ret;
/* 1538 */       if (JobHistory.LOGDIR_FS.exists(logFilePath)) {
/* 1539 */         JobHistory.LOG.info(new StringBuilder().append(logFileName).append(" exists!").toString());
/* 1540 */         if (JobHistory.LOGDIR_FS.exists(tmpFilePath)) {
/* 1541 */           JobHistory.LOG.info(new StringBuilder().append("Deleting ").append(tmpFilename).append("  and using ").append(logFileName).append(" for recovery.").toString());
/*      */ 
/* 1543 */           JobHistory.LOGDIR_FS.delete(tmpFilePath, false);
/*      */         }
/* 1545 */         ret = tmpFilePath;
/*      */       } else {
/* 1547 */         JobHistory.LOG.info(new StringBuilder().append(logFileName).append(" doesnt exist! Using ").append(tmpFilename).append(" for recovery.").toString());
/*      */         Path ret;
/* 1549 */         if (JobHistory.LOGDIR_FS.exists(tmpFilePath)) {
/* 1550 */           JobHistory.LOG.info(new StringBuilder().append("Renaming ").append(tmpFilename).append(" to ").append(logFileName).toString());
/* 1551 */           JobHistory.LOGDIR_FS.rename(tmpFilePath, logFilePath);
/* 1552 */           ret = tmpFilePath;
/*      */         } else {
/* 1554 */           ret = logFilePath;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1559 */       logFilePath = getJobHistoryLogLocationForUser(logFileName, conf);
/* 1560 */       if (logFilePath != null) {
/* 1561 */         FileSystem fs = logFilePath.getFileSystem(conf);
/* 1562 */         logDir = logFilePath.getParent();
/* 1563 */         tmpFilePath = new Path(logDir, tmpFilename);
/* 1564 */         if (fs.exists(logFilePath)) {
/* 1565 */           JobHistory.LOG.info(new StringBuilder().append(logFileName).append(" exists!").toString());
/* 1566 */           if (fs.exists(tmpFilePath)) {
/* 1567 */             JobHistory.LOG.info(new StringBuilder().append("Deleting ").append(tmpFilename).append("  and making ").append(logFileName).append(" as the master history file for user.").toString());
/*      */ 
/* 1569 */             fs.delete(tmpFilePath, false);
/*      */           }
/*      */         } else {
/* 1572 */           JobHistory.LOG.info(new StringBuilder().append(logFileName).append(" doesnt exist! Using ").append(tmpFilename).append(" as the master history file for user.").toString());
/*      */ 
/* 1574 */           if (fs.exists(tmpFilePath)) {
/* 1575 */             JobHistory.LOG.info(new StringBuilder().append("Renaming ").append(tmpFilename).append(" to ").append(logFileName).append(" in user directory").toString());
/*      */ 
/* 1577 */             fs.rename(tmpFilePath, logFilePath);
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 1582 */       return ret;
/*      */     }
/*      */ 
/*      */     static synchronized void finalizeRecovery(JobID id, JobConf conf)
/*      */       throws IOException
/*      */     {
/* 1594 */       Path tmpLogPath = JobHistory.fileManager.getHistoryFile(id);
/* 1595 */       if (tmpLogPath == null) {
/* 1596 */         if (JobHistory.LOG.isDebugEnabled()) {
/* 1597 */           JobHistory.LOG.debug(new StringBuilder().append("No file for job with ").append(id).append(" found in cache!").toString());
/*      */         }
/* 1599 */         return;
/*      */       }
/* 1601 */       String tmpLogFileName = tmpLogPath.getName();
/*      */ 
/* 1604 */       String masterLogFileName = getPrimaryFilename(tmpLogFileName, getJobName(conf));
/*      */ 
/* 1606 */       Path masterLogPath = new Path(tmpLogPath.getParent(), masterLogFileName);
/*      */ 
/* 1610 */       JobHistory.LOG.info(new StringBuilder().append("Renaming ").append(tmpLogFileName).append(" to ").append(masterLogFileName).toString());
/* 1611 */       JobHistory.LOGDIR_FS.rename(tmpLogPath, masterLogPath);
/*      */ 
/* 1613 */       JobHistory.fileManager.setHistoryFile(id, masterLogPath);
/*      */ 
/* 1616 */       masterLogPath = getJobHistoryLogLocationForUser(masterLogFileName, conf);
/*      */ 
/* 1619 */       tmpLogPath = getJobHistoryLogLocationForUser(tmpLogFileName, conf);
/*      */ 
/* 1622 */       if (masterLogPath != null) {
/* 1623 */         FileSystem fs = masterLogPath.getFileSystem(conf);
/* 1624 */         if (fs.exists(tmpLogPath)) {
/* 1625 */           JobHistory.LOG.info(new StringBuilder().append("Renaming ").append(tmpLogFileName).append(" to ").append(masterLogFileName).append(" in user directory").toString());
/*      */ 
/* 1627 */           fs.rename(tmpLogPath, masterLogPath);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     static void cleanupJob(JobID id)
/*      */     {
/* 1637 */       String localJobFilePath = getLocalJobFilePath(id);
/* 1638 */       File f = new File(localJobFilePath);
/* 1639 */       JobHistory.LOG.info(new StringBuilder().append("Deleting localized job conf at ").append(f).toString());
/* 1640 */       if ((!f.delete()) && 
/* 1641 */         (JobHistory.LOG.isDebugEnabled()))
/* 1642 */         JobHistory.LOG.debug(new StringBuilder().append("Failed to delete file ").append(f).toString());
/*      */     }
/*      */ 
/*      */     static void deleteConfFiles()
/*      */       throws IOException
/*      */     {
/* 1651 */       JobHistory.LOG.info("Cleaning up config files from the job history folder");
/* 1652 */       FileSystem fs = new Path(JobHistory.LOG_DIR).getFileSystem(JobHistory.jtConf);
/* 1653 */       FileStatus[] status = fs.listStatus(new Path(JobHistory.LOG_DIR), JobHistory.CONF_FILTER);
/* 1654 */       for (FileStatus s : status) {
/* 1655 */         JobHistory.LOG.info(new StringBuilder().append("Deleting conf file ").append(s.getPath()).toString());
/* 1656 */         fs.delete(s.getPath(), false);
/*      */       }
/*      */     }
/*      */ 
/*      */     static void markCompleted(JobID id)
/*      */       throws IOException
/*      */     {
/* 1667 */       JobHistory.fileManager.moveToDone(id);
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public static void logSubmitted(JobID jobId, JobConf jobConf, String jobConfPath, long submitTime)
/*      */       throws IOException
/*      */     {
/* 1686 */       logSubmitted(jobId, jobConf, jobConfPath, submitTime, true);
/*      */     }
/*      */ 
/*      */     public static void logSubmitted(JobID jobId, JobConf jobConf, String jobConfPath, long submitTime, boolean restarted)
/*      */       throws IOException
/*      */     {
/* 1693 */       FileSystem fs = null;
/* 1694 */       String userLogDir = null;
/* 1695 */       String jobUniqueString = jobId.toString();
/*      */ 
/* 1699 */       String jobName = getJobName(jobConf);
/* 1700 */       String user = getUserName(jobConf);
/*      */ 
/* 1703 */       String logFileName = null;
/* 1704 */       if (restarted) {
/* 1705 */         logFileName = getJobHistoryFileName(jobConf, jobId);
/* 1706 */         if (logFileName == null) {
/* 1707 */           logFileName = encodeJobHistoryFileName(getNewJobHistoryFileName(jobConf, jobId, submitTime));
/*      */         }
/*      */         else
/*      */         {
/* 1711 */           String[] parts = logFileName.split("_");
/*      */ 
/* 1714 */           String jtUniqueString = new StringBuilder().append(parts[0]).append("_").append(parts[1]).append("_").toString();
/* 1715 */           jobUniqueString = jobId.toString();
/*      */         }
/*      */       } else {
/* 1718 */         logFileName = encodeJobHistoryFileName(getNewJobHistoryFileName(jobConf, jobId, submitTime));
/*      */       }
/*      */ 
/* 1724 */       Path logFile = getJobHistoryLogLocation(logFileName);
/*      */ 
/* 1727 */       Path userLogFile = getJobHistoryLogLocationForUser(logFileName, jobConf);
/*      */ 
/* 1729 */       PrintWriter writer = null;
/*      */       try {
/* 1731 */         FSDataOutputStream out = null;
/* 1732 */         if (JobHistory.LOG_DIR != null)
/*      */         {
/* 1734 */           if (restarted) {
/* 1735 */             logFile = recoverJobHistoryFile(jobConf, logFile);
/* 1736 */             logFileName = logFile.getName();
/*      */           }
/*      */ 
/* 1739 */           int defaultBufferSize = JobHistory.LOGDIR_FS.getConf().getInt("io.file.buffer.size", 4096);
/*      */ 
/* 1741 */           out = JobHistory.LOGDIR_FS.create(logFile, new FsPermission(JobHistory.HISTORY_FILE_PERMISSION), true, defaultBufferSize, JobHistory.LOGDIR_FS.getDefaultReplication(), JobHistory.jobHistoryBlockSize, null);
/*      */ 
/* 1747 */           writer = new PrintWriter(out);
/* 1748 */           JobHistory.fileManager.addWriter(jobId, writer);
/*      */ 
/* 1751 */           JobHistory.fileManager.setHistoryFile(jobId, logFile);
/*      */         }
/* 1753 */         if (userLogFile != null)
/*      */         {
/* 1756 */           userLogDir = userLogFile.getParent().toString();
/* 1757 */           userLogFile = new Path(userLogDir, logFileName);
/*      */ 
/* 1761 */           fs = userLogFile.getFileSystem(jobConf);
/*      */ 
/* 1763 */           out = fs.create(userLogFile, true, 4096);
/* 1764 */           writer = new PrintWriter(out);
/* 1765 */           JobHistory.fileManager.addWriter(jobId, writer);
/*      */         }
/*      */ 
/* 1768 */         ArrayList writers = JobHistory.fileManager.getWriters(jobId);
/*      */ 
/* 1770 */         JobHistory.MetaInfoManager.logMetaInfo(writers);
/*      */ 
/* 1772 */         String viewJobACL = "*";
/* 1773 */         String modifyJobACL = "*";
/* 1774 */         if (JobHistory.aclsEnabled) {
/* 1775 */           viewJobACL = jobConf.get(JobACL.VIEW_JOB.getAclName(), " ");
/* 1776 */           modifyJobACL = jobConf.get(JobACL.MODIFY_JOB.getAclName(), " ");
/*      */         }
/*      */ 
/* 1779 */         JobHistory.log(writers, JobHistory.RecordTypes.Job, new JobHistory.Keys[] { JobHistory.Keys.JOBID, JobHistory.Keys.JOBNAME, JobHistory.Keys.USER, JobHistory.Keys.SUBMIT_TIME, JobHistory.Keys.JOBCONF, JobHistory.Keys.VIEW_JOB, JobHistory.Keys.MODIFY_JOB, JobHistory.Keys.JOB_QUEUE, JobHistory.Keys.WORKFLOW_ID, JobHistory.Keys.WORKFLOW_NAME, JobHistory.Keys.WORKFLOW_NODE_NAME, JobHistory.Keys.WORKFLOW_ADJACENCIES, JobHistory.Keys.WORKFLOW_TAGS }, new String[] { jobId.toString(), jobName, user, String.valueOf(submitTime), jobConfPath, viewJobACL, modifyJobACL, jobConf.getQueueName(), jobConf.get("mapreduce.workflow.id", ""), jobConf.get("mapreduce.workflow.name", ""), jobConf.get("mapreduce.workflow.node.name", ""), getWorkflowAdjacencies(jobConf), jobConf.get("mapreduce.workflow.tags", "") }, jobId);
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/* 1801 */         JobHistory.LOG.error(new StringBuilder().append("Failed creating job history log file for job ").append(jobId).toString(), e);
/* 1802 */         if (writer != null) {
/* 1803 */           JobHistory.fileManager.removeWriter(jobId, writer);
/*      */         }
/*      */       }
/*      */ 
/* 1807 */       String localJobFilePath = getLocalJobFilePath(jobId);
/* 1808 */       File localJobFile = new File(localJobFilePath);
/* 1809 */       FileOutputStream jobOut = null;
/*      */       try {
/* 1811 */         jobOut = new FileOutputStream(localJobFile);
/* 1812 */         jobConf.writeXml(jobOut);
/* 1813 */         if (JobHistory.LOG.isDebugEnabled())
/* 1814 */           JobHistory.LOG.debug(new StringBuilder().append("Job conf for ").append(jobId).append(" stored at ").append(localJobFile.getAbsolutePath()).toString());
/*      */       }
/*      */       catch (IOException ioe)
/*      */       {
/* 1818 */         JobHistory.LOG.error("Failed to store job conf on the local filesystem ", ioe);
/*      */       } finally {
/* 1820 */         if (jobOut != null) {
/*      */           try {
/* 1822 */             jobOut.close();
/*      */           } catch (IOException ie) {
/* 1824 */             JobHistory.LOG.info(new StringBuilder().append("Failed to close the job configuration file ").append(StringUtils.stringifyException(ie)).toString());
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1831 */       Path jobFilePath = null;
/* 1832 */       if (JobHistory.LOG_DIR != null) {
/* 1833 */         jobFilePath = new Path(new StringBuilder().append(JobHistory.LOG_DIR).append(File.separator).append(jobUniqueString).append("_conf.xml").toString());
/*      */ 
/* 1835 */         JobHistory.fileManager.setConfFile(jobId, jobFilePath);
/*      */       }
/* 1837 */       Path userJobFilePath = null;
/* 1838 */       if (userLogDir != null) {
/* 1839 */         userJobFilePath = new Path(new StringBuilder().append(userLogDir).append(File.separator).append(jobUniqueString).append("_conf.xml").toString());
/*      */       }
/*      */ 
/* 1842 */       FSDataOutputStream jobFileOut = null;
/*      */       try {
/* 1844 */         if (JobHistory.LOG_DIR != null) {
/* 1845 */           int defaultBufferSize = JobHistory.LOGDIR_FS.getConf().getInt("io.file.buffer.size", 4096);
/*      */ 
/* 1847 */           if (!JobHistory.LOGDIR_FS.exists(jobFilePath)) {
/* 1848 */             jobFileOut = JobHistory.LOGDIR_FS.create(jobFilePath, new FsPermission(JobHistory.HISTORY_FILE_PERMISSION), true, defaultBufferSize, JobHistory.LOGDIR_FS.getDefaultReplication(), JobHistory.LOGDIR_FS.getDefaultBlockSize(), null);
/*      */ 
/* 1854 */             jobConf.writeXml(jobFileOut);
/* 1855 */             jobFileOut.close();
/*      */           }
/*      */         }
/* 1858 */         if (userLogDir != null) {
/* 1859 */           fs = new Path(userLogDir).getFileSystem(jobConf);
/* 1860 */           jobFileOut = fs.create(userJobFilePath);
/* 1861 */           jobConf.writeXml(jobFileOut);
/*      */         }
/* 1863 */         if (JobHistory.LOG.isDebugEnabled())
/* 1864 */           JobHistory.LOG.debug(new StringBuilder().append("Job conf for ").append(jobId).append(" stored at ").append(jobFilePath).append("and").append(userJobFilePath).toString());
/*      */       }
/*      */       catch (IOException ioe)
/*      */       {
/* 1868 */         JobHistory.LOG.error("Failed to store job conf in the log dir", ioe);
/*      */       } finally {
/* 1870 */         if (jobFileOut != null)
/*      */           try {
/* 1872 */             jobFileOut.close();
/*      */           } catch (IOException ie) {
/* 1874 */             JobHistory.LOG.info(new StringBuilder().append("Failed to close the job configuration file ").append(StringUtils.stringifyException(ie)).toString());
/*      */           }
/*      */       }
/*      */     }
/*      */ 
/*      */     public static void logInited(JobID jobId, long startTime, int totalMaps, int totalReduces)
/*      */     {
/* 1890 */       ArrayList writer = JobHistory.fileManager.getWriters(jobId);
/*      */ 
/* 1892 */       if (null != writer)
/* 1893 */         JobHistory.log(writer, JobHistory.RecordTypes.Job, new JobHistory.Keys[] { JobHistory.Keys.JOBID, JobHistory.Keys.LAUNCH_TIME, JobHistory.Keys.TOTAL_MAPS, JobHistory.Keys.TOTAL_REDUCES, JobHistory.Keys.JOB_STATUS }, new String[] { jobId.toString(), String.valueOf(startTime), String.valueOf(totalMaps), String.valueOf(totalReduces), JobHistory.Values.PREP.name() }, jobId);
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public static void logStarted(JobID jobId, long startTime, int totalMaps, int totalReduces)
/*      */     {
/* 1916 */       logStarted(jobId);
/*      */     }
/*      */ 
/*      */     public static void logStarted(JobID jobId)
/*      */     {
/* 1924 */       ArrayList writer = JobHistory.fileManager.getWriters(jobId);
/*      */ 
/* 1926 */       if (null != writer)
/* 1927 */         JobHistory.log(writer, JobHistory.RecordTypes.Job, new JobHistory.Keys[] { JobHistory.Keys.JOBID, JobHistory.Keys.JOB_STATUS }, new String[] { jobId.toString(), JobHistory.Values.RUNNING.name() }, jobId);
/*      */     }
/*      */ 
/*      */     public static void logFinished(JobID jobId, long finishTime, int finishedMaps, int finishedReduces, int failedMaps, int failedReduces, Counters mapCounters, Counters reduceCounters, Counters counters)
/*      */     {
/* 1951 */       ArrayList writer = JobHistory.fileManager.getWriters(jobId);
/*      */ 
/* 1953 */       if (null != writer) {
/* 1954 */         JobHistory.log(writer, JobHistory.RecordTypes.Job, new JobHistory.Keys[] { JobHistory.Keys.JOBID, JobHistory.Keys.FINISH_TIME, JobHistory.Keys.JOB_STATUS, JobHistory.Keys.FINISHED_MAPS, JobHistory.Keys.FINISHED_REDUCES, JobHistory.Keys.FAILED_MAPS, JobHistory.Keys.FAILED_REDUCES, JobHistory.Keys.MAP_COUNTERS, JobHistory.Keys.REDUCE_COUNTERS, JobHistory.Keys.COUNTERS }, new String[] { jobId.toString(), Long.toString(finishTime), JobHistory.Values.SUCCESS.name(), String.valueOf(finishedMaps), String.valueOf(finishedReduces), String.valueOf(failedMaps), String.valueOf(failedReduces), mapCounters.makeEscapedCompactString(), reduceCounters.makeEscapedCompactString(), counters.makeEscapedCompactString() }, jobId);
/*      */ 
/* 1970 */         for (PrintWriter out : writer) {
/* 1971 */           out.close();
/*      */         }
/*      */       }
/* 1974 */       Thread historyCleaner = new Thread(new JobHistory.HistoryCleaner());
/* 1975 */       historyCleaner.start();
/*      */     }
/*      */ 
/*      */     public static void logFailed(JobID jobid, long timestamp, int finishedMaps, int finishedReduces, String failReason)
/*      */     {
/* 1985 */       ArrayList writer = JobHistory.fileManager.getWriters(jobid);
/*      */ 
/* 1987 */       if (null != writer) {
/* 1988 */         JobHistory.log(writer, JobHistory.RecordTypes.Job, new JobHistory.Keys[] { JobHistory.Keys.JOBID, JobHistory.Keys.FINISH_TIME, JobHistory.Keys.JOB_STATUS, JobHistory.Keys.FINISHED_MAPS, JobHistory.Keys.FINISHED_REDUCES, JobHistory.Keys.FAIL_REASON }, new String[] { jobid.toString(), String.valueOf(timestamp), JobHistory.Values.FAILED.name(), String.valueOf(finishedMaps), String.valueOf(finishedReduces), failReason }, jobid);
/*      */ 
/* 1992 */         for (PrintWriter out : writer)
/* 1993 */           out.close();
/*      */       }
/*      */     }
/*      */ 
/*      */     public static void logKilled(JobID jobid, long timestamp, int finishedMaps, int finishedReduces)
/*      */     {
/* 2011 */       ArrayList writer = JobHistory.fileManager.getWriters(jobid);
/*      */ 
/* 2013 */       if (null != writer) {
/* 2014 */         JobHistory.log(writer, JobHistory.RecordTypes.Job, new JobHistory.Keys[] { JobHistory.Keys.JOBID, JobHistory.Keys.FINISH_TIME, JobHistory.Keys.JOB_STATUS, JobHistory.Keys.FINISHED_MAPS, JobHistory.Keys.FINISHED_REDUCES }, new String[] { jobid.toString(), String.valueOf(timestamp), JobHistory.Values.KILLED.name(), String.valueOf(finishedMaps), String.valueOf(finishedReduces) }, jobid);
/*      */ 
/* 2019 */         for (PrintWriter out : writer)
/* 2020 */           out.close();
/*      */       }
/*      */     }
/*      */ 
/*      */     public static void logJobPriority(JobID jobid, JobPriority priority)
/*      */     {
/* 2030 */       ArrayList writer = JobHistory.fileManager.getWriters(jobid);
/*      */ 
/* 2032 */       if (null != writer)
/* 2033 */         JobHistory.log(writer, JobHistory.RecordTypes.Job, new JobHistory.Keys[] { JobHistory.Keys.JOBID, JobHistory.Keys.JOB_PRIORITY }, new String[] { jobid.toString(), priority.toString() }, jobid);
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public static void logJobInfo(JobID jobid, long submitTime, long launchTime, int restartCount)
/*      */     {
/* 2049 */       logJobInfo(jobid, submitTime, launchTime);
/*      */     }
/*      */ 
/*      */     public static void logJobInfo(JobID jobid, long submitTime, long launchTime)
/*      */     {
/* 2054 */       ArrayList writer = JobHistory.fileManager.getWriters(jobid);
/*      */ 
/* 2056 */       if (null != writer)
/* 2057 */         JobHistory.log(writer, JobHistory.RecordTypes.Job, new JobHistory.Keys[] { JobHistory.Keys.JOBID, JobHistory.Keys.SUBMIT_TIME, JobHistory.Keys.LAUNCH_TIME }, new String[] { jobid.toString(), String.valueOf(submitTime), String.valueOf(launchTime) }, jobid);
/*      */     }
/*      */   }
/*      */ 
/*      */   static class KeyValuePair
/*      */   {
/*  887 */     private Map<JobHistory.Keys, String> values = new HashMap();
/*      */ 
/*      */     public String get(JobHistory.Keys k)
/*      */     {
/*  897 */       String s = (String)this.values.get(k);
/*  898 */       return s == null ? "" : s;
/*      */     }
/*      */ 
/*      */     public int getInt(JobHistory.Keys k)
/*      */     {
/*  906 */       String s = (String)this.values.get(k);
/*  907 */       if (null != s) {
/*  908 */         return Integer.parseInt(s);
/*      */       }
/*  910 */       return 0;
/*      */     }
/*      */ 
/*      */     public long getLong(JobHistory.Keys k)
/*      */     {
/*  918 */       String s = (String)this.values.get(k);
/*  919 */       if (null != s) {
/*  920 */         return Long.parseLong(s);
/*      */       }
/*  922 */       return 0L;
/*      */     }
/*      */ 
/*      */     public void set(JobHistory.Keys k, String s)
/*      */     {
/*  930 */       this.values.put(k, s);
/*      */     }
/*      */ 
/*      */     public void set(Map<JobHistory.Keys, String> m)
/*      */     {
/*  937 */       this.values.putAll(m);
/*      */     }
/*      */ 
/*      */     public synchronized void handle(Map<JobHistory.Keys, String> values)
/*      */     {
/*  944 */       set(values);
/*      */     }
/*      */ 
/*      */     public Map<JobHistory.Keys, String> getValues()
/*      */     {
/*  950 */       return this.values;
/*      */     }
/*      */   }
/*      */ 
/*      */   static class JobHistoryLogger
/*      */   {
/*  807 */     static final Log LOG = LogFactory.getLog(JobHistoryLogger.class);
/*      */   }
/*      */ 
/*      */   static class MetaInfoManager
/*      */     implements JobHistory.Listener
/*      */   {
/*  633 */     private long version = 0L;
/*  634 */     private JobHistory.KeyValuePair pairs = new JobHistory.KeyValuePair();
/*      */ 
/*      */     public MetaInfoManager(String line) throws IOException
/*      */     {
/*  638 */       if (null != line)
/*      */       {
/*  640 */         JobHistory.parseLine(line, this, false);
/*      */       }
/*      */     }
/*      */ 
/*      */     char getLineDelim()
/*      */     {
/*  646 */       if (this.version == 0L) {
/*  647 */         return '"';
/*      */       }
/*  649 */       return '.';
/*      */     }
/*      */ 
/*      */     boolean isValueEscaped()
/*      */     {
/*  656 */       return this.version != 0L;
/*      */     }
/*      */ 
/*      */     public void handle(JobHistory.RecordTypes recType, Map<JobHistory.Keys, String> values)
/*      */       throws IOException
/*      */     {
/*  662 */       if (JobHistory.RecordTypes.Meta == recType) {
/*  663 */         this.pairs.handle(values);
/*  664 */         this.version = this.pairs.getLong(JobHistory.Keys.VERSION);
/*      */       }
/*      */     }
/*      */ 
/*      */     static void logMetaInfo(ArrayList<PrintWriter> writers)
/*      */     {
/*  674 */       if (null != writers)
/*  675 */         JobHistory.log(writers, JobHistory.RecordTypes.Meta, new JobHistory.Keys[] { JobHistory.Keys.VERSION }, new String[] { String.valueOf(1L) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static enum Values
/*      */   {
/*  489 */     SUCCESS, FAILED, KILLED, MAP, REDUCE, CLEANUP, RUNNING, PREP, SETUP;
/*      */   }
/*      */ 
/*      */   public static enum Keys
/*      */   {
/*  471 */     JOBTRACKERID, 
/*  472 */     START_TIME, FINISH_TIME, JOBID, JOBNAME, USER, JOBCONF, SUBMIT_TIME, 
/*  473 */     LAUNCH_TIME, TOTAL_MAPS, TOTAL_REDUCES, FAILED_MAPS, FAILED_REDUCES, 
/*  474 */     FINISHED_MAPS, FINISHED_REDUCES, JOB_STATUS, TASKID, HOSTNAME, TASK_TYPE, 
/*  475 */     ERROR, TASK_ATTEMPT_ID, TASK_STATUS, COPY_PHASE, SORT_PHASE, REDUCE_PHASE, 
/*  476 */     SHUFFLE_FINISHED, SORT_FINISHED, COUNTERS, SPLITS, JOB_PRIORITY, HTTP_PORT, 
/*  477 */     TRACKER_NAME, STATE_STRING, VERSION, MAP_COUNTERS, REDUCE_COUNTERS, 
/*  478 */     VIEW_JOB, MODIFY_JOB, JOB_QUEUE, FAIL_REASON, LOCALITY, AVATAAR, 
/*  479 */     WORKFLOW_ID, WORKFLOW_NAME, WORKFLOW_NODE_NAME, WORKFLOW_ADJACENCIES, 
/*  480 */     WORKFLOW_TAGS;
/*      */   }
/*      */ 
/*      */   public static enum RecordTypes
/*      */   {
/*  463 */     Jobtracker, Job, Task, MapAttempt, ReduceAttempt, Meta;
/*      */   }
/*      */ 
/*      */   private static class JobHistoryFilesManager
/*      */   {
/*  208 */     private ThreadPoolExecutor executor = null;
/*      */     private final Configuration conf;
/*      */     private final JobTracker jobTracker;
/*  213 */     private Map<JobID, FilesHolder> fileCache = new ConcurrentHashMap();
/*      */ 
/*      */     JobHistoryFilesManager(Configuration conf, JobTracker jobTracker)
/*      */       throws IOException
/*      */     {
/*  218 */       this.conf = conf;
/*  219 */       this.jobTracker = jobTracker;
/*      */     }
/*      */ 
/*      */     void start()
/*      */     {
/*  224 */       this.executor = new ThreadPoolExecutor(5, 5, 1L, TimeUnit.HOURS, new LinkedBlockingQueue());
/*      */ 
/*  228 */       this.executor.allowCoreThreadTimeOut(true);
/*      */     }
/*      */ 
/*      */     private FilesHolder getFileHolder(JobID id) {
/*  232 */       FilesHolder holder = (FilesHolder)this.fileCache.get(id);
/*  233 */       if (holder == null) {
/*  234 */         holder = new FilesHolder(null);
/*  235 */         this.fileCache.put(id, holder);
/*      */       }
/*  237 */       return holder;
/*      */     }
/*      */ 
/*      */     void addWriter(JobID id, PrintWriter writer) {
/*  241 */       FilesHolder holder = getFileHolder(id);
/*  242 */       holder.writers.add(writer);
/*      */     }
/*      */ 
/*      */     void setHistoryFile(JobID id, Path file) {
/*  246 */       FilesHolder holder = getFileHolder(id);
/*  247 */       holder.historyFilename = file;
/*      */     }
/*      */ 
/*      */     void setConfFile(JobID id, Path file) {
/*  251 */       FilesHolder holder = getFileHolder(id);
/*  252 */       holder.confFilename = file;
/*      */     }
/*      */ 
/*      */     ArrayList<PrintWriter> getWriters(JobID id) {
/*  256 */       FilesHolder holder = (FilesHolder)this.fileCache.get(id);
/*  257 */       return holder == null ? null : holder.writers;
/*      */     }
/*      */ 
/*      */     Path getHistoryFile(JobID id) {
/*  261 */       FilesHolder holder = (FilesHolder)this.fileCache.get(id);
/*  262 */       return holder == null ? null : holder.historyFilename;
/*      */     }
/*      */ 
/*      */     Path getConfFileWriters(JobID id) {
/*  266 */       FilesHolder holder = (FilesHolder)this.fileCache.get(id);
/*  267 */       return holder == null ? null : holder.confFilename;
/*      */     }
/*      */ 
/*      */     void purgeJob(JobID id) {
/*  271 */       this.fileCache.remove(id);
/*      */     }
/*      */ 
/*      */     void moveToDone(final JobID id) {
/*  275 */       final List paths = new ArrayList();
/*  276 */       final Path historyFile = JobHistory.fileManager.getHistoryFile(id);
/*  277 */       if (historyFile == null)
/*  278 */         JobHistory.LOG.info("No file for job-history with " + id + " found in cache!");
/*      */       else {
/*  280 */         paths.add(historyFile);
/*      */       }
/*      */ 
/*  283 */       Path confPath = JobHistory.fileManager.getConfFileWriters(id);
/*  284 */       if (confPath == null)
/*  285 */         JobHistory.LOG.info("No file for jobconf with " + id + " found in cache!");
/*      */       else {
/*  287 */         paths.add(confPath);
/*      */       }
/*      */ 
/*  290 */       this.executor.execute(new Runnable()
/*      */       {
/*      */         public void run() {
/*  293 */           long millisecondTime = System.currentTimeMillis();
/*      */ 
/*  295 */           Path resultDir = JobHistory.canonicalHistoryLogPath(id, millisecondTime);
/*      */           try
/*      */           {
/*  299 */             for (Path path : paths)
/*      */             {
/*  301 */               if (JobHistory.LOGDIR_FS.exists(path)) {
/*  302 */                 JobHistory.maybeMakeSubdirectory(id, millisecondTime);
/*      */ 
/*  304 */                 JobHistory.LOG.info("Moving " + path.toString() + " to " + resultDir.toString());
/*      */ 
/*  306 */                 JobHistory.DONEDIR_FS.moveFromLocalFile(path, resultDir);
/*  307 */                 JobHistory.DONEDIR_FS.setPermission(new Path(resultDir, path.getName()), new FsPermission(JobHistory.HISTORY_FILE_PERMISSION));
/*      */               }
/*      */             }
/*      */           }
/*      */           catch (Throwable e) {
/*  312 */             JobHistory.LOG.error("Unable to move history file to DONE canonical subfolder.", e);
/*      */           }
/*  314 */           String historyFileDonePath = null;
/*  315 */           if (historyFile != null) {
/*  316 */             historyFileDonePath = new Path(resultDir, historyFile.getName()).toString();
/*      */           }
/*      */ 
/*  320 */           JobHistory.jobHistoryFileMap.put(id, new JobHistory.MovedFileInfo(historyFileDonePath, millisecondTime));
/*      */ 
/*  322 */           JobHistory.JobHistoryFilesManager.this.jobTracker.historyFileCopied(id, historyFileDonePath);
/*      */ 
/*  325 */           JobHistory.fileManager.purgeJob(id);
/*      */         }
/*      */       });
/*      */     }
/*      */ 
/*      */     void removeWriter(JobID jobId, PrintWriter writer)
/*      */     {
/*  332 */       JobHistory.fileManager.getWriters(jobId).remove(writer);
/*      */     }
/*      */ 
/*      */     private static class FilesHolder
/*      */     {
/*  203 */       ArrayList<PrintWriter> writers = new ArrayList();
/*      */       Path historyFilename;
/*      */       Path confFilename;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class MovedFileInfo
/*      */   {
/*      */     private final String historyFile;
/*      */     private final long timestamp;
/*      */ 
/*      */     public MovedFileInfo(String historyFile, long timestamp)
/*      */     {
/*  178 */       this.historyFile = historyFile;
/*  179 */       this.timestamp = timestamp;
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JobHistory
 * JD-Core Version:    0.6.1
 */
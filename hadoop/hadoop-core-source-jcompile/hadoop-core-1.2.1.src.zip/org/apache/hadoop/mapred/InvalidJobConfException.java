/*    */ package org.apache.hadoop.mapred;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class InvalidJobConfException extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public InvalidJobConfException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public InvalidJobConfException(String msg)
/*    */   {
/* 37 */     super(msg);
/*    */   }
/*    */ 
/*    */   public InvalidJobConfException(String msg, Throwable t) {
/* 41 */     super(msg, t);
/*    */   }
/*    */ 
/*    */   public InvalidJobConfException(Throwable t) {
/* 45 */     super(t);
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.InvalidJobConfException
 * JD-Core Version:    0.6.1
 */
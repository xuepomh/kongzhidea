/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ class IndexRecord
/*     */ {
/*     */   long startOffset;
/*     */   long rawLength;
/*     */   long partLength;
/*     */ 
/*     */   public IndexRecord()
/*     */   {
/*     */   }
/*     */ 
/*     */   public IndexRecord(long startOffset, long rawLength, long partLength)
/*     */   {
/* 154 */     this.startOffset = startOffset;
/* 155 */     this.rawLength = rawLength;
/* 156 */     this.partLength = partLength;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.IndexRecord
 * JD-Core Version:    0.6.1
 */
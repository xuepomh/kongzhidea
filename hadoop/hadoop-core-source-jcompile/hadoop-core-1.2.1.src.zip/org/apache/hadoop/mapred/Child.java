/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.fs.FSError;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.LocalDirAllocator;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.ipc.RPC;
/*     */ import org.apache.hadoop.mapreduce.security.TokenCache;
/*     */ import org.apache.hadoop.mapreduce.security.token.JobTokenSecretManager;
/*     */ import org.apache.hadoop.mapreduce.server.tasktracker.JVMInfo;
/*     */ import org.apache.hadoop.metrics2.lib.DefaultMetricsSystem;
/*     */ import org.apache.hadoop.metrics2.source.JvmMetricsSource;
/*     */ import org.apache.hadoop.net.NetUtils;
/*     */ import org.apache.hadoop.security.Credentials;
/*     */ import org.apache.hadoop.security.SecurityUtil;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.token.Token;
/*     */ import org.apache.hadoop.util.Shell;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ import org.apache.log4j.LogManager;
/*     */ 
/*     */ class Child
/*     */ {
/*  56 */   public static final Log LOG = LogFactory.getLog(Child.class);
/*     */ 
/*  59 */   static volatile TaskAttemptID taskid = null;
/*  60 */   static volatile boolean currentJobSegmented = true;
/*     */   static volatile boolean isCleanup;
/*     */   static String cwd;
/*     */ 
/*     */   static boolean logIsSegmented(JobConf job)
/*     */   {
/*  66 */     return job.getNumTasksToExecutePerJvm() != 1;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Throwable {
/*  70 */     LOG.debug("Child starting");
/*     */ 
/*  72 */     final JobConf defaultConf = new JobConf();
/*  73 */     String host = args[0];
/*  74 */     int port = Integer.parseInt(args[1]);
/*  75 */     InetSocketAddress address = NetUtils.makeSocketAddr(host, port);
/*  76 */     TaskAttemptID firstTaskid = TaskAttemptID.forName(args[2]);
/*  77 */     final String logLocation = args[3];
/*  78 */     int SLEEP_LONGER_COUNT = 5;
/*  79 */     int jvmIdInt = Integer.parseInt(args[4]);
/*  80 */     JVMId jvmId = new JVMId(firstTaskid.getJobID(), firstTaskid.isMap(), jvmIdInt);
/*  81 */     String prefix = firstTaskid.isMap() ? "MapTask" : "ReduceTask";
/*     */ 
/*  83 */     cwd = (String)System.getenv().get("HADOOP_WORK_DIR");
/*  84 */     if (cwd == null) {
/*  85 */       throw new IOException("Environment variable HADOOP_WORK_DIR is not set");
/*     */     }
/*     */ 
/*  90 */     String jobTokenFile = (String)System.getenv().get("HADOOP_TOKEN_FILE_LOCATION");
/*     */ 
/*  92 */     Credentials credentials = TokenCache.loadTokens(jobTokenFile, defaultConf);
/*     */ 
/*  94 */     LOG.debug("loading token. # keys =" + credentials.numberOfSecretKeys() + "; from file=" + jobTokenFile);
/*     */ 
/*  97 */     Token jt = TokenCache.getJobToken(credentials);
/*  98 */     SecurityUtil.setTokenService(jt, address);
/*  99 */     UserGroupInformation current = UserGroupInformation.getCurrentUser();
/* 100 */     current.addToken(jt);
/*     */ 
/* 102 */     UserGroupInformation taskOwner = UserGroupInformation.createRemoteUser(firstTaskid.getJobID().toString());
/*     */ 
/* 104 */     taskOwner.addToken(jt);
/*     */ 
/* 107 */     defaultConf.setCredentials(credentials);
/*     */ 
/* 109 */     final TaskUmbilicalProtocol umbilical = (TaskUmbilicalProtocol)taskOwner.doAs(new PrivilegedExceptionAction()
/*     */     {
/*     */       public TaskUmbilicalProtocol run() throws Exception
/*     */       {
/* 113 */         return (TaskUmbilicalProtocol)RPC.getProxy(TaskUmbilicalProtocol.class, 19L, this.val$address, defaultConf);
/*     */       }
/*     */     });
/* 120 */     int numTasksToExecute = -1;
/* 121 */     int numTasksExecuted = 0;
/* 122 */     Runtime.getRuntime().addShutdownHook(new Thread() {
/*     */       public void run() {
/*     */         try {
/* 125 */           if (Child.taskid != null)
/* 126 */             TaskLog.syncLogs(this.val$logLocation, Child.taskid, Child.isCleanup, Child.currentJobSegmented);
/*     */         }
/*     */         catch (Throwable throwable)
/*     */         {
/*     */         }
/*     */       }
/*     */     });
/* 133 */     Thread t = new Thread()
/*     */     {
/*     */       public void run()
/*     */       {
/*     */         while (true)
/*     */           try {
/* 139 */             Thread.sleep(5000L);
/* 140 */             if (Child.taskid != null)
/* 141 */               TaskLog.syncLogs(this.val$logLocation, Child.taskid, Child.isCleanup, Child.currentJobSegmented);
/*     */           }
/*     */           catch (InterruptedException ie) {
/*     */           }
/*     */           catch (IOException iee) {
/* 146 */             Child.LOG.error("Error in syncLogs: " + iee);
/* 147 */             System.exit(-1);
/*     */           }
/*     */       }
/*     */     };
/* 152 */     t.setName("Thread for syncLogs");
/* 153 */     t.setDaemon(true);
/* 154 */     t.start();
/*     */ 
/* 156 */     String pid = "";
/* 157 */     if (!Shell.WINDOWS) {
/* 158 */       pid = (String)System.getenv().get("JVM_PID");
/*     */     }
/* 160 */     JvmContext context = new JvmContext(jvmId, pid);
/* 161 */     int idleLoopCount = 0;
/* 162 */     Task task = null;
/*     */ 
/* 164 */     UserGroupInformation childUGI = null;
/*     */ 
/* 166 */     JvmContext jvmContext = context;
/*     */     try {
/*     */       while (true) {
/* 169 */         taskid = null;
/* 170 */         currentJobSegmented = true;
/*     */ 
/* 172 */         JvmTask myTask = umbilical.getTask(context);
/* 173 */         if (myTask.shouldDie()) {
/*     */           break;
/*     */         }
/* 176 */         if (myTask.getTask() == null) {
/* 177 */           taskid = null;
/* 178 */           currentJobSegmented = true;
/*     */ 
/* 180 */           idleLoopCount++; if (idleLoopCount >= 5)
/*     */           {
/* 183 */             Thread.sleep(1500L);
/*     */           }
/* 185 */           else Thread.sleep(500L);
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 190 */           idleLoopCount = 0;
/* 191 */           task = myTask.getTask();
/* 192 */           task.setJvmContext(jvmContext);
/* 193 */           taskid = task.getTaskID();
/*     */ 
/* 196 */           JobConf job = new JobConf(task.getJobFile());
/* 197 */           currentJobSegmented = logIsSegmented(job);
/*     */ 
/* 199 */           isCleanup = task.isTaskCleanupTask();
/*     */ 
/* 201 */           FileSystem.clearStatistics();
/*     */ 
/* 204 */           job.setCredentials(defaultConf.getCredentials());
/*     */ 
/* 209 */           job.setBoolean("fs.file.impl.disable.cache", false);
/*     */ 
/* 212 */           task.setJobTokenSecret(JobTokenSecretManager.createSecretKey(jt.getPassword()));
/*     */ 
/* 217 */           TaskRunner.setupChildMapredLocalDirs(task, job);
/*     */ 
/* 220 */           localizeTask(task, job, logLocation);
/*     */ 
/* 225 */           TaskRunner.setupWorkDir(job, new File(cwd));
/*     */ 
/* 229 */           TaskLog.syncLogs(logLocation, taskid, isCleanup, logIsSegmented(job));
/*     */ 
/* 232 */           numTasksToExecute = job.getNumTasksToExecutePerJvm();
/* 233 */           assert (numTasksToExecute != 0);
/*     */ 
/* 235 */           task.setConf(job);
/*     */ 
/* 238 */           initMetrics(prefix, jvmId.toString(), job.getSessionId());
/*     */ 
/* 240 */           LOG.debug("Creating remote user to execute task: " + job.get("user.name"));
/* 241 */           childUGI = UserGroupInformation.createRemoteUser(job.get("user.name"));
/*     */ 
/* 243 */           for (Token token : UserGroupInformation.getCurrentUser().getTokens()) {
/* 244 */             childUGI.addToken(token);
/*     */           }
/*     */ 
/* 248 */           final Task taskFinal = task;
/* 249 */           childUGI.doAs(new PrivilegedExceptionAction()
/*     */           {
/*     */             public Object run() throws Exception
/*     */             {
/*     */               try {
/* 254 */                 FileSystem.get(this.val$job).setWorkingDirectory(this.val$job.getWorkingDirectory());
/* 255 */                 taskFinal.run(this.val$job, umbilical);
/*     */               }
/*     */               finally
/*     */               {
/*     */                 TaskLogsTruncater trunc;
/* 257 */                 TaskLog.syncLogs(logLocation, Child.taskid, Child.isCleanup, Child.logIsSegmented(this.val$job));
/*     */ 
/* 259 */                 TaskLogsTruncater trunc = new TaskLogsTruncater(defaultConf);
/* 260 */                 trunc.truncateLogs(new JVMInfo(TaskLog.getAttemptDir(taskFinal.getTaskID(), taskFinal.isTaskCleanupTask()), Arrays.asList(new Task[] { taskFinal })));
/*     */               }
/*     */ 
/* 265 */               return null;
/*     */             }
/*     */           });
/* 268 */           if (numTasksToExecute > 0) { numTasksExecuted++; if (numTasksExecuted == numTasksToExecute) break; }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (FSError e) {
/* 273 */       LOG.fatal("FSError from child", e);
/* 274 */       umbilical.fsError(taskid, e.getMessage(), jvmContext);
/*     */     } catch (Exception exception) {
/* 276 */       LOG.warn("Error running child", exception);
/*     */       try {
/* 278 */         if (task != null)
/*     */         {
/* 280 */           if (childUGI == null) {
/* 281 */             task.taskCleanup(umbilical);
/*     */           } else {
/* 283 */             Task taskFinal = task;
/* 284 */             childUGI.doAs(new PrivilegedExceptionAction()
/*     */             {
/*     */               public Object run() throws Exception {
/* 287 */                 this.val$taskFinal.taskCleanup(umbilical);
/* 288 */                 return null;
/*     */               } } );
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 294 */         LOG.info("Error cleaning up", e);
/*     */       }
/*     */ 
/* 297 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 298 */       exception.printStackTrace(new PrintStream(baos));
/* 299 */       if (taskid != null)
/* 300 */         umbilical.reportDiagnosticInfo(taskid, baos.toString(), jvmContext);
/*     */     }
/*     */     catch (Throwable throwable) {
/* 303 */       LOG.fatal("Error running child : " + StringUtils.stringifyException(throwable));
/*     */ 
/* 305 */       if (taskid != null) {
/* 306 */         Throwable tCause = throwable.getCause();
/* 307 */         String cause = tCause == null ? throwable.getMessage() : StringUtils.stringifyException(tCause);
/*     */ 
/* 310 */         umbilical.fatalError(taskid, cause, jvmContext);
/*     */       }
/*     */     } finally {
/* 313 */       RPC.stopProxy(umbilical);
/* 314 */       shutdownMetrics();
/*     */ 
/* 318 */       LogManager.shutdown();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void initMetrics(String prefix, String procName, String sessionId)
/*     */   {
/* 324 */     DefaultMetricsSystem.initialize(prefix);
/* 325 */     JvmMetricsSource.create(procName, sessionId);
/*     */   }
/*     */ 
/*     */   private static void shutdownMetrics() {
/* 329 */     DefaultMetricsSystem.INSTANCE.shutdown();
/*     */   }
/*     */ 
/*     */   static void localizeTask(Task task, JobConf jobConf, String logLocation)
/*     */     throws IOException
/*     */   {
/* 336 */     task.localizeConfiguration(jobConf);
/*     */ 
/* 339 */     LocalDirAllocator lDirAlloc = new LocalDirAllocator("mapred.local.dir");
/*     */ 
/* 341 */     Path localTaskFile = lDirAlloc.getLocalPathForWrite("job.xml", jobConf);
/*     */ 
/* 343 */     JobLocalizer.writeLocalJobFile(localTaskFile, jobConf);
/* 344 */     task.setJobFile(localTaskFile.toString());
/* 345 */     task.setConf(jobConf);
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.Child
 * JD-Core Version:    0.6.1
 */
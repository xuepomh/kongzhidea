/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.LocalDirAllocator;
/*     */ import org.apache.hadoop.fs.LocalFileSystem;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.mapreduce.split.JobSplit.TaskSplitIndex;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ 
/*     */ public class IsolationRunner
/*     */ {
/*  47 */   private static final Log LOG = LogFactory.getLog(IsolationRunner.class.getName());
/*     */ 
/*     */   private ClassLoader makeClassLoader(JobConf conf, File workDir)
/*     */     throws IOException
/*     */   {
/* 138 */     List classPaths = new ArrayList();
/*     */ 
/* 140 */     String jar = conf.getJar();
/* 141 */     if (jar != null) {
/* 142 */       TaskRunner.appendJobJarClasspaths(conf.getJar(), classPaths);
/*     */     }
/*     */ 
/* 145 */     classPaths.add(workDir.toString());
/*     */ 
/* 149 */     URL[] urls = new URL[classPaths.size()];
/* 150 */     for (int i = 0; i < classPaths.size(); i++) {
/* 151 */       urls[i] = new File((String)classPaths.get(i)).toURL();
/*     */     }
/* 153 */     return new URLClassLoader(urls);
/*     */   }
/*     */ 
/*     */   boolean run(String[] args)
/*     */     throws ClassNotFoundException, IOException, InterruptedException
/*     */   {
/* 161 */     if (args.length < 1) {
/* 162 */       System.out.println("Usage: IsolationRunner <path>/job.xml <optional-user-name>");
/*     */ 
/* 164 */       return false;
/*     */     }
/* 166 */     File jobFilename = new File(args[0]);
/* 167 */     if ((!jobFilename.exists()) || (!jobFilename.isFile())) {
/* 168 */       System.out.println(jobFilename + " is not a valid job file.");
/* 169 */       return false;
/*     */     }
/*     */     String user;
/*     */     String user;
/* 172 */     if (args.length > 1)
/* 173 */       user = args[1];
/*     */     else {
/* 175 */       user = UserGroupInformation.getCurrentUser().getShortUserName();
/*     */     }
/* 177 */     JobConf conf = new JobConf(new Path(jobFilename.toString()));
/* 178 */     conf.setUser(user);
/* 179 */     TaskAttemptID taskId = TaskAttemptID.forName(conf.get("mapred.task.id"));
/* 180 */     if (taskId == null) {
/* 181 */       System.out.println("mapred.task.id not found in configuration; job.xml is not a task config");
/*     */     }
/*     */ 
/* 184 */     boolean isMap = conf.getBoolean("mapred.task.is.map", true);
/* 185 */     if (!isMap) {
/* 186 */       System.out.println("Only map tasks are supported.");
/* 187 */       return false;
/*     */     }
/* 189 */     int partition = conf.getInt("mapred.task.partition", 0);
/*     */ 
/* 192 */     FileSystem local = FileSystem.getLocal(conf);
/* 193 */     LocalDirAllocator lDirAlloc = new LocalDirAllocator("mapred.local.dir");
/*     */ 
/* 195 */     boolean workDirExists = lDirAlloc.ifExists("work", conf);
/*     */     Path workDirName;
/*     */     Path workDirName;
/* 196 */     if (workDirExists)
/* 197 */       workDirName = TaskRunner.formWorkDir(lDirAlloc, conf);
/*     */     else {
/* 199 */       workDirName = lDirAlloc.getLocalPathForWrite("work", conf);
/*     */     }
/*     */ 
/* 203 */     local.setWorkingDirectory(new Path(workDirName.toString()));
/*     */ 
/* 205 */     FileSystem.get(conf).setWorkingDirectory(conf.getWorkingDirectory());
/*     */ 
/* 208 */     ClassLoader classLoader = makeClassLoader(conf, new File(workDirName.toString()));
/*     */ 
/* 210 */     Thread.currentThread().setContextClassLoader(classLoader);
/* 211 */     conf.setClassLoader(classLoader);
/*     */ 
/* 216 */     Path localMetaSplit = new LocalDirAllocator("mapred.local.dir").getLocalPathToRead(TaskTracker.getLocalSplitFile(conf.getUser(), taskId.getJobID().toString(), taskId.toString()), conf);
/*     */ 
/* 220 */     DataInputStream splitFile = FileSystem.getLocal(conf).open(localMetaSplit);
/* 221 */     JobSplit.TaskSplitIndex splitIndex = new JobSplit.TaskSplitIndex();
/* 222 */     splitIndex.readFields(splitFile);
/* 223 */     splitFile.close();
/* 224 */     Task task = new MapTask(jobFilename.toString(), taskId, partition, splitIndex, 1);
/*     */ 
/* 226 */     task.setConf(conf);
/* 227 */     task.run(conf, new FakeUmbilical(null));
/* 228 */     return true;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws ClassNotFoundException, IOException, InterruptedException
/*     */   {
/* 238 */     if (!new IsolationRunner().run(args))
/* 239 */       System.exit(1);
/*     */   }
/*     */ 
/*     */   private static class FakeUmbilical
/*     */     implements TaskUmbilicalProtocol
/*     */   {
/*     */     public long getProtocolVersion(String protocol, long clientVersion)
/*     */     {
/*  53 */       return 19L;
/*     */     }
/*     */ 
/*     */     public void done(TaskAttemptID taskid, JvmContext jvmContext) throws IOException
/*     */     {
/*  58 */       IsolationRunner.LOG.info("Task " + taskid + " reporting done.");
/*     */     }
/*     */ 
/*     */     public void fsError(TaskAttemptID taskId, String message, JvmContext jvmContext) throws IOException
/*     */     {
/*  63 */       IsolationRunner.LOG.info("Task " + taskId + " reporting file system error: " + message);
/*     */     }
/*     */ 
/*     */     public void shuffleError(TaskAttemptID taskId, String message, JvmContext jvmContext) throws IOException
/*     */     {
/*  68 */       IsolationRunner.LOG.info("Task " + taskId + " reporting shuffle error: " + message);
/*     */     }
/*     */ 
/*     */     public void fatalError(TaskAttemptID taskId, String msg, JvmContext jvmContext) throws IOException
/*     */     {
/*  73 */       IsolationRunner.LOG.info("Task " + taskId + " reporting fatal error: " + msg);
/*     */     }
/*     */ 
/*     */     public JvmTask getTask(JvmContext context) throws IOException {
/*  77 */       return null;
/*     */     }
/*     */ 
/*     */     public boolean ping(TaskAttemptID taskid, JvmContext jvmContext) throws IOException {
/*  81 */       return true;
/*     */     }
/*     */ 
/*     */     public void commitPending(TaskAttemptID taskId, TaskStatus taskStatus, JvmContext jvmContext) throws IOException, InterruptedException
/*     */     {
/*  86 */       statusUpdate(taskId, taskStatus, jvmContext);
/*     */     }
/*     */ 
/*     */     public boolean canCommit(TaskAttemptID taskid, JvmContext jvmContext) throws IOException
/*     */     {
/*  91 */       return true;
/*     */     }
/*     */ 
/*     */     public boolean statusUpdate(TaskAttemptID taskId, TaskStatus taskStatus, JvmContext context) throws IOException, InterruptedException
/*     */     {
/*  96 */       StringBuffer buf = new StringBuffer("Task ");
/*  97 */       buf.append(taskId);
/*  98 */       buf.append(" making progress to ");
/*  99 */       buf.append(taskStatus.getProgress());
/* 100 */       String state = taskStatus.getStateString();
/* 101 */       if (state != null) {
/* 102 */         buf.append(" and state of ");
/* 103 */         buf.append(state);
/*     */       }
/* 105 */       IsolationRunner.LOG.info(buf.toString());
/*     */ 
/* 108 */       return true;
/*     */     }
/*     */ 
/*     */     public void reportDiagnosticInfo(TaskAttemptID taskid, String trace, JvmContext jvmContext) throws IOException
/*     */     {
/* 113 */       IsolationRunner.LOG.info("Task " + taskid + " has problem " + trace);
/*     */     }
/*     */ 
/*     */     public MapTaskCompletionEventsUpdate getMapCompletionEvents(JobID jobId, int fromEventId, int maxLocs, TaskAttemptID id, JvmContext jvmContext)
/*     */       throws IOException
/*     */     {
/* 119 */       return new MapTaskCompletionEventsUpdate(TaskCompletionEvent.EMPTY_ARRAY, false);
/*     */     }
/*     */ 
/*     */     public void reportNextRecordRange(TaskAttemptID taskid, SortedRanges.Range range, JvmContext jvmContext)
/*     */       throws IOException
/*     */     {
/* 125 */       IsolationRunner.LOG.info("Task " + taskid + " reportedNextRecordRange " + range);
/*     */     }
/*     */ 
/*     */     public void updatePrivateDistributedCacheSizes(org.apache.hadoop.mapreduce.JobID jobId, long[] sizes)
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.IsolationRunner
 * JD-Core Version:    0.6.1
 */
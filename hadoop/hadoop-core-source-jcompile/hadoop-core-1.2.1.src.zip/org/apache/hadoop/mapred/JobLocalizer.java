/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang.ArrayUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.filecache.DistributedCache;
/*     */ import org.apache.hadoop.filecache.TrackerDistributedCacheManager;
/*     */ import org.apache.hadoop.fs.FileStatus;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.FileUtil;
/*     */ import org.apache.hadoop.fs.LocalDirAllocator;
/*     */ import org.apache.hadoop.fs.LocalFileSystem;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.fs.permission.FsPermission;
/*     */ import org.apache.hadoop.io.IOUtils;
/*     */ import org.apache.hadoop.ipc.RPC;
/*     */ import org.apache.hadoop.mapreduce.JobID;
/*     */ import org.apache.hadoop.mapreduce.security.TokenCache;
/*     */ import org.apache.hadoop.security.Credentials;
/*     */ import org.apache.hadoop.security.SecurityUtil;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.token.Token;
/*     */ import org.apache.hadoop.util.RunJar;
/*     */ 
/*     */ public class JobLocalizer
/*     */ {
/*  71 */   static final Log LOG = LogFactory.getLog(JobLocalizer.class);
/*     */ 
/*  73 */   private static final FsPermission urwx = FsPermission.createImmutable((short)448);
/*     */ 
/*  75 */   private static final FsPermission urwx_gx = FsPermission.createImmutable((short)456);
/*     */ 
/*  77 */   private static final FsPermission urw_gr = FsPermission.createImmutable((short)416);
/*     */   private final String user;
/*     */   private final String jobid;
/*     */   private final FileSystem lfs;
/*     */   private final List<Path> localDirs;
/*     */   private final LocalDirAllocator lDirAlloc;
/*     */   protected final JobConf ttConf;
/*     */   private final String JOBDIR;
/*     */   private final String DISTDIR;
/*     */   private final String WORKDIR;
/*     */   private final String JARDST;
/*     */   private final String JOBCONF;
/*     */   private final String JOBTOKEN;
/*     */   protected static final String JOB_LOCAL_CTXT = "mapred.job.local.dir";
/* 289 */   private static final FsPermission privateCachePerms = FsPermission.createImmutable((short)493);
/*     */ 
/*     */   public JobLocalizer(JobConf ttConf, String user, String jobid)
/*     */     throws IOException
/*     */   {
/*  97 */     this(ttConf, user, jobid, ttConf.getStrings("mapred.local.dir"));
/*     */   }
/*     */ 
/*     */   public JobLocalizer(JobConf ttConf, String user, String jobid, String[] localDirs)
/*     */     throws IOException
/*     */   {
/* 103 */     if (null == user) {
/* 104 */       throw new IOException("Cannot initialize for null user");
/*     */     }
/* 106 */     this.user = user;
/* 107 */     if (null == jobid) {
/* 108 */       throw new IOException("Cannot initialize for null jobid");
/*     */     }
/* 110 */     this.jobid = jobid;
/* 111 */     this.ttConf = new JobConf(ttConf);
/* 112 */     this.lfs = FileSystem.getLocal(this.ttConf).getRaw();
/* 113 */     this.localDirs = createPaths(user, localDirs);
/* 114 */     this.ttConf.setStrings("mapred.job.local.dir", localDirs);
/* 115 */     Collections.shuffle(this.localDirs);
/* 116 */     this.lDirAlloc = new LocalDirAllocator("mapred.job.local.dir");
/* 117 */     this.JOBDIR = ("jobcache/" + jobid);
/* 118 */     this.DISTDIR = (this.JOBDIR + "/" + "distcache");
/* 119 */     this.WORKDIR = (this.JOBDIR + "/work");
/* 120 */     this.JARDST = (this.JOBDIR + "/" + "jars" + "/job.jar");
/* 121 */     this.JOBCONF = (this.JOBDIR + "/" + "job.xml");
/* 122 */     this.JOBTOKEN = (this.JOBDIR + "/" + "jobToken");
/*     */   }
/*     */ 
/*     */   private static List<Path> createPaths(String user, String[] str) throws IOException
/*     */   {
/* 127 */     if ((null == str) || (0 == str.length)) {
/* 128 */       throw new IOException("mapred.local.dir contains no entries");
/*     */     }
/* 130 */     List ret = new ArrayList(str.length);
/* 131 */     for (int i = 0; i < str.length; i++) {
/* 132 */       Path p = new Path(str[i], TaskTracker.getUserDir(user));
/* 133 */       ret.add(p);
/* 134 */       str[i] = p.toString();
/*     */     }
/* 136 */     return ret;
/*     */   }
/*     */ 
/*     */   public void createLocalDirs() throws IOException {
/* 140 */     boolean userDirStatus = false;
/*     */ 
/* 142 */     for (Path localDir : this.localDirs)
/*     */     {
/* 144 */       if (!this.lfs.mkdirs(localDir, urwx)) {
/* 145 */         LOG.warn("Unable to create the user directory : " + localDir);
/*     */       }
/*     */       else
/* 148 */         userDirStatus = true;
/*     */     }
/* 150 */     if (!userDirStatus)
/* 151 */       throw new IOException("Not able to initialize user directories in any of the configured local directories for user " + this.user);
/*     */   }
/*     */ 
/*     */   public void createUserDirs()
/*     */     throws IOException
/*     */   {
/* 166 */     LOG.info("Initializing user " + this.user + " on this TT.");
/*     */ 
/* 168 */     boolean jobCacheDirStatus = false;
/* 169 */     boolean distributedCacheDirStatus = false;
/*     */ 
/* 172 */     for (Path localDir : this.localDirs)
/*     */     {
/* 174 */       Path jobDir = new Path(localDir, "jobcache");
/*     */ 
/* 176 */       if (!this.lfs.mkdirs(jobDir, urwx))
/* 177 */         LOG.warn("Unable to create job cache directory : " + jobDir);
/*     */       else {
/* 179 */         jobCacheDirStatus = true;
/*     */       }
/*     */ 
/* 182 */       Path distDir = new Path(localDir, "distcache");
/*     */ 
/* 184 */       if (!this.lfs.mkdirs(distDir, urwx))
/* 185 */         LOG.warn("Unable to create distributed-cache directory : " + distDir);
/*     */       else {
/* 187 */         distributedCacheDirStatus = true;
/*     */       }
/*     */     }
/* 190 */     if (!jobCacheDirStatus) {
/* 191 */       throw new IOException("Not able to initialize job-cache directories in any of the configured local directories for user " + this.user);
/*     */     }
/*     */ 
/* 194 */     if (!distributedCacheDirStatus)
/* 195 */       throw new IOException("Not able to initialize distributed-cache directories in any of the configured local directories for user " + this.user);
/*     */   }
/*     */ 
/*     */   public void createJobDirs()
/*     */     throws IOException
/*     */   {
/* 212 */     boolean initJobDirStatus = false;
/* 213 */     for (Path localDir : this.localDirs) {
/* 214 */       Path fullJobDir = new Path(localDir, this.JOBDIR);
/* 215 */       if (this.lfs.exists(fullJobDir))
/*     */       {
/* 219 */         this.lfs.delete(fullJobDir, true);
/*     */       }
/*     */ 
/* 222 */       if (!this.lfs.mkdirs(fullJobDir, urwx))
/* 223 */         LOG.warn("Not able to create job directory " + fullJobDir.toString());
/*     */       else {
/* 225 */         initJobDirStatus = true;
/*     */       }
/*     */     }
/* 228 */     if (!initJobDirStatus)
/* 229 */       throw new IOException("Not able to initialize job directories in any of the configured local directories for job " + this.jobid.toString());
/*     */   }
/*     */ 
/*     */   public void initializeJobLogDir()
/*     */     throws IOException
/*     */   {
/* 239 */     Path jobUserLogDir = new Path(TaskLog.getJobDir(this.jobid).toURI().toString());
/* 240 */     if (!this.lfs.mkdirs(jobUserLogDir, urwx_gx))
/* 241 */       throw new IOException("Could not create job user log directory: " + jobUserLogDir);
/*     */   }
/*     */ 
/*     */   private void localizeJobJarFile(JobConf localJobConf)
/*     */     throws IOException
/*     */   {
/* 255 */     String jarFile = localJobConf.getJar();
/* 256 */     FileStatus status = null;
/* 257 */     long jarFileSize = -1L;
/* 258 */     if (jarFile != null) {
/* 259 */       Path jarFilePath = new Path(jarFile);
/* 260 */       FileSystem userFs = jarFilePath.getFileSystem(localJobConf);
/*     */       try {
/* 262 */         status = userFs.getFileStatus(jarFilePath);
/* 263 */         jarFileSize = status.getLen();
/*     */       } catch (FileNotFoundException fe) {
/* 265 */         jarFileSize = -1L;
/*     */       }
/*     */ 
/* 269 */       Path localJarFile = this.lDirAlloc.getLocalPathForWrite(this.JARDST, 5L * jarFileSize, this.ttConf);
/*     */ 
/* 273 */       userFs.copyToLocalFile(jarFilePath, localJarFile);
/* 274 */       localJobConf.setJar(localJarFile.toString());
/*     */ 
/* 277 */       RunJar.unJar(new File(localJarFile.toString()), new File(localJarFile.getParent().toString()));
/*     */ 
/* 279 */       FileUtil.chmod(localJarFile.getParent().toString(), "ugo+rx", true);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static long[] downloadPrivateCacheObjects(Configuration conf, URI[] sources, Path[] dests, long[] times, boolean[] isPublic, boolean isArchive)
/*     */     throws IOException
/*     */   {
/* 310 */     if ((null == sources) && (null == dests) && (null == times) && (null == isPublic)) {
/* 311 */       return null;
/*     */     }
/* 313 */     if ((sources.length != dests.length) || (sources.length != times.length) || (sources.length != isPublic.length))
/*     */     {
/* 316 */       throw new IOException("Distributed cache entry arrays have different lengths: " + sources.length + ", " + dests.length + ", " + times.length + ", " + isPublic.length);
/*     */     }
/*     */ 
/* 320 */     long[] result = new long[sources.length];
/* 321 */     for (int i = 0; i < sources.length; i++)
/*     */     {
/* 324 */       if (isPublic[i] == 0) {
/* 325 */         result[i] = TrackerDistributedCacheManager.downloadCacheObject(conf, sources[i], dests[i], times[i], isArchive, privateCachePerms);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 333 */     return result;
/*     */   }
/*     */ 
/*     */   public static long[] downloadPrivateCache(Configuration conf)
/*     */     throws IOException
/*     */   {
/* 343 */     long[] fileSizes = downloadPrivateCacheObjects(conf, DistributedCache.getCacheFiles(conf), DistributedCache.getLocalCacheFiles(conf), DistributedCache.getFileTimestamps(conf), TrackerDistributedCacheManager.getFileVisibilities(conf), false);
/*     */ 
/* 351 */     long[] archiveSizes = downloadPrivateCacheObjects(conf, DistributedCache.getCacheArchives(conf), DistributedCache.getLocalCacheArchives(conf), DistributedCache.getArchiveTimestamps(conf), TrackerDistributedCacheManager.getArchiveVisibilities(conf), true);
/*     */ 
/* 361 */     return ArrayUtils.addAll(fileSizes, archiveSizes);
/*     */   }
/*     */ 
/*     */   public void localizeJobFiles(JobID jobid, JobConf jConf, Path localJobTokenFile, TaskUmbilicalProtocol taskTracker)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 367 */     localizeJobFiles(jobid, jConf, this.lDirAlloc.getLocalPathForWrite(this.JOBCONF, this.ttConf), localJobTokenFile, taskTracker);
/*     */   }
/*     */ 
/*     */   public void localizeJobFiles(final JobID jobid, JobConf jConf, Path localJobFile, Path localJobTokenFile, final TaskUmbilicalProtocol taskTracker)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 377 */     localizeJobJarFile(jConf);
/*     */ 
/* 379 */     jConf.set("mapred.job.local.dir", this.ttConf.get("mapred.job.local.dir"));
/*     */ 
/* 382 */     jConf.set("mapreduce.job.jobTokenFile", localJobTokenFile.toString());
/* 383 */     jConf.set("mapred.local.dir", this.ttConf.get("mapred.local.dir"));
/*     */ 
/* 385 */     TaskTracker.resetNumTasksPerJvm(jConf);
/*     */ 
/* 388 */     final long[] sizes = downloadPrivateCache(jConf);
/* 389 */     if (sizes != null)
/*     */     {
/* 394 */       UserGroupInformation ugi = UserGroupInformation.createRemoteUser(jobid.toString());
/*     */ 
/* 396 */       ugi.doAs(new PrivilegedExceptionAction() {
/*     */         public Object run() throws IOException {
/* 398 */           taskTracker.updatePrivateDistributedCacheSizes(jobid, sizes);
/* 399 */           return null;
/*     */         }
/*     */ 
/*     */       });
/*     */     }
/*     */ 
/* 407 */     writeJobACLs(jConf, new Path(TaskLog.getJobDir(jobid).toURI().toString()));
/*     */ 
/* 410 */     writeLocalJobFile(localJobFile, jConf);
/*     */   }
/*     */ 
/*     */   private void writeJobACLs(JobConf conf, Path logDir)
/*     */     throws IOException
/*     */   {
/* 425 */     JobConf aclConf = new JobConf(false);
/*     */ 
/* 428 */     String jobViewACL = conf.get("mapreduce.job.acl-view-job", " ");
/* 429 */     aclConf.set("mapreduce.job.acl-view-job", jobViewACL);
/*     */ 
/* 432 */     String queue = conf.getQueueName();
/* 433 */     aclConf.setQueueName(queue);
/*     */ 
/* 436 */     String qACLName = QueueManager.toFullPropertyName(queue, QueueManager.QueueACL.ADMINISTER_JOBS.getAclName());
/*     */ 
/* 438 */     String queueAdminsACL = conf.get(qACLName, " ");
/* 439 */     aclConf.set(qACLName, queueAdminsACL);
/*     */ 
/* 442 */     aclConf.set("user.name", this.user);
/*     */ 
/* 444 */     OutputStream out = null;
/* 445 */     Path aclFile = new Path(logDir, TaskTracker.jobACLsFile);
/*     */     try {
/* 447 */       out = this.lfs.create(aclFile);
/* 448 */       aclConf.writeXml(out);
/*     */     } finally {
/* 450 */       IOUtils.cleanup(LOG, new Closeable[] { out });
/*     */     }
/* 452 */     this.lfs.setPermission(aclFile, urw_gr);
/*     */   }
/*     */ 
/*     */   public void createWorkDir(JobConf jConf) throws IOException
/*     */   {
/* 457 */     Path workDir = this.lDirAlloc.getLocalPathForWrite(this.WORKDIR, this.ttConf);
/* 458 */     if (!this.lfs.mkdirs(workDir)) {
/* 459 */       throw new IOException("Mkdirs failed to create " + workDir.toString());
/*     */     }
/*     */ 
/* 462 */     jConf.set("job.local.dir", workDir.toUri().getPath());
/*     */   }
/*     */ 
/*     */   public Path findCredentials() throws IOException {
/* 466 */     return this.lDirAlloc.getLocalPathToRead(this.JOBTOKEN, this.ttConf);
/*     */   }
/*     */ 
/*     */   public int runSetup(String user, String jobid, Path localJobTokenFile, TaskUmbilicalProtocol taskTracker)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 479 */     Path localJobFile = this.lDirAlloc.getLocalPathToRead(this.JOBCONF, this.ttConf);
/* 480 */     JobConf cfgJob = new JobConf(localJobFile);
/* 481 */     createWorkDir(cfgJob);
/* 482 */     localizeJobFiles(JobID.forName(jobid), cfgJob, localJobFile, localJobTokenFile, taskTracker);
/*     */ 
/* 486 */     return 0;
/*     */   }
/*     */ 
/*     */   public static void main(String[] argv)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 498 */     final String user = argv[0];
/* 499 */     final String jobid = argv[1];
/* 500 */     InetSocketAddress ttAddr = new InetSocketAddress(argv[2], Integer.parseInt(argv[3]));
/*     */ 
/* 502 */     String uid = UserGroupInformation.getCurrentUser().getShortUserName();
/* 503 */     if (!user.equals(uid)) {
/* 504 */       LOG.warn("Localization running as " + uid + " not " + user);
/*     */     }
/*     */ 
/* 508 */     final JobConf conf = new JobConf();
/* 509 */     JobLocalizer localizer = new JobLocalizer(conf, user, jobid);
/*     */ 
/* 511 */     final Path jobTokenFile = localizer.findCredentials();
/* 512 */     Credentials creds = TokenCache.loadTokens(jobTokenFile.toUri().toString(), conf);
/*     */ 
/* 514 */     LOG.debug("Loaded tokens from " + jobTokenFile);
/* 515 */     UserGroupInformation ugi = UserGroupInformation.createRemoteUser(user);
/* 516 */     for (Token token : creds.getAllTokens()) {
/* 517 */       ugi.addToken(token);
/*     */     }
/*     */ 
/* 520 */     UserGroupInformation ugiJob = UserGroupInformation.createRemoteUser(jobid);
/* 521 */     Token jt = TokenCache.getJobToken(creds);
/* 522 */     SecurityUtil.setTokenService(jt, ttAddr);
/* 523 */     ugiJob.addToken(jt);
/*     */ 
/* 525 */     final TaskUmbilicalProtocol taskTracker = (TaskUmbilicalProtocol)ugiJob.doAs(new PrivilegedExceptionAction()
/*     */     {
/*     */       public TaskUmbilicalProtocol run() throws IOException {
/* 528 */         TaskUmbilicalProtocol taskTracker = (TaskUmbilicalProtocol)RPC.getProxy(TaskUmbilicalProtocol.class, 19L, this.val$ttAddr, conf);
/*     */ 
/* 532 */         return taskTracker;
/*     */       }
/*     */     });
/* 535 */     System.exit(((Integer)ugi.doAs(new PrivilegedExceptionAction()
/*     */     {
/*     */       public Integer run() {
/*     */         try {
/* 539 */           return Integer.valueOf(this.val$localizer.runSetup(user, jobid, jobTokenFile, taskTracker));
/*     */         } catch (Throwable e) {
/* 541 */           e.printStackTrace(System.out);
/* 542 */         }return Integer.valueOf(-1);
/*     */       }
/*     */     })).intValue());
/*     */   }
/*     */ 
/*     */   public static void writeLocalJobFile(Path jobFile, JobConf conf)
/*     */     throws IOException
/*     */   {
/* 554 */     FileSystem localFs = FileSystem.getLocal(conf);
/* 555 */     localFs.delete(jobFile);
/* 556 */     OutputStream out = null;
/*     */     try {
/* 558 */       out = FileSystem.create(localFs, jobFile, urw_gr);
/* 559 */       conf.writeXml(out);
/*     */     } finally {
/* 561 */       IOUtils.cleanup(LOG, new Closeable[] { out });
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JobLocalizer
 * JD-Core Version:    0.6.1
 */
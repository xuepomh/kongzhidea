/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.http.HttpServer;
/*     */ import org.apache.hadoop.net.NetUtils;
/*     */ import org.apache.hadoop.security.SecurityUtil;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ import org.mortbay.jetty.webapp.WebAppContext;
/*     */ 
/*     */ public class JobHistoryServer
/*     */ {
/*  58 */   private static final Log LOG = LogFactory.getLog(JobHistoryServer.class);
/*     */   private static final String JH_USER_NAME = "mapreduce.jobhistory.kerberos.principal";
/*     */   private static final String JH_KEYTAB_FILE = "mapreduce.jobhistory.keytab.file";
/*     */   public static final String MAPRED_HISTORY_SERVER_HTTP_ADDRESS = "mapreduce.history.server.http.address";
/*     */   public static final String MAPRED_HISTORY_SERVER_EMBEDDED = "mapreduce.history.server.embedded";
/*     */   private HttpServer historyServer;
/*     */   private JobConf conf;
/*     */   private String historyInfoAddr;
/*     */   private WebAppContext context;
/*     */ 
/*     */   public JobHistoryServer(JobConf conf)
/*     */     throws IOException
/*     */   {
/*  89 */     if (isEmbedded(conf)) {
/*  90 */       throw new IllegalStateException("History server is configured to run within JobTracker. Aborting..");
/*     */     }
/*     */ 
/*  94 */     this.historyInfoAddr = getBindAddress(conf);
/*  95 */     login(conf);
/*  96 */     ACLsManager aclsManager = initializeACLsManager(conf);
/*  97 */     this.historyServer = initializeWebContainer(conf, aclsManager);
/*  98 */     initializeWebServer(conf, aclsManager);
/*     */   }
/*     */ 
/*     */   public JobHistoryServer(JobConf conf, ACLsManager aclsManager, HttpServer httpServer)
/*     */     throws IOException
/*     */   {
/* 113 */     this.historyInfoAddr = getBindAddress(conf);
/* 114 */     this.historyServer = httpServer;
/* 115 */     initializeWebServer(conf, aclsManager);
/*     */   }
/*     */ 
/*     */   private void login(JobConf conf) throws IOException {
/* 119 */     UserGroupInformation.setConfiguration(conf);
/* 120 */     InetSocketAddress infoSocAddr = NetUtils.createSocketAddr(this.historyInfoAddr);
/*     */ 
/* 122 */     SecurityUtil.login(conf, "mapreduce.jobhistory.keytab.file", "mapreduce.jobhistory.kerberos.principal", infoSocAddr.getHostName());
/* 123 */     LOG.info("History server login successful");
/*     */   }
/*     */ 
/*     */   private ACLsManager initializeACLsManager(JobConf conf) throws IOException
/*     */   {
/* 128 */     LOG.info("Initializing ACLs Manager");
/*     */ 
/* 130 */     Configuration queuesConf = new Configuration(conf);
/* 131 */     QueueManager queueManager = new QueueManager(queuesConf);
/*     */ 
/* 133 */     return new ACLsManager(conf, new JobACLsManager(conf), queueManager);
/*     */   }
/*     */ 
/*     */   private void initializeWebServer(final JobConf conf, ACLsManager aclsManager)
/*     */     throws IOException
/*     */   {
/* 150 */     this.conf = conf;
/*     */     FileSystem fs;
/*     */     try
/*     */     {
/* 154 */       fs = (FileSystem)aclsManager.getMROwner().doAs(new PrivilegedExceptionAction()
/*     */       {
/*     */         public FileSystem run() throws IOException {
/* 157 */           return FileSystem.get(conf);
/*     */         } } );
/*     */     } catch (InterruptedException e) {
/* 160 */       throw new IOException("Operation interrupted", e);
/*     */     }
/*     */ 
/* 163 */     if (!isEmbedded(conf)) {
/* 164 */       JobHistory.initDone(conf, fs, false);
/*     */     }
/* 166 */     String historyLogDir = JobHistory.getCompletedJobHistoryLocation().toString();
/*     */ 
/* 168 */     FileSystem historyFS = new Path(historyLogDir).getFileSystem(conf);
/*     */ 
/* 170 */     this.historyServer.setAttribute("historyLogDir", historyLogDir);
/* 171 */     this.historyServer.setAttribute("fileSys", historyFS);
/* 172 */     this.historyServer.setAttribute("jobConf", conf);
/* 173 */     this.historyServer.setAttribute("aclManager", aclsManager);
/*     */ 
/* 175 */     this.historyServer.addServlet("historyfile", "/historyfile", RawHistoryFileServlet.class);
/*     */   }
/*     */ 
/*     */   private HttpServer initializeWebContainer(JobConf conf, ACLsManager aclsManager)
/*     */     throws IOException
/*     */   {
/* 182 */     InetSocketAddress infoSocAddr = NetUtils.createSocketAddr(this.historyInfoAddr);
/* 183 */     int tmpInfoPort = infoSocAddr.getPort();
/* 184 */     return new HttpServer("history", infoSocAddr.getHostName(), tmpInfoPort, tmpInfoPort == 0, conf, aclsManager.getAdminsAcl());
/*     */   }
/*     */ 
/*     */   public void start() throws IOException
/*     */   {
/* 189 */     if (!isEmbedded(this.conf)) {
/* 190 */       this.historyServer.start();
/*     */     }
/*     */ 
/* 193 */     InetSocketAddress infoSocAddr = NetUtils.createSocketAddr(this.historyInfoAddr);
/* 194 */     this.conf.set("mapreduce.history.server.http.address", infoSocAddr.getHostName() + ":" + this.historyServer.getPort());
/*     */ 
/* 196 */     LOG.info("Started job history server at: " + getAddress(this.conf));
/*     */   }
/*     */ 
/*     */   public void join() throws InterruptedException {
/* 200 */     this.historyServer.join();
/*     */   }
/*     */ 
/*     */   public void shutdown()
/*     */     throws Exception
/*     */   {
/* 208 */     if ((this.historyServer != null) && (!isEmbedded(this.conf))) {
/* 209 */       LOG.info("Shutting down history server");
/* 210 */       this.historyServer.stop();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 220 */     StringUtils.startupShutdownMessage(JobHistoryServer.class, args, LOG);
/*     */     try
/*     */     {
/* 223 */       JobHistoryServer server = new JobHistoryServer(new JobConf());
/* 224 */       server.start();
/* 225 */       server.join();
/*     */     } catch (Throwable e) {
/* 227 */       LOG.fatal(StringUtils.stringifyException(e));
/* 228 */       System.exit(-1);
/*     */     }
/*     */   }
/*     */ 
/*     */   static boolean isEmbedded(JobConf conf) {
/* 233 */     return conf.getBoolean("mapreduce.history.server.embedded", true);
/*     */   }
/*     */ 
/*     */   static String getAddress(JobConf conf) {
/* 237 */     return conf.get("mapreduce.history.server.http.address");
/*     */   }
/*     */ 
/*     */   static String getHistoryUrlPrefix(JobConf conf) {
/* 241 */     return "http://" + getAddress(conf);
/*     */   }
/*     */ 
/*     */   private static String getBindAddress(JobConf conf) {
/* 245 */     return conf.get("mapreduce.history.server.http.address", "localhost:0");
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  61 */     Configuration.addDefaultResource("mapred-default.xml");
/*  62 */     Configuration.addDefaultResource("mapred-site.xml");
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JobHistoryServer
 * JD-Core Version:    0.6.1
 */
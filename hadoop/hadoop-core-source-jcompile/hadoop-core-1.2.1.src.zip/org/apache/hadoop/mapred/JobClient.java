/*      */ package org.apache.hadoop.mapred;
/*      */ 
/*      */ import java.io.BufferedReader;
/*      */ import java.io.BufferedWriter;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.OutputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.PrintStream;
/*      */ import java.net.InetAddress;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URL;
/*      */ import java.net.URLConnection;
/*      */ import java.net.UnknownHostException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.apache.hadoop.classification.InterfaceAudience.Private;
/*      */ import org.apache.hadoop.conf.Configuration;
/*      */ import org.apache.hadoop.conf.Configuration.IntegerRanges;
/*      */ import org.apache.hadoop.conf.Configured;
/*      */ import org.apache.hadoop.filecache.DistributedCache;
/*      */ import org.apache.hadoop.filecache.TrackerDistributedCacheManager;
/*      */ import org.apache.hadoop.fs.FSDataOutputStream;
/*      */ import org.apache.hadoop.fs.FileStatus;
/*      */ import org.apache.hadoop.fs.FileSystem;
/*      */ import org.apache.hadoop.fs.FileUtil;
/*      */ import org.apache.hadoop.fs.Path;
/*      */ import org.apache.hadoop.fs.permission.FsPermission;
/*      */ import org.apache.hadoop.hdfs.DFSClient;
/*      */ import org.apache.hadoop.io.IOUtils;
/*      */ import org.apache.hadoop.io.Text;
/*      */ import org.apache.hadoop.io.retry.RetryPolicies;
/*      */ import org.apache.hadoop.io.retry.RetryPolicy;
/*      */ import org.apache.hadoop.io.retry.RetryProxy;
/*      */ import org.apache.hadoop.io.retry.RetryUtils;
/*      */ import org.apache.hadoop.ipc.RPC;
/*      */ import org.apache.hadoop.ipc.RemoteException;
/*      */ import org.apache.hadoop.mapreduce.JobContext;
/*      */ import org.apache.hadoop.mapreduce.JobSubmissionFiles;
/*      */ import org.apache.hadoop.mapreduce.security.TokenCache;
/*      */ import org.apache.hadoop.mapreduce.security.token.delegation.DelegationTokenIdentifier;
/*      */ import org.apache.hadoop.mapreduce.split.JobSplitWriter;
/*      */ import org.apache.hadoop.net.NetUtils;
/*      */ import org.apache.hadoop.security.AccessControlException;
/*      */ import org.apache.hadoop.security.Credentials;
/*      */ import org.apache.hadoop.security.SecurityUtil;
/*      */ import org.apache.hadoop.security.UserGroupInformation;
/*      */ import org.apache.hadoop.security.authorize.AccessControlList;
/*      */ import org.apache.hadoop.security.token.SecretManager.InvalidToken;
/*      */ import org.apache.hadoop.security.token.Token;
/*      */ import org.apache.hadoop.security.token.TokenRenewer;
/*      */ import org.apache.hadoop.util.ReflectionUtils;
/*      */ import org.apache.hadoop.util.StringUtils;
/*      */ import org.apache.hadoop.util.Tool;
/*      */ import org.apache.hadoop.util.ToolRunner;
/*      */ import org.codehaus.jackson.JsonParseException;
/*      */ import org.codehaus.jackson.map.JsonMappingException;
/*      */ import org.codehaus.jackson.map.ObjectMapper;
/*      */ 
/*      */ public class JobClient extends Configured
/*      */   implements MRConstants, Tool
/*      */ {
/*  180 */   private static final Log LOG = LogFactory.getLog(JobClient.class);
/*      */ 
/*  182 */   private TaskStatusFilter taskOutputFilter = TaskStatusFilter.FAILED;
/*      */   private static final long MAX_JOBPROFILE_AGE = 2000L;
/*      */   private JobSubmissionProtocol rpcJobSubmitClient;
/*      */   private JobSubmissionProtocol jobSubmitClient;
/*  445 */   private Path sysDir = null;
/*  446 */   private Path stagingAreaDir = null;
/*      */ 
/*  448 */   private FileSystem fs = null;
/*      */   private UserGroupInformation ugi;
/*      */   private static final String TASKLOG_PULL_TIMEOUT_KEY = "mapreduce.client.tasklog.timeout";
/*      */   private static final int DEFAULT_TASKLOG_TIMEOUT = 60000;
/*      */   static int tasklogtimeout;
/*      */   public static final String MAPREDUCE_CLIENT_RETRY_POLICY_ENABLED_KEY = "mapreduce.jobclient.retry.policy.enabled";
/*      */   public static final boolean MAPREDUCE_CLIENT_RETRY_POLICY_ENABLED_DEFAULT = false;
/*      */   public static final String MAPREDUCE_CLIENT_RETRY_POLICY_SPEC_KEY = "mapreduce.jobclient.retry.policy.spec";
/*      */   public static final String MAPREDUCE_CLIENT_RETRY_POLICY_SPEC_DEFAULT = "10000,6,60000,10";
/*      */ 
/*      */   public JobClient()
/*      */   {
/*      */   }
/*      */ 
/*      */   public JobClient(JobConf conf)
/*      */     throws IOException
/*      */   {
/*  478 */     setConf(conf);
/*  479 */     init(conf);
/*      */   }
/*      */ 
/*      */   public void init(JobConf conf)
/*      */     throws IOException
/*      */   {
/*  488 */     String tracker = conf.get("mapred.job.tracker", "local");
/*  489 */     tasklogtimeout = conf.getInt("mapreduce.client.tasklog.timeout", 60000);
/*      */ 
/*  491 */     this.ugi = UserGroupInformation.getCurrentUser();
/*  492 */     if ("local".equals(tracker)) {
/*  493 */       conf.setNumMapTasks(1);
/*  494 */       this.jobSubmitClient = new LocalJobRunner(conf);
/*      */     } else {
/*  496 */       this.rpcJobSubmitClient = createRPCProxy(JobTracker.getAddress(conf), conf);
/*      */ 
/*  498 */       this.jobSubmitClient = createProxy(this.rpcJobSubmitClient, conf);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static JobSubmissionProtocol createRPCProxy(InetSocketAddress addr, Configuration conf)
/*      */     throws IOException
/*      */   {
/*  505 */     JobSubmissionProtocol rpcJobSubmitClient = (JobSubmissionProtocol)RPC.getProxy(JobSubmissionProtocol.class, 28L, addr, UserGroupInformation.getCurrentUser(), conf, NetUtils.getSocketFactory(conf, JobSubmissionProtocol.class), 0, RetryUtils.getMultipleLinearRandomRetry(conf, "mapreduce.jobclient.retry.policy.enabled", false, "mapreduce.jobclient.retry.policy.spec", "10000,6,60000,10"), false);
/*      */ 
/*  521 */     return rpcJobSubmitClient;
/*      */   }
/*      */ 
/*      */   private static JobSubmissionProtocol createProxy(JobSubmissionProtocol rpcJobSubmitClient, Configuration conf)
/*      */     throws IOException
/*      */   {
/*  534 */     RetryPolicy defaultPolicy = RetryUtils.getDefaultRetryPolicy(conf, "mapreduce.jobclient.retry.policy.enabled", false, "mapreduce.jobclient.retry.policy.spec", "10000,6,60000,10", new Class[] { JobTrackerNotYetInitializedException.class, SafeModeException.class });
/*      */ 
/*  551 */     Map methodNameToPolicyMap = new HashMap();
/*      */ 
/*  553 */     methodNameToPolicyMap.put("killJob", RetryPolicies.TRY_ONCE_THEN_FAIL);
/*  554 */     methodNameToPolicyMap.put("killTask", RetryPolicies.TRY_ONCE_THEN_FAIL);
/*      */ 
/*  556 */     JobSubmissionProtocol jsp = (JobSubmissionProtocol)RetryProxy.create(JobSubmissionProtocol.class, rpcJobSubmitClient, defaultPolicy, methodNameToPolicyMap);
/*      */ 
/*  559 */     RPC.checkVersion(JobSubmissionProtocol.class, 28L, jsp);
/*      */ 
/*  561 */     return jsp;
/*      */   }
/*      */ 
/*      */   public JobClient(InetSocketAddress jobTrackAddr, Configuration conf)
/*      */     throws IOException
/*      */   {
/*  611 */     this.ugi = UserGroupInformation.getCurrentUser();
/*  612 */     this.rpcJobSubmitClient = createRPCProxy(jobTrackAddr, conf);
/*  613 */     this.jobSubmitClient = createProxy(this.rpcJobSubmitClient, conf);
/*      */   }
/*      */ 
/*      */   public synchronized void close()
/*      */     throws IOException
/*      */   {
/*  620 */     if (!(this.rpcJobSubmitClient instanceof LocalJobRunner))
/*  621 */       RPC.stopProxy(this.rpcJobSubmitClient);
/*      */   }
/*      */ 
/*      */   public synchronized FileSystem getFs()
/*      */     throws IOException
/*      */   {
/*  633 */     if (this.fs == null) {
/*      */       try {
/*  635 */         this.fs = ((FileSystem)this.ugi.doAs(new PrivilegedExceptionAction() {
/*      */           public FileSystem run() throws IOException {
/*  637 */             Path sysDir = JobClient.this.getSystemDir();
/*  638 */             return sysDir.getFileSystem(JobClient.this.getConf());
/*      */           } } ));
/*      */       }
/*      */       catch (InterruptedException e) {
/*  642 */         throw new RuntimeException(e);
/*      */       }
/*      */     }
/*  645 */     return this.fs;
/*      */   }
/*      */ 
/*      */   private boolean compareFs(FileSystem srcFs, FileSystem destFs)
/*      */   {
/*  652 */     URI srcUri = srcFs.getUri();
/*  653 */     URI dstUri = destFs.getUri();
/*  654 */     if (srcUri.getScheme() == null) {
/*  655 */       return false;
/*      */     }
/*  657 */     if (!srcUri.getScheme().equals(dstUri.getScheme())) {
/*  658 */       return false;
/*      */     }
/*  660 */     String srcHost = srcUri.getHost();
/*  661 */     String dstHost = dstUri.getHost();
/*  662 */     if ((srcHost != null) && (dstHost != null)) {
/*      */       try {
/*  664 */         srcHost = InetAddress.getByName(srcHost).getCanonicalHostName();
/*  665 */         dstHost = InetAddress.getByName(dstHost).getCanonicalHostName();
/*      */       } catch (UnknownHostException ue) {
/*  667 */         return false;
/*      */       }
/*  669 */       if (!srcHost.equals(dstHost))
/*  670 */         return false;
/*      */     }
/*      */     else {
/*  673 */       if ((srcHost == null) && (dstHost != null)) {
/*  674 */         return false;
/*      */       }
/*  676 */       if ((srcHost != null) && (dstHost == null)) {
/*  677 */         return false;
/*      */       }
/*      */     }
/*  680 */     if (srcUri.getPort() != dstUri.getPort()) {
/*  681 */       return false;
/*      */     }
/*  683 */     return true;
/*      */   }
/*      */ 
/*      */   private Path copyRemoteFiles(FileSystem jtFs, Path parentDir, Path originalPath, JobConf job, short replication)
/*      */     throws IOException, InterruptedException
/*      */   {
/*  697 */     FileSystem remoteFs = null;
/*  698 */     remoteFs = originalPath.getFileSystem(job);
/*      */ 
/*  700 */     if (compareFs(remoteFs, jtFs)) {
/*  701 */       return originalPath;
/*      */     }
/*      */ 
/*  705 */     Path newPath = new Path(parentDir, originalPath.getName());
/*  706 */     FileUtil.copy(remoteFs, originalPath, jtFs, newPath, false, job);
/*  707 */     jtFs.setReplication(newPath, replication);
/*  708 */     return newPath;
/*      */   }
/*      */ 
/*      */   private URI getPathURI(Path destPath, String fragment) throws URISyntaxException
/*      */   {
/*  713 */     URI pathURI = destPath.toUri();
/*  714 */     if (pathURI.getFragment() == null) {
/*  715 */       if (fragment == null)
/*  716 */         pathURI = new URI(pathURI.toString() + "#" + destPath.getName());
/*      */       else {
/*  718 */         pathURI = new URI(pathURI.toString() + "#" + fragment);
/*      */       }
/*      */     }
/*  721 */     return pathURI;
/*      */   }
/*      */ 
/*      */   private void copyAndConfigureFiles(JobConf job, Path jobSubmitDir)
/*      */     throws IOException, InterruptedException
/*      */   {
/*  733 */     short replication = (short)job.getInt("mapred.submit.replication", 10);
/*  734 */     copyAndConfigureFiles(job, jobSubmitDir, replication);
/*      */ 
/*  737 */     if (job.getWorkingDirectory() == null)
/*  738 */       job.setWorkingDirectory(this.fs.getWorkingDirectory());
/*      */   }
/*      */ 
/*      */   private void copyAndConfigureFiles(JobConf job, Path submitJobDir, short replication)
/*      */     throws IOException, InterruptedException
/*      */   {
/*  745 */     if (!job.getBoolean("mapred.used.genericoptionsparser", false)) {
/*  746 */       LOG.warn("Use GenericOptionsParser for parsing the arguments. Applications should implement Tool for the same.");
/*      */     }
/*      */ 
/*  752 */     String files = job.get("tmpfiles");
/*  753 */     String libjars = job.get("tmpjars");
/*  754 */     String archives = job.get("tmparchives");
/*      */ 
/*  765 */     FileSystem fs = submitJobDir.getFileSystem(job);
/*  766 */     LOG.debug("default FileSystem: " + fs.getUri());
/*  767 */     if (fs.exists(submitJobDir)) {
/*  768 */       throw new IOException("Not submitting job. Job directory " + submitJobDir + " already exists!! This is unexpected.Please check what's there in" + " that directory");
/*      */     }
/*      */ 
/*  772 */     submitJobDir = fs.makeQualified(submitJobDir);
/*  773 */     FsPermission mapredSysPerms = new FsPermission(JobSubmissionFiles.JOB_DIR_PERMISSION);
/*  774 */     FileSystem.mkdirs(fs, submitJobDir, mapredSysPerms);
/*  775 */     Path filesDir = JobSubmissionFiles.getJobDistCacheFiles(submitJobDir);
/*  776 */     Path archivesDir = JobSubmissionFiles.getJobDistCacheArchives(submitJobDir);
/*  777 */     Path libjarsDir = JobSubmissionFiles.getJobDistCacheLibjars(submitJobDir);
/*      */ 
/*  781 */     if (files != null) {
/*  782 */       FileSystem.mkdirs(fs, filesDir, mapredSysPerms);
/*  783 */       String[] fileArr = files.split(",");
/*  784 */       for (String tmpFile : fileArr) {
/*      */         URI tmpURI;
/*      */         try {
/*  787 */           tmpURI = new URI(tmpFile);
/*      */         } catch (URISyntaxException e) {
/*  789 */           throw new IllegalArgumentException(e);
/*      */         }
/*  791 */         Path tmp = new Path(tmpURI);
/*  792 */         Path newPath = copyRemoteFiles(fs, filesDir, tmp, job, replication);
/*      */         try {
/*  794 */           URI pathURI = getPathURI(newPath, tmpURI.getFragment());
/*  795 */           DistributedCache.addCacheFile(pathURI, job);
/*      */         }
/*      */         catch (URISyntaxException ue) {
/*  798 */           throw new IOException("Failed to create uri for " + tmpFile, ue);
/*      */         }
/*  800 */         DistributedCache.createSymlink(job);
/*      */       }
/*      */     }
/*      */ 
/*  804 */     if (libjars != null) {
/*  805 */       FileSystem.mkdirs(fs, libjarsDir, mapredSysPerms);
/*  806 */       String[] libjarsArr = libjars.split(",");
/*  807 */       for (String tmpjars : libjarsArr) {
/*  808 */         Path tmp = new Path(tmpjars);
/*  809 */         Path newPath = copyRemoteFiles(fs, libjarsDir, tmp, job, replication);
/*  810 */         DistributedCache.addArchiveToClassPath(new Path(newPath.toUri().getPath()), job, fs);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  816 */     if (archives != null) {
/*  817 */       FileSystem.mkdirs(fs, archivesDir, mapredSysPerms);
/*  818 */       String[] archivesArr = archives.split(",");
/*  819 */       for (String tmpArchives : archivesArr) {
/*      */         URI tmpURI;
/*      */         try {
/*  822 */           tmpURI = new URI(tmpArchives);
/*      */         } catch (URISyntaxException e) {
/*  824 */           throw new IllegalArgumentException(e);
/*      */         }
/*  826 */         Path tmp = new Path(tmpURI);
/*  827 */         Path newPath = copyRemoteFiles(fs, archivesDir, tmp, job, replication);
/*      */         try {
/*  829 */           URI pathURI = getPathURI(newPath, tmpURI.getFragment());
/*  830 */           DistributedCache.addCacheArchive(pathURI, job);
/*      */         }
/*      */         catch (URISyntaxException ue) {
/*  833 */           throw new IOException("Failed to create uri for " + tmpArchives, ue);
/*      */         }
/*  835 */         DistributedCache.createSymlink(job);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  840 */     TrackerDistributedCacheManager.validate(job);
/*      */ 
/*  843 */     TrackerDistributedCacheManager.determineTimestampsAndCacheVisibilities(job);
/*      */ 
/*  845 */     TrackerDistributedCacheManager.getDelegationTokens(job, job.getCredentials());
/*      */ 
/*  848 */     String originalJarPath = job.getJar();
/*      */ 
/*  850 */     if (originalJarPath != null)
/*      */     {
/*  852 */       if ("".equals(job.getJobName())) {
/*  853 */         job.setJobName(new Path(originalJarPath).getName());
/*      */       }
/*  855 */       Path originalJarFile = new Path(originalJarPath);
/*  856 */       URI jobJarURI = originalJarFile.toUri();
/*      */ 
/*  858 */       if ((jobJarURI.getScheme() == null) || (jobJarURI.getAuthority() == null) || (!jobJarURI.getScheme().equals(fs.getUri().getScheme())) || (!jobJarURI.getAuthority().equals(fs.getUri().getAuthority())))
/*      */       {
/*  862 */         Path submitJarFile = JobSubmissionFiles.getJobJar(submitJobDir);
/*  863 */         job.setJar(submitJarFile.toString());
/*  864 */         fs.copyFromLocalFile(originalJarFile, submitJarFile);
/*  865 */         fs.setReplication(submitJarFile, replication);
/*  866 */         fs.setPermission(submitJarFile, new FsPermission(JobSubmissionFiles.JOB_FILE_PERMISSION));
/*      */       }
/*      */     }
/*      */     else {
/*  870 */       LOG.warn("No job jar file set.  User classes may not be found. See JobConf(Class) or JobConf#setJar(String).");
/*      */     }
/*      */   }
/*      */ 
/*      */   public RunningJob submitJob(String jobFile)
/*      */     throws FileNotFoundException, InvalidJobConfException, IOException
/*      */   {
/*  892 */     JobConf job = new JobConf(jobFile);
/*  893 */     return submitJob(job);
/*      */   }
/*      */ 
/*      */   public RunningJob submitJob(JobConf job)
/*      */     throws FileNotFoundException, IOException
/*      */   {
/*      */     try
/*      */     {
/*  910 */       return submitJobInternal(job);
/*      */     } catch (InterruptedException ie) {
/*  912 */       throw new IOException("interrupted", ie);
/*      */     } catch (ClassNotFoundException cnfe) {
/*  914 */       throw new IOException("class not found", cnfe);
/*      */     }
/*      */   }
/*      */ 
/*      */   public RunningJob submitJobInternal(final JobConf job)
/*      */     throws FileNotFoundException, ClassNotFoundException, InterruptedException, IOException
/*      */   {
/*  936 */     return (RunningJob)this.ugi.doAs(new PrivilegedExceptionAction()
/*      */     {
/*      */       public RunningJob run()
/*      */         throws FileNotFoundException, ClassNotFoundException, InterruptedException, IOException
/*      */       {
/*  941 */         JobConf jobCopy = job;
/*  942 */         Path jobStagingArea = JobSubmissionFiles.getStagingDir(JobClient.this, jobCopy);
/*      */ 
/*  944 */         JobID jobId = JobClient.this.jobSubmitClient.getNewJobId();
/*  945 */         Path submitJobDir = new Path(jobStagingArea, jobId.toString());
/*  946 */         jobCopy.set("mapreduce.job.dir", submitJobDir.toString());
/*  947 */         JobStatus status = null;
/*      */         try {
/*  949 */           JobClient.this.populateTokenCache(jobCopy, jobCopy.getCredentials());
/*      */ 
/*  951 */           JobClient.this.copyAndConfigureFiles(jobCopy, submitJobDir);
/*      */ 
/*  954 */           TokenCache.obtainTokensForNamenodes(jobCopy.getCredentials(), new Path[] { submitJobDir }, jobCopy);
/*      */ 
/*  958 */           Path submitJobFile = JobSubmissionFiles.getJobConfPath(submitJobDir);
/*  959 */           int reduces = jobCopy.getNumReduceTasks();
/*  960 */           InetAddress ip = InetAddress.getLocalHost();
/*  961 */           if (ip != null) {
/*  962 */             job.setJobSubmitHostAddress(ip.getHostAddress());
/*  963 */             job.setJobSubmitHostName(ip.getHostName());
/*      */           }
/*  965 */           JobContext context = new JobContext(jobCopy, jobId);
/*      */ 
/*  968 */           if (reduces == 0 ? jobCopy.getUseNewMapper() : jobCopy.getUseNewReducer())
/*      */           {
/*  970 */             org.apache.hadoop.mapreduce.OutputFormat output = (org.apache.hadoop.mapreduce.OutputFormat)ReflectionUtils.newInstance(context.getOutputFormatClass(), jobCopy);
/*      */ 
/*  973 */             output.checkOutputSpecs(context);
/*      */           } else {
/*  975 */             jobCopy.getOutputFormat().checkOutputSpecs(JobClient.this.fs, jobCopy);
/*      */           }
/*      */ 
/*  978 */           jobCopy = (JobConf)context.getConfiguration();
/*      */ 
/*  981 */           FileSystem fs = submitJobDir.getFileSystem(jobCopy);
/*  982 */           JobClient.LOG.debug("Creating splits at " + fs.makeQualified(submitJobDir));
/*  983 */           int maps = JobClient.this.writeSplits(context, submitJobDir);
/*  984 */           jobCopy.setNumMapTasks(maps);
/*      */ 
/*  988 */           String queue = jobCopy.getQueueName();
/*  989 */           AccessControlList acl = JobClient.this.jobSubmitClient.getQueueAdmins(queue);
/*  990 */           jobCopy.set(QueueManager.toFullPropertyName(queue, QueueManager.QueueACL.ADMINISTER_JOBS.getAclName()), acl.getACLString());
/*      */ 
/*  994 */           FSDataOutputStream out = FileSystem.create(fs, submitJobFile, new FsPermission(JobSubmissionFiles.JOB_FILE_PERMISSION));
/*      */ 
/* 1002 */           TokenCache.cleanUpTokenReferral(jobCopy);
/*      */           try
/*      */           {
/* 1005 */             jobCopy.writeXml(out);
/*      */           } finally {
/* 1007 */             out.close();
/*      */           }
/*      */ 
/* 1012 */           JobClient.this.printTokens(jobId, jobCopy.getCredentials());
/* 1013 */           status = JobClient.this.jobSubmitClient.submitJob(jobId, submitJobDir.toString(), jobCopy.getCredentials());
/*      */ 
/* 1015 */           JobProfile prof = JobClient.this.jobSubmitClient.getJobProfile(jobId);
/* 1016 */           if ((status != null) && (prof != null)) {
/* 1017 */             return new JobClient.NetworkedJob(status, prof, JobClient.this.jobSubmitClient);
/*      */           }
/* 1019 */           throw new IOException("Could not launch job");
/*      */         }
/*      */         finally {
/* 1022 */           if (status == null) {
/* 1023 */             JobClient.LOG.info("Cleaning up the staging area " + submitJobDir);
/* 1024 */             if ((JobClient.this.fs != null) && (submitJobDir != null))
/* 1025 */               JobClient.this.fs.delete(submitJobDir, true);
/*      */           }
/*      */         }
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private void printTokens(JobID jobId, Credentials credentials)
/*      */     throws IOException
/*      */   {
/* 1035 */     if (LOG.isDebugEnabled()) {
/* 1036 */       LOG.debug("Printing tokens for job: " + jobId);
/* 1037 */       for (Token token : credentials.getAllTokens())
/* 1038 */         if (token.getKind().toString().equals("HDFS_DELEGATION_TOKEN"))
/* 1039 */           LOG.debug("Submitting with " + DFSClient.stringifyToken(token));
/*      */     }
/*      */   }
/*      */ 
/*      */   private <T extends org.apache.hadoop.mapreduce.InputSplit> int writeNewSplits(JobContext job, Path jobSubmitDir)
/*      */     throws IOException, InterruptedException, ClassNotFoundException
/*      */   {
/* 1050 */     Configuration conf = job.getConfiguration();
/* 1051 */     org.apache.hadoop.mapreduce.InputFormat input = (org.apache.hadoop.mapreduce.InputFormat)ReflectionUtils.newInstance(job.getInputFormatClass(), conf);
/*      */ 
/* 1054 */     List splits = input.getSplits(job);
/* 1055 */     org.apache.hadoop.mapreduce.InputSplit[] array = (org.apache.hadoop.mapreduce.InputSplit[])splits.toArray(new org.apache.hadoop.mapreduce.InputSplit[splits.size()]);
/*      */ 
/* 1059 */     Arrays.sort(array, new SplitComparator(null));
/* 1060 */     JobSplitWriter.createSplitFiles(jobSubmitDir, conf, jobSubmitDir.getFileSystem(conf), array);
/*      */ 
/* 1062 */     return array.length;
/*      */   }
/*      */ 
/*      */   private int writeSplits(JobContext job, Path jobSubmitDir)
/*      */     throws IOException, InterruptedException, ClassNotFoundException
/*      */   {
/* 1068 */     JobConf jConf = (JobConf)job.getConfiguration();
/*      */     int maps;
/*      */     int maps;
/* 1070 */     if (jConf.getUseNewMapper())
/* 1071 */       maps = writeNewSplits(job, jobSubmitDir);
/*      */     else {
/* 1073 */       maps = writeOldSplits(jConf, jobSubmitDir);
/*      */     }
/* 1075 */     return maps;
/*      */   }
/*      */ 
/*      */   private int writeOldSplits(JobConf job, Path jobSubmitDir)
/*      */     throws IOException
/*      */   {
/* 1081 */     InputSplit[] splits = job.getInputFormat().getSplits(job, job.getNumMapTasks());
/*      */ 
/* 1085 */     Arrays.sort(splits, new Comparator()
/*      */     {
/*      */       public int compare(InputSplit a, InputSplit b) {
/*      */         try {
/* 1089 */           long left = a.getLength();
/* 1090 */           long right = b.getLength();
/* 1091 */           if (left == right)
/* 1092 */             return 0;
/* 1093 */           if (left < right) {
/* 1094 */             return 1;
/*      */           }
/* 1096 */           return -1;
/*      */         }
/*      */         catch (IOException ie) {
/* 1099 */           throw new RuntimeException("Problem getting input split size", ie);
/*      */         }
/*      */       }
/*      */     });
/* 1103 */     JobSplitWriter.createSplitFiles(jobSubmitDir, job, jobSubmitDir.getFileSystem(job), splits);
/*      */ 
/* 1105 */     return splits.length;
/*      */   }
/*      */ 
/*      */   public static boolean isJobDirValid(Path jobDirPath, FileSystem fs)
/*      */     throws IOException
/*      */   {
/* 1135 */     FileStatus[] contents = fs.listStatus(jobDirPath);
/* 1136 */     int matchCount = 0;
/* 1137 */     if ((contents != null) && (contents.length >= 2)) {
/* 1138 */       for (FileStatus status : contents) {
/* 1139 */         if ("job.xml".equals(status.getPath().getName())) {
/* 1140 */           matchCount++;
/*      */         }
/* 1142 */         if ("job.split".equals(status.getPath().getName())) {
/* 1143 */           matchCount++;
/*      */         }
/*      */       }
/* 1146 */       if (matchCount == 2) {
/* 1147 */         return true;
/*      */       }
/*      */     }
/* 1150 */     return false;
/*      */   }
/*      */ 
/*      */   public RunningJob getJob(JobID jobid)
/*      */     throws IOException
/*      */   {
/* 1163 */     JobStatus status = this.jobSubmitClient.getJobStatus(jobid);
/* 1164 */     JobProfile profile = this.jobSubmitClient.getJobProfile(jobid);
/* 1165 */     if ((status != null) && (profile != null)) {
/* 1166 */       return new NetworkedJob(status, profile, this.jobSubmitClient);
/*      */     }
/* 1168 */     return null;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public RunningJob getJob(String jobid)
/*      */     throws IOException
/*      */   {
/* 1176 */     return getJob(JobID.forName(jobid));
/*      */   }
/*      */ 
/*      */   public TaskReport[] getMapTaskReports(JobID jobId)
/*      */     throws IOException
/*      */   {
/* 1187 */     return this.jobSubmitClient.getMapTaskReports(jobId);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public TaskReport[] getMapTaskReports(String jobId) throws IOException
/*      */   {
/* 1193 */     return getMapTaskReports(JobID.forName(jobId));
/*      */   }
/*      */ 
/*      */   public TaskReport[] getReduceTaskReports(JobID jobId)
/*      */     throws IOException
/*      */   {
/* 1204 */     return this.jobSubmitClient.getReduceTaskReports(jobId);
/*      */   }
/*      */ 
/*      */   public TaskReport[] getCleanupTaskReports(JobID jobId)
/*      */     throws IOException
/*      */   {
/* 1215 */     return this.jobSubmitClient.getCleanupTaskReports(jobId);
/*      */   }
/*      */ 
/*      */   public TaskReport[] getSetupTaskReports(JobID jobId)
/*      */     throws IOException
/*      */   {
/* 1226 */     return this.jobSubmitClient.getSetupTaskReports(jobId);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public TaskReport[] getReduceTaskReports(String jobId) throws IOException
/*      */   {
/* 1232 */     return getReduceTaskReports(JobID.forName(jobId));
/*      */   }
/*      */ 
/*      */   public void displayTasks(JobID jobId, String type, String state)
/*      */     throws IOException
/*      */   {
/* 1246 */     TaskReport[] reports = new TaskReport[0];
/* 1247 */     if (type.equals("map"))
/* 1248 */       reports = getMapTaskReports(jobId);
/* 1249 */     else if (type.equals("reduce"))
/* 1250 */       reports = getReduceTaskReports(jobId);
/* 1251 */     else if (type.equals("setup"))
/* 1252 */       reports = getSetupTaskReports(jobId);
/* 1253 */     else if (type.equals("cleanup")) {
/* 1254 */       reports = getCleanupTaskReports(jobId);
/*      */     }
/* 1256 */     for (TaskReport report : reports) {
/* 1257 */       TIPStatus status = report.getCurrentStatus();
/* 1258 */       if (((state.equals("pending")) && (status == TIPStatus.PENDING)) || ((state.equals("running")) && (status == TIPStatus.RUNNING)) || ((state.equals("completed")) && (status == TIPStatus.COMPLETE)) || ((state.equals("failed")) && (status == TIPStatus.FAILED)) || ((state.equals("killed")) && (status == TIPStatus.KILLED)))
/*      */       {
/* 1263 */         printTaskAttempts(report);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/* 1268 */   private void printTaskAttempts(TaskReport report) { if (report.getCurrentStatus() == TIPStatus.COMPLETE)
/* 1269 */       System.out.println(report.getSuccessfulTaskAttempt());
/* 1270 */     else if (report.getCurrentStatus() == TIPStatus.RUNNING)
/*      */     {
/* 1272 */       for (TaskAttemptID t : report.getRunningTaskAttempts())
/* 1273 */         System.out.println(t);
/*      */     }
/*      */   }
/*      */ 
/*      */   public ClusterStatus getClusterStatus()
/*      */     throws IOException
/*      */   {
/* 1285 */     return getClusterStatus(false);
/*      */   }
/*      */ 
/*      */   public ClusterStatus getClusterStatus(boolean detailed)
/*      */     throws IOException
/*      */   {
/* 1298 */     return this.jobSubmitClient.getClusterStatus(detailed);
/*      */   }
/*      */ 
/*      */   public Path getStagingAreaDir()
/*      */     throws IOException
/*      */   {
/* 1308 */     if (this.stagingAreaDir == null) {
/* 1309 */       this.stagingAreaDir = new Path(this.jobSubmitClient.getStagingAreaDir());
/*      */     }
/* 1311 */     return this.stagingAreaDir;
/*      */   }
/*      */ 
/*      */   public JobStatus[] jobsToComplete()
/*      */     throws IOException
/*      */   {
/* 1321 */     return this.jobSubmitClient.jobsToComplete();
/*      */   }
/*      */ 
/*      */   private static void downloadProfile(TaskCompletionEvent e) throws IOException
/*      */   {
/* 1326 */     URLConnection connection = new URL(getTaskLogURL(e.getTaskAttemptId(), e.getTaskTrackerHttp()) + "&filter=profile").openConnection();
/*      */ 
/* 1329 */     InputStream in = connection.getInputStream();
/* 1330 */     OutputStream out = new FileOutputStream(e.getTaskAttemptId() + ".profile");
/* 1331 */     IOUtils.copyBytes(in, out, 65536, true);
/*      */   }
/*      */ 
/*      */   public JobStatus[] getAllJobs()
/*      */     throws IOException
/*      */   {
/* 1341 */     return this.jobSubmitClient.getAllJobs();
/*      */   }
/*      */ 
/*      */   public static RunningJob runJob(JobConf job)
/*      */     throws IOException
/*      */   {
/* 1352 */     JobClient jc = new JobClient(job);
/* 1353 */     RunningJob rj = jc.submitJob(job);
/*      */     try {
/* 1355 */       if (!jc.monitorAndPrintJob(job, rj)) {
/* 1356 */         LOG.info("Job Failed: " + rj.getFailureInfo());
/* 1357 */         throw new IOException("Job failed!");
/*      */       }
/*      */     } catch (InterruptedException ie) {
/* 1360 */       Thread.currentThread().interrupt();
/*      */     }
/* 1362 */     return rj;
/*      */   }
/*      */ 
/*      */   public boolean monitorAndPrintJob(JobConf conf, RunningJob job)
/*      */     throws IOException, InterruptedException
/*      */   {
/* 1376 */     String lastReport = null;
/*      */ 
/* 1378 */     TaskStatusFilter filter = getTaskOutputFilter(conf);
/* 1379 */     JobID jobId = job.getID();
/* 1380 */     LOG.info("Running job: " + jobId);
/* 1381 */     int eventCounter = 0;
/* 1382 */     boolean profiling = conf.getProfileEnabled();
/* 1383 */     Configuration.IntegerRanges mapRanges = conf.getProfileTaskRange(true);
/* 1384 */     Configuration.IntegerRanges reduceRanges = conf.getProfileTaskRange(false);
/*      */ 
/* 1386 */     while (!job.isComplete()) {
/* 1387 */       Thread.sleep(1000L);
/* 1388 */       String report = " map " + StringUtils.formatPercent(job.mapProgress(), 0) + " reduce " + StringUtils.formatPercent(job.reduceProgress(), 0);
/*      */ 
/* 1392 */       if (!report.equals(lastReport)) {
/* 1393 */         LOG.info(report);
/* 1394 */         lastReport = report;
/*      */       }
/*      */ 
/* 1397 */       TaskCompletionEvent[] events = job.getTaskCompletionEvents(eventCounter);
/*      */ 
/* 1399 */       eventCounter += events.length;
/* 1400 */       for (TaskCompletionEvent event : events) {
/* 1401 */         TaskCompletionEvent.Status status = event.getTaskStatus();
/* 1402 */         if ((profiling) && ((status == TaskCompletionEvent.Status.SUCCEEDED) || (status == TaskCompletionEvent.Status.FAILED))) if ((event.isMap ? mapRanges : reduceRanges).isIncluded(event.idWithinJob()))
/*      */           {
/* 1407 */             downloadProfile(event);
/*      */           }
/* 1409 */         switch (4.$SwitchMap$org$apache$hadoop$mapred$JobClient$TaskStatusFilter[filter.ordinal()]) {
/*      */         case 1:
/* 1411 */           break;
/*      */         case 2:
/* 1413 */           if (event.getTaskStatus() == TaskCompletionEvent.Status.SUCCEEDED)
/*      */           {
/* 1415 */             LOG.info(event.toString());
/* 1416 */             displayTaskLogs(event.getTaskAttemptId(), event.getTaskTrackerHttp()); } break;
/*      */         case 3:
/* 1420 */           if (event.getTaskStatus() == TaskCompletionEvent.Status.FAILED)
/*      */           {
/* 1422 */             LOG.info(event.toString());
/*      */ 
/* 1424 */             TaskAttemptID taskId = event.getTaskAttemptId();
/* 1425 */             String[] taskDiagnostics = this.jobSubmitClient.getTaskDiagnostics(taskId);
/*      */ 
/* 1427 */             if (taskDiagnostics != null) {
/* 1428 */               for (String diagnostics : taskDiagnostics) {
/* 1429 */                 System.err.println(diagnostics);
/*      */               }
/*      */             }
/*      */ 
/* 1433 */             displayTaskLogs(event.getTaskAttemptId(), event.getTaskTrackerHttp());
/* 1434 */           }break;
/*      */         case 4:
/* 1437 */           if (event.getTaskStatus() == TaskCompletionEvent.Status.KILLED)
/* 1438 */             LOG.info(event.toString()); break;
/*      */         case 5:
/* 1442 */           LOG.info(event.toString());
/* 1443 */           displayTaskLogs(event.getTaskAttemptId(), event.getTaskTrackerHttp());
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1448 */     LOG.info("Job complete: " + jobId);
/* 1449 */     Counters counters = null;
/*      */     try {
/* 1451 */       counters = job.getCounters();
/*      */     } catch (IOException ie) {
/* 1453 */       counters = null;
/* 1454 */       LOG.info(ie.getMessage());
/*      */     }
/* 1456 */     if (counters != null) {
/* 1457 */       counters.log(LOG);
/*      */     }
/* 1459 */     return job.isSuccessful();
/*      */   }
/*      */ 
/*      */   static String getTaskLogURL(TaskAttemptID taskId, String baseUrl) {
/* 1463 */     return baseUrl + "/tasklog?plaintext=true&attemptid=" + taskId;
/*      */   }
/*      */ 
/*      */   private static void displayTaskLogs(TaskAttemptID taskId, String baseUrl)
/*      */     throws IOException
/*      */   {
/* 1469 */     if (baseUrl != null)
/*      */     {
/* 1471 */       String taskLogUrl = getTaskLogURL(taskId, baseUrl);
/*      */ 
/* 1474 */       getTaskLogs(taskId, new URL(taskLogUrl + "&filter=stdout"), System.out);
/*      */ 
/* 1477 */       getTaskLogs(taskId, new URL(taskLogUrl + "&filter=stderr"), System.err);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void getTaskLogs(TaskAttemptID taskId, URL taskLogUrl, OutputStream out)
/*      */   {
/*      */     try {
/* 1484 */       URLConnection connection = taskLogUrl.openConnection();
/* 1485 */       connection.setReadTimeout(tasklogtimeout);
/* 1486 */       connection.setConnectTimeout(tasklogtimeout);
/* 1487 */       BufferedReader input = new BufferedReader(new InputStreamReader(connection.getInputStream()));
/*      */ 
/* 1489 */       BufferedWriter output = new BufferedWriter(new OutputStreamWriter(out));
/*      */       try
/*      */       {
/* 1492 */         String logData = null;
/* 1493 */         while ((logData = input.readLine()) != null)
/* 1494 */           if (logData.length() > 0) {
/* 1495 */             output.write(taskId + ": " + logData + "\n");
/* 1496 */             output.flush();
/*      */           }
/*      */       }
/*      */       finally {
/* 1500 */         input.close();
/*      */       }
/*      */     } catch (IOException ioe) {
/* 1503 */       LOG.warn("Error reading task output" + ioe.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   static Configuration getConfiguration(String jobTrackerSpec)
/*      */   {
/* 1509 */     Configuration conf = new Configuration();
/* 1510 */     if (jobTrackerSpec != null) {
/* 1511 */       if (jobTrackerSpec.indexOf(":") >= 0) {
/* 1512 */         conf.set("mapred.job.tracker", jobTrackerSpec);
/*      */       } else {
/* 1514 */         String classpathFile = "hadoop-" + jobTrackerSpec + ".xml";
/* 1515 */         URL validate = conf.getResource(classpathFile);
/* 1516 */         if (validate == null) {
/* 1517 */           throw new RuntimeException(classpathFile + " not found on CLASSPATH");
/*      */         }
/* 1519 */         conf.addResource(classpathFile);
/*      */       }
/*      */     }
/* 1522 */     return conf;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public void setTaskOutputFilter(TaskStatusFilter newValue)
/*      */   {
/* 1532 */     this.taskOutputFilter = newValue;
/*      */   }
/*      */ 
/*      */   public static TaskStatusFilter getTaskOutputFilter(JobConf job)
/*      */   {
/* 1542 */     return TaskStatusFilter.valueOf(job.get("jobclient.output.filter", "FAILED"));
/*      */   }
/*      */ 
/*      */   public static void setTaskOutputFilter(JobConf job, TaskStatusFilter newValue)
/*      */   {
/* 1554 */     job.set("jobclient.output.filter", newValue.toString());
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public TaskStatusFilter getTaskOutputFilter()
/*      */   {
/* 1563 */     return this.taskOutputFilter;
/*      */   }
/*      */ 
/*      */   private String getJobPriorityNames() {
/* 1567 */     StringBuffer sb = new StringBuffer();
/* 1568 */     for (JobPriority p : JobPriority.values()) {
/* 1569 */       sb.append(p.name()).append(" ");
/*      */     }
/* 1571 */     return sb.substring(0, sb.length() - 1);
/*      */   }
/*      */ 
/*      */   private void displayUsage(String cmd)
/*      */   {
/* 1578 */     String prefix = "Usage: JobClient ";
/* 1579 */     String jobPriorityValues = getJobPriorityNames();
/* 1580 */     String taskTypes = "map, reduce, setup, cleanup";
/* 1581 */     String taskStates = "running, completed";
/* 1582 */     if ("-submit".equals(cmd)) {
/* 1583 */       System.err.println(prefix + "[" + cmd + " <job-file>]");
/* 1584 */     } else if (("-status".equals(cmd)) || ("-kill".equals(cmd))) {
/* 1585 */       System.err.println(prefix + "[" + cmd + " <job-id>]");
/* 1586 */     } else if ("-counter".equals(cmd)) {
/* 1587 */       System.err.println(prefix + "[" + cmd + " <job-id> <group-name> <counter-name>]");
/* 1588 */     } else if ("-events".equals(cmd)) {
/* 1589 */       System.err.println(prefix + "[" + cmd + " <job-id> <from-event-#> <#-of-events>]");
/* 1590 */     } else if ("-history".equals(cmd)) {
/* 1591 */       System.err.println(prefix + "[" + cmd + " <jobOutputDir>]");
/* 1592 */     } else if ("-list".equals(cmd)) {
/* 1593 */       System.err.println(prefix + "[" + cmd + " [all]]");
/* 1594 */     } else if (("-kill-task".equals(cmd)) || ("-fail-task".equals(cmd))) {
/* 1595 */       System.err.println(prefix + "[" + cmd + " <task-id>]");
/* 1596 */     } else if ("-set-priority".equals(cmd)) {
/* 1597 */       System.err.println(prefix + "[" + cmd + " <job-id> <priority>]. " + "Valid values for priorities are: " + jobPriorityValues);
/*      */     }
/* 1600 */     else if ("-list-active-trackers".equals(cmd)) {
/* 1601 */       System.err.println(prefix + "[" + cmd + "]");
/* 1602 */     } else if ("-list-blacklisted-trackers".equals(cmd)) {
/* 1603 */       System.err.println(prefix + "[" + cmd + "]");
/* 1604 */     } else if ("-list-attempt-ids".equals(cmd)) {
/* 1605 */       System.err.println(prefix + "[" + cmd + " <job-id> <task-type> <task-state>]. " + "Valid values for <task-type> are " + taskTypes + ". " + "Valid values for <task-state> are " + taskStates);
/*      */     }
/*      */     else
/*      */     {
/* 1610 */       System.err.printf(prefix + "<command> <args>\n", new Object[0]);
/* 1611 */       System.err.printf("\t[-submit <job-file>]\n", new Object[0]);
/* 1612 */       System.err.printf("\t[-status <job-id>]\n", new Object[0]);
/* 1613 */       System.err.printf("\t[-counter <job-id> <group-name> <counter-name>]\n", new Object[0]);
/* 1614 */       System.err.printf("\t[-kill <job-id>]\n", new Object[0]);
/* 1615 */       System.err.printf("\t[-set-priority <job-id> <priority>]. Valid values for priorities are: " + jobPriorityValues + "\n", new Object[0]);
/*      */ 
/* 1618 */       System.err.printf("\t[-events <job-id> <from-event-#> <#-of-events>]\n", new Object[0]);
/* 1619 */       System.err.printf("\t[-history <jobOutputDir>]\n", new Object[0]);
/* 1620 */       System.err.printf("\t[-list [all]]\n", new Object[0]);
/* 1621 */       System.err.printf("\t[-list-active-trackers]\n", new Object[0]);
/* 1622 */       System.err.printf("\t[-list-blacklisted-trackers]\n", new Object[0]);
/* 1623 */       System.err.println("\t[-list-attempt-ids <job-id> <task-type> <task-state>]\n");
/*      */ 
/* 1625 */       System.err.printf("\t[-kill-task <task-id>]\n", new Object[0]);
/* 1626 */       System.err.printf("\t[-fail-task <task-id>]\n\n", new Object[0]);
/* 1627 */       ToolRunner.printGenericCommandUsage(System.out);
/*      */     }
/*      */   }
/*      */ 
/*      */   public int run(String[] argv) throws Exception {
/* 1632 */     int exitCode = -1;
/* 1633 */     if (argv.length < 1) {
/* 1634 */       displayUsage("");
/* 1635 */       return exitCode;
/*      */     }
/*      */ 
/* 1638 */     String cmd = argv[0];
/* 1639 */     String submitJobFile = null;
/* 1640 */     String jobid = null;
/* 1641 */     String taskid = null;
/* 1642 */     String outputDir = null;
/* 1643 */     String counterGroupName = null;
/* 1644 */     String counterName = null;
/* 1645 */     String newPriority = null;
/* 1646 */     String taskType = null;
/* 1647 */     String taskState = null;
/* 1648 */     int fromEvent = 0;
/* 1649 */     int nEvents = 0;
/* 1650 */     boolean getStatus = false;
/* 1651 */     boolean getCounter = false;
/* 1652 */     boolean killJob = false;
/* 1653 */     boolean listEvents = false;
/* 1654 */     boolean viewHistory = false;
/* 1655 */     boolean viewAllHistory = false;
/* 1656 */     boolean listJobs = false;
/* 1657 */     boolean listAllJobs = false;
/* 1658 */     boolean listActiveTrackers = false;
/* 1659 */     boolean listBlacklistedTrackers = false;
/* 1660 */     boolean displayTasks = false;
/* 1661 */     boolean killTask = false;
/* 1662 */     boolean failTask = false;
/* 1663 */     boolean setJobPriority = false;
/*      */ 
/* 1665 */     if ("-submit".equals(cmd)) {
/* 1666 */       if (argv.length != 2) {
/* 1667 */         displayUsage(cmd);
/* 1668 */         return exitCode;
/*      */       }
/* 1670 */       submitJobFile = argv[1];
/* 1671 */     } else if ("-status".equals(cmd)) {
/* 1672 */       if (argv.length != 2) {
/* 1673 */         displayUsage(cmd);
/* 1674 */         return exitCode;
/*      */       }
/* 1676 */       jobid = argv[1];
/* 1677 */       getStatus = true;
/* 1678 */     } else if ("-counter".equals(cmd)) {
/* 1679 */       if (argv.length != 4) {
/* 1680 */         displayUsage(cmd);
/* 1681 */         return exitCode;
/*      */       }
/* 1683 */       getCounter = true;
/* 1684 */       jobid = argv[1];
/* 1685 */       counterGroupName = argv[2];
/* 1686 */       counterName = argv[3];
/* 1687 */     } else if ("-kill".equals(cmd)) {
/* 1688 */       if (argv.length != 2) {
/* 1689 */         displayUsage(cmd);
/* 1690 */         return exitCode;
/*      */       }
/* 1692 */       jobid = argv[1];
/* 1693 */       killJob = true;
/* 1694 */     } else if ("-set-priority".equals(cmd)) {
/* 1695 */       if (argv.length != 3) {
/* 1696 */         displayUsage(cmd);
/* 1697 */         return exitCode;
/*      */       }
/* 1699 */       jobid = argv[1];
/* 1700 */       newPriority = argv[2];
/*      */       try {
/* 1702 */         jp = JobPriority.valueOf(newPriority);
/*      */       }
/*      */       catch (IllegalArgumentException iae)
/*      */       {
/*      */         JobPriority jp;
/* 1704 */         displayUsage(cmd);
/* 1705 */         return exitCode;
/*      */       }
/* 1707 */       setJobPriority = true;
/* 1708 */     } else if ("-events".equals(cmd)) {
/* 1709 */       if (argv.length != 4) {
/* 1710 */         displayUsage(cmd);
/* 1711 */         return exitCode;
/*      */       }
/* 1713 */       jobid = argv[1];
/* 1714 */       fromEvent = Integer.parseInt(argv[2]);
/* 1715 */       nEvents = Integer.parseInt(argv[3]);
/* 1716 */       listEvents = true;
/* 1717 */     } else if ("-history".equals(cmd)) {
/* 1718 */       if ((argv.length != 2) && ((argv.length != 3) || (!"all".equals(argv[1])))) {
/* 1719 */         displayUsage(cmd);
/* 1720 */         return exitCode;
/*      */       }
/* 1722 */       viewHistory = true;
/* 1723 */       if ((argv.length == 3) && ("all".equals(argv[1]))) {
/* 1724 */         viewAllHistory = true;
/* 1725 */         outputDir = argv[2];
/*      */       } else {
/* 1727 */         outputDir = argv[1];
/*      */       }
/* 1729 */     } else if ("-list".equals(cmd)) {
/* 1730 */       if ((argv.length != 1) && ((argv.length != 2) || (!"all".equals(argv[1])))) {
/* 1731 */         displayUsage(cmd);
/* 1732 */         return exitCode;
/*      */       }
/* 1734 */       if ((argv.length == 2) && ("all".equals(argv[1])))
/* 1735 */         listAllJobs = true;
/*      */       else
/* 1737 */         listJobs = true;
/*      */     }
/* 1739 */     else if ("-kill-task".equals(cmd)) {
/* 1740 */       if (argv.length != 2) {
/* 1741 */         displayUsage(cmd);
/* 1742 */         return exitCode;
/*      */       }
/* 1744 */       killTask = true;
/* 1745 */       taskid = argv[1];
/* 1746 */     } else if ("-fail-task".equals(cmd)) {
/* 1747 */       if (argv.length != 2) {
/* 1748 */         displayUsage(cmd);
/* 1749 */         return exitCode;
/*      */       }
/* 1751 */       failTask = true;
/* 1752 */       taskid = argv[1];
/* 1753 */     } else if ("-list-active-trackers".equals(cmd)) {
/* 1754 */       if (argv.length != 1) {
/* 1755 */         displayUsage(cmd);
/* 1756 */         return exitCode;
/*      */       }
/* 1758 */       listActiveTrackers = true;
/* 1759 */     } else if ("-list-blacklisted-trackers".equals(cmd)) {
/* 1760 */       if (argv.length != 1) {
/* 1761 */         displayUsage(cmd);
/* 1762 */         return exitCode;
/*      */       }
/* 1764 */       listBlacklistedTrackers = true;
/* 1765 */     } else if ("-list-attempt-ids".equals(cmd)) {
/* 1766 */       if (argv.length != 4) {
/* 1767 */         displayUsage(cmd);
/* 1768 */         return exitCode;
/*      */       }
/* 1770 */       jobid = argv[1];
/* 1771 */       taskType = argv[2];
/* 1772 */       taskState = argv[3];
/* 1773 */       displayTasks = true;
/*      */     } else {
/* 1775 */       displayUsage(cmd);
/* 1776 */       return exitCode;
/*      */     }
/*      */ 
/* 1780 */     JobConf conf = null;
/* 1781 */     if (submitJobFile != null)
/* 1782 */       conf = new JobConf(submitJobFile);
/*      */     else {
/* 1784 */       conf = new JobConf(getConf());
/*      */     }
/* 1786 */     init(conf);
/*      */     try
/*      */     {
/* 1790 */       if (submitJobFile != null) {
/* 1791 */         RunningJob job = submitJob(conf);
/* 1792 */         System.out.println("Created job " + job.getID());
/* 1793 */         exitCode = 0;
/* 1794 */       } else if (getStatus) {
/* 1795 */         RunningJob job = getJob(JobID.forName(jobid));
/* 1796 */         if (job == null) {
/* 1797 */           System.out.println("Could not find job " + jobid);
/*      */         } else {
/* 1799 */           Throwable counterException = null;
/* 1800 */           Counters counters = null;
/*      */           try {
/* 1802 */             counters = job.getCounters();
/*      */           } catch (IOException e) {
/* 1804 */             counterException = e;
/*      */           }
/* 1806 */           System.out.println();
/* 1807 */           System.out.println(job);
/* 1808 */           if (counters != null) {
/* 1809 */             System.out.println(counters);
/*      */           }
/* 1811 */           else if (counterException != null)
/* 1812 */             System.out.println("Error fetching counters: " + counterException.getMessage());
/*      */           else {
/* 1814 */             System.out.println("Counters not available. Job is retired.");
/*      */           }
/*      */ 
/* 1817 */           exitCode = 0;
/*      */         }
/* 1819 */       } else if (getCounter) {
/* 1820 */         RunningJob job = getJob(JobID.forName(jobid));
/* 1821 */         if (job == null) {
/* 1822 */           System.out.println("Could not find job " + jobid);
/*      */         } else {
/* 1824 */           Throwable counterException = null;
/* 1825 */           Counters counters = null;
/*      */           try {
/* 1827 */             counters = job.getCounters();
/*      */           } catch (IOException e) {
/* 1829 */             counterException = e;
/*      */           }
/* 1831 */           if (counters == null) {
/* 1832 */             if (counterException != null) {
/* 1833 */               System.out.println("Error fetching counters: " + counterException.getMessage());
/*      */             }
/*      */             else {
/* 1836 */               System.out.println("Counters not available for retired job " + jobid);
/*      */             }
/*      */ 
/* 1839 */             exitCode = -1;
/*      */           } else {
/* 1841 */             Counters.Group group = counters.getGroup(counterGroupName);
/* 1842 */             Counters.Counter counter = group.getCounterForName(counterName);
/* 1843 */             System.out.println(counter.getCounter());
/* 1844 */             exitCode = 0;
/*      */           }
/*      */         }
/* 1847 */       } else if (killJob) {
/* 1848 */         RunningJob job = getJob(JobID.forName(jobid));
/* 1849 */         if (job == null) {
/* 1850 */           System.out.println("Could not find job " + jobid);
/*      */         } else {
/* 1852 */           job.killJob();
/* 1853 */           System.out.println("Killed job " + jobid);
/* 1854 */           exitCode = 0;
/*      */         }
/* 1856 */       } else if (setJobPriority) {
/* 1857 */         RunningJob job = getJob(JobID.forName(jobid));
/* 1858 */         if (job == null) {
/* 1859 */           System.out.println("Could not find job " + jobid);
/*      */         } else {
/* 1861 */           job.setJobPriority(newPriority);
/* 1862 */           System.out.println("Changed job priority.");
/* 1863 */           exitCode = 0;
/*      */         }
/* 1865 */       } else if (viewHistory) {
/* 1866 */         viewHistory(outputDir, viewAllHistory);
/* 1867 */         exitCode = 0;
/* 1868 */       } else if (listEvents) {
/* 1869 */         listEvents(JobID.forName(jobid), fromEvent, nEvents);
/* 1870 */         exitCode = 0;
/* 1871 */       } else if (listJobs) {
/* 1872 */         listJobs();
/* 1873 */         exitCode = 0;
/* 1874 */       } else if (listAllJobs) {
/* 1875 */         listAllJobs();
/* 1876 */         exitCode = 0;
/* 1877 */       } else if (listActiveTrackers) {
/* 1878 */         listActiveTrackers();
/* 1879 */         exitCode = 0;
/* 1880 */       } else if (listBlacklistedTrackers) {
/* 1881 */         listBlacklistedTrackers();
/* 1882 */         exitCode = 0;
/* 1883 */       } else if (displayTasks) {
/* 1884 */         displayTasks(JobID.forName(jobid), taskType, taskState);
/* 1885 */       } else if (killTask) {
/* 1886 */         if (this.jobSubmitClient.killTask(TaskAttemptID.forName(taskid), false)) {
/* 1887 */           System.out.println("Killed task " + taskid);
/* 1888 */           exitCode = 0;
/*      */         } else {
/* 1890 */           System.out.println("Could not kill task " + taskid);
/* 1891 */           exitCode = -1;
/*      */         }
/* 1893 */       } else if (failTask) {
/* 1894 */         if (this.jobSubmitClient.killTask(TaskAttemptID.forName(taskid), true)) {
/* 1895 */           System.out.println("Killed task " + taskid + " by failing it");
/* 1896 */           exitCode = 0;
/*      */         } else {
/* 1898 */           System.out.println("Could not fail task " + taskid);
/* 1899 */           exitCode = -1;
/*      */         }
/*      */       }
/*      */     } catch (RemoteException re) {
/* 1903 */       IOException unwrappedException = re.unwrapRemoteException();
/* 1904 */       if ((unwrappedException instanceof AccessControlException))
/* 1905 */         System.out.println(unwrappedException.getMessage());
/*      */       else
/* 1907 */         throw re;
/*      */     }
/*      */     finally {
/* 1910 */       close();
/*      */     }
/* 1912 */     return exitCode;
/*      */   }
/*      */ 
/*      */   private void viewHistory(String outputDir, boolean all) throws IOException
/*      */   {
/* 1917 */     HistoryViewer historyViewer = new HistoryViewer(outputDir, getConf(), all);
/*      */ 
/* 1919 */     historyViewer.print();
/*      */   }
/*      */ 
/*      */   private void listEvents(JobID jobId, int fromEventId, int numEvents)
/*      */     throws IOException
/*      */   {
/* 1929 */     TaskCompletionEvent[] events = this.jobSubmitClient.getTaskCompletionEvents(jobId, fromEventId, numEvents);
/*      */ 
/* 1931 */     System.out.println("Task completion events for " + jobId);
/* 1932 */     System.out.println("Number of events (from " + fromEventId + ") are: " + events.length);
/*      */ 
/* 1934 */     for (TaskCompletionEvent event : events)
/* 1935 */       System.out.println(event.getTaskStatus() + " " + event.getTaskAttemptId() + " " + getTaskLogURL(event.getTaskAttemptId(), event.getTaskTrackerHttp()));
/*      */   }
/*      */ 
/*      */   private void listJobs()
/*      */     throws IOException
/*      */   {
/* 1946 */     JobStatus[] jobs = jobsToComplete();
/* 1947 */     if (jobs == null) {
/* 1948 */       jobs = new JobStatus[0];
/*      */     }
/* 1950 */     System.out.printf("%d jobs currently running\n", new Object[] { Integer.valueOf(jobs.length) });
/* 1951 */     displayJobList(jobs);
/*      */   }
/*      */ 
/*      */   private void listAllJobs()
/*      */     throws IOException
/*      */   {
/* 1959 */     JobStatus[] jobs = getAllJobs();
/* 1960 */     if (jobs == null)
/* 1961 */       jobs = new JobStatus[0];
/* 1962 */     System.out.printf("%d jobs submitted\n", new Object[] { Integer.valueOf(jobs.length) });
/* 1963 */     System.out.printf("States are:\n\tRunning : 1\tSucceded : 2\tFailed : 3\tPrep : 4\n", new Object[0]);
/*      */ 
/* 1965 */     displayJobList(jobs);
/*      */   }
/*      */ 
/*      */   private void listActiveTrackers()
/*      */     throws IOException
/*      */   {
/* 1972 */     ClusterStatus c = this.jobSubmitClient.getClusterStatus(true);
/* 1973 */     Collection trackers = c.getActiveTrackerNames();
/* 1974 */     for (String trackerName : trackers)
/* 1975 */       System.out.println(trackerName);
/*      */   }
/*      */ 
/*      */   private void listBlacklistedTrackers()
/*      */     throws IOException
/*      */   {
/* 1983 */     ClusterStatus c = this.jobSubmitClient.getClusterStatus(true);
/* 1984 */     Collection trackers = c.getBlacklistedTrackerNames();
/* 1985 */     for (String trackerName : trackers)
/* 1986 */       System.out.println(trackerName);
/*      */   }
/*      */ 
/*      */   void displayJobList(JobStatus[] jobs)
/*      */   {
/* 1991 */     System.out.printf("JobId\tState\tStartTime\tUserName\tPriority\tSchedulingInfo\n", new Object[0]);
/* 1992 */     for (JobStatus job : jobs)
/* 1993 */       System.out.printf("%s\t%d\t%d\t%s\t%s\t%s\n", new Object[] { job.getJobID(), Integer.valueOf(job.getRunState()), Long.valueOf(job.getStartTime()), job.getUsername(), job.getJobPriority().name(), job.getSchedulingInfo() });
/*      */   }
/*      */ 
/*      */   public int getDefaultMaps()
/*      */     throws IOException
/*      */   {
/* 2006 */     return getClusterStatus().getMaxMapTasks();
/*      */   }
/*      */ 
/*      */   public int getDefaultReduces()
/*      */     throws IOException
/*      */   {
/* 2016 */     return getClusterStatus().getMaxReduceTasks();
/*      */   }
/*      */ 
/*      */   public Path getSystemDir()
/*      */   {
/* 2025 */     if (this.sysDir == null) {
/* 2026 */       this.sysDir = new Path(this.jobSubmitClient.getSystemDir());
/*      */     }
/* 2028 */     return this.sysDir;
/*      */   }
/*      */ 
/*      */   public JobQueueInfo[] getQueues()
/*      */     throws IOException
/*      */   {
/* 2040 */     return this.jobSubmitClient.getQueues();
/*      */   }
/*      */ 
/*      */   public JobStatus[] getJobsFromQueue(String queueName)
/*      */     throws IOException
/*      */   {
/* 2052 */     return this.jobSubmitClient.getJobsFromQueue(queueName);
/*      */   }
/*      */ 
/*      */   public JobQueueInfo getQueueInfo(String queueName)
/*      */     throws IOException
/*      */   {
/* 2063 */     return this.jobSubmitClient.getQueueInfo(queueName);
/*      */   }
/*      */ 
/*      */   public QueueAclsInfo[] getQueueAclsForCurrentUser()
/*      */     throws IOException
/*      */   {
/* 2072 */     return this.jobSubmitClient.getQueueAclsForCurrentUser();
/*      */   }
/*      */ 
/*      */   public Token<DelegationTokenIdentifier> getDelegationToken(Text renewer)
/*      */     throws IOException, InterruptedException
/*      */   {
/* 2081 */     Token result = this.jobSubmitClient.getDelegationToken(renewer);
/*      */ 
/* 2083 */     SecurityUtil.setTokenService(result, JobTracker.getAddress(getConf()));
/* 2084 */     return result;
/*      */   }
/*      */ 
/*      */   public long renewDelegationToken(Token<DelegationTokenIdentifier> token)
/*      */     throws SecretManager.InvalidToken, IOException, InterruptedException
/*      */   {
/*      */     try
/*      */     {
/* 2097 */       return this.jobSubmitClient.renewDelegationToken(token);
/*      */     } catch (RemoteException re) {
/* 2099 */       throw re.unwrapRemoteException(new Class[] { SecretManager.InvalidToken.class, AccessControlException.class });
/*      */     }
/*      */   }
/*      */ 
/*      */   public void cancelDelegationToken(Token<DelegationTokenIdentifier> token)
/*      */     throws IOException, InterruptedException
/*      */   {
/*      */     try
/*      */     {
/* 2113 */       this.jobSubmitClient.cancelDelegationToken(token);
/*      */     } catch (RemoteException re) {
/* 2115 */       throw re.unwrapRemoteException(new Class[] { SecretManager.InvalidToken.class, AccessControlException.class });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void main(String[] argv)
/*      */     throws Exception
/*      */   {
/* 2123 */     int res = ToolRunner.run(new JobClient(), argv);
/* 2124 */     System.exit(res);
/*      */   }
/*      */ 
/*      */   private void readTokensFromFiles(Configuration conf, Credentials credentials)
/*      */     throws IOException
/*      */   {
/* 2131 */     String binaryTokenFilename = conf.get("mapreduce.job.credentials.binary");
/*      */ 
/* 2133 */     if (binaryTokenFilename != null) {
/* 2134 */       Credentials binary = Credentials.readTokenStorageFile(new Path("file:///" + binaryTokenFilename), conf);
/*      */ 
/* 2137 */       credentials.addAll(binary);
/*      */     }
/*      */ 
/* 2140 */     String tokensFileName = conf.get("mapreduce.job.credentials.json");
/* 2141 */     if (tokensFileName != null) {
/* 2142 */       LOG.info("loading user's secret keys from " + tokensFileName);
/* 2143 */       String localFileName = new Path(tokensFileName).toUri().getPath();
/*      */ 
/* 2145 */       boolean json_error = false;
/*      */       try
/*      */       {
/* 2148 */         ObjectMapper mapper = new ObjectMapper();
/* 2149 */         Map nm = (Map)mapper.readValue(new File(localFileName), Map.class);
/*      */ 
/* 2152 */         for (Map.Entry ent : nm.entrySet())
/* 2153 */           credentials.addSecretKey(new Text((String)ent.getKey()), ((String)ent.getValue()).getBytes());
/*      */       }
/*      */       catch (JsonMappingException e)
/*      */       {
/* 2157 */         json_error = true;
/*      */       } catch (JsonParseException e) {
/* 2159 */         json_error = true;
/*      */       }
/* 2161 */       if (json_error)
/* 2162 */         LOG.warn("couldn't parse Token Cache JSON file with user secret keys");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void populateTokenCache(Configuration conf, Credentials credentials)
/*      */     throws IOException
/*      */   {
/* 2170 */     readTokensFromFiles(conf, credentials);
/*      */ 
/* 2173 */     String[] nameNodes = conf.getStrings("mapreduce.job.hdfs-servers");
/* 2174 */     LOG.debug("adding the following namenodes' delegation tokens:" + Arrays.toString(nameNodes));
/*      */ 
/* 2176 */     if (nameNodes != null) {
/* 2177 */       Path[] ps = new Path[nameNodes.length];
/* 2178 */       for (int i = 0; i < nameNodes.length; i++) {
/* 2179 */         ps[i] = new Path(nameNodes[i]);
/*      */       }
/* 2181 */       TokenCache.obtainTokensForNamenodes(credentials, ps, conf);
/*      */     }
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*  186 */     Configuration.addDefaultResource("mapred-default.xml");
/*  187 */     Configuration.addDefaultResource("mapred-site.xml");
/*      */   }
/*      */ 
/*      */   private static class SplitComparator
/*      */     implements Comparator<org.apache.hadoop.mapreduce.InputSplit>
/*      */   {
/*      */     public int compare(org.apache.hadoop.mapreduce.InputSplit o1, org.apache.hadoop.mapreduce.InputSplit o2)
/*      */     {
/*      */       try
/*      */       {
/* 1112 */         long len1 = o1.getLength();
/* 1113 */         long len2 = o2.getLength();
/* 1114 */         if (len1 < len2)
/* 1115 */           return 1;
/* 1116 */         if (len1 == len2) {
/* 1117 */           return 0;
/*      */         }
/* 1119 */         return -1;
/*      */       }
/*      */       catch (IOException ie) {
/* 1122 */         throw new RuntimeException("exception in compare", ie);
/*      */       } catch (InterruptedException ie) {
/* 1124 */         throw new RuntimeException("exception in compare", ie);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   @InterfaceAudience.Private
/*      */   public static class Renewer extends TokenRenewer
/*      */   {
/*      */     public boolean handleKind(Text kind)
/*      */     {
/*  569 */       return DelegationTokenIdentifier.MAPREDUCE_DELEGATION_KIND.equals(kind);
/*      */     }
/*      */ 
/*      */     public long renew(Token<?> token, Configuration conf)
/*      */       throws IOException, InterruptedException
/*      */     {
/*  576 */       InetSocketAddress addr = SecurityUtil.getTokenServiceAddr(token);
/*  577 */       JobSubmissionProtocol jt = JobClient.createProxy(JobClient.access$000(addr, conf), conf);
/*  578 */       return jt.renewDelegationToken(token);
/*      */     }
/*      */ 
/*      */     public void cancel(Token<?> token, Configuration conf)
/*      */       throws IOException, InterruptedException
/*      */     {
/*  585 */       InetSocketAddress addr = SecurityUtil.getTokenServiceAddr(token);
/*  586 */       JobSubmissionProtocol jt = JobClient.createProxy(JobClient.access$000(addr, conf), conf);
/*  587 */       jt.cancelDelegationToken(token);
/*      */     }
/*      */ 
/*      */     public boolean isManaged(Token<?> token) throws IOException
/*      */     {
/*  592 */       ByteArrayInputStream buf = new ByteArrayInputStream(token.getIdentifier());
/*  593 */       DelegationTokenIdentifier id = new DelegationTokenIdentifier();
/*  594 */       id.readFields(new DataInputStream(buf));
/*      */ 
/*  597 */       String loginUser = UserGroupInformation.getLoginUser().getShortUserName();
/*  598 */       return loginUser.equals(id.getRenewer().toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   static class NetworkedJob
/*      */     implements RunningJob
/*      */   {
/*      */     private JobSubmissionProtocol jobSubmitClient;
/*      */     JobProfile profile;
/*      */     JobStatus status;
/*      */     long statustime;
/*      */ 
/*      */     public NetworkedJob(JobStatus job, JobProfile prof, JobSubmissionProtocol jobSubmitClient)
/*      */       throws IOException
/*      */     {
/*  209 */       this.status = job;
/*  210 */       this.profile = prof;
/*  211 */       this.jobSubmitClient = jobSubmitClient;
/*  212 */       if (this.status == null) {
/*  213 */         throw new IOException("The Job status cannot be null");
/*      */       }
/*  215 */       if (this.profile == null) {
/*  216 */         throw new IOException("The Job profile cannot be null");
/*      */       }
/*  218 */       if (this.jobSubmitClient == null) {
/*  219 */         throw new IOException("The Job Submission Protocol cannot be null");
/*      */       }
/*  221 */       this.statustime = System.currentTimeMillis();
/*      */     }
/*      */ 
/*      */     synchronized void ensureFreshStatus()
/*      */       throws IOException
/*      */     {
/*  229 */       if (System.currentTimeMillis() - this.statustime > 2000L)
/*  230 */         updateStatus();
/*      */     }
/*      */ 
/*      */     synchronized void updateStatus()
/*      */       throws IOException
/*      */     {
/*  239 */       this.status = this.jobSubmitClient.getJobStatus(this.profile.getJobID());
/*  240 */       if (this.status == null) {
/*  241 */         throw new IOException("The job appears to have been removed.");
/*      */       }
/*  243 */       this.statustime = System.currentTimeMillis();
/*      */     }
/*      */ 
/*      */     public JobID getID()
/*      */     {
/*  250 */       return this.profile.getJobID();
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public String getJobID()
/*      */     {
/*  257 */       return this.profile.getJobID().toString();
/*      */     }
/*      */ 
/*      */     public String getJobName()
/*      */     {
/*  264 */       return this.profile.getJobName();
/*      */     }
/*      */ 
/*      */     public String getJobFile()
/*      */     {
/*  271 */       return this.profile.getJobFile();
/*      */     }
/*      */ 
/*      */     public String getTrackingURL()
/*      */     {
/*  278 */       return this.profile.getURL().toString();
/*      */     }
/*      */ 
/*      */     public float mapProgress()
/*      */       throws IOException
/*      */     {
/*  286 */       ensureFreshStatus();
/*  287 */       return this.status.mapProgress();
/*      */     }
/*      */ 
/*      */     public float reduceProgress()
/*      */       throws IOException
/*      */     {
/*  295 */       ensureFreshStatus();
/*  296 */       return this.status.reduceProgress();
/*      */     }
/*      */ 
/*      */     public float cleanupProgress()
/*      */       throws IOException
/*      */     {
/*  304 */       ensureFreshStatus();
/*  305 */       return this.status.cleanupProgress();
/*      */     }
/*      */ 
/*      */     public float setupProgress()
/*      */       throws IOException
/*      */     {
/*  313 */       ensureFreshStatus();
/*  314 */       return this.status.setupProgress();
/*      */     }
/*      */ 
/*      */     public synchronized boolean isComplete()
/*      */       throws IOException
/*      */     {
/*  321 */       updateStatus();
/*  322 */       return (this.status.getRunState() == 2) || (this.status.getRunState() == 3) || (this.status.getRunState() == 5);
/*      */     }
/*      */ 
/*      */     public synchronized boolean isSuccessful()
/*      */       throws IOException
/*      */     {
/*  331 */       updateStatus();
/*  332 */       return this.status.getRunState() == 2;
/*      */     }
/*      */ 
/*      */     public void waitForCompletion()
/*      */       throws IOException
/*      */     {
/*  339 */       while (!isComplete())
/*      */         try {
/*  341 */           Thread.sleep(5000L);
/*      */         }
/*      */         catch (InterruptedException ie)
/*      */         {
/*      */         }
/*      */     }
/*      */ 
/*      */     public synchronized int getJobState()
/*      */       throws IOException
/*      */     {
/*  351 */       updateStatus();
/*  352 */       return this.status.getRunState();
/*      */     }
/*      */ 
/*      */     public synchronized void killJob()
/*      */       throws IOException
/*      */     {
/*  359 */       this.jobSubmitClient.killJob(getID());
/*      */     }
/*      */ 
/*      */     public synchronized void setJobPriority(String priority)
/*      */       throws IOException
/*      */     {
/*  368 */       this.jobSubmitClient.setJobPriority(getID(), priority);
/*      */     }
/*      */ 
/*      */     public synchronized void killTask(TaskAttemptID taskId, boolean shouldFail)
/*      */       throws IOException
/*      */     {
/*  378 */       this.jobSubmitClient.killTask(taskId, shouldFail);
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public synchronized void killTask(String taskId, boolean shouldFail) throws IOException
/*      */     {
/*  384 */       killTask(TaskAttemptID.forName(taskId), shouldFail);
/*      */     }
/*      */ 
/*      */     public synchronized TaskCompletionEvent[] getTaskCompletionEvents(int startFrom)
/*      */       throws IOException
/*      */     {
/*  392 */       return this.jobSubmitClient.getTaskCompletionEvents(getID(), startFrom, 10);
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/*      */       try
/*      */       {
/*  402 */         updateStatus();
/*      */       } catch (IOException e) {
/*      */       }
/*  405 */       return new StringBuilder().append("Job: ").append(this.profile.getJobID()).append("\n").append("file: ").append(this.profile.getJobFile()).append("\n").append("tracking URL: ").append(this.profile.getURL()).append("\n").append("map() completion: ").append(this.status.mapProgress()).append("\n").append("reduce() completion: ").append(this.status.reduceProgress()).append("\n").append(this.status.getRunState() == 3 ? new StringBuilder().append("Failure Info: ").append(this.status.getFailureInfo()).toString() : "").toString();
/*      */     }
/*      */ 
/*      */     public Counters getCounters()
/*      */       throws IOException
/*      */     {
/*  418 */       return this.jobSubmitClient.getJobCounters(getID());
/*      */     }
/*      */ 
/*      */     public String[] getTaskDiagnostics(TaskAttemptID id) throws IOException
/*      */     {
/*  423 */       return this.jobSubmitClient.getTaskDiagnostics(id);
/*      */     }
/*      */ 
/*      */     public String getFailureInfo()
/*      */       throws IOException
/*      */     {
/*  431 */       ensureFreshStatus();
/*  432 */       return this.status.getFailureInfo();
/*      */     }
/*      */ 
/*      */     public JobStatus getJobStatus() throws IOException
/*      */     {
/*  437 */       updateStatus();
/*  438 */       return this.status;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static enum TaskStatusFilter
/*      */   {
/*  181 */     NONE, KILLED, FAILED, SUCCEEDED, ALL;
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JobClient
 * JD-Core Version:    0.6.1
 */
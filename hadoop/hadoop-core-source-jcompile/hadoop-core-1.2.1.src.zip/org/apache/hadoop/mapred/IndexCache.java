/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ 
/*     */ class IndexCache
/*     */ {
/*     */   private final JobConf conf;
/*     */   private final int totalMemoryAllowed;
/*  33 */   private AtomicInteger totalMemoryUsed = new AtomicInteger();
/*  34 */   private static final Log LOG = LogFactory.getLog(IndexCache.class);
/*     */ 
/*  36 */   private final ConcurrentHashMap<String, IndexInformation> cache = new ConcurrentHashMap();
/*     */ 
/*  39 */   private final LinkedBlockingQueue<String> queue = new LinkedBlockingQueue();
/*     */ 
/*     */   public IndexCache(JobConf conf)
/*     */   {
/*  43 */     this.conf = conf;
/*  44 */     this.totalMemoryAllowed = (conf.getInt("mapred.tasktracker.indexcache.mb", 10) * 1024 * 1024);
/*     */ 
/*  46 */     LOG.info("IndexCache created with max memory = " + this.totalMemoryAllowed);
/*     */   }
/*     */ 
/*     */   public IndexRecord getIndexInformation(String mapId, int reduce, Path fileName, String expectedIndexOwner)
/*     */     throws IOException
/*     */   {
/*  63 */     IndexInformation info = (IndexInformation)this.cache.get(mapId);
/*     */ 
/*  65 */     if (info == null) {
/*  66 */       info = readIndexFileToCache(fileName, mapId, expectedIndexOwner);
/*     */     } else {
/*  68 */       synchronized (info) {
/*  69 */         while (null == info.mapSpillRecord) {
/*     */           try {
/*  71 */             info.wait();
/*     */           } catch (InterruptedException e) {
/*  73 */             throw new IOException("Interrupted waiting for construction", e);
/*     */           }
/*     */         }
/*     */       }
/*  77 */       LOG.debug("IndexCache HIT: MapId " + mapId + " found");
/*     */     }
/*     */ 
/*  80 */     if ((info.mapSpillRecord.size() == 0) || (info.mapSpillRecord.size() < reduce))
/*     */     {
/*  82 */       throw new IOException("Invalid request  Map Id = " + mapId + " Reducer = " + reduce + " Index Info Length = " + info.mapSpillRecord.size());
/*     */     }
/*     */ 
/*  86 */     return info.mapSpillRecord.getIndex(reduce);
/*     */   }
/*     */ 
/*     */   private IndexInformation readIndexFileToCache(Path indexFileName, String mapId, String expectedIndexOwner)
/*     */     throws IOException
/*     */   {
/*  92 */     IndexInformation newInd = new IndexInformation(null);
/*     */     IndexInformation info;
/*  93 */     if ((info = (IndexInformation)this.cache.putIfAbsent(mapId, newInd)) != null) {
/*  94 */       synchronized (info) {
/*  95 */         while (null == info.mapSpillRecord) {
/*     */           try {
/*  97 */             info.wait();
/*     */           } catch (InterruptedException e) {
/*  99 */             throw new IOException("Interrupted waiting for construction", e);
/*     */           }
/*     */         }
/*     */       }
/* 103 */       LOG.debug("IndexCache HIT: MapId " + mapId + " found");
/* 104 */       return info;
/*     */     }
/* 106 */     LOG.debug("IndexCache MISS: MapId " + mapId + " not found");
/* 107 */     SpillRecord tmp = null;
/*     */     try {
/* 109 */       tmp = new SpillRecord(indexFileName, this.conf, expectedIndexOwner);
/*     */     } catch (Throwable e) {
/* 111 */       tmp = new SpillRecord(0);
/* 112 */       this.cache.remove(mapId);
/* 113 */       throw new IOException("Error Reading IndexFile", e);
/*     */     } finally {
/* 115 */       synchronized (newInd) {
/* 116 */         newInd.mapSpillRecord = tmp;
/* 117 */         newInd.notifyAll();
/*     */       }
/*     */     }
/* 120 */     this.queue.add(mapId);
/*     */ 
/* 122 */     if (this.totalMemoryUsed.addAndGet(newInd.getSize()) > this.totalMemoryAllowed) {
/* 123 */       freeIndexInformation();
/*     */     }
/* 125 */     return newInd;
/*     */   }
/*     */ 
/*     */   public void removeMap(String mapId)
/*     */   {
/* 134 */     IndexInformation info = (IndexInformation)this.cache.remove(mapId);
/* 135 */     if (info != null) {
/* 136 */       this.totalMemoryUsed.addAndGet(-info.getSize());
/* 137 */       if (!this.queue.remove(mapId))
/* 138 */         LOG.warn("Map ID" + mapId + " not found in queue!!");
/*     */     }
/*     */     else {
/* 141 */       LOG.info("Map ID " + mapId + " not found in cache");
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized void freeIndexInformation()
/*     */   {
/* 149 */     while (this.totalMemoryUsed.get() > this.totalMemoryAllowed) {
/* 150 */       String s = (String)this.queue.remove();
/* 151 */       IndexInformation info = (IndexInformation)this.cache.remove(s);
/* 152 */       if (info != null)
/* 153 */         this.totalMemoryUsed.addAndGet(-info.getSize());
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class IndexInformation
/*     */   {
/*     */     SpillRecord mapSpillRecord;
/*     */ 
/*     */     int getSize() {
/* 162 */       return this.mapSpillRecord == null ? 0 : this.mapSpillRecord.size() * 24;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.IndexCache
 * JD-Core Version:    0.6.1
 */
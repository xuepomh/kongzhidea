/*    */ package org.apache.hadoop.mapred;
/*    */ 
/*    */  enum Avataar
/*    */ {
/* 22 */   VIRGIN, 
/* 23 */   SPECULATIVE;
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.Avataar
 * JD-Core Version:    0.6.1
 */
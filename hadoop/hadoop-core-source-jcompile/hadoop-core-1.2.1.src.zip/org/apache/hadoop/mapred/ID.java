/*    */ package org.apache.hadoop.mapred;
/*    */ 
/*    */ public abstract class ID extends org.apache.hadoop.mapreduce.ID
/*    */ {
/*    */   public ID(int id)
/*    */   {
/* 34 */     super(id);
/*    */   }
/*    */ 
/*    */   protected ID()
/*    */   {
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.ID
 * JD-Core Version:    0.6.1
 */
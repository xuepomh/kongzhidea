/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.Format;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.FileUtil;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.fs.PathFilter;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ class HistoryViewer
/*     */ {
/*  49 */   private static SimpleDateFormat dateFormat = new SimpleDateFormat("d-MMM-yyyy HH:mm:ss");
/*     */   private FileSystem fs;
/*     */   private Configuration conf;
/*     */   private Path historyLogDir;
/*     */   private String jobLogFile;
/*     */   private JobHistory.JobInfo job;
/*     */   private String trackerHostName;
/*     */   private String trackerStartTime;
/*     */   private String jobId;
/*     */   private boolean printAll;
/*  61 */   private PathFilter jobLogFileFilter = new PathFilter() {
/*     */     public boolean accept(Path path) {
/*  63 */       return !path.getName().endsWith(".xml");
/*     */     }
/*  61 */   };
/*     */ 
/* 570 */   private Comparator<JobHistory.Task> cMap = new Comparator()
/*     */   {
/*     */     public int compare(JobHistory.Task t1, JobHistory.Task t2) {
/* 573 */       long l1 = t1.getLong(JobHistory.Keys.FINISH_TIME) - t1.getLong(JobHistory.Keys.START_TIME);
/* 574 */       long l2 = t2.getLong(JobHistory.Keys.FINISH_TIME) - t2.getLong(JobHistory.Keys.START_TIME);
/* 575 */       return l2 == l1 ? 0 : l2 < l1 ? -1 : 1;
/*     */     }
/* 570 */   };
/*     */ 
/* 579 */   private Comparator<JobHistory.Task> cShuffle = new Comparator()
/*     */   {
/*     */     public int compare(JobHistory.Task t1, JobHistory.Task t2) {
/* 582 */       long l1 = t1.getLong(JobHistory.Keys.SHUFFLE_FINISHED) - t1.getLong(JobHistory.Keys.START_TIME);
/*     */ 
/* 584 */       long l2 = t2.getLong(JobHistory.Keys.SHUFFLE_FINISHED) - t2.getLong(JobHistory.Keys.START_TIME);
/*     */ 
/* 586 */       return l2 == l1 ? 0 : l2 < l1 ? -1 : 1;
/*     */     }
/* 579 */   };
/*     */ 
/* 590 */   private Comparator<JobHistory.Task> cFinishShuffle = new Comparator()
/*     */   {
/*     */     public int compare(JobHistory.Task t1, JobHistory.Task t2) {
/* 593 */       long l1 = t1.getLong(JobHistory.Keys.SHUFFLE_FINISHED);
/* 594 */       long l2 = t2.getLong(JobHistory.Keys.SHUFFLE_FINISHED);
/* 595 */       return l2 == l1 ? 0 : l2 < l1 ? -1 : 1;
/*     */     }
/* 590 */   };
/*     */ 
/* 599 */   private Comparator<JobHistory.Task> cFinishMapRed = new Comparator()
/*     */   {
/*     */     public int compare(JobHistory.Task t1, JobHistory.Task t2) {
/* 602 */       long l1 = t1.getLong(JobHistory.Keys.FINISH_TIME);
/* 603 */       long l2 = t2.getLong(JobHistory.Keys.FINISH_TIME);
/* 604 */       return l2 == l1 ? 0 : l2 < l1 ? -1 : 1;
/*     */     }
/* 599 */   };
/*     */ 
/* 608 */   private Comparator<JobHistory.Task> cReduce = new Comparator()
/*     */   {
/*     */     public int compare(JobHistory.Task t1, JobHistory.Task t2) {
/* 611 */       long l1 = t1.getLong(JobHistory.Keys.FINISH_TIME) - t1.getLong(JobHistory.Keys.SHUFFLE_FINISHED);
/*     */ 
/* 613 */       long l2 = t2.getLong(JobHistory.Keys.FINISH_TIME) - t2.getLong(JobHistory.Keys.SHUFFLE_FINISHED);
/*     */ 
/* 615 */       return l2 == l1 ? 0 : l2 < l1 ? -1 : 1;
/*     */     }
/* 608 */   };
/*     */ 
/*     */   public HistoryViewer(String outputDir, Configuration conf, boolean printAll)
/*     */     throws IOException
/*     */   {
/*  69 */     this.conf = conf;
/*  70 */     this.printAll = printAll;
/*  71 */     Path output = new Path(outputDir);
/*  72 */     this.historyLogDir = new Path(output, "_logs/history");
/*     */     try {
/*  74 */       this.fs = output.getFileSystem(this.conf);
/*  75 */       if (!this.fs.exists(output)) {
/*  76 */         throw new IOException("History directory " + this.historyLogDir.toString() + "does not exist");
/*     */       }
/*     */ 
/*  79 */       Path[] jobFiles = FileUtil.stat2Paths(this.fs.listStatus(this.historyLogDir, this.jobLogFileFilter));
/*     */ 
/*  81 */       if (jobFiles.length == 0) {
/*  82 */         throw new IOException("Not a valid history directory " + this.historyLogDir.toString());
/*     */       }
/*     */ 
/*  85 */       this.jobLogFile = jobFiles[0].toString();
/*  86 */       String[] jobDetails = JobHistory.JobInfo.decodeJobHistoryFileName(jobFiles[0].getName()).split("_");
/*     */ 
/*  89 */       this.trackerHostName = jobDetails[0];
/*  90 */       this.trackerStartTime = jobDetails[1];
/*  91 */       this.jobId = (jobDetails[2] + "_" + jobDetails[3] + "_" + jobDetails[4]);
/*  92 */       this.job = new JobHistory.JobInfo(this.jobId);
/*  93 */       DefaultJobHistoryParser.parseJobTasks(jobFiles[0].toString(), this.job, this.fs);
/*     */     } catch (Exception e) {
/*  95 */       throw new IOException("Not able to initialize History viewer", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void print() throws IOException {
/* 100 */     printJobDetails();
/* 101 */     printTaskSummary();
/* 102 */     printJobAnalysis();
/* 103 */     printTasks("SETUP", "FAILED");
/* 104 */     printTasks("SETUP", "KILLED");
/* 105 */     printTasks("MAP", "FAILED");
/* 106 */     printTasks("MAP", "KILLED");
/* 107 */     printTasks("REDUCE", "FAILED");
/* 108 */     printTasks("REDUCE", "KILLED");
/* 109 */     printTasks("CLEANUP", "FAILED");
/* 110 */     printTasks("CLEANUP", "KILLED");
/* 111 */     if (this.printAll) {
/* 112 */       printTasks("SETUP", "SUCCESS");
/* 113 */       printTasks("MAP", "SUCCESS");
/* 114 */       printTasks("REDUCE", "SUCCESS");
/* 115 */       printTasks("CLEANUP", "SUCCESS");
/* 116 */       printAllTaskAttempts("SETUP");
/* 117 */       printAllTaskAttempts("MAP");
/* 118 */       printAllTaskAttempts("REDUCE");
/* 119 */       printAllTaskAttempts("CLEANUP");
/*     */     }
/* 121 */     DefaultJobHistoryParser.NodesFilter filter = new DefaultJobHistoryParser.FailedOnNodesFilter();
/* 122 */     printFailedAttempts(filter);
/* 123 */     filter = new DefaultJobHistoryParser.KilledOnNodesFilter();
/* 124 */     printFailedAttempts(filter);
/*     */   }
/*     */ 
/*     */   private void printJobDetails() throws IOException {
/* 128 */     StringBuffer jobDetails = new StringBuffer();
/* 129 */     jobDetails.append("\nHadoop job: ").append(this.jobId);
/* 130 */     jobDetails.append("\n=====================================");
/* 131 */     jobDetails.append("\nJob tracker host name: ").append(this.trackerHostName);
/* 132 */     jobDetails.append("\njob tracker start time: ").append(new Date(Long.parseLong(this.trackerStartTime)));
/*     */ 
/* 134 */     jobDetails.append("\nUser: ").append(this.job.get(JobHistory.Keys.USER));
/* 135 */     jobDetails.append("\nJobName: ").append(this.job.get(JobHistory.Keys.JOBNAME));
/* 136 */     jobDetails.append("\nJobConf: ").append(this.job.get(JobHistory.Keys.JOBCONF));
/* 137 */     jobDetails.append("\nSubmitted At: ").append(StringUtils.getFormattedTimeWithDiff(dateFormat, this.job.getLong(JobHistory.Keys.SUBMIT_TIME), 0L));
/*     */ 
/* 140 */     jobDetails.append("\nLaunched At: ").append(StringUtils.getFormattedTimeWithDiff(dateFormat, this.job.getLong(JobHistory.Keys.LAUNCH_TIME), this.job.getLong(JobHistory.Keys.SUBMIT_TIME)));
/*     */ 
/* 144 */     jobDetails.append("\nFinished At: ").append(StringUtils.getFormattedTimeWithDiff(dateFormat, this.job.getLong(JobHistory.Keys.FINISH_TIME), this.job.getLong(JobHistory.Keys.LAUNCH_TIME)));
/*     */ 
/* 148 */     jobDetails.append("\nStatus: ").append(this.job.get(JobHistory.Keys.JOB_STATUS) == "" ? "Incomplete" : this.job.get(JobHistory.Keys.JOB_STATUS));
/*     */     try
/*     */     {
/* 151 */       printCounters(jobDetails, this.job);
/*     */     } catch (ParseException p) {
/* 153 */       throw new IOException(p);
/*     */     }
/* 155 */     jobDetails.append("\n=====================================");
/* 156 */     System.out.println(jobDetails.toString());
/*     */   }
/*     */ 
/*     */   private void printCounters(StringBuffer buff, JobHistory.JobInfo job) throws ParseException
/*     */   {
/* 161 */     Counters mapCounters = Counters.fromEscapedCompactString(job.get(JobHistory.Keys.MAP_COUNTERS));
/*     */ 
/* 163 */     Counters reduceCounters = Counters.fromEscapedCompactString(job.get(JobHistory.Keys.REDUCE_COUNTERS));
/*     */ 
/* 165 */     Counters totalCounters = Counters.fromEscapedCompactString(job.get(JobHistory.Keys.COUNTERS));
/*     */ 
/* 169 */     if (totalCounters == null) {
/* 170 */       return;
/*     */     }
/* 172 */     buff.append("\nCounters: \n\n");
/* 173 */     buff.append(String.format("|%1$-30s|%2$-30s|%3$-10s|%4$-10s|%5$-10s|", new Object[] { "Group Name", "Counter name", "Map Value", "Reduce Value", "Total Value" }));
/*     */ 
/* 179 */     buff.append("\n---------------------------------------------------------------------------------------");
/*     */ 
/* 181 */     for (String groupName : totalCounters.getGroupNames()) {
/* 182 */       Counters.Group totalGroup = totalCounters.getGroup(groupName);
/* 183 */       Counters.Group mapGroup = mapCounters.getGroup(groupName);
/* 184 */       Counters.Group reduceGroup = reduceCounters.getGroup(groupName);
/* 185 */       Format decimal = new DecimalFormat();
/* 186 */       Iterator ctrItr = totalGroup.iterator();
/* 187 */       while (ctrItr.hasNext()) {
/* 188 */         Counters.Counter counter = (Counters.Counter)ctrItr.next();
/* 189 */         String name = counter.getDisplayName();
/* 190 */         String mapValue = decimal.format(Long.valueOf(mapGroup.getCounter(name)));
/* 191 */         String reduceValue = decimal.format(Long.valueOf(reduceGroup.getCounter(name)));
/* 192 */         String totalValue = decimal.format(Long.valueOf(counter.getValue()));
/* 193 */         buff.append(String.format("\n|%1$-30s|%2$-30s|%3$-10s|%4$-10s|%5$-10s", new Object[] { totalGroup.getDisplayName(), counter.getDisplayName(), mapValue, reduceValue, totalValue }));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void printTasks(String taskType, String taskStatus)
/*     */   {
/* 203 */     Map tasks = this.job.getAllTasks();
/* 204 */     StringBuffer taskList = new StringBuffer();
/* 205 */     taskList.append("\n").append(taskStatus).append(" ");
/* 206 */     taskList.append(taskType).append(" task list for ").append(this.jobId);
/* 207 */     taskList.append("\nTaskId\t\tStartTime\tFinishTime\tError");
/* 208 */     if (JobHistory.Values.MAP.name().equals(taskType)) {
/* 209 */       taskList.append("\tInputSplits");
/*     */     }
/* 211 */     taskList.append("\n====================================================");
/* 212 */     System.out.println(taskList.toString());
/* 213 */     for (JobHistory.Task task : tasks.values())
/* 214 */       if ((taskType.equals(task.get(JobHistory.Keys.TASK_TYPE))) && ((taskStatus.equals(task.get(JobHistory.Keys.TASK_STATUS))) || (taskStatus.equals("all"))))
/*     */       {
/* 217 */         taskList.setLength(0);
/* 218 */         taskList.append(task.get(JobHistory.Keys.TASKID));
/* 219 */         taskList.append("\t").append(StringUtils.getFormattedTimeWithDiff(dateFormat, task.getLong(JobHistory.Keys.START_TIME), 0L));
/*     */ 
/* 221 */         taskList.append("\t").append(StringUtils.getFormattedTimeWithDiff(dateFormat, task.getLong(JobHistory.Keys.FINISH_TIME), task.getLong(JobHistory.Keys.START_TIME)));
/*     */ 
/* 224 */         taskList.append("\t").append(task.get(JobHistory.Keys.ERROR));
/* 225 */         if (JobHistory.Values.MAP.name().equals(taskType)) {
/* 226 */           taskList.append("\t").append(task.get(JobHistory.Keys.SPLITS));
/*     */         }
/* 228 */         System.out.println(taskList.toString());
/*     */       }
/*     */   }
/*     */ 
/*     */   private void printAllTaskAttempts(String taskType)
/*     */   {
/* 234 */     Map tasks = this.job.getAllTasks();
/* 235 */     StringBuffer taskList = new StringBuffer();
/* 236 */     taskList.append("\n").append(taskType);
/* 237 */     taskList.append(" task list for ").append(this.jobId);
/* 238 */     taskList.append("\nTaskId\t\tStartTime");
/* 239 */     if (JobHistory.Values.REDUCE.name().equals(taskType)) {
/* 240 */       taskList.append("\tShuffleFinished\tSortFinished");
/*     */     }
/* 242 */     taskList.append("\tFinishTime\tHostName\tError\tTaskLogs");
/* 243 */     taskList.append("\n====================================================");
/* 244 */     System.out.println(taskList.toString());
/* 245 */     for (Iterator i$ = tasks.values().iterator(); i$.hasNext(); ) { task = (JobHistory.Task)i$.next();
/* 246 */       for (JobHistory.TaskAttempt attempt : task.getTaskAttempts().values())
/* 247 */         if (taskType.equals(task.get(JobHistory.Keys.TASK_TYPE))) {
/* 248 */           taskList.setLength(0);
/* 249 */           taskList.append(attempt.get(JobHistory.Keys.TASK_ATTEMPT_ID)).append("\t");
/* 250 */           taskList.append(StringUtils.getFormattedTimeWithDiff(dateFormat, attempt.getLong(JobHistory.Keys.START_TIME), 0L)).append("\t");
/*     */ 
/* 252 */           if (JobHistory.Values.REDUCE.name().equals(taskType)) {
/* 253 */             JobHistory.ReduceAttempt reduceAttempt = (JobHistory.ReduceAttempt)attempt;
/* 254 */             taskList.append(StringUtils.getFormattedTimeWithDiff(dateFormat, reduceAttempt.getLong(JobHistory.Keys.SHUFFLE_FINISHED), reduceAttempt.getLong(JobHistory.Keys.START_TIME)));
/*     */ 
/* 257 */             taskList.append("\t");
/* 258 */             taskList.append(StringUtils.getFormattedTimeWithDiff(dateFormat, reduceAttempt.getLong(JobHistory.Keys.SORT_FINISHED), reduceAttempt.getLong(JobHistory.Keys.SHUFFLE_FINISHED)));
/*     */           }
/*     */ 
/* 262 */           taskList.append(StringUtils.getFormattedTimeWithDiff(dateFormat, attempt.getLong(JobHistory.Keys.FINISH_TIME), attempt.getLong(JobHistory.Keys.START_TIME)));
/*     */ 
/* 265 */           taskList.append("\t");
/* 266 */           taskList.append(attempt.get(JobHistory.Keys.HOSTNAME)).append("\t");
/* 267 */           taskList.append(attempt.get(JobHistory.Keys.ERROR));
/* 268 */           String taskLogsUrl = JobHistory.getTaskLogsUrl(attempt);
/* 269 */           taskList.append(taskLogsUrl != null ? taskLogsUrl : "n/a");
/* 270 */           System.out.println(taskList.toString());
/*     */         } }
/*     */     JobHistory.Task task;
/*     */   }
/*     */ 
/*     */   private void printTaskSummary()
/*     */   {
/* 277 */     Map tasks = this.job.getAllTasks();
/* 278 */     int totalMaps = 0;
/* 279 */     int totalReduces = 0;
/* 280 */     int totalCleanups = 0;
/* 281 */     int totalSetups = 0;
/* 282 */     int numFailedMaps = 0;
/* 283 */     int numKilledMaps = 0;
/* 284 */     int numFailedReduces = 0;
/* 285 */     int numKilledReduces = 0;
/* 286 */     int numFinishedCleanups = 0;
/* 287 */     int numFailedCleanups = 0;
/* 288 */     int numKilledCleanups = 0;
/* 289 */     int numFinishedSetups = 0;
/* 290 */     int numFailedSetups = 0;
/* 291 */     int numKilledSetups = 0;
/* 292 */     long mapStarted = 0L;
/* 293 */     long mapFinished = 0L;
/* 294 */     long reduceStarted = 0L;
/* 295 */     long reduceFinished = 0L;
/* 296 */     long cleanupStarted = 0L;
/* 297 */     long cleanupFinished = 0L;
/* 298 */     long setupStarted = 0L;
/* 299 */     long setupFinished = 0L;
/*     */ 
/* 301 */     Map allHosts = new TreeMap();
/*     */ 
/* 303 */     for (Iterator i$ = tasks.values().iterator(); i$.hasNext(); ) { task = (JobHistory.Task)i$.next();
/* 304 */       Map attempts = task.getTaskAttempts();
/* 305 */       allHosts.put(task.get(JobHistory.Keys.HOSTNAME), "");
/* 306 */       for (JobHistory.TaskAttempt attempt : attempts.values()) {
/* 307 */         long startTime = attempt.getLong(JobHistory.Keys.START_TIME);
/* 308 */         long finishTime = attempt.getLong(JobHistory.Keys.FINISH_TIME);
/* 309 */         if (JobHistory.Values.MAP.name().equals(task.get(JobHistory.Keys.TASK_TYPE))) {
/* 310 */           if ((mapStarted == 0L) || (mapStarted > startTime)) {
/* 311 */             mapStarted = startTime;
/*     */           }
/* 313 */           if (mapFinished < finishTime) {
/* 314 */             mapFinished = finishTime;
/*     */           }
/* 316 */           totalMaps++;
/* 317 */           if (JobHistory.Values.FAILED.name().equals(attempt.get(JobHistory.Keys.TASK_STATUS)))
/* 318 */             numFailedMaps++;
/* 319 */           else if (JobHistory.Values.KILLED.name().equals(attempt.get(JobHistory.Keys.TASK_STATUS)))
/*     */           {
/* 321 */             numKilledMaps++;
/*     */           }
/* 323 */         } else if (JobHistory.Values.REDUCE.name().equals(task.get(JobHistory.Keys.TASK_TYPE))) {
/* 324 */           if ((reduceStarted == 0L) || (reduceStarted > startTime)) {
/* 325 */             reduceStarted = startTime;
/*     */           }
/* 327 */           if (reduceFinished < finishTime) {
/* 328 */             reduceFinished = finishTime;
/*     */           }
/* 330 */           totalReduces++;
/* 331 */           if (JobHistory.Values.FAILED.name().equals(attempt.get(JobHistory.Keys.TASK_STATUS)))
/* 332 */             numFailedReduces++;
/* 333 */           else if (JobHistory.Values.KILLED.name().equals(attempt.get(JobHistory.Keys.TASK_STATUS)))
/*     */           {
/* 335 */             numKilledReduces++;
/*     */           }
/* 337 */         } else if (JobHistory.Values.CLEANUP.name().equals(task.get(JobHistory.Keys.TASK_TYPE))) {
/* 338 */           if ((cleanupStarted == 0L) || (cleanupStarted > startTime)) {
/* 339 */             cleanupStarted = startTime;
/*     */           }
/* 341 */           if (cleanupFinished < finishTime) {
/* 342 */             cleanupFinished = finishTime;
/*     */           }
/* 344 */           totalCleanups++;
/* 345 */           if (JobHistory.Values.SUCCESS.name().equals(attempt.get(JobHistory.Keys.TASK_STATUS)))
/* 346 */             numFinishedCleanups++;
/* 347 */           else if (JobHistory.Values.FAILED.name().equals(attempt.get(JobHistory.Keys.TASK_STATUS)))
/*     */           {
/* 349 */             numFailedCleanups++;
/* 350 */           } else if (JobHistory.Values.KILLED.name().equals(attempt.get(JobHistory.Keys.TASK_STATUS)))
/*     */           {
/* 352 */             numKilledCleanups++;
/*     */           }
/* 354 */         } else if (JobHistory.Values.SETUP.name().equals(task.get(JobHistory.Keys.TASK_TYPE))) {
/* 355 */           if ((setupStarted == 0L) || (setupStarted > startTime)) {
/* 356 */             setupStarted = startTime;
/*     */           }
/* 358 */           if (setupFinished < finishTime) {
/* 359 */             setupFinished = finishTime;
/*     */           }
/* 361 */           totalSetups++;
/* 362 */           if (JobHistory.Values.SUCCESS.name().equals(attempt.get(JobHistory.Keys.TASK_STATUS)))
/* 363 */             numFinishedSetups++;
/* 364 */           else if (JobHistory.Values.FAILED.name().equals(attempt.get(JobHistory.Keys.TASK_STATUS)))
/*     */           {
/* 366 */             numFailedSetups++;
/* 367 */           } else if (JobHistory.Values.KILLED.name().equals(attempt.get(JobHistory.Keys.TASK_STATUS)))
/*     */           {
/* 369 */             numKilledSetups++;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     JobHistory.Task task;
/* 375 */     StringBuffer taskSummary = new StringBuffer();
/* 376 */     taskSummary.append("\nTask Summary");
/* 377 */     taskSummary.append("\n============================");
/* 378 */     taskSummary.append("\nKind\tTotal\t");
/* 379 */     taskSummary.append("Successful\tFailed\tKilled\tStartTime\tFinishTime");
/* 380 */     taskSummary.append("\n");
/* 381 */     taskSummary.append("\nSetup\t").append(totalSetups);
/* 382 */     taskSummary.append("\t").append(numFinishedSetups);
/* 383 */     taskSummary.append("\t\t").append(numFailedSetups);
/* 384 */     taskSummary.append("\t").append(numKilledSetups);
/* 385 */     taskSummary.append("\t").append(StringUtils.getFormattedTimeWithDiff(dateFormat, setupStarted, 0L));
/*     */ 
/* 387 */     taskSummary.append("\t").append(StringUtils.getFormattedTimeWithDiff(dateFormat, setupFinished, setupStarted));
/*     */ 
/* 389 */     taskSummary.append("\nMap\t").append(totalMaps);
/* 390 */     taskSummary.append("\t").append(this.job.getInt(JobHistory.Keys.FINISHED_MAPS));
/* 391 */     taskSummary.append("\t\t").append(numFailedMaps);
/* 392 */     taskSummary.append("\t").append(numKilledMaps);
/* 393 */     taskSummary.append("\t").append(StringUtils.getFormattedTimeWithDiff(dateFormat, mapStarted, 0L));
/*     */ 
/* 395 */     taskSummary.append("\t").append(StringUtils.getFormattedTimeWithDiff(dateFormat, mapFinished, mapStarted));
/*     */ 
/* 397 */     taskSummary.append("\nReduce\t").append(totalReduces);
/* 398 */     taskSummary.append("\t").append(this.job.getInt(JobHistory.Keys.FINISHED_REDUCES));
/* 399 */     taskSummary.append("\t\t").append(numFailedReduces);
/* 400 */     taskSummary.append("\t").append(numKilledReduces);
/* 401 */     taskSummary.append("\t").append(StringUtils.getFormattedTimeWithDiff(dateFormat, reduceStarted, 0L));
/*     */ 
/* 403 */     taskSummary.append("\t").append(StringUtils.getFormattedTimeWithDiff(dateFormat, reduceFinished, reduceStarted));
/*     */ 
/* 405 */     taskSummary.append("\nCleanup\t").append(totalCleanups);
/* 406 */     taskSummary.append("\t").append(numFinishedCleanups);
/* 407 */     taskSummary.append("\t\t").append(numFailedCleanups);
/* 408 */     taskSummary.append("\t").append(numKilledCleanups);
/* 409 */     taskSummary.append("\t").append(StringUtils.getFormattedTimeWithDiff(dateFormat, cleanupStarted, 0L));
/*     */ 
/* 411 */     taskSummary.append("\t").append(StringUtils.getFormattedTimeWithDiff(dateFormat, cleanupFinished, cleanupStarted));
/*     */ 
/* 413 */     taskSummary.append("\n============================\n");
/* 414 */     System.out.println(taskSummary.toString());
/*     */   }
/*     */ 
/*     */   private void printFailedAttempts(DefaultJobHistoryParser.NodesFilter filter) throws IOException {
/* 418 */     JobHistory.parseHistoryFromFS(this.jobLogFile, filter, this.fs);
/* 419 */     Map badNodes = filter.getValues();
/* 420 */     StringBuffer attempts = new StringBuffer();
/* 421 */     if (badNodes.size() > 0) {
/* 422 */       attempts.append("\n").append(filter.getFailureType());
/* 423 */       attempts.append(" task attempts by nodes");
/* 424 */       attempts.append("\nHostname\tFailedTasks");
/* 425 */       attempts.append("\n===============================");
/* 426 */       System.out.println(attempts.toString());
/* 427 */       for (Map.Entry entry : badNodes.entrySet()) {
/* 428 */         String node = (String)entry.getKey();
/* 429 */         Set failedTasks = (Set)entry.getValue();
/* 430 */         attempts.setLength(0);
/* 431 */         attempts.append(node).append("\t");
/* 432 */         for (String t : failedTasks) {
/* 433 */           attempts.append(t).append(", ");
/*     */         }
/* 435 */         System.out.println(attempts.toString());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void printJobAnalysis() {
/* 441 */     if (!JobHistory.Values.SUCCESS.name().equals(this.job.get(JobHistory.Keys.JOB_STATUS))) {
/* 442 */       System.out.println("No Analysis available as job did not finish");
/* 443 */       return;
/*     */     }
/*     */ 
/* 446 */     Map tasks = this.job.getAllTasks();
/* 447 */     int finishedMaps = this.job.getInt(JobHistory.Keys.FINISHED_MAPS);
/* 448 */     int finishedReduces = this.job.getInt(JobHistory.Keys.FINISHED_REDUCES);
/* 449 */     JobHistory.Task[] mapTasks = new JobHistory.Task[finishedMaps];
/* 450 */     JobHistory.Task[] reduceTasks = new JobHistory.Task[finishedReduces];
/* 451 */     int mapIndex = 0; int reduceIndex = 0;
/* 452 */     long avgMapTime = 0L;
/* 453 */     long avgReduceTime = 0L;
/* 454 */     long avgShuffleTime = 0L;
/*     */ 
/* 456 */     for (Iterator i$ = tasks.values().iterator(); i$.hasNext(); ) { task = (JobHistory.Task)i$.next();
/* 457 */       Map attempts = task.getTaskAttempts();
/* 458 */       for (JobHistory.TaskAttempt attempt : attempts.values())
/* 459 */         if (attempt.get(JobHistory.Keys.TASK_STATUS).equals(JobHistory.Values.SUCCESS.name())) {
/* 460 */           long avgFinishTime = attempt.getLong(JobHistory.Keys.FINISH_TIME) - attempt.getLong(JobHistory.Keys.START_TIME);
/*     */ 
/* 462 */           if (JobHistory.Values.MAP.name().equals(task.get(JobHistory.Keys.TASK_TYPE))) {
/* 463 */             mapTasks[(mapIndex++)] = attempt;
/* 464 */             avgMapTime += avgFinishTime; break;
/* 465 */           }if (!JobHistory.Values.REDUCE.name().equals(task.get(JobHistory.Keys.TASK_TYPE))) break;
/* 466 */           reduceTasks[(reduceIndex++)] = attempt;
/* 467 */           avgShuffleTime += attempt.getLong(JobHistory.Keys.SHUFFLE_FINISHED) - attempt.getLong(JobHistory.Keys.START_TIME);
/*     */ 
/* 469 */           avgReduceTime += attempt.getLong(JobHistory.Keys.FINISH_TIME) - attempt.getLong(JobHistory.Keys.SHUFFLE_FINISHED); break;
/*     */         }
/*     */     }
/*     */     JobHistory.Task task;
/* 476 */     if (finishedMaps > 0) {
/* 477 */       avgMapTime /= finishedMaps;
/*     */     }
/* 479 */     if (finishedReduces > 0) {
/* 480 */       avgReduceTime /= finishedReduces;
/* 481 */       avgShuffleTime /= finishedReduces;
/*     */     }
/* 483 */     System.out.println("\nAnalysis");
/* 484 */     System.out.println("=========");
/* 485 */     printAnalysis(mapTasks, this.cMap, "map", avgMapTime, 10);
/* 486 */     printLast(mapTasks, "map", this.cFinishMapRed);
/*     */ 
/* 488 */     if (reduceTasks.length > 0) {
/* 489 */       printAnalysis(reduceTasks, this.cShuffle, "shuffle", avgShuffleTime, 10);
/* 490 */       printLast(reduceTasks, "shuffle", this.cFinishShuffle);
/*     */ 
/* 492 */       printAnalysis(reduceTasks, this.cReduce, "reduce", avgReduceTime, 10);
/* 493 */       printLast(reduceTasks, "reduce", this.cFinishMapRed);
/*     */     }
/* 495 */     System.out.println("=========");
/*     */   }
/*     */ 
/*     */   private void printLast(JobHistory.Task[] tasks, String taskType, Comparator<JobHistory.Task> cmp)
/*     */   {
/* 502 */     Arrays.sort(tasks, this.cFinishMapRed);
/* 503 */     JobHistory.Task last = tasks[0];
/* 504 */     StringBuffer lastBuf = new StringBuffer();
/* 505 */     lastBuf.append("The last ").append(taskType);
/* 506 */     lastBuf.append(" task ").append(last.get(JobHistory.Keys.TASKID));
/*     */     Long finishTime;
/*     */     Long finishTime;
/* 508 */     if ("shuffle".equals(taskType))
/* 509 */       finishTime = Long.valueOf(last.getLong(JobHistory.Keys.SHUFFLE_FINISHED));
/*     */     else {
/* 511 */       finishTime = Long.valueOf(last.getLong(JobHistory.Keys.FINISH_TIME));
/*     */     }
/* 513 */     lastBuf.append(" finished at (relative to the Job launch time): ");
/* 514 */     lastBuf.append(StringUtils.getFormattedTimeWithDiff(dateFormat, finishTime.longValue(), this.job.getLong(JobHistory.Keys.LAUNCH_TIME)));
/*     */ 
/* 516 */     System.out.println(lastBuf.toString());
/*     */   }
/*     */ 
/*     */   private void printAnalysis(JobHistory.Task[] tasks, Comparator<JobHistory.Task> cmp, String taskType, long avg, int showTasks)
/*     */   {
/* 524 */     Arrays.sort(tasks, cmp);
/* 525 */     JobHistory.Task min = tasks[(tasks.length - 1)];
/* 526 */     StringBuffer details = new StringBuffer();
/* 527 */     details.append("\nTime taken by best performing ");
/* 528 */     details.append(taskType).append(" task ");
/* 529 */     details.append(min.get(JobHistory.Keys.TASKID)).append(": ");
/* 530 */     if ("map".equals(taskType)) {
/* 531 */       details.append(StringUtils.formatTimeDiff(min.getLong(JobHistory.Keys.FINISH_TIME), min.getLong(JobHistory.Keys.START_TIME)));
/*     */     }
/* 534 */     else if ("shuffle".equals(taskType)) {
/* 535 */       details.append(StringUtils.formatTimeDiff(min.getLong(JobHistory.Keys.SHUFFLE_FINISHED), min.getLong(JobHistory.Keys.START_TIME)));
/*     */     }
/*     */     else
/*     */     {
/* 539 */       details.append(StringUtils.formatTimeDiff(min.getLong(JobHistory.Keys.FINISH_TIME), min.getLong(JobHistory.Keys.SHUFFLE_FINISHED)));
/*     */     }
/*     */ 
/* 543 */     details.append("\nAverage time taken by ");
/* 544 */     details.append(taskType).append(" tasks: ");
/* 545 */     details.append(StringUtils.formatTimeDiff(avg, 0L));
/* 546 */     details.append("\nWorse performing ");
/* 547 */     details.append(taskType).append(" tasks: ");
/* 548 */     details.append("\nTaskId\t\tTimetaken");
/* 549 */     System.out.println(details.toString());
/* 550 */     for (int i = 0; (i < showTasks) && (i < tasks.length); i++) {
/* 551 */       details.setLength(0);
/* 552 */       details.append(tasks[i].get(JobHistory.Keys.TASKID)).append(" ");
/* 553 */       if ("map".equals(taskType)) {
/* 554 */         details.append(StringUtils.formatTimeDiff(tasks[i].getLong(JobHistory.Keys.FINISH_TIME), tasks[i].getLong(JobHistory.Keys.START_TIME)));
/*     */       }
/* 557 */       else if ("shuffle".equals(taskType)) {
/* 558 */         details.append(StringUtils.formatTimeDiff(tasks[i].getLong(JobHistory.Keys.SHUFFLE_FINISHED), tasks[i].getLong(JobHistory.Keys.START_TIME)));
/*     */       }
/*     */       else
/*     */       {
/* 562 */         details.append(StringUtils.formatTimeDiff(tasks[i].getLong(JobHistory.Keys.FINISH_TIME), tasks[i].getLong(JobHistory.Keys.SHUFFLE_FINISHED)));
/*     */       }
/*     */ 
/* 566 */       System.out.println(details.toString());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.HistoryViewer
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.fs.FSDataOutputStream;
/*     */ import org.apache.hadoop.fs.FileStatus;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.util.Progressable;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ public class FileOutputCommitter extends OutputCommitter
/*     */ {
/*  36 */   public static final Log LOG = LogFactory.getLog("org.apache.hadoop.mapred.FileOutputCommitter");
/*     */   public static final String TEMP_DIR_NAME = "_temporary";
/*     */   public static final String SUCCEEDED_FILE_NAME = "_SUCCESS";
/*     */   static final String SUCCESSFUL_JOB_OUTPUT_DIR_MARKER = "mapreduce.fileoutputcommitter.marksuccessfuljobs";
/*     */ 
/*     */   public void setupJob(JobContext context)
/*     */     throws IOException
/*     */   {
/*  47 */     JobConf conf = context.getJobConf();
/*  48 */     Path outputPath = FileOutputFormat.getOutputPath(conf);
/*  49 */     if (outputPath != null) {
/*  50 */       Path tmpDir = new Path(outputPath, "_temporary");
/*  51 */       FileSystem fileSys = tmpDir.getFileSystem(conf);
/*  52 */       if (!fileSys.mkdirs(tmpDir))
/*  53 */         LOG.error("Mkdirs failed to create " + tmpDir.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   private static boolean getOutputDirMarking(JobConf conf)
/*     */   {
/*  59 */     return conf.getBoolean("mapreduce.fileoutputcommitter.marksuccessfuljobs", true);
/*     */   }
/*     */ 
/*     */   private void markSuccessfulOutputDir(JobContext context)
/*     */     throws IOException
/*     */   {
/*  66 */     JobConf conf = context.getJobConf();
/*  67 */     Path outputPath = FileOutputFormat.getOutputPath(conf);
/*  68 */     if (outputPath != null) {
/*  69 */       FileSystem fileSys = outputPath.getFileSystem(conf);
/*     */ 
/*  71 */       if (fileSys.exists(outputPath)) {
/*  72 */         Path filePath = new Path(outputPath, "_SUCCESS");
/*  73 */         fileSys.create(filePath).close();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void commitJob(JobContext context) throws IOException
/*     */   {
/*  80 */     cleanupJob(context);
/*  81 */     if (getOutputDirMarking(context.getJobConf()))
/*  82 */       markSuccessfulOutputDir(context);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void cleanupJob(JobContext context)
/*     */     throws IOException
/*     */   {
/*  89 */     JobConf conf = context.getJobConf();
/*     */ 
/*  91 */     Path outputPath = FileOutputFormat.getOutputPath(conf);
/*  92 */     if (outputPath != null) {
/*  93 */       Path tmpDir = new Path(outputPath, "_temporary");
/*  94 */       FileSystem fileSys = tmpDir.getFileSystem(conf);
/*  95 */       context.getProgressible().progress();
/*  96 */       if (fileSys.exists(tmpDir))
/*  97 */         fileSys.delete(tmpDir, true);
/*     */     }
/*     */     else {
/* 100 */       LOG.warn("Output path is null in cleanup");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void abortJob(JobContext context, int runState)
/*     */     throws IOException
/*     */   {
/* 112 */     cleanupJob(context);
/*     */   }
/*     */ 
/*     */   public void setupTask(TaskAttemptContext context)
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void commitTask(TaskAttemptContext context)
/*     */     throws IOException
/*     */   {
/* 123 */     Path taskOutputPath = getTempTaskOutputPath(context);
/* 124 */     TaskAttemptID attemptId = context.getTaskAttemptID();
/* 125 */     JobConf job = context.getJobConf();
/* 126 */     if (taskOutputPath != null) {
/* 127 */       FileSystem fs = taskOutputPath.getFileSystem(job);
/* 128 */       context.getProgressible().progress();
/* 129 */       if (fs.exists(taskOutputPath)) {
/* 130 */         Path jobOutputPath = taskOutputPath.getParent().getParent();
/*     */ 
/* 132 */         moveTaskOutputs(context, fs, jobOutputPath, taskOutputPath);
/*     */ 
/* 134 */         if (!fs.delete(taskOutputPath, true)) {
/* 135 */           LOG.info("Failed to delete the temporary output directory of task: " + attemptId + " - " + taskOutputPath);
/*     */         }
/*     */ 
/* 138 */         LOG.info("Saved output of task '" + attemptId + "' to " + jobOutputPath);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void moveTaskOutputs(TaskAttemptContext context, FileSystem fs, Path jobOutputDir, Path taskOutput)
/*     */     throws IOException
/*     */   {
/* 149 */     TaskAttemptID attemptId = context.getTaskAttemptID();
/* 150 */     context.getProgressible().progress();
/* 151 */     if (fs.isFile(taskOutput)) {
/* 152 */       Path finalOutputPath = getFinalPath(jobOutputDir, taskOutput, getTempTaskOutputPath(context));
/*     */ 
/* 154 */       if (!fs.rename(taskOutput, finalOutputPath)) {
/* 155 */         if (!fs.delete(finalOutputPath, true)) {
/* 156 */           throw new IOException("Failed to delete earlier output of task: " + attemptId);
/*     */         }
/*     */ 
/* 159 */         if (!fs.rename(taskOutput, finalOutputPath)) {
/* 160 */           throw new IOException("Failed to save output of task: " + attemptId);
/*     */         }
/*     */       }
/*     */ 
/* 164 */       LOG.debug("Moved " + taskOutput + " to " + finalOutputPath);
/* 165 */     } else if (fs.getFileStatus(taskOutput).isDir()) {
/* 166 */       FileStatus[] paths = fs.listStatus(taskOutput);
/* 167 */       Path finalOutputPath = getFinalPath(jobOutputDir, taskOutput, getTempTaskOutputPath(context));
/*     */ 
/* 169 */       fs.mkdirs(finalOutputPath);
/* 170 */       if (paths != null)
/* 171 */         for (FileStatus path : paths)
/* 172 */           moveTaskOutputs(context, fs, jobOutputDir, path.getPath());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void abortTask(TaskAttemptContext context)
/*     */     throws IOException
/*     */   {
/* 179 */     Path taskOutputPath = getTempTaskOutputPath(context);
/*     */     try {
/* 181 */       if (taskOutputPath != null) {
/* 182 */         FileSystem fs = taskOutputPath.getFileSystem(context.getJobConf());
/* 183 */         context.getProgressible().progress();
/* 184 */         fs.delete(taskOutputPath, true);
/*     */       }
/*     */     } catch (IOException ie) {
/* 187 */       LOG.warn("Error discarding output" + StringUtils.stringifyException(ie));
/*     */     }
/*     */   }
/*     */ 
/*     */   private Path getFinalPath(Path jobOutputDir, Path taskOutput, Path taskOutputPath) throws IOException
/*     */   {
/* 193 */     URI taskOutputUri = taskOutput.toUri();
/* 194 */     URI relativePath = taskOutputPath.toUri().relativize(taskOutputUri);
/* 195 */     if (taskOutputUri == relativePath) {
/* 196 */       throw new IOException("Can not get the relative path: base = " + taskOutputPath + " child = " + taskOutput);
/*     */     }
/*     */ 
/* 199 */     if (relativePath.getPath().length() > 0) {
/* 200 */       return new Path(jobOutputDir, relativePath.getPath());
/*     */     }
/* 202 */     return jobOutputDir;
/*     */   }
/*     */ 
/*     */   public boolean needsTaskCommit(TaskAttemptContext context) throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 209 */       Path taskOutputPath = getTempTaskOutputPath(context);
/* 210 */       if (taskOutputPath != null) {
/* 211 */         context.getProgressible().progress();
/*     */ 
/* 213 */         FileSystem fs = taskOutputPath.getFileSystem(context.getJobConf());
/*     */ 
/* 216 */         if (fs.exists(taskOutputPath))
/* 217 */           return true;
/*     */       }
/*     */     }
/*     */     catch (IOException ioe) {
/* 221 */       throw ioe;
/*     */     }
/* 223 */     return false;
/*     */   }
/*     */ 
/*     */   Path getTempTaskOutputPath(TaskAttemptContext taskContext) {
/* 227 */     JobConf conf = taskContext.getJobConf();
/* 228 */     Path outputPath = FileOutputFormat.getOutputPath(conf);
/* 229 */     if (outputPath != null) {
/* 230 */       Path p = new Path(outputPath, "_temporary/_" + taskContext.getTaskAttemptID().toString());
/*     */       try
/*     */       {
/* 234 */         FileSystem fs = p.getFileSystem(conf);
/* 235 */         return p.makeQualified(fs);
/*     */       } catch (IOException ie) {
/* 237 */         LOG.warn(StringUtils.stringifyException(ie));
/* 238 */         return p;
/*     */       }
/*     */     }
/* 241 */     return null;
/*     */   }
/*     */ 
/*     */   Path getWorkPath(TaskAttemptContext taskContext, Path basePath)
/*     */     throws IOException
/*     */   {
/* 247 */     Path jobTmpDir = new Path(basePath, "_temporary");
/* 248 */     FileSystem fs = jobTmpDir.getFileSystem(taskContext.getJobConf());
/* 249 */     if (!fs.exists(jobTmpDir)) {
/* 250 */       throw new IOException("The temporary job-output directory " + jobTmpDir.toString() + " doesn't exist!");
/*     */     }
/*     */ 
/* 254 */     String taskid = taskContext.getTaskAttemptID().toString();
/* 255 */     Path taskTmpDir = new Path(jobTmpDir, "_" + taskid);
/* 256 */     if (!fs.mkdirs(taskTmpDir)) {
/* 257 */       throw new IOException("Mkdirs failed to create " + taskTmpDir.toString());
/*     */     }
/*     */ 
/* 260 */     return taskTmpDir;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.FileOutputCommitter
 * JD-Core Version:    0.6.1
 */
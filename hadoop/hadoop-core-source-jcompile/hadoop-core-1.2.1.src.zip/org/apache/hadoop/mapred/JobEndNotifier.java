/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.DelayQueue;
/*     */ import java.util.concurrent.Delayed;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.commons.httpclient.HttpClient;
/*     */ import org.apache.commons.httpclient.HttpMethod;
/*     */ import org.apache.commons.httpclient.URI;
/*     */ import org.apache.commons.httpclient.methods.GetMethod;
/*     */ import org.apache.commons.httpclient.params.HttpClientParams;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class JobEndNotifier
/*     */ {
/*  35 */   private static final Log LOG = LogFactory.getLog(JobEndNotifier.class.getName());
/*     */   private static Thread thread;
/*     */   private static volatile boolean running;
/*  40 */   private static BlockingQueue<JobEndStatusInfo> queue = new DelayQueue();
/*     */   public static final int MAPREDUCE_JOBEND_NOTIFICATION_TIMEOUT_DEFAULT = 5000;
/*     */ 
/*     */   public static void startNotifier()
/*     */   {
/*  46 */     running = true;
/*  47 */     thread = new Thread(new Runnable()
/*     */     {
/*     */       public void run() {
/*     */         try {
/*  51 */           while (JobEndNotifier.running)
/*  52 */             sendNotification((JobEndNotifier.JobEndStatusInfo)JobEndNotifier.queue.take());
/*     */         }
/*     */         catch (InterruptedException irex)
/*     */         {
/*  56 */           if (JobEndNotifier.running)
/*  57 */             JobEndNotifier.LOG.error("Thread has ended unexpectedly", irex);
/*     */         }
/*     */       }
/*     */ 
/*     */       private void sendNotification(JobEndNotifier.JobEndStatusInfo notification)
/*     */       {
/*     */         try {
/*  64 */           int code = JobEndNotifier.httpNotification(notification.getUri(), notification.getTimeout());
/*     */ 
/*  66 */           if (code != 200)
/*  67 */             throw new IOException("Invalid response status code: " + code);
/*     */         }
/*     */         catch (IOException ioex)
/*     */         {
/*  71 */           JobEndNotifier.LOG.error("Notification failure [" + notification + "]", ioex);
/*  72 */           if (notification.configureForRetry()) {
/*     */             try {
/*  74 */               JobEndNotifier.queue.put(notification);
/*     */             }
/*     */             catch (InterruptedException iex) {
/*  77 */               JobEndNotifier.LOG.error("Notification queuing error [" + notification + "]", iex);
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (Exception ex)
/*     */         {
/*  83 */           JobEndNotifier.LOG.error("Notification failure [" + notification + "]", ex);
/*     */         }
/*     */       }
/*     */     });
/*  87 */     thread.start();
/*     */   }
/*     */ 
/*     */   public static void stopNotifier() {
/*  91 */     running = false;
/*  92 */     thread.interrupt();
/*     */   }
/*     */ 
/*     */   private static JobEndStatusInfo createNotification(JobConf conf, JobStatus status)
/*     */   {
/*  97 */     JobEndStatusInfo notification = null;
/*  98 */     String uri = conf.getJobEndNotificationURI();
/*  99 */     if (uri != null) {
/* 100 */       int retryAttempts = conf.getInt("job.end.retry.attempts", 0);
/* 101 */       long retryInterval = conf.getInt("job.end.retry.interval", 30000);
/* 102 */       int timeout = conf.getInt("mapreduce.job.end-notification.timeout", 5000);
/*     */ 
/* 104 */       if (uri.contains("$jobId")) {
/* 105 */         uri = uri.replace("$jobId", status.getJobID().toString());
/*     */       }
/* 107 */       if (uri.contains("$jobStatus")) {
/* 108 */         String statusStr = status.getRunState() == 3 ? "FAILED" : status.getRunState() == 2 ? "SUCCEEDED" : "KILLED";
/*     */ 
/* 111 */         uri = uri.replace("$jobStatus", statusStr);
/*     */       }
/* 113 */       notification = new JobEndStatusInfo(uri, retryAttempts, retryInterval, timeout);
/*     */     }
/*     */ 
/* 116 */     return notification;
/*     */   }
/*     */ 
/*     */   public static void registerNotification(JobConf jobConf, JobStatus status) {
/* 120 */     JobEndStatusInfo notification = createNotification(jobConf, status);
/* 121 */     if (notification != null)
/*     */       try {
/* 123 */         queue.put(notification);
/*     */       }
/*     */       catch (InterruptedException iex) {
/* 126 */         LOG.error("Notification queuing failure [" + notification + "]", iex);
/*     */       }
/*     */   }
/*     */ 
/*     */   private static int httpNotification(String uri, int timeout)
/*     */     throws IOException
/*     */   {
/* 133 */     URI url = new URI(uri, false);
/*     */ 
/* 135 */     HttpClient httpClient = new HttpClient();
/* 136 */     httpClient.getParams().setSoTimeout(timeout);
/* 137 */     httpClient.getParams().setConnectionManagerTimeout(timeout);
/*     */ 
/* 139 */     HttpMethod method = new GetMethod(url.getEscapedURI());
/* 140 */     method.setRequestHeader("Accept", "*/*");
/* 141 */     return httpClient.executeMethod(method);
/*     */   }
/*     */ 
/*     */   public static void localRunnerNotification(JobConf conf, JobStatus status)
/*     */   {
/* 147 */     JobEndStatusInfo notification = createNotification(conf, status);
/* 148 */     if (notification != null)
/*     */       do {
/*     */         try {
/* 151 */           int code = httpNotification(notification.getUri(), notification.getTimeout());
/*     */ 
/* 153 */           if (code != 200) {
/* 154 */             throw new IOException("Invalid response status code: " + code);
/*     */           }
/*     */ 
/*     */         }
/*     */         catch (IOException ioex)
/*     */         {
/* 161 */           LOG.error("Notification error [" + notification.getUri() + "]", ioex);
/*     */         }
/*     */         catch (Exception ex) {
/* 164 */           LOG.error("Notification error [" + notification.getUri() + "]", ex);
/*     */         }
/*     */         try {
/* 167 */           synchronized (Thread.currentThread()) {
/* 168 */             Thread.sleep(notification.getRetryInterval());
/*     */           }
/*     */         }
/*     */         catch (InterruptedException iex) {
/* 172 */           LOG.error("Notification retry error [" + notification + "]", iex);
/*     */         }
/*     */       }
/* 174 */       while (notification.configureForRetry()); 
/*     */   }
/*     */   private static class JobEndStatusInfo implements Delayed {
/*     */     private String uri;
/*     */     private int retryAttempts;
/*     */     private long retryInterval;
/*     */     private long delayTime;
/*     */     private int timeout;
/*     */ 
/* 187 */     JobEndStatusInfo(String uri, int retryAttempts, long retryInterval, int timeout) { this.uri = uri;
/* 188 */       this.retryAttempts = retryAttempts;
/* 189 */       this.retryInterval = retryInterval;
/* 190 */       this.timeout = timeout;
/* 191 */       this.delayTime = System.currentTimeMillis(); }
/*     */ 
/*     */     public String getUri()
/*     */     {
/* 195 */       return this.uri;
/*     */     }
/*     */ 
/*     */     public int getRetryAttempts() {
/* 199 */       return this.retryAttempts;
/*     */     }
/*     */ 
/*     */     public long getRetryInterval() {
/* 203 */       return this.retryInterval;
/*     */     }
/*     */ 
/*     */     public int getTimeout() {
/* 207 */       return this.timeout;
/*     */     }
/*     */ 
/*     */     public long getDelayTime() {
/* 211 */       return this.delayTime;
/*     */     }
/*     */ 
/*     */     public boolean configureForRetry() {
/* 215 */       boolean retry = false;
/* 216 */       if (getRetryAttempts() > 0) {
/* 217 */         retry = true;
/* 218 */         this.delayTime = (System.currentTimeMillis() + this.retryInterval);
/*     */       }
/* 220 */       this.retryAttempts -= 1;
/* 221 */       return retry;
/*     */     }
/*     */ 
/*     */     public long getDelay(TimeUnit unit) {
/* 225 */       long n = this.delayTime - System.currentTimeMillis();
/* 226 */       return unit.convert(n, TimeUnit.MILLISECONDS);
/*     */     }
/*     */ 
/*     */     public int compareTo(Delayed d) {
/* 230 */       return (int)(this.delayTime - ((JobEndStatusInfo)d).delayTime);
/*     */     }
/*     */ 
/*     */     public boolean equals(Object o)
/*     */     {
/* 235 */       if (!(o instanceof JobEndStatusInfo)) {
/* 236 */         return false;
/*     */       }
/* 238 */       if (this.delayTime == ((JobEndStatusInfo)o).delayTime) {
/* 239 */         return true;
/*     */       }
/* 241 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 246 */       return 629 + (int)(this.delayTime ^ this.delayTime >>> 32);
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 251 */       return "URL: " + this.uri + " remaining retries: " + this.retryAttempts + " interval: " + this.retryInterval;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JobEndNotifier
 * JD-Core Version:    0.6.1
 */
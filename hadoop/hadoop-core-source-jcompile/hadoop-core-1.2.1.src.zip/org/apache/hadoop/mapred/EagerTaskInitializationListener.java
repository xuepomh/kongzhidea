/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ 
/*     */ class EagerTaskInitializationListener extends JobInProgressListener
/*     */ {
/*     */   private static final int DEFAULT_NUM_THREADS = 4;
/*  41 */   private static final Log LOG = LogFactory.getLog(EagerTaskInitializationListener.class.getName());
/*     */ 
/*  83 */   private JobInitManager jobInitManager = new JobInitManager();
/*     */   private Thread jobInitManagerThread;
/*  85 */   private List<JobInProgress> jobInitQueue = new ArrayList();
/*     */   private ExecutorService threadPool;
/*     */   private int numThreads;
/*     */   private TaskTrackerManager ttm;
/*     */ 
/*     */   public EagerTaskInitializationListener(Configuration conf)
/*     */   {
/*  91 */     this.numThreads = conf.getInt("mapred.jobinit.threads", 4);
/*  92 */     this.threadPool = Executors.newFixedThreadPool(this.numThreads);
/*     */   }
/*     */ 
/*     */   public void setTaskTrackerManager(TaskTrackerManager ttm) {
/*  96 */     this.ttm = ttm;
/*     */   }
/*     */ 
/*     */   public void start() throws IOException {
/* 100 */     this.jobInitManagerThread = new Thread(this.jobInitManager, "jobInitManager");
/* 101 */     this.jobInitManagerThread.setDaemon(true);
/* 102 */     this.jobInitManagerThread.start();
/*     */   }
/*     */ 
/*     */   public void terminate() throws IOException {
/* 106 */     if ((this.jobInitManagerThread != null) && (this.jobInitManagerThread.isAlive())) {
/* 107 */       LOG.info("Stopping Job Init Manager thread");
/* 108 */       this.jobInitManagerThread.interrupt();
/*     */       try {
/* 110 */         this.jobInitManagerThread.join();
/*     */       } catch (InterruptedException ex) {
/* 112 */         ex.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void jobAdded(JobInProgress job)
/*     */   {
/* 124 */     synchronized (this.jobInitQueue) {
/* 125 */       this.jobInitQueue.add(job);
/* 126 */       resortInitQueue();
/* 127 */       this.jobInitQueue.notifyAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized void resortInitQueue()
/*     */   {
/* 136 */     Comparator comp = new Comparator() {
/*     */       public int compare(JobInProgress o1, JobInProgress o2) {
/* 138 */         int res = o1.getPriority().compareTo(o2.getPriority());
/* 139 */         if (res == 0) {
/* 140 */           if (o1.getStartTime() < o2.getStartTime())
/* 141 */             res = -1;
/*     */           else {
/* 143 */             res = o1.getStartTime() == o2.getStartTime() ? 0 : 1;
/*     */           }
/*     */         }
/* 146 */         return res;
/*     */       }
/*     */     };
/* 150 */     synchronized (this.jobInitQueue) {
/* 151 */       Collections.sort(this.jobInitQueue, comp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void jobRemoved(JobInProgress job)
/*     */   {
/* 157 */     synchronized (this.jobInitQueue) {
/* 158 */       this.jobInitQueue.remove(job);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void jobUpdated(JobChangeEvent event)
/*     */   {
/* 164 */     if ((event instanceof JobStatusChangeEvent))
/* 165 */       jobStateChanged((JobStatusChangeEvent)event);
/*     */   }
/*     */ 
/*     */   private void jobStateChanged(JobStatusChangeEvent event)
/*     */   {
/* 172 */     if ((event.getEventType() == JobStatusChangeEvent.EventType.START_TIME_CHANGED) || (event.getEventType() == JobStatusChangeEvent.EventType.PRIORITY_CHANGED))
/*     */     {
/* 174 */       synchronized (this.jobInitQueue) {
/* 175 */         resortInitQueue();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   class InitJob
/*     */     implements Runnable
/*     */   {
/*     */     private JobInProgress job;
/*     */ 
/*     */     public InitJob(JobInProgress job)
/*     */     {
/*  75 */       this.job = job;
/*     */     }
/*     */ 
/*     */     public void run() {
/*  79 */       EagerTaskInitializationListener.this.ttm.initJob(this.job);
/*     */     }
/*     */   }
/*     */ 
/*     */   class JobInitManager
/*     */     implements Runnable
/*     */   {
/*     */     JobInitManager()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/*  50 */       JobInProgress job = null;
/*     */       try {
/*     */         while (true) {
/*  53 */           synchronized (EagerTaskInitializationListener.this.jobInitQueue) {
/*  54 */             if (EagerTaskInitializationListener.this.jobInitQueue.isEmpty()) {
/*  55 */               EagerTaskInitializationListener.this.jobInitQueue.wait(); continue;
/*     */             }
/*  57 */             job = (JobInProgress)EagerTaskInitializationListener.this.jobInitQueue.remove(0);
/*     */           }
/*  59 */           EagerTaskInitializationListener.this.threadPool.execute(new EagerTaskInitializationListener.InitJob(EagerTaskInitializationListener.this, job));
/*     */         }
/*     */       } catch (InterruptedException t) { EagerTaskInitializationListener.LOG.info("JobInitManagerThread interrupted.");
/*     */ 
/*  65 */         EagerTaskInitializationListener.LOG.info("Shutting down thread pool");
/*  66 */         EagerTaskInitializationListener.this.threadPool.shutdownNow();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.EagerTaskInitializationListener
 * JD-Core Version:    0.6.1
 */
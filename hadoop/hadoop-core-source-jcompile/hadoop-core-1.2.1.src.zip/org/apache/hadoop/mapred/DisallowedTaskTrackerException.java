/*    */ package org.apache.hadoop.mapred;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ class DisallowedTaskTrackerException extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public DisallowedTaskTrackerException(TaskTrackerStatus tracker)
/*    */   {
/* 35 */     super("Tasktracker denied communication with jobtracker: " + tracker.getTrackerName());
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.DisallowedTaskTrackerException
 * JD-Core Version:    0.6.1
 */
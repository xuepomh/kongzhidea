/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.apache.hadoop.fs.FSDataInputStream;
/*     */ import org.apache.hadoop.fs.FSDataOutputStream;
/*     */ import org.apache.hadoop.fs.FileStatus;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.io.DataInputBuffer;
/*     */ import org.apache.hadoop.io.DataOutputBuffer;
/*     */ import org.apache.hadoop.io.IOUtils;
/*     */ import org.apache.hadoop.io.WritableUtils;
/*     */ import org.apache.hadoop.io.compress.CodecPool;
/*     */ import org.apache.hadoop.io.compress.CompressionCodec;
/*     */ import org.apache.hadoop.io.compress.CompressionOutputStream;
/*     */ import org.apache.hadoop.io.compress.Compressor;
/*     */ import org.apache.hadoop.io.compress.Decompressor;
/*     */ import org.apache.hadoop.io.serializer.SerializationFactory;
/*     */ import org.apache.hadoop.io.serializer.Serializer;
/*     */ 
/*     */ class IFile
/*     */ {
/*     */   private static final int EOF_MARKER = -1;
/*     */ 
/*     */   public static class InMemoryReader<K, V> extends IFile.Reader<K, V>
/*     */   {
/*     */     RamManager ramManager;
/*     */     TaskAttemptID taskAttemptId;
/*     */ 
/*     */     public InMemoryReader(RamManager ramManager, TaskAttemptID taskAttemptId, byte[] data, int start, int length)
/*     */       throws IOException
/*     */     {
/* 467 */       super(null, length - start, null, null);
/* 468 */       this.ramManager = ramManager;
/* 469 */       this.taskAttemptId = taskAttemptId;
/*     */ 
/* 471 */       this.buffer = data;
/* 472 */       this.bufferSize = (int)this.fileLength;
/* 473 */       this.dataIn.reset(this.buffer, start, length);
/*     */     }
/*     */ 
/*     */     public long getPosition()
/*     */       throws IOException
/*     */     {
/* 481 */       return this.bytesRead;
/*     */     }
/*     */ 
/*     */     public long getLength()
/*     */     {
/* 486 */       return this.fileLength;
/*     */     }
/*     */ 
/*     */     private void dumpOnError() {
/* 490 */       File dumpFile = new File("../output/" + this.taskAttemptId + ".dump");
/* 491 */       System.err.println("Dumping corrupt map-output of " + this.taskAttemptId + " to " + dumpFile.getAbsolutePath());
/*     */       try
/*     */       {
/* 494 */         FileOutputStream fos = new FileOutputStream(dumpFile);
/* 495 */         fos.write(this.buffer, 0, this.bufferSize);
/* 496 */         fos.close();
/*     */       } catch (IOException ioe) {
/* 498 */         System.err.println("Failed to dump map-output of " + this.taskAttemptId);
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean next(DataInputBuffer key, DataInputBuffer value) throws IOException
/*     */     {
/*     */       try
/*     */       {
/* 506 */         if (this.eof) {
/* 507 */           throw new EOFException("Completed reading " + this.bytesRead);
/*     */         }
/*     */ 
/* 511 */         int oldPos = this.dataIn.getPosition();
/* 512 */         int keyLength = WritableUtils.readVInt(this.dataIn);
/* 513 */         int valueLength = WritableUtils.readVInt(this.dataIn);
/* 514 */         int pos = this.dataIn.getPosition();
/* 515 */         this.bytesRead += pos - oldPos;
/*     */ 
/* 518 */         if ((keyLength == -1) && (valueLength == -1)) {
/* 519 */           this.eof = true;
/* 520 */           return false;
/*     */         }
/*     */ 
/* 524 */         if (keyLength < 0) {
/* 525 */           throw new IOException("Rec# " + this.recNo + ": Negative key-length: " + keyLength);
/*     */         }
/*     */ 
/* 528 */         if (valueLength < 0) {
/* 529 */           throw new IOException("Rec# " + this.recNo + ": Negative value-length: " + valueLength);
/*     */         }
/*     */ 
/* 533 */         int recordLength = keyLength + valueLength;
/*     */ 
/* 536 */         pos = this.dataIn.getPosition();
/* 537 */         byte[] data = this.dataIn.getData();
/* 538 */         key.reset(data, pos, keyLength);
/* 539 */         value.reset(data, pos + keyLength, valueLength);
/*     */ 
/* 542 */         long skipped = this.dataIn.skip(recordLength);
/* 543 */         if (skipped != recordLength) {
/* 544 */           throw new IOException("Rec# " + this.recNo + ": Failed to skip past record of length: " + recordLength);
/*     */         }
/*     */ 
/* 549 */         this.bytesRead += recordLength;
/*     */ 
/* 551 */         this.recNo += 1;
/*     */ 
/* 553 */         return true;
/*     */       } catch (IOException ioe) {
/* 555 */         dumpOnError();
/* 556 */         throw ioe;
/*     */       }
/*     */     }
/*     */ 
/*     */     public void close()
/*     */     {
/* 562 */       this.dataIn = null;
/* 563 */       this.buffer = null;
/*     */ 
/* 566 */       this.ramManager.unreserve(this.bufferSize);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Reader<K, V>
/*     */   {
/*     */     private static final int DEFAULT_BUFFER_SIZE = 131072;
/*     */     private static final int MAX_VINT_SIZE = 9;
/* 245 */     private long numRecordsRead = 0L;
/*     */     private final Counters.Counter readRecordsCounter;
/*     */     final InputStream in;
/*     */     Decompressor decompressor;
/* 250 */     long bytesRead = 0L;
/*     */     final long fileLength;
/* 252 */     boolean eof = false;
/*     */     final IFileInputStream checksumIn;
/* 255 */     byte[] buffer = null;
/* 256 */     int bufferSize = 131072;
/* 257 */     DataInputBuffer dataIn = new DataInputBuffer();
/*     */ 
/* 259 */     int recNo = 1;
/*     */ 
/*     */     public Reader(Configuration conf, FileSystem fs, Path file, CompressionCodec codec, Counters.Counter readsCounter)
/*     */       throws IOException
/*     */     {
/* 275 */       this(conf, fs.open(file), fs.getFileStatus(file).getLen(), codec, readsCounter);
/*     */     }
/*     */ 
/*     */     public Reader(Configuration conf, FSDataInputStream in, long length, CompressionCodec codec, Counters.Counter readsCounter)
/*     */       throws IOException
/*     */     {
/* 294 */       this.readRecordsCounter = readsCounter;
/* 295 */       this.checksumIn = new IFileInputStream(in, length, conf);
/* 296 */       if (codec != null) {
/* 297 */         this.decompressor = CodecPool.getDecompressor(codec);
/* 298 */         this.in = codec.createInputStream(this.checksumIn, this.decompressor);
/*     */       } else {
/* 300 */         this.in = this.checksumIn;
/*     */       }
/* 302 */       this.fileLength = length;
/*     */ 
/* 304 */       if (conf != null)
/* 305 */         this.bufferSize = conf.getInt("io.file.buffer.size", 131072);
/*     */     }
/*     */ 
/*     */     public long getLength()
/*     */     {
/* 310 */       return this.fileLength - this.checksumIn.getSize();
/*     */     }
/*     */ 
/*     */     public long getPosition() throws IOException {
/* 314 */       return this.checksumIn.getPosition();
/*     */     }
/*     */ 
/*     */     private int readData(byte[] buf, int off, int len)
/*     */       throws IOException
/*     */     {
/* 327 */       int bytesRead = 0;
/* 328 */       while (bytesRead < len) {
/* 329 */         int n = IOUtils.wrappedReadForCompressedData(this.in, buf, off + bytesRead, len - bytesRead);
/*     */ 
/* 331 */         if (n < 0) {
/* 332 */           return bytesRead;
/*     */         }
/* 334 */         bytesRead += n;
/*     */       }
/* 336 */       return len;
/*     */     }
/*     */ 
/*     */     void readNextBlock(int minSize) throws IOException {
/* 340 */       if (this.buffer == null) {
/* 341 */         this.buffer = new byte[this.bufferSize];
/* 342 */         this.dataIn.reset(this.buffer, 0, 0);
/*     */       }
/* 344 */       this.buffer = rejigData(this.buffer, this.bufferSize < minSize ? new byte[minSize << 1] : this.buffer);
/*     */ 
/* 347 */       this.bufferSize = this.buffer.length;
/*     */     }
/*     */ 
/*     */     private byte[] rejigData(byte[] source, byte[] destination)
/*     */       throws IOException
/*     */     {
/* 353 */       int bytesRemaining = this.dataIn.getLength() - this.dataIn.getPosition();
/* 354 */       if (bytesRemaining > 0) {
/* 355 */         System.arraycopy(source, this.dataIn.getPosition(), destination, 0, bytesRemaining);
/*     */       }
/*     */ 
/* 360 */       int n = readData(destination, bytesRemaining, destination.length - bytesRemaining);
/*     */ 
/* 362 */       this.dataIn.reset(destination, 0, bytesRemaining + n);
/*     */ 
/* 364 */       return destination;
/*     */     }
/*     */ 
/*     */     public boolean next(DataInputBuffer key, DataInputBuffer value)
/*     */       throws IOException
/*     */     {
/* 370 */       if (this.eof) {
/* 371 */         throw new EOFException("Completed reading " + this.bytesRead);
/*     */       }
/*     */ 
/* 375 */       if (this.dataIn.getLength() - this.dataIn.getPosition() < 18) {
/* 376 */         readNextBlock(18);
/*     */       }
/*     */ 
/* 380 */       int oldPos = this.dataIn.getPosition();
/* 381 */       int keyLength = WritableUtils.readVInt(this.dataIn);
/* 382 */       int valueLength = WritableUtils.readVInt(this.dataIn);
/* 383 */       int pos = this.dataIn.getPosition();
/* 384 */       this.bytesRead += pos - oldPos;
/*     */ 
/* 387 */       if ((keyLength == -1) && (valueLength == -1)) {
/* 388 */         this.eof = true;
/* 389 */         return false;
/*     */       }
/*     */ 
/* 393 */       if (keyLength < 0) {
/* 394 */         throw new IOException("Rec# " + this.recNo + ": Negative key-length: " + keyLength);
/*     */       }
/*     */ 
/* 397 */       if (valueLength < 0) {
/* 398 */         throw new IOException("Rec# " + this.recNo + ": Negative value-length: " + valueLength);
/*     */       }
/*     */ 
/* 402 */       int recordLength = keyLength + valueLength;
/*     */ 
/* 405 */       if (this.dataIn.getLength() - pos < recordLength) {
/* 406 */         readNextBlock(recordLength);
/*     */ 
/* 409 */         if (this.dataIn.getLength() - this.dataIn.getPosition() < recordLength) {
/* 410 */           throw new EOFException("Rec# " + this.recNo + ": Could read the next " + " record");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 416 */       pos = this.dataIn.getPosition();
/* 417 */       byte[] data = this.dataIn.getData();
/* 418 */       key.reset(data, pos, keyLength);
/* 419 */       value.reset(data, pos + keyLength, valueLength);
/*     */ 
/* 422 */       long skipped = this.dataIn.skip(recordLength);
/* 423 */       if (skipped != recordLength) {
/* 424 */         throw new IOException("Rec# " + this.recNo + ": Failed to skip past record " + "of length: " + recordLength);
/*     */       }
/*     */ 
/* 429 */       this.bytesRead += recordLength;
/*     */ 
/* 431 */       this.recNo += 1;
/* 432 */       this.numRecordsRead += 1L;
/*     */ 
/* 434 */       return true;
/*     */     }
/*     */ 
/*     */     public void close() throws IOException
/*     */     {
/* 439 */       if (this.decompressor != null) {
/* 440 */         this.decompressor.reset();
/* 441 */         CodecPool.returnDecompressor(this.decompressor);
/* 442 */         this.decompressor = null;
/*     */       }
/*     */ 
/* 446 */       this.in.close();
/*     */ 
/* 449 */       this.dataIn = null;
/* 450 */       this.buffer = null;
/* 451 */       if (this.readRecordsCounter != null)
/* 452 */         this.readRecordsCounter.increment(this.numRecordsRead);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Writer<K, V>
/*     */   {
/*     */     FSDataOutputStream out;
/*  59 */     boolean ownOutputStream = false;
/*  60 */     long start = 0L;
/*     */     FSDataOutputStream rawOut;
/*     */     CompressionOutputStream compressedOut;
/*     */     Compressor compressor;
/*  65 */     boolean compressOutput = false;
/*     */ 
/*  67 */     long decompressedBytesWritten = 0L;
/*  68 */     long compressedBytesWritten = 0L;
/*     */ 
/*  71 */     private long numRecordsWritten = 0L;
/*     */     private final Counters.Counter writtenRecordsCounter;
/*     */     IFileOutputStream checksumOut;
/*     */     Class<K> keyClass;
/*     */     Class<V> valueClass;
/*     */     Serializer<K> keySerializer;
/*     */     Serializer<V> valueSerializer;
/*  81 */     DataOutputBuffer buffer = new DataOutputBuffer();
/*     */ 
/*     */     public Writer(Configuration conf, FileSystem fs, Path file, Class<K> keyClass, Class<V> valueClass, CompressionCodec codec, Counters.Counter writesCounter)
/*     */       throws IOException
/*     */     {
/*  87 */       this(conf, fs.create(file), keyClass, valueClass, codec, writesCounter);
/*     */ 
/*  89 */       this.ownOutputStream = true;
/*     */     }
/*     */ 
/*     */     public Writer(Configuration conf, FSDataOutputStream out, Class<K> keyClass, Class<V> valueClass, CompressionCodec codec, Counters.Counter writesCounter)
/*     */       throws IOException
/*     */     {
/*  96 */       this.writtenRecordsCounter = writesCounter;
/*  97 */       this.checksumOut = new IFileOutputStream(out);
/*  98 */       this.rawOut = out;
/*  99 */       this.start = this.rawOut.getPos();
/*     */ 
/* 101 */       if (codec != null) {
/* 102 */         this.compressor = CodecPool.getCompressor(codec);
/* 103 */         this.compressor.reset();
/* 104 */         this.compressedOut = codec.createOutputStream(this.checksumOut, this.compressor);
/* 105 */         this.out = new FSDataOutputStream(this.compressedOut, null);
/* 106 */         this.compressOutput = true;
/*     */       } else {
/* 108 */         this.out = new FSDataOutputStream(this.checksumOut, null);
/*     */       }
/*     */ 
/* 111 */       this.keyClass = keyClass;
/* 112 */       this.valueClass = valueClass;
/* 113 */       SerializationFactory serializationFactory = new SerializationFactory(conf);
/* 114 */       this.keySerializer = serializationFactory.getSerializer(keyClass);
/* 115 */       this.keySerializer.open(this.buffer);
/* 116 */       this.valueSerializer = serializationFactory.getSerializer(valueClass);
/* 117 */       this.valueSerializer.open(this.buffer);
/*     */     }
/*     */ 
/*     */     public void close()
/*     */       throws IOException
/*     */     {
/* 123 */       this.keySerializer.close();
/* 124 */       this.valueSerializer.close();
/*     */ 
/* 127 */       WritableUtils.writeVInt(this.out, -1);
/* 128 */       WritableUtils.writeVInt(this.out, -1);
/* 129 */       this.decompressedBytesWritten += 2 * WritableUtils.getVIntSize(-1L);
/*     */ 
/* 132 */       this.out.flush();
/*     */ 
/* 134 */       if (this.compressOutput)
/*     */       {
/* 136 */         this.compressedOut.finish();
/* 137 */         this.compressedOut.resetState();
/*     */       }
/*     */ 
/* 141 */       if (this.ownOutputStream) {
/* 142 */         this.out.close();
/*     */       }
/*     */       else
/*     */       {
/* 146 */         this.checksumOut.finish();
/*     */       }
/*     */ 
/* 149 */       this.compressedBytesWritten = (this.rawOut.getPos() - this.start);
/*     */ 
/* 151 */       if (this.compressOutput)
/*     */       {
/* 153 */         CodecPool.returnCompressor(this.compressor);
/* 154 */         this.compressor = null;
/*     */       }
/*     */ 
/* 157 */       this.out = null;
/* 158 */       if (this.writtenRecordsCounter != null)
/* 159 */         this.writtenRecordsCounter.increment(this.numRecordsWritten);
/*     */     }
/*     */ 
/*     */     public void append(K key, V value) throws IOException
/*     */     {
/* 164 */       if (key.getClass() != this.keyClass) {
/* 165 */         throw new IOException("wrong key class: " + key.getClass() + " is not " + this.keyClass);
/*     */       }
/* 167 */       if (value.getClass() != this.valueClass) {
/* 168 */         throw new IOException("wrong value class: " + value.getClass() + " is not " + this.valueClass);
/*     */       }
/*     */ 
/* 172 */       this.keySerializer.serialize(key);
/* 173 */       int keyLength = this.buffer.getLength();
/* 174 */       if (keyLength < 0) {
/* 175 */         throw new IOException("Negative key-length not allowed: " + keyLength + " for " + key);
/*     */       }
/*     */ 
/* 180 */       this.valueSerializer.serialize(value);
/* 181 */       int valueLength = this.buffer.getLength() - keyLength;
/* 182 */       if (valueLength < 0) {
/* 183 */         throw new IOException("Negative value-length not allowed: " + valueLength + " for " + value);
/*     */       }
/*     */ 
/* 188 */       WritableUtils.writeVInt(this.out, keyLength);
/* 189 */       WritableUtils.writeVInt(this.out, valueLength);
/* 190 */       this.out.write(this.buffer.getData(), 0, this.buffer.getLength());
/*     */ 
/* 193 */       this.buffer.reset();
/*     */ 
/* 196 */       this.decompressedBytesWritten += keyLength + valueLength + WritableUtils.getVIntSize(keyLength) + WritableUtils.getVIntSize(valueLength);
/*     */ 
/* 199 */       this.numRecordsWritten += 1L;
/*     */     }
/*     */ 
/*     */     public void append(DataInputBuffer key, DataInputBuffer value) throws IOException
/*     */     {
/* 204 */       int keyLength = key.getLength() - key.getPosition();
/* 205 */       if (keyLength < 0) {
/* 206 */         throw new IOException("Negative key-length not allowed: " + keyLength + " for " + key);
/*     */       }
/*     */ 
/* 210 */       int valueLength = value.getLength() - value.getPosition();
/* 211 */       if (valueLength < 0) {
/* 212 */         throw new IOException("Negative value-length not allowed: " + valueLength + " for " + value);
/*     */       }
/*     */ 
/* 216 */       WritableUtils.writeVInt(this.out, keyLength);
/* 217 */       WritableUtils.writeVInt(this.out, valueLength);
/* 218 */       this.out.write(key.getData(), key.getPosition(), keyLength);
/* 219 */       this.out.write(value.getData(), value.getPosition(), valueLength);
/*     */ 
/* 222 */       this.decompressedBytesWritten += keyLength + valueLength + WritableUtils.getVIntSize(keyLength) + WritableUtils.getVIntSize(valueLength);
/*     */ 
/* 225 */       this.numRecordsWritten += 1L;
/*     */     }
/*     */ 
/*     */     public long getRawLength() {
/* 229 */       return this.decompressedBytesWritten;
/*     */     }
/*     */ 
/*     */     public long getCompressedLength() {
/* 233 */       return this.compressedBytesWritten;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.IFile
 * JD-Core Version:    0.6.1
 */
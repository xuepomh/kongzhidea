/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import org.apache.hadoop.io.OutputBuffer;
/*     */ import org.apache.hadoop.io.RawComparator;
/*     */ import org.apache.hadoop.io.SequenceFile.Sorter.RawKeyValueIterator;
/*     */ import org.apache.hadoop.util.Progressable;
/*     */ 
/*     */ abstract class BasicTypeSorterBase
/*     */   implements BufferSorter
/*     */ {
/*     */   protected OutputBuffer keyValBuffer;
/*     */   protected int[] startOffsets;
/*     */   protected int[] keyLengths;
/*     */   protected int[] valueLengths;
/*     */   protected int[] pointers;
/*     */   protected RawComparator comparator;
/*     */   protected int count;
/*     */   private static final int BUFFERED_KEY_VAL_OVERHEAD = 16;
/*     */   private static final int INITIAL_ARRAY_SIZE = 5;
/*  60 */   private int maxKeyLength = 0;
/*  61 */   private int maxValLength = 0;
/*     */   protected Progressable reporter;
/*     */ 
/*     */   public void configure(JobConf conf)
/*     */   {
/*  69 */     this.comparator = conf.getOutputKeyComparator();
/*     */   }
/*     */ 
/*     */   public void setProgressable(Progressable reporter) {
/*  73 */     this.reporter = reporter;
/*     */   }
/*     */ 
/*     */   public void addKeyValue(int recordOffset, int keyLength, int valLength)
/*     */   {
/*  79 */     if ((this.startOffsets == null) || (this.count == this.startOffsets.length))
/*  80 */       grow();
/*  81 */     this.startOffsets[this.count] = recordOffset;
/*  82 */     this.keyLengths[this.count] = keyLength;
/*  83 */     if (keyLength > this.maxKeyLength) {
/*  84 */       this.maxKeyLength = keyLength;
/*     */     }
/*  86 */     if (valLength > this.maxValLength) {
/*  87 */       this.maxValLength = valLength;
/*     */     }
/*  89 */     this.valueLengths[this.count] = valLength;
/*  90 */     this.pointers[this.count] = this.count;
/*  91 */     this.count += 1;
/*     */   }
/*     */ 
/*     */   public void setInputBuffer(OutputBuffer buffer)
/*     */   {
/*  96 */     this.keyValBuffer = buffer;
/*     */   }
/*     */ 
/*     */   public long getMemoryUtilized()
/*     */   {
/* 103 */     if (this.startOffsets != null) {
/* 104 */       return this.startOffsets.length * 16 + this.maxKeyLength + this.maxValLength;
/*     */     }
/*     */ 
/* 108 */     return 0L;
/*     */   }
/*     */ 
/*     */   public abstract SequenceFile.Sorter.RawKeyValueIterator sort();
/*     */ 
/*     */   public void close()
/*     */   {
/* 117 */     this.count = 0;
/* 118 */     this.startOffsets = null;
/* 119 */     this.keyLengths = null;
/* 120 */     this.valueLengths = null;
/* 121 */     this.pointers = null;
/* 122 */     this.maxKeyLength = 0;
/* 123 */     this.maxValLength = 0;
/*     */ 
/* 127 */     this.keyValBuffer = null;
/*     */   }
/*     */ 
/*     */   private void grow() {
/* 131 */     int currLength = 0;
/* 132 */     if (this.startOffsets != null) {
/* 133 */       currLength = this.startOffsets.length;
/*     */     }
/* 135 */     int newLength = (int)(currLength * 1.1D) + 1;
/* 136 */     this.startOffsets = grow(this.startOffsets, newLength);
/* 137 */     this.keyLengths = grow(this.keyLengths, newLength);
/* 138 */     this.valueLengths = grow(this.valueLengths, newLength);
/* 139 */     this.pointers = grow(this.pointers, newLength);
/*     */   }
/*     */ 
/*     */   private int[] grow(int[] old, int newLength) {
/* 143 */     int[] result = new int[newLength];
/* 144 */     if (old != null) {
/* 145 */       System.arraycopy(old, 0, result, 0, old.length);
/*     */     }
/* 147 */     return result;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.BasicTypeSorterBase
 * JD-Core Version:    0.6.1
 */
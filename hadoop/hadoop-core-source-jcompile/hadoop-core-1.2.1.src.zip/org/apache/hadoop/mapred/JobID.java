/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.IOException;
/*     */ import java.text.NumberFormat;
/*     */ 
/*     */ public class JobID extends org.apache.hadoop.mapreduce.JobID
/*     */ {
/*     */   public JobID(String jtIdentifier, int id)
/*     */   {
/*  48 */     super(jtIdentifier, id);
/*     */   }
/*     */ 
/*     */   public JobID()
/*     */   {
/*     */   }
/*     */ 
/*     */   public static JobID downgrade(org.apache.hadoop.mapreduce.JobID old)
/*     */   {
/*  59 */     if ((old instanceof JobID)) {
/*  60 */       return (JobID)old;
/*     */     }
/*  62 */     return new JobID(old.getJtIdentifier(), old.getId());
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static JobID read(DataInput in) throws IOException
/*     */   {
/*  68 */     JobID jobId = new JobID();
/*  69 */     jobId.readFields(in);
/*  70 */     return jobId;
/*     */   }
/*     */ 
/*     */   public static JobID forName(String str)
/*     */     throws IllegalArgumentException
/*     */   {
/*  78 */     return (JobID)org.apache.hadoop.mapreduce.JobID.forName(str);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static String getJobIDsPattern(String jtIdentifier, Integer jobId)
/*     */   {
/*  97 */     StringBuilder builder = new StringBuilder("job").append('_');
/*  98 */     builder.append(getJobIDsPatternWOPrefix(jtIdentifier, jobId));
/*  99 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   static StringBuilder getJobIDsPatternWOPrefix(String jtIdentifier, Integer jobId)
/*     */   {
/* 105 */     StringBuilder builder = new StringBuilder();
/* 106 */     if (jtIdentifier != null)
/* 107 */       builder.append(jtIdentifier);
/*     */     else {
/* 109 */       builder.append("[^").append('_').append("]*");
/*     */     }
/* 111 */     builder.append('_').append(jobId != null ? idFormat.format(jobId) : "[0-9]*");
/*     */ 
/* 113 */     return builder;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JobID
 * JD-Core Version:    0.6.1
 */
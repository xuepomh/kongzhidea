/*    */ package org.apache.hadoop.mapred;
/*    */ 
/*    */ import org.apache.hadoop.mapreduce.JobID;
/*    */ import org.apache.hadoop.util.Progressable;
/*    */ 
/*    */ public class JobContext extends org.apache.hadoop.mapreduce.JobContext
/*    */ {
/*    */   private JobConf job;
/*    */   private Progressable progress;
/*    */ 
/*    */   JobContext(JobConf conf, JobID jobId, Progressable progress)
/*    */   {
/* 28 */     super(conf, jobId);
/* 29 */     this.job = conf;
/* 30 */     this.progress = progress;
/*    */   }
/*    */ 
/*    */   JobContext(JobConf conf, JobID jobId) {
/* 34 */     this(conf, jobId, Reporter.NULL);
/*    */   }
/*    */ 
/*    */   public JobConf getJobConf()
/*    */   {
/* 43 */     return this.job;
/*    */   }
/*    */ 
/*    */   public Progressable getProgressible()
/*    */   {
/* 52 */     return this.progress;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JobContext
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URI;
/*     */ import java.net.URLEncoder;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.fs.FileSystem;
/*     */ import org.apache.hadoop.fs.Path;
/*     */ import org.apache.hadoop.http.HtmlQuoting;
/*     */ import org.apache.hadoop.mapreduce.JobACL;
/*     */ import org.apache.hadoop.security.AccessControlException;
/*     */ import org.apache.hadoop.security.UserGroupInformation;
/*     */ import org.apache.hadoop.security.authorize.AccessControlList;
/*     */ import org.apache.hadoop.util.ServletUtil;
/*     */ import org.apache.hadoop.util.StringUtils;
/*     */ 
/*     */ class JSPUtil
/*     */ {
/*     */   static final String PRIVATE_ACTIONS_KEY = "webinterface.private.actions";
/*  55 */   private static final Map<String, JobHistory.JobInfo> jobHistoryCache = new LinkedHashMap();
/*     */ 
/*  58 */   private static final Log LOG = LogFactory.getLog(JSPUtil.class);
/*     */ 
/*     */   public static JobWithViewAccessCheck checkAccessAndGetJob(JobTracker jt, JobID jobid, HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 101 */     final JobInProgress job = jt.getJob(jobid);
/* 102 */     JobWithViewAccessCheck myJob = new JobWithViewAccessCheck(job);
/*     */ 
/* 104 */     if ((!jt.areACLsEnabled()) || (job == null)) {
/* 105 */       return myJob;
/*     */     }
/*     */ 
/* 108 */     String user = request.getRemoteUser();
/* 109 */     if (user == null) {
/* 110 */       setErrorAndForward("Null user", request, response);
/* 111 */       myJob.setViewAccess(false);
/* 112 */       return myJob;
/*     */     }
/*     */ 
/* 115 */     final UserGroupInformation ugi = UserGroupInformation.createRemoteUser(user);
/*     */     try
/*     */     {
/* 118 */       ugi.doAs(new PrivilegedExceptionAction()
/*     */       {
/*     */         public Void run() throws IOException, ServletException {
/* 121 */           this.val$jt.getACLsManager().checkAccess(job, ugi, Operation.VIEW_JOB_DETAILS);
/*     */ 
/* 123 */           return null;
/*     */         } } );
/*     */     }
/*     */     catch (AccessControlException e) {
/* 127 */       String errMsg = new StringBuilder().append("User ").append(ugi.getShortUserName()).append(" failed to view ").append(jobid).append("!<br><br>").append(e.getMessage()).append("<hr><a href=\"jobtracker.jsp\">Go back to JobTracker</a><br>").toString();
/*     */ 
/* 130 */       setErrorAndForward(errMsg, request, response);
/* 131 */       myJob.setViewAccess(false);
/*     */     } catch (InterruptedException e) {
/* 133 */       String errMsg = new StringBuilder().append(" Interrupted while trying to access ").append(jobid).append("<hr><a href=\"jobtracker.jsp\">Go back to JobTracker</a><br>").toString();
/*     */ 
/* 135 */       setErrorAndForward(errMsg, request, response);
/* 136 */       myJob.setViewAccess(false);
/*     */     }
/* 138 */     return myJob;
/*     */   }
/*     */ 
/*     */   public static void setErrorAndForward(String errMsg, HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 148 */     request.setAttribute("error.msg", errMsg);
/* 149 */     RequestDispatcher dispatcher = request.getRequestDispatcher("/job_authorization_error.jsp");
/*     */ 
/* 151 */     response.setStatus(401);
/* 152 */     dispatcher.forward(request, response);
/*     */   }
/*     */ 
/*     */   public static void processButtons(HttpServletRequest request, HttpServletResponse response, JobTracker tracker)
/*     */     throws IOException, InterruptedException, ServletException
/*     */   {
/* 170 */     String user = request.getRemoteUser();
/* 171 */     if ((privateActionsAllowed(tracker.conf)) && (request.getParameter("killJobs") != null))
/*     */     {
/* 173 */       String[] jobs = request.getParameterValues("jobCheckBox");
/* 174 */       if (jobs != null) {
/* 175 */         boolean notAuthorized = false;
/* 176 */         String errMsg = new StringBuilder().append("User ").append(user).append(" failed to kill the following job(s)!<br><br>").toString();
/*     */ 
/* 178 */         for (String job : jobs) {
/* 179 */           final JobID jobId = JobID.forName(job);
/* 180 */           if (user != null) {
/* 181 */             UserGroupInformation ugi = UserGroupInformation.createRemoteUser(user);
/*     */             try
/*     */             {
/* 184 */               ugi.doAs(new PrivilegedExceptionAction()
/*     */               {
/*     */                 public Void run() throws IOException {
/* 187 */                   this.val$tracker.killJob(jobId);
/* 188 */                   return null;
/*     */                 } } );
/*     */             }
/*     */             catch (AccessControlException e) {
/* 192 */               errMsg = errMsg.concat(new StringBuilder().append("<br>").append(e.getMessage()).toString());
/* 193 */               notAuthorized = true;
/*     */ 
/* 196 */               continue;
/*     */             }
/*     */           }
/*     */           else {
/* 200 */             tracker.killJob(jobId);
/*     */           }
/*     */         }
/* 203 */         if (notAuthorized) {
/* 204 */           errMsg = errMsg.concat("<br><hr><a href=\"jobtracker.jsp\">Go back to JobTracker</a><br>");
/*     */ 
/* 206 */           setErrorAndForward(errMsg, request, response);
/* 207 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 212 */     if ((privateActionsAllowed(tracker.conf)) && (request.getParameter("changeJobPriority") != null))
/*     */     {
/* 214 */       String[] jobs = request.getParameterValues("jobCheckBox");
/* 215 */       if (jobs != null) {
/* 216 */         final JobPriority jobPri = JobPriority.valueOf(request.getParameter("setJobPriority"));
/*     */ 
/* 218 */         boolean notAuthorized = false;
/* 219 */         String errMsg = new StringBuilder().append("User ").append(user).append(" failed to set priority for the following job(s)!<br><br>").toString();
/*     */ 
/* 222 */         for (String job : jobs) {
/* 223 */           final JobID jobId = JobID.forName(job);
/* 224 */           if (user != null) {
/* 225 */             UserGroupInformation ugi = UserGroupInformation.createRemoteUser(user);
/*     */             try
/*     */             {
/* 228 */               ugi.doAs(new PrivilegedExceptionAction()
/*     */               {
/*     */                 public Void run() throws IOException
/*     */                 {
/* 232 */                   this.val$tracker.setJobPriority(jobId, jobPri);
/* 233 */                   return null;
/*     */                 } } );
/*     */             }
/*     */             catch (AccessControlException e) {
/* 237 */               errMsg = errMsg.concat(new StringBuilder().append("<br>").append(e.getMessage()).toString());
/* 238 */               notAuthorized = true;
/*     */ 
/* 241 */               continue;
/*     */             }
/*     */           }
/*     */           else {
/* 245 */             tracker.setJobPriority(jobId, jobPri);
/*     */           }
/*     */         }
/* 248 */         if (notAuthorized) {
/* 249 */           errMsg = errMsg.concat("<br><hr><a href=\"jobtracker.jsp\">Go back to JobTracker</a><br>");
/*     */ 
/* 251 */           setErrorAndForward(errMsg, request, response);
/* 252 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String generateJobTable(String label, Collection<JobInProgress> jobs, int refresh, int rowId, JobConf conf)
/*     */     throws IOException
/*     */   {
/* 271 */     boolean isModifiable = (label.equals("Running")) && (privateActionsAllowed(conf));
/*     */ 
/* 273 */     StringBuffer sb = new StringBuffer();
/* 274 */     sb.append("<table border=\"1\" cellpadding=\"5\" cellspacing=\"0\" class=\"sortable\">\n");
/*     */ 
/* 276 */     if (jobs.size() > 0) {
/* 277 */       if (isModifiable) {
/* 278 */         sb.append("<form action=\"/jobtracker.jsp\" onsubmit=\"return confirmAction();\" method=\"POST\">");
/* 279 */         sb.append("<tr>");
/* 280 */         sb.append("<td><input type=\"Button\" onclick=\"selectAll()\" value=\"Select All\" id=\"checkEm\"></td>");
/*     */ 
/* 282 */         sb.append("<td>");
/* 283 */         sb.append("<input type=\"submit\" name=\"killJobs\" value=\"Kill Selected Jobs\">");
/* 284 */         sb.append("</td");
/* 285 */         sb.append("<td><nobr>");
/* 286 */         sb.append("<select name=\"setJobPriority\">");
/*     */ 
/* 288 */         for (JobPriority prio : JobPriority.values()) {
/* 289 */           sb.append(new StringBuilder().append("<option").append(JobPriority.NORMAL == prio ? " selected=\"selected\">" : ">").append(prio).append("</option>").toString());
/*     */         }
/*     */ 
/* 294 */         sb.append("</select>");
/* 295 */         sb.append("<input type=\"submit\" name=\"changeJobPriority\" value=\"Change\">");
/*     */ 
/* 297 */         sb.append("</nobr></td>");
/* 298 */         sb.append("<td colspan=\"10\">&nbsp;</td>");
/* 299 */         sb.append("</tr>");
/* 300 */         sb.append("<td>&nbsp;</td>");
/*     */       } else {
/* 302 */         sb.append("<tr>");
/*     */       }
/*     */ 
/* 305 */       sb.append("<td><b>Jobid</b></td>");
/* 306 */       sb.append("<td><b>Started</b></td>");
/* 307 */       sb.append("<td><b>Priority</b></td>");
/* 308 */       sb.append("<td><b>User</b></td>");
/* 309 */       sb.append("<td><b>Name</b></td>");
/* 310 */       sb.append("<td><b>Map % Complete</b></td>");
/* 311 */       sb.append("<td><b>Map Total</b></td>");
/* 312 */       sb.append("<td><b>Maps Completed</b></td>");
/* 313 */       sb.append("<td><b>Reduce % Complete</b></td>");
/* 314 */       sb.append("<td><b>Reduce Total</b></td>");
/* 315 */       sb.append("<td><b>Reduces Completed</b></td>");
/* 316 */       sb.append("<td><b>Job Scheduling Information</b></td>");
/* 317 */       sb.append("<td><b>Diagnostic Info </b></td>");
/* 318 */       sb.append("</tr>\n");
/*     */ 
/* 320 */       for (Iterator it = jobs.iterator(); it.hasNext(); rowId++) {
/* 321 */         JobInProgress job = (JobInProgress)it.next();
/* 322 */         Date time = new Date(job.getStartTime());
/* 323 */         JobProfile profile = job.getProfile();
/* 324 */         JobStatus status = job.getStatus();
/* 325 */         JobID jobid = profile.getJobID();
/*     */ 
/* 327 */         int desiredMaps = job.desiredMaps();
/* 328 */         int desiredReduces = job.desiredReduces();
/* 329 */         int completedMaps = job.finishedMaps();
/* 330 */         int completedReduces = job.finishedReduces();
/* 331 */         String name = HtmlQuoting.quoteHtmlChars(profile.getJobName());
/* 332 */         String jobpri = job.getPriority().toString();
/* 333 */         String schedulingInfo = HtmlQuoting.quoteHtmlChars(job.getStatus().getSchedulingInfo());
/*     */ 
/* 335 */         String diagnosticInfo = HtmlQuoting.quoteHtmlChars(job.getStatus().getFailureInfo());
/*     */ 
/* 337 */         if (isModifiable) {
/* 338 */           sb.append(new StringBuilder().append("<tr><td><input TYPE=\"checkbox\" onclick=\"checkButtonVerbage()\" name=\"jobCheckBox\" value=").append(jobid).append("></td>").toString());
/*     */         }
/*     */         else
/*     */         {
/* 343 */           sb.append("<tr>");
/*     */         }
/*     */ 
/* 346 */         sb.append(new StringBuilder().append("<td id=\"job_").append(rowId).append("\"><a href=\"jobdetails.jsp?jobid=").append(jobid).append("&amp;refresh=").append(refresh).append("\">").append(jobid).append("</a></td>").append("<td id=\"started_").append(rowId).append("\">").append(time).append("</td>").append("<td id=\"priority_").append(rowId).append("\">").append(jobpri).append("</td>").append("<td id=\"user_").append(rowId).append("\">").append(HtmlQuoting.quoteHtmlChars(profile.getUser())).append("</td>").append("<td id=\"name_").append(rowId).append("\">").append("".equals(name) ? "&nbsp;" : name).append("</td>").append("<td>").append(StringUtils.formatPercent(status.mapProgress(), 2)).append(ServletUtil.percentageGraph(status.mapProgress() * 100.0F, 80)).append("</td><td>").append(desiredMaps).append("</td><td>").append(completedMaps).append("</td><td>").append(StringUtils.formatPercent(status.reduceProgress(), 2)).append(ServletUtil.percentageGraph(status.reduceProgress() * 100.0F, 80)).append("</td><td>").append(desiredReduces).append("</td><td> ").append(completedReduces).append("</td><td>").append(schedulingInfo).append("</td><td>").append(diagnosticInfo).append("</td></tr>\n").toString());
/*     */       }
/*     */ 
/* 365 */       if (isModifiable)
/* 366 */         sb.append("</form>\n");
/*     */     }
/*     */     else {
/* 369 */       sb.append("<tr><td align=\"center\" colspan=\"8\"><i>none</i></td></tr>\n");
/*     */     }
/*     */ 
/* 372 */     sb.append("</table>\n");
/*     */ 
/* 374 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String generateRetiredJobTable(JobTracker tracker, int rowId)
/*     */     throws IOException
/*     */   {
/* 381 */     StringBuffer sb = new StringBuffer();
/* 382 */     sb.append("<table border=\"1\" cellpadding=\"5\" cellspacing=\"0\">\n");
/*     */ 
/* 384 */     Iterator iterator = tracker.retireJobs.getAll().descendingIterator();
/*     */ 
/* 386 */     if (!iterator.hasNext()) {
/* 387 */       sb.append("<tr><td align=\"center\" colspan=\"8\"><i>none</i></td></tr>\n");
/*     */     }
/*     */     else {
/* 390 */       sb.append("<tr>");
/*     */ 
/* 392 */       sb.append("<td><b>Jobid</b></td>");
/* 393 */       sb.append("<td><b>Priority</b></td>");
/* 394 */       sb.append("<td><b>User</b></td>");
/* 395 */       sb.append("<td><b>Name</b></td>");
/* 396 */       sb.append("<td><b>State</b></td>");
/* 397 */       sb.append("<td><b>Start Time</b></td>");
/* 398 */       sb.append("<td><b>Finish Time</b></td>");
/* 399 */       sb.append("<td><b>Map % Complete</b></td>");
/* 400 */       sb.append("<td><b>Reduce % Complete</b></td>");
/* 401 */       sb.append("<td><b>Job Scheduling Information</b></td>");
/* 402 */       sb.append("<td><b>Diagnostic Info </b></td>");
/* 403 */       sb.append("</tr>\n");
/* 404 */       for (int i = 0; (i < 100) && (iterator.hasNext()); i++) {
/* 405 */         JobTracker.RetireJobInfo info = (JobTracker.RetireJobInfo)iterator.next();
/* 406 */         String historyFile = info.getHistoryFile();
/* 407 */         String historyFileUrl = null;
/* 408 */         if ((historyFile != null) && (!historyFile.equals(""))) {
/*     */           try {
/* 410 */             historyFileUrl = URLEncoder.encode(info.getHistoryFile(), "UTF-8");
/*     */           } catch (UnsupportedEncodingException e) {
/* 412 */             LOG.warn("Can't create history url ", e);
/*     */           }
/*     */         }
/* 415 */         sb.append("<tr>");
/* 416 */         sb.append(new StringBuilder().append("<td id=\"job_").append(rowId).append("\">").append(historyFileUrl == null ? "" : new StringBuilder().append("<a href=\"").append(JobHistoryServer.getHistoryUrlPrefix(tracker.conf)).append("/jobdetailshistory.jsp?logFile=").append(historyFileUrl).append("\">").toString()).append(info.status.getJobId()).append("</a></td>").append("<td id=\"priority_").append(rowId).append("\">").append(info.status.getJobPriority().toString()).append("</td>").append("<td id=\"user_").append(rowId).append("\">").append(HtmlQuoting.quoteHtmlChars(info.profile.getUser())).append("</td>").append("<td id=\"name_").append(rowId).append("\">").append(HtmlQuoting.quoteHtmlChars(info.profile.getJobName())).append("</td>").append("<td>").append(JobStatus.getJobRunState(info.status.getRunState())).append("</td>").append("<td>").append(new Date(info.status.getStartTime())).append("</td>").append("<td>").append(new Date(info.finishTime)).append("</td>").append("<td>").append(StringUtils.formatPercent(info.status.mapProgress(), 2)).append(ServletUtil.percentageGraph(info.status.mapProgress() * 100.0F, 80)).append("</td>").append("<td>").append(StringUtils.formatPercent(info.status.reduceProgress(), 2)).append(ServletUtil.percentageGraph(info.status.reduceProgress() * 100.0F, 80)).append("</td>").append("<td>").append(HtmlQuoting.quoteHtmlChars(info.status.getSchedulingInfo())).append("</td>").append("<td>").append(HtmlQuoting.quoteHtmlChars(info.status.getFailureInfo())).append("</td></tr>\n").toString());
/*     */ 
/* 450 */         rowId++;
/*     */       }
/*     */     }
/* 453 */     sb.append("</table>\n");
/* 454 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   static Path getJobConfFilePath(Path logFile) {
/* 458 */     return JobHistory.confPathFromLogFilePath(logFile);
/*     */   }
/*     */ 
/*     */   static JobHistory.JobInfo getJobInfo(Path logFile, FileSystem fs, JobConf jobConf, ACLsManager acLsManager, String user)
/*     */     throws IOException
/*     */   {
/* 472 */     String jobid = getJobID(logFile.getName());
/* 473 */     JobHistory.JobInfo jobInfo = null;
/* 474 */     synchronized (jobHistoryCache) {
/* 475 */       jobInfo = (JobHistory.JobInfo)jobHistoryCache.remove(jobid);
/* 476 */       if (jobInfo == null) {
/* 477 */         jobInfo = new JobHistory.JobInfo(jobid);
/* 478 */         LOG.info(new StringBuilder().append("Loading Job History file ").append(jobid).append(".   Cache size is ").append(jobHistoryCache.size()).toString());
/*     */ 
/* 480 */         DefaultJobHistoryParser.parseJobTasks(logFile.toUri().getPath(), jobInfo, fs);
/*     */       }
/*     */ 
/* 483 */       jobHistoryCache.put(jobid, jobInfo);
/* 484 */       int CACHE_SIZE = jobConf.getInt("mapred.job.tracker.jobhistory.lru.cache.size", 5);
/*     */ 
/* 486 */       if (jobHistoryCache.size() > CACHE_SIZE) {
/* 487 */         Iterator it = jobHistoryCache.entrySet().iterator();
/*     */ 
/* 489 */         String removeJobId = (String)((Map.Entry)it.next()).getKey();
/* 490 */         it.remove();
/* 491 */         LOG.info(new StringBuilder().append("Job History file removed form cache ").append(removeJobId).toString());
/*     */       }
/*     */     }
/*     */     UserGroupInformation currentUser;
/*     */     UserGroupInformation currentUser;
/* 496 */     if (user == null)
/* 497 */       currentUser = UserGroupInformation.getCurrentUser();
/*     */     else {
/* 499 */       currentUser = UserGroupInformation.createRemoteUser(user);
/*     */     }
/*     */ 
/* 503 */     acLsManager.checkAccess(jobid, currentUser, jobInfo.getJobQueue(), Operation.VIEW_JOB_DETAILS, jobInfo.get(JobHistory.Keys.USER), (AccessControlList)jobInfo.getJobACLs().get(JobACL.VIEW_JOB));
/*     */ 
/* 507 */     return jobInfo;
/*     */   }
/*     */ 
/*     */   static JobHistory.JobInfo checkAccessAndGetJobInfo(HttpServletRequest request, HttpServletResponse response, JobConf jobConf, ACLsManager acLsManager, FileSystem fs, Path logFile)
/*     */     throws IOException, InterruptedException, ServletException
/*     */   {
/* 528 */     String jobid = getJobID(logFile.getName());
/* 529 */     String user = request.getRemoteUser();
/* 530 */     JobHistory.JobInfo job = null;
/* 531 */     if (user != null) {
/*     */       try {
/* 533 */         job = getJobInfo(logFile, fs, jobConf, acLsManager, user);
/*     */       } catch (AccessControlException e) {
/* 535 */         String trackerAddress = jobConf.get("mapred.job.tracker.http.address");
/* 536 */         String errMsg = String.format(new StringBuilder().append("User %s failed to view %s!<br><br>%s<hr><a href=\"jobhistory.jsp\">Go back to JobHistory</a><br><a href=\"http://").append(trackerAddress).append("/jobtracker.jsp\">Go back to JobTracker</a>").toString(), new Object[] { user, jobid, e.getMessage() });
/*     */ 
/* 544 */         setErrorAndForward(errMsg, request, response);
/* 545 */         return null;
/*     */       }
/*     */     }
/*     */     else {
/* 549 */       job = getJobInfo(logFile, fs, jobConf, acLsManager, null);
/*     */     }
/* 551 */     return job;
/*     */   }
/*     */ 
/*     */   static String getJobID(String historyFileName) {
/* 555 */     return JobHistory.jobIdNameFromLogFileName(historyFileName);
/*     */   }
/*     */ 
/*     */   static String getUserName(String historyFileName) {
/* 559 */     return JobHistory.userNameFromLogFileName(historyFileName);
/*     */   }
/*     */ 
/*     */   static String getJobName(String historyFileName) {
/* 563 */     return JobHistory.jobNameFromLogFileName(historyFileName);
/*     */   }
/*     */ 
/*     */   static void printJobACLs(JobTracker tracker, Map<JobACL, AccessControlList> jobAcls, JspWriter out)
/*     */     throws IOException
/*     */   {
/* 576 */     if (tracker.areACLsEnabled()) {
/* 577 */       printJobACLsInternal(jobAcls, out);
/*     */     }
/*     */     else
/* 580 */       out.print(new StringBuilder().append("<b>Job-ACLs: ").append(new AccessControlList("*").toString()).append("</b><br>").toString());
/*     */   }
/*     */ 
/*     */   static void printJobACLs(JobConf conf, Map<JobACL, AccessControlList> jobAcls, JspWriter out)
/*     */     throws IOException
/*     */   {
/* 588 */     if (conf.getBoolean("mapred.acls.enabled", false)) {
/* 589 */       printJobACLsInternal(jobAcls, out);
/*     */     }
/*     */     else
/* 592 */       out.print(new StringBuilder().append("<b>Job-ACLs: ").append(new AccessControlList("*").toString()).append("</b><br>").toString());
/*     */   }
/*     */ 
/*     */   private static void printJobACLsInternal(Map<JobACL, AccessControlList> jobAcls, JspWriter out)
/*     */     throws IOException
/*     */   {
/* 600 */     out.print("<b>Job-ACLs:</b><br>");
/* 601 */     for (JobACL aclName : JobACL.values()) {
/* 602 */       String aclConfigName = aclName.getAclName();
/* 603 */       AccessControlList aclConfigured = (AccessControlList)jobAcls.get(aclName);
/* 604 */       if (aclConfigured != null) {
/* 605 */         String aclStr = aclConfigured.toString();
/* 606 */         out.print(new StringBuilder().append("&nbsp;&nbsp;&nbsp;&nbsp;").append(aclConfigName).append(": ").append(aclStr).append("<br>").toString());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static boolean privateActionsAllowed(JobConf conf)
/*     */   {
/* 613 */     return conf.getBoolean("webinterface.private.actions", false);
/*     */   }
/*     */ 
/*     */   static class JobWithViewAccessCheck
/*     */   {
/*  66 */     private JobInProgress job = null;
/*     */ 
/*  69 */     private boolean isViewAllowed = true;
/*     */ 
/*     */     JobWithViewAccessCheck(JobInProgress job) {
/*  72 */       this.job = job;
/*     */     }
/*     */ 
/*     */     JobInProgress getJob() {
/*  76 */       return this.job;
/*     */     }
/*     */ 
/*     */     boolean isViewJobAllowed() {
/*  80 */       return this.isViewAllowed;
/*     */     }
/*     */ 
/*     */     void setViewAccess(boolean isViewAllowed) {
/*  84 */       this.isViewAllowed = isViewAllowed;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JSPUtil
 * JD-Core Version:    0.6.1
 */
/*     */ package org.apache.hadoop.mapred;
/*     */ 
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.lang.management.ThreadInfo;
/*     */ import java.lang.management.ThreadMXBean;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.conf.Configuration;
/*     */ import org.mortbay.jetty.nio.SelectChannelConnector;
/*     */ 
/*     */ class JettyBugMonitor extends Thread
/*     */ {
/*  43 */   private static final Log LOG = LogFactory.getLog(JettyBugMonitor.class);
/*     */ 
/*  46 */   private static final ThreadMXBean threadBean = ManagementFactory.getThreadMXBean();
/*     */   private static final String CHECK_ENABLED_KEY = "mapred.tasktracker.jetty.cpu.check.enabled";
/*     */   private static final boolean CHECK_ENABLED_DEFAULT = true;
/*     */   static final String CHECK_INTERVAL_KEY = "mapred.tasktracker.jetty.cpu.check.interval";
/*     */   private static final long CHECK_INTERVAL_DEFAULT = 15000L;
/*     */   private long checkInterval;
/*     */   private static final String WARN_THRESHOLD_KEY = "mapred.tasktracker.jetty.cpu.threshold.warn";
/*     */   private static final float WARN_THRESHOLD_DEFAULT = 0.5F;
/*     */   private float warnThreshold;
/*     */   private static final String FATAL_THRESHOLD_KEY = "mapred.tasktracker.jetty.cpu.threshold.fatal";
/*     */   private static final float FATAL_THRESHOLD_DEFAULT = 0.9F;
/*     */   private float fatalThreshold;
/*  68 */   private boolean stopping = false;
/*     */ 
/*     */   public static JettyBugMonitor create(Configuration conf)
/*     */   {
/*  75 */     if (!conf.getBoolean("mapred.tasktracker.jetty.cpu.check.enabled", true)) {
/*  76 */       return null;
/*     */     }
/*     */ 
/*  79 */     if (!threadBean.isThreadCpuTimeSupported()) {
/*  80 */       LOG.warn("Not starting monitor for Jetty bug since thread CPU time measurement is not supported by this JVM");
/*     */ 
/*  82 */       return null;
/*     */     }
/*  84 */     return new JettyBugMonitor(conf);
/*     */   }
/*     */ 
/*     */   JettyBugMonitor(Configuration conf) {
/*  88 */     setName("Monitor for Jetty bugs");
/*  89 */     setDaemon(true);
/*     */ 
/*  91 */     this.warnThreshold = conf.getFloat("mapred.tasktracker.jetty.cpu.threshold.warn", 0.5F);
/*     */ 
/*  93 */     this.fatalThreshold = conf.getFloat("mapred.tasktracker.jetty.cpu.threshold.fatal", 0.9F);
/*     */ 
/*  95 */     this.checkInterval = conf.getLong("mapred.tasktracker.jetty.cpu.check.interval", 15000L);
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/* 102 */       doRun();
/*     */     } catch (InterruptedException ie) {
/* 104 */       if (!this.stopping)
/* 105 */         LOG.warn("Jetty monitor unexpectedly interrupted", ie);
/*     */     }
/*     */     catch (Throwable t) {
/* 108 */       LOG.error("Jetty bug monitor failed", t);
/*     */     }
/* 110 */     LOG.debug("JettyBugMonitor shutting down");
/*     */   }
/*     */ 
/*     */   private void doRun() throws InterruptedException {
/* 114 */     List tids = waitForJettyThreads();
/* 115 */     if (tids.isEmpty()) {
/* 116 */       LOG.warn("Could not locate Jetty selector threads");
/* 117 */       return;
/*     */     }
/*     */     try {
/*     */       while (true)
/* 121 */         monitorThreads(tids);
/*     */     }
/*     */     catch (ThreadNotRunningException tnre)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   private void monitorThreads(List<Long> tids)
/*     */     throws InterruptedException, JettyBugMonitor.ThreadNotRunningException
/*     */   {
/* 139 */     long timeBefore = System.nanoTime();
/* 140 */     long usageBefore = getCpuUsageNanos(tids);
/*     */     while (true) {
/* 142 */       Thread.sleep(this.checkInterval);
/* 143 */       long usageAfter = getCpuUsageNanos(tids);
/* 144 */       long timeAfter = System.nanoTime();
/*     */ 
/* 146 */       long delta = usageAfter - usageBefore;
/* 147 */       double percentCpu = delta / timeAfter - timeBefore;
/*     */ 
/* 149 */       String msg = String.format("Jetty CPU usage: %.1f%%", new Object[] { Double.valueOf(percentCpu * 100.0D) });
/* 150 */       if (percentCpu > this.fatalThreshold) {
/* 151 */         LOG.fatal("************************************************************\n" + msg + ". This is greater than the fatal threshold " + "mapred.tasktracker.jetty.cpu.threshold.fatal" + ". Aborting JVM.\n" + "************************************************************");
/*     */ 
/* 156 */         doAbort();
/* 157 */       } else if (percentCpu > this.warnThreshold) {
/* 158 */         LOG.warn(msg);
/* 159 */       } else if (LOG.isDebugEnabled()) {
/* 160 */         LOG.debug(msg);
/*     */       }
/*     */ 
/* 163 */       usageBefore = usageAfter;
/* 164 */       timeBefore = timeAfter;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void doAbort() {
/* 169 */     Runtime.getRuntime().exit(1);
/*     */   }
/*     */ 
/*     */   protected List<Long> waitForJettyThreads()
/*     */     throws InterruptedException
/*     */   {
/* 178 */     List tids = new ArrayList();
/* 179 */     int i = 0;
/* 180 */     while ((tids.isEmpty() & i++ < 30)) {
/* 181 */       Thread.sleep(1000L);
/* 182 */       tids = getJettyThreadIds();
/*     */     }
/* 184 */     return tids;
/*     */   }
/*     */ 
/*     */   private static long getCpuUsageNanos(List<Long> tids) throws JettyBugMonitor.ThreadNotRunningException
/*     */   {
/* 189 */     long total = 0L;
/* 190 */     for (Iterator i$ = tids.iterator(); i$.hasNext(); ) { long tid = ((Long)i$.next()).longValue();
/* 191 */       long time = threadBean.getThreadCpuTime(tid);
/* 192 */       if (time == -1L) {
/* 193 */         LOG.warn("Unable to monitor CPU usage for thread: " + tid);
/* 194 */         throw new ThreadNotRunningException(null);
/*     */       }
/* 196 */       total += time;
/*     */     }
/* 198 */     return total;
/*     */   }
/*     */ 
/*     */   static List<Long> getJettyThreadIds() {
/* 202 */     List tids = new ArrayList();
/* 203 */     long[] threadIds = threadBean.getAllThreadIds();
/* 204 */     for (long tid : threadIds) {
/* 205 */       if (isJettySelectorThread(tid)) {
/* 206 */         tids.add(Long.valueOf(tid));
/*     */       }
/*     */     }
/* 209 */     return tids;
/*     */   }
/*     */ 
/*     */   private static boolean isJettySelectorThread(long tid)
/*     */   {
/* 217 */     ThreadInfo info = threadBean.getThreadInfo(tid, 20);
/* 218 */     for (StackTraceElement stack : info.getStackTrace())
/*     */     {
/* 221 */       if (SelectChannelConnector.class.getName().equals(stack.getClassName()))
/*     */       {
/* 223 */         LOG.debug("Thread #" + tid + " (" + info.getThreadName() + ") " + "is a Jetty selector thread.");
/*     */ 
/* 225 */         return true;
/*     */       }
/*     */     }
/* 228 */     LOG.debug("Thread #" + tid + " (" + info.getThreadName() + ") " + "is not a jetty thread");
/*     */ 
/* 230 */     return false;
/*     */   }
/*     */ 
/*     */   public void shutdown()
/*     */   {
/* 238 */     this.stopping = true;
/* 239 */     interrupt();
/*     */   }
/*     */ 
/*     */   private static class ThreadNotRunningException extends Exception
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JettyBugMonitor
 * JD-Core Version:    0.6.1
 */
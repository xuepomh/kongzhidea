/*    */ package org.apache.hadoop.mapred;
/*    */ 
/*    */ import java.io.DataInput;
/*    */ import java.io.DataOutput;
/*    */ import java.io.IOException;
/*    */ import org.apache.hadoop.fs.Path;
/*    */ import org.apache.hadoop.io.Text;
/*    */ import org.apache.hadoop.io.Writable;
/*    */ import org.apache.hadoop.io.WritableUtils;
/*    */ import org.apache.hadoop.mapreduce.JobID;
/*    */ 
/*    */ class JobInfo
/*    */   implements Writable
/*    */ {
/*    */   private JobID id;
/*    */   private Text user;
/*    */   private Path jobSubmitDir;
/*    */ 
/*    */   public JobInfo()
/*    */   {
/*    */   }
/*    */ 
/*    */   public JobInfo(JobID id, Text user, Path jobSubmitDir)
/*    */   {
/* 44 */     this.id = id;
/* 45 */     this.user = user;
/* 46 */     this.jobSubmitDir = jobSubmitDir;
/*    */   }
/*    */ 
/*    */   public JobID getJobID()
/*    */   {
/* 53 */     return this.id;
/*    */   }
/*    */ 
/*    */   public Text getUser()
/*    */   {
/* 60 */     return this.user;
/*    */   }
/*    */ 
/*    */   public Path getJobSubmitDir()
/*    */   {
/* 67 */     return this.jobSubmitDir;
/*    */   }
/*    */ 
/*    */   public void readFields(DataInput in) throws IOException {
/* 71 */     this.id = new JobID();
/* 72 */     this.id.readFields(in);
/* 73 */     this.user = new Text();
/* 74 */     this.user.readFields(in);
/* 75 */     this.jobSubmitDir = new Path(WritableUtils.readString(in));
/*    */   }
/*    */ 
/*    */   public void write(DataOutput out) throws IOException {
/* 79 */     this.id.write(out);
/* 80 */     this.user.write(out);
/* 81 */     WritableUtils.writeString(out, this.jobSubmitDir.toString());
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JobInfo
 * JD-Core Version:    0.6.1
 */
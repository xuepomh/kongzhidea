/*    */ package org.apache.hadoop.conf;
/*    */ 
/*    */ public class Configured
/*    */   implements Configurable
/*    */ {
/*    */   private Configuration conf;
/*    */ 
/*    */   public Configured()
/*    */   {
/* 28 */     this(null);
/*    */   }
/*    */ 
/*    */   public Configured(Configuration conf)
/*    */   {
/* 33 */     setConf(conf);
/*    */   }
/*    */ 
/*    */   public void setConf(Configuration conf)
/*    */   {
/* 38 */     this.conf = conf;
/*    */   }
/*    */ 
/*    */   public Configuration getConf()
/*    */   {
/* 43 */     return this.conf;
/*    */   }
/*    */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.conf.Configured
 * JD-Core Version:    0.6.1
 */
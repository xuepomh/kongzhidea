/*      */ package org.apache.hadoop.conf;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.DataInput;
/*      */ import java.io.DataOutput;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.OutputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.net.URI;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.ListIterator;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.WeakHashMap;
/*      */ import java.util.concurrent.CopyOnWriteArrayList;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import javax.xml.parsers.ParserConfigurationException;
/*      */ import javax.xml.transform.Transformer;
/*      */ import javax.xml.transform.TransformerException;
/*      */ import javax.xml.transform.TransformerFactory;
/*      */ import javax.xml.transform.dom.DOMSource;
/*      */ import javax.xml.transform.stream.StreamResult;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.apache.hadoop.fs.FileSystem;
/*      */ import org.apache.hadoop.fs.Path;
/*      */ import org.apache.hadoop.io.Writable;
/*      */ import org.apache.hadoop.io.WritableUtils;
/*      */ import org.apache.hadoop.util.ReflectionUtils;
/*      */ import org.apache.hadoop.util.StringUtils;
/*      */ import org.codehaus.jackson.JsonFactory;
/*      */ import org.codehaus.jackson.JsonGenerator;
/*      */ import org.w3c.dom.Comment;
/*      */ import org.w3c.dom.DOMException;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ import org.xml.sax.SAXException;
/*      */ 
/*      */ public class Configuration
/*      */   implements Iterable<Map.Entry<String, String>>, Writable
/*      */ {
/*  146 */   private static final Log LOG = LogFactory.getLog(Configuration.class);
/*      */ 
/*  149 */   private boolean quietmode = true;
/*      */ 
/*  154 */   private ArrayList<Object> resources = new ArrayList();
/*      */ 
/*  159 */   private Set<String> finalParameters = new HashSet();
/*      */ 
/*  161 */   private boolean loadDefaults = true;
/*      */ 
/*  166 */   private static final WeakHashMap<Configuration, Object> REGISTRY = new WeakHashMap();
/*      */ 
/*  173 */   private static final CopyOnWriteArrayList<String> defaultResources = new CopyOnWriteArrayList();
/*      */   static final String UNKNOWN_RESOURCE = "Unknown";
/*      */   private HashMap<String, String> updatingResource;
/*      */   private Properties properties;
/*      */   private Properties overlay;
/*  209 */   private ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*      */ 
/*  350 */   private static Pattern varPat = Pattern.compile("\\$\\{[^\\}\\$ ]+\\}");
/*  351 */   private static int MAX_SUBST = 20;
/*      */ 
/*      */   public Configuration()
/*      */   {
/*  217 */     this(true);
/*      */   }
/*      */ 
/*      */   public Configuration(boolean loadDefaults)
/*      */   {
/*  210 */     if (this.classLoader == null) {
/*  211 */       this.classLoader = Configuration.class.getClassLoader();
/*      */     }
/*      */ 
/*  228 */     this.loadDefaults = loadDefaults;
/*  229 */     this.updatingResource = new HashMap();
/*  230 */     synchronized (Configuration.class) {
/*  231 */       REGISTRY.put(this, null);
/*      */     }
/*      */   }
/*      */ 
/*      */   public Configuration(Configuration other)
/*      */   {
/*  210 */     if (this.classLoader == null) {
/*  211 */       this.classLoader = Configuration.class.getClassLoader();
/*      */     }
/*      */ 
/*  242 */     this.resources = ((ArrayList)other.resources.clone());
/*  243 */     synchronized (other) {
/*  244 */       if (other.properties != null) {
/*  245 */         this.properties = ((Properties)other.properties.clone());
/*      */       }
/*      */ 
/*  248 */       if (other.overlay != null) {
/*  249 */         this.overlay = ((Properties)other.overlay.clone());
/*      */       }
/*      */ 
/*  252 */       this.updatingResource = new HashMap(other.updatingResource);
/*      */     }
/*      */ 
/*  256 */     this.finalParameters = new HashSet(other.finalParameters);
/*  257 */     synchronized (Configuration.class) {
/*  258 */       REGISTRY.put(this, null);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static synchronized void addDefaultResource(String name)
/*      */   {
/*  268 */     if (!defaultResources.contains(name)) {
/*  269 */       defaultResources.add(name);
/*  270 */       for (Configuration conf : REGISTRY.keySet())
/*  271 */         if (conf.loadDefaults)
/*  272 */           conf.reloadConfiguration();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void addResource(String name)
/*      */   {
/*  288 */     addResourceObject(name);
/*      */   }
/*      */ 
/*      */   public void addResource(URL url)
/*      */   {
/*  302 */     addResourceObject(url);
/*      */   }
/*      */ 
/*      */   public void addResource(Path file)
/*      */   {
/*  316 */     addResourceObject(file);
/*      */   }
/*      */ 
/*      */   public void addResource(InputStream in)
/*      */   {
/*  328 */     addResourceObject(in);
/*      */   }
/*      */ 
/*      */   public synchronized void reloadConfiguration()
/*      */   {
/*  341 */     this.properties = null;
/*  342 */     this.finalParameters.clear();
/*      */   }
/*      */ 
/*      */   private synchronized void addResourceObject(Object resource) {
/*  346 */     this.resources.add(resource);
/*  347 */     reloadConfiguration();
/*      */   }
/*      */ 
/*      */   private String substituteVars(String expr)
/*      */   {
/*  354 */     if (expr == null) {
/*  355 */       return null;
/*      */     }
/*  357 */     Matcher match = varPat.matcher("");
/*  358 */     String eval = expr;
/*  359 */     for (int s = 0; s < MAX_SUBST; s++) {
/*  360 */       match.reset(eval);
/*  361 */       if (!match.find()) {
/*  362 */         return eval;
/*      */       }
/*  364 */       String var = match.group();
/*  365 */       var = var.substring(2, var.length() - 1);
/*  366 */       String val = null;
/*      */       try {
/*  368 */         val = System.getProperty(var);
/*      */       } catch (SecurityException se) {
/*  370 */         LOG.warn("Unexpected SecurityException in Configuration", se);
/*      */       }
/*  372 */       if (val == null) {
/*  373 */         val = getRaw(var);
/*      */       }
/*  375 */       if (val == null) {
/*  376 */         return eval;
/*      */       }
/*      */ 
/*  379 */       eval = eval.substring(0, match.start()) + val + eval.substring(match.end());
/*      */     }
/*  381 */     throw new IllegalStateException("Variable substitution depth too large: " + MAX_SUBST + " " + expr);
/*      */   }
/*      */ 
/*      */   public String get(String name)
/*      */   {
/*  397 */     return substituteVars(getProps().getProperty(name));
/*      */   }
/*      */ 
/*      */   public String getRaw(String name)
/*      */   {
/*  409 */     return getProps().getProperty(name);
/*      */   }
/*      */ 
/*      */   public void set(String name, String value)
/*      */   {
/*  419 */     getOverlay().setProperty(name, value);
/*  420 */     getProps().setProperty(name, value);
/*  421 */     this.updatingResource.put(name, "Unknown");
/*      */   }
/*      */ 
/*      */   public synchronized void unset(String name)
/*      */   {
/*  428 */     getOverlay().remove(name);
/*  429 */     getProps().remove(name);
/*      */   }
/*      */ 
/*      */   public void setIfUnset(String name, String value)
/*      */   {
/*  438 */     if (get(name) == null)
/*  439 */       set(name, value);
/*      */   }
/*      */ 
/*      */   private synchronized Properties getOverlay()
/*      */   {
/*  444 */     if (this.overlay == null) {
/*  445 */       this.overlay = new Properties();
/*      */     }
/*  447 */     return this.overlay;
/*      */   }
/*      */ 
/*      */   public String get(String name, String defaultValue)
/*      */   {
/*  460 */     return substituteVars(getProps().getProperty(name, defaultValue));
/*      */   }
/*      */ 
/*      */   public int getInt(String name, int defaultValue)
/*      */   {
/*  475 */     String valueString = get(name);
/*  476 */     if (valueString == null)
/*  477 */       return defaultValue;
/*      */     try {
/*  479 */       String hexString = getHexDigits(valueString);
/*  480 */       if (hexString != null) {
/*  481 */         return Integer.parseInt(hexString, 16);
/*      */       }
/*  483 */       return Integer.parseInt(valueString); } catch (NumberFormatException e) {
/*      */     }
/*  485 */     return defaultValue;
/*      */   }
/*      */ 
/*      */   public void setInt(String name, int value)
/*      */   {
/*  496 */     set(name, Integer.toString(value));
/*      */   }
/*      */ 
/*      */   public long getLong(String name, long defaultValue)
/*      */   {
/*  511 */     String valueString = get(name);
/*  512 */     if (valueString == null)
/*  513 */       return defaultValue;
/*      */     try {
/*  515 */       String hexString = getHexDigits(valueString);
/*  516 */       if (hexString != null) {
/*  517 */         return Long.parseLong(hexString, 16);
/*      */       }
/*  519 */       return Long.parseLong(valueString); } catch (NumberFormatException e) {
/*      */     }
/*  521 */     return defaultValue;
/*      */   }
/*      */ 
/*      */   private String getHexDigits(String value)
/*      */   {
/*  526 */     boolean negative = false;
/*  527 */     String str = value;
/*  528 */     String hexString = null;
/*  529 */     if (value.startsWith("-")) {
/*  530 */       negative = true;
/*  531 */       str = value.substring(1);
/*      */     }
/*  533 */     if ((str.startsWith("0x")) || (str.startsWith("0X"))) {
/*  534 */       hexString = str.substring(2);
/*  535 */       if (negative) {
/*  536 */         hexString = "-" + hexString;
/*      */       }
/*  538 */       return hexString;
/*      */     }
/*  540 */     return null;
/*      */   }
/*      */ 
/*      */   public void setLong(String name, long value)
/*      */   {
/*  550 */     set(name, Long.toString(value));
/*      */   }
/*      */ 
/*      */   public float getFloat(String name, float defaultValue)
/*      */   {
/*  564 */     String valueString = get(name);
/*  565 */     if (valueString == null)
/*  566 */       return defaultValue;
/*      */     try {
/*  568 */       return Float.parseFloat(valueString); } catch (NumberFormatException e) {
/*      */     }
/*  570 */     return defaultValue;
/*      */   }
/*      */ 
/*      */   public void setFloat(String name, float value)
/*      */   {
/*  580 */     set(name, Float.toString(value));
/*      */   }
/*      */ 
/*      */   public boolean getBoolean(String name, boolean defaultValue)
/*      */   {
/*  594 */     String valueString = get(name);
/*  595 */     if ("true".equals(valueString))
/*  596 */       return true;
/*  597 */     if ("false".equals(valueString))
/*  598 */       return false;
/*  599 */     return defaultValue;
/*      */   }
/*      */ 
/*      */   public void setBoolean(String name, boolean value)
/*      */   {
/*  609 */     set(name, Boolean.toString(value));
/*      */   }
/*      */ 
/*      */   public void setBooleanIfUnset(String name, boolean value)
/*      */   {
/*  618 */     setIfUnset(name, Boolean.toString(value));
/*      */   }
/*      */ 
/*      */   public <T extends Enum<T>> void setEnum(String name, T value)
/*      */   {
/*  628 */     set(name, value.toString());
/*      */   }
/*      */ 
/*      */   public <T extends Enum<T>> T getEnum(String name, T defaultValue)
/*      */   {
/*  639 */     String val = get(name);
/*  640 */     return null == val ? defaultValue : Enum.valueOf(defaultValue.getDeclaringClass(), val);
/*      */   }
/*      */ 
/*      */   public IntegerRanges getRange(String name, String defaultValue)
/*      */   {
/*  740 */     return new IntegerRanges(get(name, defaultValue));
/*      */   }
/*      */ 
/*      */   public Collection<String> getStringCollection(String name)
/*      */   {
/*  754 */     String valueString = get(name);
/*  755 */     return StringUtils.getStringCollection(valueString);
/*      */   }
/*      */ 
/*      */   public String[] getStrings(String name)
/*      */   {
/*  768 */     String valueString = get(name);
/*  769 */     return StringUtils.getStrings(valueString);
/*      */   }
/*      */ 
/*      */   public String[] getStrings(String name, String[] defaultValue)
/*      */   {
/*  783 */     String valueString = get(name);
/*  784 */     if (valueString == null) {
/*  785 */       return defaultValue;
/*      */     }
/*  787 */     return StringUtils.getStrings(valueString);
/*      */   }
/*      */ 
/*      */   public void setStrings(String name, String[] values)
/*      */   {
/*  799 */     set(name, StringUtils.arrayToString(values));
/*      */   }
/*      */ 
/*      */   public Class<?> getClassByName(String name)
/*      */     throws ClassNotFoundException
/*      */   {
/*  810 */     return Class.forName(name, true, this.classLoader);
/*      */   }
/*      */ 
/*      */   public Class<?>[] getClasses(String name, Class<?>[] defaultValue)
/*      */   {
/*  826 */     String[] classnames = getStrings(name);
/*  827 */     if (classnames == null)
/*  828 */       return defaultValue;
/*      */     try {
/*  830 */       Class[] classes = new Class[classnames.length];
/*  831 */       for (int i = 0; i < classnames.length; i++) {
/*  832 */         classes[i] = getClassByName(classnames[i]);
/*      */       }
/*  834 */       return classes;
/*      */     } catch (ClassNotFoundException e) {
/*  836 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public Class<?> getClass(String name, Class<?> defaultValue)
/*      */   {
/*  851 */     String valueString = get(name);
/*  852 */     if (valueString == null)
/*  853 */       return defaultValue;
/*      */     try {
/*  855 */       return getClassByName(valueString);
/*      */     } catch (ClassNotFoundException e) {
/*  857 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public <U> Class<? extends U> getClass(String name, Class<? extends U> defaultValue, Class<U> xface)
/*      */   {
/*      */     try
/*      */     {
/*  881 */       Class theClass = getClass(name, defaultValue);
/*  882 */       if ((theClass != null) && (!xface.isAssignableFrom(theClass)))
/*  883 */         throw new RuntimeException(theClass + " not " + xface.getName());
/*  884 */       if (theClass != null) {
/*  885 */         return theClass.asSubclass(xface);
/*      */       }
/*  887 */       return null;
/*      */     } catch (Exception e) {
/*  889 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public <U> List<U> getInstances(String name, Class<U> xface)
/*      */   {
/*  907 */     List ret = new ArrayList();
/*  908 */     Class[] classes = getClasses(name, new Class[0]);
/*  909 */     for (Class cl : classes) {
/*  910 */       if (!xface.isAssignableFrom(cl)) {
/*  911 */         throw new RuntimeException(cl + " does not implement " + xface);
/*      */       }
/*  913 */       ret.add(ReflectionUtils.newInstance(cl, this));
/*      */     }
/*  915 */     return ret;
/*      */   }
/*      */ 
/*      */   public void setClass(String name, Class<?> theClass, Class<?> xface)
/*      */   {
/*  930 */     if (!xface.isAssignableFrom(theClass))
/*  931 */       throw new RuntimeException(theClass + " not " + xface.getName());
/*  932 */     set(name, theClass.getName());
/*      */   }
/*      */ 
/*      */   public Path getLocalPath(String dirsProp, String path)
/*      */     throws IOException
/*      */   {
/*  947 */     String[] dirs = getStrings(dirsProp);
/*  948 */     int hashCode = path.hashCode();
/*  949 */     FileSystem fs = FileSystem.getLocal(this);
/*  950 */     for (int i = 0; i < dirs.length; i++) {
/*  951 */       int index = (hashCode + i & 0x7FFFFFFF) % dirs.length;
/*  952 */       Path file = new Path(dirs[index], path);
/*  953 */       Path dir = file.getParent();
/*  954 */       if ((fs.mkdirs(dir)) || (fs.exists(dir))) {
/*  955 */         return file;
/*      */       }
/*      */     }
/*  958 */     LOG.warn("Could not make " + path + " in local directories from " + dirsProp);
/*      */ 
/*  960 */     for (int i = 0; i < dirs.length; i++) {
/*  961 */       int index = (hashCode + i & 0x7FFFFFFF) % dirs.length;
/*  962 */       LOG.warn(dirsProp + "[" + index + "]=" + dirs[index]);
/*      */     }
/*  964 */     throw new IOException("No valid local directories in property: " + dirsProp);
/*      */   }
/*      */ 
/*      */   public File getFile(String dirsProp, String path)
/*      */     throws IOException
/*      */   {
/*  979 */     String[] dirs = getStrings(dirsProp);
/*  980 */     int hashCode = path.hashCode();
/*  981 */     for (int i = 0; i < dirs.length; i++) {
/*  982 */       int index = (hashCode + i & 0x7FFFFFFF) % dirs.length;
/*  983 */       File file = new File(dirs[index], path);
/*  984 */       File dir = file.getParentFile();
/*  985 */       if ((dir.exists()) || (dir.mkdirs())) {
/*  986 */         return file;
/*      */       }
/*      */     }
/*  989 */     throw new IOException("No valid local directories in property: " + dirsProp);
/*      */   }
/*      */ 
/*      */   public URL getResource(String name)
/*      */   {
/*  999 */     return this.classLoader.getResource(name);
/*      */   }
/*      */ 
/*      */   public InputStream getConfResourceAsInputStream(String name)
/*      */   {
/*      */     try
/*      */     {
/* 1011 */       URL url = getResource(name);
/*      */ 
/* 1013 */       if (url == null) {
/* 1014 */         LOG.info(name + " not found");
/* 1015 */         return null;
/*      */       }
/* 1017 */       LOG.info("found resource " + name + " at " + url);
/*      */ 
/* 1020 */       return url.openStream(); } catch (Exception e) {
/*      */     }
/* 1022 */     return null;
/*      */   }
/*      */ 
/*      */   public Reader getConfResourceAsReader(String name)
/*      */   {
/*      */     try
/*      */     {
/* 1035 */       URL url = getResource(name);
/*      */ 
/* 1037 */       if (url == null) {
/* 1038 */         LOG.info(name + " not found");
/* 1039 */         return null;
/*      */       }
/* 1041 */       LOG.info("found resource " + name + " at " + url);
/*      */ 
/* 1044 */       return new InputStreamReader(url.openStream()); } catch (Exception e) {
/*      */     }
/* 1046 */     return null;
/*      */   }
/*      */ 
/*      */   private synchronized Properties getProps()
/*      */   {
/* 1051 */     if (this.properties == null) {
/* 1052 */       this.properties = new Properties();
/* 1053 */       loadResources(this.properties, this.resources, this.quietmode);
/* 1054 */       if (this.overlay != null) {
/* 1055 */         this.properties.putAll(this.overlay);
/* 1056 */         for (Map.Entry item : this.overlay.entrySet()) {
/* 1057 */           this.updatingResource.put((String)item.getKey(), "Unknown");
/*      */         }
/*      */       }
/*      */     }
/* 1061 */     return this.properties;
/*      */   }
/*      */ 
/*      */   public int size()
/*      */   {
/* 1070 */     return getProps().size();
/*      */   }
/*      */ 
/*      */   public void clear()
/*      */   {
/* 1077 */     getProps().clear();
/* 1078 */     getOverlay().clear();
/*      */   }
/*      */ 
/*      */   public Iterator<Map.Entry<String, String>> iterator()
/*      */   {
/* 1092 */     Map result = new HashMap();
/* 1093 */     for (Map.Entry item : getProps().entrySet()) {
/* 1094 */       if (((item.getKey() instanceof String)) && ((item.getValue() instanceof String)))
/*      */       {
/* 1096 */         result.put((String)item.getKey(), (String)item.getValue());
/*      */       }
/*      */     }
/* 1099 */     return result.entrySet().iterator();
/*      */   }
/*      */ 
/*      */   private void loadResources(Properties properties, ArrayList resources, boolean quiet)
/*      */   {
/* 1105 */     if (this.loadDefaults) {
/* 1106 */       for (String resource : defaultResources) {
/* 1107 */         loadResource(properties, resource, quiet);
/*      */       }
/*      */ 
/* 1111 */       if (getResource("hadoop-site.xml") != null) {
/* 1112 */         loadResource(properties, "hadoop-site.xml", quiet);
/*      */       }
/*      */     }
/*      */ 
/* 1116 */     for (Iterator i$ = resources.iterator(); i$.hasNext(); ) { Object resource = i$.next();
/* 1117 */       loadResource(properties, resource, quiet); }
/*      */   }
/*      */ 
/*      */   private void loadResource(Properties properties, Object name, boolean quiet)
/*      */   {
/*      */     try {
/* 1123 */       DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
/*      */ 
/* 1126 */       docBuilderFactory.setIgnoringComments(true);
/*      */ 
/* 1129 */       docBuilderFactory.setNamespaceAware(true);
/*      */       try {
/* 1131 */         docBuilderFactory.setXIncludeAware(true);
/*      */       } catch (UnsupportedOperationException e) {
/* 1133 */         LOG.error("Failed to set setXIncludeAware(true) for parser " + docBuilderFactory + ":" + e, e);
/*      */       }
/*      */ 
/* 1138 */       DocumentBuilder builder = docBuilderFactory.newDocumentBuilder();
/* 1139 */       Document doc = null;
/* 1140 */       Element root = null;
/*      */ 
/* 1142 */       if ((name instanceof URL)) {
/* 1143 */         URL url = (URL)name;
/* 1144 */         if (url != null) {
/* 1145 */           if (!quiet) {
/* 1146 */             LOG.info("parsing " + url);
/*      */           }
/* 1148 */           doc = builder.parse(url.toString());
/*      */         }
/* 1150 */       } else if ((name instanceof String)) {
/* 1151 */         URL url = getResource((String)name);
/* 1152 */         if (url != null) {
/* 1153 */           if (!quiet) {
/* 1154 */             LOG.info("parsing " + url);
/*      */           }
/* 1156 */           doc = builder.parse(url.toString());
/*      */         }
/* 1158 */       } else if ((name instanceof Path))
/*      */       {
/* 1161 */         File file = new File(((Path)name).toUri().getPath()).getAbsoluteFile();
/*      */ 
/* 1163 */         if (file.exists()) {
/* 1164 */           if (!quiet) {
/* 1165 */             LOG.info("parsing " + file);
/*      */           }
/* 1167 */           InputStream in = new BufferedInputStream(new FileInputStream(file));
/*      */           try {
/* 1169 */             doc = builder.parse(in);
/*      */           } finally {
/* 1171 */             in.close();
/*      */           }
/*      */         }
/* 1174 */       } else if ((name instanceof InputStream)) {
/*      */         try {
/* 1176 */           doc = builder.parse((InputStream)name);
/*      */         } finally {
/* 1178 */           ((InputStream)name).close();
/*      */         }
/* 1180 */       } else if ((name instanceof Element)) {
/* 1181 */         root = (Element)name;
/*      */       }
/*      */ 
/* 1184 */       if ((doc == null) && (root == null)) {
/* 1185 */         if (quiet)
/* 1186 */           return;
/* 1187 */         throw new RuntimeException(name + " not found");
/*      */       }
/*      */ 
/* 1190 */       if (root == null) {
/* 1191 */         root = doc.getDocumentElement();
/*      */       }
/* 1193 */       if (!"configuration".equals(root.getTagName()))
/* 1194 */         LOG.fatal("bad conf file: top-level element not <configuration>");
/* 1195 */       NodeList props = root.getChildNodes();
/* 1196 */       for (int i = 0; i < props.getLength(); i++) {
/* 1197 */         Node propNode = props.item(i);
/* 1198 */         if ((propNode instanceof Element))
/*      */         {
/* 1200 */           Element prop = (Element)propNode;
/* 1201 */           if ("configuration".equals(prop.getTagName())) {
/* 1202 */             loadResource(properties, prop, quiet);
/*      */           }
/*      */           else {
/* 1205 */             if (!"property".equals(prop.getTagName()))
/* 1206 */               LOG.warn("bad conf file: element not <property>");
/* 1207 */             NodeList fields = prop.getChildNodes();
/* 1208 */             String attr = null;
/* 1209 */             String value = null;
/* 1210 */             boolean finalParameter = false;
/* 1211 */             for (int j = 0; j < fields.getLength(); j++) {
/* 1212 */               Node fieldNode = fields.item(j);
/* 1213 */               if ((fieldNode instanceof Element))
/*      */               {
/* 1215 */                 Element field = (Element)fieldNode;
/* 1216 */                 if (("name".equals(field.getTagName())) && (field.hasChildNodes()))
/* 1217 */                   attr = ((org.w3c.dom.Text)field.getFirstChild()).getData().trim();
/* 1218 */                 if (("value".equals(field.getTagName())) && (field.hasChildNodes()))
/* 1219 */                   value = ((org.w3c.dom.Text)field.getFirstChild()).getData();
/* 1220 */                 if (("final".equals(field.getTagName())) && (field.hasChildNodes())) {
/* 1221 */                   finalParameter = "true".equals(((org.w3c.dom.Text)field.getFirstChild()).getData());
/*      */                 }
/*      */               }
/*      */             }
/* 1225 */             if (attr != null) {
/* 1226 */               if (value != null) {
/* 1227 */                 if (!this.finalParameters.contains(attr)) {
/* 1228 */                   properties.setProperty(attr, value);
/* 1229 */                   this.updatingResource.put(attr, name.toString());
/* 1230 */                 } else if (!value.equals(properties.getProperty(attr))) {
/* 1231 */                   LOG.warn(name + ":a attempt to override final parameter: " + attr + ";  Ignoring.");
/*      */                 }
/*      */               }
/*      */ 
/* 1235 */               if (finalParameter)
/* 1236 */                 this.finalParameters.add(attr);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     } catch (IOException e) {
/* 1242 */       LOG.fatal("error parsing conf file: " + e);
/* 1243 */       throw new RuntimeException(e);
/*      */     } catch (DOMException e) {
/* 1245 */       LOG.fatal("error parsing conf file: " + e);
/* 1246 */       throw new RuntimeException(e);
/*      */     } catch (SAXException e) {
/* 1248 */       LOG.fatal("error parsing conf file: " + e);
/* 1249 */       throw new RuntimeException(e);
/*      */     } catch (ParserConfigurationException e) {
/* 1251 */       LOG.fatal("error parsing conf file: " + e);
/* 1252 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void writeXml(OutputStream out)
/*      */     throws IOException
/*      */   {
/* 1263 */     writeXml(new OutputStreamWriter(out));
/*      */   }
/*      */ 
/*      */   public void writeXml(Writer out)
/*      */     throws IOException
/*      */   {
/* 1273 */     Document doc = asXmlDocument();
/*      */     try {
/* 1275 */       DOMSource source = new DOMSource(doc);
/* 1276 */       StreamResult result = new StreamResult(out);
/* 1277 */       TransformerFactory transFactory = TransformerFactory.newInstance();
/* 1278 */       Transformer transformer = transFactory.newTransformer();
/*      */ 
/* 1283 */       transformer.transform(source, result);
/*      */     } catch (TransformerException te) {
/* 1285 */       throw new IOException(te);
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized Document asXmlDocument() throws IOException
/*      */   {
/* 1294 */     Properties properties = getProps();
/*      */     Document doc;
/*      */     try
/*      */     {
/* 1296 */       doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
/*      */     }
/*      */     catch (ParserConfigurationException pe) {
/* 1299 */       throw new IOException(pe);
/*      */     }
/* 1301 */     Element conf = doc.createElement("configuration");
/* 1302 */     doc.appendChild(conf);
/* 1303 */     conf.appendChild(doc.createTextNode("\n"));
/* 1304 */     for (Enumeration e = properties.keys(); e.hasMoreElements(); ) {
/* 1305 */       String name = (String)e.nextElement();
/* 1306 */       Object object = properties.get(name);
/* 1307 */       String value = null;
/* 1308 */       if ((object instanceof String)) {
/* 1309 */         value = (String)object;
/*      */ 
/* 1313 */         Element propNode = doc.createElement("property");
/* 1314 */         conf.appendChild(propNode);
/* 1315 */         if (this.updatingResource != null) {
/* 1316 */           Comment commentNode = doc.createComment("Loaded from " + (String)this.updatingResource.get(name));
/*      */ 
/* 1318 */           propNode.appendChild(commentNode);
/*      */         }
/* 1320 */         Element nameNode = doc.createElement("name");
/* 1321 */         nameNode.appendChild(doc.createTextNode(name));
/* 1322 */         propNode.appendChild(nameNode);
/*      */ 
/* 1324 */         Element valueNode = doc.createElement("value");
/* 1325 */         valueNode.appendChild(doc.createTextNode(value));
/* 1326 */         propNode.appendChild(valueNode);
/*      */ 
/* 1328 */         conf.appendChild(doc.createTextNode("\n"));
/*      */       }
/*      */     }
/* 1330 */     return doc;
/*      */   }
/*      */ 
/*      */   public static void dumpConfiguration(Configuration config, Writer out)
/*      */     throws IOException
/*      */   {
/* 1346 */     JsonFactory dumpFactory = new JsonFactory();
/* 1347 */     JsonGenerator dumpGenerator = dumpFactory.createJsonGenerator(out);
/* 1348 */     dumpGenerator.writeStartObject();
/* 1349 */     dumpGenerator.writeFieldName("properties");
/* 1350 */     dumpGenerator.writeStartArray();
/* 1351 */     dumpGenerator.flush();
/* 1352 */     synchronized (config) {
/* 1353 */       for (Map.Entry item : config.getProps().entrySet()) {
/* 1354 */         dumpGenerator.writeStartObject();
/* 1355 */         dumpGenerator.writeStringField("key", (String)item.getKey());
/* 1356 */         dumpGenerator.writeStringField("value", config.get((String)item.getKey()));
/*      */ 
/* 1358 */         dumpGenerator.writeBooleanField("isFinal", config.finalParameters.contains(item.getKey()));
/*      */ 
/* 1360 */         dumpGenerator.writeStringField("resource", (String)config.updatingResource.get(item.getKey()));
/*      */ 
/* 1362 */         dumpGenerator.writeEndObject();
/*      */       }
/*      */     }
/* 1365 */     dumpGenerator.writeEndArray();
/* 1366 */     dumpGenerator.writeEndObject();
/* 1367 */     dumpGenerator.flush();
/*      */   }
/*      */ 
/*      */   public ClassLoader getClassLoader()
/*      */   {
/* 1376 */     return this.classLoader;
/*      */   }
/*      */ 
/*      */   public void setClassLoader(ClassLoader classLoader)
/*      */   {
/* 1385 */     this.classLoader = classLoader;
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1390 */     StringBuffer sb = new StringBuffer();
/* 1391 */     sb.append("Configuration: ");
/* 1392 */     if (this.loadDefaults) {
/* 1393 */       toString(defaultResources, sb);
/* 1394 */       if (this.resources.size() > 0) {
/* 1395 */         sb.append(", ");
/*      */       }
/*      */     }
/* 1398 */     toString(this.resources, sb);
/* 1399 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   private void toString(List resources, StringBuffer sb) {
/* 1403 */     ListIterator i = resources.listIterator();
/* 1404 */     while (i.hasNext()) {
/* 1405 */       if (i.nextIndex() != 0) {
/* 1406 */         sb.append(", ");
/*      */       }
/* 1408 */       sb.append(i.next());
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void setQuietMode(boolean quietmode)
/*      */   {
/* 1421 */     this.quietmode = quietmode;
/*      */   }
/*      */ 
/*      */   public static void main(String[] args) throws Exception
/*      */   {
/* 1426 */     new Configuration().writeXml(System.out);
/*      */   }
/*      */ 
/*      */   public void readFields(DataInput in) throws IOException
/*      */   {
/* 1431 */     clear();
/* 1432 */     int size = WritableUtils.readVInt(in);
/* 1433 */     for (int i = 0; i < size; i++)
/* 1434 */       set(org.apache.hadoop.io.Text.readString(in), org.apache.hadoop.io.Text.readString(in));
/*      */   }
/*      */ 
/*      */   public void write(DataOutput out)
/*      */     throws IOException
/*      */   {
/* 1441 */     Properties props = getProps();
/* 1442 */     WritableUtils.writeVInt(out, props.size());
/* 1443 */     for (Map.Entry item : props.entrySet()) {
/* 1444 */       org.apache.hadoop.io.Text.writeString(out, (String)item.getKey());
/* 1445 */       org.apache.hadoop.io.Text.writeString(out, (String)item.getValue());
/*      */     }
/*      */   }
/*      */ 
/*      */   public Map<String, String> getValByRegex(String regex)
/*      */   {
/* 1455 */     Pattern p = Pattern.compile(regex);
/*      */ 
/* 1457 */     Map result = new HashMap();
/*      */ 
/* 1460 */     for (Map.Entry item : getProps().entrySet()) {
/* 1461 */       if (((item.getKey() instanceof String)) && ((item.getValue() instanceof String)))
/*      */       {
/* 1463 */         Matcher m = p.matcher((String)item.getKey());
/* 1464 */         if (m.find()) {
/* 1465 */           result.put((String)item.getKey(), (String)item.getValue());
/*      */         }
/*      */       }
/*      */     }
/* 1469 */     return result;
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*  190 */     ClassLoader cL = Thread.currentThread().getContextClassLoader();
/*  191 */     if (cL == null) {
/*  192 */       cL = Configuration.class.getClassLoader();
/*      */     }
/*  194 */     if (cL.getResource("hadoop-site.xml") != null) {
/*  195 */       LOG.warn("DEPRECATED: hadoop-site.xml found in the classpath. Usage of hadoop-site.xml is deprecated. Instead use core-site.xml, mapred-site.xml and hdfs-site.xml to override properties of core-default.xml, mapred-default.xml and hdfs-default.xml respectively");
/*      */     }
/*      */ 
/*  201 */     addDefaultResource("core-default.xml");
/*  202 */     addDefaultResource("core-site.xml");
/*      */   }
/*      */ 
/*      */   public static class IntegerRanges
/*      */   {
/*  658 */     List<Range> ranges = new ArrayList();
/*      */ 
/*      */     public IntegerRanges() {
/*      */     }
/*      */ 
/*      */     public IntegerRanges(String newValue) {
/*  664 */       StringTokenizer itr = new StringTokenizer(newValue, ",");
/*  665 */       while (itr.hasMoreTokens()) {
/*  666 */         String rng = itr.nextToken().trim();
/*  667 */         String[] parts = rng.split("-", 3);
/*  668 */         if ((parts.length < 1) || (parts.length > 2)) {
/*  669 */           throw new IllegalArgumentException("integer range badly formed: " + rng);
/*      */         }
/*      */ 
/*  672 */         Range r = new Range(null);
/*  673 */         r.start = convertToInt(parts[0], 0);
/*  674 */         if (parts.length == 2)
/*  675 */           r.end = convertToInt(parts[1], 2147483647);
/*      */         else {
/*  677 */           r.end = r.start;
/*      */         }
/*  679 */         if (r.start > r.end) {
/*  680 */           throw new IllegalArgumentException("IntegerRange from " + r.start + " to " + r.end + " is invalid");
/*      */         }
/*      */ 
/*  683 */         this.ranges.add(r);
/*      */       }
/*      */     }
/*      */ 
/*      */     private static int convertToInt(String value, int defaultValue)
/*      */     {
/*  694 */       String trim = value.trim();
/*  695 */       if (trim.length() == 0) {
/*  696 */         return defaultValue;
/*      */       }
/*  698 */       return Integer.parseInt(trim);
/*      */     }
/*      */ 
/*      */     public boolean isIncluded(int value)
/*      */     {
/*  707 */       for (Range r : this.ranges) {
/*  708 */         if ((r.start <= value) && (value <= r.end)) {
/*  709 */           return true;
/*      */         }
/*      */       }
/*  712 */       return false;
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/*  717 */       StringBuffer result = new StringBuffer();
/*  718 */       boolean first = true;
/*  719 */       for (Range r : this.ranges) {
/*  720 */         if (first)
/*  721 */           first = false;
/*      */         else {
/*  723 */           result.append(',');
/*      */         }
/*  725 */         result.append(r.start);
/*  726 */         result.append('-');
/*  727 */         result.append(r.end);
/*      */       }
/*  729 */       return result.toString();
/*      */     }
/*      */ 
/*      */     private static class Range
/*      */     {
/*      */       int start;
/*      */       int end;
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.conf.Configuration
 * JD-Core Version:    0.6.1
 */
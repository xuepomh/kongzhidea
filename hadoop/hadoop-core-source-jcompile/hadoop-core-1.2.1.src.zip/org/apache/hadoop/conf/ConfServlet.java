/*     */ package org.apache.hadoop.conf;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.hadoop.classification.InterfaceAudience.LimitedPrivate;
/*     */ import org.apache.hadoop.classification.InterfaceStability.Unstable;
/*     */ import org.apache.hadoop.http.HttpServer;
/*     */ 
/*     */ @InterfaceAudience.LimitedPrivate({"HDFS", "MapReduce"})
/*     */ @InterfaceStability.Unstable
/*     */ public class ConfServlet extends HttpServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String FORMAT_JSON = "json";
/*     */   private static final String FORMAT_XML = "xml";
/*     */   private static final String FORMAT_PARAM = "format";
/*     */ 
/*     */   private Configuration getConfFromContext()
/*     */   {
/*  49 */     Configuration conf = (Configuration)getServletContext().getAttribute("hadoop.conf");
/*     */ 
/*  51 */     assert (conf != null);
/*  52 */     return conf;
/*     */   }
/*     */ 
/*     */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  58 */     if (!HttpServer.isInstrumentationAccessAllowed(getServletContext(), request, response))
/*     */     {
/*  60 */       return;
/*     */     }
/*  62 */     String format = request.getParameter("format");
/*  63 */     if (null == format) {
/*  64 */       format = "xml";
/*     */     }
/*     */ 
/*  67 */     if ("xml".equals(format))
/*  68 */       response.setContentType("text/xml; charset=utf-8");
/*  69 */     else if ("json".equals(format)) {
/*  70 */       response.setContentType("application/json; charset=utf-8");
/*     */     }
/*     */ 
/*  73 */     Writer out = response.getWriter();
/*     */     try {
/*  75 */       writeResponse(getConfFromContext(), out, format);
/*     */     } catch (BadFormatException bfe) {
/*  77 */       response.sendError(400, bfe.getMessage());
/*     */     }
/*  79 */     out.close();
/*     */   }
/*     */ 
/*     */   static void writeResponse(Configuration conf, Writer out, String format)
/*     */     throws IOException, ConfServlet.BadFormatException
/*     */   {
/*  87 */     if ("json".equals(format))
/*  88 */       Configuration.dumpConfiguration(conf, out);
/*  89 */     else if ("xml".equals(format))
/*  90 */       conf.writeXml(out);
/*     */     else
/*  92 */       throw new BadFormatException("Bad format: " + format);
/*     */   }
/*     */ 
/*     */   public static class BadFormatException extends Exception
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public BadFormatException(String msg) {
/* 100 */       super();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.conf.ConfServlet
 * JD-Core Version:    0.6.1
 */
package org.apache.hadoop.conf;

public abstract interface Configurable
{
  public abstract void setConf(Configuration paramConfiguration);

  public abstract Configuration getConf();
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.conf.Configurable
 * JD-Core Version:    0.6.1
 */
package org.apache.hadoop.jmx;

interface package-info
{
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.jmx.package-info
 * JD-Core Version:    0.6.1
 */
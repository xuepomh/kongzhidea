/*     */ package org.apache.hadoop.jmx;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.IntrospectionException;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.RuntimeMBeanException;
/*     */ import javax.management.openmbean.CompositeData;
/*     */ import javax.management.openmbean.CompositeType;
/*     */ import javax.management.openmbean.TabularData;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.hadoop.http.HttpServer;
/*     */ import org.codehaus.jackson.JsonFactory;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ 
/*     */ public class JMXJsonServlet extends HttpServlet
/*     */ {
/* 105 */   private static final Log LOG = LogFactory.getLog(JMXJsonServlet.class);
/*     */   private static final long serialVersionUID = 1L;
/* 113 */   protected transient MBeanServer mBeanServer = null;
/*     */ 
/*     */   public void init()
/*     */     throws ServletException
/*     */   {
/* 122 */     this.mBeanServer = ManagementFactory.getPlatformMBeanServer();
/*     */   }
/*     */ 
/*     */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*     */     try
/*     */     {
/* 137 */       if (!HttpServer.isInstrumentationAccessAllowed(getServletContext(), request, response))
/*     */       {
/* 139 */         return;
/*     */       }
/*     */ 
/* 142 */       response.setContentType("application/json; charset=utf8");
/*     */ 
/* 144 */       PrintWriter writer = response.getWriter();
/*     */ 
/* 146 */       JsonFactory jsonFactory = new JsonFactory();
/* 147 */       JsonGenerator jg = jsonFactory.createJsonGenerator(writer);
/* 148 */       jg.useDefaultPrettyPrinter();
/* 149 */       jg.writeStartObject();
/* 150 */       if (this.mBeanServer == null) {
/* 151 */         jg.writeStringField("result", "ERROR");
/* 152 */         jg.writeStringField("message", "No MBeanServer could be found");
/* 153 */         jg.close();
/* 154 */         return;
/*     */       }
/* 156 */       String qry = request.getParameter("qry");
/* 157 */       if (qry == null) {
/* 158 */         qry = "*:*";
/*     */       }
/* 160 */       listBeans(jg, new ObjectName(qry));
/* 161 */       jg.close();
/*     */     } catch (IOException e) {
/* 163 */       LOG.error("Caught an exception while processing JMX request", e);
/* 164 */       response.setStatus(500);
/*     */     } catch (MalformedObjectNameException e) {
/* 166 */       LOG.error("Caught an exception while processing JMX request", e);
/* 167 */       response.setStatus(400);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void listBeans(JsonGenerator jg, ObjectName qry) throws IOException
/*     */   {
/* 173 */     LOG.debug("Listing beans for " + qry);
/* 174 */     Set names = null;
/* 175 */     names = this.mBeanServer.queryNames(qry, null);
/*     */ 
/* 177 */     jg.writeArrayFieldStart("beans");
/* 178 */     Iterator it = names.iterator();
/* 179 */     while (it.hasNext()) { ObjectName oname = (ObjectName)it.next();
/*     */       MBeanInfo minfo;
/*     */       String code;
/*     */       try { minfo = this.mBeanServer.getMBeanInfo(oname);
/* 185 */         code = minfo.getClassName();
/*     */         try {
/* 187 */           if ("org.apache.commons.modeler.BaseModelMBean".equals(code))
/* 188 */             code = (String)this.mBeanServer.getAttribute(oname, "modelerType");
/*     */         }
/*     */         catch (AttributeNotFoundException e)
/*     */         {
/*     */         }
/*     */         catch (MBeanException e)
/*     */         {
/* 195 */           LOG.error("getting attribute modelerType of " + oname + " threw an exception", e);
/*     */         }
/*     */         catch (RuntimeException e)
/*     */         {
/* 199 */           LOG.error("getting attribute modelerType of " + oname + " threw an exception", e);
/*     */         }
/*     */         catch (ReflectionException e)
/*     */         {
/* 203 */           LOG.error("getting attribute modelerType of " + oname + " threw an exception", e);
/*     */         }
/*     */       } catch (InstanceNotFoundException e)
/*     */       {
/* 207 */         continue;
/*     */       }
/*     */       catch (IntrospectionException e)
/*     */       {
/* 211 */         LOG.error("Problem while trying to process JMX query: " + qry + " with MBean " + oname, e);
/* 212 */         continue;
/*     */       }
/*     */       catch (ReflectionException e)
/*     */       {
/* 216 */         LOG.error("Problem while trying to process JMX query: " + qry + " with MBean " + oname, e);
/* 217 */       }continue;
/*     */ 
/* 220 */       jg.writeStartObject();
/* 221 */       jg.writeStringField("name", oname.toString());
/*     */ 
/* 224 */       jg.writeStringField("modelerType", code);
/*     */ 
/* 226 */       MBeanAttributeInfo[] attrs = minfo.getAttributes();
/* 227 */       for (int i = 0; i < attrs.length; i++) {
/* 228 */         writeAttribute(jg, oname, attrs[i]);
/*     */       }
/*     */ 
/* 233 */       jg.writeEndObject();
/*     */     }
/* 235 */     jg.writeEndArray();
/*     */   }
/*     */ 
/*     */   private void writeAttribute(JsonGenerator jg, ObjectName oname, MBeanAttributeInfo attr) throws IOException {
/* 239 */     if (!attr.isReadable()) {
/* 240 */       return;
/*     */     }
/* 242 */     String attName = attr.getName();
/* 243 */     if ("modelerType".equals(attName)) {
/* 244 */       return;
/*     */     }
/* 246 */     if ((attName.indexOf("=") >= 0) || (attName.indexOf(":") >= 0) || (attName.indexOf(" ") >= 0))
/*     */     {
/* 248 */       return;
/*     */     }
/* 250 */     Object value = null;
/*     */     try {
/* 252 */       value = this.mBeanServer.getAttribute(oname, attName);
/*     */     }
/*     */     catch (RuntimeMBeanException e)
/*     */     {
/* 256 */       if ((e.getCause() instanceof UnsupportedOperationException))
/* 257 */         LOG.debug("getting attribute " + attName + " of " + oname + " threw an exception", e);
/*     */       else {
/* 259 */         LOG.error("getting attribute " + attName + " of " + oname + " threw an exception", e);
/*     */       }
/* 261 */       return;
/*     */     }
/*     */     catch (AttributeNotFoundException e)
/*     */     {
/* 266 */       return;
/*     */     }
/*     */     catch (MBeanException e)
/*     */     {
/* 270 */       LOG.error("getting attribute " + attName + " of " + oname + " threw an exception", e);
/* 271 */       return;
/*     */     }
/*     */     catch (RuntimeException e)
/*     */     {
/* 275 */       LOG.error("getting attribute " + attName + " of " + oname + " threw an exception", e);
/* 276 */       return;
/*     */     }
/*     */     catch (ReflectionException e)
/*     */     {
/* 280 */       LOG.error("getting attribute " + attName + " of " + oname + " threw an exception", e);
/* 281 */       return;
/*     */     }
/*     */     catch (InstanceNotFoundException e)
/*     */     {
/* 286 */       return;
/*     */     }
/*     */ 
/* 289 */     writeAttribute(jg, attName, value);
/*     */   }
/*     */ 
/*     */   private void writeAttribute(JsonGenerator jg, String attName, Object value) throws IOException {
/* 293 */     jg.writeFieldName(attName);
/* 294 */     writeObject(jg, value);
/*     */   }
/*     */ 
/*     */   private void writeObject(JsonGenerator jg, Object value) throws IOException {
/* 298 */     if (value == null) {
/* 299 */       jg.writeNull();
/*     */     } else {
/* 301 */       Class c = value.getClass();
/* 302 */       if (c.isArray()) {
/* 303 */         jg.writeStartArray();
/* 304 */         int len = Array.getLength(value);
/* 305 */         for (int j = 0; j < len; j++) {
/* 306 */           Object item = Array.get(value, j);
/* 307 */           writeObject(jg, item);
/*     */         }
/* 309 */         jg.writeEndArray();
/* 310 */       } else if ((value instanceof Number)) {
/* 311 */         Number n = (Number)value;
/* 312 */         jg.writeNumber(n.toString());
/* 313 */       } else if ((value instanceof Boolean)) {
/* 314 */         Boolean b = (Boolean)value;
/* 315 */         jg.writeBoolean(b.booleanValue());
/* 316 */       } else if ((value instanceof CompositeData)) {
/* 317 */         CompositeData cds = (CompositeData)value;
/* 318 */         CompositeType comp = cds.getCompositeType();
/* 319 */         Set keys = comp.keySet();
/* 320 */         jg.writeStartObject();
/* 321 */         for (String key : keys) {
/* 322 */           writeAttribute(jg, key, cds.get(key));
/*     */         }
/* 324 */         jg.writeEndObject();
/* 325 */       } else if ((value instanceof TabularData)) {
/* 326 */         TabularData tds = (TabularData)value;
/* 327 */         jg.writeStartArray();
/* 328 */         for (Iterator i$ = tds.values().iterator(); i$.hasNext(); ) { Object entry = i$.next();
/* 329 */           writeObject(jg, entry);
/*     */         }
/* 331 */         jg.writeEndArray();
/*     */       } else {
/* 333 */         jg.writeString(value.toString());
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.jmx.JMXJsonServlet
 * JD-Core Version:    0.6.1
 */
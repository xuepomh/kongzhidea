package org.apache.hadoop.classification;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;

@InterfaceAudience.Public
@Evolving
public class InterfaceStability
{
  @Documented
  public static @interface Unstable
  {
  }

  @Documented
  public static @interface Evolving
  {
  }

  @Documented
  public static @interface Stable
  {
  }
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.classification.InterfaceStability
 * JD-Core Version:    0.6.1
 */
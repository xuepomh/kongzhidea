package org.apache.hadoop.classification;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;

@Public
@InterfaceStability.Evolving
public class InterfaceAudience
{
  @Documented
  public static @interface Private
  {
  }

  @Documented
  public static @interface LimitedPrivate
  {
    public abstract String[] value();
  }

  @Documented
  public static @interface Public
  {
  }
}

/* Location:           D:\workspace\hadoop\lib\hadoop-core-1.2.1.jar
 * Qualified Name:     org.apache.hadoop.classification.InterfaceAudience
 * JD-Core Version:    0.6.1
 */